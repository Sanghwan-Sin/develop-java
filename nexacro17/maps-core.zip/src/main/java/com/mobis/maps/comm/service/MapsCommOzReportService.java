package com.mobis.maps.comm.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommOzReportVO;

/**
 * <pre>
 * 오즈 공통 서비스
 * </pre>
 *
 * @ClassName   : MapsCommOzReportService.java
 * @Description : 오즈 공통 서비스
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsCommOzReportService {

    /**
     * MAPS 오즈 공통 리스트 조회
     *
     * @param commDbTblColVO
     * @return
     * @throws Exception
     */
    public MapsCommOzReportVO selectCommMapsOzReport(LoginInfoVO loginInfo , List<MapsCommOzReportVO> mapsCommOzReportVO) throws Exception;
    
    public MapsCommOzReportVO selectCommMapsOzReportMulti(LoginInfoVO loginInfo , List<MapsCommOzReportVO> mapsCommOzReportVO) throws Exception;
    
}
