package com.mobis.maps.iam.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamWordDicaryVO;

/**
 * <pre>
 * 용어사전 관리 서비스
 * </pre>
 *
 * @ClassName   : MapsCommWordDicaryService.java
 * @Description : 용어사전 관리 서비스를 정의.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
public interface MapsIamWordDicaryService {
    
    /**
     * 용어사전 리스트 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public List<MapsIamWordDicaryVO> selectWdDicPgList(MapsIamWordDicaryVO iamWdDicVO) throws Exception;

    /**
     * 용어사전 조회(용어ID+언어코드)
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public MapsIamWordDicaryVO selectWdDicInfoByLangWordId(MapsIamWordDicaryVO iamWdDicVO) throws Exception;
    
    /**
     * 용어사전 등록
     *
     * @param wdDicInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiWdDicInfo(List<MapsIamWordDicaryVO> wdDicInfos, LoginInfoVO loginInfo) throws Exception;
    
    
    /**
     * 용어사전 팝업 리스트 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public List<MapsIamWordDicaryVO> selectWdDicPgPopList(MapsIamWordDicaryVO iamWdDicVO) throws Exception;
    
    /**
     * 참조언어,용어ID에 대한 용어사전 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public MapsIamWordDicaryVO selectWdDicInfoByRefrnLangCd(MapsIamWordDicaryVO iamWdDicVO) throws Exception;

}
