package com.mobis.maps.iam.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.iam.vo.MapsIamLoginHistVO;
import com.mobis.maps.iam.vo.MapsIamPlusPwdArsCrtfcHistVO;
import com.mobis.maps.iam.vo.MapsIamUserAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserExcelUpldVO;
import com.mobis.maps.iam.vo.MapsIamUserIndvdlzMenuVO;
import com.mobis.maps.iam.vo.MapsIamUserIndvdlzScrinFnctVO;
import com.mobis.maps.iam.vo.MapsIamUserLangVO;
import com.mobis.maps.iam.vo.MapsIamUserMenuVO;
import com.mobis.maps.iam.vo.MapsIamUserPermIpVO;
import com.mobis.maps.iam.vo.MapsIamUserPwdChghstVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinConectHistVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinFnctVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;

/**
 * <pre>
 * 사용자관리 서비스
 * </pre>
 *
 * @ClassName   : MapsIamUserService.java
 * @Description : 사용자관리에 대한 서비스를 정의.
 * @author 최은삼
 * @since 2019. 12. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 13.     최은삼     	최초 생성
 * </pre>
 */

public interface MapsIamUserService {

    /**
     * 사용자 페이징리스트 조회
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectUserPgList(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 일반사용자 페이징리스트 조회
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectNormalUserPgList(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자 상세 조회
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsIamUserVO selectUserDetail(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 프로퍼티 사용자 초기암호 취득
     * 특정 문자에서 a# + USR_ID로 변경함
     * @return
     * @throws MapsBizException 
     */
    public String selectGetPropInitlUserPwd(String usrId ,String sysSeCd) throws Exception ;
    
    /**
     * 프로퍼티 암호변경주기일수 취득
     *
     * @return
     */
    public int selectGetPropPwdChageCyclDayCnt() throws Exception;
    
    /**
     * 사용자 조회
     *
     * @param userSeqId
     * @return
     */
    public MapsIamUserVO selectUser(String userSeqId) throws Exception;

    /**
     * 사용자 저장
     *
     * @param iamUsers
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiUser(List<MapsIamUserVO> iamUsers, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자 액셀업로드 저장
     *
     * @param request
     * @param response
     * @param iamUserExcelUpldVO
     * @param loginInfo
     * @throws Exception
     */
    public void multiUserInfoFiileUpload(HttpServletRequest request, HttpServletResponse response, MapsIamUserExcelUpldVO iamUserExcelUpldVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자 계정잠김해제
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateUserUnlock(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자 암호초기화(사용자)
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateUserResetPwd02(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자 암호초기화(암호만료)
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateUserResetPwd03(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자 암호초기화(암호변경횟수초과)
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateUserResetPwd04(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자 암호초기화(관리자암호초기화)
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateUserResetPwd05(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자 암호만료일 연장
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateUserPwdEndDtExtn(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자 퇴사
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateRetireUser(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 일반사용자 저장
     *
     * @param iamUsers
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiNormalUser(List<MapsIamUserVO> iamUsers, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자 변경이력 페이징리스트 조회
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectUserChghstPgList(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자허용IP 리스트 조회
     *
     * @param iamUserPermIpVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserPermIpVO> selectUserPermIpList(MapsIamUserPermIpVO iamUserPermIpVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자허용IP 저장
     *
     * @param userPermIps
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiUserPermIp(List<MapsIamUserPermIpVO> userPermIps, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자언어 리스트 조회
     *
     * @param iamUserLangVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserLangVO> selectUserLangList(MapsIamUserLangVO iamUserLangVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자언어 저장
     *
     * @param userLangs
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiUserLang(List<MapsIamUserLangVO> userLangs, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자암호변경이력 페이징리스트 조회
     *
     * @param iamUserPwdChghstVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserPwdChghstVO> selectUserPwdChghstPgList(MapsIamUserPwdChghstVO iamUserPwdChghstVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자권한 리스트 조회
     *
     * @param iamUserAuthorVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserAuthorVO> selectUserAuthorList(MapsIamUserAuthorVO iamUserAuthorVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자권한 저장
     *
     * @param userAuthors
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiUserAuthor(List<MapsIamUserAuthorVO> userAuthors, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자개별메뉴 리스트 조회
     *
     * @param iamUserIndvdlzMenuVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserIndvdlzMenuVO> selectUserIndvdlzMenuList(MapsIamUserIndvdlzMenuVO iamUserIndvdlzMenuVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자개별메뉴 저장
     *
     * @param userIndvdlzMenus
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiUserIndvdlzMenu(List<MapsIamUserIndvdlzMenuVO> userIndvdlzMenus, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자개별 화면기능 리스트 조회
     *
     * @param iamUserIndvdlzScrinFnctVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserIndvdlzScrinFnctVO> selectUserIndvdlzScrinFnctList(MapsIamUserIndvdlzScrinFnctVO iamUserIndvdlzScrinFnctVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자개별 화면기능 저장
     *
     * @param userIndvdlzScrinFncts
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiUserIndvdlzScrinFnct(List<MapsIamUserIndvdlzScrinFnctVO> userIndvdlzScrinFncts, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자메뉴 리스트 조회
     *
     * @param iamUserMenuVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserMenuVO> selectUserMenuList(MapsIamUserMenuVO iamUserMenuVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자화면기능 리스트 조회
     *
     * @param iamUserScrinFnctVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinFnctVO> selectUserScrinFnctList(MapsIamUserScrinFnctVO iamUserScrinFnctVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 로그인이력 페이징리스트 조회
     *
     * @param iamLoginHistVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamLoginHistVO> selectLoginHistPgList(MapsIamLoginHistVO iamLoginHistVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자화면접속이력 페이징리스트 조회
     *
     * @param imUserScrinConectHistVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinConectHistVO> selectUserScrinConectHistPgList(MapsIamUserScrinConectHistVO imUserScrinConectHistVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자 페이징리스트 팝업 조회
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectPopupUserPgList(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자ID찾기
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectFindUserId(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자비밀번호찾기
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateFindUserPwd(MapsIamUserVO iamUserVO) throws Exception;

    /**
     * 관리자 이메일 리스트 조회
     *
     * @param iamUserVO
     * @param orgnztDistVO
     * @param isIncludeOprtr
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectMngrEmailList(MapsIamUserVO iamUserVO, MapsOrgnztDistVO orgnztDistVO, boolean isIncludeOprtr) throws Exception;
    
    /**
     * 사용자 계정잠김해제
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateAcntUnlock(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 로그인 사용자 수정
     *
     * @param iamUserBassInfoVO
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateLoginUserInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 계정 개인정보수집및이용동의
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateAcntIndvdlinfoColctUseAgre(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * ARS 인증 등록
     *
     * @param iamPlusPwdArsCrtfcHistVO
     * @throws Exception
     */
    public int insertPlusPwdArsCrtfcHist(MapsIamPlusPwdArsCrtfcHistVO iamPlusPwdArsCrtfcHistVO) throws Exception;
    
    /**
     * ARS 인증 UPDATE
     *
     * @param iamPlusPwdArsCrtfcHistVO
     * @throws Exception
     */
    public int updatePlusPwdArsCrtfcHist(MapsIamPlusPwdArsCrtfcHistVO iamPlusPwdArsCrtfcHistVO) throws Exception;
    
}
