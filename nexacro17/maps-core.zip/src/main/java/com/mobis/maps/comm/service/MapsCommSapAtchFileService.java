package com.mobis.maps.comm.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileChkVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileCntVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileVO;

/**
 * <pre>
 * SAP 첨부파일 서비스
 * </pre>
 *
 * @ClassName   : MapsCommSapAtchFileService.java
 * @Description : SAP 첨부파일에 대한 서비스를 정의.
 * @author DT048058
 * @since 2020. 3. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 3.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsCommSapAtchFileService {

    public static final String PARAM_TARGET_FILE_INFO = "INFO";
    public static final String PARAM_TARGET_FILE_COUNT = "COUNT";
    public static final String PARAM_TARGET_FILE_SUM = "SUM";
    public static final String PARAM_TARGET_FILE_LIST = "LIST";
    public static final String PARAM_TARGET_FILE_CONTENT = "CONTENT";
    public static final String PARAM_TARGET_FILE_CREATE = "CREATE";
    public static final String PARAM_TARGET_FILE_UPDATE = "UPDATE";
    public static final String PARAM_TARGET_FILE_DELETE = "DELETE";
    public static final String PARAM_TARGET_FILE_ALL_DELETE = "ALL_DELETE";
    
    public static final String FIELD_TARGET_I_REF_NO_T = "I_REF_NO_T";
    public static final String FIELD_TARGET_ES_CREATE = "ES_CREATE";
    public static final String FIELD_TARGET_ES_CONFIG = "ES_CONFIG";
    public static final String FIELD_TARGET_ES_MASTER = "ES_MASTER";
    public static final String FIELD_TARGET_ES_ATTACH_COUNT = "ES_ATTACH_COUNT";
    public static final String FIELD_TARGET_ES_ATTACH = "ES_ATTACH";
    public static final String FIELD_TARGET_IT_ATTACH_SUM = "IT_ATTACH_SUM";
    public static final String FIELD_TARGET_IT_ATTACH = "IT_ATTACH";
    
    
    public static final String MAP_KEY_ES_CONFIG = "esConfig";
    public static final String MAP_KEY_ES_MASTER = "esMaster";
    public static final String MAP_KEY_ES_CREATE = "esCreate";

    /**
     * SAP 첨부파일 리스트 조회
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileVO> selectSapAtchFileList(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * SAP 첨부파일 상세 조회
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileVO selectSapAtchFileDetail(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception; 
    
    /**
     * SAP 첨부파일 건수 조회
     *
     * @param commSapAtchFileInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileInfoVO selectSapAtchFileCnt(MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 건수 조회(복수건)
     *
     * @param commSapAtchFileCntVO
     * @param refNos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileCntVO> selectSapAtchFileCntList(MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , List<MapsCommSapAtchFileCntVO> refNos
            , LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 Summary건수 조회
     *
     * @param commSapAtchFileCntVO
     * @param refNos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileCntVO> selectSapAtchFileSumryCnt(MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , List<MapsCommSapAtchFileCntVO> refNos
            , LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 등록정보 조회
     *
     * @param commSapAtchFileInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public Map<String, MapsCommSapAtchFileInfoVO> selectSapAtchFileRegistInfo(MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 체크
     *
     * @param commSapAtchFileChkVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileChkVO selectSapAtchFileChk(MapsCommSapAtchFileChkVO commSapAtchFileChkVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 등록
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileVO insertSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 수정
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileVO updateSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 삭제
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileVO deleteSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 전체 삭제
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileVO> deleteAllSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;

}
