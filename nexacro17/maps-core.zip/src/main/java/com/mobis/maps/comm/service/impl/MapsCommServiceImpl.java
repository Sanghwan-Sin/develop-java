package com.mobis.maps.comm.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.WebUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommScrinConectInfoService;
import com.mobis.maps.comm.service.MapsCommService;
import com.mobis.maps.comm.service.dao.MapsCommMDAO;
import com.mobis.maps.comm.vo.MapsCommOrgnztVO;
import com.mobis.maps.comm.vo.MapsCommScrinConectInfoVO;
import com.mobis.maps.comm.vo.ScrinConectInfoVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;

/**
 * <pre>
 * MAPS공통 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommServiceImpl.java
 * @Description : MAPS공통에 대한 서비스 구현.
 * @author DT048058
 * @since 2020. 1. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 30.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsCommService")
public class MapsCommServiceImpl extends HService implements MapsCommService {

    @Resource(name = "mapsCommScrinConectInfoService")
    private MapsCommScrinConectInfoService mapsCommScrinConectInfoService;

    @Resource(name = "mapsCommMDAO")
    private MapsCommMDAO mapsCommMDAO;
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommService#insertScrinConectInfo(javax.servlet.http.HttpServletRequest, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public void insertScrinConectInfo(HttpServletRequest request, LoginInfoVO loginInfo) throws Exception {

        MapsCommScrinConectInfoVO scrinConectInfoVO = new MapsCommScrinConectInfoVO();
        
        /* 파라미터 정보 설정 */
        // 파라미터 정보 취득
        String sysSeCd = request.getParameter("sysSeCd");
        String menuId = request.getParameter("menuId");
        String scrinId = request.getParameter("scrinId");
        // 파라미터 정보 설정
        scrinConectInfoVO.setSysSeCd(sysSeCd);
        scrinConectInfoVO.setMenuId(menuId);
        scrinConectInfoVO.setScrinId(scrinId);
        // 화면 정보 확인
        MapsIamScreenVO scrinInfo = mapsCommScrinConectInfoService.selectScrinInfo(scrinConectInfoVO);
        if (scrinInfo == null) {
            throw new MapsBizException(messageSource, "ECI0000005");    //사용할 수 없는 화면입니다.
        }
        
        /* 로그인 정보 설정 */
        if (loginInfo != null) {
            scrinConectInfoVO.setUserId(loginInfo.getUserId());
            scrinConectInfoVO.setConectId(loginInfo.getUserSeqId());
        } else {
            scrinConectInfoVO.setUserId("NON-LOGIN");
            scrinConectInfoVO.setConectId("NON-LOGIN");
        }

        /* 요청 정보 설정 */
        String serverNm = request.getServerName();
        String userAgent = WebUtil.getUserAgent(request);
        String brwsrNm = WebUtil.getBrowserName(request);
        String conectIpAdres = WebUtil.getUserIpAdres(request);

        scrinConectInfoVO.setServerNm(serverNm);
        scrinConectInfoVO.setUserAgent(userAgent);
        scrinConectInfoVO.setBrwsrNm(brwsrNm);
        scrinConectInfoVO.setConectIpAdres(conectIpAdres);

        /* 화면 접속 정보 등록 */
        insertScrinConectInfo(scrinConectInfoVO);
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommService#insertScrinConectInfo(java.lang.String, java.lang.String, java.lang.String, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public void insertScrinConectInfo(ScrinConectInfoVO connectInfo, LoginInfoVO loginInfo) throws Exception {

        /* 화면 접속 정보 설정 */
        MapsCommScrinConectInfoVO scrinConectInfoVO = new MapsCommScrinConectInfoVO();
        scrinConectInfoVO.setSysSeCd(connectInfo.getSysSeCd());
        scrinConectInfoVO.setMenuId(connectInfo.getMenuId());
        scrinConectInfoVO.setScrinId(connectInfo.getScrinId());
        scrinConectInfoVO.setServerNm(connectInfo.getServerNm());
        scrinConectInfoVO.setUserAgent(connectInfo.getUserAgent());
        scrinConectInfoVO.setBrwsrNm(connectInfo.getBrwsrNm());
        scrinConectInfoVO.setConectIpAdres(connectInfo.getConectIpAdres());

        MapsIamScreenVO scrinInfo = mapsCommScrinConectInfoService.selectScrinInfo(scrinConectInfoVO);
        if (scrinInfo == null) {
            throw new MapsBizException(messageSource, "ECI0000005");    //사용할 수 없는 화면입니다.
        }
        
        /* 로그인 정보 설정 */
        if (loginInfo != null) {
            scrinConectInfoVO.setUserId(loginInfo.getUserId());
            scrinConectInfoVO.setConectId(loginInfo.getUserSeqId());
        } else {
            scrinConectInfoVO.setUserId("NON-LOGIN");
            scrinConectInfoVO.setConectId("NON-LOGIN");
        }

        /* 화면 접속 정보 등록 */
        insertScrinConectInfo(scrinConectInfoVO);
    }

    /**
     * 화면접속정보 등록
     *
     * @param scrinConectInfoVO
     * @throws Exception
     */
    private void insertScrinConectInfo(MapsCommScrinConectInfoVO scrinConectInfoVO) throws Exception {

        String serverProfl = WebUtil.getServerProfile();
        if (StringUtils.isBlank(serverProfl)) {
            serverProfl = WebUtil.getServerProfile(scrinConectInfoVO.getServerNm());
        }
        scrinConectInfoVO.setServerProfl(serverProfl);
        
        if (logger.isDebugEnabled()) {
            logger.debug("→ insertScrinConectInfo.start"
                    +"[sysSeCd="+scrinConectInfoVO.getSysSeCd()
                    +",userId="+scrinConectInfoVO.getUserId()
                    +",menuId="+scrinConectInfoVO.getMenuId()
                    +",scrinId="+scrinConectInfoVO.getScrinId()
                    +",serverNm="+scrinConectInfoVO.getServerNm()
                    +",serverProfl="+scrinConectInfoVO.getServerProfl()
                    +",userAgent="+scrinConectInfoVO.getUserAgent()
                    +",brwsrNm="+scrinConectInfoVO.getBrwsrNm()
                    +",conectId="+scrinConectInfoVO.getConectId()
                    +",conectIpAdres="+scrinConectInfoVO.getConectIpAdres()
            +"]");
        }
        mapsCommScrinConectInfoService.insertScrinConectInfo(scrinConectInfoVO);
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommService#selectOrgnztPgList(com.mobis.maps.comm.vo.MapsCommOrgnztVO)
     */
    @Override
    public List<MapsCommOrgnztVO> selectOrgnztPgList(MapsCommOrgnztVO commOrgnztVO) throws Exception {

        // RFC PC SYSTEM 설정
        commOrgnztVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        commOrgnztVO.setRfcPcClient(RfcSapSys.PC.getClient());
        // RFC PW SYSTEM 설정
        commOrgnztVO.setRfcPwSysId(RfcSapSys.PW.getSysId());
        commOrgnztVO.setRfcPwClient(RfcSapSys.PW.getClient());
        
        List<MapsCommOrgnztVO> lstOrgnzt = mapsCommMDAO.selectOrgnztPgList(commOrgnztVO);
        
        return lstOrgnzt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommService#selectOrgnztNm(com.mobis.maps.comm.vo.MapsCommOrgnztVO)
     */
    @Override
    public MapsCommOrgnztVO selectOrgnztNm(MapsCommOrgnztVO commOrgnztVO) throws Exception {
        
        MapsCommOrgnztVO rsltOrgnztVO = null;
        
        if (StringUtils.isBlank(commOrgnztVO.getOrgnztSeCd())
                || StringUtils.isBlank(commOrgnztVO.getOrgnztCd())) {
            return rsltOrgnztVO;
        }

        // RFC PC SYSTEM 설정
        commOrgnztVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        commOrgnztVO.setRfcPcClient(RfcSapSys.PC.getClient());
        // RFC PW SYSTEM 설정
        commOrgnztVO.setRfcPwSysId(RfcSapSys.PW.getSysId());
        commOrgnztVO.setRfcPwClient(RfcSapSys.PW.getClient());
        
        rsltOrgnztVO = mapsCommMDAO.selectOrgnztNm(commOrgnztVO);
        
        return rsltOrgnztVO;
    }

}
