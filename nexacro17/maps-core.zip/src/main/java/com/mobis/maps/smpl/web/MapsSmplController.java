package com.mobis.maps.smpl.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.smpl.service.MapsSmplService;
import com.mobis.maps.smpl.vo.MapsSmplAtchFileVO;
import com.mobis.maps.smpl.vo.MapsSmplFileUpVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 10.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Controller
public class MapsSmplController extends HController {

    @Resource(name = "mapsSmplService")
    private MapsSmplService mapsSmplService;
    
    /**
     * 샘플 첨부파일 등록
     *
     * @param smplAtchFileVO
     * @param atchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/smpl/multiSmplAtchFile.do")
    public NexacroResult multiSmplAtchFile(
            @ParamDataSet(name="dsInput") MapsSmplAtchFileVO smplAtchFileVO
            , @ParamDataSet(name="dsInputAtchFile") List<MapsAtchFileVO> atchFiles
            , NexacroResult result) throws Exception {
        
        int procCnt = mapsSmplService.multiSmplAtchFile(smplAtchFileVO, atchFiles);

        result.addVariable("procCnt", procCnt);

        return result;
    }
    
    /**
     * 샘플 파일업로드
     *
     * @param atchSe
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/smpl/selectFileUpload.do", method = {RequestMethod.GET, RequestMethod.POST})
    public NexacroResult selectFileUpload(
            @RequestParam("atchSe") String atchSe
            , HttpServletRequest request
            , NexacroResult result) throws Exception {

        MapsSmplFileUpVO smplFileUpVO = mapsSmplService.selectFileUpload(request, atchSe);
        
        result.addDataSet("dsOutput", smplFileUpVO.getAtchFileVO());
        result.addDataSet("dsOutputAtchFiles", smplFileUpVO.getAtchFiles());
        
        return result;
    }
}
