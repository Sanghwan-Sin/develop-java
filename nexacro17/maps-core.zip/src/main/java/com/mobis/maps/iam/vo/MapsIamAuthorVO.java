package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * 권한관리 항목
 * </pre>
 *
 * @ClassName   : MapsIamAuthorVO.java
 * @Description : 권한관리에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 10.     DT048058     	최초 생성
 * </pre>
 */
public class MapsIamAuthorVO extends MapsIamCommVO {
    /* 조회조건 */
    /** 시작일자 */
    private Date strtDt;
    /** 종료일자 */
    private Date endDt;
    /* 데이터항목 */
    /** 권한ID */
    private String authorId;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 권한명 */
    private String authorNm;
    /** 전체사용자권한여부 */
    private String allAuthorUseYn;
    /** 권한설명 */
    private String authorDc;
    /** 사용여부 */
    private String useYn;
    /* 등록항목 */
    /** 가져오기권한ID */
    private String importAuthorId;
    /* 변경이력 */
    /** 변경구분코드 */
    private String changeSeCd;
    /** 변경자ID */
    private String changeId;
    /** 변경일시 */
    private Date changeDt;
    /**
     * @return the strtDt
     */
    public Date getStrtDt() {
        return strtDt;
    }
    /**
     * @param strtDt the strtDt to set
     */
    public void setStrtDt(Date strtDt) {
        this.strtDt = strtDt;
    }
    /**
     * @return the endDt
     */
    public Date getEndDt() {
        return endDt;
    }
    /**
     * @param endDt the endDt to set
     */
    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }
    /**
     * @return the authorId
     */
    public String getAuthorId() {
        return authorId;
    }
    /**
     * @param authorId the authorId to set
     */
    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the authorNm
     */
    public String getAuthorNm() {
        return authorNm;
    }
    /**
     * @param authorNm the authorNm to set
     */
    public void setAuthorNm(String authorNm) {
        this.authorNm = authorNm;
    }
    /**
     * @return the allAuthorUseYn
     */
    public String getAllAuthorUseYn() {
        return allAuthorUseYn;
    }
    /**
     * @param allAuthorUseYn the allAuthorUseYn to set
     */
    public void setAllAuthorUseYn(String allAuthorUseYn) {
        this.allAuthorUseYn = allAuthorUseYn;
    }
    /**
     * @return the authorDc
     */
    public String getAuthorDc() {
        return authorDc;
    }
    /**
     * @param authorDc the authorDc to set
     */
    public void setAuthorDc(String authorDc) {
        this.authorDc = authorDc;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * @return the importAuthorId
     */
    public String getImportAuthorId() {
        return importAuthorId;
    }
    /**
     * @param importAuthorId the importAuthorId to set
     */
    public void setImportAuthorId(String importAuthorId) {
        this.importAuthorId = importAuthorId;
    }
    /**
     * @return the changeSeCd
     */
    public String getChangeSeCd() {
        return changeSeCd;
    }
    /**
     * @param changeSeCd the changeSeCd to set
     */
    public void setChangeSeCd(String changeSeCd) {
        this.changeSeCd = changeSeCd;
    }
    /**
     * @return the changeId
     */
    public String getChangeId() {
        return changeId;
    }
    /**
     * @param changeId the changeId to set
     */
    public void setChangeId(String changeId) {
        this.changeId = changeId;
    }
    /**
     * @return the changeDt
     */
    public Date getChangeDt() {
        return changeDt;
    }
    /**
     * @param changeDt the changeDt to set
     */
    public void setChangeDt(Date changeDt) {
        this.changeDt = changeDt;
    }
}