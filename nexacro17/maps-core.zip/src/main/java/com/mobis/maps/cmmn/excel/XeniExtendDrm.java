package com.mobis.maps.cmmn.excel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nexacro17.xapi.data.DataSet;
import com.nexacro17.xapi.data.PlatformData;
import com.nexacro17.xapi.data.VariableList;
import com.nexacro17.xapi.tx.HttpPlatformResponse;
import com.nexacro17.xapi.tx.PlatformType;
import com.nexacro17.xeni.extend.XeniExcelDataStorageBase;
import com.nexacro17.xeni.util.CommUtil;

/**
 * <pre>
 * Xeni사용시 DRM 처리
 * </pre>
 *
 * @ClassName   : XeniExtendDrm.java
 * @Description : Xeni사용시 DRM 처리
 * @author Sin Sanghwan
 * @since 2019. 8. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 5.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class XeniExtendDrm implements XeniExcelDataStorageBase {

    private static Logger logger = LoggerFactory.getLogger(XeniExtendDrm.class);

    /*
     * @see com.nexacro17.xeni.extend.XeniExcelDataStorageBase#loadTargetStream(java.lang.String)
     */
    @Override
    public InputStream loadTargetStream(String filepath) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ loadTargetStream.start[filepath="+filepath+"]");
        }
        File file = new File(filepath);

        return new FileInputStream(file);
    }

    /*
     * @see com.nexacro17.xeni.extend.XeniExcelDataStorageBase#saveImportStream(com.nexacro17.xapi.data.VariableList, java.io.InputStream, java.lang.String)
     */
    @Override
    public String saveImportStream(VariableList varlist
            , InputStream in
            , String filepath) throws Exception {

        if (logger.isDebugEnabled()) {
            logger.debug("→ saveImportStream1.start[filepath="+filepath+"]");
        }
        //FileOutputStream fout = null;
        try {
            String fileName = UUID.randomUUID().toString();
            int nFileIdx = filepath.lastIndexOf("/");
            String sFileParent = StringUtils.substring(filepath, 0, nFileIdx);
            String sFilePath = sFileParent + "/" + fileName;
            
            File fFilePath = new File(sFileParent);
            if (!fFilePath.exists()) {
                fFilePath.mkdirs();
            }
            //fout = new FileOutputStream(sFilePath);
            
            FileUtils.copyInputStreamToFile(in, new File(sFilePath));
            /*
            byte[] buf = new byte[1024];
            int length = 0;
            while ((length = in.read(buf)) > 0) {
                fout.write(buf, 0, length);
            }
            fout.flush();
            fout.close();
            in.close();
            */

//            boolean isSuccess = true;
//            if (isSuccess) {
//                File delFile = new File(srcFile);
//                if (delFile.exists()) {
//                    fPath.delete();
//                }
//            }
        } finally {
            if (logger.isDebugEnabled()) {
                logger.debug("→ saveImportStream.finally[filepath="+filepath+"]");
            }
        }
        return null;
    }

    /*
     * @see com.nexacro17.xeni.extend.XeniExcelDataStorageBase#saveExportStream(com.nexacro17.xapi.data.VariableList, com.nexacro17.xapi.data.DataSet, java.io.ByteArrayOutputStream, java.lang.String, java.lang.String)
     */
    @Override
    public DataSet saveExportStream(VariableList varlist
            , DataSet dscmd
            , ByteArrayOutputStream out
            , String filepath
            , String fileurl) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ saveImportStream2.start[filepath="+filepath+",fileurl="+fileurl+"]");
        }
        DataSet dsRes = null;
        FileOutputStream fout = null;
        try {
            
            String fileName = UUID.randomUUID().toString();
            int nFileIdx = filepath.lastIndexOf("/");
            String sFileParent = StringUtils.substring(filepath, 0, nFileIdx);
            int nUrlIdx = StringUtils.lastIndexOf(fileurl, "/");
            String sUrlParent = StringUtils.substring(fileurl, 0, nUrlIdx);
            String sFilePath = sFileParent + "/" + fileName;
            String sFileUrl = sUrlParent + "/" + fileName;
            
            File fFilePath = new File(sFileParent);
            if (!fFilePath.exists()) {
                fFilePath.mkdirs();
            }
            
            /* 파일처리 */
            fout = new FileOutputStream(sFilePath);
            fout.write(out.toByteArray());
            fout.close();
            out.close();
            
            /* DRM 처리 */
            @SuppressWarnings("unused")
            String drmFlag = "N";
            if (varlist != null) {
                drmFlag = StringUtils.defaultIfEmpty(varlist.getString("drmFlag"), "N");
            }
            dsRes = CommUtil.getDatasetExportResponse(dscmd);
            dsRes.set(0, "url", sFileUrl);
        } finally {
            if (fout != null) {fout.close();}
        }
        return dsRes;
    }

    /*
     * @see com.nexacro17.xeni.extend.XeniExcelDataStorageBase#saveExportStream(com.nexacro17.xapi.data.VariableList, com.nexacro17.xapi.data.DataSet, java.io.ByteArrayOutputStream, java.lang.String, java.lang.String, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public int saveExportStream(VariableList varlist
            , DataSet dscmd
            , ByteArrayOutputStream out
            , String filepath
            , String fileurl
            , HttpServletResponse response) throws Exception {

        if (logger.isDebugEnabled()) {
            logger.debug("→ saveImportStream3.start[filepath="+filepath+",fileurl="+fileurl+"]");
        }
        FileOutputStream fout = null;
        try {
//        String fileurl = "";
//        if (filepath != null && filepath != "") {
//            int nFileNameStart = StringUtils.lastIndexOf(fileurlIn, "/");
//            String fileFirstUrl = StringUtils.substring(fileurlIn, 0, nFileNameStart);
//            // uuid로 파일 생성(한글 파일 생성필요없음)
//            String fileName = UUID.randomUUID().toString();
//            fileurl = fileFirstUrl + "/" + fileName;
//
//            int nIdx = filepath.lastIndexOf("/");
//            String sPath = filepath.substring(0, nIdx);
//            File file = new File(sPath);
//            if (!file.exists()) {
//                file.mkdirs();
//            }
//            int fileSize = out.toByteArray().length;
//            fout = new FileOutputStream(sPath + File.separator + fileName);
//            fout.write(out.toByteArray());
//            fout.close();
//            out.close();
//
//            String drmFlag = "";
//            if (varlist != null) {
//                drmFlag = StringUtils.defaultIfEmpty(varlist.getString("drmFlag"), "N");
//            } else {
//                drmFlag = "N";
//            }
//            // 다시 원복처리
//            if ("Y".equals(drmFlag.toUpperCase())) {
//                // encrypt 처리
//                File srcFile = new File(filepath);
//                File dstFile = DocPsrvUtil.encryptScDsFile(srcFile);
//                String srcFileName = StringUtil.isNullToString(srcFile.getName());
//                String dstFileName = StringUtil.isNullToString(dstFile.getName());
//                FileUtil fileUtil = new FileUtil();
//                logger.debug("[Excel Export SRC] " + srcFile.getAbsolutePath());
//                logger.debug("[Excel Export DST] " + dstFile.getAbsolutePath());
//                if ((!srcFileName.equals(dstFileName)) && (fileUtil.moveFile(dstFile, srcFile))) {
//                    // if(fileUtil.moveFile(dstFile, srcFile)){
//                    logger.debug("[Excel Export DST] 파일 삭제 : " + dstFile.getAbsolutePath() + File.separator
//                            + dstFile.getName());
//                    // }
//                    // }else{
//                    // throw new ExcelBindingException("ERR0006");
//                }
//                logger.debug("[Excel Export DST] 다운로드 " + filepath);
//            }
//
//            if (varlist != null) {
//                for (int i = 0; i < varlist.size(); i++) {
//                    logger.debug(varlist.keyList().get(i) + " : " + varlist.getString(i));
//                }
//            }
//
//            if ("Y".equals(varlist.getString("noTranYn"))) {
//            }
//        }
            
            /*
            String fileName = UUID.randomUUID().toString();
            int nFileIdx = filepath.lastIndexOf("/");
            String sFileParent = StringUtils.substring(filepath, 0, nFileIdx);
            int nUrlIdx = StringUtils.lastIndexOf(fileurl, "/");
            String sUrlParent = StringUtils.substring(fileurl, 0, nUrlIdx);
            String sFilePath = sFileParent + "/" + fileName;
            String sFileUrl = sUrlParent + "/" + fileName;
            
            File fFilePath = new File(sFileParent);
            if (!fFilePath.exists()) {
                fFilePath.mkdirs();
            }
            */
            /* 파일처리 */
            /*
            fout = new FileOutputStream(sFilePath);
            fout.write(out.toByteArray());
            fout.close();
            out.close();
            */
            
            int nFileIdx = filepath.lastIndexOf("/");
            String sFileParent = StringUtils.substring(filepath, 0, nFileIdx);
            File fFilePath = new File(sFileParent);
            if (!fFilePath.exists()) {
                fFilePath.mkdirs();
            }
            
            fout = new FileOutputStream(filepath);
            fout.write(out.toByteArray());
            fout.close();
            out.close();
            
            
            /* DRM 처리 */
            String drmFlag = "N";
            if (varlist != null) {
                printVarlist(varlist);
                drmFlag = StringUtils.defaultIfEmpty(varlist.getString("drmFlag"), "N");
            }
            /*
            boolean isSuccess = true;
            if (isSuccess) {
                File delFile = new File(sFilePath);
                if (delFile.exists()) {
                    fFilePath.delete();
                    if (logger.isDebugEnabled()) {
                        logger.debug("→ saveImportStream3.fFilePath[path="+fFilePath.getPath()+",exists="+fFilePath.exists()+"]");
                    }
                }
            }
            */
            DataSet dsRes = CommUtil.getDatasetExportResponse(dscmd);
    
            PlatformData resData = new PlatformData();
            VariableList varList = resData.getVariableList();
    
            varList.add("ErrorCode", 0);
            varList.add("ErrorMsg", "SUCCESS");

            
            dsRes.set(0, "url", fileurl);
            resData.addDataSet(dsRes);
    
            HttpPlatformResponse platformRes = new HttpPlatformResponse(response, PlatformType.CONTENT_TYPE_SSV, "UTF-8");
            platformRes.setData(resData);
            platformRes.sendData();
        } finally {
            if (fout != null) {fout.close();}
        }
        return 0;
    }

    /**
     * printVarlist
     *
     * @param varlist
     */
    private void printVarlist(VariableList varlist) {
        for (int i = 0; i < varlist.size(); i++) {
            if (logger.isDebugEnabled()) {
                logger.debug("→ saveImportStream3.varlist["+i+"][" + varlist.keyList().get(i) + " : " + varlist.getString(i) + "]");
            }
        }
    }

}
