package com.mobis.maps.cmmn.vo;

import java.io.Serializable;

import able.com.service.file.FileVO;

import com.mobis.maps.cmmn.util.FileUploadUtil;

/**
 * <pre>
 * 첨부파일정보 항목
 * </pre>
 *
 * @ClassName   : MapsAtchFileVO.java
 * @Description : 첨부파일정보 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 8.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsAtchFileVO extends FileVO implements Serializable {

    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = 1L;
    /** 선택여부 */
    private String chkYn = "N";
    /** 첨부구분 */
    private String atchSe;
    /** 첨부ID */
    private String atchId;
    /** 파일NO */
    private int fileNo;
    /** 등록ID */
    private String registId;
    /** 등록일시 */
    private String registDt;
    
    public String getStoredFileFullPath() {
        return FileUploadUtil.getFileFolder(getFolderPath(), getStoredFileName());
    }
    
    /**
     * @return the chkYn
     */
    public String getChkYn() {
        return chkYn;
    }
    /**
     * @param chkYn the chkYn to set
     */
    public void setChkYn(String chkYn) {
        this.chkYn = chkYn;
    }
    /**
     * @return the atchSe
     */
    public String getAtchSe() {
        return atchSe;
    }
    /**
     * @param atchSe the atchSe to set
     */
    public void setAtchSe(String atchSe) {
        this.atchSe = atchSe;
    }
    /**
     * @return the atchId
     */
    public String getAtchId() {
        return atchId;
    }
    /**
     * @param atchId the atchId to set
     */
    public void setAtchId(String atchId) {
        this.atchId = atchId;
    }
    /**
     * @return the fileNo
     */
    public int getFileNo() {
        return fileNo;
    }
    /**
     * @param fileNo the fileNo to set
     */
    public void setFileNo(int fileNo) {
        this.fileNo = fileNo;
    }
    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }
    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }
    /**
     * @return the registDt
     */
    public String getRegistDt() {
        return registDt;
    }
    /**
     * @param registDt the registDt to set
     */
    public void setRegistDt(String registDt) {
        this.registDt = registDt;
    }
}
