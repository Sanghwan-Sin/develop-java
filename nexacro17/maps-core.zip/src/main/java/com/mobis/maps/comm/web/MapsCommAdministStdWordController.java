package com.mobis.maps.comm.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommAdministStdWordService;
import com.mobis.maps.comm.vo.MapsCommAdministStdWordVO;

/**
 * <pre>
 * 행정표준용어 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommAdministStdWordController.java
 * @Description : 행정표준용어에 대한 컨트롤러를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommAdministStdWordController extends HController {

    @Resource(name = "mapsCommAdministStdWordService")
    private MapsCommAdministStdWordService mapsCommAdministStdWordService;
    
    /**
     * 행정표준용어 리스트 조회
     *
     * @param commAdministStdWordVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectAdministStdWordPgList.do")
    public NexacroResult selectAdministStdWordPgList(
            @ParamDataSet(name="dsPgInput") MapsCommAdministStdWordVO commAdministStdWordVO
            , NexacroResult result) throws Exception {
        
        List<MapsCommAdministStdWordVO> administStdWords = mapsCommAdministStdWordService.selectAdministStdWordPgList(commAdministStdWordVO);
        
        result.addDataSet("dsPgOutput", administStdWords);
        
        return result;
    }
    /**
     * 행정표준용어 액셀다운로드
     *
     * @param commAdministStdWordVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectAdministStdWordListExcelDown.do")
    public NexacroResult selectAdministStdWordListExcelDown(
            @ParamDataSet(name="dsPgInput") MapsCommAdministStdWordVO commAdministStdWordVO
            , NexacroResult result) throws Exception {
        
        List<MapsCommAdministStdWordVO> administStdWords = mapsCommAdministStdWordService.selectAdministStdWordPgList(commAdministStdWordVO);
        
        result.addDataSet("dsPgOutput", administStdWords);

        return result;
    }
    
    /**
     * 행정표준용어 업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectAdministStdWordListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectMsgListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<MapsCommAdministStdWordVO> administStdWords = new ArrayList<MapsCommAdministStdWordVO>();

        List<String[]> rowList = ExcelUtil.importExcelToList(request, 1, 9, 0, "N");
        
        if (rowList != null && !rowList.isEmpty()) {

            for (String[] arrCol : rowList) {

                MapsCommAdministStdWordVO administStdWordVO = new MapsCommAdministStdWordVO();
                
                administStdWordVO.setWordSe(arrCol[2]);
                administStdWordVO.setWordNm(arrCol[3]);
                administStdWordVO.setWordEngNm(arrCol[4]);
                administStdWordVO.setEngAbrvNm(arrCol[5]);
                administStdWordVO.setWordDfn(arrCol[6]);
                administStdWordVO.setThemaRelm(arrCol[7]);
                //administStdWordVO.setRgsde(DateUtil.arrCol[7]);

                administStdWords.add(administStdWordVO);
            }
        }

        result.addDataSet("dsOutput", administStdWords);

        return result;
    }

    /**
     * 행정표준용어 저장
     *
     * @param administStdWords
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/multiAdministStdWord.do")
    public NexacroResult multiAdministStdWord(
            @ParamDataSet(name="dsInput") List<MapsCommAdministStdWordVO> administStdWords
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsCommAdministStdWordService.multiAdministStdWord(loginInfo, administStdWords);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 행정표준영문약어 조회
     *
     * @param administStdWords
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectAdministStdEngAbrv.do")
    public NexacroResult selectAdministStdEngAbrv(
            @ParamDataSet(name="dsInput") List<MapsCommAdministStdWordVO> administStdWords
            , NexacroResult result) throws Exception {

        List<MapsCommAdministStdWordVO> administStdEngAbrvs = mapsCommAdministStdWordService.selectAdministStdEngAbrv(administStdWords);
        
        result.addDataSet("dsOutput", administStdEngAbrvs);
        
        return result;
    }
}
