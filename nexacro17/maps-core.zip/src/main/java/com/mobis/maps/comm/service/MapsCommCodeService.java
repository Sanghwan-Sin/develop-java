package com.mobis.maps.comm.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.SapCodeVO;
import com.mobis.maps.comm.vo.MapsCommCodeGroupVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;

/**
 * <pre>
 * 공통코드 서비스
 * </pre>
 *
 * @ClassName   : MapsCommCodeService.java
 * @Description : 공통코드 서비스를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 29.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsCommCodeService {
    
    public static final String CODE_SYS_SAP = "S";
    
    public static final String SYS_ENVRN_CHANNEL = "CHN";
    public static final String SYS_ENVRN_SAP = "SAP";
    public static final String SYS_ENVRN_DOMAIN = "DOMN";
    
    public static final String CBO_SJ_TY_ALL = "A";
    public static final String CBO_SJ_TY_SELECT = "S";
    public static final String CBO_SJ_TY_KEYWORD = "K";

    public static final String CODE_DISP_TY_KEY = "K";
    public static final String CODE_DISP_TY_VALUE = "V";
    public static final String CODE_DISP_TY_KEY_VALUE = "KV";
    public static final String CODE_DISP_TY_VALUE_KEY = "VK";

    /**
     * 공통코드 전체리스트 조회
     *
     * @param commCodeVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommCodeVO> selectCommCodeAllPgList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo)
            throws Exception;

    /**
     * 공통코드그룹 리스트 조회
     *
     * @param commCodeGroupVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommCodeGroupVO> selectCommCodeGroupPgList(MapsCommCodeGroupVO commCodeGroupVO,
            LoginInfoVO loginInfo) throws Exception;

    /**
     * 공통코드그룹 조회
     *
     * @param commCodeGroupVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommCodeGroupVO selectCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO, LoginInfoVO loginInfo)
            throws Exception;

    /**
     * 공통코드그룹 등록
     *
     * @param commCodeGroupVO
     * @param loginInfo
     * @throws Exception
     */
    public int insertCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 공통코드그룹 수정
     *
     * @param commCodeGroupVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 공통코드그룹 삭제
     *
     * @param commCodeGroupVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int deleteCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 공통코드 리스트 조회
     *
     * @param commCodeVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommCodeVO> selectCommCodePgList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 공통코드 저장
     *
     * @param commCodes
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiCommCode(List<MapsCommCodeVO> commCodes, LoginInfoVO loginInfo) throws Exception;

    /**
     * 코드 리스트 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public List<CodeVO> selectCodeList(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * 코드 리스트 조회
     *
     * @param commCodeVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<CodeVO> selectCodeList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 하위코드 리스트 조회
     *
     * @param commCodeVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<CodeVO> selectLwprtCodeList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 코드명 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public CodeVO selectCodeNm(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * 코드명 조회
     *
     * @param commCodeVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public CodeVO selectCodeNm(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * SAP코드 리스트 조회
     *
     * @param commCodeVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<SapCodeVO> selectSapCodeList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * SAP코드명 조회
     *
     * @param commCodeVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public SapCodeVO selectSapCodeNm(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * Domain코드 리스트 조회
     *
     * @param commCodeVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<CodeVO> selectDomnCodeList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * Domain코드명 조회
     *
     * @param commCodeVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public CodeVO selectDomnCodeNm(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception;
}
