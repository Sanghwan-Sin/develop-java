package com.mobis.maps.comm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.exception.BizException;
import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommAdministStdWordService;
import com.mobis.maps.comm.service.dao.MapsCommAdministStdWordMDAO;
import com.mobis.maps.comm.vo.MapsCommAdministStdWordVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 행정표준용어 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommAdministStdWordServiceImpl.java
 * @Description : 행정표준용어에 대한 서비스를 구현.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Service("mapsCommAdministStdWordService")
public class MapsCommAdministStdWordServiceImpl extends HService implements MapsCommAdministStdWordService {

    @Resource(name="mapsCommAdministStdWordMDAO")
    private MapsCommAdministStdWordMDAO mapsCommAdministStdWordMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommAdministStdWordService#selectAdministStdWordPgList(com.mobis.maps.comm.vo.MapsCommAdministStdWordVO)
     */
    @Override
    public List<MapsCommAdministStdWordVO> selectAdministStdWordPgList(MapsCommAdministStdWordVO commAdministStdWordVO) throws Exception {
        
        List<MapsCommAdministStdWordVO> lstAdministStdWord = mapsCommAdministStdWordMDAO.selectAdministStdWordPgList(commAdministStdWordVO);
        
        return lstAdministStdWord;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommAdministStdWordService#multiAdministStdWord(com.mobis.maps.cmmn.vo.LoginInfoVO, java.util.List)
     */
    @Override
    public int multiAdministStdWord(LoginInfoVO loginInfo
            , List<MapsCommAdministStdWordVO> administStdWords) throws Exception {

        int procCnt = 0;
        
        MapsCommAdministStdWordVO resultAdministStdWordVO = null;
        
        for (MapsCommAdministStdWordVO administStdWord: administStdWords) {
            
            int rowType = administStdWord.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            administStdWord.setRegistId(loginInfo.getUserId());
            administStdWord.setUpdtId(loginInfo.getUserId());

            resultAdministStdWordVO = mapsCommAdministStdWordMDAO.selectAdministStdWord(administStdWord);
            
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    if (resultAdministStdWordVO != null) {
                        throw new BizException(messageSource, "EC00000011", new String[]{"Common Code Info"}, null);
                    }
                    mapsCommAdministStdWordMDAO.insertAdministStdWord(administStdWord);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    if (resultAdministStdWordVO == null) {
                        throw new BizException(messageSource, "EC00000011", new String[]{"Common Code Info"}, null);
                    }
                    mapsCommAdministStdWordMDAO.updateAdministStdWord(administStdWord);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    if (resultAdministStdWordVO == null) {
                        throw new BizException(messageSource, "EC00000011", new String[]{"Common Code Info"}, null);
                    }
                    mapsCommAdministStdWordMDAO.deleteAdministStdWord(administStdWord);
                    break;
                default :
                    continue;
            }
            procCnt++;
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommAdministStdWordService#selectAdministStdEngAbrv(java.util.List)
     */
    @Override
    public List<MapsCommAdministStdWordVO> selectAdministStdEngAbrv(List<MapsCommAdministStdWordVO> administStdWords) throws Exception {

        List<MapsCommAdministStdWordVO> resultAdministStdWords = new ArrayList<MapsCommAdministStdWordVO>();
        
        Map<String, Integer> hmWordNm = new HashMap<String, Integer>();
        
        int row = 0;
        for (MapsCommAdministStdWordVO administStdWord: administStdWords) {
            
            if (hmWordNm.get(administStdWord.getWordNm()) == null) {
                
                List<MapsCommAdministStdWordVO> lstAdministStdWord = mapsCommAdministStdWordMDAO.selectAdministStdEngAbrvList(administStdWord);
                
                if (lstAdministStdWord.isEmpty()) {
                    resultAdministStdWords.add(administStdWord);
                } else {
                    resultAdministStdWords.addAll(lstAdministStdWord);
                }
                
                hmWordNm.put(administStdWord.getWordNm(), row);
            }
            row++;
        }
        
        return resultAdministStdWords;
    }

}
