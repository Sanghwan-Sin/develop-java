package com.mobis.maps.cmmn.msg;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.sql.DataSource;

import able.com.service.msg.MessageDBResourceDAO;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.mobis.maps.cmmn.constants.MapsConstants;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsMessageDBResourceDAO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsMessageDBResourceDAO extends MessageDBResourceDAO {
    
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    
    private String system;

    /*
     * @see able.com.service.msg.MessageDBResourceDAO#setDataSource(javax.sql.DataSource)
     */
    @Override
    public void setDataSource(DataSource dataSource) {
        super.setDataSource(dataSource);
        this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    /*
     * @see able.com.service.msg.MessageDBResourceDAO#getMessageTimestamp(java.lang.String)
     */
    @Override
    public long getMessageTimestamp(String lang) throws Exception {
        
        Map<String, String> param = new HashMap<>();
        param.put("system", system);
        param.put("lang", lang);
        
        Map<String, Object> result = this.namedParameterJdbcTemplate.queryForMap(getSqlMsgTimestamp(), param);
        long time = -1L;
        if (null == result || (null != result && null == result.get(getColumnTimestamp()))) {
            time = -1L;
        } else {
            String lastModify = (String) result.get(getColumnTimestamp());
            String format = "YYYY/MM/DD HH:mm:ss";
            SimpleDateFormat sdf = new SimpleDateFormat(format , Locale.KOREA);
            time = sdf.parse(lastModify).getTime() / 1000L;
        }
        return time;
    }
    
    /*
     * @see able.com.service.msg.MessageDBResourceDAO#getMessageResource(java.lang.String)
     */
    @Override
    public List<Map<String, Object>> getMessageResource(String lang) throws Exception {

        Map<String, String> param = new HashMap<>();
        param.put("system", system);
        param.put("lang", lang);
        param.put("dfltLocale", MapsConstants.DFLT_LOCALE.toString());
        
        List<Map<String, Object>> resultList = this.namedParameterJdbcTemplate.queryForList(getSqlMsgProperty(), param);
        for (Map<String, Object> result : resultList) {
            Object sMKey = result.get("mkey");
            result.put("key", sMKey);
            result.remove("mkey");
        }
        return resultList;
    }
    
    /**
     * @return the system
     */
    public String getSystem() {
        return system;
    }
    /**
     * @param system the system to set
     */
    public void setSystem(String system) {
        this.system = system;
    }

}
