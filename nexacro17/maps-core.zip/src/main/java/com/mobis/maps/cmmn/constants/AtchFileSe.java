package com.mobis.maps.cmmn.constants;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.codec.binary.StringUtils;

/**
 * <pre>
 * 첨부파일구분정보
 * </pre>
 *
 * @ClassName   : AtchFileSe.java
 * @Description : 첨부파일구분정보를 정의한다.
 * @author Sin Sanghwan
 * @since 2019. 8. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 8.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public enum AtchFileSe {
    
      SAPATCH("Sap첨부파일", new String[]{"refNo"}, "sapAtch")
    , NMGNSMP("Sample", new String[]{"seq"}, "upload")
    , NMGN002("공지사항", new String[]{"seq"}, "notice")
    , NMGN003("게시판", new String[]{"bbscttId", "bbscttSeq"}, "borad")
    , NMGN004("DistInfo", new String[]{"vkorg","vtweg","kunnr"}, "dist")
    , NMGN005("DistStaffInfo", new String[]{"distCode","seqNum"}, "dist")
    , NMGN006("Dpom", new String[]{"docNo"}, "dpom")
    , NMGN007("NewsLetter", new String[]{"refNo"}, "newsLetter")
    , DEMO001("DemoReviewBBS", new String[]{"bbscttId", "bbscttSeq"}, "demo")
    , NMGN008("DistInfo", new String[]{"vkorg","vtweg","kunnr"}, "dist")
    , IDBNK01("IdeaBank", new String[]{"regNo"},"upload")
    ;
    
    /** 첨부파일구분명 */
    private String atchFileSeNm;
    /** 첨부파일ID 생성항목 */
    private String[] fields;
    /** 첨부파일 저장 SUB폴더 키 */
    private String subFolder;
    
    private AtchFileSe(String atchFileSeNm, String[] fields, String subFolder) {
        this.atchFileSeNm = atchFileSeNm;
        this.fields = fields;
        this.subFolder = subFolder;
    }
    
    /**
     * Statements
     *
     * @param name
     * @return
     */
    public static AtchFileSe get(String name) {
        for (AtchFileSe e: AtchFileSe.values()) {
            if (StringUtils.equals(e.name(), name)) {
                return e;
            }
        }
        return null;
    }
    
    /**
     * 첨부파일ID 생성
     *
     * @param bean
     * @return
     * @throws Exception
     */
    public String getAtchId(Object bean) throws Exception {
        
        StringBuilder sb = new StringBuilder();
        
        for (String field: fields) {
            Object oId = BeanUtils.getProperty(bean, field);
            if (oId != null) {
                if (sb.length() > 0) {
                    sb.append("|");
                }
                sb.append(oId);
            }
        }
        return sb.toString();
    }

    /**
     * @return the subFolder
     */
    public String getSubFolder() {
        return subFolder;
    }

    /**
     * @return the atchFileSeNm
     */
    public String getAtchFileSeNm() {
        return atchFileSeNm;
    }
}
