package com.mobis.maps.comm.constants;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.commons.codec.binary.StringUtils;

import com.mobis.maps.cmmn.vo.CodeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : RfcLangCd.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 23.     DT048058     	최초 생성
 * </pre>
 */

public enum RfcLangCd {
    
      KO("3", Locale.KOREA)
    , ZH("1", Locale.CHINA)
    , EN("E", Locale.US)
    ;
    
    private String langKey;
    private Locale locale;
    
    private RfcLangCd(String langKey, Locale locale) {
        this.langKey = langKey;
        this.locale = locale;
    }
    
    public static RfcLangCd get(String name) {

        for (RfcLangCd rfcLangCd: values()) {
            if (StringUtils.equals(name, rfcLangCd.name())) {
                return rfcLangCd;
            }
        }
        return null;
    }
    
    public static List<CodeVO> getCodeList() {
        
        List<CodeVO> codes = new ArrayList<CodeVO>();
        for (RfcLangCd rfcLangCd: values()) {
            CodeVO code = new CodeVO();
            code.setCode(rfcLangCd.name());
            code.setCodeNm(rfcLangCd.name());
            
            codes.add(code);
        }
        
        return codes;
    }

    /**
     * @return the langKey
     */
    public String getLangKey() {
        return langKey;
    }

    /**
     * @return the locale
     */
    public Locale getLocale() {
        return locale;
    }
    
}
