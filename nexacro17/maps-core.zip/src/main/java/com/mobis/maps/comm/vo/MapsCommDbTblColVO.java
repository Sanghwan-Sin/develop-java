package com.mobis.maps.comm.vo;

import org.hibernate.validator.constraints.NotBlank;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommDbTblColVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsCommDbTblColVO extends PgBascVO {
    /** 스키마명 */
    @NotBlank(message="EC00000001|SCHEMA_NAME")
    private String schemaNm;
    /** 테이블명 */
    @NotBlank(message="EC00000001|TABLE_NAME")
    private String tableNm;
    /** 테이블주석 */
    private String tableCm;
    /** 테이블별칭 */
    private String tableNcm;
    /** 컬럼명 */
    private String columnNm;
    /** 컬럼주석 */
    private String columnCm;
    /** 컬럼위치 */
    private int columnPosit;
    /** 컬럼데이터타입 */
    private String columnDataTy;
    /**
     * @return the schemaNm
     */
    public String getSchemaNm() {
        return schemaNm;
    }
    /**
     * @param schemaNm the schemaNm to set
     */
    public void setSchemaNm(String schemaNm) {
        this.schemaNm = schemaNm;
    }
    /**
     * @return the tableNm
     */
    public String getTableNm() {
        return tableNm;
    }
    /**
     * @param tableNm the tableNm to set
     */
    public void setTableNm(String tableNm) {
        this.tableNm = tableNm;
    }
    /**
     * @return the tableCm
     */
    public String getTableCm() {
        return tableCm;
    }
    /**
     * @param tableCm the tableCm to set
     */
    public void setTableCm(String tableCm) {
        this.tableCm = tableCm;
    }
    /**
     * @return the tableNcm
     */
    public String getTableNcm() {
        return tableNcm;
    }
    /**
     * @param tableNcm the tableNcm to set
     */
    public void setTableNcm(String tableNcm) {
        this.tableNcm = tableNcm;
    }
    /**
     * @return the columnNm
     */
    public String getColumnNm() {
        return columnNm;
    }
    /**
     * @param columnNm the columnNm to set
     */
    public void setColumnNm(String columnNm) {
        this.columnNm = columnNm;
    }
    /**
     * @return the columnCm
     */
    public String getColumnCm() {
        return columnCm;
    }
    /**
     * @param columnCm the columnCm to set
     */
    public void setColumnCm(String columnCm) {
        this.columnCm = columnCm;
    }
    /**
     * @return the columnPosit
     */
    public int getColumnPosit() {
        return columnPosit;
    }
    /**
     * @param columnPosit the columnPosit to set
     */
    public void setColumnPosit(int columnPosit) {
        this.columnPosit = columnPosit;
    }
    /**
     * @return the columnDataTy
     */
    public String getColumnDataTy() {
        return columnDataTy;
    }
    /**
     * @param columnDataTy the columnDataTy to set
     */
    public void setColumnDataTy(String columnDataTy) {
        this.columnDataTy = columnDataTy;
    }

}
