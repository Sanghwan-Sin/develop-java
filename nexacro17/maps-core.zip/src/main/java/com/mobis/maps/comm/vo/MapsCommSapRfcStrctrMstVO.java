package com.mobis.maps.comm.vo;

import org.hibernate.validator.constraints.NotBlank;

/**
 * <pre>
 * RFC구조체기본정보 항목
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcStrctrMstVO.java
 * @Description : RFC구조체기본정보 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 23.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsCommSapRfcStrctrMstVO extends PgBascVO {
    /** 구조체아이디 */
    @NotBlank(message="EC00000001|STRCTR_ID")
    private String strctrId;
    /** 구조체명 */
    @NotBlank(message="EC00000001|STRCTR_NM")
    private String strctrNm;
    /**
     * @return the strctrId
     */
    public String getStrctrId() {
        return strctrId;
    }
    /**
     * @param strctrId the strctrId to set
     */
    public void setStrctrId(String strctrId) {
        this.strctrId = strctrId;
    }
    /**
     * @return the strctrNm
     */
    public String getStrctrNm() {
        return strctrNm;
    }
    /**
     * @param strctrNm the strctrNm to set
     */
    public void setStrctrNm(String strctrNm) {
        this.strctrNm = strctrNm;
    }

}
