package com.mobis.maps.comm.vo;

/**
 * <pre>
 * 호면캡쳐방지용 화면정보 항목
 * </pre>
 *
 * @ClassName   : MapsOpenSdiScrinInfoVO.java
 * @Description : 호면캡쳐방지용 화면정보 항목을 정의.
 * @author DT048058
 * @since 2019. 12. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 6.     DT048058     	최초 생성
 * </pre>
 */

public class MapsOpenSdiScrinInfoVO {

    /** 메뉴ID */
    private String menuId;
    /** 화면코드 */
    private String scrinCd;
    /** 타이틀 */
    private String title;
    /** 설명URL */
    private String descUrl;
    
    /** 품의내부번호 */
    private String cnSulInnerNo;
    /** 결재항목코드 */
    private String sancItemCd;
    
    
    
    
    /**
     * @return the cnSulInnerNo
     */
    public String getCnSulInnerNo() {
        return cnSulInnerNo;
    }
    /**
     * @param cnSulInnerNo the cnSulInnerNo to set
     */
    public void setCnSulInnerNo(String cnSulInnerNo) {
        this.cnSulInnerNo = cnSulInnerNo;
    }
    /**
     * @return the sancItemCd
     */
    public String getSancItemCd() {
        return sancItemCd;
    }
    /**
     * @param sancItemCd the sancItemCd to set
     */
    public void setSancItemCd(String sancItemCd) {
        this.sancItemCd = sancItemCd;
    }
    
    
    /**
     * @return the menuId
     */
    public String getMenuId() {
        return menuId;
    }
    /**
     * @param menuId the menuId to set
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
    /**
     * @return the scrinCd
     */
    public String getScrinCd() {
        return scrinCd;
    }
    /**
     * @param scrinCd the scrinCd to set
     */
    public void setScrinCd(String scrinCd) {
        this.scrinCd = scrinCd;
    }
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * @return the descUrl
     */
    public String getDescUrl() {
        return descUrl;
    }
    /**
     * @param descUrl the descUrl to set
     */
    public void setDescUrl(String descUrl) {
        this.descUrl = descUrl;
    }
}
