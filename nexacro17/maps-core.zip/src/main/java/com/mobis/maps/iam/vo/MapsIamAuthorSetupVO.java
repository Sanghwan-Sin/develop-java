package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * 권한설정변경이력 항목
 * </pre>
 *
 * @ClassName   : MapsIamAuthorSetupVO.java
 * @Description : 권한설정변경이력에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 13.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamAuthorSetupVO extends MapsIamCommVO {
    /* 조회조건 */
    /** 시작일자 */
    private Date strtDt;
    /** 종료일자 */
    private Date endDt;
    /** 화면ID */
    private String scrinId;
    /* 권한설정변경이력 */
    /** 변경일시 */
    private Date changeDt;
    /** 권한설정구분코드 */
    private String authorSetupSeCd;
    /** 권한ID */
    private String authorId;
    /** 권한설정대상ID */
    private String authorSetupTrgetId;
    /** 변경구분코드 */
    private String changeSeCd;
    /** 변경자ID */
    private String changeId;
    /**
     * @return the strtDt
     */
    public Date getStrtDt() {
        return strtDt;
    }
    /**
     * @param strtDt the strtDt to set
     */
    public void setStrtDt(Date strtDt) {
        this.strtDt = strtDt;
    }
    /**
     * @return the endDt
     */
    public Date getEndDt() {
        return endDt;
    }
    /**
     * @param endDt the endDt to set
     */
    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the changeDt
     */
    public Date getChangeDt() {
        return changeDt;
    }
    /**
     * @param changeDt the changeDt to set
     */
    public void setChangeDt(Date changeDt) {
        this.changeDt = changeDt;
    }
    /**
     * @return the authorSetupSeCd
     */
    public String getAuthorSetupSeCd() {
        return authorSetupSeCd;
    }
    /**
     * @param authorSetupSeCd the authorSetupSeCd to set
     */
    public void setAuthorSetupSeCd(String authorSetupSeCd) {
        this.authorSetupSeCd = authorSetupSeCd;
    }
    /**
     * @return the authorId
     */
    public String getAuthorId() {
        return authorId;
    }
    /**
     * @param authorId the authorId to set
     */
    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }
    /**
     * @return the authorSetupTrgetId
     */
    public String getAuthorSetupTrgetId() {
        return authorSetupTrgetId;
    }
    /**
     * @param authorSetupTrgetId the authorSetupTrgetId to set
     */
    public void setAuthorSetupTrgetId(String authorSetupTrgetId) {
        this.authorSetupTrgetId = authorSetupTrgetId;
    }
    /**
     * @return the changeSeCd
     */
    public String getChangeSeCd() {
        return changeSeCd;
    }
    /**
     * @param changeSeCd the changeSeCd to set
     */
    public void setChangeSeCd(String changeSeCd) {
        this.changeSeCd = changeSeCd;
    }
    /**
     * @return the changeId
     */
    public String getChangeId() {
        return changeId;
    }
    /**
     * @param changeId the changeId to set
     */
    public void setChangeId(String changeId) {
        this.changeId = changeId;
    }
}
