package com.mobis.maps.comm.constants;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.commons.codec.binary.StringUtils;

import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.sapjco.manager.Destination;
import com.sap.conn.jco.JCoException;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : RfcJCoDest.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 23.     DT048058     	최초 생성
 * </pre>
 */

public enum RfcJCoDest {
    
      PC_KO(RfcSapSys.PC, RfcLangCd.KO, "pcko")
    , PC_ZH(RfcSapSys.PC, RfcLangCd.ZH, "pczh")
    , PC_EN(RfcSapSys.PC, RfcLangCd.EN, "pcen")
    , PW_KO(RfcSapSys.PW, RfcLangCd.KO, "pwko")
    , PW_ZH(RfcSapSys.PW, RfcLangCd.ZH, "pwzh")
    , PW_EN(RfcSapSys.PW, RfcLangCd.EN, "pwen")
    ;

    private RfcSapSys rfcSapSys;
    private RfcLangCd rfcLangCd;
    private String destId;
    
    private RfcJCoDest(RfcSapSys rfcSapSys,  RfcLangCd rfcLangCd, String destId) {
        this.rfcSapSys = rfcSapSys;
        this.rfcLangCd = rfcLangCd;
        this.destId = destId;
    }
    
    public static RfcJCoDest get(String name) {
        for (RfcJCoDest destination: values()) {
            if (StringUtils.equals(name, destination.name())) {
                return destination;
            }
        }
        return null;
    }
    
    public static RfcJCoDest get(RfcSapSys rfcSapSys, String sapLangCd) {
        for (RfcJCoDest destination: values()) {
            if (rfcSapSys != destination.getRfcSapSys()) {
                continue;
            }
            if (!StringUtils.equals(sapLangCd, destination.getSapLangCd())) {
                continue;
            }
            return destination;
        }
        return null;
    }
    
    public static RfcJCoDest getByLangKey(RfcSapSys rfcSapSys, String langKey) {
        for (RfcJCoDest destination: values()) {
            if (rfcSapSys != destination.getRfcSapSys()) {
                continue;
            }
            if (!StringUtils.equals(langKey, destination.getLangKey())) {
                continue;
            }
            return destination;
        }
        return null;
    }
    
    public static RfcJCoDest getByLocale(RfcSapSys rfcSapSys, Locale locale) {
        for (RfcJCoDest destination: values()) {
            if (rfcSapSys != destination.getRfcSapSys()) {
                continue;
            }
            if (!destination.getLocale().equals(locale)) {
                continue;
            }
            return destination;
        }
        return null;
    }
    
    public static List<CodeVO> getCodeList() {
        
        List<CodeVO> codes = new ArrayList<CodeVO>();
        for (RfcJCoDest destination: values()) {
            CodeVO code = new CodeVO();
            code.setCode(destination.name());
            code.setCodeNm(destination.name());
            
            codes.add(code);
        }
        
        return codes;
    }
    
    public Destination getDestination() throws JCoException {
        return new Destination(destId);
    }

    public String getSapSys() {
        return getRfcSapSys().name();
    }

    public String getSapLangCd() {
        return getRfcLangCd().name();
    }

    public String getLangKey() {
        return getRfcLangCd().getLangKey();
    }

    public Locale getLocale() {
        return getRfcLangCd().getLocale();
    }


    /**
     * @return the rfcSapSys
     */
    public RfcSapSys getRfcSapSys() {
        return rfcSapSys;
    }

    /**
     * @return the rfcLangCd
     */
    public RfcLangCd getRfcLangCd() {
        return rfcLangCd;
    }

    /**
     * @return the destId
     */
    public String getDestId() {
        return destId;
    }


}
