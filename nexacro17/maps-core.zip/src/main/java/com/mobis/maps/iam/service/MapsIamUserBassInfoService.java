package com.mobis.maps.iam.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserOrgnztVO;

/**
 * <pre>
 * 사용자기본정보 서비스
 * </pre>
 *
 * @ClassName   : MapsIamUserBassInfoService.java
 * @Description : 사용자기본정보에 대한 서비스를 정의.
 * @author DT048058
 * @since 2020. 3. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 17.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsIamUserBassInfoService {

    /**
     * 사용자기본정보 페이징리스트 조회
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserBassInfoVO> selectUserBassInfoPgList(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본정보 페이징리스트 팝업조회
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserBassInfoVO> selectPopupUserBassInfoPgList(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자기본정보 조회
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsIamUserBassInfoVO selectUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본정보 저장
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiUserBassInfo(List<MapsIamUserBassInfoVO> userBassInfos, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본정보 등록 정합성체크
     *
     * @param iamUserBassInfoVO
     * @param isAutoUserId
     * @param loginInfo
     * @throws Exception
     */
    public void insertValidateUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, boolean isAutoUserId, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본정보 수정 정합성체크
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @throws Exception
     */
    public void updateValidateUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본정보 삭제 정합성체크
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsIamUserBassInfoVO deleteValidateUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본정보 존재 조회
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamUserBassInfoVO selectHasUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자기본순번ID 채번 등록
     *
     * @param iamUserOrgnztVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public String insertUserIdSeq(MapsIamUserOrgnztVO iamUserOrgnztVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본정보 등록
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int insertUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본정보 수정
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 로그인 사용자기본정보 수정
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateLoginUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본정보 삭제
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int deleteUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자기본변경이력 페이징조회
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserBassInfoVO> selectUserBassChghstPgList(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 사용자기본변경이력 등록
     *
     * @param changeSeCd
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @throws Exception
     */
    public void insertUserBassChghst(String changeSeCd, MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception;
}
