package com.mobis.maps.logback.db.names;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSapRfcColumnName.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 7.     DT048058     	최초 생성
 * </pre>
 */

public enum MapsColumnName {
    
    EVENT_ID, 

    TIMESTMP, FORMATTED_MESSAGE, LOGGER_NAME, LEVEL_STRING, THREAD_NAME, REFERENCE_FLAG, ARG0, ARG1, ARG2, ARG3, CALLER_FILENAME, CALLER_CLASS, CALLER_METHOD, CALLER_LINE, 
    
    /* MDC */ 
    MAPPED_KEY, MAPPED_VALUE, 

    I, TRACE_LINE
    ;
}
