package com.mobis.maps.cmmn.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

/**
 * <pre>
 * MAPS 대리점 조직정보 항목
 * </pre>
 *
 * @ClassName   : MapsOrgnztDistVO.java
 * @Description : MAPS 대리점 조직정보에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 4.     DT048058     	최초 생성
 * </pre>
 */

public class MapsOrgnztDistVO implements Serializable {
    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = -132495282291639316L;
    /** 영업조직(법인코드) */
    private String vkorg;
    /** 영업조직명(법인코드명) */
    private String vkorgNm;
    /** 유통경로 */
    private String vtweg;
    /** 고객번호(대리점코드) */
    private String kunnr;
    /** 조직 구분자 */
    private String zorgType;
    /** Service Type(DDS : 직배, DTS : 일반) */
    private String zservty;
    /** 영업소 */
    private String vkbur;
    /** L-REGION */
    private String zlregio;
    /** M-REGION */
    private String zmregio;
    /** S-REGION */
    private String zsregio;
    /** ACCOUNT (ZPSDT1000) */
    private String zactno;
    /** 고객상태 */
    private String zcustat;
    /** AS-IS 고객코드 */
    private String zsacutm;
    /** 고객번호(대리점코드) */
    private String zkunnr;
    /** 딜러코드 */
    private String zdealer;
    /** 대표대리점코드 */
    private String zkunn2;
    /** 대표딜러코드  */
    private String zdeale2;
    /** 영업조직명 */
    private String zvknam;
    /** 대리점상호 */
    private String zkunam;
    /** 딜러상호 */
    private String zdlrnam;
    /** 대표대리점상호 */
    private String zku2nam;
    /** 대표딜러상호 */
    private String zdlr2nam;
    /** 사업자등록번호 */
    private String stcd2;
    /** 국가코드 */
    private String land1;
    /** 도시 */
    private String ort01;
    /** 상세주소 */
    private String stras;
    /** 우편번호 */
    private String pstlz;
    /** 이메일 */
    private String zemail;
    /** 전화번호 */
    private String ztelno1;
    /** H/K 구분자 */
    private String kvgr1;
    /** 고객유형 */
    private String kvgr2;
    /** 고객세부유형 */
    private String kvgr3;
    /** Customer Type */
    private String kvgr4;
    /** 고객추가 구분자 (1004추가) */
    private String zcumgy;
    /** Old/New구분 (확실) */
    private String zedity;
    /** Auto Receiving (확실) */
    private String zautoRev;
    /** 보상처리율 */
    private BigDecimal zmarkup;
    /** 거래개시일 */
    private Date zbubign;
    /** 거래마감일 */
    private Date zterdat;
    /** 화폐코드 */
    private String waers;
    /** 신용구분 */
    private String riskClass;
    /** 동곤여부 (CO-PACK) */
    private String zcopak;
    /** 포장유형_Air */
    private String zpacktyAir;
    /** 포장유형_Sea */
    private String zpacktySea;
    /** 지불유형_Air */
    private String zwels1;
    /** 지불유형_Sea */
    private String zwels2;
    /** 거래조건_Air */
    private String zinco1;
    /** 거래조건_Sea */
    private String zinco2;
    /** 적용가격코드 (가격리스트) */
    private String pltyp;
    /** 기술사양지역 (PAM REGION) */
    private String zpamre;
    /** 도착항구_Air */
    private String zarport1;
    /** 도착항구_Sea */
    private String zarport2;
    /** 최종도착지_Air */
    private String zfindes1;
    /** 최종도착지_Sea */
    private String zfindes2;
    /** 승용할인율_Air */
    private BigDecimal zdisRate01;
    /** 승용할인율_Sea */
    private BigDecimal zdisRate02;
    /** 승용할인율_Vor */
    private BigDecimal zdisRate03;
    /** 중계무역선적지 */
    private String zintmd;
    /** CENTER_CODE */
    private String zcentcd;
    /** MAPS고객번호(10자리) */
    private String zkunnr2;
    /** 영업사원코드 */
    private String zsalesPer;
    /** 고객그룹 [10:[HQ]내수_도매, 11:[HQ]내수_소매, 12:[HQ]내수_정비, 13:[HQ]수출_모비스, 14:[HQ]수출_대리점, 15:[HQ]수출_로컬수출] */
    private String kdgrp;
    /** 대표대리점여부[0:대표대리점,1:비대표대리점] */
    private String repKunnrFlag;
    
    public boolean isReqDist() {
        return StringUtils.equals(repKunnrFlag, "0") || StringUtils.equals(repKunnrFlag, "1");
    }
    
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vkorgNm
     */
    public String getVkorgNm() {
        return vkorgNm;
    }
    /**
     * @param vkorgNm the vkorgNm to set
     */
    public void setVkorgNm(String vkorgNm) {
        this.vkorgNm = vkorgNm;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the zorgType
     */
    public String getZorgType() {
        return zorgType;
    }
    /**
     * @param zorgType the zorgType to set
     */
    public void setZorgType(String zorgType) {
        this.zorgType = zorgType;
    }
    /**
     * @return the zservty
     */
    public String getZservty() {
        return zservty;
    }
    /**
     * @param zservty the zservty to set
     */
    public void setZservty(String zservty) {
        this.zservty = zservty;
    }
    /**
     * @return the vkbur
     */
    public String getVkbur() {
        return vkbur;
    }
    /**
     * @param vkbur the vkbur to set
     */
    public void setVkbur(String vkbur) {
        this.vkbur = vkbur;
    }
    /**
     * @return the zlregio
     */
    public String getZlregio() {
        return zlregio;
    }
    /**
     * @param zlregio the zlregio to set
     */
    public void setZlregio(String zlregio) {
        this.zlregio = zlregio;
    }
    /**
     * @return the zmregio
     */
    public String getZmregio() {
        return zmregio;
    }
    /**
     * @param zmregio the zmregio to set
     */
    public void setZmregio(String zmregio) {
        this.zmregio = zmregio;
    }
    /**
     * @return the zsregio
     */
    public String getZsregio() {
        return zsregio;
    }
    /**
     * @param zsregio the zsregio to set
     */
    public void setZsregio(String zsregio) {
        this.zsregio = zsregio;
    }
    /**
     * @return the zactno
     */
    public String getZactno() {
        return zactno;
    }
    /**
     * @param zactno the zactno to set
     */
    public void setZactno(String zactno) {
        this.zactno = zactno;
    }
    /**
     * @return the zcustat
     */
    public String getZcustat() {
        return zcustat;
    }
    /**
     * @param zcustat the zcustat to set
     */
    public void setZcustat(String zcustat) {
        this.zcustat = zcustat;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the zkunnr
     */
    public String getZkunnr() {
        return zkunnr;
    }
    /**
     * @param zkunnr the zkunnr to set
     */
    public void setZkunnr(String zkunnr) {
        this.zkunnr = zkunnr;
    }
    /**
     * @return the zdealer
     */
    public String getZdealer() {
        return zdealer;
    }
    /**
     * @param zdealer the zdealer to set
     */
    public void setZdealer(String zdealer) {
        this.zdealer = zdealer;
    }
    /**
     * @return the zkunn2
     */
    public String getZkunn2() {
        return zkunn2;
    }
    /**
     * @param zkunn2 the zkunn2 to set
     */
    public void setZkunn2(String zkunn2) {
        this.zkunn2 = zkunn2;
    }
    /**
     * @return the zdeale2
     */
    public String getZdeale2() {
        return zdeale2;
    }
    /**
     * @param zdeale2 the zdeale2 to set
     */
    public void setZdeale2(String zdeale2) {
        this.zdeale2 = zdeale2;
    }
    /**
     * @return the zvknam
     */
    public String getZvknam() {
        return zvknam;
    }
    /**
     * @param zvknam the zvknam to set
     */
    public void setZvknam(String zvknam) {
        this.zvknam = zvknam;
    }
    /**
     * @return the zkunam
     */
    public String getZkunam() {
        return zkunam;
    }
    /**
     * @param zkunam the zkunam to set
     */
    public void setZkunam(String zkunam) {
        this.zkunam = zkunam;
    }
    /**
     * @return the zdlrnam
     */
    public String getZdlrnam() {
        return zdlrnam;
    }
    /**
     * @param zdlrnam the zdlrnam to set
     */
    public void setZdlrnam(String zdlrnam) {
        this.zdlrnam = zdlrnam;
    }
    /**
     * @return the zku2nam
     */
    public String getZku2nam() {
        return zku2nam;
    }
    /**
     * @param zku2nam the zku2nam to set
     */
    public void setZku2nam(String zku2nam) {
        this.zku2nam = zku2nam;
    }
    /**
     * @return the zdlr2nam
     */
    public String getZdlr2nam() {
        return zdlr2nam;
    }
    /**
     * @param zdlr2nam the zdlr2nam to set
     */
    public void setZdlr2nam(String zdlr2nam) {
        this.zdlr2nam = zdlr2nam;
    }
    /**
     * @return the stcd2
     */
    public String getStcd2() {
        return stcd2;
    }
    /**
     * @param stcd2 the stcd2 to set
     */
    public void setStcd2(String stcd2) {
        this.stcd2 = stcd2;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the ort01
     */
    public String getOrt01() {
        return ort01;
    }
    /**
     * @param ort01 the ort01 to set
     */
    public void setOrt01(String ort01) {
        this.ort01 = ort01;
    }
    /**
     * @return the stras
     */
    public String getStras() {
        return stras;
    }
    /**
     * @param stras the stras to set
     */
    public void setStras(String stras) {
        this.stras = stras;
    }
    /**
     * @return the pstlz
     */
    public String getPstlz() {
        return pstlz;
    }
    /**
     * @param pstlz the pstlz to set
     */
    public void setPstlz(String pstlz) {
        this.pstlz = pstlz;
    }
    /**
     * @return the zemail
     */
    public String getZemail() {
        return zemail;
    }
    /**
     * @param zemail the zemail to set
     */
    public void setZemail(String zemail) {
        this.zemail = zemail;
    }
    /**
     * @return the ztelno1
     */
    public String getZtelno1() {
        return ztelno1;
    }
    /**
     * @param ztelno1 the ztelno1 to set
     */
    public void setZtelno1(String ztelno1) {
        this.ztelno1 = ztelno1;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the kvgr2
     */
    public String getKvgr2() {
        return kvgr2;
    }
    /**
     * @param kvgr2 the kvgr2 to set
     */
    public void setKvgr2(String kvgr2) {
        this.kvgr2 = kvgr2;
    }
    /**
     * @return the kvgr3
     */
    public String getKvgr3() {
        return kvgr3;
    }
    /**
     * @param kvgr3 the kvgr3 to set
     */
    public void setKvgr3(String kvgr3) {
        this.kvgr3 = kvgr3;
    }
    /**
     * @return the kvgr4
     */
    public String getKvgr4() {
        return kvgr4;
    }
    /**
     * @param kvgr4 the kvgr4 to set
     */
    public void setKvgr4(String kvgr4) {
        this.kvgr4 = kvgr4;
    }
    /**
     * @return the zcumgy
     */
    public String getZcumgy() {
        return zcumgy;
    }
    /**
     * @param zcumgy the zcumgy to set
     */
    public void setZcumgy(String zcumgy) {
        this.zcumgy = zcumgy;
    }
    /**
     * @return the zedity
     */
    public String getZedity() {
        return zedity;
    }
    /**
     * @param zedity the zedity to set
     */
    public void setZedity(String zedity) {
        this.zedity = zedity;
    }
    /**
     * @return the zautoRev
     */
    public String getZautoRev() {
        return zautoRev;
    }
    /**
     * @param zautoRev the zautoRev to set
     */
    public void setZautoRev(String zautoRev) {
        this.zautoRev = zautoRev;
    }
    /**
     * @return the zmarkup
     */
    public BigDecimal getZmarkup() {
        return zmarkup;
    }
    /**
     * @param zmarkup the zmarkup to set
     */
    public void setZmarkup(BigDecimal zmarkup) {
        this.zmarkup = zmarkup;
    }
    /**
     * @return the zbubign
     */
    public Date getZbubign() {
        return zbubign;
    }
    /**
     * @param zbubign the zbubign to set
     */
    public void setZbubign(Date zbubign) {
        this.zbubign = zbubign;
    }
    /**
     * @return the zterdat
     */
    public Date getZterdat() {
        return zterdat;
    }
    /**
     * @param zterdat the zterdat to set
     */
    public void setZterdat(Date zterdat) {
        this.zterdat = zterdat;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the riskClass
     */
    public String getRiskClass() {
        return riskClass;
    }
    /**
     * @param riskClass the riskClass to set
     */
    public void setRiskClass(String riskClass) {
        this.riskClass = riskClass;
    }
    /**
     * @return the zcopak
     */
    public String getZcopak() {
        return zcopak;
    }
    /**
     * @param zcopak the zcopak to set
     */
    public void setZcopak(String zcopak) {
        this.zcopak = zcopak;
    }
    /**
     * @return the zpacktyAir
     */
    public String getZpacktyAir() {
        return zpacktyAir;
    }
    /**
     * @param zpacktyAir the zpacktyAir to set
     */
    public void setZpacktyAir(String zpacktyAir) {
        this.zpacktyAir = zpacktyAir;
    }
    /**
     * @return the zpacktySea
     */
    public String getZpacktySea() {
        return zpacktySea;
    }
    /**
     * @param zpacktySea the zpacktySea to set
     */
    public void setZpacktySea(String zpacktySea) {
        this.zpacktySea = zpacktySea;
    }
    /**
     * @return the zwels1
     */
    public String getZwels1() {
        return zwels1;
    }
    /**
     * @param zwels1 the zwels1 to set
     */
    public void setZwels1(String zwels1) {
        this.zwels1 = zwels1;
    }
    /**
     * @return the zwels2
     */
    public String getZwels2() {
        return zwels2;
    }
    /**
     * @param zwels2 the zwels2 to set
     */
    public void setZwels2(String zwels2) {
        this.zwels2 = zwels2;
    }
    /**
     * @return the zinco1
     */
    public String getZinco1() {
        return zinco1;
    }
    /**
     * @param zinco1 the zinco1 to set
     */
    public void setZinco1(String zinco1) {
        this.zinco1 = zinco1;
    }
    /**
     * @return the zinco2
     */
    public String getZinco2() {
        return zinco2;
    }
    /**
     * @param zinco2 the zinco2 to set
     */
    public void setZinco2(String zinco2) {
        this.zinco2 = zinco2;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the zpamre
     */
    public String getZpamre() {
        return zpamre;
    }
    /**
     * @param zpamre the zpamre to set
     */
    public void setZpamre(String zpamre) {
        this.zpamre = zpamre;
    }
    /**
     * @return the zarport1
     */
    public String getZarport1() {
        return zarport1;
    }
    /**
     * @param zarport1 the zarport1 to set
     */
    public void setZarport1(String zarport1) {
        this.zarport1 = zarport1;
    }
    /**
     * @return the zarport2
     */
    public String getZarport2() {
        return zarport2;
    }
    /**
     * @param zarport2 the zarport2 to set
     */
    public void setZarport2(String zarport2) {
        this.zarport2 = zarport2;
    }
    /**
     * @return the zfindes1
     */
    public String getZfindes1() {
        return zfindes1;
    }
    /**
     * @param zfindes1 the zfindes1 to set
     */
    public void setZfindes1(String zfindes1) {
        this.zfindes1 = zfindes1;
    }
    /**
     * @return the zfindes2
     */
    public String getZfindes2() {
        return zfindes2;
    }
    /**
     * @param zfindes2 the zfindes2 to set
     */
    public void setZfindes2(String zfindes2) {
        this.zfindes2 = zfindes2;
    }
    /**
     * @return the zdisRate01
     */
    public BigDecimal getZdisRate01() {
        return zdisRate01;
    }
    /**
     * @param zdisRate01 the zdisRate01 to set
     */
    public void setZdisRate01(BigDecimal zdisRate01) {
        this.zdisRate01 = zdisRate01;
    }
    /**
     * @return the zdisRate02
     */
    public BigDecimal getZdisRate02() {
        return zdisRate02;
    }
    /**
     * @param zdisRate02 the zdisRate02 to set
     */
    public void setZdisRate02(BigDecimal zdisRate02) {
        this.zdisRate02 = zdisRate02;
    }
    /**
     * @return the zdisRate03
     */
    public BigDecimal getZdisRate03() {
        return zdisRate03;
    }
    /**
     * @param zdisRate03 the zdisRate03 to set
     */
    public void setZdisRate03(BigDecimal zdisRate03) {
        this.zdisRate03 = zdisRate03;
    }
    /**
     * @return the zintmd
     */
    public String getZintmd() {
        return zintmd;
    }
    /**
     * @param zintmd the zintmd to set
     */
    public void setZintmd(String zintmd) {
        this.zintmd = zintmd;
    }
    /**
     * @return the zcentcd
     */
    public String getZcentcd() {
        return zcentcd;
    }
    /**
     * @param zcentcd the zcentcd to set
     */
    public void setZcentcd(String zcentcd) {
        this.zcentcd = zcentcd;
    }
    /**
     * @return the zkunnr2
     */
    public String getZkunnr2() {
        return zkunnr2;
    }
    /**
     * @param zkunnr2 the zkunnr2 to set
     */
    public void setZkunnr2(String zkunnr2) {
        this.zkunnr2 = zkunnr2;
    }
    /**
     * @return the zsalesPer
     */
    public String getZsalesPer() {
        return zsalesPer;
    }
    /**
     * @param zsalesPer the zsalesPer to set
     */
    public void setZsalesPer(String zsalesPer) {
        this.zsalesPer = zsalesPer;
    }
    /**
     * @return the kdgrp
     */
    public String getKdgrp() {
        return kdgrp;
    }
    /**
     * @param kdgrp the kdgrp to set
     */
    public void setKdgrp(String kdgrp) {
        this.kdgrp = kdgrp;
    }
    /**
     * @return the repKunnrFlag
     */
    public String getRepKunnrFlag() {
        return repKunnrFlag;
    }
    /**
     * @param repKunnrFlag the repKunnrFlag to set
     */
    public void setRepKunnrFlag(String repKunnrFlag) {
        this.repKunnrFlag = repKunnrFlag;
    }
}
