package com.mobis.maps.comm.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommRfcExecutLogVO;

/**
 * <pre>
 * RFC실행로그 서비스 정의
 * </pre>
 *
 * @ClassName   : MapsCommRfcExecutLogService.java
 * @Description : RFC실행로그에 대한 서비스를 정의.
 * @author DT048058
 * @since 2020. 2. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 7.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsCommRfcExecutLogService {

    /**
     * RFC실행로그 초기화정보 조회
     *
     * @return
     * @throws Exception
     */
    public Map<String, Object> selectRfcExecutLogInit() throws Exception;
    
    /**
     * RFC실행로그 페이징 리스트 조회
     *
     * @param commRfcExecutLogVO
     * @return
     * @throws Exception
     */
    public List<MapsCommRfcExecutLogVO> selectRfcExecutLogPgList(MapsCommRfcExecutLogVO commRfcExecutLogVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * RFC실행로그 입출력데이터 리스트 조회
     *
     * @param commRfcExecutLogVO
     * @return
     * @throws Exception
     */
    public List<MapsCommRfcExecutLogVO> selectRfcExecutLogDataList(MapsCommRfcExecutLogVO commRfcExecutLogVO, LoginInfoVO loginInfo) throws Exception;

}
