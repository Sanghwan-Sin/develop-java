package com.mobis.maps.comm.vo;

import java.util.Date;

/**
 * <pre>
 * RFC실행로그 항목
 * </pre>
 *
 * @ClassName   : MapsCommRfcExecutLogVO.java
 * @Description : RFC실행로그에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 2. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 7.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommRfcExecutLogVO extends PgBascVO {
    /* 조회조건 */
    /** 로그일시(시작일시) */
    private Date strtDt;
    /** 로그일시(종료일시) */
    private Date endDt;
    /** 시스템ID */
    private String rfcSysId;
    /* RFC실행로그 정보 */
    /** 이벤드ID */
    private int eventId;
    /** 시스템ID */
    private String sysId;
    /** RFC ID */
    private String rfcId;
    /** RFC서버 */
    private String rfcServer;
    /** CLIENT */
    private String rfcClient;
    /** 언어 */
    private String rfcLang;
    /** 화면ID */
    private String scrinId;
    /** 화면명 */
    private String scrinNm;
    /** 사용자ID */
    private String userId;
    /** 로그인IP주소 */
    private String lgiIpAdres;
    /** 스레드명 */
    private String threadNm;
    /** 로그레벨 */
    private String logLevel;
    /** 로그입출력 */
    private String logIptt;
    /** 로그메세지 */
    private String logMsg;
    /** 로그일시 */
    private Date logDt;
    /* RFC실행로그 데이터 정보 */
    /** RFC입출력구분 */
    private String rfcIpttSe;
    /** RFC필드 */
    private String rfcField;
    /** RFC데이터타입 */
    private String rfcDataTy;
    /** RFC데이터 */
    private String rfcData;
    
    /**
     * @return the strtDt
     */
    public Date getStrtDt() {
        return strtDt;
    }
    /**
     * @param strtDt the strtDt to set
     */
    public void setStrtDt(Date strtDt) {
        this.strtDt = strtDt;
    }
    /**
     * @return the endDt
     */
    public Date getEndDt() {
        return endDt;
    }
    /**
     * @param endDt the endDt to set
     */
    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }
    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }
    /**
     * @return the rfcSysId
     */
    public String getRfcSysId() {
        return rfcSysId;
    }
    /**
     * @param rfcSysId the rfcSysId to set
     */
    public void setRfcSysId(String rfcSysId) {
        this.rfcSysId = rfcSysId;
    }
    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    /**
     * @return the sysId
     */
    public String getSysId() {
        return sysId;
    }
    /**
     * @param sysId the sysId to set
     */
    public void setSysId(String sysId) {
        this.sysId = sysId;
    }
    /**
     * @return the rfcId
     */
    public String getRfcId() {
        return rfcId;
    }
    /**
     * @param rfcId the rfcId to set
     */
    public void setRfcId(String rfcId) {
        this.rfcId = rfcId;
    }
    /**
     * @return the rfcServer
     */
    public String getRfcServer() {
        return rfcServer;
    }
    /**
     * @param rfcServer the rfcServer to set
     */
    public void setRfcServer(String rfcServer) {
        this.rfcServer = rfcServer;
    }
    /**
     * @return the rfcClient
     */
    public String getRfcClient() {
        return rfcClient;
    }
    /**
     * @param rfcClient the rfcClient to set
     */
    public void setRfcClient(String rfcClient) {
        this.rfcClient = rfcClient;
    }
    /**
     * @return the rfcLang
     */
    public String getRfcLang() {
        return rfcLang;
    }
    /**
     * @param rfcLang the rfcLang to set
     */
    public void setRfcLang(String rfcLang) {
        this.rfcLang = rfcLang;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the scrinNm
     */
    public String getScrinNm() {
        return scrinNm;
    }
    /**
     * @param scrinNm the scrinNm to set
     */
    public void setScrinNm(String scrinNm) {
        this.scrinNm = scrinNm;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the lgiIpAdres
     */
    public String getLgiIpAdres() {
        return lgiIpAdres;
    }
    /**
     * @param lgiIpAdres the lgiIpAdres to set
     */
    public void setLgiIpAdres(String lgiIpAdres) {
        this.lgiIpAdres = lgiIpAdres;
    }
    /**
     * @return the threadNm
     */
    public String getThreadNm() {
        return threadNm;
    }
    /**
     * @param threadNm the threadNm to set
     */
    public void setThreadNm(String threadNm) {
        this.threadNm = threadNm;
    }
    /**
     * @return the logLevel
     */
    public String getLogLevel() {
        return logLevel;
    }
    /**
     * @param logLevel the logLevel to set
     */
    public void setLogLevel(String logLevel) {
        this.logLevel = logLevel;
    }
    /**
     * @return the logIptt
     */
    public String getLogIptt() {
        return logIptt;
    }
    /**
     * @param logIptt the logIptt to set
     */
    public void setLogIptt(String logIptt) {
        this.logIptt = logIptt;
    }
    /**
     * @return the logMsg
     */
    public String getLogMsg() {
        return logMsg;
    }
    /**
     * @param logMsg the logMsg to set
     */
    public void setLogMsg(String logMsg) {
        this.logMsg = logMsg;
    }
    /**
     * @return the logDt
     */
    public Date getLogDt() {
        return logDt;
    }
    /**
     * @param logDt the logDt to set
     */
    public void setLogDt(Date logDt) {
        this.logDt = logDt;
    }
    /**
     * @return the rfcIpttSe
     */
    public String getRfcIpttSe() {
        return rfcIpttSe;
    }
    /**
     * @param rfcIpttSe the rfcIpttSe to set
     */
    public void setRfcIpttSe(String rfcIpttSe) {
        this.rfcIpttSe = rfcIpttSe;
    }
    /**
     * @return the rfcField
     */
    public String getRfcField() {
        return rfcField;
    }
    /**
     * @param rfcField the rfcField to set
     */
    public void setRfcField(String rfcField) {
        this.rfcField = rfcField;
    }
    /**
     * @return the rfcDataTy
     */
    public String getRfcDataTy() {
        return rfcDataTy;
    }
    /**
     * @param rfcDataTy the rfcDataTy to set
     */
    public void setRfcDataTy(String rfcDataTy) {
        this.rfcDataTy = rfcDataTy;
    }
    /**
     * @return the rfcData
     */
    public String getRfcData() {
        return rfcData;
    }
    /**
     * @param rfcData the rfcData to set
     */
    public void setRfcData(String rfcData) {
        this.rfcData = rfcData;
    }
}
