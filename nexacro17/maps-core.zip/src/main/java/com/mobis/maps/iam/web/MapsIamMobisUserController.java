package com.mobis.maps.iam.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.annotation.ParamVariable;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.vo.MapsIamMobisOrgnztVO;
import com.mobis.maps.iam.vo.MapsIamMobisUserVO;

/**
 * <pre>
 * 모비스사용자 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamMobisUserController.java
 * @Description : 모비스사용자에 대한 컨트롤러를 정의.
 * @author DT048058
 * @since 2020. 4. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 17.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamMobisUserController extends HController {

    @Resource(name = "mapsIamMobisUserService")
    private MapsIamMobisUserService mapsIamMobisUserService;

    /**
     * 모비스 조직 트리리스트 조회
     *
     * @param iamMobisOrgnztVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectMobisOrgnztTreeList.do")
    public NexacroResult selectMobisOrgnztTreeList(
            @ParamDataSet(name="dsInput") MapsIamMobisOrgnztVO iamMobisOrgnztVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (loginInfo == null) {
            return result;
        }
        
        List<MapsIamMobisOrgnztVO> mobisOrgnzts = mapsIamMobisUserService.selectMobisOrgnztTreeList(iamMobisOrgnztVO);
        
        result.addDataSet("dsOutput", mobisOrgnzts);
        
        return result;
    }

    /**
     * 모비스 사용자 페이징리스트 조회
     *
     * @param iamMobisUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectMobisUserPgList.do")
    public NexacroResult selectMobisUserPgList(
            @ParamDataSet(name="dsInput") MapsIamMobisUserVO iamMobisUserVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (loginInfo == null) {
            return result;
        }
        
        List<MapsIamMobisUserVO> mobisUsers = mapsIamMobisUserService.selectMobisUserPgList(iamMobisUserVO);
        
        result.addDataSet("dsOutput", mobisUsers);
        
        return result;
    }

    /**
     * 모비스 사용자 트리리스트 조회
     *
     * @param iamMobisUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectMobisUserTreeList.do")
    public NexacroResult selectMobisUserTreeList(
            @ParamDataSet(name="dsInput") MapsIamMobisUserVO iamMobisUserVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (loginInfo == null) {
            return result;
        }
        
        List<MapsIamMobisUserVO> mobisUsers = mapsIamMobisUserService.selectMobisUserTreeList(iamMobisUserVO);
        
        result.addDataSet("dsOutput", mobisUsers);
        
        return result;
    }

    /**
     * 대표하위대리점 리스트 조회
     *
     * @param iamMobisOrgnztVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectOrgnztDistInfoList.do")
    public NexacroResult selectOrgnztDistInfoList(
            @ParamDataSet(name="dsInput") MapsIamMobisOrgnztVO iamMobisOrgnztVO
            , @ParamVariable(name="cboSjTy") String cboSjTy
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (loginInfo == null) {
            return result;
        }
        
        List<MapsOrgnztDistVO> repDistOrgnzts = mapsIamMobisUserService.selectOrgnztDistInfoList(loginInfo);
        
        if (StringUtils.isNotBlank(cboSjTy)) {
            MapsOrgnztDistVO cboSjOrgnzt = mapsIamMobisUserService.selectCboSjWordNm(cboSjTy, loginInfo);
            repDistOrgnzts.add(0, cboSjOrgnzt);
        }
        
        result.addDataSet("dsOutput", repDistOrgnzts);
        
        return result;
    }

    /**
     * 대리점 고객그룹 리스트 조회
     *
     * @param iamMobisOrgnztVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectDistKdGrpList.do")
    public NexacroResult selectDistKdGrpList(
            @ParamDataSet(name="dsInput") MapsIamMobisOrgnztVO iamMobisOrgnztVO
            , @ParamVariable(name="cboSjTy") String cboSjTy
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (loginInfo == null) {
            return result;
        }
        
        List<MapsOrgnztDistVO> distKdGrpOrgnzts = mapsIamMobisUserService.selectDistKdGrpList(loginInfo);

        if (StringUtils.isNotBlank(cboSjTy)) {
            MapsOrgnztDistVO cboSjOrgnzt = mapsIamMobisUserService.selectCboSjWordNm(cboSjTy, loginInfo);
            distKdGrpOrgnzts.add(0, cboSjOrgnzt);
        }
        
        result.addDataSet("dsOutput", distKdGrpOrgnzts);
        
        return result;
    }
}
