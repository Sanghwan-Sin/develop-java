package com.mobis.maps.smpl.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplAtchFileVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsSmplAtchFileVO {

    private String atchSe;
    private String seq;
    
    /**
     * @return the atchSe
     */
    public String getAtchSe() {
        return atchSe;
    }
    /**
     * @param atchSe the atchSe to set
     */
    public void setAtchSe(String atchSe) {
        this.atchSe = atchSe;
    }
    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }
}
