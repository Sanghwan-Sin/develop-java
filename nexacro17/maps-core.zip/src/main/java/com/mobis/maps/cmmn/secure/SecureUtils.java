package com.mobis.maps.cmmn.secure;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import able.com.secure.WebSecurityUtil;
import able.com.util.crypto.AES256CryptoService;
import able.com.util.crypto.ARIACryptoService;
import able.com.util.crypto.SHA256PasswordEncoder;
import able.com.util.crypto.TripleDESCryptoService;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mobis.maps.cmmn.constants.SecureConstants;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.util.StringUtil;
import com.nexacro17.xapi.data.DataSet;
import com.nexacro17.xapi.data.DataSetList;
import com.nexacro17.xapi.data.PlatformData;
import com.nexacro17.xapi.data.Variable;
import com.nexacro17.xapi.data.VariableList;

/**
 * <pre>
 * 암호화 및 복호화
 * </pre>
 *
 * @ClassName   : SecureUtils.java
 * @Description : 암호화 및 복호화
 * @author KWON CHAN SOON
 * @since 2017. 11. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2017. 11. 29.  KWON CHAN SOON   최초 생성
 * </pre>
 */
@Component
public class SecureUtils {
    
    private final static char[] HEXARRAY = "0123456789ABCDEF".toCharArray();
    private final static String PREPIX = "KEY_";
    private final static String PROP_KEY_VALUE = "_KEY_VALUE";
    private final static String PROP_IV_VALUE = "_IV_VALUE";
    private static byte[] ivBytes = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

    private static Logger logger = LoggerFactory.getLogger(SecureUtils.class);

    /**
     * SHA256 암호화
     * 패스워드 용
     * @param str
     * @return
     */
    public static String encryptPwSHA256(String str) {
        String encrypted = null;

        if(!StringUtils.isEmpty(str)) {
            encrypted = SHA256PasswordEncoder.encryptPassword(str, getKey("SHA256_SALT"), SecureConstants.SHA256_ITERATIOS_VALUE);
        } else {
            encrypted = str;
        }

        return encrypted;
    }

    /**
     * SHA256 확인함수
     * 패스워드 확인
     * @param str
     * @return
     */
    public static boolean encryptCheckPwSHA256(String str,String encryptedPassword) {
        boolean chk = false;

        if(!StringUtils.isEmpty(str) && !StringUtils.isEmpty(encryptedPassword)) {
            chk = SHA256PasswordEncoder.checkPassword(str,encryptedPassword,getKey("SHA256_SALT"), SecureConstants.SHA256_ITERATIOS_VALUE);
        }

        return chk;
    }

    /**
     * encryptARIA
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String encryptARIA(String str) throws Exception {
        String encrypted = null;

        if(!StringUtils.isEmpty(str)) {
            ARIACryptoService ariaCryptoService = new ARIACryptoService();

            // String -> byte[] 변환
            byte[] msgB = str.getBytes();

            // 암호화
            byte[] encryptedB = ariaCryptoService.encrypt(msgB, getKey("ARIA"));

            // byte[] -> Base64 String 변환
            encrypted = org.apache.commons.codec.binary.Base64.encodeBase64String(encryptedB);
        } else {
            encrypted = str;
        }

        return encrypted;
    }

    /**
     * decryptARIA
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String decryptARIA(String str) throws Exception{
        String decrypted = null;

        if(!StringUtils.isEmpty(str)) {
            ARIACryptoService ariaCryptoService = new ARIACryptoService();

            // Base64 String -> byte[] 변환
            byte[] encyptedB = org.apache.commons.codec.binary.Base64.decodeBase64(str);

            // 복호화
            byte[] decryptedB = ariaCryptoService.decrypt(encyptedB, getKey("ARIA"));

            // byte[] -> String 변환
            decrypted = new String(decryptedB);
        } else {
            decrypted = str;
        }

        return decrypted;
    }

    /**
     * encryptAES256
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String encryptAES256(String str) throws Exception {
        String encrypted = null;

        if(!StringUtils.isEmpty(str)) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();

            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(getKey("AES256").toCharArray());
            byte[] ivB = Hex.decodeHex(getIv("AES256").toCharArray());

            // 암호화 - Base64 String 결과 반환
            encrypted = aes256CryptoService.encrypt(keyB, ivB, str);
        } else {
            encrypted =  str;
        }

        return encrypted;
    }

    /**
     * encryptAES256
     *
     * @param str
     * @param key
     * @param iv
     * @return
     * @throws Exception
     */
    public static String encryptAES256(String str, String key, String iv) throws Exception {
        String encrypted = null;

        if(!StringUtils.isEmpty(str) && !StringUtils.isEmpty(key) && !StringUtils.isEmpty(iv)) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();

            // Hex String -> byte[] 변환
            byte[] ivB = Hex.decodeHex(iv.toCharArray());

            // 암호화 - Base64 String 결과 반환
            encrypted = aes256CryptoService.encrypt(key.getBytes(), ivB, str);
        } else {
            encrypted =  str;
        }

        return encrypted;
    }

    /**
    *
    * 블루멤버스 화면 호출용
    *
    * @param str
    * @return
    * @throws Exception
    */
   public static String encryptAES256ForBlueMemScrn(String str) throws Exception {
       String encrypted = null;

       if ( !StringUtils.isEmpty(str) ) {
           AES256CryptoService aes256CryptoService = new AES256CryptoService();
           byte[] keyB = getKey("BLUE_256_SCRN").getBytes();
           byte[] ivB = getIv("BLUE_256_SCRN").getBytes();
           // 암호화 - Base64 String 결과 반환
           encrypted = aes256CryptoService.encrypt(keyB, ivB, str);
       } else {
           encrypted =  str;
       }

       return encrypted;
   }

   public static String decryptAES256ForBlueMemScrn(String str) throws Exception {
       String decrypted = null;

       if(!StringUtils.isEmpty(str)) {
           AES256CryptoService aes256CryptoService = new AES256CryptoService();
           byte[] keyB = getKey("BLUE_256_SCRN").getBytes();
           byte[] ivB = getIv("BLUE_256_SCRN").getBytes();
           // 복호화
           decrypted = aes256CryptoService.decrypt(keyB, ivB, str);
       } else {
           decrypted =  str;
       }

       return decrypted;
   }

    /**
     *
     * 블루멤버스 API 호출용
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String encryptAES256ForBlueMemUrl(String str) throws Exception {
        String encrypted = null;

        if ( !StringUtils.isEmpty(str) ) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = getKey("BLUE_256").getBytes();
            byte[] ivB = getIv("BLUE_256").getBytes();
            // 암호화 - Base64 String 결과 반환
            encrypted = aes256CryptoService.encrypt(keyB, ivB, str);
        } else {
            encrypted =  str;
        }

        return encrypted;
    }

    public static String decryptAES256ForBlueMemUrl(String str) throws Exception {
        String decrypted = null;

        if(!StringUtils.isEmpty(str)) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = getKey("BLUE_256").getBytes();
            byte[] ivB = getIv("BLUE_256").getBytes();
            // 복호화
            decrypted = aes256CryptoService.decrypt(keyB, ivB, str);
        } else {
            decrypted =  str;
        }

        return decrypted;
    }

    /**
     * decryptAES256
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String decryptAES256(String str) throws Exception {
        String decrypted = null;

        if (!StringUtils.isEmpty(str)) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();

            // Base64 String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(getKey("AES256").toCharArray());
            byte[] ivB = Hex.decodeHex(getIv("AES256").toCharArray());

            // 복호화
            decrypted = aes256CryptoService.decrypt(keyB, ivB, str);
        } else {
            decrypted =  str;
        }

        return decrypted;
    }

    /**
     * decryptAES256
     *
     * @param str
     * @param key
     * @param iv
     * @return
     * @throws Exception
     */
    public static String decryptAES256(String str, String key, String iv) throws Exception {
        String decrypted = null;

        if(!StringUtils.isEmpty(str) && !StringUtils.isEmpty(key) && !StringUtils.isEmpty(iv)) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();

            // Base64 String -> byte[] 변환
            byte[] ivB = Hex.decodeHex(iv.toCharArray());

            // 복호화
            decrypted = aes256CryptoService.decrypt(key.getBytes("UTF-8"), ivB, str);
        } else {
            decrypted =  str;
        }

        return decrypted;
    }
    
    /**
     * encryptAES256Cipher
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String encryptAES256Cipher(String str) throws Exception {
        
        return encryptAES256Cipher(str, SecureConstants.AES256_CIPHER_KEY_VALUE, SecureConstants.AES256_CIPHER_IV_VALUE);
    }
    
    /**
     * encryptAES256Cipher
     *
     * @param str
     * @param key
     * @param iv
     * @return
     * @throws Exception
     */
    public static String encryptAES256Cipher(String str, String key, String iv) throws Exception {

        SecretKey secureKey = generateKey(key);
        Cipher c = Cipher.getInstance(SecureConstants.AES_CBC_PKCS5PADDING);
        c.init(Cipher.ENCRYPT_MODE, secureKey, new IvParameterSpec(new byte[16]));
        byte[] encrypted = c.doFinal(str.getBytes("UTF-8"));

        return new String(org.apache.commons.codec.binary.Base64.encodeBase64(encrypted));
    }

    /**
     * decryptAES256Cipher
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String decryptAES256Cipher(String str) throws Exception {
        
        return decryptAES256Cipher(str, SecureConstants.AES256_CIPHER_KEY_VALUE, SecureConstants.AES256_CIPHER_IV_VALUE);
    }
    
    /**
     * decryptAES256Cipher
     *
     * @param str
     * @param key
     * @param iv
     * @return
     * @throws Exception
     */
    public static String decryptAES256Cipher(String str, String key, String iv) throws Exception {

        SecretKey secureKey = generateKey(key);
        Cipher c = Cipher.getInstance(SecureConstants.AES_CBC_PKCS5PADDING);
        c.init(Cipher.DECRYPT_MODE, secureKey, new IvParameterSpec(new byte[16]));
        
        return new String(c.doFinal(org.apache.commons.codec.binary.Base64.decodeBase64(str)), "UTF-8");
    }

    /**
     *
     * VAN 암호화
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String encryptAES256ForVanUrl(String str) throws Exception {
        String encrypted = null;

        if ( !StringUtils.isEmpty(str) ) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = getKey("VAN_256").getBytes();
            byte[] ivB = getIv("VAN_256").getBytes();
            // 암호화 - Base64 String 결과 반환
            encrypted = aes256CryptoService.encrypt(keyB, ivB, str);
        } else {
            encrypted =  str;
        }

        return encrypted;
    }

    /**
     *
     * VAN 복호화
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String decryptAES256ForVanUrl(String str) throws Exception {
        String decrypted = null;

        if(!StringUtils.isEmpty(str)) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = getKey("VAN_256").getBytes();
            byte[] ivB = getIv("VAN_256").getBytes();
            // 복호화
            decrypted = aes256CryptoService.decrypt(keyB, ivB, str);
        } else {
            decrypted =  str;
        }

        return decrypted;
    }

    /**
     * encryptTripleDES
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String encryptTripleDES(String str) throws Exception {
        String encrypted = null;

        if (!StringUtils.isEmpty(str)) {
            TripleDESCryptoService tripleDESCryptoService = new TripleDESCryptoService();

            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(getKey("TDES").toCharArray());
            byte[] ivB = Hex.decodeHex(getIv("TDES").toCharArray());

            // 암호화 - Base64 String 결과 반환
            encrypted = tripleDESCryptoService.encrypt(keyB, ivB, str);
        } else {
            encrypted =  str;
        }

        return encrypted;
    }

    /**
     * decryptTripleDES
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String decryptTripleDES(String str) throws Exception {
        String decrypted = null;

        if(!StringUtils.isEmpty(str)) {
            TripleDESCryptoService tripleDESCryptoService = new TripleDESCryptoService();
            // Base64 String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(getKey("TDES").toCharArray());
            byte[] ivB = Hex.decodeHex(getIv("TDES").toCharArray());

            // 복호화
            decrypted = tripleDESCryptoService.decrypt(keyB, ivB, str);
        } else {
            decrypted =  str;
        }

        return decrypted;
    }

    /* 긴급출동 CTI연계 파마메터 암호화 */
    public static String encryptSosUrl(String param) throws Exception {
        return encryptSosUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("SOS"), getIv("SOS"));
    }

    public static String encryptSosUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = null;
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if(transType.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
                //ECB모드는 ivKey 사용없음
                cipher.init(Cipher.ENCRYPT_MODE, key);
            } else {
                //CBC모드는 ivKey 사용
                if(null != ivValue && ivValue.length() > 0){
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }

            byte[] encData  = cipher.doFinal(srcData.getBytes());
            result = com.mobis.maps.cmmn.secure.Base64.encodeToString(encData);
        } catch(Exception e) {
            if( logger.isDebugEnabled() ){
                logger.debug("{}",e.getMessage());
            }
            result = "";
        }
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : {}" , srcData);
            logger.debug("암호화 : {}" , result);
        }

        return result;
    }

    /* 긴급출동 CTI연계 파마메터 복호화 */
    public static String decryptSosUrl(String param) throws Exception {
        return decryptSosUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("SOS"), getIv("SOS"));
    }

    public static String decryptSosUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = "";

        try {
            SecretKey key = generateKey(keyValue);

            Cipher cipher = Cipher.getInstance(transType);

            if ( transType.equals(SecureConstants.AES_CBC_PKCS5PADDING) ) {
                if ( null!=ivValue && ivValue.length()>0 ) {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }

            byte[] decData = cipher.doFinal(Base64.decodeToByteArray(srcData));

            result = new String(decData);
        } catch (Exception e) {
            result = "";
        }
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : {}" , srcData);
            logger.debug("복호화 : {}", result);
        }
        return result;
    }

    //CM URL 암호화
    public static String encryptCmUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = null;
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if(transType.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
                //ECB모드는 ivKey 사용없음
                cipher.init(Cipher.ENCRYPT_MODE, key);
            } else {
                //CBC모드는 ivKey 사용
                if(null != ivValue && ivValue.length() > 0){
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] encData  = cipher.doFinal(srcData.getBytes());
            result = com.mobis.maps.cmmn.secure.Base64.encodeToString(encData);
        } catch(Exception e) {
            result = "";
        }
        return result;
    }

    //CM URL 암호화
    public static String encryptCmUrl(String param) throws Exception {
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);
        String tempParam=param;
        Date currentTime = new Date();
        String mTime = sDateFormat.format(currentTime);
        tempParam += mTime;
        return encryptCmUrl(SecureConstants.AES_CBC_PKCS5PADDING, tempParam, getKey("CM_256"), getIv("CM_256"));
    }

    //Haims URL 암호화
    public static String encryptHaimsUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = null;
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if(transType.equals(SecureConstants.AES_CBC_PKCS5PADDING)){
                if(null != ivValue && ivValue.length() > 0){
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] encData  = cipher.doFinal(srcData.getBytes());
            result = com.mobis.maps.cmmn.secure.Base64.encodeToString(encData);
        } catch(Exception e) {
            result = "";
        }
        return result;
    }

    //Haims URL 암호화
    public static String encryptHaimsUrl(String param) throws Exception {
        return encryptHaimsUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("HAIMS"), getIv("HAIMS"));
    }

    //Haims URL 복호화
    public static String decryptToHaims(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = "";
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if ( transType.equals(SecureConstants.AES_CBC_PKCS5PADDING) ) {
                if ( null!=ivValue && ivValue.length()>0 ) {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] decData = cipher.doFinal(Base64.decodeToByteArray(srcData));
            result = new String(decData);
        } catch (Exception e) {
            result = "";
        }
        return result;
    }

    //Haims URL 복호화
    public static String decryptToHaims(String param) throws Exception {
        return decryptToHaims(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("HAIMS"), getIv("HAIMS"));
    }

    // URL 복호화
    public static String decryptUrl(String algorithm, String keyScn, String param) throws Exception {
        String result = "";
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : " + param);
        }

        if(algorithm.equals(SecureConstants.AES_ECB_NOPADDING)){
            result = decryptUrl(SecureConstants.AES_ECB_NOPADDING, param, getKey(keyScn), getIv(keyScn));
        } else if(algorithm.equals(SecureConstants.AES_CBC_NOPADDING)){
            result = decryptUrl(SecureConstants.AES_CBC_NOPADDING, param, getKey(keyScn), getIv(keyScn));
        } else if(algorithm.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
            result = decryptUrl(SecureConstants.AES_ECB_PKCS5PADDING, param, getKey(keyScn), getIv(keyScn));
        } else if(algorithm.equals(SecureConstants.AES_CBC_PKCS5PADDING)){
            result = decryptUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey(keyScn), getIv(keyScn));
        }
        if( logger.isDebugEnabled() ){
            logger.debug("암호화 : " + result);
        }
        return result;
    }

    // URL 복호화 : 파트너시스템인 경우
    public static String decryptUrlPartner(String algorithm, String keyScn, String param) throws Exception {
        String result = "";
        try {
            SecretKey key = generateKey(getKey(keyScn));
            Cipher cipher = Cipher.getInstance(algorithm);
            AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
            cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);

            byte[] textBytes = cipher.doFinal(org.apache.commons.codec.binary.Base64.decodeBase64(param));
            result = new String(textBytes, "UTF-8");
        } catch (Exception e) {
            result = "";
        }

        return result;
    }

    //MicroSite URL 암호화 2018-04-26 오지민 생성
    public static String encryptMicroUrl(String param) throws Exception {
        return encryptMicroUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("MICRO"), getIv("MICRO"));
    }

    //MicroSite URL 암호화 2018-04-26 오지민 생성
    public static String encryptMicroUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = null;
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if(transType.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
                //ECB모드는 ivKey 사용없음
                cipher.init(Cipher.ENCRYPT_MODE, key);
            } else {
                //CBC모드는 ivKey 사용
                if(null != ivValue && ivValue.length() > 0){
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] encData  = cipher.doFinal(srcData.getBytes());
            //result = com.mobis.maps.cmmn.secure.Base64.encodeToString(encData);
            result = byteArrayToHexString(encData);
        } catch(Exception e) {
            result = "";
        }
        return result;
    }


  //MicroSite URL 복호화 2018-04-26 오지민 생성
    public static String decryptMicroUrl(String param) throws Exception {
        return decryptMicroUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("MICRO"), getIv("MICRO"));
    }
    //Micro URL 복호화  2018-04-26 오지민 생성
    public static String decryptMicroUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = "";

        try {
            SecretKey key = generateKey(keyValue);

            Cipher cipher = Cipher.getInstance(transType);

            if(transType.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
                if ( null!=ivValue && ivValue.length()>0 ) {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }

            byte[] decData = cipher.doFinal(hexStringToByteArray(srcData));

            result = new String(decData);

            result = new String(decData);
        } catch (Exception e) {
            result = "";
        }
        
        return result;
    }

    /**
     * Statements
     *
     * @param s
     * @return
     */
    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                                 + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }


    /**
     * Statements
     *
     * @param bytes
     * @return
     */
    public static String byteArrayToHexString(byte[] bytes){
        char[] hexChars = new char[bytes.length * 2];
        for(int i = 0; i < bytes.length; i++){
            int v = bytes[i] & 0xff;
            hexChars[i * 2] = HEXARRAY[v >>> 4];
            hexChars[i * 2 + 1] = HEXARRAY[v & 0x0f];
        }
        return new String(hexChars);
    }

    // URL 복호화
    public static String decryptUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = "";

        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);


            if ( transType.equals(SecureConstants.AES_CBC_PKCS5PADDING) ) {

                if ( null!=ivValue && ivValue.length()>0 ) {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] decData = cipher.doFinal(Base64.decodeToByteArray(srcData));

            result = new String(decData);

        } catch (Exception e) {
            result = "";
        }
        return result;
    }

    // URL 암호화
    public static String encryptUrl(String algorithm, String keyScn, String param) throws Exception {
        String result = "";
        if(algorithm.equals(SecureConstants.AES_ECB_NOPADDING)){
            result = encryptUrl(SecureConstants.AES_ECB_NOPADDING, param, getKey(keyScn), StringUtils.stripToNull(getIv(keyScn)));
        } else if(algorithm.equals(SecureConstants.AES_CBC_NOPADDING)){
            result = encryptUrl(SecureConstants.AES_CBC_NOPADDING, param, getKey(keyScn), StringUtils.stripToNull(getIv(keyScn)));
        } else if(algorithm.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
            result = encryptUrl(SecureConstants.AES_ECB_PKCS5PADDING, param, getKey(keyScn), StringUtils.stripToNull(getIv(keyScn)));
        } else if(algorithm.equals(SecureConstants.AES_CBC_PKCS5PADDING)){
            result = encryptUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey(keyScn), StringUtils.stripToNull(getIv(keyScn)));
        }
        return result;
    }

    // URL 암호화 : 파트너시스템인 경우
    public static String encryptUrlPartner(String algorithm, String keyScn, String param) throws Exception {
        String result = "";
        try {
            SecretKey key = generateKey(getKey(keyScn));
            Cipher cipher = Cipher.getInstance(algorithm);
            AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
            cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);

            byte[] textBytes = cipher.doFinal(param.getBytes("UTF-8"));
            result = org.apache.commons.codec.binary.Base64.encodeBase64String(textBytes);
        } catch(Exception e) {
            result = "";
        }

       return result;
    }

    //URL 암호화
    public static String encryptUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = "";
        if( logger.isDebugEnabled() ){
            logger.debug("==encryptUrl keyValue : " + keyValue);
            logger.debug("==encryptUrl ivValue : " + ivValue);
        }
        try {
            SecretKey key = generateKey(keyValue);

            Cipher cipher = Cipher.getInstance(transType);

            if(transType.equals(SecureConstants.AES_ECB_NOPADDING)){
                cipher.init(Cipher.ENCRYPT_MODE, key);

                byte[] eArr = cipher.doFinal(addPadding(srcData.getBytes()));

                return fromHex(eArr);
            }else if(transType.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
                cipher.init(Cipher.ENCRYPT_MODE, key);
            } else {
                if(null != ivValue && ivValue.length() > 0){
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }

                if(transType.equals(SecureConstants.AES_CBC_NOPADDING)){
                    byte[] eArr = cipher.doFinal(addPadding(srcData.getBytes()));

                    return fromHex(eArr);
                }
            }
            byte[] encData = cipher.doFinal(srcData.getBytes());

            result = com.mobis.maps.cmmn.secure.Base64.encodeToString(encData);

        } catch(Exception e) {
            result = "";
        }

        return result;
    }

    private static byte[] addPadding(final byte[] pBytes) {
        int pCount = pBytes.length;
        int tCount = pCount + (16 - (pCount % 16));

        byte[] tBytes = new byte[tCount];

        System.arraycopy(pBytes, 0, tBytes, 0, pCount);

        for (int rIndex = pCount; rIndex < tCount; rIndex++) {
            tBytes[rIndex] = 0x00;
        }

        return tBytes;
    }

    public static String fromHex(byte[] pBytes) {
        int pCount = pBytes.length;

        StringBuffer buff = new StringBuffer(pCount * 2);

        for (int pIndex = 0; pIndex < pCount; pIndex++) {
            if ((pBytes[pIndex] & 0xff) < 0x10) {
                buff.append("0");
            }

            buff.append(Long.toString(pBytes[pIndex] & 0xff, 16));
        }

        return buff.toString();
    }

    //OC URL 암호화
    public static String encryptOcUrl(String param) throws Exception {
        //SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);
        //Date currentTime = new Date();
        String temp=param;
        long mTime = Calendar.getInstance().getTimeInMillis();
        temp += mTime;
        return encryptCmUrl(SecureConstants.AES_CBC_PKCS5PADDING, temp, getKey("OC"), getIv("OC"));
    }

    //DID URL 암호화 2016-09-28 노명선 생성
    public static String encryptDidUrl(String param) throws Exception {
        return encryptDidUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("DID"), getIv("DID"));
    }

    //DID URL 암호화 2016-09-28 노명선 생성
    public static String encryptDidUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = null;
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if(transType.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
                //ECB모드는 ivKey 사용없음
                cipher.init(Cipher.ENCRYPT_MODE, key);
            } else {
                //CBC모드는 ivKey 사용
                if(null != ivValue && ivValue.length() > 0){
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] encData  = cipher.doFinal(srcData.getBytes());
            result = com.mobis.maps.cmmn.secure.Base64.encodeToString(encData);
        } catch(Exception e) {
            result = "";
        }
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : {}" , srcData);
            logger.debug("암호화 : {}" , result);
        }
        return result;
    }

    //DID URL 복호화  2016-09-28 노명선 생성
    public static String decryptDidUrl(String param) throws Exception {
        return decryptDidUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("DID"), getIv("DID"));
    }

    //DID URL 복호화  2016-09-28 노명선 생성
    public static String decryptDidUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = "";
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if ( transType.equals(SecureConstants.AES_CBC_PKCS5PADDING) ) {
                if ( null!=ivValue && ivValue.length()>0 ) {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] decData = cipher.doFinal(Base64.decodeToByteArray(srcData));
            result = new String(decData);
        } catch (Exception e) {
            if( logger.isDebugEnabled() ){
                logger.debug("{}",e.getMessage());
            }
            result = "";
        }
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : {}" , srcData);
            logger.debug("복호화 : {}" ,result);
        }

        return result;
    }

    public static String encryptBlueMemUrl(String param) throws Exception {
        String result = "";
        if(param == null || "".equals(param)) {
            result = "";
        }else{
            result = encryptCmUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("CM"), getIv("CM"));
        }
        return result;
    }

    public static String decryptBlueMemUrl(String param) throws Exception {
        String result = "";
        if(param == null || "".equals(param)) {
            result = "";
        }else{
            result = decryptUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("CM"), getIv("CM"));
        }
        return result;
    }

    /* Van 연계 파마메터 암호화  20170628 김정아*/
    public static String encryptVanUrl(String param) throws Exception {
        return encryptVanUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("VAN"), getIv("VAN"));
    }

    public static String encryptVanUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = null;
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if(transType.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
                //ECB모드는 ivKey 사용없음
                cipher.init(Cipher.ENCRYPT_MODE, key);
            } else {
                //CBC모드는 ivKey 사용
                if(null != ivValue && ivValue.length() > 0){
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] encData  = cipher.doFinal(srcData.getBytes());
            result = com.mobis.maps.cmmn.secure.Base64.encodeToString(encData);
        } catch(Exception e) {
            if( logger.isDebugEnabled() ){
                logger.debug("{}",e.getMessage());
            }
            result = "";
        }
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : {}" , srcData);
            logger.debug("암호화 : {}" , result);
        }
        return result;
    }

    public static String decryptVanUrl(String param) throws Exception {
        return decryptVanUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey("VAN"), getIv("VAN"));
    }

    public static String decryptVanUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = "";
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if ( transType.equals(SecureConstants.AES_CBC_PKCS5PADDING) ) {
                if ( null!=ivValue && ivValue.length()>0 ) {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] decData = cipher.doFinal(Base64.decodeToByteArray(srcData));
            result = new String(decData);
        } catch (Exception e) {
            if( logger.isDebugEnabled() ){
                logger.debug("{}",e.getMessage());
            }
            result = "";
        }
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : {}", srcData);
            logger.debug("복호화 : {}", result);
        }
        return result;
    }

    // TI URL 암호화
    public static String encryptTiUrl(String param) throws Exception {
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);
        Date currentTime = new Date();
        String mTime = sDateFormat.format(currentTime);
        String data = param;
        data += mTime;
        String result = null;

        try {
            SecretKey key = generateKey(getKey("TI"));
            String ivValue = getIv("TI") ;
            Cipher cipher = Cipher.getInstance(SecureConstants.AES_CBC_PKCS5PADDING);

            if(null != ivValue && ivValue.length() > 0){
                cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
            } else {
                cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(new byte[16]));
            }
            byte[] encData  = cipher.doFinal(data.getBytes());
            result = com.mobis.maps.cmmn.secure.Base64.encodeToString(encData);
        } catch(Exception e) {
            if( logger.isDebugEnabled() ){
                logger.debug(e.getMessage());
            }
            result = "";
        }
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : " + data);
            logger.debug("암호화 : " + result);
        }
        return result;
    }

    /**
     * 암호화 처리
     *
     * @param scn
     * @param val
     * @return
     * @throws Exception
     */
    public static String secureEncryptAES256(String scn, String val) throws Exception{
        String result = "";
        Secure secure = new Secure(getKey(scn), getIv(scn));
        result = secure.encryptAES256(val);
        return result;
    }

    /**
     * 복호화 처리
     *
     * @param scn
     * @param val
     * @return
     * @throws Exception
     */
    public static String secureDecryptAES256(String scn, String val) throws Exception{
        String result = "";
        Secure secure = new Secure(getKey(scn), getIv(scn));
        result = secure.decryptAES256(val);
        return result;
    }


    /**
     * PRINT 암호화
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String encryptAES128Print(String str) throws Exception {
        return encryptAES128(str, getKey("PRINT"), "");
    }

    /**
     * PRINT 복화화
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String decryptAES128Print(String str) throws Exception {
        return decryptAES128(str, getKey("PRINT"), "");
    }
    /**
     * encryptAES128
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String encryptAES128(String str, String key, String iv) throws Exception {
        String encrypted = null;

        if(!StringUtils.isEmpty(str)) {
            AES128CryptoService aes128CryptoService = new AES128CryptoService();

            // Hex String -> byte[] 변환
            byte[] keyB = key.getBytes("UTF-8");
            byte[] ivB = null;
            if(iv != null && !iv.equals("")){
                ivB = iv.getBytes();
            }else{
                ivB = ivBytes;
            }

            // 암호화 - Base64 String 결과 반환
            encrypted = aes128CryptoService.encrypt(keyB, ivB, str);
        } else {
            encrypted =  str;
        }
        return encrypted;
    }

    /**
     * decryptAES256
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String decryptAES128(String str, String key, String iv) throws Exception {
        String decrypted = null;

        if (!StringUtils.isEmpty(str)) {
            AES128CryptoService aes128CryptoService = new AES128CryptoService();

            // Base64 String -> byte[] 변환
            byte[] keyB = key.getBytes("UTF-8");
            byte[] ivB = null;
            if(iv != null && !iv.equals("")){
                ivB = iv.getBytes();
            }else{
                ivB = ivBytes;
            }
            // 복호화
            decrypted = aes128CryptoService.decrypt(keyB, ivB, str);
        } else {
            decrypted =  str;
        }
        return decrypted;
    }

    /**
     * Partner 전용 복호화 모듈
     *  - 암호화 : secureCryptPartner(true,  "1234")                     ==> [IhdL8XoEoYfBQHdCsQzLFQ==]
     *  - 복호화 : secureCryptPartner(false, "IhdL8XoEoYfBQHdCsQzLFQ==") ==> [1234]
     *
     * @param isEncrypt
     * @param val
     * @return
     * @throws Exception
     */
    public static String secureCryptPartner(boolean isEncrypt, String val) throws Exception{
        String crypted = null;

        if(!StringUtils.isEmpty(val)) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();

            byte[] keyB = getKey("PARTNER_256").getBytes();
            //byte[] keyB  = Hex.decodeHex( getKey("PARTNER_256").toCharArray());
            // Hex String -> byte[] 변환
            //byte[] ivB  = Hex.decodeHex( getIv("PARTNER_256").toCharArray());
            byte[] ivB  = getIv("PARTNER_256").getBytes();
            if( logger.isDebugEnabled() ){
                logger.debug("=================================");
                logger.debug("keyB : " + keyB);
                logger.debug("ivB : " + ivB);
                logger.debug("=================================");
            }

            if (isEncrypt) {
                // 암호화 - Base64 String 결과 반환
                crypted = aes256CryptoService.encrypt(keyB, ivB, val);
            } else {
                // 복호화
                crypted = aes256CryptoService.decrypt(keyB, ivB, val);
            }
        } else {
            crypted = val;
        }

        return crypted;
    }

    /**
     * Key 조회
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String getKey(String str){
        String result = "";
        try {
            result = PropertiesUtil.getValue(PREPIX + str +PROP_KEY_VALUE);
        } catch (Exception e) {
            logger.error(MessageUtil.getErrorLog(e.getStackTrace()));
        }
        return result;
    }
    /**
     * Iv 조회
     *
     * @param str
     * @return
     * @throws Exception
     */
    public static String getIv(String str){
        String result = "";
        try {
            result = PropertiesUtil.getValue(PREPIX + str +PROP_IV_VALUE);
        } catch (Exception e) {
            logger.error(MessageUtil.getErrorLog(e.getStackTrace()));
        }
        return result;
    }

    private static SecretKey generateKey(String keyValue) throws Exception {
        return new SecretKeySpec(keyValue.getBytes("UTF-8"), "AES");
    }

    @SuppressWarnings("unused")
    private String getTimestamp() {
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);
        Date currentTime = new Date();
        String mTime = sDateFormat.format(currentTime);
        return mTime;
    }

    /**
     * AES256 암호화 처리 되어있는지 확인후 암호화 처리가 되어있으면 그대로 반환 암호화 처리가 되어 있지 않으면 암호화 처리후 반환
     *
     * @param val
     * @return
     */
    public static String getIsEncryptAES256(String val){

        String result = "";
        if(!StringUtils.isBlank(val)){
            try {
                SecureUtils.decryptAES256(val);
                result = val;
            } catch (Exception e) {
                try {
                    result = SecureUtils.encryptAES256(val);
                } catch (Exception e1) {
                    if( logger.isDebugEnabled() ){
                        logger.error("암호화 에러");
                    }
                }
            }
        }
        return result;
    }

    /**
     * AES256 암호화 처리 되어있는지 확인
     *
     * @param val
     * @return
     */
    public static boolean isEncryptAES256(String val){
        boolean result = false;
        if(!StringUtils.isBlank(val)){
            try {
                SecureUtils.decryptAES256(val);
                result = true;
            } catch (Exception e) {
                result = false;
            }
        }
        return result;
    }

    public static void checkSecurity(PlatformData platformData) throws SecurityException {

        VariableList variableList = platformData.getVariableList();
        int size = variableList.size();
        for(int i=0; i<size; i++) {
            Variable variable = variableList.get(i);
            checkSecurity(variable);
        }


        DataSetList dataSetList = platformData.getDataSetList();
        size = dataSetList.size();
        for(int i=0; i<size; i++) {
            DataSet ds = dataSetList.get(i);
            checkSecurity(ds);
        }

    }

    public static void checkSecurity(Variable variable) throws SecurityException {

        String value = null;
        try {
            value = variable.getString();
        } catch(Exception e) {
            // ignore
            return;
        }

        checkPathTraversal(value);
        // convert xss
        String convertedValue = convertXSS(value);
        if(value != null && !value.equals(convertedValue)) {
            variable.set(convertedValue);
        }

    }

    public static void checkSecurity(DataSet ds) throws SecurityException {

        int rowCount = ds.getRowCount();
        int colCount = ds.getColumnCount();
        for(int rowIndex=0; rowIndex<rowCount; rowIndex++) {
            checckSecurityRoop1(ds, colCount, rowIndex);
        } // end data

        int removedCount = ds.getRemovedRowCount();
        for(int removedIndex=0; removedIndex<removedCount; removedIndex++) {
            checkSecurityRoop2(ds, colCount, removedIndex);
        } // end removed data

    }

    /**
     * Statements
     *
     * @param ds
     * @param colCount
     * @param removedIndex
     */
    private static void checkSecurityRoop2(DataSet ds, int colCount, int removedIndex) {
        for(int colIndex=0; colIndex<colCount; colIndex++) {
            String value = null;
            try {
                value = ds.getRemovedStringData(removedIndex, colIndex);
            } catch(Exception e) {
                // ignore
                continue;
            }

            checkPathTraversal(value);
            // convert xss
            String convertedValue = convertXSS(value);

            if(value != null && !value.equals(convertedValue)) {
                ds.setRemovedData(removedIndex, colIndex, convertedValue);
            }
        }
    }

    /**
     * Statements
     *
     * @param ds
     * @param colCount
     * @param rowIndex
     */
    private static void checckSecurityRoop1(DataSet ds, int colCount, int rowIndex) {
        boolean hasSavedRow = ds.hasSavedRow(rowIndex);
        for(int colIndex=0; colIndex<colCount; colIndex++) {

            String value = ds.getString(rowIndex, colIndex);
            checkPathTraversal(value);
            // convert xss
            String convertedValue = convertXSS(value);
            if(value != null && !value.equals(convertedValue)) {
                ds.set(rowIndex, colIndex, convertedValue);
            }
            // saved data..
            if(hasSavedRow) {
                value = ds.getSavedStringData(rowIndex, colIndex);
                checkPathTraversal(value);
                // convert xss
                convertedValue = convertXSS(value);
                if(value != null && !value.equals(convertedValue)) {
                    ds.setSavedData(rowIndex, colIndex, convertedValue);
                }
            }

        }
    }

    public static void checkUploadFileExt(String fileName) throws SecurityException {

        if(fileName == null) {
            return;
        }

        // Map securityResult = null;
        Map<String, String> securityResult = null;

        // check file extention
        securityResult = WebSecurityUtil.uploadFileExtCheck(fileName, "uploadExt");
        if ("true".equals(securityResult.get("result"))) {
          throw new SecurityException("Web Security Violation " + (securityResult.get("securitySort")) + ", Violation Char:: ' " + (securityResult.get("violationChar")) + "'");
        }

        // check file upload detour
        securityResult = WebSecurityUtil.uploadFileExtCheck(fileName, "uploadDetour");
        if ("true".equals(securityResult.get("result"))) {
          throw new SecurityException("Web Security Violation : " + (securityResult.get("securitySort")) + ", Violation Char:: ' " + (securityResult.get("violationChar")) + "'");
        }

    }

    public static void checkPathTraversal(String value) throws SecurityException {

        if(value == null) {
            return;
        }

        // check path traversal attack..
        Map<String, String> securityResult = null;
        try {
            securityResult = WebSecurityUtil.checkDownloadParams(value);
        } catch (UnsupportedEncodingException e) {
            // logging..


            throw new SecurityException("encoding format does not support. value="+value, e);
        }

        if ("true".equals(securityResult.get("result"))) {
            // logging..

            throw new SecurityException("Web Security Violation :  " + (securityResult.get("securitySort"))
                    + ", Violation Char:: ' " + (securityResult.get("violationChar")) + "'");
        }
    }

    public static String convertXSS(String value) {
        if(value == null) {
            return null;
        }
        String convertedValue = StringUtil.replaceStripXSS(value);
        return convertedValue;
    }


    //2019.05.28 choi.sh HVOC 암복호화 시작 추가
    public static String encryptHVocUrlAES(String param, String sKey, String sIv) throws Exception {
        return encryptHVocUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey(sKey), getIv(sIv));
    }

    public static String encryptHVocUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = null;
        try {
            SecretKey key = generateKey(keyValue);
            Cipher cipher = Cipher.getInstance(transType);
            if(transType.equals(SecureConstants.AES_ECB_PKCS5PADDING)){
                //ECB모드는 ivKey 사용없음
                cipher.init(Cipher.ENCRYPT_MODE, key);
            } else {
                //CBC모드는 ivKey 사용
                if(null != ivValue && ivValue.length() > 0){
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
                } else {
                    cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(new byte[16]));
                }
            }
            byte[] encData  = cipher.doFinal(srcData.getBytes());
            //result = com.mobis.maps.cmmn.secure.Base64.encodeToString(encData);
            result = byteArrayToHexString(encData);

        } catch(Exception e) {
            e.printStackTrace();
            result = "";
        }
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : {}" , srcData);
            logger.debug("암호화 : {}" ,result);
        }
        return result;
    }

    public static String decryptHVocUrlAES(String param, String sKey, String sIv) throws Exception {
        return decryptHVocUrl(SecureConstants.AES_CBC_PKCS5PADDING, param, getKey(sKey), getIv(sIv));
    }

    public static String decryptHVocUrl(String transType, String srcData, String keyValue, String ivValue) throws Exception {
        String result = "";

        try {
            SecretKey key = generateKey(keyValue);

            Cipher cipher = Cipher.getInstance(transType);


            if ( null!=ivValue && ivValue.length()>0 ) {
                cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(ivValue.getBytes()));
            } else {
                cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(new byte[16]));
            }


            byte[] decData = cipher.doFinal(hexStringToByteArray(srcData));

            result = new String(decData);
        } catch (Exception e) {
            //System.out.println(e.getMessage());
            result = "";
        }
        if( logger.isDebugEnabled() ){
            logger.debug("원문 : {}" , srcData);
            logger.debug("복호화 : {}" ,result);
        }
        return result;
    }
    //2019.05.28 choi.sh HVOC 암복호화 종료 추가

    public static String encryptQVOC(String str,String type) throws Exception {
        String encrypted = null;

        String privateKey = null;
        String ivKey = null;
        if("QVOC1".equals(type)) {
            privateKey = PropertiesUtil.getValue("KEY_QVOC_CALL_AES256_KEY_VALUE");
            ivKey = PropertiesUtil.getValue("KEY_QVOC_CALL_AES256_IV_VALUE");
        } else if("QVOC2".equals(type)) {
            privateKey = PropertiesUtil.getValue("KEY_QVOC_AES256_KEY_VALUE");
            ivKey = PropertiesUtil.getValue("KEY_QVOC_AES256_IV_VALUE");
        }

        if(!StringUtils.isEmpty(str)) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();

            // Hex String -> byte[] 변환
            byte[] keyB = privateKey.getBytes("UTF8");
            byte[] ivB = ivKey.getBytes("UTF8");
            // 암호화 - Base64 String 결과 반환
            encrypted = aes256CryptoService.encrypt(keyB, ivB, str);

            encrypted = org.apache.commons.codec.binary.Base64.encodeBase64String(encrypted.getBytes("UTF8"));
            if( logger.isDebugEnabled() ){
                logger.debug("원문 : {}" , str);
                logger.debug("암호화 : {}" ,encrypted);
            }
        } else {
            encrypted =  str;
        }

        return encrypted;
    }

    public static String decryptQVOC(String str,String type) throws Exception {
        String decrypted = null;
        String privateKey = null;
        if("QVOC1".equals(type)) {
            privateKey = PropertiesUtil.getValue("KEY_QVOC_CALL_AES256_VALUE");
        } else if("QVOC2".equals(type)) {
            privateKey = PropertiesUtil.getValue("KEY_QVOC_AES256_VALUE");
        }

        String decodStr = str;
        if("QVOC2".equals(type)) {
            decodStr = new String(org.apache.commons.codec.binary.Base64.decodeBase64(str));
            logger.debug("QVOC2 decodStr : " + decodStr);
        }

        if (!StringUtils.isEmpty(decodStr)) {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();

            // Base64 String -> byte[] 변환
            byte[] keyB = privateKey.getBytes("UTF8");
            byte[] ivB = privateKey.substring(0, 16).getBytes("UTF8");

            // 복호화
            decrypted = aes256CryptoService.decrypt(keyB, ivB, decodStr);

        } else {
            decrypted =  decodStr;
        }

        return decrypted;
    }
    
    public static String getTmprPwd(int length) throws Exception {
        
        String uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowercase = "abcdefghijklmnopqrstuvwxyz";
        String symbols = uppercase + lowercase;
        
        Random random = SecureRandom.getInstanceStrong();    // as of JDK 8, this should return the strongest algorithm available to the JVM
        StringBuilder sbTmprPwd = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int idx = random.nextInt(symbols.length());
            sbTmprPwd.append(symbols.substring(idx, idx + 1));
        }
        return sbTmprPwd.toString();
    }
    
    /* maps portalsso용 암호화 방법 소스 받음 20200916 */
    private static final String KEYFORMAPSSSSO = "M0bisSecurity12#M0bisSecurity12#";
    public static final byte[] IV_BYTE_FOR_MAPSSSO = new byte[16];
    
    /**
     * mapssso용 암호화 encrypt
     *
     * @param str
     * @return
     * @throws UnsupportedEncodingException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public static String encryptAES256ForMapsSso(String str)
      throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        byte[] textBytes = str.getBytes("UTF-8");
        AlgorithmParameterSpec ivSpec = new IvParameterSpec(IV_BYTE_FOR_MAPSSSO);
        SecretKeySpec newKey = new SecretKeySpec(KEYFORMAPSSSSO.getBytes("UTF-8"), "AES");
        Cipher cipher = null;
        cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(1, newKey, ivSpec);
        return org.apache.commons.codec.binary.Base64.encodeBase64String(cipher.doFinal(textBytes));
    }
    /**
     * mapssso용 암호화 decrypt
     *
     * @param str
     * @return
     * @throws UnsupportedEncodingException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public static String decryptAES256ForMapsSso(String str) throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
        byte[] textBytes = org.apache.commons.codec.binary.Base64.decodeBase64(str);
        AlgorithmParameterSpec ivSpec = new IvParameterSpec(IV_BYTE_FOR_MAPSSSO);
        SecretKeySpec newKey = new SecretKeySpec(KEYFORMAPSSSSO.getBytes("UTF-8"), "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(2, newKey, ivSpec);
        return new String(cipher.doFinal(textBytes), "UTF-8");
    }
    
}
