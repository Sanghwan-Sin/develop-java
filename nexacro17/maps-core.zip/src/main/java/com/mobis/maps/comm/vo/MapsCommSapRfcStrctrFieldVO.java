package com.mobis.maps.comm.vo;

import org.hibernate.validator.constraints.NotBlank;

/**
 * <pre>
 * RFC구조체필드정보 항목
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcStrctrFieldVO.java
 * @Description : RFC구조체필드정보 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 23.     Sin Sanghwan       최초 생성
 * </pre>
 */

public class MapsCommSapRfcStrctrFieldVO extends PgBascVO {
    /** RFC아이디 */
    private String rfcId;
    /** 구조체아이디 */
    @NotBlank(message="EC00000001|STRCTR_ID")
    private String strctrId;
    /** 구조체명 */
    private String strctrNm;
    /** RFC필드 */
    @NotBlank(message="EC00000001|RFC_FIELD")
    private String rfcField;
    /** 항목ID */
    private String iemId;
    /** 용어ID */
    private String wordId;
    /** RFC필드명 */
    @NotBlank(message="EC00000001|RFC_FIELD_NM")
    private String rfcFieldNm;
    /** 데이터타입 */
    @NotBlank(message="EC00000001|DATA_TY")
    private String dataTy;
    /** RFC필드설명 */
    private String rfcFieldDc;
    /** 사용여부 */
    @NotBlank(message="EC00000001|USE_YN")
    private String useYn;
    /** 삭제여부 */
    @NotBlank(message="EC00000001|DEL_YN")
    private String delYn;
    /** 용어명 */
    private String wordNm;

    /**
     * @return the rfcId
     */
    public String getRfcId() {
        return rfcId;
    }
    /**
     * @param rfcId the rfcId to set
     */
    public void setRfcId(String rfcId) {
        this.rfcId = rfcId;
    }
    /**
     * @return the strctrId
     */
    public String getStrctrId() {
        return strctrId;
    }
    /**
     * @param strctrId the strctrId to set
     */
    public void setStrctrId(String strctrId) {
        this.strctrId = strctrId;
    }
    /**
     * @return the strctrNm
     */
    public String getStrctrNm() {
        return strctrNm;
    }
    /**
     * @param strctrNm the strctrNm to set
     */
    public void setStrctrNm(String strctrNm) {
        this.strctrNm = strctrNm;
    }
    /**
     * @return the rfcField
     */
    public String getRfcField() {
        return rfcField;
    }
    /**
     * @param rfcField the rfcField to set
     */
    public void setRfcField(String rfcField) {
        this.rfcField = rfcField;
    }
    /**
     * @return the iemId
     */
    public String getIemId() {
        return iemId;
    }
    /**
     * @param iemId the iemId to set
     */
    public void setIemId(String iemId) {
        this.iemId = iemId;
    }
    /**
     * @return the wordId
     */
    public String getWordId() {
        return wordId;
    }
    /**
     * @param wordId the wordId to set
     */
    public void setWordId(String wordId) {
        this.wordId = wordId;
    }
    /**
     * @return the rfcFieldNm
     */
    public String getRfcFieldNm() {
        return rfcFieldNm;
    }
    /**
     * @param rfcFieldNm the rfcFieldNm to set
     */
    public void setRfcFieldNm(String rfcFieldNm) {
        this.rfcFieldNm = rfcFieldNm;
    }
    /**
     * @return the dataTy
     */
    public String getDataTy() {
        return dataTy;
    }
    /**
     * @param dataTy the dataTy to set
     */
    public void setDataTy(String dataTy) {
        this.dataTy = dataTy;
    }
    /**
     * @return the rfcFieldDc
     */
    public String getRfcFieldDc() {
        return rfcFieldDc;
    }
    /**
     * @param rfcFieldDc the rfcFieldDc to set
     */
    public void setRfcFieldDc(String rfcFieldDc) {
        this.rfcFieldDc = rfcFieldDc;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }
    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    /**
     * @return the wordNm
     */
    public String getWordNm() {
        return wordNm;
    }
    /**
     * @param wordNm the wordNm to set
     */
    public void setWordNm(String wordNm) {
        this.wordNm = wordNm;
    }
}
