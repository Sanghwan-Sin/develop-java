package com.mobis.maps.iam.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamUserLoginStatsService;
import com.mobis.maps.iam.vo.MapsIamUserLoginStatsVO;

/**
 * <pre>
 * 사용자 로그인 통계 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamUserLoginStatsController.java
 * @Description : 사용자 로그인 통계에 대한 컨트롤러를 정의.
 * @author DT048058
 * @since 2020. 5. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 7.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamUserLoginStatsController extends HController {
    
    @Resource(name = "mapsIamUserLoginStatsService")
    private MapsIamUserLoginStatsService mapsIamUserLoginStatsService;

    /**
     * 사용자 로그인 통계 메인 리스트 조회
     *
     * @param iamUserLoginStatsVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserLoginStatsMainList.do")
    public NexacroResult selectUserLoginStatsMainList(
            @ParamDataSet(name="dsInput") MapsIamUserLoginStatsVO iamUserLoginStatsVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserLoginStatsVO> userLoginStatsMains = mapsIamUserLoginStatsService.selectUserLoginStatsMainList(iamUserLoginStatsVO, loginInfo);
                
        result.addDataSet("dsOutput", userLoginStatsMains);        
        
        return result;
    }

    /**
     * 사용자 로그인 통계 상세 리스트 조회
     *
     * @param iamUserLoginStatsVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserLoginStatsDetailList.do")
    public NexacroResult selectUserLoginStatsDetailList(
            @ParamDataSet(name="dsInput") MapsIamUserLoginStatsVO iamUserLoginStatsVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserLoginStatsVO> userLoginStatsDetails = mapsIamUserLoginStatsService.selectUserLoginStatsDetailList(iamUserLoginStatsVO, loginInfo);
                
        result.addDataSet("dsOutput", userLoginStatsDetails);        
        
        return result;
    }
}
