package com.mobis.maps.sapjco.manager;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : Field.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 5. 8.     DT045877     	최초 생성
 * </pre>
 */
public @interface Field {
    String value();
}