package com.mobis.maps.comm.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.service.HService;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.FileUploadUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.JCoMetaDataType;
import com.mobis.maps.comm.constants.RfcDataTy;
import com.mobis.maps.comm.constants.RfcIpttSe;
import com.mobis.maps.comm.constants.RfcJCoDest;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.comm.service.MapsCommSapRfcService;
import com.mobis.maps.comm.service.dao.MapsCommSapRfcMDAO;
import com.mobis.maps.comm.util.MapsCommSapRfcExcelParserUtil;
import com.mobis.maps.comm.vo.MapsCommSapDestConectInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapDestInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcBassInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIpttInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrFieldVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrMstVO;
import com.mobis.maps.sapjco.manager.Destination;
import com.mobis.maps.sapjco.manager.FunctionTemplate;
import com.nexacro17.xapi.data.DataSet;
import com.sap.conn.jco.JCoListMetaData;
import com.sap.conn.jco.JCoRecordMetaData;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.monitor.JCoConnectionData;
import com.sap.conn.jco.monitor.JCoDestinationMonitor;

/**
 * <pre>
 * RFC 관리 서비스구현
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcServiceImpl.java
 * @Description : RFC 관리 서비스를 구현
 * @author Sin Sanghwan
 * @since 2019. 10. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 14.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Service("mapsCommSapRfcService")
public class MapsCommSapRfcServiceImpl extends HService implements MapsCommSapRfcService {
    
    //@Resource(name = "destinationManager")
    //private DestinationManager destinationManager;

    @Resource(name = "mapsCommFileService")
    private MapsCommFileService mapsCommFileService;

    @Resource(name = "mapsCommSapRfcMDAO")
    private MapsCommSapRfcMDAO mapsCommSapRfcMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#selectSapRfcMetaDataInfo(com.mobis.maps.comm.vo.MapsCommSapRfcBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapRfcInfoVO selectSapRfcMetaDataInfo(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO, LoginInfoVO loginInfo) throws Exception {

        /* RFC호출정보 취득 */
        RfcSapSys rfcSapSys = RfcSapSys.get(commSapRfcBassInfoVO.getSysId());
        RfcJCoDest rfcJCoDest = RfcJCoDest.get(rfcSapSys, loginInfo.getRfcServerLang());
        Destination destination = rfcJCoDest.getDestination();

        /* RFC정보 초기화 */
        // RFC입출력정보
        List<MapsCommSapRfcBassInfoVO> sapRfcBassInfos = new ArrayList<MapsCommSapRfcBassInfoVO>();
        sapRfcBassInfos.add(commSapRfcBassInfoVO);
        // RFC입출력정보
        List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos = new ArrayList<MapsCommSapRfcIpttInfoVO>();
        // RFC구조체기본정보
        List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos = new ArrayList<MapsCommSapRfcStrctrMstVO>();
        // RFC구조체필드정보
        List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos = new ArrayList<MapsCommSapRfcStrctrFieldVO>();
        // RFC정보 초기화 셋팅
        MapsCommSapRfcInfoVO sapRfcInfoVO = new MapsCommSapRfcInfoVO();
        sapRfcInfoVO.setSapRfcBassInfos(sapRfcBassInfos);
        sapRfcInfoVO.setSapRfcIpttInfos(sapRfcIpttInfos);
        sapRfcInfoVO.setSapRfcStrctrInfos(sapRfcStrctrInfos);
        sapRfcInfoVO.setSapRfcStrctrFieldInfos(sapRfcStrctrFieldInfos);

        /* RFC Meta Data 정보 취득 */
        String sysId = commSapRfcBassInfoVO.getSysId(); // SYSTEM ID
        String rfcId = commSapRfcBassInfoVO.getRfcId(); // RFC ID
        // 구조체중복체크 Map
        Map<String, String> mStrctr = new HashMap<String, String>();
        //Import Meta Data 정보 취득
        selectImportJCoListMetaData(sapRfcInfoVO, destination, sysId, rfcId, mStrctr);
        //Export Meta Data 정보 취득
        selectExportJCoListMetaData(sapRfcInfoVO, destination, sysId, rfcId, mStrctr);
        //Table Meta Data 정보 취득
        selectTableJCoListMetaData(sapRfcInfoVO, destination, sysId, rfcId, mStrctr);
        
        return sapRfcInfoVO;
    }
    
    /**
     * Import Meta Data 정보 취득
     *
     * @param commSapRfcInfoVO
     * @param destination
     * @param sysId
     * @param rfcId
     * @param mStrctr
     * @throws Exception
     */
    private void selectImportJCoListMetaData(MapsCommSapRfcInfoVO commSapRfcInfoVO, Destination destination, String sysId, String rfcId, Map<String, String> mStrctr) throws Exception {

        FunctionTemplate functionTemplate = destination.getFunctionTemplate(rfcId);
        
        JCoListMetaData iParamList = functionTemplate.getImportParameterList();

        if (iParamList != null) {
            for (int i = 0; i < iParamList.getFieldCount(); i++) {
                
                String rfcField = iParamList.getName(i);
                
                if (MapsCommSapRfcService.RFC_FIELD_ID_IS_IFCOMM.equals(rfcField)) {
                    continue;
                }
    
                MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO = selectJCoListMetaData(sysId, rfcId, iParamList, i);
                commSapRfcInfoVO.getSapRfcIpttInfos().add(commSapRfcIpttInfoVO);
                
                String strctrId = iParamList.getRecordTypeName(i);
                String strctrNm = iParamList.getDescription(i);
                boolean isTable = iParamList.isTable(i);
                boolean isStructure = iParamList.isStructure(i);
                
                if ((isStructure || isTable) && (mStrctr.get(strctrId) == null)) {
                    
                    MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO = selectSapRfcStrctrMstVO(strctrId, strctrNm);
                    MapsCommSapRfcStrctrMstVO tempCommSapRfcStrctrMstVO = mapsCommSapRfcMDAO.selectSapRfcStrctrMst(commSapRfcStrctrMstVO);
                    if (tempCommSapRfcStrctrMstVO != null) {
                        commSapRfcIpttInfoVO.setStrctrExstYn("Y");
    
                        tempCommSapRfcStrctrMstVO.setRnum(commSapRfcInfoVO.getSapRfcStrctrInfos().size() + 1);
                        commSapRfcInfoVO.getSapRfcStrctrInfos().add(tempCommSapRfcStrctrMstVO);
                        
                        MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO = new MapsCommSapRfcStrctrFieldVO();
                        commSapRfcStrctrFieldVO.setStrctrId(tempCommSapRfcStrctrMstVO.getStrctrId());
                        commSapRfcInfoVO.getSapRfcStrctrFieldInfos().addAll(mapsCommSapRfcMDAO.selectSapRfcStrctrFieldList(commSapRfcStrctrFieldVO));
                    } else {
                        commSapRfcIpttInfoVO.setStrctrExstYn("N");
    
                        commSapRfcInfoVO.getSapRfcStrctrInfos().add(commSapRfcStrctrMstVO);
    
                        if (isStructure) {
                            JCoStructure structure = functionTemplate.getFunction().getImportStructure(rfcField);
                            commSapRfcInfoVO.getSapRfcStrctrFieldInfos().addAll(selectJCoStructure(rfcId, strctrId, structure));
                        } else if (isTable) {
                            JCoTable table = functionTemplate.getFunction().getImportParameterList().getTable(rfcField);
                            commSapRfcInfoVO.getSapRfcStrctrFieldInfos().addAll(selectJCoTable(rfcId, strctrId, table));
                        }
                    }
                    mStrctr.put(strctrId, strctrNm);
                }
            }
        }
    }
    
    /**
     * Export Meta Data 정보 취득
     *
     * @param commSapRfcInfoVO
     * @param destination
     * @param sysId
     * @param rfcId
     * @param mStrctr
     * @throws Exception
     */
    private void selectExportJCoListMetaData(MapsCommSapRfcInfoVO commSapRfcInfoVO, Destination destination, String sysId, String rfcId, Map<String, String> mStrctr) throws Exception {

        FunctionTemplate functionTemplate = destination.getFunctionTemplate(rfcId);

        JCoListMetaData eParamList = functionTemplate.getExportParameterList();
        
        if (eParamList != null) {
            for (int i = 0; i < eParamList.getFieldCount(); i++) {
                
                String rfcField = eParamList.getName(i);
                
                if (MapsCommSapRfcService.RFC_FIELD_ID_ES_RETURN.equals(rfcField)) {
                    continue;
                }
    
                MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO = selectJCoListMetaData(sysId, rfcId, eParamList, i);
                commSapRfcInfoVO.getSapRfcIpttInfos().add(commSapRfcIpttInfoVO);
    
                String strctrId = eParamList.getRecordTypeName(i);
                String strctrNm = eParamList.getDescription(i);
                boolean isTable = eParamList.isTable(i);
                boolean isStructure = eParamList.isStructure(i);
    
                if ((isStructure || isTable) && (mStrctr.get(strctrId) == null)) {
                    
                    MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO = selectSapRfcStrctrMstVO(strctrId, strctrNm);
                    MapsCommSapRfcStrctrMstVO tempCommSapRfcStrctrMstVO = mapsCommSapRfcMDAO.selectSapRfcStrctrMst(commSapRfcStrctrMstVO);
                    if (tempCommSapRfcStrctrMstVO != null) {
                        commSapRfcIpttInfoVO.setStrctrExstYn("Y");
    
                        tempCommSapRfcStrctrMstVO.setRnum(commSapRfcInfoVO.getSapRfcStrctrInfos().size() + 1);
                        commSapRfcInfoVO.getSapRfcStrctrInfos().add(tempCommSapRfcStrctrMstVO);
                        
                        MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO = new MapsCommSapRfcStrctrFieldVO();
                        commSapRfcStrctrFieldVO.setStrctrId(tempCommSapRfcStrctrMstVO.getStrctrId());
                        commSapRfcInfoVO.getSapRfcStrctrFieldInfos().addAll(mapsCommSapRfcMDAO.selectSapRfcStrctrFieldList(commSapRfcStrctrFieldVO));
                    } else {
                        commSapRfcIpttInfoVO.setStrctrExstYn("N");
    
                        commSapRfcInfoVO.getSapRfcStrctrInfos().add(commSapRfcStrctrMstVO);
    
                        if (isStructure) {
                            JCoStructure structure = functionTemplate.getFunctionResult().getExportStructure(rfcField);
                            commSapRfcInfoVO.getSapRfcStrctrFieldInfos().addAll(selectJCoStructure(rfcId, strctrId, structure));
                        } else if (isTable) {
                            JCoTable table = functionTemplate.getFunctionResult().getJCoTable(rfcField);
                            commSapRfcInfoVO.getSapRfcStrctrFieldInfos().addAll(selectJCoTable(rfcId, strctrId, table));
                        }
                    }
                    mStrctr.put(strctrId, strctrNm);
                }
            }
        }
    }
    
    /**
     * Table Meta Data 정보 취득
     *
     * @param commSapRfcInfoVO
     * @param destination
     * @param sysId
     * @param rfcId
     * @param mStrctr
     * @throws Exception
     */
    private void selectTableJCoListMetaData(MapsCommSapRfcInfoVO commSapRfcInfoVO, Destination destination, String sysId, String rfcId, Map<String, String> mStrctr) throws Exception {

        FunctionTemplate functionTemplate = destination.getFunctionTemplate(rfcId);

        JCoListMetaData tParamList = functionTemplate.getTableParameterList();
        
        if (tParamList != null) {
            for (int i = 0; i < tParamList.getFieldCount(); i++) {
                
                String rfcField = tParamList.getName(i);
                
                MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO = selectJCoListMetaData(sysId, rfcId, tParamList, i);
                commSapRfcInfoVO.getSapRfcIpttInfos().add(commSapRfcIpttInfoVO);
    
                String strctrId = tParamList.getRecordTypeName(i);
                String strctrNm = tParamList.getDescription(i);
                boolean isTable = tParamList.isTable(i);
                boolean isStructure = tParamList.isStructure(i);
    
                if ((isStructure || isTable) && (mStrctr.get(strctrId) == null)) {
                    
                    MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO = selectSapRfcStrctrMstVO(strctrId, strctrNm);
                    MapsCommSapRfcStrctrMstVO tempCommSapRfcStrctrMstVO = mapsCommSapRfcMDAO.selectSapRfcStrctrMst(commSapRfcStrctrMstVO);
                    if (tempCommSapRfcStrctrMstVO != null) {
                        commSapRfcIpttInfoVO.setStrctrExstYn("Y");
                        
                        tempCommSapRfcStrctrMstVO.setRnum(commSapRfcInfoVO.getSapRfcStrctrInfos().size() + 1);
                        commSapRfcInfoVO.getSapRfcStrctrInfos().add(tempCommSapRfcStrctrMstVO);
                        
                        MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO = new MapsCommSapRfcStrctrFieldVO();
                        commSapRfcStrctrFieldVO.setStrctrId(tempCommSapRfcStrctrMstVO.getStrctrId());
                        commSapRfcInfoVO.getSapRfcStrctrFieldInfos().addAll(mapsCommSapRfcMDAO.selectSapRfcStrctrFieldList(commSapRfcStrctrFieldVO));
                    } else {
                        commSapRfcIpttInfoVO.setStrctrExstYn("N");
    
                        commSapRfcInfoVO.getSapRfcStrctrInfos().add(commSapRfcStrctrMstVO);
    
                        if (isStructure) {
                            JCoStructure structure = functionTemplate.getFunctionResult().getExportStructure(rfcField);
                            commSapRfcInfoVO.getSapRfcStrctrFieldInfos().addAll(selectJCoStructure(rfcId, strctrId, structure));
                        } else if (isTable) {
                            JCoTable table = functionTemplate.getFunctionResult().getJCoTable(rfcField);
                            commSapRfcInfoVO.getSapRfcStrctrFieldInfos().addAll(selectJCoTable(rfcId, strctrId, table));
                        }
                    }
                    mStrctr.put(strctrId, strctrNm);
                }
            }
            
        }
    }

    /**
     * RFC 입출력정보 생성
     *
     * @param sysId
     * @param rfcId
     * @param jCoListMetaData
     * @param filedIdx
     * @return
     * @throws MapsBizException 
     */
    private MapsCommSapRfcIpttInfoVO selectJCoListMetaData(String sysId, String rfcId, JCoListMetaData jCoListMetaData, int filedIdx) throws MapsBizException {

        String rfcField = jCoListMetaData.getName(filedIdx);
        boolean isImport = jCoListMetaData.isImport(filedIdx);
        boolean isExport = jCoListMetaData.isExport(filedIdx);
        String dataType = jCoListMetaData.getTypeAsString(filedIdx);
        String rfcFieldDc = jCoListMetaData.getDescription(filedIdx);
        boolean isTable = jCoListMetaData.isTable(filedIdx);
        boolean isStructure = jCoListMetaData.isStructure(filedIdx);
        String strctrId = jCoListMetaData.getRecordTypeName(filedIdx);
        String classNameOfField = jCoListMetaData.getClassNameOfField(filedIdx);
        if (logger.isDebugEnabled()) {
            StringBuilder sb = new StringBuilder();
            sb.append("→ " +sysId + "." + rfcId + "::" + rfcField);
            sb.append("[RecordFieldName=" + jCoListMetaData.getRecordFieldName(filedIdx) + "]");
            sb.append("[isImport=" + isImport + "]");
            sb.append("[isExport=" + isExport + "]");
            sb.append("[Type=" + jCoListMetaData.getType(filedIdx) + "]");
            sb.append("[TypeAsString=" + dataType + "]");
            sb.append("[ClassNameOfField=" + classNameOfField + "]");
            sb.append("[RecordTypeName=" + strctrId + "]");
            sb.append("[isTable=" + isTable + "]");
            sb.append("[isStructure=" + isStructure + "]");
            sb.append("[Description=" + rfcFieldDc + "]");
            logger.debug(sb.toString());
        }
        MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO = new MapsCommSapRfcIpttInfoVO();
        commSapRfcIpttInfoVO.setSysId(sysId);
        commSapRfcIpttInfoVO.setRfcId(rfcId);
        if (isImport) {
            commSapRfcIpttInfoVO.setRfcIpttSe(RfcIpttSe.Import.getCode());
        } else if (isExport) {
            commSapRfcIpttInfoVO.setRfcIpttSe(RfcIpttSe.Export.getCode());
        }
        commSapRfcIpttInfoVO.setRfcField(rfcField);
        commSapRfcIpttInfoVO.setRfcFieldNm(rfcFieldDc);
        if (isTable) {
            commSapRfcIpttInfoVO.setDataTy(RfcDataTy.List.getCode());
            commSapRfcIpttInfoVO.setStrctrId(strctrId);
        } else if (isStructure) {
            commSapRfcIpttInfoVO.setDataTy(RfcDataTy.Structure.getCode());
            commSapRfcIpttInfoVO.setStrctrId(strctrId);
        } else {
            JCoMetaDataType jCoMetaDataType = JCoMetaDataType.get(dataType, classNameOfField);
            RfcDataTy rfcDataTy = jCoMetaDataType.getRfcDataTy();
            commSapRfcIpttInfoVO.setDataTy(rfcDataTy.getCode());
        }
        commSapRfcIpttInfoVO.setRfcFieldDc(rfcFieldDc);
        commSapRfcIpttInfoVO.setUseYn("Y");
        commSapRfcIpttInfoVO.setDelYn("N");
        
        return commSapRfcIpttInfoVO;
    }
    
    /**
     * 구조체 필드 정보 생성
     *
     * @param rfcId
     * @param structureNm
     * @param structure
     * @return
     * @throws MapsBizException 
     */
    private List<MapsCommSapRfcStrctrFieldVO> selectJCoStructure(String rfcId, String structureNm, JCoStructure structure) throws MapsBizException {
        
        List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos = new ArrayList<MapsCommSapRfcStrctrFieldVO>();
        
        JCoRecordMetaData jCoRecordMetaData = structure.getRecordMetaData();
        for (int i = 0; i < jCoRecordMetaData.getFieldCount(); i++) {
            /* Table컬럼정보 취득 */
            String rfcField = jCoRecordMetaData.getName(i);
            String dataType = jCoRecordMetaData.getTypeAsString(i);
            boolean isTable = jCoRecordMetaData.isTable(i);
            boolean isStructure = jCoRecordMetaData.isStructure(i);
            String strctrId = jCoRecordMetaData.getRecordTypeName(i);
            String rfcFieldDc = jCoRecordMetaData.getDescription(i);
            String classNameOfField = jCoRecordMetaData.getClassNameOfField(i);
            if (logger.isDebugEnabled()) {
                StringBuilder sbLogger = new StringBuilder();
                sbLogger.append("→ " +rfcId + "::" + structureNm);
                sbLogger.append("[name=" + jCoRecordMetaData.getName(i) + "]");
                sbLogger.append("[Type=" + jCoRecordMetaData.getType(i) + "]");
                sbLogger.append("[TypeAsString=" + dataType + "]");
                sbLogger.append("[ClassNameOfField=" + classNameOfField + "]");
                sbLogger.append("[RecordTypeName=" + strctrId + "]");
                sbLogger.append("[isTable=" + isTable + "]");
                sbLogger.append("[isStructure=" + isStructure + "]");
                sbLogger.append("[Description=" + rfcFieldDc + "]");
                logger.debug(sbLogger.toString());
            }
            
            /* Table컬럼정보 취득 */
            MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO = new MapsCommSapRfcStrctrFieldVO();
            commSapRfcStrctrFieldVO.setRfcField(rfcId);
            commSapRfcStrctrFieldVO.setStrctrId(structureNm);
            commSapRfcStrctrFieldVO.setRfcField(rfcField);
            commSapRfcStrctrFieldVO.setRfcFieldNm(rfcFieldDc);
            if (isTable) {
                commSapRfcStrctrFieldVO.setDataTy(RfcDataTy.List.getCode());
                commSapRfcStrctrFieldVO.setStrctrId(strctrId);
            } else if (isStructure) {
                commSapRfcStrctrFieldVO.setDataTy(RfcDataTy.Structure.getCode());
                commSapRfcStrctrFieldVO.setStrctrId(strctrId);
            } else {
                JCoMetaDataType jCoMetaDataType = JCoMetaDataType.get(dataType, classNameOfField);
                RfcDataTy rfcDataTy = jCoMetaDataType.getRfcDataTy();
                commSapRfcStrctrFieldVO.setDataTy(rfcDataTy.getCode());
            }
            commSapRfcStrctrFieldVO.setRfcFieldDc(rfcFieldDc);
            commSapRfcStrctrFieldVO.setUseYn("Y");
            commSapRfcStrctrFieldVO.setDelYn("N");
            
            sapRfcStrctrFieldInfos.add(commSapRfcStrctrFieldVO);
        }
        
        return sapRfcStrctrFieldInfos;
    }
    
    /**
     * Table의 구조체 필드 정보 생성
     *
     * @param rfcId
     * @param tableNm
     * @param table
     * @return
     * @throws MapsBizException 
     */
    private List<MapsCommSapRfcStrctrFieldVO> selectJCoTable(String rfcId, String tableNm, JCoTable table) throws MapsBizException {
        
        List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos = new ArrayList<MapsCommSapRfcStrctrFieldVO>();
        
        JCoRecordMetaData jCoRecordMetaData = table.getRecordMetaData();
        for (int i = 0; i < jCoRecordMetaData.getFieldCount(); i++) {
            /* Table컬럼정보 취득 */
            String rfcField = jCoRecordMetaData.getName(i);
            String dataType = jCoRecordMetaData.getTypeAsString(i);
            boolean isTable = jCoRecordMetaData.isTable(i);
            boolean isStructure = jCoRecordMetaData.isStructure(i);
            String strctrId = jCoRecordMetaData.getRecordTypeName(i);
            String rfcFieldDc = jCoRecordMetaData.getDescription(i);
            String classNameOfField = jCoRecordMetaData.getClassNameOfField(i);
            if (logger.isDebugEnabled()) {
                StringBuilder sbLogger = new StringBuilder();
                sbLogger.append("→ " +rfcId + "::" + tableNm);
                sbLogger.append("[name=" + rfcField + "]");
                sbLogger.append("[Type=" + jCoRecordMetaData.getType(i) + "]");
                sbLogger.append("[TypeAsString=" + dataType + "]");
                sbLogger.append("[ClassNameOfField=" + classNameOfField + "]");
                sbLogger.append("[RecordTypeName=" + strctrId + "]");
                sbLogger.append("[isTable=" + isTable + "]");
                sbLogger.append("[isStructure=" + isStructure + "]");
                sbLogger.append("[Description=" + rfcFieldDc + "]");
                logger.debug(sbLogger.toString());
            }
            
            /* Table컬럼정보 취득 */
            MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO = new MapsCommSapRfcStrctrFieldVO();
            commSapRfcStrctrFieldVO.setRfcField(rfcId);
            commSapRfcStrctrFieldVO.setStrctrId(tableNm);
            commSapRfcStrctrFieldVO.setRfcField(rfcField);
            commSapRfcStrctrFieldVO.setRfcFieldNm(rfcFieldDc);
            if (isTable) {
                commSapRfcStrctrFieldVO.setDataTy(RfcDataTy.List.getCode());
                commSapRfcStrctrFieldVO.setStrctrId(strctrId);
            } else if (isStructure) {
                commSapRfcStrctrFieldVO.setDataTy(RfcDataTy.Structure.getCode());
                commSapRfcStrctrFieldVO.setStrctrId(strctrId);
            } else {
                JCoMetaDataType jCoMetaDataType = JCoMetaDataType.get(dataType, classNameOfField);
                RfcDataTy rfcDataTy = jCoMetaDataType.getRfcDataTy();
                commSapRfcStrctrFieldVO.setDataTy(rfcDataTy.getCode());
            }
            commSapRfcStrctrFieldVO.setRfcFieldDc(rfcFieldDc);
            commSapRfcStrctrFieldVO.setUseYn("Y");
            commSapRfcStrctrFieldVO.setDelYn("N");
            
            sapRfcStrctrFieldInfos.add(commSapRfcStrctrFieldVO);
        }
        
        return sapRfcStrctrFieldInfos;
    }
    
    /**
     * RFC 구조체 마스터정보 생성
     *
     * @param strctrId
     * @param strctrNm
     * @return
     */
    private MapsCommSapRfcStrctrMstVO selectSapRfcStrctrMstVO(String strctrId, String strctrNm) {
        
        MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO = new MapsCommSapRfcStrctrMstVO();
        commSapRfcStrctrMstVO.setStrctrId(strctrId);
        commSapRfcStrctrMstVO.setStrctrNm(strctrNm);
        
        return commSapRfcStrctrMstVO;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#selectSapRfcInfoFileUpload(java.lang.String, javax.servlet.http.HttpServletRequest, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapRfcInfoVO selectSapRfcInfoFileUpload(String sysId, HttpServletRequest request, LoginInfoVO loginInfo) throws Exception {

        MapsCommSapRfcInfoVO sapRfcInfoVO = null;

        File fUp = null;
        try {

            fUp = mapsCommFileService.selectFileUpload(request);
            //logger.debug("→ selectSapRfcInfoFileUpload.fUp[path=" + fUp.getPath() + "]");

            sapRfcInfoVO = MapsCommSapRfcExcelParserUtil.setRfcInfo(sysId, fUp);

        } finally {
            if (fUp != null) {
                FileUploadUtil.removeFile(fUp);
            }
        }

        return sapRfcInfoVO;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#multiSapRfcInfoFileUpload(com.mobis.maps.comm.vo.MapsCommSapRfcInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiSapRfcInfoFileUpload(MapsCommSapRfcInfoVO commSapRfcInfoVO, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        
        /* RFC기본정보 등록 */ 
        List<MapsCommSapRfcBassInfoVO> sapRfcBassInfos = commSapRfcInfoVO.getSapRfcBassInfos();
        multiSapRfcBassInfo(sapRfcBassInfos, loginInfo);
        /* RFC입출력정보 등록 */
        List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos = commSapRfcInfoVO.getSapRfcIpttInfos();
        multiSapRfcIpttInfo(sapRfcIpttInfos, loginInfo);
        /* RFC구조체마스터 등로 */
        List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos = commSapRfcInfoVO.getSapRfcStrctrInfos();
        multiSapRfcStrctrMast(sapRfcStrctrInfos, loginInfo);
        /* RFC구조체필드정보 등록 */
        List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFields = commSapRfcInfoVO.getSapRfcStrctrFieldInfos();
        multiSapRfcStrctrFieldInfo(sapRfcStrctrFields, loginInfo);
        
        procCnt = 1;
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#selectSapRfcBassInfoPgList(com.mobis.maps.comm.vo.MapsCommSapRfcInfoVO)
     */
    @Override
    public List<MapsCommSapRfcBassInfoVO> selectSapRfcBassInfoPgList(MapsCommSapRfcInfoVO commSapRfcInfoVO) throws Exception {
        
        List<MapsCommSapRfcBassInfoVO> lstSapRfcBassInfo = mapsCommSapRfcMDAO.selectSapRfcBassInfoPgList(commSapRfcInfoVO);
        
        return lstSapRfcBassInfo;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#selectSapRfcInfoDetail(com.mobis.maps.comm.vo.MapsCommSapRfcBassInfoVO)
     */
    @Override
    public MapsCommSapRfcInfoVO selectSapRfcInfoDetail(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO) throws Exception {
        
        /* RFC입출력정보 조회 */
        MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO = new MapsCommSapRfcIpttInfoVO();
        BeanUtils.copyProperties(commSapRfcIpttInfoVO, commSapRfcBassInfoVO);
        commSapRfcIpttInfoVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos = mapsCommSapRfcMDAO.selectSapRfcIpttInfoByRfcIdList(commSapRfcIpttInfoVO);
        /* RFC구조체기본정보 */
        List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos = mapsCommSapRfcMDAO.selectSapRfcStrctrMstByRfcIdList(commSapRfcBassInfoVO);
        /* RFC구조체필드정보 */
        MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO = new MapsCommSapRfcStrctrFieldVO();
        BeanUtils.copyProperties(commSapRfcStrctrFieldVO, commSapRfcBassInfoVO);
        commSapRfcStrctrFieldVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos = mapsCommSapRfcMDAO.selectSapRfcStrctrFieldByRfcIdList(commSapRfcStrctrFieldVO);
        
        MapsCommSapRfcInfoVO sapRfcInfoVO = new MapsCommSapRfcInfoVO();
        sapRfcInfoVO.setSapRfcIpttInfos(sapRfcIpttInfos);
        sapRfcInfoVO.setSapRfcStrctrInfos(sapRfcStrctrInfos);
        sapRfcInfoVO.setSapRfcStrctrFieldInfos(sapRfcStrctrFieldInfos);
        
        return sapRfcInfoVO;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#multiSapRfcBassInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiSapRfcBassInfo(List<MapsCommSapRfcBassInfoVO> sapRfcBassInfos, LoginInfoVO loginInfo) throws Exception {

        if (logger.isDebugEnabled()) {
            logger.debug("→ multiSapRfcBassInfo::start");
        }
        int rowCnt = 0;
        int procCnt = 0;
        
        MapsCommSapRfcBassInfoVO resultSapRfcBassInfo = null;
        
        for (MapsCommSapRfcBassInfoVO sapRfcBassInfo: sapRfcBassInfos) {
            
            int rowType = sapRfcBassInfo.getRowType();

            rowCnt++;
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            sapRfcBassInfo.setRegistId(loginInfo.getUserId());
            sapRfcBassInfo.setUpdtId(loginInfo.getUserId());

            resultSapRfcBassInfo = mapsCommSapRfcMDAO.selectSapRfcBassInfo(sapRfcBassInfo);
            
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    if (resultSapRfcBassInfo != null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC Base Information"}, null);
                    }
                    mapsCommSapRfcMDAO.insertSapRfcBassInfo(sapRfcBassInfo);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    if (resultSapRfcBassInfo == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC Base Information"}, null);
                    }
                    mapsCommSapRfcMDAO.updateSapRfcBassInfo(sapRfcBassInfo);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    if (resultSapRfcBassInfo == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC Base Information"}, null);
                    }
                    mapsCommSapRfcMDAO.deleteSapRfcBassInfo(sapRfcBassInfo);
                    mapsCommSapRfcMDAO.deleteSapRfcIpttInfoAll(sapRfcBassInfo);
                    break;
                default :
                    continue;
            }
            procCnt++;
        }

        if (logger.isDebugEnabled()) {
            logger.debug("→ multiSapRfcBassInfo::end[rowCnt=" + rowCnt + ",procCnt=" + procCnt + "]");
        }
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#multiSapRfcIpttInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiSapRfcIpttInfo(List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos, LoginInfoVO loginInfo) throws Exception {

        if (logger.isDebugEnabled()) {
            logger.debug("→ multiSapRfcIpttInfo::start");
        }
        int rowCnt = 0;
        int procCnt = 0;

        MapsCommSapRfcBassInfoVO resultSapRfcBassInfo = null;
        String[] arrChkRfcId = new String[0];
        for (MapsCommSapRfcIpttInfoVO sapRfcIpttInfo: sapRfcIpttInfos) {
            
            if (ArrayUtils.hashCode(sapRfcIpttInfo.getRfcId()) > -1) {
                continue;
            }
            MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO = new MapsCommSapRfcBassInfoVO();
            commSapRfcBassInfoVO.setRfcId(sapRfcIpttInfo.getRfcId());
            resultSapRfcBassInfo = mapsCommSapRfcMDAO.selectSapRfcBassInfo(commSapRfcBassInfoVO);
            if (resultSapRfcBassInfo == null) {
                throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC Base Information"}, null);
            }
            arrChkRfcId = ArrayUtils.add(arrChkRfcId, sapRfcIpttInfo.getRfcId());
        }
        
        MapsCommSapRfcIpttInfoVO resultSapRfcIpttInfo = null;
        
        for (MapsCommSapRfcIpttInfoVO sapRfcIpttInfo: sapRfcIpttInfos) {
            
            int rowType = sapRfcIpttInfo.getRowType();
            rowCnt++;
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            sapRfcIpttInfo.setRegistId(loginInfo.getUserId());
            sapRfcIpttInfo.setUpdtId(loginInfo.getUserId());

            resultSapRfcIpttInfo = mapsCommSapRfcMDAO.selectSapRfcIpttInfo(sapRfcIpttInfo);
            
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    if (resultSapRfcIpttInfo != null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC InOutput Information"}, null);
                    }
                    mapsCommSapRfcMDAO.insertSapRfcIpttInfo(sapRfcIpttInfo);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    if (resultSapRfcIpttInfo == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC InOutput Information"}, null);
                    }
                    mapsCommSapRfcMDAO.updateSapRfcIpttInfo(sapRfcIpttInfo);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    if (resultSapRfcIpttInfo == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC InOutput Information"}, null);
                    }
                    mapsCommSapRfcMDAO.deleteSapRfcIpttInfo(sapRfcIpttInfo);
                    break;
                default :
                    continue;
            }
            procCnt++;
        }

        if (logger.isDebugEnabled()) {
            logger.debug("→ multiSapRfcBassInfo::end[rowCnt=" + rowCnt + ",procCnt=" + procCnt + "]");
        }
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#selectSapRfcStrctrMast(com.mobis.maps.comm.vo.MapsCommSapRfcStrctrMstVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapRfcStrctrMstVO selectSapRfcStrctrMast(MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO
            , LoginInfoVO loginInfo) throws Exception {
        
        MapsCommSapRfcStrctrMstVO commSapRfcStrctrMst = mapsCommSapRfcMDAO.selectSapRfcStrctrMst(commSapRfcStrctrMstVO);
        
        return commSapRfcStrctrMst;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#multiSapRfcStrctrMast(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiSapRfcStrctrMast(List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ multiSapRfcStrctrMast::start");
        }
        int rowCnt = 0;
        int procCnt = 0;
        
        MapsCommSapRfcStrctrMstVO resultSapRfcStrctrMst = null;
        
        for (MapsCommSapRfcStrctrMstVO sapRfcStrctrInfo: sapRfcStrctrInfos) {
            
            int rowType = sapRfcStrctrInfo.getRowType();
            rowCnt++;
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            sapRfcStrctrInfo.setRegistId(loginInfo.getUserId());
            sapRfcStrctrInfo.setUpdtId(loginInfo.getUserId());

            resultSapRfcStrctrMst = mapsCommSapRfcMDAO.selectSapRfcStrctrMst(sapRfcStrctrInfo);
            
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    if (resultSapRfcStrctrMst == null) {
                        mapsCommSapRfcMDAO.insertSapRfcStrctrMst(sapRfcStrctrInfo);
                    }
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    if (resultSapRfcStrctrMst == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC Structure Field"}, null);
                    }
                    mapsCommSapRfcMDAO.deleteSapRfcStrctrMst(sapRfcStrctrInfo);
                    mapsCommSapRfcMDAO.deleteSapRfcStrctrFieldAll(sapRfcStrctrInfo);
                    break;
                default :
                    continue;
            }
            procCnt++;
        }

        if (logger.isDebugEnabled()) {
            logger.debug("→ multiSapRfcStrctrMast::end[rowCnt=" + rowCnt + ",procCnt=" + procCnt + "]");
        }
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#multiSapRfcStrctrFieldInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiSapRfcStrctrFieldInfo(List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFields
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ multiSapRfcStrctrFieldInfo::start");
        }
        int rowCnt = 0;
        int procCnt = 0;
        
        MapsCommSapRfcStrctrMstVO resultSapRfcStrctrMst = null;
        String[] arrChkStrctrId = new String[0];
        for (MapsCommSapRfcStrctrFieldVO sapRfcStrctrField: sapRfcStrctrFields) {
            if (ArrayUtils.hashCode(sapRfcStrctrField.getStrctrId()) > -1) {
                continue;
            }
            MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO = new MapsCommSapRfcStrctrMstVO();
            commSapRfcStrctrMstVO.setStrctrId(sapRfcStrctrField.getStrctrId());
            resultSapRfcStrctrMst = mapsCommSapRfcMDAO.selectSapRfcStrctrMst(commSapRfcStrctrMstVO);
            if (resultSapRfcStrctrMst == null) {
                throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC Structure Field"}, null);
            }
            arrChkStrctrId = ArrayUtils.add(arrChkStrctrId, sapRfcStrctrField.getStrctrId());
        }

        MapsCommSapRfcStrctrFieldVO resultSapRfcStrctrField = null;
        for (MapsCommSapRfcStrctrFieldVO sapRfcStrctrField: sapRfcStrctrFields) {
            
            int rowType = sapRfcStrctrField.getRowType();
            rowCnt++;
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            sapRfcStrctrField.setRegistId(loginInfo.getUserId());
            sapRfcStrctrField.setUpdtId(loginInfo.getUserId());

            resultSapRfcStrctrField = mapsCommSapRfcMDAO.selectSapRfcStrctrField(sapRfcStrctrField);
            
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    if (resultSapRfcStrctrField != null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC Structure Field"}, null);
                    }
                    mapsCommSapRfcMDAO.insertSapRfcStrctrField(sapRfcStrctrField);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    if (resultSapRfcStrctrField == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC Structure Field"}, null);
                    }
                    mapsCommSapRfcMDAO.updateSapRfcStrctrField(sapRfcStrctrField);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    if (resultSapRfcStrctrField == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC Structure Field"}, null);
                    }
                    mapsCommSapRfcMDAO.deleteSapRfcStrctrField(sapRfcStrctrField);
                    break;
                default :
                    continue;
            }
            procCnt++;
        }

        if (logger.isDebugEnabled()) {
            logger.debug("→ multiSapRfcStrctrFieldInfo::end[rowCnt=" + rowCnt + ",procCnt=" + procCnt + "]");
        }
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapRfcService#selectSapDestInfo(com.mobis.maps.comm.vo.MapsCommSapRfcInfoVO)
     */
    @Override
    public MapsCommSapDestInfoVO selectSapDestInfo(MapsCommSapRfcInfoVO commSapRfcInfoVO) throws Exception {

        RfcSapSys ffcSapSys = RfcSapSys.get(commSapRfcInfoVO.getSysId());
        
        RfcJCoDest rfcJCoDest = RfcJCoDest.get(ffcSapSys, commSapRfcInfoVO.getSapLangCd());
        
        Destination destination = rfcJCoDest.getDestination();
        
        // Destination 조회
        JCoDestinationMonitor monitor = destination.getMonitor();
        if (logger.isDebugEnabled()) {
            logger.debug("→ getJCoDestinationMonitor::Destination ID: " + monitor.getDestinationID());
            logger.debug("→ getJCoDestinationMonitor::Destination name: " + monitor.getDestinationName());
            logger.debug("→ getJCoDestinationMonitor::Last Activity timestamp: " + monitor.getLastActivityTimestamp());
            logger.debug("→ getJCoDestinationMonitor::Max used count: " + monitor.getMaxUsedCount());
            logger.debug("→ getJCoDestinationMonitor::Origin destination ID: " + monitor.getOriginDestinationID());
            logger.debug("→ getJCoDestinationMonitor::Peak limit: " + monitor.getPeakLimit());
            logger.debug("→ getJCoDestinationMonitor::Pool capacity: " + monitor.getPoolCapacity());
            logger.debug("→ getJCoDestinationMonitor::Pooled connection count:" + monitor.getPooledConnectionCount());
            logger.debug("→ getJCoDestinationMonitor::Used connection count:" + monitor.getUsedConnectionCount());
            logger.debug("→ getJCoDestinationMonitor::Waiting thread count:" + monitor.getWaitingThreadCount());
            logger.debug("→ getJCoDestinationMonitor::Vaid: " + (monitor.isValid() ? "Yes" : "No"));
        }
        Calendar calLastActvty = Calendar.getInstance();
        calLastActvty.setTimeInMillis(monitor.getLastActivityTimestamp());
        
        MapsCommSapDestInfoVO commSapDestInfoVO = new MapsCommSapDestInfoVO();
        commSapDestInfoVO.setDestId(monitor.getDestinationID());
        commSapDestInfoVO.setDestNm(monitor.getDestinationName());
        commSapDestInfoVO.setLastActvtyDt(calLastActvty.getTime());
        commSapDestInfoVO.setMaxUsedCnt(monitor.getMaxUsedCount());
        commSapDestInfoVO.setOrginDestId(monitor.getOriginDestinationID());
        commSapDestInfoVO.setPkLmt(monitor.getPeakLimit());
        commSapDestInfoVO.setPoolCpcty(monitor.getPoolCapacity());
        commSapDestInfoVO.setPooledConectCnt(monitor.getPooledConnectionCount());
        commSapDestInfoVO.setUsedConectCnt(monitor.getUsedConnectionCount());
        commSapDestInfoVO.setWaitThreadCnt(monitor.getWaitingThreadCount());
        commSapDestInfoVO.setValid(monitor.isValid());
        
        List<? extends JCoConnectionData> connections = destination.getConnectionInfo();
        List<MapsCommSapDestConectInfoVO> destConectInfos = new ArrayList<MapsCommSapDestConectInfoVO>();
        int i = 0;
        for (JCoConnectionData connection: connections) {
            if (logger.isDebugEnabled()) {
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Group name: " + connection.getGroupName());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::System ID: " + connection.getSystemID());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Protocol: " + connection.getProtocol());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Thread ID: " + connection.getThreadIdAsString());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Thread name: " + connection.getThreadName());  
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Connection type: " + connection.getConnectionType());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Connection handle: " + connection.getConnectionHandleAsString());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::State: " + connection.getStateAsString());  
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::ABAP system number: " + connection.getAbapSystemNumber());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::ABAP host: " + connection.getAbapHost());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::ABAP client: " + connection.getAbapClient());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::ABAP language: " + connection.getAbapLanguage());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::ABAP user: " + connection.getAbapUser());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Application name: " + connection.getApplicationName());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Session ID: " + connection.getSessionId());        
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Conv ID: " + connection.getConvId());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::DSR passport: " + connection.getDSRPassportAsString());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Function module name: " + connection.getFunctionModuleName());
                logger.debug("→ getJCoDestinationMonitor::connections["+i+"]::Last activity timestamp: " + connection.getLastActivityTimestampAsString(calLastActvty));
            }
            MapsCommSapDestConectInfoVO commSapDestConectInfoVO = new MapsCommSapDestConectInfoVO();
            commSapDestConectInfoVO.setDestId(connection.getGroupName());
            commSapDestConectInfoVO.setSysId(connection.getSystemID());
            commSapDestConectInfoVO.setPrtcl(connection.getProtocol());
            commSapDestConectInfoVO.setThreadId(connection.getThreadIdAsString());
            commSapDestConectInfoVO.setThreadNm(connection.getThreadName());
            commSapDestConectInfoVO.setConectTy(connection.getConnectionType());
            commSapDestConectInfoVO.setConectHndl(connection.getConnectionHandleAsString());
            commSapDestConectInfoVO.setState(connection.getStateAsString());
            commSapDestConectInfoVO.setAbapSysNum( connection.getAbapSystemNumber());
            commSapDestConectInfoVO.setAbapHost(connection.getAbapHost());
            commSapDestConectInfoVO.setAbapClnt(connection.getAbapClient());
            commSapDestConectInfoVO.setAbapLang(connection.getAbapLanguage());
            commSapDestConectInfoVO.setAbapUser(connection.getAbapUser());
            commSapDestConectInfoVO.setAplctnNm(connection.getApplicationName());
            commSapDestConectInfoVO.setSesionId(connection.getSessionId());
            commSapDestConectInfoVO.setConvId(connection.getConvId());
            commSapDestConectInfoVO.setDsrPassport(connection.getDSRPassportAsString());
            commSapDestConectInfoVO.setFncModuleNm(connection.getFunctionModuleName());
            commSapDestConectInfoVO.setLastActvtyDate(connection.getLastActivityTimestampAsString(calLastActvty));
            destConectInfos.add(commSapDestConectInfoVO);
            i++;
        }
        commSapDestInfoVO.setDestConectInfos(destConectInfos);
        
        return commSapDestInfoVO;
    }
}