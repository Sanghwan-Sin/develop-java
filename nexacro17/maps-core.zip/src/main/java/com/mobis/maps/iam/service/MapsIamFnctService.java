package com.mobis.maps.iam.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamFnctEstnUrlVO;
import com.mobis.maps.iam.vo.MapsIamFnctVO;

/**
 * <pre>
 * Function관리 서비스
 * </pre>
 *
 * @ClassName   : MapsIamFnctService.java
 * @Description : Function관리 서비스를 정의.
 * @author DT048657
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     DT048657     	최초 생성
 * </pre>
 */
public interface MapsIamFnctService {
    
    public static final String FNCT_SE_CD_URL = "U";
    public static final String FNCT_SE_CD_POPUP = "P";

    /**
     * Function관리 리스트 조회
     *
     * @param commFnctVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamFnctVO> selectFnctPgList(MapsIamFnctVO iamFnctVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * Function관리 저장
     *
     * @param FnctInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiFnctInfo(List<MapsIamFnctVO> iamFnctInfos, LoginInfoVO loginInfo) throws Exception;

    /**
     * Function확장URL 리스트 조회
     *
     * @param iamFnctEstnUrlVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamFnctEstnUrlVO> selectFnctEstnUrlList(MapsIamFnctEstnUrlVO iamFnctEstnUrlVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * Function확장URL 저장
     *
     * @param FnctInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiFnctEstnUrl(List<MapsIamFnctEstnUrlVO> fnctEstnUrls, LoginInfoVO loginInfo) throws Exception;

    /**
     * 화면 Function관리 저장
     *
     * @param FnctInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiScreenFnctInfo(List<MapsIamFnctVO> fnctInfos, LoginInfoVO loginInfo) throws Exception;
}
