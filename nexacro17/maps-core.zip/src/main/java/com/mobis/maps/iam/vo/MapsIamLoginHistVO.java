package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * 로그인이력 항목
 * </pre>
 *
 * @ClassName   : MapsIamLoginHistVO.java
 * @Description : 로그인이력에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 24.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamLoginHistVO extends MapsIamCommVO {
/* 조회조건 */
    /** 시작일자 */
    private Date strtDt;
    /** 종료일자 */
    private Date endDt;
/* 로그인이력정보 */
    /** 로그인일시 */
    private Date loginDt;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 사용자ID */
    private String userId;
    /** 언어코드 */
    private String langCd;
    /** 서버명 */
    private String serverNm;
    /** 성공여부 */
    private String succesYn;
    /** 실패구분코드 */
    private String failrSeCd;
    /** 로그인사용자순번ID */
    private String loginSeqId;
    /** 로그인IP주소 */
    private String loginIpAdres;
/* 사용자변경정보 */
    /** 계정잠금여부 */
    private String acntLockYn;
    /** 계정잠금사유코드 */
    private String acntLockResnCd;
    /** 암호오류횟수 */
    private int pwdErrorCo;
    /** 로그아웃 일시 */
    private Date logoutDt;
    /** jsessionID*/
    private String jsessionid;
    /** preLoginFlag*/
    private String preLoginFlag;
    
    /** maxLoginDt*/
    private String maxLoginDt;
    
    
     
    /**
     * @return the maxLoginDt
     */
    public String getMaxLoginDt() {
        return maxLoginDt;
    }
    /**
     * @param maxLoginDt the maxLoginDt to set
     */
    public void setMaxLoginDt(String maxLoginDt) {
        this.maxLoginDt = maxLoginDt;
    }
    /**
     * @return the preLoginFlag
     */
    public String getPreLoginFlag() {
        return preLoginFlag;
    }
    /**
     * @param preLoginFlag the preLoginFlag to set
     */
    public void setPreLoginFlag(String preLoginFlag) {
        this.preLoginFlag = preLoginFlag;
    }
    /**
     * @return the logoutDt
     */
    public Date getLogoutDt() {
        return logoutDt;
    }
    /**
     * @param logoutDt the logoutDt to set
     */
    public void setLogoutDt(Date logoutDt) {
        this.logoutDt = logoutDt;
    }
    /**
     * @return the jsessionid
     */
    public String getJsessionid() {
        return jsessionid;
    }
    /**
     * @param jsessionid the jsessionid to set
     */
    public void setJsessionid(String jsessionid) {
        this.jsessionid = jsessionid;
    }
    /**
     * @return the strtDt
     */
    public Date getStrtDt() {
        return strtDt;
    }
    /**
     * @param strtDt the strtDt to set
     */
    public void setStrtDt(Date strtDt) {
        this.strtDt = strtDt;
    }
    /**
     * @return the endDt
     */
    public Date getEndDt() {
        return endDt;
    }
    /**
     * @param endDt the endDt to set
     */
    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }
    /**
     * @return the loginDt
     */
    public Date getLoginDt() {
        return loginDt;
    }
    /**
     * @param loginDt the loginDt to set
     */
    public void setLoginDt(Date loginDt) {
        this.loginDt = loginDt;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the langCd
     */
    public String getLangCd() {
        return langCd;
    }
    /**
     * @param langCd the langCd to set
     */
    public void setLangCd(String langCd) {
        this.langCd = langCd;
    }
    /**
     * @return the serverNm
     */
    public String getServerNm() {
        return serverNm;
    }
    /**
     * @param serverNm the serverNm to set
     */
    public void setServerNm(String serverNm) {
        this.serverNm = serverNm;
    }
    /**
     * @return the succesYn
     */
    public String getSuccesYn() {
        return succesYn;
    }
    /**
     * @param succesYn the succesYn to set
     */
    public void setSuccesYn(String succesYn) {
        this.succesYn = succesYn;
    }
    /**
     * @return the failrSeCd
     */
    public String getFailrSeCd() {
        return failrSeCd;
    }
    /**
     * @param failrSeCd the failrSeCd to set
     */
    public void setFailrSeCd(String failrSeCd) {
        this.failrSeCd = failrSeCd;
    }
    /**
     * @return the loginSeqId
     */
    public String getLoginSeqId() {
        return loginSeqId;
    }
    /**
     * @param loginSeqId the loginSeqId to set
     */
    public void setLoginSeqId(String loginSeqId) {
        this.loginSeqId = loginSeqId;
    }
    /**
     * @return the loginIpAdres
     */
    public String getLoginIpAdres() {
        return loginIpAdres;
    }
    /**
     * @param loginIpAdres the loginIpAdres to set
     */
    public void setLoginIpAdres(String loginIpAdres) {
        this.loginIpAdres = loginIpAdres;
    }
    /**
     * @return the acntLockYn
     */
    public String getAcntLockYn() {
        return acntLockYn;
    }
    /**
     * @param acntLockYn the acntLockYn to set
     */
    public void setAcntLockYn(String acntLockYn) {
        this.acntLockYn = acntLockYn;
    }
    /**
     * @return the acntLockResnCd
     */
    public String getAcntLockResnCd() {
        return acntLockResnCd;
    }
    /**
     * @param acntLockResnCd the acntLockResnCd to set
     */
    public void setAcntLockResnCd(String acntLockResnCd) {
        this.acntLockResnCd = acntLockResnCd;
    }
    /**
     * @return the pwdErrorCo
     */
    public int getPwdErrorCo() {
        return pwdErrorCo;
    }
    /**
     * @param pwdErrorCo the pwdErrorCo to set
     */
    public void setPwdErrorCo(int pwdErrorCo) {
        this.pwdErrorCo = pwdErrorCo;
    }
}
