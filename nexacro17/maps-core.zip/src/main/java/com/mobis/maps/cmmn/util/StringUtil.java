package com.mobis.maps.cmmn.util;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <pre>
 * StringUtil
 * </pre>
 *
 * @ClassName   : StringUtil.java
 * @Description : apache commons 사용권장합니다.
 * @author oh.dongwon
 * @since 2018. 5. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2018. 5. 18.     oh.dongwon     	최초 생성
 * </pre>
 */
public class StringUtil {


    private static Logger logger = LoggerFactory.getLogger(StringUtil.class);

    /**
     * 빈 문자열 <code>""</code>.
     */

    public static final String EMPTY = "";

    /**
     * <p>
     * The maximum size to which the padding constant(s) can expand.
     * </p>
     */

    private static final int PAD_LIMIT = 8192;

    /**
     * <p>
     * An array of <code>String</code>s used for padding.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * Used for efficient space padding. The length of each String expands as
     * needed.
     * </p>
     */

    private static final String[] PADDING = new String[Character.MAX_VALUE];

    static {

        // space padding is most common, start with 64 chars

        PADDING[32] = "                                                                ";

    }

    public static String StringReplace(String str) {
        String tempStr=str;
        String match = "[^\uAC00-\uD7A3xfe0-9a-zA-Z\\s]";
        tempStr = tempStr.replaceAll(match, "");
        return tempStr;
    }

    /**
     * List<Map> 를 JSON String 으로 변환 출력
     *
     * @param list
     * @return String
     */
    @SuppressWarnings("unchecked")
    public static String jsonString(String key, List<Map<String, Object>> list) {
        JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        for (Map<String, Object> map : list) {
            jsonArray.add(map);
        }
        jsonObject.put(key, jsonArray);
        return jsonObject.toJSONString();
    }

    /**
     * 문자열이 지정한 길이를 초과했을때 지정한길이에다가 해당 문자열을 붙여주는 메서드.
     *
     * @param source  원본 문자열 배열
     * @param output  더할문자열
     * @param slength 지정길이
     * @return 지정길이로 잘라서 더할분자열 합친 문자열
     */
    public static String cutString(String source, String output, int slength) {
        String returnVal = null;
        if (source != null) {
            if (source.length() > slength) {
                returnVal = source.substring(0, slength) + output;
            } else returnVal = source;
        }
        return returnVal;
    }

    /**
     * 문자열이 지정한 길이를 초과했을때 해당 문자열을 삭제하는 메서드
     *
     * @param source  원본 문자열 배열
     * @param slength 지정길이
     * @return 지정길이로 잘라서 더할분자열 합친 문자열
     */
    public static String cutString(String source, int slength) {
        String result = null;
        if (source != null) {
            if (source.length() > slength) {
                result = source.substring(0, slength);
            } else result = source;
        }
        return result;
    }

    /**
     * <p>
     * String이 비었거나("") 혹은 null 인지 검증한다.
     * </p>
     * <p>
     * <pre>
     *  StringUtil.isEmpty(null)      = true
     *  StringUtil.isEmpty("")        = true
     *  StringUtil.isEmpty(" ")       = false
     *  StringUtil.isEmpty("bob")     = false
     *  StringUtil.isEmpty("  bob  ") = false
     * </pre>
     *
     * @param str - 체크 대상 스트링오브젝트이며 null을 허용함
     * @return <code>true</code> - 입력받은 String 이 빈 문자열 또는 null인 경우
     */
    public static boolean isEmpty(String str) {
        return str == null || str.length() == 0;
    }

    /**
     * <p>
     * 기준 문자열에 포함된 모든 대상 문자(char)를 제거한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.remove(null, *)       = null
     * StringUtil.remove("", *)         = ""
     * StringUtil.remove("queued", 'u') = "qeed"
     * StringUtil.remove("queued", 'z') = "queued"
     * </pre>
     *
     * @param str    입력받는 기준 문자열
     * @param remove 입력받는 문자열에서 제거할 대상 문자열
     * @return 제거대상 문자열이 제거된 입력문자열. 입력문자열이 null인 경우 출력문자열은 null
     */
    public static String remove(String str, char remove) {
    	String result = "";
        if (isEmpty(str) || str.indexOf(remove) == -1) {
        	result = str;
        } else {
	        char[] chars = str.toCharArray();
	        int pos = 0;
	        for (int i = 0; i < chars.length; i++) {
	            if (chars[i] != remove) {
	                chars[pos++] = chars[i];
	            }
	        }
	        result = new String(chars, 0, pos);
        }
        return result;
    }

    /**
     * <p>
     * 문자열 내부의 콤마 character(,)를 모두 제거한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.removeCommaChar(null)       = null
     * StringUtil.removeCommaChar("")         = ""
     * StringUtil.removeCommaChar("asdfg,qweqe") = "asdfgqweqe"
     * </pre>
     *
     * @param str 입력받는 기준 문자열
     * @return " , "가 제거된 입력문자열 입력문자열이 null인 경우 출력문자열은 null
     */
    public static String removeCommaChar(String str) {
        return remove(str, ',');
    }

    /**
     * <p>
     * 문자열 내부의 마이너스 character(-)를 모두 제거한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.removeMinusChar(null)       = null
     * StringUtil.removeMinusChar("")         = ""
     * StringUtil.removeMinusChar("a-sdfg-qweqe") = "asdfgqweqe"
     * </pre>
     *
     * @param str 입력받는 기준 문자열
     * @return " - "가 제거된 입력문자열 입력문자열이 null인 경우 출력문자열은 null
     */
    public static String removeMinusChar(String str) {
        return remove(str, '-');
    }

    /**
     * 원본 문자열의 포함된 특정 문자열을 새로운 문자열로 변환하는 메서드
     *
     * @param source  원본 문자열
     * @param subject 원본 문자열에 포함된 특정 문자열
     * @param object  변환할 문자열
     * @return sb.toString() 새로운 문자열로 변환된 문자열
     */
    public static String replace(String source, String subject, String object) {
        StringBuffer rtnStr = new StringBuffer();
        String preStr = "";
        String nextStr = source;
        String srcStr = source;

        while (srcStr.indexOf(subject) >= 0) {
            preStr = srcStr.substring(0, srcStr.indexOf(subject));
            nextStr = srcStr.substring(srcStr.indexOf(subject) + subject.length(), srcStr.length());
            srcStr = nextStr;
            rtnStr.append(preStr).append(object);
        }
        rtnStr.append(nextStr);

        return rtnStr.toString();
    }

    /**
     * 원본 문자열의 포함된 특정 문자열 첫번째 한개만 새로운 문자열로 변환하는 메서드
     *
     * @param source  원본 문자열
     * @param subject 원본 문자열에 포함된 특정 문자열
     * @param object  변환할 문자열
     * @return sb.toString() 새로운 문자열로 변환된 문자열 / source 특정문자열이 없는 경우 원본 문자열
     */
    public static String replaceOnce(String source, String subject, String object) {
        StringBuffer rtnStr = new StringBuffer();
        String preStr = "";
        String nextStr = source;
        String result = "";
        if (source.indexOf(subject) >= 0) {
            preStr = source.substring(0, source.indexOf(subject));
            nextStr = source.substring(source.indexOf(subject) + subject.length(), source.length());
            rtnStr.append(preStr).append(object).append(nextStr);

            result = rtnStr.toString();
        } else {
        	result = source;
        }
        return result;
    }

    /**
     * <code>subject</code>에 포함된 각각의 문자를 object로 변환한다.
     *
     * @param source  원본 문자열
     * @param subject 원본 문자열에 포함된 특정 문자열
     * @param object  변환할 문자열
     * @return sb.toString() 새로운 문자열로 변환된 문자열
     */
    public static String replaceChar(String source, String subject, String object) {
        StringBuffer rtnStr = new StringBuffer();
        String preStr = "";
        String nextStr = source;
        String srcStr = source;

        char chA;

        for (int i = 0; i < subject.length(); i++) {
            chA = subject.charAt(i);

            if (srcStr.indexOf(chA) >= 0) {
                preStr = srcStr.substring(0, srcStr.indexOf(chA));
                nextStr = srcStr.substring(srcStr.indexOf(chA) + 1, srcStr.length());
                srcStr = rtnStr.append(preStr).append(object).append(nextStr).toString();
            }
        }
        return srcStr;
    }

    /**
     * <p>
     * <code>str</code> 중 <code>searchStr</code>의 시작(index) 위치를 반환.
     * </p>
     * <p>
     * <p>
     * 입력값 중 <code>null</code>이 있을 경우 <code>-1</code>을 반환.
     * </p>
     * <p>
     * <pre>
     * StringUtil.indexOf(null, *)          = -1
     * StringUtil.indexOf(*, null)          = -1
     * StringUtil.indexOf("", "")           = 0
     * StringUtil.indexOf("aabaabaa", "a")  = 0
     * StringUtil.indexOf("aabaabaa", "b")  = 2
     * StringUtil.indexOf("aabaabaa", "ab") = 1
     * StringUtil.indexOf("aabaabaa", "")   = 0
     * </pre>
     *
     * @param str       검색 문자열
     * @param searchStr 검색 대상문자열
     * @return 검색 문자열 중 검색 대상문자열이 있는 시작 위치 검색대상 문자열이 없거나 null인 경우 -1
     */
    public static int indexOf(String str, String searchStr) {
        int returnResult;
        if (str == null || searchStr == null) {
            returnResult = -1;
        }else{
            returnResult = str.indexOf(searchStr);
        }
        return returnResult;
    }

    /**
     * <p>
     * 오라클의 decode 함수와 동일한 기능을 가진 메서드이다. <code>sourStr</code>과
     * <code>compareStr</code>의 값이 같으면 <code>returStr</code>을 반환하며, 다르면
     * <code>defaultStr</code>을 반환한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.decode(null, null, "foo", "bar")= "foo"
     * StringUtil.decode("", null, "foo", "bar") = "bar"
     * StringUtil.decode(null, "", "foo", "bar") = "bar"
     * StringUtil.decode("하이", "하이", null, "bar") = null
     * StringUtil.decode("하이", "하이  ", "foo", null) = null
     * StringUtil.decode("하이", "하이", "foo", "bar") = "foo"
     * StringUtil.decode("하이", "하이  ", "foo", "bar") = "bar"
     * </pre>
     *
     * @param sourceStr  비교할 문자열
     * @param compareStr 비교 대상 문자열
     * @param returnStr  sourceStr와 compareStr의 값이 같을 때 반환할 문자열
     * @param defaultStr sourceStr와 compareStr의 값이 다를 때 반환할 문자열
     * @return sourceStr과 compareStr의 값이 동일(equal)할 때 returnStr을 반환하며, <br/>
     * 다르면 defaultStr을 반환한다.
     */
    public static String decode(String sourceStr, String compareStr, String returnStr, String defaultStr) {
    	String result = "";
        if (sourceStr == null && compareStr == null) {
        	result = returnStr;
        }else if (sourceStr == null && compareStr != null) {
        	result = defaultStr;
        }else if (null != sourceStr && sourceStr.trim().equals(compareStr)) {
        	result = returnStr;
        }
        return result;
    }

    /**
     * <p>
     * 오라클의 decode 함수와 동일한 기능을 가진 메서드이다. <code>sourStr</code>과
     * <code>compareStr</code>의 값이 같으면 <code>returStr</code>을 반환하며, 다르면
     * <code>sourceStr</code>을 반환한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.decode(null, null, "foo") = "foo"
     * StringUtil.decode("", null, "foo") = ""
     * StringUtil.decode(null, "", "foo") = null
     * StringUtil.decode("하이", "하이", "foo") = "foo"
     * StringUtil.decode("하이", "하이 ", "foo") = "하이"
     * StringUtil.decode("하이", "바이", "foo") = "하이"
     * </pre>
     *
     * @param sourceStr  비교할 문자열
     * @param compareStr 비교 대상 문자열
     * @param returnStr  sourceStr와 compareStr의 값이 같을 때 반환할 문자열
     * @return sourceStr과 compareStr의 값이 동일(equal)할 때 returnStr을 반환하며, <br/>
     * 다르면 sourceStr을 반환한다.
     */
    public static String decode(String sourceStr, String compareStr, String returnStr) {
        return decode(sourceStr, compareStr, returnStr, sourceStr);
    }

    /**
     * 객체가 null인지 확인하고 null인 경우 "" 로 바꾸는 메서드
     *
     * @param object 원본 객체
     * @return resultVal 문자열
     */
    public static String isNullToString(Object object) {
        String string = "";

        if (object != null) {
            string = object.toString().trim();
        }

        return string;
    }

    /**
     * <pre>
     * 인자로 받은 String이 null일 경우 &quot;&quot;로 리턴한다.
     * &#064;param src null값일 가능성이 있는 String 값.
     * &#064;return 만약 String이 null 값일 경우 &quot;&quot;로 바꾼 String 값.
     * </pre>
     */
    public static String nullConvert(Object src) {
        // if (src != null &&
        // src.getClass().getName().equals("java.math.BigDecimal")) {
    	String result = "";
        if (src != null && src instanceof java.math.BigDecimal) {
        	result = ((BigDecimal) src).toString();
        }else {
            if (src == null || src.equals("null")) {
            	result = "";
            } else {
            	result = ((String) src).trim();
            }
        }
        return result;
    }

    /**
     * <pre>
     * 인자로 받은 String이 null일 경우 &quot;&quot;로 리턴한다.
     * &#064;param src null값일 가능성이 있는 String 값.
     * &#064;return 만약 String이 null 값일 경우 &quot;&quot;로 바꾼 String 값.
     * </pre>
     */
    public static String nullConvert(String src) {
    	String result = "";
        if (src == null || src.equals("null") || "".equals(src) || " ".equals(src)) {
        	result = "";
        } else {
        	result = src.trim();
        }
        return result;
    }

    /**
     * <pre>
     * 인자로 받은 String이 null일 경우 &quot;0&quot;로 리턴한다.
     * &#064;param src null값일 가능성이 있는 String 값.
     * &#064;return 만약 String이 null 값일 경우 &quot;0&quot;로 바꾼 String 값.
     * </pre>
     */
    public static int zeroConvert(Object src) {
        int returnResult=0;
        if (src != null && !src.equals("null")) {
            returnResult = Integer.parseInt(((String) src).trim());
        }
        return returnResult;
    }

    /**
     * <pre>
     * 인자로 받은 String이 null일 경우 &quot;&quot;로 리턴한다.
     * &#064;param src null값일 가능성이 있는 String 값.
     * &#064;return 만약 String이 null 값일 경우 &quot;&quot;로 바꾼 String 값.
     * </pre>
     */
    public static int zeroConvert(String src) {
        int returnResult=0;
        if (src != null && !src.equals("null") && !"".equals(src) && !" ".equals(src)) {
            returnResult = Integer.parseInt(src.trim());
        }
        return returnResult;
    }

    /**
     * <p>
     * 문자열에서 {@link Character#isWhitespace(char)}에 정의된 모든 공백문자를 제거한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.removeWhitespace(null)         = null
     * StringUtil.removeWhitespace("")           = ""
     * StringUtil.removeWhitespace("abc")        = "abc"
     * StringUtil.removeWhitespace("   ab  c  ") = "abc"
     * </pre>
     *
     * @param str 공백문자가 제거도어야 할 문자열
     * @return the 공백문자가 제거된 문자열, null이 입력되면 <code>null</code>이 리턴
     */
    public static String removeWhitespace(String str) {
    	String result = "";
        if (isEmpty(str)) {
        	result = str;
        }else{
            int sz = str.length();
            char[] chs = new char[sz];
            int count = 0;
            for (int i = 0; i < sz; i++) {
                if (!Character.isWhitespace(str.charAt(i))) {
                    chs[count++] = str.charAt(i);
                }
            }
            if (count == sz) {
            	result = str;
            }else{
            	result = new String(chs, 0, count);
            }
        }
        return result;
    }

    /**
     * Html 코드가 들어간 문서를 표시할때 태그에 손상없이 보이기 위한 메서드
     *
     * @param strString
     * @return HTML 태그를 치환한 문자열
     */
    public static String checkHtmlView(String strString) {
        String strNew = "";

        StringBuffer strTxt = new StringBuffer("");

        char chrBuff;
        int len = strString.length();

        for (int i = 0; i < len; i++) {
            chrBuff = strString.charAt(i);

            switch (chrBuff) {
                case '<':
                    strTxt.append("&lt;");
                    break;
                case '>':
                    strTxt.append("&gt;");
                    break;
                case '"':
                    strTxt.append("&quot;");
                    break;
                case 10:
                    strTxt.append("<br>");
                    break;
                case ' ':
                    strTxt.append("&nbsp;");
                    break;
                // case '&' :
                // strTxt.append("&amp;");
                // break;
                default:
                    strTxt.append(chrBuff);
            }
        }

        strNew = strTxt.toString();

        return strNew;
    }

    /**
     * 문자열을 지정한 분리자에 의해 배열로 리턴하는 메서드.
     *
     * @param source    원본 문자열
     * @param separator 분리자
     * @return result 분리자로 나뉘어진 문자열 배열
     */
    public static String[] split(String source, String separator) throws NullPointerException {
        String[] returnVal = null;
        int cnt = 1;

        int index = source.indexOf(separator);
        int index0 = 0;
        while (index >= 0) {
            cnt++;
            index = source.indexOf(separator, index + 1);
        }
        returnVal = new String[cnt];
        cnt = 0;
        index = source.indexOf(separator);
        while (index >= 0) {
            returnVal[cnt] = source.substring(index0, index);
            index0 = index + 1;
            index = source.indexOf(separator, index + 1);
            cnt++;
        }
        returnVal[cnt] = source.substring(index0);

        return returnVal;
    }

    /**
     * <p>
     * {@link String#toLowerCase()}를 이용하여 소문자로 변환한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.lowerCase(null)  = null
     * StringUtil.lowerCase("")    = ""
     * StringUtil.lowerCase("aBc") = "abc"
     * </pre>
     *
     * @param str 소문자로 변환되어야 할 문자열
     * @return 소문자로 변환된 문자열, null이 입력되면 <code>null</code> 리턴
     */
    public static String lowerCase(String str) {
    	String result = "";
        if (str == null) {
        	result = null;
        }else{
        	result = str.toLowerCase();
        }
        return result;
    }

    /**
     * <p>
     * {@link String#toUpperCase()}를 이용하여 대문자로 변환한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.upperCase(null)  = null
     * StringUtil.upperCase("")    = ""
     * StringUtil.upperCase("aBc") = "ABC"
     * </pre>
     *
     * @param str 대문자로 변환되어야 할 문자열
     * @return 대문자로 변환된 문자열, null이 입력되면 <code>null</code> 리턴
     */
    public static String upperCase(String str) {
    	String result = "";
        if (str == null) {
        	result = null;
        }else{
        	result = str.toUpperCase();
        }
        return result;

    }

    /**
     * <p>
     * 입력된 String의 앞쪽에서 두번째 인자로 전달된 문자(stripChars)를 모두 제거한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.stripStart(null, *)          = null
     * StringUtil.stripStart("", *)            = ""
     * StringUtil.stripStart("abc", "")        = "abc"
     * StringUtil.stripStart("abc", null)      = "abc"
     * StringUtil.stripStart("  abc", null)    = "abc"
     * StringUtil.stripStart("abc  ", null)    = "abc  "
     * StringUtil.stripStart(" abc ", null)    = "abc "
     * StringUtil.stripStart("yxabc  ", "xyz") = "abc  "
     * </pre>
     *
     * @param tempStr        지정된 문자가 제거되어야 할 문자열
     * @param stripChars 제거대상 문자열
     * @return 지정된 문자가 제거된 문자열, null이 입력되면 <code>null</code> 리턴
     */
    public static String stripStart(String str, String stripChars) {
    	String result = "";
        String tempStr=str;
        int strLen=tempStr.length();
        if (tempStr == null || strLen == 0) {
        	result = tempStr;
        }else{
            int start = 0;
            if (stripChars == null) {
                while ((start != strLen) && Character.isWhitespace(tempStr.charAt(start))) {
                    start++;
                }
                result = tempStr.substring(start);
            } else if (stripChars.length() == 0) {
            	result = tempStr;
            } else {
                while ((start != strLen) && (stripChars.indexOf(tempStr.charAt(start)) != -1)) {
                    start++;
                }
                result = tempStr.substring(start);
            }
        }
        return result;
    }

    /**
     * <p>
     * 입력된 String의 뒤쪽에서 두번째 인자로 전달된 문자(stripChars)를 모두 제거한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.stripEnd(null, *)          = null
     * StringUtil.stripEnd("", *)            = ""
     * StringUtil.stripEnd("abc", "")        = "abc"
     * StringUtil.stripEnd("abc", null)      = "abc"
     * StringUtil.stripEnd("  abc", null)    = "  abc"
     * StringUtil.stripEnd("abc  ", null)    = "abc"
     * StringUtil.stripEnd(" abc ", null)    = " abc"
     * StringUtil.stripEnd("  abcyx", "xyz") = "  abc"
     * </pre>
     *
     * @param tempStr        지정된 문자가 제거되어야 할 문자열
     * @param stripChars 제거대상 문자열
     * @return 지정된 문자가 제거된 문자열, null이 입력되면 <code>null</code> 리턴
     */
    public static String stripEnd(String str, String stripChars) {
        String tempStr=str;
        String returnResult=null;
        if (tempStr != null) {
            int end= tempStr.length();
            if(end == 0){
                returnResult="";
            }else{
                if (stripChars == null) {
                    while ((end != 0) && Character.isWhitespace(tempStr.charAt(end - 1))) {
                        end--;
                    }
                    returnResult = tempStr.substring(0, end);
                } else if (stripChars.length() == 0) {
                    returnResult = tempStr;
                } else {
                    while ((end != 0) && (stripChars.indexOf(tempStr.charAt(end - 1)) != -1)) {
                        end--;
                    }
                    returnResult = tempStr.substring(0, end);
                }
            }
        }
        return returnResult;
    }

    /**
     * <p>
     * 입력된 String의 앞, 뒤에서 두번째 인자로 전달된 문자(stripChars)를 모두 제거한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.strip(null, *)          = null
     * StringUtil.strip("", *)            = ""
     * StringUtil.strip("abc", null)      = "abc"
     * StringUtil.strip("  abc", null)    = "abc"
     * StringUtil.strip("abc  ", null)    = "abc"
     * StringUtil.strip(" abc ", null)    = "abc"
     * StringUtil.strip("  abcyx", "xyz") = "  abc"
     * </pre>
     *
     * @param str        지정된 문자가 제거되어야 할 문자열
     * @param stripChars 제거대상 문자열
     * @return 지정된 문자가 제거된 문자열, null이 입력되면 <code>null</code> 리턴
     */
    public static String strip(String str, String stripChars) {
    	String result = "";
        if (isEmpty(str)) {
        	result = str;
        }else{
            String srcStr = str;
            srcStr = stripStart(srcStr, stripChars);

            result = stripEnd(srcStr, stripChars);
        }
        return result;
    }

    /**
     * 문자열을 지정한 분리자에 의해 지정된 길이의 배열로 리턴하는 메서드.
     *
     * @param source      원본 문자열
     * @param separator   분리자
     * @param arraylength 배열 길이
     * @return 분리자로 나뉘어진 문자열 배열
     */
    public static String[] split(String source, String separator, int arraylength) throws NullPointerException {
        String[] returnVal = new String[arraylength];
        int cnt = 0;
        int index0 = 0;
        int index = source.indexOf(separator);
        while (index >= 0 && cnt < (arraylength - 1)) {
            returnVal[cnt] = source.substring(index0, index);
            index0 = index + 1;
            index = source.indexOf(separator, index + 1);
            cnt++;
        }
        returnVal[cnt] = source.substring(index0);
        if (cnt < (arraylength - 1)) {
            for (int i = cnt + 1; i < arraylength; i++) {
                returnVal[i] = "";
            }
        }

        return returnVal;
    }

    /**
     * 문자열 A에서 Z사이의 랜덤 문자열을 구하는 기능을 제공 시작문자열과 종료문자열 사이의 랜덤 문자열을 구하는 기능
     *
     * @param startChr - 첫 문자
     * @param endChr   - 마지막문자
     * @return 랜덤문자
     * @see
     */
    public static String getRandomStr(char startChr, char endChr) {

        int randomInt;
        String randomStr = null;

        // 시작문자 및 종료문자를 아스키숫자로 변환한다.
        int startInt = Integer.valueOf(startChr);
        int endInt = Integer.valueOf(endChr);

        // 시작문자열이 종료문자열보가 클경우
        if (startInt > endInt) {
            throw new IllegalArgumentException("Start String: " + startChr + " End String: " + endChr);
        }

        // 랜덤 객체 생성
        SecureRandom rnd = new SecureRandom();

        do {
            // 시작문자 및 종료문자 중에서 랜덤 숫자를 발생시킨다.
            randomInt = rnd.nextInt(endInt + 1);
        } while (randomInt < startInt); // 입력받은 문자 'A'(65)보다 작으면 다시 랜덤 숫자 발생.

        // 랜덤 숫자를 문자로 변환 후 스트링으로 다시 변환
        randomStr = (char) randomInt + "";

        // 랜덤문자열를 리턴
        return randomStr;
    }

    /**
     * 문자열을 다양한 문자셋(EUC-KR[KSC5601],UTF-8..)을 사용하여 인코딩하는 기능 역으로 디코딩하여 원래의 문자열을
     * 복원하는 기능을 제공함 String temp = new String(문자열.getBytes("바꾸기전 인코딩"),"바꿀 인코딩");
     * String temp = new String(문자열.getBytes("8859_1"),"KSC5601"); => UTF-8 에서
     * EUC-KR
     *
     * @param srcString    - 문자열
     * @param srcCharsetNm - 원래 CharsetNm
     * @param cnvrCharsetNm    - CharsetNm
     * @return 인(디)코딩 문자열
     * @see
     */
    public static String getEncdDcd(String srcString, String srcCharsetNm, String cnvrCharsetNm) {
    	String result = "";
        String rtnStr = null;
        if (srcString == null) {
        	result = null;
        }else{
            try {
                rtnStr = new String(srcString.getBytes(srcCharsetNm), cnvrCharsetNm);
            } catch (UnsupportedEncodingException e) {
                rtnStr = null;
            }

            result = rtnStr;
        }
        return result;
    }

    /**
     * 특수문자를 웹 브라우저에서 정상적으로 보이기 위해 특수문자를 처리('<' -> & lT)하는 기능이다
     *
     * @param srcString - '<'
     * @return 변환문자열('<' -> "&lt"
     * @see
     */
    public static String getSpclStrCnvr(String srcString) {

        String rtnStr = null;

        StringBuffer strTxt = new StringBuffer("");

        char chrBuff;
        int len = srcString.length();

        for (int i = 0; i < len; i++) {
            chrBuff = srcString.charAt(i);

            switch (chrBuff) {
                case '<':
                    strTxt.append("&lt;");
                    break;
                case '>':
                    strTxt.append("&gt;");
                    break;
                case '&':
                    strTxt.append("&amp;");
                    break;
                default:
                    strTxt.append(chrBuff);
            }
        }

        rtnStr = strTxt.toString();

        return rtnStr;
    }

    /**
     * 응용어플리케이션에서 고유값을 사용하기 위해 시스템에서17자리의TIMESTAMP값을 구하는 기능
     *
     * @param
     * @return Timestamp 값
     * @see
     */
    public static String getTimeStamp() {

        String rtnStr = null;

        // 문자열로 변환하기 위한 패턴 설정(년도-월-일 시:분:초:초(자정이후 초))
        String pattern = "yyyyMMddhhmmssSSS";

        SimpleDateFormat sdfCurrent = new SimpleDateFormat(pattern, Locale.KOREA);
        Timestamp ts = new Timestamp(System.currentTimeMillis());

        rtnStr = sdfCurrent.format(ts.getTime());

        return rtnStr;
    }

    /**
     * html의 특수문자를 표현하기 위해
     *
     * @param srcString
     * @return String
     * @throws Exception
     * @see
     */
    public static String getHtmlStrCnvr(String srcString) {

        String tmpString = srcString;

        tmpString = tmpString.replaceAll("&lt;", "<");
        tmpString = tmpString.replaceAll("&gt;", ">");
        tmpString = tmpString.replaceAll("&amp;", "&");
        tmpString = tmpString.replaceAll("&nbsp;", " ");
        tmpString = tmpString.replaceAll("&apos;", "\'");
        tmpString = tmpString.replaceAll("&quot;", "\"");

        return tmpString;

    }

    /**
     * <p>
     * 날짜 형식의 문자열 내부에 마이너스 character(-)를 추가한다.
     * </p>
     * <p>
     * <pre>
     * StringUtil.addMinusChar("20100901") = "2010-09-01"
     * </pre>
     *
     * @param date 입력받는 문자열
     * @return " - "가 추가된 입력문자열
     */
    public static String addMinusChar(String date) {
    	String result = "";
        if (date.length() == 8) {
        	result = date.substring(0, 4).concat("-").concat(date.substring(4, 6)).concat("-").concat(date.substring(6, 8));
        } else {
        	result = "";
        }
        return result;
    }

    public static String truncateNicely(String s, int len, String tail) {
    	String result = "";
        if (s == null) {
        	result = null;
        }else{
            int srcLen = realLength(s);
            if (srcLen < len){
            	result = s;
            }else{
                String tmpTail = tail;
                if (tail == null)
                    tmpTail = "";
                int tailLen = realLength(tmpTail);
                if (tailLen > len) {
                	result = "";
                }else{
                    char a;
                    int i = 0;
                    int realLen = 0;
                    for (i = 0; i < len - tailLen && realLen < len - tailLen; i++) {
                        a = s.charAt(i);
                        if ((a & 0xFF00) == 0)
                            realLen += 1;
                        else
                            realLen += 2;
                    }
                    while (realLength(s.substring(0, i)) > len - tailLen) {
                        i--;
                    }
                    result = s.substring(0, i) + tmpTail;
                }
            }
        }
        return result;
    }

    public static int realLength(String s) {
        return s.getBytes().length;
    }

    /**
     * 문자열의 CharSet을 unicode(8859_1)로 바꾸는 메서드
     *
     * @param source 원본 문자열
     * @return result 유니코드로 변환된 문자열
     */
    public static String toUnicode(String source) {
        String ret = null;
        if (source == null) {
            ret = null;
        }else{
            try {
                ret = new String(source.getBytes(), "8859_1");
            } catch (UnsupportedEncodingException e) {
                ret = null;
            }
        }
        return ret;
    }

    /**
     * 문자열의 CharSet을 EUC-KR(KSC5601)로 바꾸는 메서드.
     *
     * @param source 원본 문자열
     * @return result EUC-KR로 변환된 문자열
     */
    public static String toEuckr(String source) {
        String ret = null;
        if (source == null){
        	ret = null;
        }else{
            try {
                ret = new String(source.getBytes(), "KSC5601");
            } catch (UnsupportedEncodingException e) {
                ret = null;
            }
        }
        return ret;
    }

    /**
     * 문자열의 unicode(8859_1) CharSet을 넘겨 받아 EUC-KR(KSC5601)로 바꾸는 메서드.
     *
     * @param source unicode(8859_1) 원본 문자열
     * @return result EUC-KR로 변환된 문자열
     */
    public static String toEuckr2(String source) {
        String ret = null;
        String result = "";
        if (source == null){
        	result = null;
        }else{
            try {
                ret = new String(source.getBytes("8859_1"), "KSC5601");
            } catch (UnsupportedEncodingException e) {
                ret = null;
            }
            result = ret;
        }
        return result;
    }

    /**
     * 문자열을 원하는 형태의 CharSet으로 바꾸는 메서드.
     *
     * @param source  원본 문자열
     * @param charset CharSet
     * @return result 지정 charset으로 변환된 문자열
     */
    public static String toCharset(String source, String charset) {
        String ret = null;
        String result = "";
        if (source == null){
        	result = null;
        }else{
            try {
                ret = new String(source.getBytes("8859_1"), charset);
            } catch (UnsupportedEncodingException e) {
                ret = null;
            }
            result = ret;
        }
        return result;
    }

    /**
     * DB에 넣기 위해 single quotation 입력을 처리하는 메서드
     *
     * @param source 원본 문자열
     * @return single quotation 처리된 문자열
     */
    public static String procQuotation(String source) {
        String result = "";
        if (source == null){
        	result = null;
        }else{
        	result = replace(source, "'", "''");
        }
        return result;
    }

    /**
     * single quotation 입력을 처리하고 앞뒤로 single quotation을 추가하는 메서드
     *
     * @param source 원본 문자열
     * @return single quotation 처리된 문자열
     */

    public static String autoQuotation(String source) {

        return "'" + procQuotation(source) + "'";

    }

    /**
     * String의 공백을 제거한다.
     *
     * @param source 원본 문자열
     * @return null이 아닌 경우 공백 제거, null인 경우 empty String 리턴
     */
    public static String isNullTrim(String source) {
    	String result = "";
        if (source != null) {
        	result = source.trim();
        } else {
        	result = "";
        }
        return result;
    }

    /**
     * 문자열이 null인지 확인하고 null인 경우 지정된 문자열로 바꾸는 메서드
     *
     * @param source 원본 문자열
     * @param value  null일 경우 바뀔 문자열
     * @return resultVal 문자열
     */
    public static String isNullToString(String source, String value) {
        String retVal;
        if (source == null || source.length() < 1) {
            retVal = value;
        } else {
            retVal = source;
        }
        retVal = replace(retVal, "'", "`"); // add by khko 20030908 '를 `로 바꾼다
        return retVal;
    }

    /**
     * 문자배열이 null인지 확인하고 null인 경우 지정된 문자열로 바꾸는 메서드
     *
     * @param source 원본 문자배열
     * @param value  null일 경우 바뀔 문자열
     * @return resultVal 문자열
     */
    public static String isNull(String[] source, String value) {
        String retVal;
        if (source == null) {
            retVal = value;
        } else {
            retVal = source[0];
        }
        return retVal;
    }

    /**
     * 문자열이 null인지 확인하고 null인 경우 지정된 문자열로 바꾸는 메서드
     *
     * @param source 원본 문자배열
     * @param value  null일 경우 바뀔 문자열
     * @return resultVal 문자열
     */
    public static String isNull2(String source, String value) {
        String str;
        char ch;
        String result = "";
        int i;
        if (source == null) {
            str = value;
        } else {
            str = source;
        }

        try {
            for (i = 0; i < str.length(); i++) {
                ch = str.charAt(i);
                if (ch == '"') {
                    result += "\"";
                } else if (ch == '\'') {
                    result += "\"";
                } else {
                    result += ch;
                }
            }
        } catch (Exception e) {
            logger.error(MessageUtil.getErrorLog(e.getStackTrace()));
            result = "";
        }
        return result;
    }

    /**
     * 문자열이 null인지 확인하고 null인 경우 지정된 문자열로 바꾸는 함수. ',' 문자가 있는경우 제거한다.
     *
     * @param source 원본 문자열
     * @param value  null일경우 바뀔 문자열
     * @return 문자열
     */
    public static String isNull3(String source, String value) {
        String retVal;
        if (source == null || source.length() < 1) {
            retVal = value;
        } else {
            retVal = source;
        }
        retVal = replace(retVal, ",", ""); // add by khko 20030916 ','를 제거한다
        return retVal;
    }

    /**
     * 문자열을 int형으로 변환하고, null인지 확인하여 null인 경우 지정된 int로 바꾸는 메서드
     *
     * @param source 원본 문자열
     * @param value  null일 경우 바뀔 정수값
     * @return resultVal 변환된 정수
     */
    public static int isNullToInt(String source, int value) {
        int resultVal = 0;
        try {
            if (source == null || source.length() < 1) {
                resultVal = value;
            } else {
                resultVal = Integer.parseInt(source);
            }
        } catch (Exception e) {
            resultVal = value;
        }
        return resultVal;
    }

    /**
     * 문자열배열을 지정한 분리자에 의해 합한 문자열로 리턴하는 메서드.
     *
     * @param source    원본 문자열 배열
     * @param separator 분리자
     * @return 분리자 합친 문자열
     */
    public static String patch(String[] source, String separator) throws NullPointerException {
        return patch(source, separator, false);
    }

    /**
     * 문자열배열을 지정한 분리자에 의해 합한 문자열로 리턴하는 메서드.
     *
     * @param source        원본 문자열 배열
     * @param separator     분리자
     * @param isblankinsert 빈값에서 분리자를 표시할 지 여부
     * @return 분리자 합친 문자열
     */
    public static String patch(String[] source, String separator, boolean isblankinsert) throws NullPointerException {
        StringBuffer returnVal = new StringBuffer();
        int cnt = 0;
        if (source != null) {
            for (int i = 0; i < source.length; i++) {
                if (!isblankinsert) {
                    if (cnt != 0) returnVal.append(separator);
                    returnVal.append(isNullToString(source[i], ""));
                    cnt++;
                } else {
                    if (isNullToString(source[i], "").length() > 0) {
                        if (cnt != 0)
                            returnVal.append(separator);
                        returnVal.append(source[i]);
                        cnt++;
                    }
                }
            }
        }
        return returnVal.toString();
    }

    /**
     * 넘겨받은 문자열의 한글 문자열 포함 여부를 체크하는 메서드
     *
     * @param uni20 체크할 문자열
     * @return check 한글 문자열 포함 여부
     */
    public static boolean checkHan(String uni20) {
        boolean check = false;
        if (uni20 == null || uni20.equals("")) {
            check = false;
        } else {
            int len = uni20.length();
            char c;
            for (int i = 0; i < len; i++) {
                c = uni20.charAt(i);
                if (c < 0xac00 || 0xd7a3 < c) {
                    check = false;
                } else {
                    check = true;
                    break;
                }
            }
        }
        return check;
    }

    /**
     * 넘겨받은 두개의 문자열을 숫자로 변환하여 곱한 값을 반환하는 메서드
     *
     * @param a 첫번째 문자열
     * @param b 두번째 문자열
     * @return 두개의 문자열을 숫자로 변환하여 곱한 값
     */
    public static int calString(String a, String b) {
        int result = 0;
        if (a == null || a.equals("") || b == null || b.equals("")) {
            result = 0;
        } else {
            result = Integer.parseInt(isNullTrim(a)) * Integer.parseInt(isNullTrim(b));
        }
        return result;
    }

    /**
     * 숫자형 스트링을 Locale.KOREA 의 숫자형식으로 표시한다.
     *
     * @param number
     * @return 숫자형식의 문자열
     */
    public static String formatComma(String number) {
        return formatComma(Double.parseDouble(number));
    }

    /**
     * double 형 숫자를 Locale.KOREA 의 숫자형식으로 표시한다.(콤마표시)(김용훈 대리 요청)
     * 2005/06/18 다시 추가
     *
     * @param number
     * @return 숫자형식의 문자열
     */

    public static String formatComma(double number) {
        return formatComma(number, Locale.KOREA);
    }


    /**
     * 숫자형 스트링을 locale 의 숫자형식으로 표시한다.(콤마표시)(김용훈 대리 요청)
     * 2005/06/18 다시 추가
     *
     * @param number
     * @param locale
     * @return 숫자형식의 문자열
     */

    public static String formatComma(String number, Locale locale) {
        return formatComma(Double.parseDouble(number), locale);
    }


    /**
     * double 형 숫자를 locale 의 숫자형식으로 표시한다.(콤마표시)(김용훈 대리 요청)
     * 2005/06/18 다시 추가
     *
     * @param number
     * @param locale
     * @return 숫자형식의 문자열
     */
    public static String formatComma(double number, Locale locale) {
        NumberFormat form = NumberFormat.getInstance(locale);
        return form.format(number);
    }

    /**
     * 자리수만큼 0을 채워준다.
     *
     * @param length   - 자리수
     * @param tempContents - 내용
     * @return 자리 수 만큼 0을 채운 문자열
     */
    public static String fixNumericLength(int length, String contents) {
        String tempContents=contents;
        if (tempContents == null)
            tempContents = "";
        StringBuffer sb = new StringBuffer();
        int gap = length - tempContents.getBytes().length;
        for (int i = 0; i < gap; i++)
            sb.append("0");
        return sb.append(tempContents).toString();
    }

    /**
     * <p>
     * String 객체의 첫번째 캐릭터를 char 원시타입으로 반환한다. 비어 있는 String 객체일 때에는 Exception을
     * 던진다.
     * </p>
     * <p>
     * <pre>
     *    StringUtil.toChar(null) = IllegalArgumentException
     *    StringUtil.toChar(&quot;&quot;)   = IllegalArgumentException
     *    StringUtil.toChar(&quot;A&quot;)  = 'A'
     *    StringUtil.toChar(&quot;BA&quot;) = 'B'
     * </pre>
     *
     * @param str the character to convert
     * @return the char value of the first letter of the String
     * @throws IllegalArgumentException if the String is empty
     */
    public static char toChar(String str) {
        if (isEmpty(str)) {
            throw new IllegalArgumentException("The String must not be empty");
        }
        return str.charAt(0);
    }

    /**
     * <p>
     * String 객체의 첫번째 캐릭터를 char 원시타입으로 반환하며, <code>null</code>
     * <p>
     * 혹은 빈 문자열("")일 경우에는 defaultValue를 반환.
     * <p>
     * <p>
     * <p>
     * <pre>
     *   StringUtil.toChar(null, 'X') = 'X'
     *   StringUtil.toChar("", 'X')   = 'X'
     *   StringUtil.toChar("A", 'X')  = 'A'
     *   StringUtil.toChar("BA", 'X') = 'B'
     * </pre>
     *
     * @param str          the character to convert
     * @param defaultValue the value to use if the Character is null
     * @return the char value of the first letter of the String or the default
     * if null
     */
    public static char toChar(String str, char defaultValue) {
        char returnResult;
        if (StringUtil.isEmpty(str)) {
            returnResult = defaultValue;
        }else{
            returnResult = str.charAt(0);
        }
        return returnResult;
    }

    /**
     * <p>
     * 입력된 String의 앞과 뒤에서 공백문자(whitespace)를 모두 제거한다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * Whitespace is defined by {@link Character#isWhitespace(char)}.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * A <code>null</code> input String returns <code>null</code>.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     *
     * StringUtil.strip(null)     = null
     * StringUtil.strip("")       = ""
     * StringUtil.strip("   ")    = ""
     * StringUtil.strip("abc")    = "abc"
     * StringUtil.strip("  abc")  = "abc"
     * StringUtil.strip("abc  ")  = "abc"
     * StringUtil.strip(" abc ")  = "abc"
     * StringUtil.strip(" ab c ") = "ab c"
     * </pre>
     *
     * @param str the String to remove whitespace from, may be null
     * @return the stripped String, <code>null</code> if null String input
     */
    public static String strip(String str) {
        return strip(str, null);
    }

    /**
     * <p>
     * 입력된 String의 앞과 뒤에서 공백문자(whitespace)를 모두 제거한다. 입력 값이
     * <p>
     * <code>null</code>이면 빈문자열("")을 반환한다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * Whitespace is defined by {@link Character#isWhitespace(char)}.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.strip(null)     = ""
     * StringUtil.strip("")       = ""
     * StringUtil.strip("   ")    = ""
     * StringUtil.strip("abc")    = "abc"
     * StringUtil.strip("  abc")  = "abc"
     * StringUtil.strip("abc  ")  = "abc"
     * StringUtil.strip(" abc ")  = "abc"
     * StringUtil.strip(" ab c ") = "ab c"
     * </pre>
     *
     * @param str the String to be stripped, may be null
     * @return the trimmed String, or an empty String if <code>null</code> input
     */
    public static String stripToEmpty(String str) {
        return str == null ? EMPTY : strip(str, null);
    }

    /**
     * <p>
     * 입력된 String의 앞과 뒤에서 공백문자(whitespace)를 모두 제거한다. 공백을
     * <p>
     * 제거한 후의 값이 빈문자열("")이면 <code>null</code>을 반환한다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * Whitespace is defined by {@link Character#isWhitespace(char)}.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.strip(null)     = null
     * StringUtil.strip("")       = null
     * StringUtil.strip("   ")    = null
     * StringUtil.strip("abc")    = "abc"
     * StringUtil.strip("  abc")  = "abc"
     * StringUtil.strip("abc  ")  = "abc"
     * StringUtil.strip(" abc ")  = "abc"
     * StringUtil.strip(" ab c ") = "ab c"
     * </pre>
     *
     * @param tempStr the String to be stripped, may be null
     * @return the stripped String,
     * <p>
     * <code>null</code> if whitespace, empty or null String input
     */
    public static String stripToNull(String str) {
        String tempStr=str;
        if (tempStr == null) {
        	tempStr = null;
        }else{
            tempStr = strip(tempStr, null);
            tempStr = tempStr.length() == 0 ? null : tempStr;
        }
        return tempStr;
    }

    /**
     * <p>
     * Returns padding using the specified delimiter repeated
     * <p>
     * to a given length.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.padding(0, 'e')  = ""
     * StringUtil.padding(3, 'e')  = "eee"
     * StringUtil.padding(-2, 'e') = IndexOutOfBoundsException
     * </pre>
     *
     * @param repeat  number of times to repeat delim
     * @param padChar character to repeat
     * @return String with repeated character
     * @throws IndexOutOfBoundsException if <code>repeat &lt; 0</code>
     */
    private static String padding(int repeat, char padChar) {
        // be careful of synchronization in this method
        // we are assuming that get and set from an array index is atomic
        String pad = PADDING[padChar];
        if (pad == null) {
            pad = String.valueOf(padChar);
        }
        while (pad.length() < repeat) {
            pad = pad.concat(pad);
        }
        PADDING[padChar] = pad;
        return pad.substring(0, repeat);
    }

    /**
     * <p>
     * 문자열의 우측(끝)에 공백(' ')을 덧붙인다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * The String is padded to the size of <code>size</code>.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.rightPad(null, *)   = null
     * StringUtil.rightPad("", 3)     = "   "
     * StringUtil.rightPad("bat", 3)  = "bat"
     * StringUtil.rightPad("bat", 5)  = "bat  "
     * StringUtil.rightPad("bat", 1)  = "bat"
     * StringUtil.rightPad("bat", -1) = "bat"
     * </pre>
     *
     * @param str  the String to pad out, may be null
     * @param size the size to pad to
     * @return right padded String or original String if no padding is
     * necessary,
     * <p>
     * <code>null</code> if null String input
     */
    public static String rightPad(String str, int size) {
        return rightPad(str, size, ' ');
    }

    /**
     * <p>
     * 문자열의 우측(끝)에 지정한 문자(character)를 덧붙인다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * The String is padded to the size of <code>size</code>.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.rightPad(null, *, *)     = null
     * StringUtil.rightPad("", 3, 'z')     = "zzz"
     * StringUtil.rightPad("bat", 3, 'z')  = "bat"
     * StringUtil.rightPad("bat", 5, 'z')  = "batzz"
     * StringUtil.rightPad("bat", 1, 'z')  = "bat"
     * StringUtil.rightPad("bat", -1, 'z') = "bat"
     * </pre>
     *
     * @param str     the String to pad out, may be null
     * @param size    the size to pad to
     * @param padChar the character to pad with
     * @return right padded String or original String if no padding is
     * necessary,
     * <p>
     * <code>null</code> if null String input
     */
    public static String rightPad(String str, int size, char padChar) {
    	String result = "";
        if (str == null) {
        	result = null;
        }else{
            int pads = size - str.length();
            if (pads <= 0) {
            	result = str; // returns original String when possible
            }else  if (pads > PAD_LIMIT) {
            	result = rightPad(str, size, String.valueOf(padChar));
            }else {
            	result = str.concat(padding(pads, padChar));
            }
        }
        return result;
    }

    /**
     * <p>
     * 문자열의 우측(끝)에 지정한 문자열(String)을 덧붙인다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * The String is padded to the size of <code>size</code>.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.rightPad(null, *, *)      = null
     * StringUtil.rightPad("", 3, "z")      = "zzz"
     * StringUtil.rightPad("bat", 3, "yz")  = "bat"
     * StringUtil.rightPad("bat", 5, "yz")  = "batyz"
     * StringUtil.rightPad("bat", 8, "yz")  = "batyzyzy"
     * StringUtil.rightPad("bat", 1, "yz")  = "bat"
     * StringUtil.rightPad("bat", -1, "yz") = "bat"
     * StringUtil.rightPad("bat", 5, null)  = "bat  "
     * StringUtil.rightPad("bat", 5, "")    = "bat  "
     * </pre>
     *
     * @param tempStr    the String to pad out, may be null
     * @param size   the size to pad to
     * @param tempPadStr the String to pad with, null or empty treated as single space
     * @return right padded String or original String if no padding is
     * necessary,
     * <p>
     * <code>null</code> if null String input
     */
    public static String rightPad(String str, int size, String padStr) {
        String tempPadStr=padStr;
        String tempStr=str;
        String result = "";
        if (tempStr == null) {
        	result = null;
        }else{
            if (isEmpty(tempPadStr)) {
                tempPadStr = " ";
            }
            int padLen = tempPadStr.length();
            int strLen = tempStr.length();
            int pads = size - strLen;
            if (pads <= 0) {
            	result = tempStr; // returns original String when possible
            }else if (padLen == 1 && pads <= PAD_LIMIT) {
            	result = rightPad(tempStr, size, tempPadStr.charAt(0));
            }else if (pads == padLen) {
            	result = tempStr.concat(tempPadStr);
            } else if (pads < padLen) {
            	result = tempStr.concat(tempPadStr.substring(0, pads));
            } else {
                char[] padding = new char[pads];
                char[] padChars = tempPadStr.toCharArray();
                for (int i = 0; i < pads; i++) {
                    padding[i] = padChars[i % padLen];
                }
                result = tempStr.concat(new String(padding));
            }
        }
        return result;
    }

    /**
     * <p>
     * 문자열의 좌측에 공백(' ')을 덧붙인다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * The String is padded to the size of <code>size<code>.</p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.leftPad(null, *)   = null
     * StringUtil.leftPad("", 3)     = "   "
     * StringUtil.leftPad("bat", 3)  = "bat"
     * StringUtil.leftPad("bat", 5)  = "  bat"
     * StringUtil.leftPad("bat", 1)  = "bat"
     * StringUtil.leftPad("bat", -1) = "bat"
     * </pre>
     * <p>
     * <p>
     * <p>
     * &#64;param str  the String to pad out, may be null
     * <p>
     * &#64;param size  the size to pad to
     * <p>
     * &#64;return left padded String or original String if no padding is necessary,
     * <p>
     * <code>null</code> if null String input
     */
    public static String leftPad(String str, int size) {
        return leftPad(str, size, ' ');
    }

    /**
     * <p>
     * 문자열의 좌측에 지정한 문자(character)를 덧붙인다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * Pad to a size of <code>size</code>.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.leftPad(null, *, *)     = null
     * StringUtil.leftPad("", 3, 'z')     = "zzz"
     * StringUtil.leftPad("bat", 3, 'z')  = "bat"
     * StringUtil.leftPad("bat", 5, 'z')  = "zzbat"
     * StringUtil.leftPad("bat", 1, 'z')  = "bat"
     * StringUtil.leftPad("bat", -1, 'z') = "bat"
     * </pre>
     *
     * @param str     the String to pad out, may be null
     * @param size    the size to pad to
     * @param padChar the character to pad with
     * @return left padded String or original String if no padding is necessary,
     * <p>
     * <code>null</code> if null String input
     * @since 2.0
     */
    public static String leftPad(String str, int size, char padChar) {
        String returnResult=null;
        if (str != null) {
            int pads = size - str.length();
            if (pads <= 0) {
                returnResult = str; // returns original String when possible
            }else if (pads > PAD_LIMIT) {
                returnResult = leftPad(str, size, String.valueOf(padChar));
            }else{
                returnResult = padding(pads, padChar).concat(str);
            }
        }
        return returnResult;
    }

    /**
     * <p>
     * 문자열의 좌측에 지정한 문자열(String)을 덧붙인다..
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * Pad to a size of <code>size</code>.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.leftPad(null, *, *)      = null
     * StringUtil.leftPad("", 3, "z")      = "zzz"
     * StringUtil.leftPad("bat", 3, "yz")  = "bat"
     * StringUtil.leftPad("bat", 5, "yz")  = "yzbat"
     * StringUtil.leftPad("bat", 8, "yz")  = "yzyzybat"
     * StringUtil.leftPad("bat", 1, "yz")  = "bat"
     * StringUtil.leftPad("bat", -1, "yz") = "bat"
     * StringUtil.leftPad("bat", 5, null)  = "  bat"
     * StringUtil.leftPad("bat", 5, "")    = "  bat"
     * </pre>
     *
     * @param str    the String to pad out, may be null
     * @param size   the size to pad to
     * @param tempPadStr the String to pad with, null or empty treated as single space
     * @return left padded String or original String if no padding is necessary,
     * <p>
     * <code>null</code> if null String input
     */
    public static String leftPad(String str, int size, String padStr) {
        String tempPadStr=padStr;
        String returnResult=null;
        if (str != null) {
            if (isEmpty(tempPadStr)) {
                tempPadStr = " ";
            }

            int padLen = tempPadStr.length();
            int strLen = str.length();
            int pads = size - strLen;
            if (pads <= 0) {
                returnResult = str; // returns original String when possible
            }else{
                if (padLen == 1 && pads <= PAD_LIMIT) {
                    returnResult = leftPad(str, size, tempPadStr.charAt(0));
                }else{
                    if (pads == padLen) {
                        returnResult = tempPadStr.concat(str);
                    } else if (pads < padLen) {
                        returnResult = tempPadStr.substring(0, pads).concat(str);
                    } else {
                        char[] padding = new char[pads];
                        char[] padChars = tempPadStr.toCharArray();
                        for (int i = 0; i < pads; i++) {
                            padding[i] = padChars[i % padLen];
                        }
                        returnResult = new String(padding).concat(str);
                    }
                }
            }
        }
        return returnResult;
    }

    /**
     * <p>
     * 입력된 문자열 값이 <code>null</code>인 경우, 빈문자열("")을 반환.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.defaultString(null)  = ""
     * StringUtil.defaultString("")    = ""
     * StringUtil.defaultString("bat") = "bat"
     * </pre>
     *
     * @param str the String to check, may be null
     * @return the passed in String, or the empty String if it
     * <p>
     * was <code>null</code>
     * @see String#valueOf(Object)
     */
    public static String defaultString(String str) {
        return str == null ? EMPTY : str;
    }

    /**
     * <p>
     * 입력된 문자열 값이 <code>null</code>인 경우, 두번째 인자 값을 반환한다.
     * <p>
     * <code>null</code>아닌 경우 그대로 반환.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.defaultString(null, "NULL")  = "NULL"
     * StringUtil.defaultString("", "NULL")    = ""
     * StringUtil.defaultString("bat", "NULL") = "bat"
     * </pre>
     *
     * @param str        the String to check, may be null
     * @param defaultStr the default String to return
     *                   <p>
     *                   if the input is <code>null</code>, may be null
     * @return the passed in String, or the default if it was <code>null</code>
     * @see String#valueOf(Object)
     */
    public static String defaultString(String str, String defaultStr) {
        return str == null ? defaultStr : str;
    }

    /**
     * <p>
     * 문자열에서 숫자만 추출한다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.keepNumberChar(null)       = null
     * StringUtil.keepNumberChar("")         = ""
     * StringUtil.keepNumberChar("1한글5과숫자1234") = "151234"
     * StringUtil.keepNumberChar("abc한글과123영문과숫자423098") = "123423098"
     * </pre>
     *
     * @param str the source String to search, may be null
     * @return 0~9 character로만 구성된 문자열,
     * <p>
     * <code>null</code> if null String input
     */
    public static String keepNumberChar(String str) {
    	String result = "";
        if (str == null) {
        	result = null;
        }else{
            StringBuffer buffer = new StringBuffer(str.length());
            char[] chrs = str.toCharArray();
            int sz = chrs.length;
            for (int i = 0; i < sz; i++) {
                if (47 < chrs[i] && chrs[i] < 58) {
                    buffer.append(chrs[i]);
                }
            }
            result = buffer.toString();
        }
        return result;
    }

    /**
     * <p>
     * 주민등록번호에 분리자('-') 추가.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.insertMinusCharInSsn(null) = null
     * StringUtil.insertMinusCharInSsn("8001291018717") = "800129-1018717"
     * StringUtil.insertMinusCharInSsn("8001012017212") = "800101-2017212"
     * StringUtil.insertMinusCharInSsn("7504011010")    = IllegalArgumentException
     * </pre>
     *
     * @param ssn 구분자가 없이 숫자만으로 이루어진 주민등록번호 문자열
     * @return '-' 구분자가 삽입된 주민등록번호 문자열,
     * <p>
     * <code>null</code> if null String input
     */
    public static String insertMinusCharInSsn(String ssn) {
        String returnResult=null;
        if (ssn != null) {
            if (ssn.trim().length() != 13) {
                throw new IllegalArgumentException("Invalid SSN: " + ssn + " Length=" + ssn.trim().length());
            }
            returnResult = new StringBuffer(ssn).insert(6, '-').toString();
        }
        return returnResult;
    }

    /**
     * <p>
     * 입력된 문자열을 <code>repeat</code>에 지정한 횟수만큼 반복해서 붙인 후
     * <p>
     * 반환한다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.repeat(null, 2) = null
     * StringUtil.repeat("", 0)   = ""
     * StringUtil.repeat("", 2)   = ""
     * StringUtil.repeat("a", 3)  = "aaa"
     * StringUtil.repeat("ab", 2) = "abab"
     * StringUtil.repeat("a", -2) = ""
     * </pre>
     *
     * @param str    the String to repeat, may be null
     * @param repeat number of times to repeat str, negative treated as zero
     * @return a new String consisting of the original String repeated,
     * <p>
     * <code>null</code> if null String input
     */
    public static String repeat(String str, int repeat) {
        return StringUtils.repeat(str, repeat);
        /*
        String returnResult=null;
        if (str != null) {
            if (repeat <= 0) {
                returnResult = EMPTY;
            }else{
                int inputLength = str.length();
                if (repeat == 1 || inputLength == 0) {
                    returnResult = str;
                }else{
                    if (inputLength == 1 && repeat <= PAD_LIMIT) {
                        returnResult = padding(repeat, str.charAt(0));
                    }else{
                        int outputLength = inputLength * repeat;
                        switch (inputLength) {
                            case 1:
                                char ch = str.charAt(0);
                                char[] output1 = new char[outputLength];
                                for (int i = repeat - 1; i >= 0; i--) {
                                    output1[i] = ch;
                                }
                                returnResult = new String(output1);
                            case 2:
                                char ch0 = str.charAt(0);
                                char ch1 = str.charAt(1);
                                char[] output2 = new char[outputLength];
                                for (int i = repeat * 2 - 2; i >= 0; i--, i--) {
                                    output2[i] = ch0;
                                    output2[i + 1] = ch1;
                                }
                                returnResult = new String(output2);

                            default:
                                StringBuffer buf = new StringBuffer(outputLength);
                                for (int i = 0; i < repeat; i++) {
                                    buf.append(str);
                                }
                                returnResult = buf.toString();
                        }
                    }
                }
            }
        }
        
        return returnResult;
        */
    }

    /**
     * <p>
     * 지정한 <code>len</code> 숫자만큼 우측에서 문자열을 추출한다.
     * <p>
     * <p>
     * <p>
     * <p>
     * <p>
     * If <code>len</code> characters are not available, or the String
     * <p>
     * is <code>null</code>, the String will be returned without an
     * <p>
     * an exception. An exception is thrown if len is negative.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.right(null, *)    = null
     * StringUtil.right(*, -ve)     = ""
     * StringUtil.right("", *)      = ""
     * StringUtil.right("abc", 0)   = ""
     * StringUtil.right("abc", 2)   = "bc"
     * StringUtil.right("abc", 4)   = "abc"
     * </pre>
     *
     * @param str the String to get the rightmost characters from, may be null
     * @param len the length of the required String, must be zero or positive
     * @return the rightmost characters, <code>null</code> if null String input
     */
    public static String right(String str, int len) {
        String returnResult=null;
        if (str != null) {
            if (len < 0) {
                returnResult = EMPTY;
            }else if (str.length() <= len) {
                returnResult = str;
            } else {
                returnResult = str.substring(str.length() - len);
            }
        }
        return returnResult;
    }

    /**
     * <p>
     * 문자열에서 newline character(\n, \r)를 모두 제거한다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.removeEnterChar(null) = null
     * StringUtil.removeEnterChar("") = ""
     * StringUtil.removeEnterChar("\r\n\n\n\r\r\n") = ""
     * StringUtil.removeEnterChar("\n\u00A0\n\r\u202F\r") = "\u00A0\u202F"
     * StringUtil.removeEnterChar("\n\r한글\r") = "한글"
     * StringUtil.removeEnterChar("소나기가 \r\n내리는 \r\n밤이었습니다") = "소나기가 내리는 밤이었습니다"
     * StringUtil.removeEnterChar("소나기가 \n내리는 \n밤이었습니다") = "소나기가 내리는 밤이었습니다"
     * </pre>
     *
     * @param str the String to delete newline from, may be null
     * @return the String without newline, <code>null</code> if null String
     * input
     */
    public static String removeEnterChar(String str) {
    	String result = "";
        if (isEmpty(str)) {
        	result = str;
        }else{
            int sz = str.length();
            char[] chs = new char[sz];
            int count = 0;
            for (int i = 0; i < sz; i++) {
                if (str.charAt(i) != '\n' && str.charAt(i) != '\r') {
                    chs[count++] = str.charAt(i);
                }
            }
            if (count == sz) {
            	result= str;
            }else{
            	result = new String(chs, 0, count);
            }
        }
        return result;
    }

    /**
     * <p>
     * 입력 문자열의 크기를 조정한다. 문자열이 주어진 <code>size</code> 보다 길면
     * <p>
     * 자르고, 작으면 공백(' ')을 뒤에 추가한다
     * <p>
     * (2byte 문자(한글)의 경우 길이를 2로 간주한다).
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * 2byte 문자가 1byte만 잘려야 할 경우 해당 문자를 버린다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.rightPadOrSubsting("abc영어공부", 4)  = "abc"
     * StringUtil.rightPadOrSubsting("abc영어공부", 5)  = "abc영"
     * StringUtil.rightPadOrSubsting("abc영어공부", 9)  = "abc영어공"
     * StringUtil.rightPadOrSubsting("abc영어공부", 11) = "abc영어공부"
     * StringUtil.rightPadOrSubsting("abc영어공부", 12) = "abc영어공부 "
     * StringUtil.rightPadOrSubsting("abc영어공부", 16) = "abc영어공부     "
     * </pre>
     *
     * @param str  the String to pad out, may be null
     * @param size the size to pad to
     * @return 문자열을 주어진 길이로 자르거나, 뒤에 공백을 붙여서 반환한다. 문자열 길이와
     * <p>
     * 주어진 길이가 같을 경우 주어진 문자열을 반환한다.
     * <p>
     * <code>null</code> if null String input
     */
    /*
    public static String rightPadOrSubsting(String str, int size) {
        String returnResult=null;
        if (str != null) {
            int strLen = str.getBytes().length;
            int pads = size - strLen;
            if (pads == 0) {
                returnResult = str;
            } else if (pads > 0) {
                returnResult = rightPad2(str, size, ' ');
            } else {
                returnResult = substring2ByteString(str, size);
            }
        }
        return returnResult;
    }*/

    /**
     * <p>
     * 지정한 <code>size</code>가 될 때까지 <code>padStr</code>을 <code>str</code>의
     * <p>
     * 우측에 붙인다(2byte 문자(한글)의 경우 길이를 2로 간주한다).<br>
     * <p>
     * <code>padStr</code>가 <code>null</code>이거나 빈 문자열("")이면 공백문자(' ')를
     * <p>
     * 사용한다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * 2byte 문자가 1byte만 잘려야 할 경우 해당 문자를 버린다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.rightPad2("한글과 abc", 4, null) = "한글과 abc"
     * StringUtil.rightPad2("한글과 abc", 4, "") = "한글과 abc"
     * StringUtil.rightPad2("한글과 abc", 11, null) = "한글과 abc "
     * StringUtil.rightPad2("한글과 abc", 11, "") = "한글과 abc "
     * StringUtil.rightPad2("한글과 abc", 12, "a") = "한글과 abcaa"
     * StringUtil.rightPad2("한글과 abc", 12, "한글") = "한글과 abc한"
     * StringUtil.rightPad2("한글과 abc", 13, "한글") = "한글과 abc한"
     * </pre>
     *
     * @param str    the String to pad out, may be null
     * @param size   the size to pad to
     * @param tempPadStr the String to pad with, null or empty treated as single space
     * @return right padded String or original String if no padding is
     * necessary,
     * <p>
     * <code>null</code> if null String input
     */
    /*
    public static String rightPad2(String str, int size, String padStr) {
        String tempPadStr=padStr;
        String returnResult=null;
        if (str != null) {
            if (isEmpty(tempPadStr)) {
                tempPadStr = " ";
            }

            // 2byte character는 2자리로 계산해야하기 때문...
            int padLen = tempPadStr.getBytes().length;
            int strLen = str.getBytes().length;
            int pads = size - strLen;
            if (pads <= 0) {
                returnResult = str; // returns original String when possible
            }else{
                // 2byte character는 1이 될 수 없음...
                if (padLen == 1 && pads <= PAD_LIMIT) {
                    returnResult = rightPad2(str, size, tempPadStr.charAt(0));
                }else{
                    if (pads == padLen) {
                        returnResult = str.concat(tempPadStr);
                    } else if (pads < padLen) {
                        returnResult = str.concat(substring2ByteString(tempPadStr, pads));
                    } else {
                        int gap = padLen - tempPadStr.length();
                        char[] padChars = tempPadStr.toCharArray();
                        char[] padding = new char[pads];
                        if (gap == 0) {
                            for (int i = 0; i < pads; i++) {
                                padding[i] = padChars[i % padLen];
                            }
                            returnResult = str.concat(new String(padding));
                        } else {
                            int padLen2 = tempPadStr.length();
                            for (int i = 0; i < pads - gap; i++) {
                                padding[i] = padChars[i % padLen2];
                            }
                            returnResult = substring2ByteString(str.concat(new String(padding)), size);
                        }
                    }
                }
            }
        }
        return returnResult;
    }*/

    /**
     * <p>
     * 공백문자(' ')를 지정한 길이가 될 때까지 우측에 덧붙인다
     * <p>
     * (2byte 문자(한글)의 경우 길이를 2로 간주한다).
     * </p>
     * <p>
     * <p>
     * <p>
     * <p>
     * The String is padded to the size of <code>size</code>.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.rightPad2("한글", 0)   = "한글"
     * StringUtil.rightPad2("한글", 1)   = "한글"
     * StringUtil.rightPad2("한글", 4)   = "한글"
     * StringUtil.rightPad2("한글", 5)   = "한글 "
     * StringUtil.rightPad2("한글", 10)  = "한글      "
     * StringUtil.rightPad2("한글a", 10) = "한글a     "
     * </pre>
     *
     * @param str  the String to pad out, may be null
     * @param size the size to pad to
     * @return right padded String or original String if no padding is
     * necessary,
     * <p>
     * <code>null</code> if null String input
     */
    /*public static String rightPad2(String str, int size) {
        return rightPad2(str, size, ' ');

    }

    *//**
     * <p>
     * 지정한 <code>size</code>가 될 때까지 <code>padChar</code>를 <code>str</code>의
     * <p>
     * 우측에 붙인다(2byte 문자(한글)의 경우 길이를 2로 간주한다).<br>
     * <p>
     * <code>padChar</code>가 <code>null</code>이거나 빈 문자열("")이면 공백문자(" ")를
     * <p>
     * 사용한다.
     * </p>
     * <p>
     * <p>
     * <p>
     * <pre>
     * StringUtil.rightPad2("한글", 3, null) = "한글"
     * StringUtil.rightPad2("한글", 4, null) = "한글"
     * StringUtil.rightPad2("한글", 5, null) = "한글 "
     * StringUtil.rightPad2("한글", 5, ' ') = "한글 "
     * StringUtil.rightPad2("한글", 5, 'a') = "한글a"
     * StringUtil.rightPad2("한글", 5, '\n') = "한글\n"
     * StringUtil.rightPad2("abc와 한글", 11, 'z') = "abc와 한글z"
     * StringUtil.rightPad2("abc와 한글", 15, 'z') = "abc와 한글zzzzz"
     * </pre>
     *
     * @param str     the String to pad out, may be null
     * @param size    the size to pad to
     * @param padChar the character to pad with
     * @return right padded String or original String if no padding is
     * necessary,
     * <p>
     * <code>null</code> if null String input
     *//*
    public static String rightPad2(String str, int size, char padChar) {
    	String result = "";
        if (str == null) {
        	result = null;
        }else{
            int pads = size - str.getBytes().length;
            if (pads <= 0) {
            	result = str; // returns original String when possible
            }else{
                if (pads > PAD_LIMIT) {
                	result = rightPad2(str, size, String.valueOf(padChar));
                }else{
                	result = str.concat(padding2(pads, padChar));
                }
            }
        }
        return result;
    }*/
    /*
    private static String padding2(int repeat, char padChar) {

        // be careful of synchronization in this method

        // we are assuming that get and set from an array index is atomic
        String pad = PADDING[padChar];
        if (pad == null) {
            pad = String.valueOf(padChar);
        }
        while (pad.length() < repeat) {
            pad = pad.concat(pad);
        }
        PADDING[padChar] = pad;
        return substring2ByteString(pad, repeat);

    }*/

    public static String substring2ByteString(String str, int endIndex) {
    	String result = "";
        if (str == null) {
        	result = null;
        }else{
            byte[] strByte = str.getBytes();
            int i, strLen;
            strLen = strByte.length;
            if (strLen <= endIndex) {
            	result = str;
            }else{
                int cnt = 0;
                for (i = 0; i < endIndex; i++) {
                    if (((strByte[i]) & 0xff) > 0x80) {
                        cnt++;
                    }
                }
                if ((cnt % 2) == 1) {
                    i--;
                }
                result = new String(strByte, 0, i);
            }
        }
        return result;
    }

    public static String changeHtmlToText(String strString) {
        String strNew = "";
        try {
            StringBuffer strTxt = new StringBuffer("");
            char chrBuff;
            int len = 0;
            int i = 0;
            len = strString.length();
            for (i = 0; i < len; i++) {
                chrBuff = strString.charAt(i);
                switch (chrBuff) {
                    case '<':
                        strTxt.append("&lt");
                        break;
                    case '>':
                        strTxt.append("&gt");
                        break;
                    case 10:
                        strTxt.append("<br>");
                        break;
                    case 13:
                        // strTxt.append("<br>");
                        break;
                    case ' ':
                        strTxt.append(" ");
                        break;
                    default:
                        strTxt.append(chrBuff);
                }// switch
            } // for
            strNew = strTxt.toString();
        } catch (Exception ex) {
        	logger.error(MessageUtil.getErrorLog(ex.getStackTrace()));
        }
        return strNew;

    }

    public static String toHtmlString(String str) {
    	String result = "";
        if (str == null){
        	result = "";
        }else if ("".equals(str)){
        	result = "-";
        }else{
            String tempStr = replace(str, "\n", "<br>");
            if(tempStr != null && !tempStr.equals("")){
                tempStr = StringUtil.replaceString(tempStr, "<a href", "<ahref");
                tempStr = StringUtil.replace(tempStr, " ", "&nbsp;");
                tempStr = StringUtil.replaceString(tempStr, "<ahref", "<a href");
                result = tempStr;
            }
        }
        return result;

    }

    public static String toHtmlString(String str, String clsName) {
    	String result = "";
        if (str == null){
        	result = "";
        }else if ("".equals(str)){
        	result = "-";
        }else{
            String tempStr = replace(str, "\n", "<br>");
            tempStr = StringUtil.replaceString(tempStr, "<a href", "<ahref");
            tempStr = StringUtil.replace(tempStr, " ", "&nbsp;");
            tempStr = StringUtil.replaceString(tempStr, "<ahref", "<a class='" + clsName + "' href");
            result = tempStr;
        }
        return result;

    }

    public static String tagRemove(String s) {
        StringBuffer stripHtml = new StringBuffer();
        char[] buf = s.toCharArray();
        int j = 0;
        for (; j < buf.length; j++) {
            if (buf[j] == '<') {
                for (; j < buf.length; j++) {
                    if (buf[j] == '>') {
                        break;
                    }
                }
            } else {
                stripHtml.append(buf[j]);
            }
        }
        return stripHtml.toString();
    }

    public static String replaceDang(String str) {
        String tempStr=str;
        if (tempStr != null && !tempStr.equals("")) {
            tempStr = StringUtil.null2space(tempStr);
            tempStr = StringUtil.replaceString(tempStr, "'", "&#39;");
            tempStr = StringUtil.replaceString(tempStr, "\"", "&quot;");
        }
        return tempStr;
    }

    public static String replaceDangRev(String str) {
        String tempStr=str;
        if (tempStr != null && !tempStr.equals("")) {
            tempStr = StringUtil.replaceString(tempStr, "&#39;", "'");
            tempStr = StringUtil.replaceString(tempStr, "&quot;", "\"");
        }
        return tempStr;
    }

    public static String replaceAmp(String str) {
        String tempStr=str;
        if (tempStr != null && !tempStr.equals("")) {
            tempStr = StringUtil.null2space(tempStr);
            tempStr = StringUtil.replaceString(tempStr, "&", "&amp;");
        }
        return tempStr;
    }

    public static String replaceAmpRev(String str) {
        String tempStr=str;
        if (tempStr != null && !tempStr.equals("")) {
            tempStr = StringUtil.replaceString(tempStr, "&amp;", "&");
        }
        return tempStr;
    }

    public static String checkHtmlEdit(String strString) {

        String strNew = "";
        try {
            StringBuffer strTxt = new StringBuffer("");
            char chrBuff;
            int len = strString.length();
            for (int i = 0; i < len; i++) {
                chrBuff = strString.charAt(i);
                switch (chrBuff) {
                    case '<':
                        strTxt.append("&lt;");
                        break;
                    case '>':
                        strTxt.append("&gt;");
                        break;
                    case '"':
                        strTxt.append("&quot;");
                        break;
                    // case '&' :

                    // strTxt.append("&amp;");

                    // break;
                    default:
                        strTxt.append(chrBuff);
                }
            }
            strNew = strTxt.toString();
        } catch (Exception ex) {
            strNew = "";
        }
        return strNew;
    }

    public static String byteCutLine(String str, int cut, String pushChar) {
        String tempStr1=str;
        String result = "";
        if (tempStr1 == null){
        	result = null;
        } else {
            int kk = tempStr1.lastIndexOf("&nbsp;");
            String nbstr = "";
            if (kk != (-1)) {
                tempStr1 = tempStr1.substring(kk + 6);
            }
            byte[] bl = tempStr1.getBytes();
            if (bl.length <= cut){
            	result = tempStr1;
            }else{
                int size = (int) (Math.ceil((float) bl.length / (float) cut));
                StringBuffer reVal = new StringBuffer();
                String tempStr = tempStr1;
                for (int i = 0; i < size - 1; i++) {
                    byte[] temp1 = new byte[cut];
                    System.arraycopy(tempStr.getBytes(), 0, temp1, 0, cut);
                    String val = new String(temp1);
                    int idx = val.length();
                    reVal.append(tempStr.substring(0, idx + 1) + "<br>" + pushChar);
                    tempStr = tempStr.substring(idx + 1, tempStr.length());
                }
                reVal.append(tempStr);
                result = nbstr + reVal.toString();
            }
        }
        return result;
    }

    public static String replaceString(String str, String src, String tgt) {
        StringBuffer ret = new StringBuffer();
        String result = "";
        if (str == null){
        	result = null;
        }else if (str.equals("")){
        	result = "";
        }else{
            int start = 0;
            int found = str.indexOf(src);
            while (found >= 0) {
                if (found > start)
                    ret.append(str.substring(start, found));
                if (tgt != null)
                    ret.append(tgt);
                start = found + src.length();
                found = str.indexOf(src, start);
            }
            if (str.length() > start)
                ret.append(str.substring(start, str.length()));
            result = ret.toString();
        }
        return result;
    }

    public static String null2space(String s) {
    	String result = "";
        if (s == null || s.length() == 0) {
        	result = "";
        }else{
        	result = s.trim();
        }
        return result;
    }

    public static String getSum(String arrString, int scale) {
    	String result = "";
        if (arrString == null) {
        	result = "0";
        }else{
            String[] val = arrString.split(",");
            BigDecimal sum = new BigDecimal(0);
            BigDecimal denominator = new BigDecimal(1);
            for (int i = 0; i < val.length; i++) {
                if (val[i] != null) {
                    BigDecimal calVal = new BigDecimal(val[i]);
                    sum = sum.add(calVal);
                }
            }
            sum = sum.divide(denominator, scale, BigDecimal.ROUND_HALF_UP);
            result = String.valueOf(sum);
        }
        return result;
    }

    public static String getAverage(String arrString, int scale) {
    	String result = "";
        if (arrString == null){
        	result = "0";
        }else{
            String[] val = arrString.split(",");
            BigDecimal sum = new BigDecimal(0);
            BigDecimal denominator = new BigDecimal(val.length);
            for (int i = 0; i < val.length; i++) {
                if (val[i] != null) {
                    BigDecimal calVal = new BigDecimal(val[i]);
                    sum = sum.add(calVal);
                }
            }
            sum = sum.divide(denominator, scale, BigDecimal.ROUND_HALF_UP);
            result = String.valueOf(sum);
        }
        return result;

    }

    public static String getAverage(String arrString, float deno, int scale) {
    	String result = "";
        if (arrString == null){
        	result = "0";
        }else{
            String[] val = arrString.split(",");
            BigDecimal sum = new BigDecimal(0);
            BigDecimal denominator = new BigDecimal(deno);
            for (int i = 0; i < val.length; i++) {
                if (val[i] != null) {
                    BigDecimal calVal = new BigDecimal(val[i]);
                    sum = sum.add(calVal);
                }
            }
            sum = sum.divide(denominator, scale, BigDecimal.ROUND_HALF_UP);
            result = String.valueOf(sum);
        }
        return result;
    }

    public static String UTF8Decode(byte in[], int offset, int length) {

        StringBuffer buff = new StringBuffer();

        int max = offset + length;

        for (int i = offset; i < max; i++) {

            char c = 0;

            if ((in[i] & 0x80) == 0) {

                c = (char) in[i];

            } else if ((in[i] & 0xe0) == 0xc0) // 11100000

            {

                c |= ((in[i] & 0x1f) << 6); // 00011111

                i++;

                c |= ((in[i] & 0x3f) << 0); // 00111111

            } else if ((in[i] & 0xf0) == 0xe0) // 11110000

            {

                c |= ((in[i] & 0x0f) << 12); // 00001111

                i++;

                c |= ((in[i] & 0x3f) << 6); // 00111111

                i++;

                c |= ((in[i] & 0x3f) << 0); // 00111111

            } else if ((in[i] & 0xf8) == 0xf0) // 11111000

            {

                c |= ((in[i] & 0x07) << 16); // 00000111

                i++;

                c |= ((in[i] & 0x3f) << 12); // 00111111

                i++;

                c |= ((in[i] & 0x3f) << 6); // 00111111

                i++;

                c |= ((in[i] & 0x3f) << 0); // 00111111

            } else {

                c = '?';

            }

            buff.append(c);

        }

        return buff.toString();

    }
/*
    // 2014-08-10 | 노명선 | 협력사 직원 CI 적용 관련

    // 주민번호 유효성 체크(CI채번 : 앞에7자리에 대해서만 유효성체크)

    public static String isJuminForCi(String sJumin) {

        String errRsn = "";
        String jumin = isNullToString(sJumin, "");
        int sexScnCd = 0;
        int mm = 0;
        int dd = 0;
        String result = "";
        boolean isYymmdd = true;
        if ("".equals(jumin)) {
        	result = "주민번호가 누락되었습니다.";
        }else{
            jumin = jumin.replaceAll("-", "");
            // 길이체크 7자리 이하 체크
            if (jumin.length() < 7) {
                errRsn = "주민번호 길이가 맞지 않습니다. ";
            } else {
    			try {
    				Integer.parseInt(jumin.substring(0, 2));
    				mm = Integer.parseInt(jumin.substring(2, 4));
    				dd = Integer.parseInt(jumin.substring(4, 6));
    				if (mm < 1 || mm > 12) {
    					isYymmdd = false;
    				}
    				switch (mm) {
    				case 2:
    					if (dd < 1 || dd > 29) {
    						isYymmdd = false;
    					}
    					break;
    				default:
    					if (mm == 4 || mm == 6 || mm == 9 || mm == 11) {
    						if (dd < 1 || dd > 30) {
    							isYymmdd = false;
    						}
    					} else {
    						if (dd < 1 || dd > 31) {
    							isYymmdd = false;
    						}
    					}
    					break;
    				}
    				if (!isYymmdd) {
    					result = "생년월일을 확인해 주세요.";
    				}else{
        				sexScnCd = Integer.parseInt(jumin.substring(6, 7));
        				if (sexScnCd <= 0 || sexScnCd > 8) {
        					result = "성별을 확인해 주세요.";
        				}else{
        					Integer.parseInt(jumin.substring(7));
        				}
    				}
    			} catch (Exception e) {
    				errRsn = "주민번호는 숫자로 이루어져야 합니다.";
    			}
    		}
            result = errRsn;
        }
        return result;
    }*/

    /**
     * Object VO 에 변수명과 변수값을 Keyset형태에 리스트로 가져옴
     * Statements
     *
     * @param object
     * @return
     */
    public static List<HashMap<String, Object>> getFieldSet(Object object) {
    	List<HashMap<String, Object>> result = new ArrayList<HashMap<String, Object>>();
    	try {
        	if(object != null){
        		for(Field field :  object.getClass().getDeclaredFields()){
        			HashMap<String, Object> data = new HashMap<String, Object>();
        			field.setAccessible(true);
        			Object value = field.get(object);
        			if(value  != null){
        				data.put("fieldKey", field.getName());
        				data.put("fieldValue", value);
        				result.add(data);
        			}
        		}
        	}
		} catch (Exception e) {
			result = null;
		}
    	return result;
    }

    /**
     * 맵핑값 변경
     *
     * @param msg
     * @param msgArgs
     * @return
     */
    public static String getStringFormatMapper(String msg, String[] msgArgs) throws PatternSyntaxException, NumberFormatException, Exception{
    	String result = msg;

    	String preFix = "{";
    	String postFix = "}";

    	Pattern pattern = Pattern.compile("(\\"+preFix+"[0-9]*\\"+postFix+")");
    	try {
        	Matcher matcher = pattern.matcher(result);
        	if(matcher != null){
            	while (matcher.find()) {
            		String matGroup = matcher.group();
            		int mat = Integer.parseInt(replace(replace(matGroup, preFix, ""), postFix, ""));
        			result = replace(result, matGroup, msgArgs[mat]);
            	}
    		}
		} catch (NullPointerException e) {
			logger.error("패턴 일치하는 항목 없음.");
		}

    	return result;
    }

    /**
     * TEXT Byte Check
     *
     * @param text
     * @param len
     * @return
     */
    public static boolean getByteCheck(String text, int len){
    	boolean result = false;
    	if(isNullToString(text).equals("")){
    		result = true;
    	}else{
    		int en = 0;
    		int ko = 0;
    		int etc = 0;

    		char[] textChar = text.toCharArray();
    		for(int j = 0 ; j < text.length() ; j++){
    			if(textChar[j] >= 'A' && textChar[j] <= 'z'){
    				en++;
    			}else if(textChar[j] >= '\uAC00' && textChar[j] <= '\uD7A3'){
    				ko++;
    				ko++;
    				ko++;
    			}else{
    				etc++;
    			}
    		}
    		int textByte = en + ko + etc;
    		if(textByte > len){
    			result = false;
    		}else{
    			result = true;
    		}
    	}

    	return result;
    }


    /**
     * 바이트 사이즈 취득
     *
     * @param text
     * @return
     * @throws UnsupportedEncodingException
     */
    public static int getByteLength(String text) throws UnsupportedEncodingException {
        return getByteLength(text, "EUC-KR");
    }

    /**
     * 바이트 사이즈 취득
     *
     * @param text
     * @param encodingType
     * @return
     * @throws UnsupportedEncodingException
     */
    public static int getByteLength(String text, String encodingType) throws UnsupportedEncodingException {
        return StringUtils.defaultString(text).getBytes(encodingType).length;
    }

    /**
     * 최대 바이트 여부
     *
     * @param text
     * @param len
     * @return
     * @throws UnsupportedEncodingException
     */
    public static boolean isMaxByteLength(String text, int len) throws UnsupportedEncodingException {
        return isMaxByteLength(text, len, "EUC-KR");
    }

    /**
     * 최대 바이트 여부
     *
     * @param text
     * @param len
     * @param encodingType
     * @return
     * @throws UnsupportedEncodingException
     */
    public static boolean isMaxByteLength(String text, int len, String encodingType) throws UnsupportedEncodingException {

        boolean isLen = true;

        if (StringUtils.isNotBlank(text)) {

            int chkLen = 0;
            for (int i = 0; i < text.length(); i++) {
                chkLen += getByteLength(StringUtils.substring(text, i, i + 1), encodingType);
            }

            if (chkLen > len) {
                isLen = false;
            }
        }

        return isLen;
    }

    /**
     * 문자열 자르기
     *
     * @param str
     * @param start
     * @return
     */
    public static String substring(String str, int start){
    	String result = "";
    	int startLen = start;
        if(str == null){
        	result = null;
        }else{
            if(startLen < 0)
                startLen = str.length() + startLen;
            if(startLen < 0)
                startLen = 0;
            if(startLen > str.length())
            	result = "";
            else
            	result = str.substring(startLen);
        }
        return result;
    }

    /**
     * 문자열 자르기
     *
     * @param str
     * @param start
     * @param end
     * @return
     */
    public static String substring(String str, int start, int end){
    	String result = "";
    	int startLen = start;
    	int endLen = end;
        if(str == null){
        	result = null;
        }else{
            if(endLen < 0)
                endLen = str.length() + endLen;
            if(startLen < 0)
                startLen = str.length() + startLen;
            if(endLen > str.length())
                endLen = str.length();
            if(startLen > endLen){
            	result = "";
            }else{
                if(startLen < 0)
                    startLen = 0;
                if(endLen < 0)
                    endLen = 0;
                result = str.substring(startLen, endLen);
            }
        }
        return result;
    }

    /**
     * XSS 취약 문자 역 변환
     *
     * @param value
     * @return String (역 변환된 parameters)
     */
    public static String reXSSParam(String value) {
        String result = value;
        String strArr[] = {"&#39;","&#58;","&#59;","&#40;","&#41;","&lt;","&gt;","&#123;","&#125;","&#35;","&#36;","&#37;","&amp;","&#63;","&#33;","&#64;","&#42;","&#124;"};
        String valArr[] = {"`",":",";","(",")","<",">","{","}","#","$","%","&","?","!","@","*","|"};
        if(!StringUtil.isNullToString(value).equals("")){
            for(int i = 0 ; i < strArr.length ; i++){
            	String str = strArr[i];
            	String val = valArr[i];
            	if(result.indexOf(str) != -1){
            		result = StringUtil.replace(result, str, val);
            	}
            }
        }
        return result;
    }

    /**
     * XSS 취약 문자 있는경우
     *
     * @param value
     * @return String (역 변환된 parameters)
     */
    public static boolean isXSSParam(String value) {
        boolean result = false;
        String regex = "(&#[0-9]+;)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(value);
        result = matcher.find();
        return result;
    }

    /**
     * XSS 방어 로직 처리
     * (Pattern[])patterns
     */
    private static Pattern[] patterns = new Pattern[] {
            // Script fragments
            Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE),
            // src='...'
//            Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE
//                    | Pattern.DOTALL),
//            Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE
//                    | Pattern.DOTALL),
            // lonely script tags
            Pattern.compile("</script>", Pattern.CASE_INSENSITIVE),
            Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // eval(...)
            Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // expression(...)
            Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // javascript:...
            Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE),
            // vbscript:...
            Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE),
            // query % ...
            //Pattern.compile("^%|[\\%]$", Pattern.CASE_INSENSITIVE),
            // onload(...)=...
            Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL) };

    /**
     * XSS 방어 처리
     *
     * @param value
     * @return
     */
    public static String replaceStripXSS(String value) {
        String result = value;
        if (result != null) {
            for (Pattern scriptPattern : patterns) {
                Matcher m = scriptPattern.matcher(result);
                if(m.find()){
                    result = m.replaceAll("");
                }
            }
        }
        return result;
    }

    /**
     * <pre>
     * 전화번호 형태로 포맷팅한다.
     * </pre>
     * @param str
     * @return String
     */
    /*public static String toTel(String strIn) {
        
        if( StringUtils.isBlank(strIn)) {
            return "";
        }
        StringBuffer sb = new StringBuffer();
        String str = strIn;
        if (   str.length() < 3) {
            return str;
        } 
        makeTelNo(sb, str);
        return sb.toString();
    }

    *//**
     * Statements
     *
     * @param sb
     * @param str
     *//*
    private static void makeTelNo(StringBuffer sb, String str) {
        String mask = "";
        int j = 0;
        str = str.replaceAll(" ", "");
        str = str.replaceAll("-", "");
        str = str.replaceAll("(", "");
        str = str.replaceAll(")", "");

        if (str.length() >= 2) {
            if (str.substring(0, 2).equals("02")) {
                mask = (str.length() == 9) ? "99-999-9999" : "99-9999-9999";
            } else if (str.substring(0, 4).equals("1899")) {
                mask = (str.length() == 8) ? "9999-9999" : "9999-9999";
            } else {
                mask = (str.length() == 10) ? "999-999-9999" : "999-9999-9999";
            }

            for (int i = 0; i < str.length(); i++) {
                sb.append(str.charAt(i));
                j++;
                if (j < mask.length() && "()-".indexOf(mask.charAt(j)) != -1) {
                    sb.append(mask.charAt(j++));
                }
            }
        } else {
            sb.append(str);
        }
    }*/

    /**
     * <pre>
     * 핸드폰 번호 형태로 포맷팅한다.
     * </pre>
     * @param str
     * @return String
     */
    public static String toHpTel(String strIn) {

        StringBuffer sb = new StringBuffer();

        if (strIn != null) {
            String str = strIn;
            String mask = "";
            int j = 0;

            str = str.replaceAll(" ", "");
            str = str.replaceAll("-", "");
            str = str.replaceAll("(", "");
            str = str.replaceAll(")", "");

            if (str.length() == 10) {
                mask =  "999-999-9999";
            } else {
                mask = "999-9999-9999";
            }

            for (int i = 0; i < str.length(); i++) {
                sb.append(str.charAt(i));
                j++;
                if (j < mask.length() && "()-".indexOf(mask.charAt(j)) != -1)
                    sb.append(mask.charAt(j++));
            }
        }

        return sb.toString();
    }

    /**
     * <pre>
     * 입력받은 html문자열에서 이벤트 속성 삭제
     * </pre>
     *
     * @param html
     * @return
     */
    public static String removeXssHTML(String html) {
        String newHtml = "";
        if (!StringUtil.isEmpty(html)) {
            Document doc = Jsoup.parse(html);
            //script 테그 삭제
            doc.getElementsByTag("script").remove();
            //iframe 테그 삭제
            doc.getElementsByTag("iframe").remove();
            //object 테그 삭제
            doc.getElementsByTag("object").remove();

            //on으로 시작하는 attribute 삭제
            Elements elements = doc.getElementsByAttributeStarting("on");
            for (Element el : elements) {
                Attributes attributes = el.attributes();
                for (Attribute attr : attributes) {
                    if (attr.getKey() != null && attr.getKey().toLowerCase().startsWith("on")) {
                        el.removeAttr(attr.getKey());
                    }
                }
            }

            //href attribute 삭제
            elements = doc.getElementsByAttribute("href");
            for (Element el : elements) {
                Attributes attributes = el.attributes();
                for (Attribute attr : attributes) {
                    if ("href".equalsIgnoreCase(attr.getKey())) {
                        el.removeAttr(attr.getKey());
                    }
                }
            }

            newHtml = doc.html();

            //newHtml = Jsoup.clean(html, Whitelist.relaxed());
        }
        return newHtml;
    }

    public static boolean isAlpha(String str) {

        boolean isAlpha = false;
        try {
            Pattern p = Pattern.compile("^[A-Za-z]+$");
            Matcher m = p.matcher(str);
            isAlpha = m.matches();
        } catch (Exception e) {
            isAlpha = false;
        }

        return isAlpha;
    }

    public static boolean isAlphanNmeric(String str) {

        boolean isAlphanNmeric = false;
        try {
            Pattern p = Pattern.compile("^[A-Za-z0-9]+$");
            Matcher m = p.matcher(str);
            isAlphanNmeric = m.matches();
        } catch (Exception e) {
            isAlphanNmeric = false;
        }
        return isAlphanNmeric;
    }

    public static boolean isNumeric(String str) {

        boolean isNumeric = false;
        try {
            Pattern p = Pattern.compile("^[0-9]+$");
            Matcher m = p.matcher(str);
            isNumeric = m.matches();
        } catch (Exception e) {
            isNumeric = false;
        }
        return isNumeric;
    }

    public static boolean isCeqPno(String ceqPno) {

        boolean isCeqPno = false;
        try {
            Pattern p = Pattern.compile("^[-A-Z0-9- ]+$");
            Matcher m = p.matcher(ceqPno);
            isCeqPno = m.matches();
        } catch (Exception e) {
            isCeqPno = false;
        }
        return isCeqPno;
    }

    /**
    *
    * 주민번호체크
    *
    * @param rrn
    * @return
    * @throws Exception
    */
    public static boolean selectCheckRrn(String rrn) {

        int[] verifyNumArr = { 2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5 };
        int verifyNumSum = 0;
        int verificationnum = 0;
        boolean isValid = false;

        try {
            int i = 0;
            for (int verifyNum : verifyNumArr) {
                int rrnChar = Character.getNumericValue(rrn.charAt(i++));
                verifyNumSum = verifyNumSum + (verifyNum * rrnChar);
            }

            verificationnum = 11 - verifyNumSum % 11;
            int checknum = Character.getNumericValue(rrn.charAt(12));

            if (verificationnum == checknum) {
                isValid = true;
            }

        } catch (Exception e) {
            isValid = false;
        }
       return isValid;
   }
    /*
    public static String getJsessionIdDupRemove(String cookie){
        String result = "";
        if(!isNullToString(cookie).equals("")){
            String[] cookies = split(cookie, ";");
            List<String> cookieList = new ArrayList<String>();
            if(cookies != null && cookies.length > 0){
                for(int i  = 0 ; i < cookies.length ; i++){
                    String[] cookiesTemp = split(cookies[i], "=");
                    if(cookiesTemp != null){
                        String cookieName = "";
                        String cookieValue = "";
                        if(cookiesTemp.length >= 2){
                            cookieName = substring(cookies[i], 0, cookies[i].indexOf("="));
                            cookieValue = substring(cookies[i], cookies[i].indexOf("=")+1, cookies[i].length());
//                            cookieName = cookiesTemp[0];
//                            cookieValue = cookiesTemp[1];
                        }else if(cookiesTemp.length == 1){
                            cookieName = cookiesTemp[0];
                        }
                        if(!cookieList.contains(cookieName)){
                            result += cookieName + "=" + cookieValue + "; ";
                        }
                        cookieList.add(cookieName);
                    }
                }
            }
            if(result.lastIndexOf(";") != -1){
                result = substring(result, 0, result.lastIndexOf(";"));
            }
        }
        return result;
    }
    */
}
