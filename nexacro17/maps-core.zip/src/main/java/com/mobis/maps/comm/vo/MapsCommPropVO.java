package com.mobis.maps.comm.vo;

import org.hibernate.validator.constraints.NotBlank;

/**
 * <pre>
 * 프로퍼티 관리 항목
 * </pre>
 *
 * @ClassName   : MapsCommPropVO.java
 * @Description : 프로퍼티 관리 항목을 정의.
 * @author DT048058
 * @since 2019. 12. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 18.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommPropVO extends PgBascVO {
    /** 프로퍼티시스템 */
    @NotBlank(message="EC00000001|Property System")
    private String propSys;
    /** 프로퍼티키 */
    @NotBlank(message="EC00000001|Property Key")
    private String propKey;
    /** 프로퍼티값 */
    @NotBlank(message="EC00000001|Property Value")
    private String propVal;
    /** 프로퍼티설명 */
    private String propDc;
    /**
     * @return the propSys
     */
    public String getPropSys() {
        return propSys;
    }
    /**
     * @param propSys the propSys to set
     */
    public void setPropSys(String propSys) {
        this.propSys = propSys;
    }
    /**
     * @return the propKey
     */
    public String getPropKey() {
        return propKey;
    }
    /**
     * @param propKey the propKey to set
     */
    public void setPropKey(String propKey) {
        this.propKey = propKey;
    }
    /**
     * @return the propVal
     */
    public String getPropVal() {
        return propVal;
    }
    /**
     * @param propVal the propVal to set
     */
    public void setPropVal(String propVal) {
        this.propVal = propVal;
    }
    /**
     * @return the propDc
     */
    public String getPropDc() {
        return propDc;
    }
    /**
     * @param propDc the propDc to set
     */
    public void setPropDc(String propDc) {
        this.propDc = propDc;
    }

}
