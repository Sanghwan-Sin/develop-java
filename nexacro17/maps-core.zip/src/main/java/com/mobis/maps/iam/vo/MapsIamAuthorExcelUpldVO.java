package com.mobis.maps.iam.vo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 권한액셀업로드 항목
 * </pre>
 *
 * @ClassName   : MapsIamAuthorExcelUpldVO.java
 * @Description : 권한 액셀업로드에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 9. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 9.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamAuthorExcelUpldVO extends MapsIamExcelUpldCommVO {
    
    /** 권한리스트 */
    private List<MapsIamAuthorVO> authors;
    /** 권한ID 매핑행 */
    private Map<String, String> authorIdMapngRow;
    /** 권한ID 매핑 사용자리스트 */
    private Map<String, List<MapsIamAuthorMenuVO>> mapngMenus;
    /** 권한ID 매핑 사용자리스트 */
    private Map<String, List<MapsIamAuthorUserVO>> mapngUsers;
    
    public MapsIamAuthorExcelUpldVO() {
        this.authorIdMapngRow = new HashMap<String, String>();
        this.mapngMenus = new HashMap<String, List<MapsIamAuthorMenuVO>>();
        this.mapngUsers = new HashMap<String, List<MapsIamAuthorUserVO>>();
    }
    
    public void addAuthorIdMapngRow(int row, String authorId) {
        authorIdMapngRow.put(String.valueOf(row), authorId);
    }
    
    public String getAuthorIdMapngRow(int row) {
        
        return authorIdMapngRow.get(String.valueOf(row));
    }

    public List<MapsIamAuthorMenuVO> getAuthorMenu(String authorId) {
        
        return mapngMenus.get(authorId);
    }
    
    public void addAuthorMenu(String authorId, MapsIamAuthorMenuVO iamAuthorMenuVO) {
        
        List<MapsIamAuthorMenuVO> menus = getAuthorMenu(authorId);
        
        if (menus == null) {
            menus = new ArrayList<MapsIamAuthorMenuVO>();
        }
        menus.add(iamAuthorMenuVO);
        
        mapngMenus.put(authorId, menus);
    }

    public List<MapsIamAuthorUserVO> getAuthorUser(String authorId) {
        
        return mapngUsers.get(authorId);
    }
    
    public void addAuthorUser(String authorId, MapsIamAuthorUserVO iamAuthorUserVO) {
        
        List<MapsIamAuthorUserVO> users = getAuthorUser(authorId);
        
        if (users == null) {
            users = new ArrayList<MapsIamAuthorUserVO>();
        }
        users.add(iamAuthorUserVO);
        
        mapngUsers.put(authorId, users);
    }
    
    /**
     * @return the authors
     */
    public List<MapsIamAuthorVO> getAuthors() {
        return authors;
    }
    /**
     * @param authors the authors to set
     */
    public void setAuthors(List<MapsIamAuthorVO> authors) {
        this.authors = authors;
    }
    /**
     * @return the mapngMenus
     */
    public Map<String, List<MapsIamAuthorMenuVO>> getMapngMenus() {
        return mapngMenus;
    }
    /**
     * @param mapngMenus the mapngMenus to set
     */
    public void setMapngMenus(Map<String, List<MapsIamAuthorMenuVO>> mapngMenus) {
        this.mapngMenus = mapngMenus;
    }
    /**
     * @return the mapngUsers
     */
    public Map<String, List<MapsIamAuthorUserVO>> getMapngUsers() {
        return mapngUsers;
    }
    /**
     * @param mapngUsers the mapngUsers to set
     */
    public void setMapngUsers(Map<String, List<MapsIamAuthorUserVO>> mapngUsers) {
        this.mapngUsers = mapngUsers;
    }
}
