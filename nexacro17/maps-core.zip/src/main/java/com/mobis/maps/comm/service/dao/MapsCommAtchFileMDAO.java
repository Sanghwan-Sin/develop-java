package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.vo.MapsCommFileExtVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;

/**
 * <pre>
 * 첨부파일 데이터처리
 * </pre>
 *
 * @ClassName   : MapsCommAtchFileMDAO.java
 * @Description : 첨부파일 데이터처리를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 19.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Mapper("mapsCommAtchFileMDAO")
public interface MapsCommAtchFileMDAO {

    /**
     * 업로드허용 첨부파일 확장자리스트
     *
     * @param atchFile
     * @return
     * @throws Exception
     */
    public List<MapsCommFileExtVO> selectAtchFileExtInfo(MapsCommFileExtVO atchFile) throws Exception;
    
    
    /**
     * 첨부파일리스트 조회
     *
     * @param atchFile
     * @return
     * @throws Exception
     */
    public List<MapsAtchFileVO> selectAtchFileList(MapsAtchFileVO atchFile) throws Exception;

    /**
     * 첨부파일 조회
     *
     * @param atchFile
     * @return
     * @throws Exception
     */
    public MapsAtchFileVO selectAtchFile(MapsAtchFileVO atchFile) throws Exception;

    /**
     * 첨부파일 등록
     *
     * @param atchFile
     * @return
     * @throws Exception
     */
    public void insertAtchFile(MapsAtchFileVO atchFile) throws Exception;

    /**
     * 첨부파일 삭제
     *
     * @param atchFile
     * @return
     * @throws Exception
     */
    public int deleteAtchFile(MapsAtchFileVO atchFile) throws Exception;

    /**
     * 첨부파일 삭제(전체)
     *
     * @param atchFile
     * @return
     * @throws Exception
     */
    public int deleteAtchFileAll(MapsAtchFileVO atchFile) throws Exception;
    
    /**
     * 화면명 조회
     *
     * @param iamScreenVO
     * @return
     * @throws Exception
     */
    public MapsIamScreenVO selectScrinNm(MapsIamScreenVO iamScreenVO) throws Exception;
}
