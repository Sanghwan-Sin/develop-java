package com.mobis.maps.cmmn.excel.support;

import com.mobis.maps.cmmn.excel.Row;

/**
 * <pre>
 * Row 를 읽어서 적절한 pojoClass(T) 반환할 인터페이스
 * </pre>
 *
 * @ClassName   : RowMapper.java
 * @Description : Row 를 읽어서 적절한 pojoClass(T) 반환할 인터페이스
 * @author oh.dongwon
 * @since 2018. 5. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2018. 5. 18.     oh.dongwon     	최초 생성
 * </pre>
 */
public interface RowMapper<T> {

    public T mapRow(Row row);

}
