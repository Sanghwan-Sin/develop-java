package com.mobis.maps.comm.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mobis.maps.comm.vo.MapsCommIndexVO;

/**
 * <pre>
 * 초기화면로드 서비스
 * </pre>
 *
 * @ClassName   : MapsCommIndexService.java
 * @Description : 초기화면로드에 대하 서비스 정의.
 * @author DT048058
 * @since 2019. 12. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 4.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsCommIndexService {
    
    /** MAP키(iMobis사용자ID) */
    public static final String MAPKEY_IMOBIS_USERID = "iMobisUserId";
    /** MAP(iMobis로케일코드) */
    public static final String MAPKEY_IMOBIS_LOCALE_CD = "iMobisLocaleCd";

    /**
     * 화면캡쳐방지용 화면오픈정보 취득
     *
     * @param request
     * @param response
     * @throws Exception
     */
    public void selecSapSdilInfo(HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    /**
     * 결재 암호화 테스트용 정보 획득
     *
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public MapsCommIndexVO selectWorkflowSancVal(MapsCommIndexVO inVo) throws Exception;
    
    /**
     * imobis SSO 인증용 테스트용 정보 획득
     *
     * @param usrId
     * @param randomNum
     * @return
     * @throws Exception
     */
    public Map<String, String> selectSsoCheckMap(String usrId , String randomNum) throws Exception;
    
    /**
     * Portal SSO 인증용 테스트용 정보 획득
     *
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public HashMap<String,String> selectSsoFromPortalCheck(String ssoEncData) throws Exception;
    
}
