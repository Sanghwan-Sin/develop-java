package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;
import able.com.vo.HMap;

import com.mobis.maps.iam.vo.MapsIamScreenCompnVO;

/**
 * <pre>
 * 컴포넌트 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsIamCompnMDAO.java
 * @Description : 컴포넌트 데이터처를 정의.
 * @author DT048657
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     DT048657     	최초 생성
 * </pre>
 */
@Mapper("mapsIamCompnMDAO")
public interface MapsIamCompnMDAO {

    /**
     * 컴포넌트 페이징 리스트 조회
     *
     * @param commScreenCompnVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScreenCompnVO> selectScreenCompnPgList(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception;
    
    /**
     * 컴포넌트 리스트 조회
     *
     * @param commScreenCompnVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScreenCompnVO> selectScreenCompnList(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception;
    
    /**
     * 컴포넌트 조회
     *
     * @param iamScreenCompnVO
     * @return
     * @throws Exception
     */
    public MapsIamScreenCompnVO selectScreenCompnInfo(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception;
    
    /**
     * 다음 컴포넌트코드 조회
     *
     * @param iamScreenCompnVO
     * @return
     * @throws Exception
     */
    public HMap selectNextScreenCompnCd(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception;
        
    /**
     * 컴포넌트 저장
     *
     * @param iamScreenCompnVO
     * @throws Exception
     */
    public void insertScreenCompnInfo(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception;
        
    /**
     * 컴포넌트 수정
     *
     * @param iamScreenCompnVO
     * @return
     * @throws Exception
     */
    public int updateScreenCompnInfo(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception;
        
    /**
     * 컴포넌트 삭제
     *
     * @param iamScreenCompnVO
     * @return
     * @throws Exception
     */
    public int deleteScreenCompnInfo(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception;

    
    
}
