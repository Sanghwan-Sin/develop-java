package com.mobis.maps.comm.constants;

/**
 * <pre>
 * RFC입출력 구분
 * </pre>
 *
 * @ClassName   : RfcIpttSe.java
 * @Description : RFC입출력 구분을 정의.
 * @author Sin Sanghwan
 * @since 2019. 10. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 14.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public enum RfcIpttSe {
    
      Import("I")
    , Export("E")
    ;
    
    /** RFC입출력 구분명 */
    private String code;
    
    private RfcIpttSe(String code) {
        this.code = code;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
}
