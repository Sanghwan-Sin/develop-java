package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztCcpyVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztMobisVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztPdaVO;
import com.mobis.maps.comm.vo.MapsCommAuthorVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.comm.vo.MapsCommLoginVO;
import com.mobis.maps.comm.vo.MapsCommMenuVO;
import com.mobis.maps.comm.vo.MapsCommSapLoginVO;
import com.mobis.maps.comm.vo.MapsCommUserScrinBkmkVO;
import com.mobis.maps.iam.vo.MapsIamLoginHistVO;
import com.mobis.maps.iam.vo.MapsIamUserLangVO;
import com.mobis.maps.iam.vo.MapsIamUserPermIpVO;

/**
 * <pre>
 * 로그인 데이터처리
 * </pre>
 *
 * @ClassName   : MapsCommLoginMDAO.java
 * @Description : 로그인에 대한 데이터처리를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 18.     Sin Sanghwan       최초 생성
 * </pre>
 */
@Mapper("mapsCommLoginMDAO")
public interface MapsCommLoginMDAO {

    /**
     * 로그인정보 조회
     *
     * @param commLoginVO
     * @return
     * @throws Exception
     */
    public LoginInfoVO selectLoginInfo(MapsCommLoginVO commLoginVO) throws Exception;
    
    /**
     * 사용자언어 리스트 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserLangVO> selectUserLangList(LoginInfoVO loginInfoVO) throws Exception;
    
    
    /**
     * 기존에 해당 사용자가 이미 로그인 되어 있는지 체크함.
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamLoginHistVO selectPreLogin(LoginInfoVO loginInfoVO) throws Exception;
    
    /**
     * 사용자허용IP 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamUserPermIpVO selectUserPermIp(LoginInfoVO loginInfoVO) throws Exception;

    /**
     * 사용자언어 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamUserLangVO selectUserLang(LoginInfoVO loginInfoVO) throws Exception;

    /**
     * MAPS 모비스본사(해외법인) 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public MapsOrgnztMobisVO selectOrgnztMobisInfo(LoginInfoVO loginInfoVO) throws Exception;
    
    /**
     * MAPS 대리점,딜러 업체정보 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public MapsOrgnztDistVO selectOrgnztDistInfo(LoginInfoVO loginInfoVO) throws Exception;

    /**
     * MAPS 협력업체정보 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public MapsOrgnztCcpyVO selectOrgnztCcpyInfo(LoginInfoVO loginInfoVO) throws Exception;
    
    /**
     * MAPS PDA정보 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsOrgnztPdaVO> selectOrgnztPdaInfo(LoginInfoVO loginInfoVO) throws Exception;

    /**
     * 로그인 언어 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public List<CodeVO> selectLoginLangList(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * SAP로그인정보 조회
     *
     * @param commSapLoginVO
     * @return
     * @throws Exception
     */
    public LoginInfoVO selectSapLoginInfo(MapsCommSapLoginVO commSapLoginVO) throws Exception;

    /**
     * 사용자 권한별 메뉴리스트 조회
     *
     * @param commLoginVO
     * @return
     * @throws Exception
     */
    public List<MapsCommMenuVO> selectMenuListByUser(LoginInfoVO loginInfoVO) throws Exception;
    
    /**
     * 사용자 화면 즐겨찾기 리스트 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsCommUserScrinBkmkVO> selectUserScrinBkmkList(LoginInfoVO loginInfoVO) throws Exception;

    /**
     * 사용자정보관리 메뉴 리스트 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsCommMenuVO> selectUserInfoManageMenuList(LoginInfoVO loginInfoVO) throws Exception;
    
    /**
     * 로그인 이력에 대한 로그인정보 수정
     *
     * @param iamLoginHistVO
     * @throws Exception
     */
    public int updateLoginInfoByLoginHist(MapsIamLoginHistVO iamLoginHistVO) throws Exception;
    
    /**
     * 계정잠김 사용자이력 등록
     *
     * @param iamLoginHistVO
     * @throws Exception
     */
    public void insertAcntLockUserChghst(MapsIamLoginHistVO iamLoginHistVO) throws Exception;
    
    /**
     * 로그인 이력 등록
     *
     * @param iamLoginHistVO
     * @throws Exception
     */
    public void insertLoginHist(MapsIamLoginHistVO iamLoginHistVO) throws Exception;
    
    
    /**
     * 로그인사용자의 권한리스트 조회
     *
     * @param MapsCommAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsCommAuthorVO> selectAuthorList(MapsCommAuthorVO authorVO) throws Exception;
    
    /**
     * 로그아웃처리
     *
     * @param MapsCommAuthorVO
     * @return
     * @throws Exception
     */
    public int updateLoginOutInfo(LoginInfoVO loginInfoVO) throws Exception;
    
    
    
    /**
     * 중복 로그인 체크
     * 나보다 이후에 로그인되었는지 찾는다.
     * @param iamLoginHistVO
     * @return
     * @throws Exception
     */
    public MapsIamLoginHistVO selectLoginExpired(MapsIamLoginHistVO iamLoginHistVO) throws Exception;
}
