package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserIdSeqVO;

/**
 * <pre>
 * 사용자기본정보 데이터처리
 * </pre>
 *
 * @ClassName   : MapsIamUserBassInfoMDAO.java
 * @Description : 사용자기본정보에 대한 데이터처리를 정의.
 * @author DT048058
 * @since 2020. 3. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 17.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsIamUserBassInfoMDAO")
public interface MapsIamUserBassInfoMDAO {

    /**
     * 사용자기본정보 페이징리스트 조회
     *
     * @param iamUserBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserBassInfoVO> selectUserBassInfoPgList(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자기본정보 페이징리스트 팝업 조회
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserBassInfoVO> selectPopupUserBassInfoPgList(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자기본정보 조회
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamUserBassInfoVO selectUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자기본정보 존재 조회
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamUserBassInfoVO selectHasUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자ID순번 채번 등록
     *
     * @param mapsIamUserIdSeqVO
     * @return
     * @throws Exception
     */
    public int insertUserIdSeq(MapsIamUserIdSeqVO mapsIamUserIdSeqVO) throws Exception;
    
    /**
     * 사용자기본정보 등록
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public void insertUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자기본정보 수정
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public int updateUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자기본정보 삭제 수정
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public int updateDeleteUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자기본정보 삭제
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public int deleteUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자기본변경이력 페이징조회
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserBassInfoVO> selectUserBassChghstPgList(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 사용자기본정보 변경이력 등록
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public void insertUserBassChghst(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
}
