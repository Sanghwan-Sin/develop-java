package com.mobis.maps.comm.vo;

/**
 * <pre>
 * 공통 코드그룹 항목
 * </pre>
 *
 * @ClassName : MapsCommCodeGroupVO.java
 * @Description : 공통 코드그룹 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 29.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class MapsCommCodeGroupVO extends PgBascVO {
    /* 조회조건 */
    /** 코드환경(CHN:채널시스템, DOMN:Domain Code, 그외 SAP Code) */ 
    private String sysEnvrn;
    /* 데이터항목 */
    /** 코드그룹 */
    private String codeGroup;
    /** 코드그룹명 */
    private String codeGroupNm;
    /** 코드시스템 */
    private String codeSys;
    /** 상위코드그룹 */
    private String upperCodeGroup;
    /** 코드참고설명1 */
    private String codeReferDc1;
    /** 코드참고설명2 */
    private String codeReferDc2;
    /** 코드참고설명3 */
    private String codeReferDc3;
    /** 코드참고설명4 */
    private String codeReferDc4;
    /** 코드참고설명5 */
    private String codeReferDc5;
    /** 사용여부 */
    private String useYn;
    /** 삭제여부 */
    private String delYn;
    /* SAP코드 */
    /** SAP시스템ID */ 
    private String sysId;
    /** SAP클라이언트 */ 
    private String client;
    /**
     * @return the codeGroup
     */
    public String getCodeGroup() {
        return codeGroup;
    }
    /**
     * @param codeGroup the codeGroup to set
     */
    public void setCodeGroup(String codeGroup) {
        this.codeGroup = codeGroup;
    }
    /**
     * @return the codeGroupNm
     */
    public String getCodeGroupNm() {
        return codeGroupNm;
    }
    /**
     * @param codeGroupNm the codeGroupNm to set
     */
    public void setCodeGroupNm(String codeGroupNm) {
        this.codeGroupNm = codeGroupNm;
    }
    /**
     * @return the codeSys
     */
    public String getCodeSys() {
        return codeSys;
    }
    /**
     * @return the upperCodeGroup
     */
    public String getUpperCodeGroup() {
        return upperCodeGroup;
    }
    /**
     * @param upperCodeGroup the upperCodeGroup to set
     */
    public void setUpperCodeGroup(String upperCodeGroup) {
        this.upperCodeGroup = upperCodeGroup;
    }
    /**
     * @param codeSys the codeSys to set
     */
    public void setCodeSys(String codeSys) {
        this.codeSys = codeSys;
    }
    /**
     * @return the codeReferDc1
     */
    public String getCodeReferDc1() {
        return codeReferDc1;
    }
    /**
     * @param codeReferDc1 the codeReferDc1 to set
     */
    public void setCodeReferDc1(String codeReferDc1) {
        this.codeReferDc1 = codeReferDc1;
    }
    /**
     * @return the codeReferDc2
     */
    public String getCodeReferDc2() {
        return codeReferDc2;
    }
    /**
     * @param codeReferDc2 the codeReferDc2 to set
     */
    public void setCodeReferDc2(String codeReferDc2) {
        this.codeReferDc2 = codeReferDc2;
    }
    /**
     * @return the codeReferDc3
     */
    public String getCodeReferDc3() {
        return codeReferDc3;
    }
    /**
     * @param codeReferDc3 the codeReferDc3 to set
     */
    public void setCodeReferDc3(String codeReferDc3) {
        this.codeReferDc3 = codeReferDc3;
    }
    /**
     * @return the codeReferDc4
     */
    public String getCodeReferDc4() {
        return codeReferDc4;
    }
    /**
     * @param codeReferDc4 the codeReferDc4 to set
     */
    public void setCodeReferDc4(String codeReferDc4) {
        this.codeReferDc4 = codeReferDc4;
    }
    /**
     * @return the codeReferDc5
     */
    public String getCodeReferDc5() {
        return codeReferDc5;
    }
    /**
     * @param codeReferDc5 the codeReferDc5 to set
     */
    public void setCodeReferDc5(String codeReferDc5) {
        this.codeReferDc5 = codeReferDc5;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }
    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    /**
     * @return the sysEnvrn
     */
    public String getSysEnvrn() {
        return sysEnvrn;
    }
    /**
     * @param sysEnvrn the sysEnvrn to set
     */
    public void setSysEnvrn(String sysEnvrn) {
        this.sysEnvrn = sysEnvrn;
    }
    /**
     * @return the sysId
     */
    public String getSysId() {
        return sysId;
    }
    /**
     * @param sysId the sysId to set
     */
    public void setSysId(String sysId) {
        this.sysId = sysId;
    }
    /**
     * @return the client
     */
    public String getClient() {
        return client;
    }
    /**
     * @param client the client to set
     */
    public void setClient(String client) {
        this.client = client;
    }
}
