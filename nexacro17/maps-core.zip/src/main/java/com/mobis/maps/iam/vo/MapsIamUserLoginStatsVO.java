package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * 사용자 로그인 통계 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserLoginStatsVO.java
 * @Description : 사용자 로그인 통계에 대한 항목정의.
 * @author DT048058
 * @since 2020. 5. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 7.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserLoginStatsVO extends MapsIamCommVO {
    /* 조회조건 */
    /** 시작일자 */
    private Date strtDt;
    /** 종료일자 */
    private Date endDt;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 조직구분코드 */
    private String orgnztSeCd;
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 조직코드 */
    private String orgnztCd;
    /* 사용자 로그인 통계 항목 */
    /** 조직명 */
    private String orgnztNm;
    /** 사용자ID */
    private String userId;
    /** 사용자명 */
    private String userNm;
    /** 로그인일시 */
    private Date loginDt;
    /** 로그인건수 */
    private int loginCnt;
    /** 로그인 합계건수 */
    private int loginSum;
    
    
    
    /**
     * @return the loginSum
     */
    public int getLoginSum() {
        return loginSum;
    }
    /**
     * @param loginSum the loginSum to set
     */
    public void setLoginSum(int loginSum) {
        this.loginSum = loginSum;
    }
    /**
     * @return the strtDt
     */
    public Date getStrtDt() {
        return strtDt;
    }
    /**
     * @param strtDt the strtDt to set
     */
    public void setStrtDt(Date strtDt) {
        this.strtDt = strtDt;
    }
    /**
     * @return the endDt
     */
    public Date getEndDt() {
        return endDt;
    }
    /**
     * @param endDt the endDt to set
     */
    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the orgnztSeCd
     */
    public String getOrgnztSeCd() {
        return orgnztSeCd;
    }
    /**
     * @param orgnztSeCd the orgnztSeCd to set
     */
    public void setOrgnztSeCd(String orgnztSeCd) {
        this.orgnztSeCd = orgnztSeCd;
    }
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the orgnztCd
     */
    public String getOrgnztCd() {
        return orgnztCd;
    }
    /**
     * @param orgnztCd the orgnztCd to set
     */
    public void setOrgnztCd(String orgnztCd) {
        this.orgnztCd = orgnztCd;
    }
    /**
     * @return the orgnztNm
     */
    public String getOrgnztNm() {
        return orgnztNm;
    }
    /**
     * @param orgnztNm the orgnztNm to set
     */
    public void setOrgnztNm(String orgnztNm) {
        this.orgnztNm = orgnztNm;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userNm
     */
    public String getUserNm() {
        return userNm;
    }
    /**
     * @param userNm the userNm to set
     */
    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }
    /**
     * @return the loginDt
     */
    public Date getLoginDt() {
        return loginDt;
    }
    /**
     * @param loginDt the loginDt to set
     */
    public void setLoginDt(Date loginDt) {
        this.loginDt = loginDt;
    }
    /**
     * @return the loginCnt
     */
    public int getLoginCnt() {
        return loginCnt;
    }
    /**
     * @param loginCnt the loginCnt to set
     */
    public void setLoginCnt(int loginCnt) {
        this.loginCnt = loginCnt;
    }
    
}

