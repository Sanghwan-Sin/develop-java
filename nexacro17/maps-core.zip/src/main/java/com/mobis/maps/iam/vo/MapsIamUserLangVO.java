package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 사용자 언어 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserLangVO.java
 * @Description : 사용자 언어에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 20.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserLangVO extends MapsIamCommVO {
    /** 사용자언어ID */
    private String userLangId;
    /** 사용자순번ID */
    private String userSeqId;
    /** 언어코드 */
    private String langCd;
    /** 언어명 */
    private String langNm;
    /** 대표여부 */
    private String reprsntYn;
    /**
     * @return the userLangId
     */
    public String getUserLangId() {
        return userLangId;
    }
    /**
     * @param userLangId the userLangId to set
     */
    public void setUserLangId(String userLangId) {
        this.userLangId = userLangId;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    /**
     * @return the langCd
     */
    public String getLangCd() {
        return langCd;
    }
    /**
     * @param langCd the langCd to set
     */
    public void setLangCd(String langCd) {
        this.langCd = langCd;
    }
    /**
     * @return the langNm
     */
    public String getLangNm() {
        return langNm;
    }
    /**
     * @param langNm the langNm to set
     */
    public void setLangNm(String langNm) {
        this.langNm = langNm;
    }
    /**
     * @return the reprsntYn
     */
    public String getReprsntYn() {
        return reprsntYn;
    }
    /**
     * @param reprsntYn the reprsntYn to set
     */
    public void setReprsntYn(String reprsntYn) {
        this.reprsntYn = reprsntYn;
    }
}
