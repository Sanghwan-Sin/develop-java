package com.mobis.maps.comm.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.comm.vo.MapsCommLoginVO;
import com.mobis.maps.comm.vo.MapsCommMenuVO;
import com.mobis.maps.comm.vo.MapsCommSapLoginVO;
import com.mobis.maps.comm.vo.MapsCommUserScrinBkmkVO;
import com.mobis.maps.comm.vo.MapsOpenSdiScrinInfoVO;
import com.mobis.maps.iam.vo.MapsIamLoginHistVO;
import com.mobis.maps.iam.vo.MapsIamUserLangVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommLoginService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 28.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsCommLoginService {
    
    /* ================= 로그인 에러코드 ===================== */
    /* 계정 상태 */
    public static final int LOGIN_STATUS_ACCOUNT_EXPIRED = 10;   // 10 -계정 사용기간 만료
    public static final int LOGIN_STATUS_MAX_NOT_CONNECTED = 20; // 20 -일정기간 미접속
    public static final int LOGIN_STATUS_MAX_PW_ERROR = 30;       // 30 -패스워드 오류 횟수 초과

    /* 로그인 결과 */
    public static final int LOGIN_RESULT_CHANGE_PW = 10;           // 10 -패스워드 변경 페이지 분기
    public static final int LOGIN_RESULT_INIT_PW_CHANGE = 20;     // 10 -패스워드 변경 페이지 분기
    public static final int LOGIN_RESULT_SUCCESS = 0;              // 0 -로그인 성공
    public static final int LOGIN_RESULT_FAIL = -1;                // -1 -로그인 실패
    public static final int LOGIN_RESULT_ACCOUNT_EXPIRED = -10;   // -10 -계정사용기간 만료
    public static final int LOGIN_RESULT_MAX_NOT_CONNECTED = -20; // -20 -일정기간 미접속
    public static final int LOGIN_RESULT_MAX_PW_ERROR = -30;       // -30 -패스워드 오류횟수 초과
    public static final int LOGIN_RESULT_USE_N = -40;               // -40 -사용자계정 잠김

/*
  - 001 : 미등록 사용자로 로그인시 오류
  - 002 : 허용IP사용시 오류
  - 003 : 미설정언어사용시
  - 004 : 계정잠김
  - 100 : 비밀번호입력시 오류
  - 101 : 비밀번호오류횟수초과
  - 102 : 비밀번호만료
  - 200 : 장기미사용자
  - 400 : 중복로그인
  - 999 : 시스템오류
 */
    /** 실패구분코드[001:미등록 사용자로 로그인시 오류] */
    public static final String FAILR_SE_CD_NOT_HAS_USER = "001";
    /** 실패구분코드[002:허용IP사용시 오류] */
    public static final String FAILR_SE_CD_NOT_MATCH_IP = "002";
    /** 실패구분코드[003:미설정언어사용시] */
    public static final String FAILR_SE_CD_NOT_MATCH_LANG = "003";
    /** 실패구분코드[004:계정잠김] */
    public static final String FAILR_SE_CD_ACCOUNT_LOCK = "004";
    /** 실패구분코드[100:비밀번호입력시 오류] */
    public static final String FAILR_SE_CD_NOT_MATCH_PASSWORD = "100";
    /** 실패구분코드[101:비밀번호오류횟수초과] */
    public static final String FAILR_SE_CD_PASSWORD_OVER_COUNT = "101";
    /** 실패구분코드[102:비밀번호만료] */
    public static final String FAILR_SE_CD_END_PASSWORD = "102";
    /** 실패구분코드[200:장기미사용자] */
    public static final String FAILR_SE_CD_NOT_USED_LONG = "200";
    /** 실패구분코드[201:미사용기간] */
    public static final String FAILR_SE_CD_NOT_USED_PRIOD = "201";
    /** 실패구분코드[400:중복로그인] */
    public static final String FAILR_SE_CD_PRE_LOGIN = "400";
    /** 실패구분코드[999:시스템오류] */
    public static final String FAILR_SE_CD_SYSTEM = "999";
    
    /** */
    public static final String PRE_LOGIN_CHECK_FLAG = "LOGIN";

    /* DB Property KEY */
    /** DB프로퍼티키[LOGIN_DEFAULT_LANG_CD:초기언어코드] */
    public static final String DBPROP_KEY_LOGIN_DEFAULT_LANG_CD = "LOGIN_DEFAULT_LANG_CD";
    /** DB프로퍼티키[LOGIN_PW_ERR_CNT:패스워드오류건수] */
    public static final String DBPROP_KEY_LOGIN_PW_ERR_CNT = "LOGIN_PW_ERR_CNT";
    /** DB프로퍼티키[LOGIN_NOT_CNNECT_MAX_DAY:미로그인최대접속일수] */
    public static final String DBPROP_KEY_LOGIN_NOT_CNNECT_MAX_DAY = "LOGIN_NOT_CNNECT_MAX_DAY";
    /** DB프로퍼티키[DUP_LOGIN_CHECK_YN:로그인중복체크여부] */
    public static final String DBPROP_KEY_DUP_LOGIN_CHECK_YN = "DUP_LOGIN_CHECK_YN";
    /** DB프로퍼티키[IAM_LOGIN_NOT_CNNECT_MAX_DAY:시스템별미로그인최대접속일수] */
    public static final String DBPROP_KEY_IAM_LOGIN_NOT_CNNECT_MAX_DAY = "IAM_LOGIN_NOT_CNNECT_MAX_DAY";
    
    /**
     * 로그인 초기화
     *
     * @param commLoginVO
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public MapsCommLoginVO selectLoginInit(MapsCommLoginVO commLoginVO , HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    
    /**
     * 로그인 언어 조회
     *
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public List<CodeVO> selectLoginLangList(MapsCommCodeVO commCodeVO) throws Exception ;
    
    /**
     * 로그인 정보 조회
     *
     * @param commLoginVO
     * @param iamLoginHistVO
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public LoginInfoVO selectLoginInfo(MapsCommLoginVO commLoginVO, MapsIamLoginHistVO iamLoginHistVO, HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    /**
     * 사용자메뉴 조회
     *
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommMenuVO> selectMenuListByUser(LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자 화면 즐겨찾기 리스트 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsCommUserScrinBkmkVO> selectUserScrinBkmkList(LoginInfoVO loginInfoVO) throws Exception;

    /**
     * 사용자정보관리 메뉴 리스트 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsCommMenuVO> selectUserInfoManageMenuList(LoginInfoVO loginInfoVO) throws Exception;
    
    /**
     * 사용자언어 리스트 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserLangVO> selectUserLangList(LoginInfoVO loginInfoVO) throws Exception;
    
    /**
     * 로그인 이력 등록
     *
     * @param iamLoginHistVO
     * @throws Exception
     */
    public int insertLoginHist(MapsIamLoginHistVO iamLoginHistVO) throws Exception;
    
    /**
     * 로그아웃
     *
     * @param request
     * @param response
     * @throws Exception
     */
    public void selectLogout(HttpServletRequest request, HttpServletResponse response) throws Exception;
        
    /**
     * SAP 로그인 초기화
     *
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public MapsCommSapLoginVO selectSapLoginInit(HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    /**
     * SAP 로그인 정보 취득
     *
     * @param commSapLoginVO
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public MapsOpenSdiScrinInfoVO selectSapLoginInfo(MapsCommSapLoginVO commSapLoginVO, HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    /**
     * 로그아웃 처리
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public int updateLoginOutInfo(LoginInfoVO loginInfoVO) throws Exception; 
    
    /**
     * 중복로그인 체크
     *
     * @param iamLoginHistVO
     * @return
     * @throws Exception
     */
    public MapsIamLoginHistVO selectLoginExpired(MapsIamLoginHistVO iamLoginHistVO) throws Exception;
    
}
