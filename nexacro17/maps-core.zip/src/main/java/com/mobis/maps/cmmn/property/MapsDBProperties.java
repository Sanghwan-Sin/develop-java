package com.mobis.maps.cmmn.property;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

/**
 * <pre>
 * DB 프로퍼티 데이터처리
 * </pre>
 *
 * @ClassName   : MapsDBPropertiey.java
 * @Description : DB에 등록된 프로퍼티 데이터처리를 관리한다.
 * @author Sin Sanghwan
 * @since 2019. 8. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 6.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class MapsDBProperties extends Properties {
    
    private final Logger logger = LoggerFactory.getLogger(MapsDBProperties.class);

    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = -4330589788022515601L;
    
    public static final String PRAMETER_KEY_SYSTEM = "sys";

    public static final String KEY = "pkey";
    
    public static final String VALUE = "value";
    
    public static final String LASTMODIFY = "lastmodify";

    public static final SimpleDateFormat SDF_LASTMODIFY = new SimpleDateFormat("yyyyMMddHHmmss" , Locale.KOREA);
    
    private DataSource dataSource;
    
    private NamedParameterJdbcTemplate jdbcTemplate;
    
    private String system;
    
    private String sqlPropTimestamp;
    
    private String sqlPropList;
    
    private final Map<String, Object> args;
    
    private boolean isLoaded;
    
    public MapsDBProperties() {
        
        this.args = new HashMap<String, Object>();
        this.isLoaded = false;
    }

    public void load() {
        
        if (logger.isDebugEnabled()) {
            logger.debug("→ load::start[dataSource=" + dataSource + "]");
            logger.debug("→ load::start[system=" + system + "]");
            logger.debug("→ load::start[sqlPropTimestamp=" + sqlPropTimestamp + "]");
            logger.debug("→ load::start[sqlPropList=" + sqlPropList + "]");
        }
        
        List<Map<String, Object>> lstProperty = jdbcTemplate.queryForList(sqlPropList, args);
        
        for (Map<String, Object> property : lstProperty) {
            String key = "";
            if (property.get(KEY) != null) {
                key = (String) property.get(KEY);
            }
            String value = "";
            if (property.get(VALUE) != null) {
                value = (String) property.get(VALUE);
            }
            setProperty(key, value);
        }
        
        this.isLoaded = true;
    }
    
    public Calendar getDbLastmodify() {
        
        Map<String, Object> mTimestamp = jdbcTemplate.queryForMap(sqlPropTimestamp, args);

        Calendar cal = Calendar.getInstance();
        try {
            if (mTimestamp != null &&  mTimestamp.get(LASTMODIFY) != null) {
                cal.setTime(SDF_LASTMODIFY.parse((String) mTimestamp.get(LASTMODIFY)));
            }
        } catch (ParseException e) {
            if (logger.isDebugEnabled()) {
                logger.debug("[ParseException e]" + e.getMessage());
            }
        }
        
        return cal;
    }

    /**
     * @return the dataSource
     */
    public DataSource getDataSource() {
        return dataSource;
    }
    /**
     * @param dataSource the dataSource to set
     */
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }
    /**
     * @return the system
     */
    public String getSystem() {
        return system;
    }
    /**
     * @param system the system to set
     */
    public void setSystem(String system) {
        this.system = system;
        this.args.put(PRAMETER_KEY_SYSTEM, system);
    }
    /**
     * @return the sqlPropTimestamp
     */
    public String getSqlPropTimestamp() {
        return sqlPropTimestamp;
    }
    /**
     * @param sqlPropTimestamp the sqlPropTimestamp to set
     */
    public void setSqlPropTimestamp(String sqlPropTimestamp) {
        this.sqlPropTimestamp = sqlPropTimestamp;
    }
    /**
     * @return the sqlPropList
     */
    public String getSqlPropList() {
        return sqlPropList;
    }
    /**
     * @param sqlPropList the sqlPropList to set
     */
    public void setSqlPropList(String sqlPropList) {
        this.sqlPropList = sqlPropList;
    }

    /**
     * @return the args
     */
    public Map<String, Object> getArgs() {
        return args;
    }

    /**
     * @return the isLoaded
     */
    public boolean isLoaded() {
        return isLoaded;
    }

}
