package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 사용자 조직정보 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserOrgnztVO.java
 * @Description : 사용자 조직에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 9. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 18.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserOrgnztVO extends MapsIamCommVO {

    /** 조직구분코드 */
    private String orgnztSeCd;
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 조직코드 */
    private String orgnztCd;
    /** 조직명 */
    private String orgnztNm;
    /** 딜러코드 */
    private String dealerCd;
    /** 딜러명 */
    private String dealerNm;
/* nMGN조직정보 */
    /** 대리점코드 */
    private String distCd;
    /** 영업사원코드 */
    private String zsalesPer;
    /** 고객그룹 [10:[HQ]내수_도매, 11:[HQ]내수_소매, 12:[HQ]내수_정비, 13:[HQ]수출_모비스, 14:[HQ]수출_대리점, 15:[HQ]수출_로컬수출] */
    private String kdgrp;

    /**
     * @return the orgnztSeCd
     */
    public String getOrgnztSeCd() {
        return orgnztSeCd;
    }
    /**
     * @param orgnztSeCd the orgnztSeCd to set
     */
    public void setOrgnztSeCd(String orgnztSeCd) {
        this.orgnztSeCd = orgnztSeCd;
    }
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the orgnztCd
     */
    public String getOrgnztCd() {
        return orgnztCd;
    }
    /**
     * @param orgnztCd the orgnztCd to set
     */
    public void setOrgnztCd(String orgnztCd) {
        this.orgnztCd = orgnztCd;
    }
    /**
     * @return the orgnztNm
     */
    public String getOrgnztNm() {
        return orgnztNm;
    }
    /**
     * @param orgnztNm the orgnztNm to set
     */
    public void setOrgnztNm(String orgnztNm) {
        this.orgnztNm = orgnztNm;
    }
    /**
     * @return the dealerCd
     */
    public String getDealerCd() {
        return dealerCd;
    }
    /**
     * @param dealerCd the dealerCd to set
     */
    public void setDealerCd(String dealerCd) {
        this.dealerCd = dealerCd;
    }
    /**
     * @return the dealerNm
     */
    public String getDealerNm() {
        return dealerNm;
    }
    /**
     * @param dealerNm the dealerNm to set
     */
    public void setDealerNm(String dealerNm) {
        this.dealerNm = dealerNm;
    }
    /**
     * @return the distCd
     */
    public String getDistCd() {
        return distCd;
    }
    /**
     * @param distCd the distCd to set
     */
    public void setDistCd(String distCd) {
        this.distCd = distCd;
    }
    /**
     * @return the zsalesPer
     */
    public String getZsalesPer() {
        return zsalesPer;
    }
    /**
     * @param zsalesPer the zsalesPer to set
     */
    public void setZsalesPer(String zsalesPer) {
        this.zsalesPer = zsalesPer;
    }
    /**
     * @return the kdgrp
     */
    public String getKdgrp() {
        return kdgrp;
    }
    /**
     * @param kdgrp the kdgrp to set
     */
    public void setKdgrp(String kdgrp) {
        this.kdgrp = kdgrp;
    }
}
