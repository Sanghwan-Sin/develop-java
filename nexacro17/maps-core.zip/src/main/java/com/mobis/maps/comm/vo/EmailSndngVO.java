package com.mobis.maps.comm.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : EmailSndngVO.java
 * @Description : EMail Send VO
 * @author hong.minho
 * @since 2020. 4. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 13.     hong.minho     	최초 생성
 * </pre>
 */

public class EmailSndngVO extends CommVO {
    private int    emailSn = 0 ;  // 이메일순번
    private String sndngProgrm ;  // 발송프로그램 
    private String sndngSe     ;  // 발송구분
    private String creatDt     ;  // 생성일시
    private String sndngDt     ;  // 발송일시
    private String errorMssage ;  // 에러메시지
    private String htmlYn      ;  // HTML여부
    private String sndngEmail  ;  // 발송이메일
    private String recptnEmail ;  // 수신이메일
    private String recptnCc    ;  // 수신참조
    private String recptnBcc   ;  // 수신숨은참조
    private String emailRply   ;  // 이메일회신
    private String emailSj     ;  // 메일제목
    private String emailBdt    ;  // 메일본문
    private String atchYn      ;  // 첨부여부
    private String refCol1     ;  // 추가컬럼1(업무에서자유사용)
    private String refCol2     ;  // 추가컬럼2(업무에서자유사용)
    private String refCol3     ;  // 추가컬럼3(업무에서자유사용)
    private String refCol4     ;  // 추가컬럼4(업무에서자유사용)
    private String refCol5     ;  // 추가컬럼5(업무에서자유사용)
    
    // 보낼려는 첨부파일ID
    private String atchSe;
    private String atchId;
    private int fileNo = 0;
    
    
    
    
    /**
     * @return the emailSn
     */
    public int getEmailSn() {
        return emailSn;
    }
    /**
     * @param emailSn the emailSn to set
     */
    public void setEmailSn(int emailSn) {
        this.emailSn = emailSn;
    }
    /**
     * @return the sndngProgrm
     */
    public String getSndngProgrm() {
        return sndngProgrm;
    }
    /**
     * @param sndngProgrm the sndngProgrm to set
     */
    public void setSndngProgrm(String sndngProgrm) {
        this.sndngProgrm = sndngProgrm;
    }
    /**
     * @return the sndngSe
     */
    public String getSndngSe() {
        return sndngSe;
    }
    /**
     * @param sndngSe the sndngSe to set
     */
    public void setSndngSe(String sndngSe) {
        this.sndngSe = sndngSe;
    }
    /**
     * @return the creatDt
     */
    public String getCreatDt() {
        return creatDt;
    }
    /**
     * @param creatDt the creatDt to set
     */
    public void setCreatDt(String creatDt) {
        this.creatDt = creatDt;
    }
    /**
     * @return the sndngDt
     */
    public String getSndngDt() {
        return sndngDt;
    }
    /**
     * @param sndngDt the sndngDt to set
     */
    public void setSndngDt(String sndngDt) {
        this.sndngDt = sndngDt;
    }
    /**
     * @return the errorMssage
     */
    public String getErrorMssage() {
        return errorMssage;
    }
    /**
     * @param errorMssage the errorMssage to set
     */
    public void setErrorMssage(String errorMssage) {
        this.errorMssage = errorMssage;
    }
    /**
     * @return the htmlYn
     */
    public String getHtmlYn() {
        return htmlYn;
    }
    /**
     * @param htmlYn the htmlYn to set
     */
    public void setHtmlYn(String htmlYn) {
        this.htmlYn = htmlYn;
    }
    /**
     * @return the sndngEmail
     */
    public String getSndngEmail() {
        return sndngEmail;
    }
    /**
     * @param sndngEmail the sndngEmail to set
     */
    public void setSndngEmail(String sndngEmail) {
        this.sndngEmail = sndngEmail;
    }
    /**
     * @return the recptnEmail
     */
    public String getRecptnEmail() {
        return recptnEmail;
    }
    /**
     * @param recptnEmail the recptnEmail to set
     */
    public void setRecptnEmail(String recptnEmail) {
        this.recptnEmail = recptnEmail;
    }
    /**
     * @return the recptnCc
     */
    public String getRecptnCc() {
        return recptnCc;
    }
    /**
     * @param recptnCc the recptnCc to set
     */
    public void setRecptnCc(String recptnCc) {
        this.recptnCc = recptnCc;
    }
    /**
     * @return the recptnBcc
     */
    public String getRecptnBcc() {
        return recptnBcc;
    }
    /**
     * @param recptnBcc the recptnBcc to set
     */
    public void setRecptnBcc(String recptnBcc) {
        this.recptnBcc = recptnBcc;
    }
    /**
     * @return the emailRply
     */
    public String getEmailRply() {
        return emailRply;
    }
    /**
     * @param emailRply the emailRply to set
     */
    public void setEmailRply(String emailRply) {
        this.emailRply = emailRply;
    }
    /**
     * @return the emailSj
     */
    public String getEmailSj() {
        return emailSj;
    }
    /**
     * @param emailSj the emailSj to set
     */
    public void setEmailSj(String emailSj) {
        this.emailSj = emailSj;
    }
    /**
     * @return the emailBdt
     */
    public String getEmailBdt() {
        return emailBdt;
    }
    /**
     * @param emailBdt the emailBdt to set
     */
    public void setEmailBdt(String emailBdt) {
        this.emailBdt = emailBdt;
    }
    /**
     * @return the atchYn
     */
    public String getAtchYn() {
        return atchYn;
    }
    /**
     * @param atchYn the atchYn to set
     */
    public void setAtchYn(String atchYn) {
        this.atchYn = atchYn;
    }
    /**
     * @return the refCol1
     */
    public String getRefCol1() {
        return refCol1;
    }
    /**
     * @param refCol1 the refCol1 to set
     */
    public void setRefCol1(String refCol1) {
        this.refCol1 = refCol1;
    }
    /**
     * @return the refCol2
     */
    public String getRefCol2() {
        return refCol2;
    }
    /**
     * @param refCol2 the refCol2 to set
     */
    public void setRefCol2(String refCol2) {
        this.refCol2 = refCol2;
    }
    /**
     * @return the refCol3
     */
    public String getRefCol3() {
        return refCol3;
    }
    /**
     * @param refCol3 the refCol3 to set
     */
    public void setRefCol3(String refCol3) {
        this.refCol3 = refCol3;
    }
    /**
     * @return the refCol4
     */
    public String getRefCol4() {
        return refCol4;
    }
    /**
     * @param refCol4 the refCol4 to set
     */
    public void setRefCol4(String refCol4) {
        this.refCol4 = refCol4;
    }
    /**
     * @return the refCol5
     */
    public String getRefCol5() {
        return refCol5;
    }
    /**
     * @param refCol5 the refCol5 to set
     */
    public void setRefCol5(String refCol5) {
        this.refCol5 = refCol5;
    }
    /**
     * @return the atchSe
     */
    public String getAtchSe() {
        return atchSe;
    }
    /**
     * @param atchSe the atchSe to set
     */
    public void setAtchSe(String atchSe) {
        this.atchSe = atchSe;
    }
    /**
     * @return the atchId
     */
    public String getAtchId() {
        return atchId;
    }
    /**
     * @param atchId the atchId to set
     */
    public void setAtchId(String atchId) {
        this.atchId = atchId;
    }
    /**
     * @return the fileNo
     */
    public int getFileNo() {
        return fileNo;
    }
    /**
     * @param fileNo the fileNo to set
     */
    public void setFileNo(int fileNo) {
        this.fileNo = fileNo;
    }
    
    
}
