package com.mobis.maps.comm.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;

import able.com.exception.BizException;
import able.com.service.HService;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.SapCodeVO;
import com.mobis.maps.comm.constants.RfcLangCd;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommCodeService;
import com.mobis.maps.comm.service.dao.MapsCommCodeMDAO;
import com.mobis.maps.comm.vo.MapsCommCodeGroupVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 공통코드 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommCodeServiceImpl.java
 * @Description : 공통코드 서비스를 구현.
 * @author Sin Sanghwan
 * @since 2019. 8. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 29.     Sin Sanghwan       최초 생성
 * </pre>
 */
@Service("mapsCommCodeService")
public class MapsCommCodeServiceImpl extends HService implements MapsCommCodeService {

    @Resource(name="mapsCommCodeMDAO")
    private MapsCommCodeMDAO mapsCommCodeMDAO;
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectCommCodeAllPgList(com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommCodeVO> selectCommCodeAllPgList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {
        
        List<MapsCommCodeVO> commCodes =  mapsCommCodeMDAO.selectCommCodeAllPgList(commCodeVO);
        
        return commCodes;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectCommCodeGroupPgList(com.mobis.maps.comm.vo.MapsCommCodeGroupVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommCodeGroupVO> selectCommCodeGroupPgList(MapsCommCodeGroupVO commCodeGroupVO, LoginInfoVO loginInfo) throws Exception {
        
        List<MapsCommCodeGroupVO> commCodeGroups =  mapsCommCodeMDAO.selectCommCodeGroupPgList(commCodeGroupVO);
        
        return commCodeGroups;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectCommCodeGroup(com.mobis.maps.comm.vo.MapsCommCodeGroupVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommCodeGroupVO selectCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO, LoginInfoVO loginInfo) throws Exception {
        
        MapsCommCodeGroupVO commCodeGroup = mapsCommCodeMDAO.selectCommCodeGroup(commCodeGroupVO);
        
        return commCodeGroup;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#insertCommCodeGroup(com.mobis.maps.comm.vo.MapsCommCodeGroupVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int insertCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO, LoginInfoVO loginInfo) throws Exception {

        commCodeGroupVO.setRegistId(loginInfo.getUserSeqId());
        commCodeGroupVO.setUpdtId(loginInfo.getUserSeqId());
        
        mapsCommCodeMDAO.insertCommCodeGroup(commCodeGroupVO);
        
        return 1;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#updateCommCodeGroup(com.mobis.maps.comm.vo.MapsCommCodeGroupVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        commCodeGroupVO.setRegistId(loginInfo.getUserSeqId());
        commCodeGroupVO.setUpdtId(loginInfo.getUserSeqId());
        
        procCnt = mapsCommCodeMDAO.updateCommCodeGroup(commCodeGroupVO);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#deleteCommCodeGroup(com.mobis.maps.comm.vo.MapsCommCodeGroupVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int deleteCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        commCodeGroupVO.setRegistId(loginInfo.getUserSeqId());
        commCodeGroupVO.setUpdtId(loginInfo.getUserSeqId());
        /* 공통코드그룹 물리삭제 */
        // 공통코드그룹 삭제
        procCnt = mapsCommCodeMDAO.deleteCommCodeGroup(commCodeGroupVO);
        // 공통코드 삭제
        mapsCommCodeMDAO.deleteCommCodeAll(commCodeGroupVO);
//        /* 공통코드그룹 논리삭제 */
//        // 공통코드그룹 삭제
//        procCnt = mapsCommCodeMDAO.updateDelCommCodeGroup(commCodeGroupVO);
//        // 공통코드 삭제
//        mapsCommCodeMDAO.updateDelCommCodeAll(commCodeGroupVO);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectCommCodePgList(com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommCodeVO> selectCommCodePgList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {
        
        List<MapsCommCodeVO> commCodes = mapsCommCodeMDAO.selectCommCodePgList(commCodeVO);
        
        return commCodes;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#multiCommCode(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiCommCode(List<MapsCommCodeVO> commCodes, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        
        MapsCommCodeVO resultCommCode = null;
        
        for (MapsCommCodeVO commCode: commCodes) {
            
            int rowType = commCode.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            commCode.setRegistId(loginInfo.getUserSeqId());
            commCode.setUpdtId(loginInfo.getUserSeqId());

            resultCommCode = mapsCommCodeMDAO.selectCommCode(commCode);
            
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    if (resultCommCode != null) {
                        throw new BizException(messageSource, "EC00000011", new String[]{"Common Code Info"}, null);
                    }
                    mapsCommCodeMDAO.insertCommCode(commCode);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    if (resultCommCode == null) {
                        throw new BizException(messageSource, "EC00000011", new String[]{"Common Code Info"}, null);
                    }
                    mapsCommCodeMDAO.updateCommCode(commCode);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    if (mapsCommCodeMDAO == null) {
                        throw new BizException(messageSource, "EC00000011", new String[]{"Common Code Info"}, null);
                    }
                    mapsCommCodeMDAO.deleteCommCode(commCode);
                    break;
                default :
                    continue;
            }
            procCnt++;
        }
        
        return procCnt;
    }
    
    /**
     * 코드조회 초기화
     *
     * @param commCodeVO
     * @param codes
     * @param loginInfo
     * @throws Exception
     */
    private void selectCodeInit(MapsCommCodeVO commCodeVO, List<CodeVO> codes, LoginInfoVO loginInfo) throws Exception {

        if (StringUtils.isBlank(commCodeVO.getLangCd())) {
            if (loginInfo != null) {
                commCodeVO.setLangCd(loginInfo.getUserLcale().toString());
            } else {
                commCodeVO.setLangCd(MapsConstants.DFLT_LOCALE.toString());
            }
        }

        String cboSjTy = commCodeVO.getCboSjTy();
        if (StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_ALL)
                || StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_SELECT)
                || StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_KEYWORD)) {
            codes.add(selectBlankCodeList(commCodeVO, commCodeVO.getCboSjTy()));
        }
    }
    
    /**
     * 초기값콤보 코드정보 추가
     *
     * @param commCodeVO
     * @param codes
     * @param cboSjTy
     * @throws Exception 
     */
    private CodeVO selectBlankCodeList(MapsCommCodeVO commCodeVO, String cboSjTy) throws Exception {
        
        CodeVO addCodeVO = new CodeVO();
        addCodeVO.setCodeGroup(commCodeVO.getCodeGroup());
        if (StringUtils.isNotBlank(commCodeVO.getCboDfltVal())) {
            addCodeVO.setCode(commCodeVO.getCboDfltVal());
        }
        
        if (StringUtils.isBlank(commCodeVO.getCboDfltId())) {
            if (StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_ALL)) {
                commCodeVO.setCboDfltId("W0000000158");
            } else if (StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_SELECT)) {
                commCodeVO.setCboDfltId("W0000000157");
            } else if (StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_KEYWORD)) {
                commCodeVO.setCboDfltId("W0000002989");
            }
        }
        
        String codeNm = null;
        if (StringUtils.isNotBlank(commCodeVO.getCboDfltId())) {
            codeNm = mapsCommCodeMDAO.selectCodeWordNm(commCodeVO);
        } else {
            if (StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_ALL)) {
                codeNm = "-- All --";
            } else if (StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_SELECT)) {
                codeNm = "-- Select --";
            } else if (StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_KEYWORD)) {
                codeNm = "-- Keyword --";
            } else {
                codeNm = commCodeVO.getCboDfltId();
            }
        }
        addCodeVO.setCodeNm(codeNm);
        
        return addCodeVO;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectCodeList(com.mobis.maps.comm.vo.MapsCommCodeVO)
     */
    @Override
    public List<CodeVO> selectCodeList(MapsCommCodeVO commCodeVO) throws Exception {
        return selectCodeList(commCodeVO, null);
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectCodeList(com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<CodeVO> selectCodeList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {

        List<CodeVO> codes = new ArrayList<CodeVO>();

        selectCodeInit(commCodeVO, codes, loginInfo);
        
        codes.addAll(mapsCommCodeMDAO.selectCodeList(commCodeVO));
        
        return codes;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectLwprtCodeList(com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<CodeVO> selectLwprtCodeList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {
        
        List<CodeVO> codes = new ArrayList<CodeVO>();

        selectCodeInit(commCodeVO, codes, loginInfo);
        
        codes.addAll(mapsCommCodeMDAO.selectLwprtCodeList(commCodeVO));
        
        return codes;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectCodeNm(com.mobis.maps.comm.vo.MapsCommCodeVO)
     */
    @Override
    public CodeVO selectCodeNm(MapsCommCodeVO commCodeVO) throws Exception {
        
        CodeVO codeVO = mapsCommCodeMDAO.selectCodeNm(commCodeVO);
        
        return codeVO;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectCodeNm(com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public CodeVO selectCodeNm(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {

        if (StringUtils.isBlank(commCodeVO.getLangCd())) {
            if (loginInfo != null) {
                commCodeVO.setLangCd(loginInfo.getUserLcale().toString());
            } else {
                commCodeVO.setLangCd(MapsConstants.DFLT_LOCALE.toString());
            }
        }
        
        CodeVO codeVO = selectCodeNm(commCodeVO);
        
        return codeVO;
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectSapCodeList(com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<SapCodeVO> selectSapCodeList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {
        
        selectInitSapCommCodeVO(commCodeVO, loginInfo);
        
        List<SapCodeVO> codes = new ArrayList<SapCodeVO>();
        String cboSjTy = commCodeVO.getCboSjTy();
        if (StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_ALL)
                || StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_SELECT)
                || StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_KEYWORD)) {
            CodeVO blankCode = selectBlankCodeList(commCodeVO, commCodeVO.getCboSjTy());
            SapCodeVO blankSapCode = new SapCodeVO();
            BeanUtils.copyProperties(blankSapCode, blankCode);
            codes.add(blankSapCode);
        }
        
        List<SapCodeVO> rsltCodes= mapsCommCodeMDAO.selectSapCodeList(commCodeVO);
        for (SapCodeVO sapCodeVO: rsltCodes) {
            selectSetSapCommCodeInfo(commCodeVO.getCodeColNm(), commCodeVO.getDispTy(), sapCodeVO);
        }
        
        codes.addAll(rsltCodes);
        
        return codes;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectSapCodeNm(com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public SapCodeVO selectSapCodeNm(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {

        selectInitSapCommCodeVO(commCodeVO, loginInfo);
        
        SapCodeVO sapCodeVO = mapsCommCodeMDAO.selectSapCodeNm(commCodeVO);
        
        selectSetSapCommCodeInfo(commCodeVO.getCodeColNm(), commCodeVO.getDispTy(), sapCodeVO);
        
        return sapCodeVO;
    }
    
    /**
     * SAP코드 조회조건 초기화
     *
     * @param commCodeVO
     * @param loginInfo
     * @throws Exception
     */
    private void selectInitSapCommCodeVO(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {
        // RFC 시스템
        RfcSapSys rfcSapSys = RfcSapSys.get(commCodeVO.getSysId());
        if (rfcSapSys == null) {
            rfcSapSys = RfcSapSys.PC;
        }
        // SYSID
        commCodeVO.setSysId(rfcSapSys.getSysId());
        // CLIENT
        commCodeVO.setClient(rfcSapSys.getClient());
        // 언어키
        RfcLangCd rfcLangCd = RfcLangCd.EN;
        Locale locale = MapsConstants.DFLT_LOCALE;
        if (loginInfo != null) {
            rfcLangCd = RfcLangCd.get(loginInfo.getRfcServerLang());
            locale = loginInfo.getUserLcale();
        } else {
            if (StringUtils.isNotBlank(commCodeVO.getLangCd())) {
                
                MapsCommCodeVO resultCommCode = selectLangCode(commCodeVO);
                
                rfcLangCd = RfcLangCd.get(resultCommCode.getCodeRefer2());
            }
        }
        if (StringUtils.isBlank(commCodeVO.getAspLangKey())) {
            commCodeVO.setAspLangKey(rfcLangCd.getLangKey());
        }
        if (StringUtils.isBlank(commCodeVO.getLangCd())) {
            commCodeVO.setLangCd(locale.toString());
        }
    }
    
    /**
     * 언어코드 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    private MapsCommCodeVO selectLangCode(MapsCommCodeVO commCodeVO) throws Exception {

        MapsCommCodeVO langCodeVO = new MapsCommCodeVO();
        langCodeVO.setCodeGroup("C000000001");
        langCodeVO.setCode(commCodeVO.getLangCd());
        
        MapsCommCodeVO resultlangCode = mapsCommCodeMDAO.selectCommCode(langCodeVO);
        
        return resultlangCode;
    }

    /**
     * SAP코드 정보 설정
     *
     * @param codeColNm
     * @param dispTy
     * @param sapCodeVO
     * @throws Exception
     */
    private void selectSetSapCommCodeInfo(String codeColNm, String dispTy, SapCodeVO sapCodeVO) throws Exception {
        
        if (!StringUtils.defaultString(codeColNm).matches("codeRefer1|codeRefer2|codeRefer3|codeRefer4|codeRefer5")) {
            return;
        }
        
        if (sapCodeVO == null) {
            return;
        }
        
        String code = BeanUtils.getProperty(sapCodeVO, codeColNm);
        String codeNm = StringUtils.defaultIfBlank(sapCodeVO.getCodeNm(), code);
        
        if (MapsCommCodeService.CODE_DISP_TY_KEY.equals(dispTy)) {
            codeNm = code;
        } else if (MapsCommCodeService.CODE_DISP_TY_KEY_VALUE.equals(dispTy)) {
            codeNm = code + " : " + codeNm;
        } else if (MapsCommCodeService.CODE_DISP_TY_VALUE_KEY.equals(dispTy)) {
            codeNm = codeNm + " : " + code;
        }
        
//        if (logger.isDebugEnabled()) {
//            logger.debug("→ selectSetSapCommCode::[codeColNm=" + codeColNm + "]before[codeNm=" + sapCodeVO.getCodeNm() + "]after[code=" + code + ",codeNm=" + codeNm + "]");
//        }
        sapCodeVO.setCode(code);
        sapCodeVO.setCodeNm(codeNm);
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectDomnCodeList(com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<CodeVO> selectDomnCodeList(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {
        
        selectInitDomnCommCodeVO(commCodeVO, loginInfo);
        
        List<CodeVO> codes = new ArrayList<CodeVO>();
        String cboSjTy = commCodeVO.getCboSjTy();
        if (StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_ALL)
                || StringUtils.equals(cboSjTy, MapsCommCodeService.CBO_SJ_TY_SELECT)) {
            CodeVO blankCode = selectBlankCodeList(commCodeVO, commCodeVO.getCboSjTy());
            SapCodeVO blankSapCode = new SapCodeVO();
            BeanUtils.copyProperties(blankSapCode, blankCode);
            codes.add(blankSapCode);
        }
        
        codes.addAll(mapsCommCodeMDAO.selectDomnCodeList(commCodeVO));
        
        return codes;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectDomnCodeNm(com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public CodeVO selectDomnCodeNm(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {

        selectInitDomnCommCodeVO(commCodeVO, loginInfo);
        
        CodeVO codeVO = mapsCommCodeMDAO.selectDomnCodeNm(commCodeVO);
        
        return codeVO;
    }
    
    /**
     * Domain코드 조회조건 초기화
     *
     * @param commCodeVO
     * @param loginInfo
     * @throws Exception
     */
    private void selectInitDomnCommCodeVO(MapsCommCodeVO commCodeVO, LoginInfoVO loginInfo) throws Exception {
        // RFC 시스템
        RfcSapSys rfcSapSys = RfcSapSys.get(commCodeVO.getSysId());
        if (rfcSapSys == null) {
            rfcSapSys = RfcSapSys.PC;
        }
        // SYSID
        commCodeVO.setSysId(rfcSapSys.getDomainSysId());
        // CLIENT
        commCodeVO.setClient(rfcSapSys.getDomainClient());
        // 언어키
        RfcLangCd rfcLangCd = RfcLangCd.EN;
        Locale locale = MapsConstants.DFLT_LOCALE;
        if (loginInfo != null) {
            rfcLangCd = RfcLangCd.get(loginInfo.getRfcServerLang());
            locale = loginInfo.getUserLcale();
        } else {
            if (StringUtils.isNotBlank(commCodeVO.getLangCd())) {
                
                MapsCommCodeVO resultCommCode = selectLangCode(commCodeVO);
                
                rfcLangCd = RfcLangCd.get(resultCommCode.getCodeRefer2());
            }
        }
        if (StringUtils.isBlank(commCodeVO.getAspLangKey())) {
            commCodeVO.setAspLangKey(rfcLangCd.getLangKey());
        }
        if (StringUtils.isBlank(commCodeVO.getLangCd())) {
            commCodeVO.setLangCd(locale.toString());
        }
    }
}
