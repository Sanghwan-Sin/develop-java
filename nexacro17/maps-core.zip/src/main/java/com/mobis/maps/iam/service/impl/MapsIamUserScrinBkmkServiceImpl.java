package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamUserScrinBkmkService;
import com.mobis.maps.iam.service.dao.MapsIamUserScrinBkmkMDAO;
import com.mobis.maps.iam.vo.MapsIamUserScrinBkmkVO;

/**
 * <pre>
 * 사용자 화면 즐겨찾기 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinBkmkServiceImpl.java
 * @Description : 사용자 화면 즐겨찾기에 대한 서비스를 구현.
 * @author DT048058
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsIamUserScrinBkmkService")
public class MapsIamUserScrinBkmkServiceImpl extends HService implements MapsIamUserScrinBkmkService {
    
    @Resource(name = "mapsIamUserScrinBkmkMDAO")
    private MapsIamUserScrinBkmkMDAO mapsIamUserScrinBkmkMDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserScrinBkmkService#selectUserScrinBkmkList(com.mobis.maps.iam.vo.MapsIamUserScrinBkmkVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserScrinBkmkVO> selectUserScrinBkmkList(MapsIamUserScrinBkmkVO iamUserScrinBkmkVO
            , LoginInfoVO loginInfo) throws Exception {
        
        iamUserScrinBkmkVO.setUserSeqId(loginInfo.getUserSeqId());
        iamUserScrinBkmkVO.setLangCd(loginInfo.getUserLcale().toString());
        
        List<MapsIamUserScrinBkmkVO> lstUserScrinBkmk = mapsIamUserScrinBkmkMDAO.selectUserScrinBkmkList(iamUserScrinBkmkVO);
        
        return lstUserScrinBkmk;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserScrinBkmkService#insertUserScrinBkmk(com.mobis.maps.iam.vo.MapsIamUserScrinBkmkVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int insertUserScrinBkmk(MapsIamUserScrinBkmkVO iamUserScrinBkmkVO, LoginInfoVO loginInfo) throws Exception {
        
        iamUserScrinBkmkVO.setUserSeqId(loginInfo.getUserSeqId());
        
        mapsIamUserScrinBkmkMDAO.insertUserScrinBkmk(iamUserScrinBkmkVO);
        
        return 1;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserScrinBkmkService#deleteUserScrinBkmk(com.mobis.maps.iam.vo.MapsIamUserScrinBkmkVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int deleteUserScrinBkmk(MapsIamUserScrinBkmkVO iamUserScrinBkmkVO, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        
        iamUserScrinBkmkVO.setUserSeqId(loginInfo.getUserSeqId());

        procCnt = mapsIamUserScrinBkmkMDAO.deleteUserScrinBkmk(iamUserScrinBkmkVO);
        
        return procCnt;
    }

}
