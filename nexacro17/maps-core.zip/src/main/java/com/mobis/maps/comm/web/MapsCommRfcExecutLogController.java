package com.mobis.maps.comm.web;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommRfcExecutLogService;
import com.mobis.maps.comm.vo.MapsCommRfcExecutLogVO;

/**
 * <pre>
 * RFC실행로그 컨트롤러 정의
 * </pre>
 *
 * @ClassName   : MapsCommRfcExecutLogController.java
 * @Description : RFC실행로그에 대한 컨트롤러를 정의.
 * @author DT048058
 * @since 2020. 2. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 7.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommRfcExecutLogController extends HController {

    @Resource(name = "mapsCommRfcExecutLogService")
    private MapsCommRfcExecutLogService mapsCommRfcExecutLogService;

    /**
     * RFC실행로그 초기화 조회
     *
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectRfcExecutLogInit.do")
    public NexacroResult selectRfcExecutLogInit(NexacroResult result) throws Exception {
        
        Map<String, Object> mInit = mapsCommRfcExecutLogService.selectRfcExecutLogInit();
        
        Iterator<String> i = mInit.keySet().iterator();
        while (i.hasNext()) {
            String dsNm = i.next();
            result.addDataSet(dsNm, mInit.get(dsNm));
        }
        
        return result;
    }

    /**
     * RFC실행로그 페이징 리스트 조회
     *
     * @param commRfcExecutLogVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectRfcExecutLogPgList.do")
    public NexacroResult selectRfcExecutLogPgList(
            @ParamDataSet(name="dsInput") MapsCommRfcExecutLogVO commRfcExecutLogVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommRfcExecutLogVO>  rfcExecutLogs = mapsCommRfcExecutLogService.selectRfcExecutLogPgList(commRfcExecutLogVO, loginInfo);
        
        result.addDataSet("dsOutput", rfcExecutLogs);
        
        return result;
    }
    
    /**
     * RFC실행로그 데이터 리스트 조회
     *
     * @param commRfcExecutLogVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectRfcExecutLogDataList.do")
    public NexacroResult selectRfcExecutLogDataList(
            @ParamDataSet(name="dsInput") MapsCommRfcExecutLogVO commRfcExecutLogVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommRfcExecutLogVO>  rfcExecutLogDatas = mapsCommRfcExecutLogService.selectRfcExecutLogDataList(commRfcExecutLogVO, loginInfo);
        
        result.addDataSet("dsOutput", rfcExecutLogDatas);
        
        return result;
    }
}
