package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 계정신청허용IP 항목
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstPermIpVO.java
 * @Description : 계정신청허용IP에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamAcntReqstPermIpVO extends MapsIamCommVO {
    /** 계정신청번호 */
    private String acntReqstNo;
    /** 허용IP주소 */
    private String permIpAdres;
    /* 승인정보 */
    /** 사용자허용IP관리순번 */
    private int userPermIpManageSeq;
    /** 사용자순번ID */
    private String userSeqId;
    /**
     * @return the acntReqstNo
     */
    public String getAcntReqstNo() {
        return acntReqstNo;
    }
    /**
     * @param acntReqstNo the acntReqstNo to set
     */
    public void setAcntReqstNo(String acntReqstNo) {
        this.acntReqstNo = acntReqstNo;
    }
    /**
     * @return the permIpAdres
     */
    public String getPermIpAdres() {
        return permIpAdres;
    }
    /**
     * @param permIpAdres the permIpAdres to set
     */
    public void setPermIpAdres(String permIpAdres) {
        this.permIpAdres = permIpAdres;
    }
    /**
     * @return the userPermIpManageSeq
     */
    public int getUserPermIpManageSeq() {
        return userPermIpManageSeq;
    }
    /**
     * @param userPermIpManageSeq the userPermIpManageSeq to set
     */
    public void setUserPermIpManageSeq(int userPermIpManageSeq) {
        this.userPermIpManageSeq = userPermIpManageSeq;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
}
