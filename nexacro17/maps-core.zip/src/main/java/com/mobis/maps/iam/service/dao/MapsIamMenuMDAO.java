package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.iam.vo.MapsIamMenuScreenVO;
import com.mobis.maps.iam.vo.MapsIamMenuVO;

/**
 * <pre>
 * 메뉴 관리 데이터처리
 * </pre>
 *
 * @ClassName   : MapsIamMenuMDAO.java
 * @Description : 메뉴 관리 데이터처를 정의.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
@Mapper("mapsIamMenuMDAO")
public interface MapsIamMenuMDAO {

    /**
     * 메뉴 리스트 조회
     *
     * @param iamMenuVO
     * @return
     * @throws Exception
     */
    public List<MapsIamMenuVO> selectMenuList(MapsIamMenuVO iamMenuVO) throws Exception;
    
    /**
     * 메뉴 조회
     *
     * @param iamMenuVO
     * @return
     * @throws Exception
     */
    public MapsIamMenuVO selectMenuInfo(MapsIamMenuVO iamMenuVO) throws Exception;
         
    /**
     * 메뉴 저장
     *
     * @param iamMenuVO
     * @throws Exception
     */
    public void insertMenuInfo(MapsIamMenuVO iamMenuVO) throws Exception;
        
    /**
     * 메뉴 수정
     *
     * @param iamMenuVO
     * @return
     * @throws Exception
     */
    public int updateMenuInfo(MapsIamMenuVO iamMenuVO) throws Exception;
        
    /**
     * 메뉴 삭제
     *
     * @param iamMenuVO
     * @return
     * @throws Exception
     */
    public int deleteMenuInfo(MapsIamMenuVO iamMenuVO) throws Exception;
    
    
    /**
     * 메뉴화면 리스트 조회
     *
     * @param iamMenuVO
     * @return
     * @throws Exception
     */
    public List<MapsIamMenuScreenVO> selectMenuScreenList(MapsIamMenuVO iamMenuVO) throws Exception;
    
    /**
     * 메뉴화면 저장
     *
     * @param iamMenuVO
     * @throws Exception
     */
    public void insertMenuScreenInfo(MapsIamMenuScreenVO iamMenuScreenVO) throws Exception;
        
    /**
     * 메뉴화면 수정
     *
     * @param iamMenuVO
     * @return
     * @throws Exception
     */
    public int updateMenuScreenInfo(MapsIamMenuScreenVO iamMenuScreenVO) throws Exception;
    
    /**
     * 메뉴화면 삭제
     *
     * @param iamMenuScreenVO
     * @return
     * @throws Exception
     */
    public int deleteMenuScreenInfo(MapsIamMenuScreenVO iamMenuScreenVO) throws Exception;
        
    /**
     * 메뉴화면 삭제 By MenuId
     *
     * @param iamMenuVO
     * @return
     * @throws Exception
     */
    public int deleteMenuScreenInfoByMenuId(MapsIamMenuVO iamMenuVO) throws Exception;
    
    
    
}
