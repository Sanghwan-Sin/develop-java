package com.mobis.maps.iam.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.annotation.ParamVariable;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamAcntReqstInfoService;
import com.mobis.maps.iam.vo.MapsIamAcntReqstAuthorVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstLangVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstPermIpVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstVO;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;

/**
 * <pre>
 * 계정신청 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstInfoController.java
 * @Description : 계정신청에 대한 컨트롤러를 정의.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamAcntReqstInfoController extends HController {
    
    @Resource
    private Validator validator;
    
    @Resource(name = "mapsIamAcntReqstInfoService")
    private MapsIamAcntReqstInfoService mapsIamAcntReqstInfoService;

    /**
     * 계정신청정보 조회
     *
     * @param iamAcntReqstVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAcntReqstInfo.do")
    public NexacroResult selectAcntReqstInfo(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstVO iamAcntReqstVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        MapsIamAcntReqstVO iamAcntReqst = mapsIamAcntReqstInfoService.selectAcntReqstInfo(iamAcntReqstVO, loginInfo);

        result.addDataSet("dsOutput", iamAcntReqst.getIamAcntReqstInfo());
        result.addDataSet("dsOutputLang", iamAcntReqst.getAcntReqstLangs());
        result.addDataSet("dsOutputPermIp", iamAcntReqst.getAcntReqstPermIps());
        result.addDataSet("dsOutputAuthor", iamAcntReqstVO.getAcntReqstAuthors());

        return result;
    }
    
    /**
     * 권한마스터 리스트 조회
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAuthorMstList.do")
    public NexacroResult selectAuthorMstList(
              @ParamDataSet(name="dsInput") MapsIamAuthorVO iamAuthorVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamAuthorVO> authorMsts = mapsIamAcntReqstInfoService.selectAuthorMstList(iamAuthorVO, loginInfo);

        result.addDataSet("dsOutput", authorMsts);

        return result;
    }
    
    /**
     * 계정신청정보 저장
     *
     * @param iamAcntReqstInfo
     * @param acntReqstLangs
     * @param acntReqstPermIps
     * @param acntReqstAuthor
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/insertAcntReqst.do")
    public NexacroResult insertAcntReqst(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfo
            , @ParamDataSet(name="dsInputLang") List<MapsIamAcntReqstLangVO> acntReqstLangs
            , @ParamDataSet(name="dsInputPermIp") List<MapsIamAcntReqstPermIpVO> acntReqstPermIps
            , @ParamDataSet(name="dsInputAuthor") List<MapsIamAcntReqstAuthorVO> acntReqstAuthors
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        //ValidatorUtil.validate(propInfos, validator);

        MapsIamAcntReqstVO iamAcntReqstVO = new MapsIamAcntReqstVO();
        iamAcntReqstVO.setIamAcntReqstInfo(iamAcntReqstInfo);
        iamAcntReqstVO.setAcntReqstLangs(acntReqstLangs);
        iamAcntReqstVO.setAcntReqstPermIps(acntReqstPermIps);
        iamAcntReqstVO.setAcntReqstAuthors(acntReqstAuthors);

        int procCnt = mapsIamAcntReqstInfoService.insertAcntReqst(iamAcntReqstVO, loginInfo);

        result.addVariable("procCnt", procCnt);
        result.addDataSet("dsOutput", iamAcntReqstVO.getIamAcntReqstInfo());
        
        return result;
    }

    /**
     * 계정신청정보 신청
     *
     * @param iamAcntReqstInfo
     * @param acntReqstLangs
     * @param acntReqstPermIps
     * @param acntReqstAuthor
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/insertReqstAcnt.do")
    public NexacroResult insertReqstAcnt(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfo
            , @ParamDataSet(name="dsInputLang") List<MapsIamAcntReqstLangVO> acntReqstLangs
            , @ParamDataSet(name="dsInputPermIp") List<MapsIamAcntReqstPermIpVO> acntReqstPermIps
            , @ParamDataSet(name="dsInputAuthor") List<MapsIamAcntReqstAuthorVO> acntReqstAuthors
            , HttpServletRequest request
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        MapsIamAcntReqstVO iamAcntReqstVO = new MapsIamAcntReqstVO();
        iamAcntReqstVO.setIamAcntReqstInfo(iamAcntReqstInfo);
        iamAcntReqstVO.setAcntReqstLangs(acntReqstLangs);
        iamAcntReqstVO.setAcntReqstPermIps(acntReqstPermIps);
        iamAcntReqstVO.setAcntReqstAuthors(acntReqstAuthors);

        int procCnt = mapsIamAcntReqstInfoService.insertReqstAcnt(iamAcntReqstVO, request, loginInfo);

        result.addVariable("procCnt", procCnt);
        result.addDataSet("dsOutput", iamAcntReqstVO.getIamAcntReqstInfo());
        
        return result;
    }

    /**
     * 계정신청정보 삭제
     *
     * @param iamAcntReqstInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/deleteAcntReqstInfo.do")
    public NexacroResult deleteAcntReqstInfo(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamAcntReqstInfoService.deleteAcntReqstInfo(iamAcntReqstInfoVO, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    
    /**
     * 계정신청 승인 저장
     *
     * @param iamAcntReqstInfo
     * @param acntReqstLangs
     * @param acntReqstPermIps
     * @param acntReqstAuthors
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateApprvSaveAcntReqst.do")
    public NexacroResult updateApprvSaveAcntReqst(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfo
            , @ParamDataSet(name="dsInputLang") List<MapsIamAcntReqstLangVO> acntReqstLangs
            , @ParamDataSet(name="dsInputPermIp") List<MapsIamAcntReqstPermIpVO> acntReqstPermIps
            , @ParamDataSet(name="dsInputAuthor") List<MapsIamAcntReqstAuthorVO> acntReqstAuthors
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        MapsIamAcntReqstVO iamAcntReqstVO = new MapsIamAcntReqstVO();
        iamAcntReqstVO.setIamAcntReqstInfo(iamAcntReqstInfo);
        iamAcntReqstVO.setAcntReqstLangs(acntReqstLangs);
        iamAcntReqstVO.setAcntReqstPermIps(acntReqstPermIps);
        iamAcntReqstVO.setAcntReqstAuthors(acntReqstAuthors);

        int procCnt = mapsIamAcntReqstInfoService.updateApprvSaveAcntReqst(iamAcntReqstVO, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 계정신청 승인
     *
     * @param iamAcntReqstInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateAcntReqstApprv.do")
    public NexacroResult updateAcntReqstApprv(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamAcntReqstInfoService.updateAcntReqstApprv(iamAcntReqstInfoVO, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * 계정신청 반려
     *
     * @param iamAcntReqstInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateAcntReqstReturn.do")
    public NexacroResult updateAcntReqstReturn(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamAcntReqstInfoService.updateAcntReqstReturn(iamAcntReqstInfoVO, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * [비로그인]계정존재 조회
     *
     * @param iamAcntReqstVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectAcntExst.do")
    public NexacroResult selectAcntExst(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , NexacroResult result) throws Exception {

        MapsIamUserVO iamUser = mapsIamAcntReqstInfoService.selectAcntExst(iamAcntReqstInfoVO);

        result.addDataSet("dsOutput", iamUser);

        return result;
    }
    
    /**
     * [비로그인]계정신청 조회
     *
     * @param iamAcntReqstVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectNlognAcntReqstInfo.do")
    public NexacroResult selectNlognAcntReqstInfo(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstVO iamAcntReqstVO
            , @ParamVariable(name="langCd") String langCd
            , NexacroResult result) throws Exception {

        MapsIamAcntReqstVO iamAcntReqst = mapsIamAcntReqstInfoService.selectNlognAcntReqstInfo(iamAcntReqstVO, langCd);

        result.addDataSet("dsOutput", iamAcntReqst.getIamAcntReqstInfo());
        result.addDataSet("dsOutputLang", iamAcntReqst.getAcntReqstLangs());
        result.addDataSet("dsOutputPermIp", iamAcntReqst.getAcntReqstPermIps());
        result.addDataSet("dsOutputAuthor", iamAcntReqstVO.getAcntReqstAuthors());

        return result;
    }
    
    /**
     * [비로그인]권한마스터 리스트 조회
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectAuthorMstList.do")
    public NexacroResult selectNlognAuthorMstList(
              @ParamDataSet(name="dsInput") MapsIamAuthorVO iamAuthorVO
            , NexacroResult result) throws Exception {

        List<MapsIamAuthorVO> authorMsts = mapsIamAcntReqstInfoService.selectNlognAuthorMstList(iamAuthorVO);

        result.addDataSet("dsOutput", authorMsts);

        return result;
    }

    /**
     * [비로그인]사용자기본정보 조회(Email)
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectUserBassInfoByEmail.do")
    public NexacroResult selectUserBassInfoByEmail(
              @ParamDataSet(name="dsInput") MapsIamUserBassInfoVO iamUserBassInfoVO
            , NexacroResult result) throws Exception {

        MapsIamUserBassInfoVO userBassInfo = mapsIamAcntReqstInfoService.selectUserBassInfoByEmail(iamUserBassInfoVO);

        result.addDataSet("dsOutput", userBassInfo);

        return result;
    }
    
    /**
     * [비로그인]계정신청 신청
     *
     * @param iamAcntReqstInfo
     * @param acntReqstLangs
     * @param acntReqstPermIps
     * @param acntReqstAuthor
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/insertNlognReqstAcnt.do")
    public NexacroResult insertNlognReqstAcnt(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfo
            , @ParamDataSet(name="dsInputLang") List<MapsIamAcntReqstLangVO> acntReqstLangs
            , @ParamDataSet(name="dsInputPermIp") List<MapsIamAcntReqstPermIpVO> acntReqstPermIps
            , @ParamDataSet(name="dsInputAuthor") List<MapsIamAcntReqstAuthorVO> acntReqstAuthors
            , @ParamVariable(name="langCd") String langCd
            , NexacroResult result) throws Exception {

        MapsIamAcntReqstVO iamAcntReqstVO = new MapsIamAcntReqstVO();
        iamAcntReqstVO.setIamAcntReqstInfo(iamAcntReqstInfo);
        iamAcntReqstVO.setAcntReqstLangs(acntReqstLangs);
        iamAcntReqstVO.setAcntReqstPermIps(acntReqstPermIps);
        iamAcntReqstVO.setAcntReqstAuthors(acntReqstAuthors);
        iamAcntReqstVO.setLangCd(langCd);

        int procCnt = mapsIamAcntReqstInfoService.insertNlognReqstAcnt(iamAcntReqstVO, langCd);

        result.addVariable("procCnt", procCnt);
        result.addDataSet("dsOutput", iamAcntReqstVO.getIamAcntReqstInfo());
        
        return result;
    }

    /**
     * [비로그인]계정신청정보 삭제
     *
     * @param iamAcntReqstInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/deleteNlognAcntReqstInfo.do")
    public NexacroResult deleteNlognAcntReqstInfo(
              @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , @ParamVariable(name="langCd") String langCd
            , NexacroResult result) throws Exception {

        int procCnt = mapsIamAcntReqstInfoService.deleteNlognAcntReqstInfo(iamAcntReqstInfoVO, langCd);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }
}
