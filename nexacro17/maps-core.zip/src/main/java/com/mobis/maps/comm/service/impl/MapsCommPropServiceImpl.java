package com.mobis.maps.comm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommPropService;
import com.mobis.maps.comm.service.dao.MapsCommPropMDAO;
import com.mobis.maps.comm.vo.MapsCommPropVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommPropServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 18.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsCommPropService")
public class MapsCommPropServiceImpl extends HService implements MapsCommPropService {

    @Resource(name="mapsCommPropMDAO")
    private MapsCommPropMDAO mapsCommPropMDAO;
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommPropService#selectPropPgList(com.mobis.maps.comm.vo.MapsCommPropVO)
     */
    @Override
    public List<MapsCommPropVO> selectPropPgList(MapsCommPropVO commPropVO) throws Exception {

        List<MapsCommPropVO> propInfos = mapsCommPropMDAO.selectPropPgList(commPropVO);
        
        return propInfos;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommPropService#multiPropInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiPropInfo(List<MapsCommPropVO> propInfos, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        
        for (MapsCommPropVO commProp: propInfos) {
            
            int rowType = commProp.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            commProp.setRegistId(loginInfo.getUserSeqId());
            commProp.setUpdtId(loginInfo.getUserSeqId());
            
            MapsCommPropVO resultCommProp = null;
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    resultCommProp = mapsCommPropMDAO.selectPropInfo(commProp);
                    if (resultCommProp != null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Message Info"}, null);
                    }
                    mapsCommPropMDAO.insertPropInfo(commProp);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    mapsCommPropMDAO.updatePropInfo(commProp);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    resultCommProp = mapsCommPropMDAO.selectPropInfo(commProp);
                    if (resultCommProp == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Message Info"}, null);
                    }
                    mapsCommPropMDAO.deletePropInfo(commProp);
                    break;
                default :
                    break;
            }
            procCnt++;
        }
        
        return procCnt;
    }

}
