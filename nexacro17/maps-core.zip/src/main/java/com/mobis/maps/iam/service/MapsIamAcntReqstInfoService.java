package com.mobis.maps.iam.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstVO;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;

/**
 * <pre>
 * 계정신청 서비스
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstInfoService.java
 * @Description : 계정신청에 대한 서비스를 정의.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */
public interface MapsIamAcntReqstInfoService {
    
    /** 신청상태코드(0 : 작성중) */
    public final static String REQST_STTUS_CD_WRITING = "0";
    /** 신청상태코드(1 : 신청중) */
    public final static String REQST_STTUS_CD_REQUSETING = "1";
    /** 신청상태코드(2 : 반려) */
    public final static String REQST_STTUS_CD_RETURN = "2";
    /** 신청상태코드(3 : 발행) */
    public final static String REQST_STTUS_CD_PUBLICATION = "3";
    /** 신청상태코드(9 : 삭제) */
    public final static String REQST_STTUS_CD_DELETE = "9";

    /** 승인상태코드(0 : 승인대기중) */
    public final static String APPRV_STTUS_CD_WATING = "0";
    /** 승인상태코드(1 : 승인) */
    public final static String APPRV_STTUS_CD_APPROVAL= "1";
    /** 승인상태코드(2 : 반려) */
    public final static String APPRV_STTUS_CD_RETURN = "2";
    
    /**
     * 계정신청정보 조회
     *
     * @param iamAcntReqstVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsIamAcntReqstVO selectAcntReqstInfo(MapsIamAcntReqstVO iamAcntReqstVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 권한마스트 조회
     *
     * @param iamAuthorVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectAuthorMstList(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 계정 존재 조회
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamUserVO selectAcntExst(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;

    /**
     * 계정신청정보 신규등록
     *
     * @param iamAcntReqstVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int insertAcntReqst(MapsIamAcntReqstVO iamAcntReqstVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 계정신청 신청등록
     *
     * @param iamAcntReqstVO
     * @param request
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int insertReqstAcnt(MapsIamAcntReqstVO iamAcntReqstVO, HttpServletRequest request, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 계정신청 삭제
     *
     * @param iamAcntReqstInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int deleteAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 계정신청 승인 저장
     *
     * @param iamAcntReqstVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateApprvSaveAcntReqst(MapsIamAcntReqstVO iamAcntReqstVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 계정신청 승인
     *
     * @param iamAcntReqstInfoVO
     * @param request
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateAcntReqstApprv(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 계정신청 반려
     *
     * @param iamAcntReqstInfoVO
     * @param request
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int updateAcntReqstReturn(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * [비로그인]계정신청 조회
     *
     * @param iamAcntReqstVO
     * @param langCd
     * @return
     * @throws Exception
     */
    public MapsIamAcntReqstVO selectNlognAcntReqstInfo(MapsIamAcntReqstVO iamAcntReqstVO, String langCd) throws Exception;
    
    /**
     * [비로그인]권한마스트 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectNlognAuthorMstList(MapsIamAuthorVO iamAuthorVO) throws Exception;
    
    /**
     * [비로그인]사용자기본정보 조회 (Email)
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamUserBassInfoVO selectUserBassInfoByEmail(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * [비로그인] 계정신청 신청등록
     *
     * @param iamAcntReqstVO
     * @param langCd
     * @return
     * @throws Exception
     */
    public int insertNlognReqstAcnt(MapsIamAcntReqstVO iamAcntReqstVO, String langCd) throws Exception;
    
    /**
     * [비로그인] 계정신청 신청삭제
     *
     * @param iamAcntReqstInfoVO
     * @param langCd
     * @return
     * @throws Exception
     */
    public int deleteNlognAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, String langCd) throws Exception;
}
