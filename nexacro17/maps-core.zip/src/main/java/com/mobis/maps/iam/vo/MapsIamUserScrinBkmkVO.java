package com.mobis.maps.iam.vo;

import com.mobis.maps.comm.vo.CommVO;

/**
 * <pre>
 * 사용자 화면 즐겨찾기 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinBkmkVO.java
 * @Description : 사용자 화면 즐겨찾기에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserScrinBkmkVO extends CommVO {
    /** Level */
    private int level = 0;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 사용자순번ID */
    private String userSeqId;
    /** 화면ID */
    private String scrinId;
    /** 화면코드 */
    private String scrinCd;
    /** 화면명 */
    private String scrinNm;
    /**
     * @return the level
     */
    public int getLevel() {
        return level;
    }
    /**
     * @param level the level to set
     */
    public void setLevel(int level) {
        this.level = level;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the scrinCd
     */
    public String getScrinCd() {
        return scrinCd;
    }
    /**
     * @param scrinCd the scrinCd to set
     */
    public void setScrinCd(String scrinCd) {
        this.scrinCd = scrinCd;
    }
    /**
     * @return the scrinNm
     */
    public String getScrinNm() {
        return scrinNm;
    }
    /**
     * @param scrinNm the scrinNm to set
     */
    public void setScrinNm(String scrinNm) {
        this.scrinNm = scrinNm;
    }

}
