package com.mobis.maps.logback.db.names;

import ch.qos.logback.classic.db.names.DBNameResolver;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSapRfcDBNameResolver.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 7.     DT048058     	최초 생성
 * </pre>
 */

public class MapsSapRfcDBNameResolver implements DBNameResolver {

    /*
     * @see ch.qos.logback.classic.db.names.DBNameResolver#getTableName(java.lang.Enum)
     */
    @Override
    public <N extends Enum<?>> String getTableName(N tableName) {
        return tableName.toString();
    }

    /*
     * @see ch.qos.logback.classic.db.names.DBNameResolver#getColumnName(java.lang.Enum)
     */
    @Override
    public <N extends Enum<?>> String getColumnName(N columnName) {
        return columnName.toString();
    }
}
