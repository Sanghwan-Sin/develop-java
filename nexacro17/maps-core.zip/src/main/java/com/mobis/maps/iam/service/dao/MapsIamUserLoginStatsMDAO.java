package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.iam.vo.MapsIamUserLoginStatsVO;

/**
 * <pre>
 * 사용자 로그인 통계 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsIamUserLoginStatsMDAO.java
 * @Description : 사용자 로그인 통계에 대한 데이터 처리를 정의.
 * @author DT048058
 * @since 2020. 5. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 7.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsIamUserLoginStatsMDAO")
public interface MapsIamUserLoginStatsMDAO {

    /**
     * 사용자 로그인 통계 메인 리스트 조회
     *
     * @param iamUserLoginStatsVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserLoginStatsVO> selectUserLoginStatsMainList(MapsIamUserLoginStatsVO iamUserLoginStatsVO) throws Exception;

    /**
     * 사용자 로그인 통계 상세 리스트 조회
     *
     * @param iamUserLoginStatsVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserLoginStatsVO> selectUserLoginStatsDetailList(MapsIamUserLoginStatsVO iamUserLoginStatsVO) throws Exception;
    
}
