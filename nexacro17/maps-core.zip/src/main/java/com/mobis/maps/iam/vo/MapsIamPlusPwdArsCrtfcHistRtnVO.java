package com.mobis.maps.iam.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsIamPlusPwdArsCrtfcHistRtnVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2021. 1. 2.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2021. 1. 2.     oh.dongwon     	최초 생성
 * </pre>
 */

public class MapsIamPlusPwdArsCrtfcHistRtnVO {
    
    /** 0000 : 성공 이외의 값은 실패 (아래 인증결과 코드표 참조)  */
    private String resultCode;
    /** 요청 계정정보(사번)   */
    private String account;
    /** T_PLUS_PWD_ARS_CRTFC_HIST.CRTFC_SEQ_ID   */
    private String tranId;
    /**
     * @return the resultCode
     */
    public String getResultCode() {
        return resultCode;
    }
    /**
     * @param resultCode the resultCode to set
     */
    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }
    /**
     * @return the account
     */
    public String getAccount() {
        return account;
    }
    /**
     * @param account the account to set
     */
    public void setAccount(String account) {
        this.account = account;
    }
    /**
     * @return the tranId
     */
    public String getTranId() {
        return tranId;
    }
    /**
     * @param tranId the tranId to set
     */
    public void setTranId(String tranId) {
        this.tranId = tranId;
    }
    
    
}
