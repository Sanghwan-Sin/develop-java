package com.mobis.maps.iam.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamUserScrinStatsService;
import com.mobis.maps.iam.vo.MapsIamUserScrinStatsVO;

/**
 * <pre>
 * 사용자 화면 통계 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinStatsController.java
 * @Description : 사용자 화면 통계에 대한 컨트롤러를 정의.
 * @author DT048058
 * @since 2020. 5. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 7.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamUserScrinStatsController extends HController {
    
    @Resource(name = "mapsIamUserScrinStatsService")
    private MapsIamUserScrinStatsService mapsIamUserScrinStatsService;

    /**
     * 사용자 화면 접속 통계 메인 리스트 조회
     *
     * @param iamUserScrinStatsVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserScrinStatsMainList.do")
    public NexacroResult selectUserScrinStatsMainList(
            @ParamDataSet(name="dsInput") MapsIamUserScrinStatsVO iamUserScrinStatsVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserScrinStatsVO> userScrinStatsMains = mapsIamUserScrinStatsService.selectUserScrinStatsMainList(iamUserScrinStatsVO, loginInfo);
                
        result.addDataSet("dsOutput", userScrinStatsMains);        
        
        return result;
    }
    
    /**
     * 사용자 화면 접속 통계 상세 리스트 조회
     *
     * @param iamUserScrinStatsVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserScrinStatsDetailList.do")
    public NexacroResult selectUserScrinStatsDetailList(
            @ParamDataSet(name="dsInput") MapsIamUserScrinStatsVO iamUserScrinStatsVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserScrinStatsVO> userScrinStatsDetails = mapsIamUserScrinStatsService.selectUserScrinStatsDetailList(iamUserScrinStatsVO, loginInfo);
                
        result.addDataSet("dsOutput", userScrinStatsDetails);        
        
        return result;
    }
}
