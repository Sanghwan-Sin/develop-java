package com.mobis.maps.cmmn.interceptor;

import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.ui.adaptor.nexacro.servlet.NexacroContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsAuthenticException;
import com.mobis.maps.cmmn.exception.MapsScrinAuthenticException;
import com.mobis.maps.cmmn.spring.SpringApplicationContext;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommAuthenticService;
import com.mobis.maps.comm.vo.MapsCommAuthenticVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AuthenticInterceptor.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 7. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 16.     DT048058     	최초 생성
 * </pre>
 */

public class MapsAuthenticInterceptor extends HandlerInterceptorAdapter {
    
    protected Logger logger = LoggerFactory.getLogger(MapsAuthenticInterceptor.class);
    
    private static final String PROP_KEY_NON_CRTFC_YN_URL = "NON_CRTFC_YN_URL";
    
    private static final String PROP_KEY_NON_CRTFC_YN_SCREEN = "NON_CRTFC_YN_SCREEN";
    
    private static final String PROP_KEY_NON_LOGIN_SCRIN_ID = "NON_LOGIN_SCRIN_ID";

    private static final String OPEN_TYPE_MAIN = "M";
    
    private static final String OPEN_TYPE_POPUP = "P";
    
    private static final String OPEN_TYPE_URL = "U";
    
    private static final String LOGIN_SCRIN_ID = "S00000";
    
    private PathMatcher pathMatcher = new AntPathMatcher();

    private List<String> nonCrtfcUrlPattern;
    
    /*
     * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
     */
    @Override
    public boolean preHandle(
              HttpServletRequest request
            , HttpServletResponse response
            , Object handler) throws Exception {
        
        debugPreHandleStart(request, response);

        /* URL정보 */
        String uri = request.getRequestURI();
        if (logger.isDebugEnabled()) {
            logger.debug("preHandle::request[uri=" + uri + "]");
        }
        
        /* 로그인정보 */
        // 로그인정보 취득
        LoginInfoVO loginInfo = (LoginInfoVO) request.getSession().getAttribute(MapsConstants.SSS_LOGIN_INFO);
        // 로그인여부
        boolean isLogin = (loginInfo != null && StringUtils.isNotBlank(loginInfo.getUserSeqId()));
        if (logger.isDebugEnabled()) {
            logger.debug("preHandle::loginInfo[isLogin=" + isLogin + "]");
        }
        
        /* 미인증URL */
        boolean isNonCrtfcUrl = false;
        for (String urlPattern: nonCrtfcUrlPattern) {
            isNonCrtfcUrl = pathMatcher.match(urlPattern, uri);
            if (logger.isDebugEnabled()) {
                logger.debug("preHandle::nonCrtfcUrlPattern[urlPattern="+urlPattern+",isNonCrtFcUrl=" + isNonCrtfcUrl + "]");
            }
            if (isNonCrtfcUrl) {
                return true;
            }
        }
        
        /* 서비스 정의 */
        MapsCommAuthenticService mapsCommAuthenticService = (MapsCommAuthenticService) SpringApplicationContext.getBean("mapsCommAuthenticService");

        /* 인증정보설정 */
        MapsCommAuthenticVO commAuthenticVO = new MapsCommAuthenticVO();
        // 기본정보설정
        commAuthenticVO.setOpenTy(OPEN_TYPE_URL);
        // 화면실행및인증처리
        boolean isActionUrl = false;
        try {
            if (pathMatcher.match("/comm/selectAction.do", uri)) {
                String nonCrtfScrinYn = PropertiesUtil.getDbValue(PROP_KEY_NON_CRTFC_YN_SCREEN);
                if (logger.isDebugEnabled()) {
                    logger.debug("preHandle::Screen.start[nonCrtfUrlYn="+nonCrtfScrinYn+"]");
                }
                /* 프로퍼티정보 */
                if (StringUtils.equals(nonCrtfScrinYn, MapsConstants.YN_YES)) {
                    return true;
                }
    
                commAuthenticVO.setMenuId(request.getParameter("menuId"));
                commAuthenticVO.setScrinId(request.getParameter("scrinId"));
                commAuthenticVO.setScrinUrl(request.getParameter("scrinUrl"));
                commAuthenticVO.setSvcUrl(request.getParameter("svcUrl"));
                commAuthenticVO.setOpenTy(request.getParameter("openTy"));
                if (logger.isDebugEnabled()) {
                    logger.debug("preHandle::Screen.end"
                            +"[MenuId=" + commAuthenticVO.getMenuId()
                            +",ScrinId=" + commAuthenticVO.getScrinId()
                            +",ScrinUrl=" + commAuthenticVO.getScrinUrl()
                            +",SvcUrl=" + commAuthenticVO.getSvcUrl()
                            +",OpenTy=" + commAuthenticVO.getOpenTy()
                            +"]"
                    );
                }
                if (!StringUtils.contains(commAuthenticVO.getSvcUrl(), commAuthenticVO.getScrinUrl())) {
                    //해당 화면에 대한 권한이 없습니다.
                    throw new MapsAuthenticException(MessageUtil.getMessageSource(), "ECI0000008", null);
                }
                isActionUrl = true;
            // URL인증처리
            } else {
                /* 프로퍼티정보 */
                String nonCrtfUrlYn = PropertiesUtil.getDbValue(PROP_KEY_NON_CRTFC_YN_URL);
                if (logger.isDebugEnabled()) {
                    logger.debug("preHandle::URL.start[nonCrtfUrlYn="+nonCrtfUrlYn+"]");
                }
                if (StringUtils.equals(nonCrtfUrlYn, MapsConstants.YN_YES)) {
                    return true;
                }
    
                /* 화면정보설정 */
                Object context = RequestContextHolder.getRequestAttributes().getAttribute("NexacroCachedData", 0);
                NexacroContext nexacontext = null;
                if (context instanceof NexacroContext) {
                    nexacontext = (NexacroContext)context;
                }
    
                if (nexacontext != null){
                    DataSet data = nexacontext.getPlatformData().getDataSet("gdsTranParam");
                    if(data != null){
                        commAuthenticVO.setMenuId(data.getString(0, "menuId"));
                        commAuthenticVO.setScrinNm(data.getString(0, "menuNm"));
                        commAuthenticVO.setScrinId(data.getString(0, "scrinId"));
                    }
                }
    
                if (StringUtils.isBlank(commAuthenticVO.getScrinId())){
                    commAuthenticVO.setMenuId(request.getParameter("menuId"));
                    commAuthenticVO.setScrinNm(request.getParameter("menuNm"));
                    commAuthenticVO.setScrinId(request.getParameter("scrinId"));
                }
    
                /* URL정보설정 */
                commAuthenticVO.setSvcUrl(uri);
                if (logger.isDebugEnabled()) {
                    logger.debug("preHandle::URL.end"
                            +"[MenuId=" + commAuthenticVO.getMenuId()
                            +",ScrinId=" + commAuthenticVO.getScrinId()
                            +",SvcUrl=" + commAuthenticVO.getSvcUrl()
                            +",OpenTy=" + commAuthenticVO.getOpenTy()
                            +"]"
                    );
                }
            }
    
            /* 화면정보 인증 */
            // 화면조회정보 설정
            commAuthenticVO.setLangCd(request.getParameter("langCd"));
            commAuthenticVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
            if (isLogin) {
                commAuthenticVO.setLangCd(loginInfo.getLangCd());
                commAuthenticVO.setUserSeqId(loginInfo.getUserSeqId());
            }
            // 화면정보 조회
            MapsCommAuthenticVO rsltScrinInfo = mapsCommAuthenticService.selectScrinInfo(commAuthenticVO);
            if (rsltScrinInfo == null) {
                String[] msgArgs = new String[]{
                    StringUtils.defaultString(commAuthenticVO.getScrinNm(), commAuthenticVO.getScrinId())
                };
                throw new MapsAuthenticException(MessageUtil.getMessageSource(), "EC00000011", msgArgs, null);
            }
            // 화면실행및인증 URL 정합성체크
            if (isActionUrl && !StringUtils.contains(rsltScrinInfo.getScrinUrl(), commAuthenticVO.getScrinUrl())) {
                //해당 화면에 대한 권한이 없습니다.
                throw new MapsAuthenticException(MessageUtil.getMessageSource(), "ECI0000008", null);
            }
    
            /* 화면 및 URL 인증 */
            List<MapsCommAuthenticVO> lstAuthentic = null;
            // 메인화면
            if (StringUtils.equals(commAuthenticVO.getOpenTy(), OPEN_TYPE_MAIN)) {
                if (isLogin) {
                    lstAuthentic = mapsCommAuthenticService.selectAuthenticScrin(commAuthenticVO);
                    if (lstAuthentic.isEmpty()) {
                        //해당 화면에 대한 권한이 없습니다.
                        throw new MapsAuthenticException(MessageUtil.getMessageSource(), "ECI0000008", null);
                    }
                }
            // 팝업화면
            } else if (StringUtils.equals(commAuthenticVO.getOpenTy(), OPEN_TYPE_POPUP)) {
                if (!isLogin) {
                    // 비로그인 대상 화면ID 체크
                    String nonNlognScrinId = PropertiesUtil.getDbValue(PROP_KEY_NON_LOGIN_SCRIN_ID);
                    if (!commAuthenticVO.getScrinId().matches(nonNlognScrinId)) {
                        //해당 팝업화면에 대한 권한이 없습니다.
                        throw new MapsAuthenticException(MessageUtil.getMessageSource(), "ECI0000009", null);
                    }
                    lstAuthentic = mapsCommAuthenticService.selecttNlognAuthenticPopupScrin(commAuthenticVO);
                } else {
                    if (LOGIN_SCRIN_ID.equals(commAuthenticVO.getMenuId())) {
                        lstAuthentic = mapsCommAuthenticService.selecttNlognAuthenticPopupScrin(commAuthenticVO);
                    } else {
                        lstAuthentic = mapsCommAuthenticService.selectAuthenticPopupScrin(commAuthenticVO);
                    }
                }
                if (lstAuthentic.isEmpty()) {
                    //해당 팝업화면에 대한 권한이 없습니다.
                    throw new MapsAuthenticException(MessageUtil.getMessageSource(), "ECI0000009", null);
                }
            // 서비스URL
            } else if (StringUtils.equals(commAuthenticVO.getOpenTy(), OPEN_TYPE_URL)) {
                if (!isLogin
                        || LOGIN_SCRIN_ID.equals(commAuthenticVO.getMenuId())
                        || pathMatcher.match("/**/nlogn/**/*.do", uri)
                        || StringUtils.equals(rsltScrinInfo.getPopupYn(), MapsConstants.YN_YES)) {
                    lstAuthentic = mapsCommAuthenticService.selectNlognAuthenticSvcUrl(commAuthenticVO);
                } else {
                    lstAuthentic = mapsCommAuthenticService.selectAuthenticSvcUrl(commAuthenticVO);
                }
                if (lstAuthentic.isEmpty()) {
                    //해당 서비스에 대한 권한이 없습니다.
                    throw new MapsAuthenticException(MessageUtil.getMessageSource(), "ECI0000010", null);
                }
            } else {
                throw new MapsAuthenticException(MessageUtil.getMessageSource(), "EC00000011", new String[]{"Open Type Parameter"}, null);
            }
        } catch (Exception e) {
            if (isActionUrl) {
                throw new MapsScrinAuthenticException(e.getMessage());
            } else {
                throw e;
            }
        }
        
        return true;
    }
    
    private void debugPreHandleStart(HttpServletRequest request, HttpServletResponse response) {
        
        if (logger.isDebugEnabled()) {
            logger.debug("━━━━━━━━━━━━━━━   MapsAuthenticInterceptor preHandle     ━━━━━━━━━━━━━━━━");
            logger.debug("");
            logger.debug(" ================= request Paramter ===============");
            Enumeration<String> e1 = request.getParameterNames();
            while (e1.hasMoreElements()) {
                String key = e1.nextElement();
                logger.debug(key + " :  " + request.getParameter(key));
            }

            logger.debug("");
            logger.debug(" ================= request Header ===============");
            Enumeration<String> e = request.getHeaderNames();
            while (e.hasMoreElements()) {
                String key = e.nextElement();
                logger.debug(key + " : " + request.getHeader(key));
            }
        }
    }
    
    private void debugAfterCompletionStart(HttpServletRequest request, HttpServletResponse response) {
        if (logger.isDebugEnabled()) {
            logger.debug("━━━━━━━━━━━━━━━   MapsAuthenticInterceptor afterCompletion ━━━━━━━━━━━━━━━");
        }
    }
    
    /*
     * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#postHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, org.springframework.web.servlet.ModelAndView)
     */
    @Override
    public void postHandle(
              HttpServletRequest request
            , HttpServletResponse response
            , Object handler
            , ModelAndView modelAndView) throws Exception {
        
    }
    
    /*
     * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#afterCompletion(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, java.lang.Exception)
     */
    @Override
    public void afterCompletion(
              HttpServletRequest request
            , HttpServletResponse response
            , Object handler
            , Exception ex) throws Exception {
        
        debugAfterCompletionStart(request, response);
    }

    /**
     * @param nonCrtfcUrlPattern the nonCrtfcUrlPattern to set
     */
    public void setNonCrtfcUrlPattern(List<String> nonCrtfcUrlPattern) {
        this.nonCrtfcUrlPattern = nonCrtfcUrlPattern;
    }

}
