package com.mobis.maps.cmmn.vo;

import java.io.Serializable;

/**
 * <pre>
 * MAPS 모비스 조직정보 항목
 * </pre>
 *
 * @ClassName   : MapsOrgnztMobisVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 6. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 8.     DT048058     	최초 생성
 * </pre>
 */

public class MapsOrgnztMobisVO  implements Serializable {
    
    
    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = 4965416166142500168L;
    /** 신청WFNAME */
    private String wfName;
    /** UNIQUENO(자동생성) */
    private String wfNo;
    /** 아이디 */
    private String userId;
    /** 이름(모국어) */
    private String userNm;
    /** 이름(영어) */
    private String userEnglishNm;
    /**  */
    private String userChinaNm;
    /** 고용구분 */
    private String userEmploy;
    /** 국내/외구분 */
    private String domain;
    /** 직위코드 */
    private String userGradeCode;
    /** 직위명(모국어) */
    private String jwNmHome;
    /** 대외직위코드 */
    private String userZzjikwiOut;
    /** 대외직위명 */
    private String userTtoutOut;
    /** 직책명(모국어) */
    private String dutyNmHome;
    /** 직책코드 */
    private String dutyCd;
    /** 인사영역 */
    private String userWerks;
    /** 인사영역명 */
    private String userWerksTxt;
    /** 본부코드 */
    private String userDivCode;
    /** 본부명 */
    private String userDivNm;
    /** 실코드 */
    private String userSilCode;
    /** 실명 */
    private String userSilNm;
    /** 부서코드 */
    private String deptCd;
    /** 부서명(모국어) */
    private String deptNm;
    /** 파트코드 */
    private String userPartCode;
    /** 파트명 */
    private String userPartNm;
    /** 소속조직코드 */
    private String userCurrentCode;
    /** 소속조직명 */
    private String userCurrentNm;
    /** 사원그룹 */
    private String userPersg;
    /** 사원그룹이름 */
    private String userPtext;
    /** 법인명 */
    private String branchNm;
    /** 법인코드 */
    private String branchCd;
    /** 이메일 */
    private String userEmail;
    /** 핸드폰번호 */
    private String userMobile;
    /** 사내전화번호 */
    private String userTelephone;
    /** 팩스번호 */
    private String userFax;
    /** 사원구분 */
    private String userZgubun;
    /** 사원구분TEXT */
    private String userTtoutZgubun;
    /** 근무지코드 */
    private String userZzzip;
    /** 근무지명 */
    private String userZzzipText;
    /** 파트장사번 */
    private String userPartId;
    /** 팀장사번 */
    private String userTeamId;
    /** 실장사번 */
    private String userSilId;
    /** 본부장사번 */
    private String userDivId;
    /** 코스트센터 */
    private String userCostCode;
    /** 코스트센터명 */
    private String userCostNm;
    /** 사용기간시작일 */
    private String userJoinDt;
    /** 승진일 */
    private String promtDate;
    /** 퇴직flag */
    private String retireFlag;
    /** 생성일자 */
    private String wfCrtDate;
    /** WF_HISTORY변경일자 */
    private String wfVanDate;
    /** 부서변경일자 */
    private String userDeptChgDt;
    /** 상세업무 */
    private String jobinfo;
    /** 상세업무1 */
    private String jobdetail1;
    /** 상세업무2 */
    private String jobdetail2;
    /** 상세업무3 */
    private String jobdetail3;
    /**
     * @return the wfName
     */
    public String getWfName() {
        return wfName;
    }
    /**
     * @param wfName the wfName to set
     */
    public void setWfName(String wfName) {
        this.wfName = wfName;
    }
    /**
     * @return the wfNo
     */
    public String getWfNo() {
        return wfNo;
    }
    /**
     * @param wfNo the wfNo to set
     */
    public void setWfNo(String wfNo) {
        this.wfNo = wfNo;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userNm
     */
    public String getUserNm() {
        return userNm;
    }
    /**
     * @param userNm the userNm to set
     */
    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }
    /**
     * @return the userEnglishNm
     */
    public String getUserEnglishNm() {
        return userEnglishNm;
    }
    /**
     * @param userEnglishNm the userEnglishNm to set
     */
    public void setUserEnglishNm(String userEnglishNm) {
        this.userEnglishNm = userEnglishNm;
    }
    /**
     * @return the userChinaNm
     */
    public String getUserChinaNm() {
        return userChinaNm;
    }
    /**
     * @param userChinaNm the userChinaNm to set
     */
    public void setUserChinaNm(String userChinaNm) {
        this.userChinaNm = userChinaNm;
    }
    /**
     * @return the userEmploy
     */
    public String getUserEmploy() {
        return userEmploy;
    }
    /**
     * @param userEmploy the userEmploy to set
     */
    public void setUserEmploy(String userEmploy) {
        this.userEmploy = userEmploy;
    }
    /**
     * @return the domain
     */
    public String getDomain() {
        return domain;
    }
    /**
     * @param domain the domain to set
     */
    public void setDomain(String domain) {
        this.domain = domain;
    }
    /**
     * @return the userGradeCode
     */
    public String getUserGradeCode() {
        return userGradeCode;
    }
    /**
     * @param userGradeCode the userGradeCode to set
     */
    public void setUserGradeCode(String userGradeCode) {
        this.userGradeCode = userGradeCode;
    }
    /**
     * @return the jwNmHome
     */
    public String getJwNmHome() {
        return jwNmHome;
    }
    /**
     * @param jwNmHome the jwNmHome to set
     */
    public void setJwNmHome(String jwNmHome) {
        this.jwNmHome = jwNmHome;
    }
    /**
     * @return the userZzjikwiOut
     */
    public String getUserZzjikwiOut() {
        return userZzjikwiOut;
    }
    /**
     * @param userZzjikwiOut the userZzjikwiOut to set
     */
    public void setUserZzjikwiOut(String userZzjikwiOut) {
        this.userZzjikwiOut = userZzjikwiOut;
    }
    /**
     * @return the userTtoutOut
     */
    public String getUserTtoutOut() {
        return userTtoutOut;
    }
    /**
     * @param userTtoutOut the userTtoutOut to set
     */
    public void setUserTtoutOut(String userTtoutOut) {
        this.userTtoutOut = userTtoutOut;
    }
    /**
     * @return the dutyNmHome
     */
    public String getDutyNmHome() {
        return dutyNmHome;
    }
    /**
     * @param dutyNmHome the dutyNmHome to set
     */
    public void setDutyNmHome(String dutyNmHome) {
        this.dutyNmHome = dutyNmHome;
    }
    /**
     * @return the dutyCd
     */
    public String getDutyCd() {
        return dutyCd;
    }
    /**
     * @param dutyCd the dutyCd to set
     */
    public void setDutyCd(String dutyCd) {
        this.dutyCd = dutyCd;
    }
    /**
     * @return the userWerks
     */
    public String getUserWerks() {
        return userWerks;
    }
    /**
     * @param userWerks the userWerks to set
     */
    public void setUserWerks(String userWerks) {
        this.userWerks = userWerks;
    }
    /**
     * @return the userWerksTxt
     */
    public String getUserWerksTxt() {
        return userWerksTxt;
    }
    /**
     * @param userWerksTxt the userWerksTxt to set
     */
    public void setUserWerksTxt(String userWerksTxt) {
        this.userWerksTxt = userWerksTxt;
    }
    /**
     * @return the userDivCode
     */
    public String getUserDivCode() {
        return userDivCode;
    }
    /**
     * @param userDivCode the userDivCode to set
     */
    public void setUserDivCode(String userDivCode) {
        this.userDivCode = userDivCode;
    }
    /**
     * @return the userDivNm
     */
    public String getUserDivNm() {
        return userDivNm;
    }
    /**
     * @param userDivNm the userDivNm to set
     */
    public void setUserDivNm(String userDivNm) {
        this.userDivNm = userDivNm;
    }
    /**
     * @return the userSilCode
     */
    public String getUserSilCode() {
        return userSilCode;
    }
    /**
     * @param userSilCode the userSilCode to set
     */
    public void setUserSilCode(String userSilCode) {
        this.userSilCode = userSilCode;
    }
    /**
     * @return the userSilNm
     */
    public String getUserSilNm() {
        return userSilNm;
    }
    /**
     * @param userSilNm the userSilNm to set
     */
    public void setUserSilNm(String userSilNm) {
        this.userSilNm = userSilNm;
    }
    /**
     * @return the deptCd
     */
    public String getDeptCd() {
        return deptCd;
    }
    /**
     * @param deptCd the deptCd to set
     */
    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }
    /**
     * @return the deptNm
     */
    public String getDeptNm() {
        return deptNm;
    }
    /**
     * @param deptNm the deptNm to set
     */
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }
    /**
     * @return the userPartCode
     */
    public String getUserPartCode() {
        return userPartCode;
    }
    /**
     * @param userPartCode the userPartCode to set
     */
    public void setUserPartCode(String userPartCode) {
        this.userPartCode = userPartCode;
    }
    /**
     * @return the userPartNm
     */
    public String getUserPartNm() {
        return userPartNm;
    }
    /**
     * @param userPartNm the userPartNm to set
     */
    public void setUserPartNm(String userPartNm) {
        this.userPartNm = userPartNm;
    }
    /**
     * @return the userCurrentCode
     */
    public String getUserCurrentCode() {
        return userCurrentCode;
    }
    /**
     * @param userCurrentCode the userCurrentCode to set
     */
    public void setUserCurrentCode(String userCurrentCode) {
        this.userCurrentCode = userCurrentCode;
    }
    /**
     * @return the userCurrentNm
     */
    public String getUserCurrentNm() {
        return userCurrentNm;
    }
    /**
     * @param userCurrentNm the userCurrentNm to set
     */
    public void setUserCurrentNm(String userCurrentNm) {
        this.userCurrentNm = userCurrentNm;
    }
    /**
     * @return the userPersg
     */
    public String getUserPersg() {
        return userPersg;
    }
    /**
     * @param userPersg the userPersg to set
     */
    public void setUserPersg(String userPersg) {
        this.userPersg = userPersg;
    }
    /**
     * @return the userPtext
     */
    public String getUserPtext() {
        return userPtext;
    }
    /**
     * @param userPtext the userPtext to set
     */
    public void setUserPtext(String userPtext) {
        this.userPtext = userPtext;
    }
    /**
     * @return the branchNm
     */
    public String getBranchNm() {
        return branchNm;
    }
    /**
     * @param branchNm the branchNm to set
     */
    public void setBranchNm(String branchNm) {
        this.branchNm = branchNm;
    }
    /**
     * @return the branchCd
     */
    public String getBranchCd() {
        return branchCd;
    }
    /**
     * @param branchCd the branchCd to set
     */
    public void setBranchCd(String branchCd) {
        this.branchCd = branchCd;
    }
    /**
     * @return the userEmail
     */
    public String getUserEmail() {
        return userEmail;
    }
    /**
     * @param userEmail the userEmail to set
     */
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    /**
     * @return the userMobile
     */
    public String getUserMobile() {
        return userMobile;
    }
    /**
     * @param userMobile the userMobile to set
     */
    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }
    /**
     * @return the userTelephone
     */
    public String getUserTelephone() {
        return userTelephone;
    }
    /**
     * @param userTelephone the userTelephone to set
     */
    public void setUserTelephone(String userTelephone) {
        this.userTelephone = userTelephone;
    }
    /**
     * @return the userFax
     */
    public String getUserFax() {
        return userFax;
    }
    /**
     * @param userFax the userFax to set
     */
    public void setUserFax(String userFax) {
        this.userFax = userFax;
    }
    /**
     * @return the userZgubun
     */
    public String getUserZgubun() {
        return userZgubun;
    }
    /**
     * @param userZgubun the userZgubun to set
     */
    public void setUserZgubun(String userZgubun) {
        this.userZgubun = userZgubun;
    }
    /**
     * @return the userTtoutZgubun
     */
    public String getUserTtoutZgubun() {
        return userTtoutZgubun;
    }
    /**
     * @param userTtoutZgubun the userTtoutZgubun to set
     */
    public void setUserTtoutZgubun(String userTtoutZgubun) {
        this.userTtoutZgubun = userTtoutZgubun;
    }
    /**
     * @return the userZzzip
     */
    public String getUserZzzip() {
        return userZzzip;
    }
    /**
     * @param userZzzip the userZzzip to set
     */
    public void setUserZzzip(String userZzzip) {
        this.userZzzip = userZzzip;
    }
    /**
     * @return the userZzzipText
     */
    public String getUserZzzipText() {
        return userZzzipText;
    }
    /**
     * @param userZzzipText the userZzzipText to set
     */
    public void setUserZzzipText(String userZzzipText) {
        this.userZzzipText = userZzzipText;
    }
    /**
     * @return the userPartId
     */
    public String getUserPartId() {
        return userPartId;
    }
    /**
     * @param userPartId the userPartId to set
     */
    public void setUserPartId(String userPartId) {
        this.userPartId = userPartId;
    }
    /**
     * @return the userTeamId
     */
    public String getUserTeamId() {
        return userTeamId;
    }
    /**
     * @param userTeamId the userTeamId to set
     */
    public void setUserTeamId(String userTeamId) {
        this.userTeamId = userTeamId;
    }
    /**
     * @return the userSilId
     */
    public String getUserSilId() {
        return userSilId;
    }
    /**
     * @param userSilId the userSilId to set
     */
    public void setUserSilId(String userSilId) {
        this.userSilId = userSilId;
    }
    /**
     * @return the userDivId
     */
    public String getUserDivId() {
        return userDivId;
    }
    /**
     * @param userDivId the userDivId to set
     */
    public void setUserDivId(String userDivId) {
        this.userDivId = userDivId;
    }
    /**
     * @return the userCostCode
     */
    public String getUserCostCode() {
        return userCostCode;
    }
    /**
     * @param userCostCode the userCostCode to set
     */
    public void setUserCostCode(String userCostCode) {
        this.userCostCode = userCostCode;
    }
    /**
     * @return the userCostNm
     */
    public String getUserCostNm() {
        return userCostNm;
    }
    /**
     * @param userCostNm the userCostNm to set
     */
    public void setUserCostNm(String userCostNm) {
        this.userCostNm = userCostNm;
    }
    /**
     * @return the userJoinDt
     */
    public String getUserJoinDt() {
        return userJoinDt;
    }
    /**
     * @param userJoinDt the userJoinDt to set
     */
    public void setUserJoinDt(String userJoinDt) {
        this.userJoinDt = userJoinDt;
    }
    /**
     * @return the promtDate
     */
    public String getPromtDate() {
        return promtDate;
    }
    /**
     * @param promtDate the promtDate to set
     */
    public void setPromtDate(String promtDate) {
        this.promtDate = promtDate;
    }
    /**
     * @return the retireFlag
     */
    public String getRetireFlag() {
        return retireFlag;
    }
    /**
     * @param retireFlag the retireFlag to set
     */
    public void setRetireFlag(String retireFlag) {
        this.retireFlag = retireFlag;
    }
    /**
     * @return the wfCrtDate
     */
    public String getWfCrtDate() {
        return wfCrtDate;
    }
    /**
     * @param wfCrtDate the wfCrtDate to set
     */
    public void setWfCrtDate(String wfCrtDate) {
        this.wfCrtDate = wfCrtDate;
    }
    /**
     * @return the wfVanDate
     */
    public String getWfVanDate() {
        return wfVanDate;
    }
    /**
     * @param wfVanDate the wfVanDate to set
     */
    public void setWfVanDate(String wfVanDate) {
        this.wfVanDate = wfVanDate;
    }
    /**
     * @return the userDeptChgDt
     */
    public String getUserDeptChgDt() {
        return userDeptChgDt;
    }
    /**
     * @param userDeptChgDt the userDeptChgDt to set
     */
    public void setUserDeptChgDt(String userDeptChgDt) {
        this.userDeptChgDt = userDeptChgDt;
    }
    /**
     * @return the jobinfo
     */
    public String getJobinfo() {
        return jobinfo;
    }
    /**
     * @param jobinfo the jobinfo to set
     */
    public void setJobinfo(String jobinfo) {
        this.jobinfo = jobinfo;
    }
    /**
     * @return the jobdetail1
     */
    public String getJobdetail1() {
        return jobdetail1;
    }
    /**
     * @param jobdetail1 the jobdetail1 to set
     */
    public void setJobdetail1(String jobdetail1) {
        this.jobdetail1 = jobdetail1;
    }
    /**
     * @return the jobdetail2
     */
    public String getJobdetail2() {
        return jobdetail2;
    }
    /**
     * @param jobdetail2 the jobdetail2 to set
     */
    public void setJobdetail2(String jobdetail2) {
        this.jobdetail2 = jobdetail2;
    }
    /**
     * @return the jobdetail3
     */
    public String getJobdetail3() {
        return jobdetail3;
    }
    /**
     * @param jobdetail3 the jobdetail3 to set
     */
    public void setJobdetail3(String jobdetail3) {
        this.jobdetail3 = jobdetail3;
    }
}
