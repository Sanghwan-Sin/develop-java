package com.mobis.maps.iam.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamAuthorService;
import com.mobis.maps.iam.vo.MapsIamAuthorExcelUpldVO;
import com.mobis.maps.iam.vo.MapsIamAuthorMenuScnFnctVO;
import com.mobis.maps.iam.vo.MapsIamAuthorMenuVO;
import com.mobis.maps.iam.vo.MapsIamAuthorSetupVO;
import com.mobis.maps.iam.vo.MapsIamAuthorUserVO;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;

/**
 * <pre>
 * 권한관리 컨드롤러
 * </pre>
 *
 * @ClassName   : MapsIamAuthorController.java
 * @Description : 권한관리에 대한 컨드롤러를 정의.
 * @author 최은삼
 * @since 2019. 12. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 13.     최은삼     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamAuthorController extends HController {

    @Resource(name = "mapsIamAuthorService")
    private MapsIamAuthorService mapsIamAuthorService;
    
    /**
     * 권한 리스트 조회
     *
     * @param iamAuthorVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAuthorList.do")
    public NexacroResult selectAuthorList(@ParamDataSet(name = "dsInput") MapsIamAuthorVO iamAuthorVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamAuthorVO> authorInfos = mapsIamAuthorService.selectAuthorList(iamAuthorVO, loginInfo);

        result.addDataSet("dsOutput", authorInfos);

        return result;
    }
    
    /**
     * 권한 페이징리스트 조회
     *
     * @param iamAuthorVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAuthorPgList.do")
    public NexacroResult selectAuthorPgList(@ParamDataSet(name = "dsInput") MapsIamAuthorVO iamAuthorVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamAuthorVO> authorInfos = mapsIamAuthorService.selectAuthorPgList(iamAuthorVO, loginInfo);

        result.addDataSet("dsOutput", authorInfos);

        return result;
    }

    /**
     * 권한 저장
     * 
     * @param iamAuthorInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiAuthorInfo.do")
    public NexacroResult multiAuthorInfo(@ParamDataSet(name="dsInput") List<MapsIamAuthorVO> authorInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamAuthorService.multiAuthorInfo(authorInfos, loginInfo);

        result.addVariable("procCnt", procCnt);

        return result;
    }
    
    /**
     * 권한정보 파일업로드 저장
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiAuthorInfoFiileUpload.do", method = { RequestMethod.GET, RequestMethod.POST })
    public NexacroResult multiAuthorInfoFiileUpload(HttpServletRequest request, HttpServletResponse response, NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        // 권한업로드정보
        MapsIamAuthorExcelUpldVO iamAuthorExcelUpldVO = new MapsIamAuthorExcelUpldVO();

        mapsIamAuthorService.multiAuthorInfoFiileUpload(request, response, iamAuthorExcelUpldVO, loginInfo);

        result.addVariable("isError", iamAuthorExcelUpldVO.hasError());
        if (iamAuthorExcelUpldVO.hasError()) {
            iamAuthorExcelUpldVO.setErrorCode(-1);
            iamAuthorExcelUpldVO.setErrorMsg(iamAuthorExcelUpldVO.toErrorString());
            result.addDataSet("dsOutputExcelUpld", iamAuthorExcelUpldVO);
        }
        //권한마스터정보 취득
        result.addDataSet("dsOutputAuthor", iamAuthorExcelUpldVO.getAuthors());
        //권한메뉴정보 취득
        Map<String, List<MapsIamAuthorMenuVO>> mAuthorMenu = iamAuthorExcelUpldVO.getMapngMenus();
        List<MapsIamAuthorMenuVO> lstAuthorMenu = new ArrayList<MapsIamAuthorMenuVO>();
        for (List<MapsIamAuthorMenuVO> authorMenu: mAuthorMenu.values()) {
            lstAuthorMenu.addAll(authorMenu);
        }
        result.addDataSet("dsOutputAuthorMenu", lstAuthorMenu);

        //권한사용자정보 취득
        Map<String, List<MapsIamAuthorUserVO>> mAuthorUser = iamAuthorExcelUpldVO.getMapngUsers();
        List<MapsIamAuthorUserVO> lstAuthorUser = new ArrayList<MapsIamAuthorUserVO>();
        for (List<MapsIamAuthorUserVO> authorUser: mAuthorUser.values()) {
            lstAuthorUser.addAll(authorUser);
        }
        result.addDataSet("dsOutputAuthorUser", lstAuthorUser);

        return result;
    }
    
    /**
     * 권한 변경이력 페이징리스트 조회
     *
     * @param iamAuthorVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAuthorChghstPgList.do")
    public NexacroResult selectAuthorChghstPgList(@ParamDataSet(name = "dsInput") MapsIamAuthorVO iamAuthorVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamAuthorVO> authorChghsts = mapsIamAuthorService.selectAuthorChghstPgList(iamAuthorVO, loginInfo);

        result.addDataSet("dsOutput", authorChghsts);

        return result;
    }

    /**
     * 권한별 메뉴 리스트 조회
     *
     * @param iamAuthorVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAuthorMenuScrinList.do")
    public NexacroResult selectAuthorMenuScrinList(@ParamDataSet(name = "dsInput") MapsIamAuthorMenuVO imAuthorMenuVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamAuthorMenuVO> authorMenuInfos = mapsIamAuthorService.selectAuthorMenuScrinList(imAuthorMenuVO, loginInfo);

        result.addDataSet("dsOutput", authorMenuInfos);

        return result;
    }

    /**
     * 메뉴/화면 권한 추가/삭제
     * 
     * @param iamAuthorMenuInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiAuthorMenuInfo.do")
    public NexacroResult multiAuthorMenuInfo(
            @ParamDataSet(name = "dsInput") List<MapsIamAuthorMenuVO> iamAuthorMenuInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamAuthorService.multiAuthorMenuInfo(iamAuthorMenuInfos, loginInfo);

        result.addVariable("procCnt", procCnt);

        return result;
    }

    /**
     * 권한별 화면 기능 리스트 조회
     *
     * @param iamAuthorVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAuthorScrinFnctList.do")
    public NexacroResult selectAuthorScrinFnctList(
            @ParamDataSet(name = "dsInput") MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        iamAuthorMenuScnFnctVO.setLangCd(loginInfo.getLangCd());

        List<MapsIamAuthorMenuScnFnctVO> authorMenuScnFnctInfos = mapsIamAuthorService.selectAuthorScrinFnctList(iamAuthorMenuScnFnctVO);

        result.addDataSet("dsOutput", authorMenuScnFnctInfos);

        return result;
    }

    /**
     * 화면기능 권한 추가/삭제
     * 
     * @param iamAuthorScrinFnctInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiAuthorScrinFnctInfo.do")
    public NexacroResult multiAuthorScrinFnctInfo(
            @ParamDataSet(name = "dsInput") List<MapsIamAuthorMenuScnFnctVO> iamAuthorScrinFnctInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamAuthorService.multiAuthorScrinFnctInfo(iamAuthorScrinFnctInfos, loginInfo);

        result.addVariable("procCnt", procCnt);

        return result;
    }
    

    /**
     * 권한설정 변경이력 페이징리스트 조회
     *
     * @param iamAuthorSetupVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAuthorSetupChghstPgList.do")
    public NexacroResult selectAuthorSetupChghstPgList(@ParamDataSet(name = "dsInput") MapsIamAuthorSetupVO iamAuthorSetupVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamAuthorSetupVO> authorSetupChghst = mapsIamAuthorService.selectAuthorSetupChghstPgList(iamAuthorSetupVO, loginInfo);

        result.addDataSet("dsOutput", authorSetupChghst);

        return result;
    }

    /**
     * 권한별 사용자 리스트 조회
     *
     * @param iamAuthorUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAuthorUserPgList.do")
    public NexacroResult selectAuthorUserPgList(@ParamDataSet(name = "dsInput") MapsIamAuthorUserVO iamAuthorUserVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamAuthorUserVO> authorUserInfos = mapsIamAuthorService.selectAuthorUserPgList(iamAuthorUserVO, loginInfo);

        result.addDataSet("dsOutput", authorUserInfos);

        return result;
    }

    /**
     * 권한별 사용자 리스트 액셀다운로드
     *
     * @param iamAuthorUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAuthorUserListExcelDown.do")
    public NexacroResult selectAuthorUserListExcelDown(@ParamDataSet(name="dsInput") MapsIamAuthorUserVO iamAuthorUserVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        iamAuthorUserVO.setExcelDwnlYn(MapsConstants.YN_YES);
        iamAuthorUserVO.setPgNum(1);
        iamAuthorUserVO.setPgSize(iamAuthorUserVO.getTotMaxCnt());

        List<MapsIamAuthorUserVO> authorUserInfos = mapsIamAuthorService.selectAuthorUserPgList(iamAuthorUserVO, loginInfo);

        result.addDataSet("dsOutput", authorUserInfos);

        return result;
    }

    /**
     * 권한 사용자 저장
     * 
     * @param iamUserVO
     * @param iamIpInfos
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiAuthorUserInfo.do")
    public NexacroResult multiUserAuthorInfo(
            @ParamDataSet(name = "dsInput") List<MapsIamAuthorUserVO> iamAuthorUserInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamAuthorService.multiAuthorUserInfo(iamAuthorUserInfos, loginInfo);

        result.addVariable("procCnt", procCnt);

        return result;
    }

    /**
     * 권한별정보 가져오기
     *
     * @param iamAuthorVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/insertImportAuthorInfo.do")
    public NexacroResult insertImportAuthorInfo(@ParamDataSet(name = "dsInput") MapsIamAuthorVO iamAuthorVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamAuthorService.insertImportAuthorInfo(iamAuthorVO, loginInfo);

        result.addVariable("procCnt", procCnt);

        return result;
    }
}
