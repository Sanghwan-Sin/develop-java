package com.mobis.maps.cmmn.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import able.com.service.msg.MessageDBResourceDAO;
import able.com.vo.HMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;

import com.mobis.maps.cmmn.spring.SpringApplicationContext;
import com.mobis.maps.cmmn.vo.MessageVO;
import com.nexacro17.xapi.data.DataSet;
import com.nexacro17.xapi.data.datatype.PlatformDataType;

/**
 * <pre>
 * 메세지 UTIL
 * </pre>
 *
 * @ClassName   : MessageUtil.java
 * @Description : 메세지를 관리한다.
 * @author Sin Sanghwan
 * @since 2019. 8. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 6.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class MessageUtil {

    private static MessageSource messageSource;
    
    public static MessageSource getMessageSource() {
        
        if (messageSource == null) {
            messageSource = (MessageSource)SpringApplicationContext.getBean("messageSource");
        }
        
        return messageSource;
    }

    /**
     * 메세지
     *
     * @param code
     * @param args
     * @param locale
     * @return
     */
    public static String getMessage(String code, Locale locale) {
        return getMessageSource().getMessage(code, null, locale);
    }

    /**
     * 메세지
     *
     * @param code
     * @param args
     * @param locale
     * @return
     */
    public static String getMessage(String code, Object[] args, Locale locale) {
        return getMessageSource().getMessage(code, args, locale);
    }
    
    /**
     * 메세지
     *
     * @param code
     * @param args
     * @param defaultMessage
     * @param locale
     * @return
     */
    public static String getMessage(String code, Object[] args, String defaultMessage, Locale locale) {
        return getMessageSource().getMessage(code, args, defaultMessage, locale);
    }
    
    /**
     * 메세지
     *
     * @param locale
     * @param msgKeys
     * @return
     * @throws Exception
     */
    public static List<HMap> getMessages(Locale locale, String[] msgKeys) throws Exception {

        List<HMap> mMsgs = new ArrayList<HMap>();
        for (String msgKey: msgKeys) {
            String value = getMessage(msgKey, locale);
            if (StringUtils.isBlank(value)) {
                continue;
            }
            HMap mMsg = new HMap();
            mMsg.put("key", msgKey);
            mMsg.put("value", value);
            mMsg.put("language", locale.toString());
            mMsgs.add(mMsg);
        }
        return mMsgs;
    }
    
    /**
     * 메세지 처리
     *
     * @param msgCd 메세지 코드
     * @param msgNm 메세지 명
     * @param msgSe 메세지 구분[정상:S,에러:E]
     * @return
     */
    public static DataSet getMessage(String msgCd, String msgNm, String msgSe) {

        DataSet ds = new DataSet("gdsMessage");
        ds.addColumn("msgCd", PlatformDataType.STRING);
        ds.addColumn("msgNm", PlatformDataType.STRING);
        ds.addColumn("msgSe", PlatformDataType.STRING);
        int row = ds.newRow();
        ds.set(row, "msgCd", msgCd);
        ds.set(row, "msgNm", msgNm);
        ds.set(row, "msgSe", msgSe);
        return ds;
    }

    /**
     * 메세지 처리
     *
     * @param msgCd
     * @param msgNm
     * @param msgCdScn
     * @return
     */
    public static MessageVO getMessageVO(String msgCd, String msgNm, String msgSe) {

        MessageVO msg = new MessageVO();
        msg.setMsgCd(msgCd);
        msg.setMsgNm(msgNm);
        msg.setMsgSe(msgSe);
        return msg;
    }

    /**
     * 에러 메세지를 반환한다.
     *
     * @param element
     * @return
     */
    public static String getErrorLog(StackTraceElement[] element) {
        StringBuffer sb = new StringBuffer();
        sb.append("\n");
        for (int index = 0; index < element.length; index++) {
            sb.append(element[index].toString()).append("\n");
        }
        return sb.toString();
    }

    
    /**
     * LOCAL 반환
     *
     * @param langCd
     * @return
     * @throws Exception
     */
    public static Locale getLocale(String langCd) throws Exception {

        String[] arrLocaleInfo = StringUtils.split(langCd, "_");
        
        Locale locale = new Locale(arrLocaleInfo[0], arrLocaleInfo[1]);
        
        return locale;
    }

    /**
     * 메세지 리스트조회
     *
     * @param langCd
     * @return
     * @throws Exception
     */
    public static List<HMap> selectMessageList(String langCd) throws Exception {
        return selectMessageList(getLocale(langCd));
    }
    
    /**
     * 메세지 리스트조회
     *
     * @param locale
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public static List<HMap> selectMessageList(Locale locale) throws Exception {
        //메세지리스트 가져오기
        MessageDBResourceDAO messageDao = (MessageDBResourceDAO)SpringApplicationContext.getBean("messageDBResourceDAO");

        return (List<HMap>) messageDao.getMessageResource(locale.toString());
    }
    
    /**
     * 전체 메세지 조회
     *
     * @param locale
     * @return
     * @throws Exception
     */
    public static List<HMap> getAllMessages(Locale locale, String[] msgKeys) throws Exception {
        
        List<HMap> mMsgs =selectMessageList(locale);
        
        mMsgs.addAll(getMessages(locale, msgKeys));
        
        return mMsgs;
    }
}
