package com.mobis.maps.cmmn.util;

import java.io.File;
import java.io.IOException;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.UUID;

import able.com.service.file.FileUploadProperty;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.icu.util.Calendar;
import com.mobis.maps.cmmn.spring.SpringApplicationContext;

/**
 * <pre>
 * 파일업로드 UTIL
 * </pre>
 *
 * @ClassName   : FileUploadUtil.java
 * @Description : 파일업로드 UTIL를 정의한다.
 * @author Sin Sanghwan
 * @since 2019. 8. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 6.     Sin Sanghwan        최초 생성
 * </pre>
 */
public class FileUploadUtil {
    
    private final static Logger LOGGER = LoggerFactory.getLogger(FileUploadUtil.class);
    
    public final static char SEPARATOR = File.separatorChar;

    public final static String SAP_FILEUPLOAD_ROOT_PATH = "/mobis";
    
    //public final static SimpleDateFormat SDF_STORED_PATH = new SimpleDateFormat("yyyyMM" + SEPARATOR + "dd", Locale.KOREAN);
    
    private static FileUploadProperty fileUploadProperty;
    
    private static FileUploadProperty getFileUploadProperty() {
        
        if (fileUploadProperty == null) {
            fileUploadProperty = (FileUploadProperty) SpringApplicationContext.getBean("fileUploadProperty");
        }
        
        return fileUploadProperty;
    }

    /**
     * 파일 패스 Seprator 변경
     *
     * @param filePath
     * @return
     */
    public static String replaceSeperator(String filePath) {
        
        String sPath = "";
        
        if (SEPARATOR == '/') {
            sPath = StringUtils.replace(filePath, "\\", File.separator);
        } else {
            sPath = StringUtils.replace(filePath, "/", File.separator);
        }
        return sPath;
    }
    
    /**
     * 기본경로
     *
     * @return
     */
    public static String getFolder() {
        
        return FileUploadUtil.replaceSeperator(getFileUploadProperty().getFolder());
    }
    
    /**
     * 서브경로
     *
     * @param sub
     * @return
     */
    public static String getSubFolder(String sub) {

        String subFolder = "";
        
        if (StringUtils.isNotEmpty(sub)) {
            subFolder = getFileUploadProperty().getSub(sub);
        }
        
        return FileUploadUtil.replaceSeperator(subFolder);
    }

    /**
     * 저장될 폴더를 가져옴
     *
     * @param sub
     * @return
     */
    public static String getStoredFolder(String sub) {
        
        return getStoredFolder(sub, null);
    }

    /**
     * 저장될 폴더를 가져옴
     *
     * @param sub
     * @return
     */
    public static String getStoredFolder(String sub, String yyyyMMdd){

        String storedFolder = "";
        
        if (StringUtils.isNotEmpty(sub)) {
            storedFolder += SEPARATOR + getSubFolder(sub);
        }
        
        if (StringUtils.length(yyyyMMdd) >= 8) {
            String yyyyMM = yyyyMMdd.substring(0, 6);
            String dd = yyyyMMdd.substring(6, 8);
            storedFolder += SEPARATOR + yyyyMM + SEPARATOR + dd;
        } else {
            
            SimpleDateFormat sdf = new SimpleDateFormat(SEPARATOR + "yyyyMM" + SEPARATOR + "dd", Locale.KOREAN);
            
            storedFolder += sdf.format(Calendar.getInstance().getTime());
        }
        
        return storedFolder;
    }

    /**
     * 저장될 전체 폴더를 가져옴
     *
     * @param subFolder
     * @return
     */
    public static String getStoredFolderFullPath(String sub) {
        
        return getStoredFolderFullPath(sub, null);
    }

    /**
     * 저장될 전체 폴더를 가져옴
     *
     * @param sub
     * @param yyyyMMdd
     * @return
     */
    public static String getStoredFolderFullPath(String sub, String yyyyMMdd) {

        return getStoredFolderFullPath(sub, yyyyMMdd, null);
    }

    /**
     * 저장될 전체 폴더를 가져옴
     *
     * @param sub
     * @param fileName
     * @param yyyyMMdd
     * @return
     */
    public static String getStoredFolderFullPath(String sub, String yyyyMMdd, String fileName) {

        String storedFolderPath = getFolder();
        
        if (StringUtils.isNotEmpty(sub)) {
            storedFolderPath += SEPARATOR + getSubFolder(sub);
        }
        
        if (StringUtils.length(yyyyMMdd) >= 8) {
            String yyyyMM = yyyyMMdd.substring(0, 6);
            String dd = yyyyMMdd.substring(6, 8);
            storedFolderPath += SEPARATOR + yyyyMM + SEPARATOR + dd;
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat(SEPARATOR + "yyyyMM" + SEPARATOR + "dd", Locale.KOREAN);
            storedFolderPath += sdf.format(Calendar.getInstance().getTime());
        }
        
        if (StringUtils.isNotBlank(fileName)) {
            storedFolderPath += SEPARATOR + fileName;
        }
        
        return storedFolderPath;
    }

    /**
     * NAS에 저장될 물리 파일명을 가져옴
     *
     * @param originalFileName
     * @return
     * @throws Exception
     */
    public static String getGenerateStoredFileName(){
        return UUID.randomUUID().toString().replace("-", "");
    }

    /**
     * 저장될 전체 물리 경로 및 파일명을 가져옴
     *
     * @param sub
     * @return
     */
    public static String getGenerateStoredFileName(String sub) {
        
        String fullFileName = getStoredFolderFullPath(sub) + File.separator + getGenerateStoredFileName();
        
        return fullFileName;
    }
    
    /**
     * 저장된 전체 물리 경로 및 파일명을 가져옴
     *
     * @param subFolder
     * @return
     */
    public static String getFileFolder(String subFolder) {
        return getFileFolder(subFolder, null);
    }
    
    /**
     * 저장된 전체 물리 경로 및 파일명을 가져옴
     *
     * @param subFolder
     * @param fileName
     * @return
     */
    public static String getFileFolder(String subFolder, String fileName) {

        String folderPath = getFolder();
        
        if (StringUtils.isNotBlank(subFolder)) {
            folderPath += subFolder;
        }
        
        if (StringUtils.isNotBlank(fileName)) {
            folderPath += SEPARATOR + fileName;
        }
        
        return FileUploadUtil.replaceSeperator(folderPath);
    }

    /**
     * 파일에 Mime Type를 가져옴
     *
     * @param fileName
     * @return
     */
    public static String getMimeType(String fileName) {
        
        FileNameMap fileNameMap = URLConnection.getFileNameMap();
        
        String type = fileNameMap.getContentTypeFor(fileName);
        
        return type;
    }

    /**
     * 공통관리 폴더를 뺀 나머지 경로를 가져옴
     * ex) /wasapp/as/uploadfile/acct/2018/01/llaksfjoijaoijdfoiajer -> 2018/01/llaksfjoijaoijdfoiajer
     *
     * @param subFolder
     * @return
     */
    public static String removeFolderPath(String subFolder, String fullPath) {
        String path = "";
        if (StringUtils.isNotBlank(fullPath)) {
            
            String storedFolderPath = getFolder();
            
            if (StringUtils.isNotEmpty(subFolder)) {
                storedFolderPath += SEPARATOR + getSubFolder(subFolder);
            }
            if (StringUtils.isNotBlank(storedFolderPath)) {
                storedFolderPath = StringUtils.replace(storedFolderPath, "\\", File.separator);
                path = StringUtils.replace(fullPath, storedFolderPath, "");
            }
        } else {
            path = fullPath;
        }
        return path;
    }

    /**
     * 공통관리 폴더를 가져옴
     * ex) 2018/01/llaksfjoijaoijdfoiajer -> /wasapp/as/uploadfile/acct/2018/01/llaksfjoijaoijdfoiajer
     *
     * @param subFolder
     * @return
     */
    public static String addFolderPath(String subFolder){
        String storedFolderPath = getFolder();
        if (StringUtils.isNotEmpty(subFolder)) {
            storedFolderPath += SEPARATOR + getSubFolder(subFolder);
        }
        return storedFolderPath;
    }

    /**
     * 파일 생성
     *
     * @param filePath
     * @return
     * @throws IOException  
     */
    public static void createFile(String filePath) throws IOException {
        createFile(new File(filePath));
    }

    /**
     * 파일 생성
     *
     * @param file
     * @return
     * @throws IOException 
     */
    public static void createFile(File file) throws IOException {

        String filePath = file.getAbsolutePath();
        if (filePath.indexOf(File.separator) != -1) {
            String fileName = file.getName();
            String fileFolder = StringUtils.replace(filePath, fileName, "");
            File fileDir = new File(fileFolder);
            if (!fileDir.exists()) {
                FileUtils.forceMkdir(fileDir);
            }
            file.createNewFile();
        } else {
            file.createNewFile();
        }
    }
    
    /**
     * 파일 삭제
     *
     * @param filePath
     * @return
     * @throws IOException 
     */
    public static void removeFile(String filePath) throws IOException {
        removeFile(new File(filePath));
    }
    
    /**
     * 파일 삭제
     *
     * @param file
     * @return
     * @throws IOException 
     */
    public static void removeFile(File file) throws IOException {

        if (file.exists()) {
            file.delete();
        } else {
            LOGGER.error("\n\n파일이 존재하지 않습니다.");
        }
    }
    
    /**
     * SAP 기본경로
     *
     * @return
     */
    public static String getSapFolder() {
        
        return FileUploadUtil.replaceSeperator(SAP_FILEUPLOAD_ROOT_PATH);
    }
    
    /**
     * SAP 경로파일
     *
     * @param filePath
     * @return
     */
    public static File getSapFilePath(String filePath) {
        return new File(getSapFolder(), filePath);
    }
    
    /**
     * 다운로드파일명 변경
     *
     * @param ipAdres
     * @return
     */
    public static String convertDwlnFileNm(String fileNm) {

        return StringUtils.replacePattern(fileNm, "[;:\\\\/*?|<>~!@#$%^&\\'\"?]", "_");
    }
    
}
