package com.mobis.maps.comm.vo;

import java.util.Date;
import java.util.Locale;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcIfCommVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsCommSapRfcIfCommVO extends PgBascVO {
    /** 시스템ID */
    private String sysId;
    /** 사용언어 */
    private Locale lcale;
    /** Interface ID */
    private String ifCode;
    /** 회사 코드 */
    private String bukRs;
    /** 영업조직 */
    private String vkorg;
    /** 사용자의 시간대 */
    private String tzone;
    /** 사용자언어 */
    private String spras;
    /** 사용자명 */
    private String uname;
    /** Create User */
    private String zcrname;
    /** Create System Date */
    private Date zcrsdate;
    /** Create System Time */
    private String zcrstime;
    /** Create Local Date */
    private Date zcrldate;
    /** Create Local Time */
    private String zcrltime;
//    /** Change User */
//    private String zudname;
//    /** Change System Date */
//    private Date zudsdate;
//    /** Change System Time */
//    private String zudstime;
//    /** Change Local Date */
//    private Date zudldate;
//    /** Change Local Time */
//    private String zudltime;
    /** Channel사용자이름 */
    private String zusrnm;
    /** IAM 식별자 */
    private String ziamid;
    /** Channel System ID */
    private String zchnsysid;
    /** Channel Login ID */
    private String zchnid;
    /** 메세지 결과[S:성공, E:오류] */
    private String msgType;
    /** 메세지 */
    private String msg;
    /** 메세지ID */
    private String msgId;
    /** 메세지번호 */
    private String msgNo;
    /**
     * @return the sysId
     */
    public String getSysId() {
        return sysId;
    }
    /**
     * @param sysId the sysId to set
     */
    public void setSysId(String sysId) {
        this.sysId = sysId;
    }
    /**
     * @return the lcale
     */
    public Locale getLcale() {
        return lcale;
    }
    /**
     * @param lcale the lcale to set
     */
    public void setLcale(Locale lcale) {
        this.lcale = lcale;
    }
    /**
     * @return the ifCode
     */
    public String getIfCode() {
        return ifCode;
    }
    /**
     * @param ifCode the ifCode to set
     */
    public void setIfCode(String ifCode) {
        this.ifCode = ifCode;
    }
    /**
     * @return the bukRs
     */
    public String getBukRs() {
        return bukRs;
    }
    /**
     * @param bukRs the bukRs to set
     */
    public void setBukRs(String bukRs) {
        this.bukRs = bukRs;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the tzone
     */
    public String getTzone() {
        return tzone;
    }
    /**
     * @param tzone the tzone to set
     */
    public void setTzone(String tzone) {
        this.tzone = tzone;
    }
    /**
     * @return the spras
     */
    public String getSpras() {
        return spras;
    }
    /**
     * @param spras the spras to set
     */
    public void setSpras(String spras) {
        this.spras = spras;
    }
    /**
     * @return the uname
     */
    public String getUname() {
        return uname;
    }
    /**
     * @param uname the uname to set
     */
    public void setUname(String uname) {
        this.uname = uname;
    }
    /**
     * @return the zcrname
     */
    public String getZcrname() {
        return zcrname;
    }
    /**
     * @param zcrname the zcrname to set
     */
    public void setZcrname(String zcrname) {
        this.zcrname = zcrname;
    }
    /**
     * @return the zcrsdate
     */
    public Date getZcrsdate() {
        return zcrsdate;
    }
    /**
     * @param zcrsdate the zcrsdate to set
     */
    public void setZcrsdate(Date zcrsdate) {
        this.zcrsdate = zcrsdate;
    }
    /**
     * @return the zcrstime
     */
    public String getZcrstime() {
        return zcrstime;
    }
    /**
     * @param zcrstime the zcrstime to set
     */
    public void setZcrstime(String zcrstime) {
        this.zcrstime = zcrstime;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zcrltime
     */
    public String getZcrltime() {
        return zcrltime;
    }
    /**
     * @param zcrltime the zcrltime to set
     */
    public void setZcrltime(String zcrltime) {
        this.zcrltime = zcrltime;
    }
    /**
     * @return the zusrnm
     */
    public String getZusrnm() {
        return zusrnm;
    }
    /**
     * @param zusrnm the zusrnm to set
     */
    public void setZusrnm(String zusrnm) {
        this.zusrnm = zusrnm;
    }
    /**
     * @return the ziamid
     */
    public String getZiamid() {
        return ziamid;
    }
    /**
     * @param ziamid the ziamid to set
     */
    public void setZiamid(String ziamid) {
        this.ziamid = ziamid;
    }
    /**
     * @return the zchnsysid
     */
    public String getZchnsysid() {
        return zchnsysid;
    }
    /**
     * @param zchnsysid the zchnsysid to set
     */
    public void setZchnsysid(String zchnsysid) {
        this.zchnsysid = zchnsysid;
    }
    /**
     * @return the zchnid
     */
    public String getZchnid() {
        return zchnid;
    }
    /**
     * @param zchnid the zchnid to set
     */
    public void setZchnid(String zchnid) {
        this.zchnid = zchnid;
    }
    /**
     * @return the msgType
     */
    public String getMsgType() {
        return msgType;
    }
    /**
     * @param msgType the msgType to set
     */
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }
    /**
     * @return the msg
     */
    public String getMsg() {
        return msg;
    }
    /**
     * @param msg the msg to set
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }
    /**
     * @return the msgId
     */
    public String getMsgId() {
        return msgId;
    }
    /**
     * @param msgId the msgId to set
     */
    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }
    /**
     * @return the msgNo
     */
    public String getMsgNo() {
        return msgNo;
    }
    /**
     * @param msgNo the msgNo to set
     */
    public void setMsgNo(String msgNo) {
        this.msgNo = msgNo;
    }
}
