package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * 사용자암호변경이력 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserPwdChghstVO.java
 * @Description : 사용자암호변경이력에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 20.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserPwdChghstVO extends MapsIamCommVO {
    /** 시작일자 */
    private Date strtDt;
    /** 종료일자 */
    private Date endDt;
    /* 사용자암호변경이력 */
    /** 변경일시 */
    private Date changeDt;
    /** 사용자순번ID */
    private String userSeqId;
    /** 암호변경구분코드 */
    private String pwdChageSeCd;
    /** 이전암호 */
    private String bfePwd;
    /** 사용자암호 */
    private String userPwd;
    /** 암호만료일시 */
    private Date pwdEndDt;
    /** 변경자ID */
    private String changeId;
    /**
     * @return the strtDt
     */
    public Date getStrtDt() {
        return strtDt;
    }
    /**
     * @param strtDt the strtDt to set
     */
    public void setStrtDt(Date strtDt) {
        this.strtDt = strtDt;
    }
    /**
     * @return the endDt
     */
    public Date getEndDt() {
        return endDt;
    }
    /**
     * @param endDt the endDt to set
     */
    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }
    /**
     * @return the changeDt
     */
    public Date getChangeDt() {
        return changeDt;
    }
    /**
     * @param changeDt the changeDt to set
     */
    public void setChangeDt(Date changeDt) {
        this.changeDt = changeDt;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    /**
     * @return the pwdChageSeCd
     */
    public String getPwdChageSeCd() {
        return pwdChageSeCd;
    }
    /**
     * @param pwdChageSeCd the pwdChageSeCd to set
     */
    public void setPwdChageSeCd(String pwdChageSeCd) {
        this.pwdChageSeCd = pwdChageSeCd;
    }
    /**
     * @return the bfePwd
     */
    public String getBfePwd() {
        return bfePwd;
    }
    /**
     * @param bfePwd the bfePwd to set
     */
    public void setBfePwd(String bfePwd) {
        this.bfePwd = bfePwd;
    }
    /**
     * @return the userPwd
     */
    public String getUserPwd() {
        return userPwd;
    }
    /**
     * @param userPwd the userPwd to set
     */
    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }
    /**
     * @return the pwdEndDt
     */
    public Date getPwdEndDt() {
        return pwdEndDt;
    }
    /**
     * @param pwdEndDt the pwdEndDt to set
     */
    public void setPwdEndDt(Date pwdEndDt) {
        this.pwdEndDt = pwdEndDt;
    }
    /**
     * @return the changeId
     */
    public String getChangeId() {
        return changeId;
    }
    /**
     * @param changeId the changeId to set
     */
    public void setChangeId(String changeId) {
        this.changeId = changeId;
    }
}
