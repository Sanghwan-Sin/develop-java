package com.mobis.maps.comm.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsFileDwnlException;
import com.mobis.maps.cmmn.exception.MapsTmplatDwnlException;
import com.mobis.maps.cmmn.util.StringUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.comm.service.MapsCommSapAtchFileService;
import com.mobis.maps.comm.vo.MapsCommFileExtVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileCntVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;

/**
 * <pre>
 * 공통 파일 관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommFileController.java
 * @Description : 공통 파일 관리에 대한 컨트롤러 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 8.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommFileController extends HController {

    @Resource(name = "mapsCommFileService")
    private MapsCommFileService mapsCommFileService;
    
    
    /**
     * 업로드 가능 첨부파일확장자 리스트 조회
     *
     * @param attachFileVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/file/selectAtchFileExtInfo.do")
    public NexacroResult selectAtchFileExtInfo(
            NexacroResult result) throws Exception {
        MapsCommFileExtVO atchFileTemp = new MapsCommFileExtVO();
        List<MapsCommFileExtVO> lstAtchFile = mapsCommFileService.selectAtchFileExtInfo(atchFileTemp);
        result.addDataSet("dsOutput", lstAtchFile);
        return result;
    }
    
    /**
     * 첨부파일리스트 조회
     *
     * @param attachFileVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/file/selectAtchFileList.do")
    public NexacroResult selectAtchFileList(
            @ParamDataSet(name="dsInput") MapsAtchFileVO attachFileVO
            , NexacroResult result) throws Exception {

        List<MapsAtchFileVO> lstAtchFile = mapsCommFileService.selectAtchFileList(attachFileVO);
        
        result.addDataSet("dsOutput", lstAtchFile);
        
        return result;
    }
    
    /**
     * 첨부파일 삭제
     *
     * @param attachFileVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/file/deleteAtchFile.do")
    public NexacroResult deleteAtchFile(@ParamDataSet(name="dsInput") MapsAtchFileVO attachFileVO
            , NexacroResult result) throws Exception {

        int procCnt = mapsCommFileService.deleteAtchFile(attachFileVO);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 첨부파일 삭제(전체)
     *
     * @param attachFileVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/file/deleteAtchFileAll.do")
    public NexacroResult deleteAtchFileAll(@ParamDataSet(name="dsInput") MapsAtchFileVO attachFileVO
            , NexacroResult result) throws Exception {

        int procCnt = mapsCommFileService.deleteAtchFileAll(attachFileVO);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 첨부파일 업로드
     *
     * @param request
     * @param attachGubn
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/file/selectAtchFileUpload.do", method = {RequestMethod.GET, RequestMethod.POST})
    public NexacroResult selectAtchFileUpload(
            @RequestParam("atchSe") String atchSe
            , HttpServletRequest request
            , NexacroResult result) throws Exception {

        List<MapsAtchFileVO> lstAtchFile = mapsCommFileService.selectAtchFileUpload(request, atchSe);
        
        result.addDataSet("dsOutput", lstAtchFile);
        
        return result;
    }

    /**
     * 첨부파일 다운로드
     *
     * @param request
     * @param response
     * @param attachFileVO
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectAtchFileDownload.do", method = {RequestMethod.GET, RequestMethod.POST})
    public void selectAtchFileDownload(
            @RequestParam("atchSe") String atchSe
            , @RequestParam("atchId") String atchId
            , @RequestParam("fileNo") int fileNo
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        
        MapsAtchFileVO atchFileVO = new MapsAtchFileVO();
        atchFileVO.setAtchSe(atchSe);
        atchFileVO.setAtchId(StringUtil.reXSSParam(atchId));
        atchFileVO.setFileNo(fileNo);

        try {
            mapsCommFileService.selectAtchFileDownload(atchFileVO, request, response);
        } catch (Exception e) {
            throw new MapsFileDwnlException(e.getMessage(), e);
        }
    }
    
    /**
     * 첨부파일 Image Viewer
     *
     * @param atchSe
     * @param atchId
     * @param fileNo
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectAtchFileImageViewer.do", method = {RequestMethod.GET, RequestMethod.POST})
    public void selectAtchFileImageViewer(
            @RequestParam("atchSe") String atchSe
            , @RequestParam("atchId") String atchId
            , @RequestParam("fileNo") int fileNo
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        
        MapsAtchFileVO atchFileVO = new MapsAtchFileVO();
        atchFileVO.setAtchSe(atchSe);
        atchFileVO.setAtchId(StringUtil.reXSSParam(atchId));
        atchFileVO.setFileNo(fileNo);

        try {
            mapsCommFileService.selectAtchFileImageViewer(atchFileVO, request, response);
        } catch (Exception e) {
            throw new MapsFileDwnlException(e.getMessage(), e);
        }
    }

    /**
     * Template파일 다운로드
     *
     * @param tmplatId
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(path = "/comm/selectTmplatFileDownload.do", method = {RequestMethod.GET, RequestMethod.POST})
    public void selectTmplatFileDownload(
            @RequestParam("tmplatId") String tmplatId
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        mapsCommFileService.selectTmplatFileDownload(tmplatId, request, response);
    }
    
    /**
     * Excel Template파일 다운로드
     *
     * @param tmplatId
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(path = "/comm/selectExcelTmplatFileDownload.do", method = {RequestMethod.GET, RequestMethod.POST})
    public void selectExcelTmplatFileDownload(
            @RequestParam("tmplatId") String tmplatId
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        mapsCommFileService.selectExcelTmplatFileDownload(tmplatId, request, response);
    }
    

    /**
     * 메뉴얼 뷰어
     *
     * @param scrinId
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/file/selectMnlViewer.do", method = {RequestMethod.GET, RequestMethod.POST})
    public String selectMnlViewer(
              @RequestParam("scrinId") String scrinId
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        MapsIamScreenVO iamScreenVO = mapsCommFileService.selectScrinNm(scrinId, loginInfo);
        if (iamScreenVO == null) {
            // 메뉴얼을 찾을 수 없습니다.
            throw new MapsTmplatDwnlException(messageSource, "ECI0000089", loginInfo.getUserLcale(), null);
        }

        request.setAttribute("langCd", loginInfo.getLangCd());
        request.setAttribute("scrinCd", iamScreenVO.getScrinCd());
        request.setAttribute("scrinNm", iamScreenVO.getScrinNm());
        
        return "comm/mnlViewer";
    }
    
    /**
     * 메뉴얼 파일 다운로드
     *
     * @param scrinId
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectMnlFileDownload.do", method = {RequestMethod.GET, RequestMethod.POST})
    public void selectMnlFileDownload(
            @RequestParam("scrinId") String scrinId
            , @RequestParam(value="dwnlMode", required=false , defaultValue="D") String dwnlMode
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        mapsCommFileService.selectMnlFileDownload(scrinId, dwnlMode, loginInfo, request, response);
    }
    
    /**
     * SAP 첨부파일리스트 조회
     *
     * @param commSapRfcVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectSapAtchFileList.do")
    public NexacroResult selectSapAtchFileList(@ParamDataSet(name="dsInput") MapsCommSapAtchFileVO commSapRfcVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsCommSapAtchFileVO> lstSapAtchFile = mapsCommFileService.selectSapAtchFileList(commSapRfcVO, loginInfo);

        result.addDataSet("dsOutput", lstSapAtchFile);
        
        return result;
    }

    /**
     * SAP 첨부파일상세 조회
     *
     * @param commSapAtchFileVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectSapAtchFileDetail.do")
    public NexacroResult selectSapAtchFileDetail(@ParamDataSet(name="dsInput") MapsCommSapAtchFileVO commSapAtchFileVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        MapsCommSapAtchFileVO rsltSapAtchFile = mapsCommFileService.selectSapAtchFileDetail(commSapAtchFileVO, loginInfo);

        result.addDataSet("dsOutput", rsltSapAtchFile);
        
        return result;
    }
    
    /**
     * SAP 첨부파일건수 조회
     *
     * @param commSapAtchFileInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectSapAtchFileCnt.do")
    public NexacroResult selectSapAtchFileCnt(@ParamDataSet(name="dsInput") MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        MapsCommSapAtchFileInfoVO rsltSapAtchFileCntInfo = mapsCommFileService.selectSapAtchFileCnt(commSapAtchFileInfoVO, loginInfo);

        result.addDataSet("dsOutput", rsltSapAtchFileCntInfo);
        
        return result;
    }
    
    /**
     * SAP 첨부파일건수 조회(복수건)
     *
     * @param commSapAtchFileCntVO
     * @param refNos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectSapAtchFileCntList.do")
    public NexacroResult selectSapAtchFileCntList(@ParamDataSet(name="dsInput") MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , @ParamDataSet(name="dsInputRefNo") List<MapsCommSapAtchFileCntVO> refNos
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsCommSapAtchFileCntVO> lstSapAtchFileCnt = mapsCommFileService.selectSapAtchFileCntList(commSapAtchFileCntVO, refNos, loginInfo);

        result.addDataSet("dsOutput", lstSapAtchFileCnt);
        
        return result;
    }
    
    /**
     * SAP 첨부파일 Summary건수 조회
     *
     * @param commSapAtchFileSum2VO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectSapAtchFileSumryCnt.do")
    public NexacroResult selectSapAtchFileSumryCnt(@ParamDataSet(name="dsInput") MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , @ParamDataSet(name="dsInputRefNo") List<MapsCommSapAtchFileCntVO> refNos
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsCommSapAtchFileCntVO> lstSapAtchFileSumInfo = mapsCommFileService.selectSapAtchFileSumryCnt(commSapAtchFileCntVO, refNos, loginInfo);

        result.addDataSet("dsOutput", lstSapAtchFileSumInfo);
        
        return result;
    }


    /**
     * SAP 첨부파일정보 조회
     *
     * @param commSapRfcInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectSapAtchFileRegistInfo.do")
    public NexacroResult selectSapAtchFileRegistInfo(@ParamDataSet(name="dsInput") MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, MapsCommSapAtchFileInfoVO> mFileInfo = mapsCommFileService.selectSapAtchFileRegistInfo(commSapAtchFileInfoVO, loginInfo);

        result.addDataSet("dsOutputConfig", mFileInfo.get(MapsCommSapAtchFileService.MAP_KEY_ES_CONFIG));
        result.addDataSet("dsOutputMaster", mFileInfo.get(MapsCommSapAtchFileService.MAP_KEY_ES_MASTER));
        result.addDataSet("dsOutputCreate", mFileInfo.get(MapsCommSapAtchFileService.MAP_KEY_ES_CREATE));
        
        return result;
    }
    
    /**
     * SAP 첨부파일 복수 등록
     *
     * @param commSapRfcVO
     * @param sapAtchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/multiSapAtchFile.do")
    public NexacroResult multiSapAtchFile(@ParamDataSet(name="dsInput") MapsCommSapAtchFileVO commSapAtchFileVO
            , List<MapsCommSapAtchFileVO> sapAtchFiles
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsCommSapAtchFileVO> lstSapAtchFile = mapsCommFileService.multiSapAtchFile(commSapAtchFileVO, sapAtchFiles, loginInfo);

        result.addDataSet("dsOutput", lstSapAtchFile);
        
        return result;
    }
    
    /**
     * SAP 첨부파일 등록
     *
     * @param commSapAtchFileVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/insertSapAtchFile.do")
    public NexacroResult insertSapAtchFile(@ParamDataSet(name="dsInput") MapsCommSapAtchFileVO commSapAtchFileVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        MapsCommSapAtchFileVO rsltSapAtchFile = mapsCommFileService.insertSapAtchFile(commSapAtchFileVO, loginInfo);

        result.addDataSet("dsOutput", rsltSapAtchFile);
        
        return result;
    }
    
    /**
     * SAP 첨부파일 수정
     *
     * @param commSapRfcVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/updateSapAtchFile.do")
    public NexacroResult updateSapAtchFile(@ParamDataSet(name="dsInput") MapsCommSapAtchFileVO commSapAtchFileVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        MapsCommSapAtchFileVO rsltSapAtchFile = mapsCommFileService.updateSapAtchFile(commSapAtchFileVO, loginInfo);

        result.addDataSet("dsOutput", rsltSapAtchFile);
        
        return result;
    }
    
    /**
     * SAP 첨부파일 삭제
     *
     * @param commSapAtchFileVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/deleteSapAtchFile.do")
    public NexacroResult deleteSapAtchFile(@ParamDataSet(name="dsInput") MapsCommSapAtchFileVO commSapAtchFileVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        MapsCommSapAtchFileVO rsltSapAtchFile = mapsCommFileService.deleteSapAtchFile(commSapAtchFileVO, loginInfo);

        result.addDataSet("dsOutput", rsltSapAtchFile);
        
        return result;
    }

    /**
     * SAP 첨부파일 삭제(전체)
     *
     * @param commSapAtchFileVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/deleteAllSapAtchFile.do", method = {RequestMethod.GET, RequestMethod.POST})
    public NexacroResult deleteAllSapAtchFile(@ParamDataSet(name="dsInput") MapsCommSapAtchFileVO commSapAtchFileVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsCommSapAtchFileVO> lstSapAtchFile = mapsCommFileService.deleteAllSapAtchFile(commSapAtchFileVO, loginInfo);

        result.addDataSet("dsOutput", lstSapAtchFile);
        
        return result;
    }

    /**
     * SAP 첨부파일 삭제(RowSe="D" 선택)
     *
     * @param commSapAtchFileVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/deleteSelectdSapAtchFile.do", method = {RequestMethod.GET, RequestMethod.POST})
    public NexacroResult deleteSelectdSapAtchFile(@ParamDataSet(name="dsInput") List<MapsCommSapAtchFileVO> sapAtchFiles
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsCommSapAtchFileVO> lstSapAtchFile = mapsCommFileService.deleteSelectdSapAtchFile(sapAtchFiles, loginInfo);

        result.addDataSet("dsOutput", lstSapAtchFile);
        
        return result;
    }
    
    /**
     * SAP첨부파일 업로드
     *
     * @param request
     * @param attachGubn
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/file/selectSapAtchFileUpload.do", method = {RequestMethod.GET, RequestMethod.POST})
    public NexacroResult selectSapAtchFileUpload(
            @RequestParam("sysSeCd") String sysSeCd
            , @RequestParam("sysId") String sysId
            , @RequestParam("fscode") String fscode
            , @RequestParam("refNo") String refNo
            , @RequestParam(value="sameFileNmWithRefNo", required=false , defaultValue="N") String sameFileNmWithRefNo
            , HttpServletRequest request
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsCommSapAtchFileVO> lstSapAtchFile = mapsCommFileService.selectSapAtchFileUpload(request, sysSeCd, sysId, fscode, refNo , sameFileNmWithRefNo , loginInfo);
        
        result.addDataSet("dsOutput", lstSapAtchFile);
        
        return result;
    }
    
    /**
     * SAP첨부파일 다운로드
     *
     * @param storgeCtgry
     * @param fileId
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectSapAtchFileDownload.do", method = {RequestMethod.GET, RequestMethod.POST})
    public void selectSapAtchFileDownload(
            @RequestParam(value="sysId", required=false, defaultValue="PC") String sysId
            , @RequestParam("fscode") String fscode
            , @RequestParam("refNo") String refNo
            , @RequestParam("fileSeqno") String fileSeqno
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        MapsCommSapAtchFileVO commSapRfcVO = new MapsCommSapAtchFileVO();
        commSapRfcVO.setSysId(sysId);
        commSapRfcVO.setFscode(fscode);
        commSapRfcVO.setRefNo(refNo);
        commSapRfcVO.setFileSeqno(fileSeqno);

        try {
            mapsCommFileService.selectSapAtchFileDownload(commSapRfcVO, loginInfo, request, response);
        } catch (Exception e) {
            throw new MapsFileDwnlException(e.getMessage(), e);
        }
    }

    /**
     * SAP이미지파일 뷰어
     *
     * @param storgeCtgry
     * @param fileId
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(path = "/comm/file/selectSapImageFileViewer.do", method = {RequestMethod.GET, RequestMethod.POST})
    public void selectSapImageFileViewer(
            @RequestParam(value="sysId", required=false, defaultValue="PC") String sysId
            , @RequestParam("fscode") String fscode
            , @RequestParam("refNo") String refNo
            , @RequestParam("fileSeqno") String fileSeqno
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        MapsCommSapAtchFileVO commSapRfcVO = new MapsCommSapAtchFileVO();
        commSapRfcVO.setSysId(sysId);
        commSapRfcVO.setFscode(fscode);
        commSapRfcVO.setRefNo(refNo);
        commSapRfcVO.setFileSeqno(fileSeqno);

        try {
            mapsCommFileService.selectSapImageFileViewer(commSapRfcVO, loginInfo, request, response);
        } catch (Exception e) {
            throw new MapsFileDwnlException(e.getMessage(), e);
        }
    }


    /**
     * SAP첨부파일 업로드 - 복수 refNo : POST시 'name' 의 값으로 refNo를 보내야 함
     *
     * @param request
     * @param attachGubn
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/file/selectSapAtchFileUploadMulti.do", method = {RequestMethod.GET, RequestMethod.POST})
    public NexacroResult selectSapAtchFileUploadMulti (
            @RequestParam("sysSeCd") String sysSeCd
            , @RequestParam("sysId") String sysId
            , @RequestParam("fscode") String fscode
            , @RequestParam(value="sameFileNmWithRefNo", required=false , defaultValue="N") String sameFileNmWithRefNo
            , HttpServletRequest request
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsCommSapAtchFileVO> lstSapAtchFile = mapsCommFileService.selectSapAtchFileUploadMulti(request, sysSeCd, sysId, fscode, sameFileNmWithRefNo , loginInfo);
        
        result.addDataSet("dsOutput", lstSapAtchFile);
        
        return result;
    }

}
