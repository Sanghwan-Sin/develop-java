package com.mobis.maps.comm.constants;

import java.io.StringWriter;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.context.MessageSource;

import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.comm.service.MapsCommCodeService;
import com.mobis.maps.comm.vo.MapsCommCodeVO;

import freemarker.cache.ClassTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.TemplateNotFoundException;

/**
 * <pre>
 * E-메일템플릿
 * </pre>
 *
 * @ClassName   : MapsCommEmailTmplat.java
 * @Description : E-메일템플릿에 대한 정보를 정의
 * @author DT048058
 * @since 2020. 5. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 13.     DT048058     	최초 생성
 * </pre>
 */

public enum MapsCommEmailTmplat {
    
      IAM001("iam", "DC00000001", "")           //비밀번호찾기
    , IAM002("iam", "DC00000002", "")           //계정잠김해제
    , IAM003("iam", "DC00000003", "")           //계정신청(신청자)
    , IAM004("iam", "DC00000006", "")           //계정신청(승인자)
    , IAM005("iam", "DC00000004", "")           //계정신청승인(신청자)
    , IAM006("iam", "DC00000005", "")           //계정신청반려(신청자)
    , IAM007("iam", "DCI0000004", "")           //계정잠김해제요청(관리자)
    , IAM008("iam", "DCM0000002", "")           //ID 찾기
    ;

    /** 서브패스 */
    private String subPath;
    /** 제목메세지ID */
    private String sjMsgId;
    /** 디폴트송신자메일 */
    private String dfltFromEmail;
    
    private MapsCommEmailTmplat(String subPath, String sjMsgId, String dfltFromEmail) {
        this.subPath = subPath;
        this.sjMsgId = sjMsgId;
        this.dfltFromEmail = dfltFromEmail;
    }
    
    public String getSj(MessageSource msgSrc, Object bean, Locale locale) throws Exception {
        
        String[] args = new String[0];
        if (this == IAM001) {
            args = ArrayUtils.add(args, BeanUtils.getProperty(bean, "userNm"));
        } else if (this == IAM002) {
            args = ArrayUtils.add(args, BeanUtils.getProperty(bean, "userNm"));
        } else if (this == IAM003) {
            args = ArrayUtils.add(args, BeanUtils.getProperty(bean, "acntReqstNo"));
        } else if (this == IAM004) {
            args = ArrayUtils.add(args, BeanUtils.getProperty(bean, "userNm"));
            args = ArrayUtils.add(args, BeanUtils.getProperty(bean, "acntReqstNo"));
        } else if (this == IAM005) {
            args = ArrayUtils.add(args, BeanUtils.getProperty(bean, "acntReqstNo"));
        } else if (this == IAM006) {
            args = ArrayUtils.add(args, BeanUtils.getProperty(bean, "acntReqstNo"));
        } else if (this == IAM007) {
            args = ArrayUtils.add(args, BeanUtils.getProperty(bean, "userNm"));
        } else if (this == IAM008) {
            args = ArrayUtils.add(args, BeanUtils.getProperty(bean, "sysSeNm"));
        }
        
        return msgSrc.getMessage(this.getSjMsgId(), args, locale);
    }

    public String getCn(Object data, Locale locale) throws Exception {

        Configuration cfg = getFreemakerCfg(locale);

        Template cnTmplat = getFreemakerTmplat(cfg, locale);

        String cn = null;

        try (StringWriter out = new StringWriter()) {
            
            cnTmplat.process(data, out);
            
            cn = out.getBuffer().toString();

            out.flush();
        }
        
        return cn;
    }
    
    public String getCn(Map<String, Object> mData, Locale locale) throws Exception {
        
        Configuration cfg = getFreemakerCfg(locale);
        
        Template cnTmplat = getFreemakerTmplat(cfg, locale);

        String cn = null;
        
        try (StringWriter out = new StringWriter()) {
            
            cnTmplat.process(mData, out);
            
            cn = out.getBuffer().toString();

            out.flush();
        }
        
        return cn;
    }
    
    private Configuration getFreemakerCfg(Locale locale) {

        Configuration cfg = new Configuration(Configuration.VERSION_2_3_28);
        cfg.setDefaultEncoding("UTF-8");
        cfg.setLocale(locale);
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        
        ClassTemplateLoader cTmplat = new ClassTemplateLoader(getClass(), "/templates/email/" + getSubPath());
        cfg.setTemplateLoader(cTmplat);
        
        return cfg;
    }
    
    private Template getFreemakerTmplat(Configuration cfg, Locale locale)throws Exception {

        Template cnTmplat = null;
        try {
            cnTmplat = cfg.getTemplate(this.name() + "_" + locale.toString() + ".ftl");
        } catch (TemplateNotFoundException e) {
            cnTmplat = cfg.getTemplate(this.name() + ".ftl");
        }
        
        return cnTmplat;
    }
    
    /**
     * 시스템구분명 취득
     *
     * @param sysSeCd
     * @param langCd
     * @return
     * @throws Exception
     */
    public String getSysSeNm(MapsCommCodeService commCodeService, String sysSeCd, String langCd) throws Exception {
        
        MapsCommCodeVO commCodeVO = new MapsCommCodeVO();
        commCodeVO.setCodeGroup("C000000002");
        commCodeVO.setCode(sysSeCd);
        commCodeVO.setLangCd(langCd);
        
        CodeVO codeNmVO = commCodeService.selectCodeNm(commCodeVO);
        if (codeNmVO == null) {
            return null;
        }
        
        return codeNmVO.getCodeNm();
    }

    /**
     * @return the subPath
     */
    public String getSubPath() {
        return subPath;
    }
    
    /**
     * @return the sjMsgId
     */
    public String getSjMsgId() {
        return sjMsgId;
    }

    /**
     * @return the dfltFromEmail
     */
    public String getDfltFromEmail() {
        return dfltFromEmail;
    }
}

