package com.mobis.maps.cmmn.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import able.com.util.fmt.DateUtil;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.RfcOptionVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsRfcMappperUtil.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 10. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 10.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsRfcMappperUtil {
    
    private final static Logger LOGGER = LoggerFactory.getLogger(MapsRfcMappperUtil.class);
    
    public static final String SEPERATOR = "|";

    public static final String TARGET_NAME_PARAMLIST = "P";
    
    public static final String IPTT_SE_IMPORT = "I";
    
    public static final String IPTT_SE_EXPORT = "E";
    
    public static final String[] RESULT_INFO_KEY = {
          "MTYPE"
        , "MESSAGE"
        , "MSGID"
        , "MSGNO"
    };
    public static final String[] RESULT_INFO_NAME = {
         "msgType"
       , "msg"
       , "msgId"
       , "msgNo"
    };
    public static final String[] COMM_TIME_FIELDS = {
          "ZCRSTIME"
        , "ZCRLTIME"
        , "ZUDSTIME"
        , "ZUDLTIME"
    };
    /**
     * Field 정합성 체크
     *
     * @param annotation
     * @param targetNm
     * @param ipttSeNm
     * @return
     */
    private static boolean validateField(MapsRfcMappper annotation, String targetNm, String ipttSeNm) {

        //logger.debug("→ setImportParamList::start[targetNm="+targetNm+",ipttSeNm="+ipttSeNm+"]");
        String targetName = annotation.targetName();
        String ipttSe = annotation.ipttSe();
        String fieldKey = annotation.fieldKey();

        boolean bRtn = true;
        if (StringUtils.isBlank(targetName) || !targetNm.matches(targetName)) {
            bRtn = false;
        } else if (StringUtils.isBlank(ipttSe) || !ipttSeNm.matches(ipttSe)) {
            bRtn = false;
        } else if (StringUtils.isBlank(fieldKey)) {
            bRtn = false;
        }

        //logger.debug("→ validateField::end["+bRtn+"][targetNm="+targetNm+"("+targetNm.matches(targetName)+"),ipttSeNm="+ipttSeNm+"("+ipttSeNm.matches(ipttSe)+")]");
        return bRtn;
    }
    
    /**
     * Import ParameterList Setting
     *
     * @param function
     * @param object
     */
    public static void setImportParamList(Function function, Object object) {
        // Load all fields in the class (private included)
        Field[] attributes = object.getClass().getDeclaredFields();
        for (Field field : attributes) {
            // Dynamically read Attribute Name
            MapsRfcMappper annotation = field.getAnnotation(MapsRfcMappper.class);
            if (annotation == null)  {
                continue;
            }
            
            if (!validateField(annotation, TARGET_NAME_PARAMLIST, IPTT_SE_IMPORT)) {
                continue;
            }
            
            String fieldKey = annotation.fieldKey();
            int idxFieldKey = StringUtils.indexOf(fieldKey, SEPERATOR);
            if (idxFieldKey > 0) {
                fieldKey = StringUtils.split(fieldKey, SEPERATOR)[0];
            }
            //logger.debug("→ setImportParamList::annotation[name="+field.getName()+",fieldKey="+fieldKey+"]");
            
            //logger.debug("→ setImportParamList::Field[name="+field.getName()+",fieldKey="+fieldKey+"]");
            Object objValue = null;
            try {
                field.setAccessible(true);
                
                objValue = field.get(object);
                if (objValue == null) {
                    String defaultVal = annotation.defaultVal();
                    if (StringUtils.isBlank(defaultVal)) {
                        continue;
                    }
                    int idxDefaultVal = StringUtils.indexOf(defaultVal, SEPERATOR);
                    if (idxDefaultVal > 0) {
                        defaultVal = StringUtils.split(defaultVal, SEPERATOR)[0];
                    }
                    objValue = convertObjectValue(field, defaultVal);
                }
            } catch (IllegalArgumentException | IllegalAccessException e) {
                e.printStackTrace();
            }
            
            function.getImportParameterList().setValue(fieldKey, objValue);
        }
    }
    

    /**
     * Import ParameterList Setting
     *
     * @param function
     * @param paramTrgtNm
     * @param object
     */
    public static void setImportParamList(Function function, String paramTrgtNm, Object object) {
        // Load all fields in the class (private included)
        Field[] attributes = object.getClass().getDeclaredFields();
        checkImport(function, paramTrgtNm, object, attributes);
    }

    /**
     * Statements
     *
     * @param function
     * @param paramTrgtNm
     * @param object
     * @param attributes
     */
    private static void checkImport(Function function, String paramTrgtNm, Object object, Field[] attributes) {
        for (Field field : attributes) {
            // Dynamically read Attribute Name
            MapsRfcMappper annotation = field.getAnnotation(MapsRfcMappper.class);
            if (annotation == null)  {
                continue;
            }

            String fieldParamTrgtNm = annotation.paramTrgtNm();
            if (StringUtils.isBlank(fieldParamTrgtNm) || !paramTrgtNm.matches(fieldParamTrgtNm)) {
                continue;
            }
            
            if (!validateField(annotation, TARGET_NAME_PARAMLIST, IPTT_SE_IMPORT)) {
                continue;
            }
            
            String fieldKey = annotation.fieldKey();
            int idxFieldKey = StringUtils.indexOf(fieldKey, SEPERATOR);
            if (idxFieldKey > 0) {
                fieldKey = StringUtils.split(fieldKey, SEPERATOR)[0];
            }
            //logger.debug("→ setImportParamList::annotation[name="+field.getName()+",fieldKey="+fieldKey+"]");
            
            //logger.debug("→ setImportParamList::Field[name="+field.getName()+",fieldKey="+fieldKey+"]");
            Object objValue = null;
            try {
                field.setAccessible(true);
                
                objValue = field.get(object);
                if (objValue == null) {
                    String defaultVal = annotation.defaultVal();
                    if (StringUtils.isBlank(defaultVal)) {
                        continue;
                    }
                    int idxDefaultVal = StringUtils.indexOf(defaultVal, SEPERATOR);
                    if (idxDefaultVal > 0) {
                        defaultVal = StringUtils.split(defaultVal, SEPERATOR)[0];
                    }
                    objValue = convertObjectValue(field, defaultVal);
                }
            } catch (IllegalArgumentException | IllegalAccessException e) {
                e.printStackTrace();
            }
            
            function.getImportParameterList().setValue(fieldKey, objValue);
        }
    }
    
    /**
     * Import ParameterList Structure Setting
     *
     * @param function
     * @param structureName
     * @param object
     * @return
     */
    public static JCoStructure setImportStructure(Function function, String structureName, Object object) {
        
        JCoStructure structure = function.getImportStructure(structureName);
        
        // Load all fields in the class (private included)
        Field[] attributes = object.getClass().getDeclaredFields();
        for (Field field : attributes) {
            // Dynamically read Attribute Name
            MapsRfcMappper annotation = field.getAnnotation(MapsRfcMappper.class);
            if (annotation == null)  {
                continue;
            }
            
            if (!validateField(annotation, structureName, IPTT_SE_IMPORT)) {
                continue;
            }

            String fieldKey = annotation.fieldKey();
            int idxFieldKey = StringUtils.indexOf(fieldKey, SEPERATOR);
            if (idxFieldKey > 0) {
                fieldKey = StringUtils.split(fieldKey, SEPERATOR)[0];
            }
            //logger.debug("→ setImportStructure::annotation[name="+field.getName()+",fieldKey="+fieldKey+"]");

            Object objValue = null;
            try {
                field.setAccessible(true);

                objValue = field.get(object);
                if (objValue == null) {
                    String defaultVal = annotation.defaultVal();
                    if (StringUtils.isEmpty(defaultVal)) {
                        continue;
                    }
                    int idxDefaultVal = StringUtils.indexOf(defaultVal, SEPERATOR);
                    if (idxDefaultVal > 0) {
                        defaultVal = StringUtils.split(defaultVal, SEPERATOR)[0];
                    }
                    objValue = convertObjectValue(field, defaultVal);
                }
            } catch (IllegalArgumentException | IllegalAccessException e) {
                LOGGER.error(e.getMessage(), e);
            }
            
            structure.setValue(fieldKey, objValue);
        }
        
        return structure;
    }

    /**
     * Import ParameterList Table Setting
     *
     * @param function
     * @param structureName
     * @param object
     */
    public static void appendImportStructureTableRow(Function function, String structureName, Object object) {

        JCoTable jcoTbl = function.getImportStructureTable(structureName);
        jcoTbl.appendRow();

        Field[] attributes = object.getClass().getDeclaredFields();
        for (Field field : attributes) {
            MapsRfcMappper annotation = field.getAnnotation(MapsRfcMappper.class);
            if (annotation == null)  {
                continue;
            }
            
            if (!validateField(annotation, structureName, IPTT_SE_IMPORT)) {
                continue;
            }

            String fieldKey = annotation.fieldKey();
            int idxFieldKey = StringUtils.indexOf(fieldKey, SEPERATOR);
            if (idxFieldKey > 0) {
                fieldKey = StringUtils.split(fieldKey, SEPERATOR)[0];
            }
            //logger.debug("→ appendImportTableRow::annotation[name="+field.getName()+",fieldKey="+fieldKey+"]");
            
            Object objValue = null;
            try {
                field.setAccessible(true);

                objValue = field.get(object);
                if (objValue == null) {
                    String defaultVal = annotation.defaultVal();
                    if (StringUtils.isEmpty(defaultVal)) {
                        continue;
                    }
                    int idxDefaultVal = StringUtils.indexOf(defaultVal, SEPERATOR);
                    if (idxDefaultVal > 0) {
                        defaultVal = StringUtils.split(defaultVal, SEPERATOR)[0];
                    }
                    objValue = convertObjectValue(field, defaultVal);
                }
            } catch (IllegalArgumentException | IllegalAccessException e) {
                LOGGER.error(e.getMessage(), e);
            }
            
            jcoTbl.setValue(fieldKey, objValue);
        }
    }

    /**
     * Import ParameterList Table Setting(Multi Values)
     *
     * @param function
     * @param structureName
     * @param values
     * @throws Exception
     */
    public static void appendImportMultiValues(Function function, String structureName, List<RfcOptionVO> values) throws Exception {

        JCoTable jcoTbl = function.getImportStructureTable(structureName);
        
        for (RfcOptionVO value: values) {
            jcoTbl.appendRow();
            jcoTbl.setValue(0, value.getVal());
        }
    }

    /**
     * Import ParameterList Table Setting(Multi Options)
     *
     * @param function
     * @param structureName
     * @param values
     * @throws Exception
     */
    public static void appendImportMultiOptions(Function function, String structureName, List<RfcOptionVO> values) throws Exception {

        JCoTable jcoTbl = function.getImportStructureTable(structureName);
        
        for (RfcOptionVO value: values) {
            jcoTbl.appendRow();
            jcoTbl.setValue("SIGN", value.getSign());
            jcoTbl.setValue("OPTION", value.getOption());
            jcoTbl.setValue("LOW", value.getLow());
            jcoTbl.setValue("HIGH", value.getHigh());
        }
    }
    
    /**
     * Import TableParameterList Setting
     *
     * @param function
     * @param tableName
     * @param object
     */
    public static void appendImportTableRow(Function function, String tableName, Object object) {

        JCoTable jcoTbl = function.getImportTableParameter(tableName);
        jcoTbl.appendRow();

        Field[] attributes = object.getClass().getDeclaredFields();
        for (Field field : attributes) {
            MapsRfcMappper annotation = field.getAnnotation(MapsRfcMappper.class);
            if (annotation == null)  {
                continue;
            }
            
            if (!validateField(annotation, tableName, IPTT_SE_IMPORT)) {
                continue;
            }

            String fieldKey = annotation.fieldKey();
            int idxFieldKey = StringUtils.indexOf(fieldKey, SEPERATOR);
            if (idxFieldKey > 0) {
                fieldKey = StringUtils.split(fieldKey, SEPERATOR)[0];
            }
            //logger.debug("→ appendImportTableRow::annotation[name="+field.getName()+",fieldKey="+fieldKey+"]");
            
            Object objValue = null;
            try {
                field.setAccessible(true);

                objValue = field.get(object);
                if (objValue == null) {
                    String defaultVal = annotation.defaultVal();
                    if (StringUtils.isEmpty(defaultVal)) {
                        continue;
                    }
                    int idxDefaultVal = StringUtils.indexOf(defaultVal, SEPERATOR);
                    if (idxDefaultVal > 0) {
                        defaultVal = StringUtils.split(defaultVal, SEPERATOR)[0];
                    }
                    objValue = convertObjectValue(field, defaultVal);
                }
            } catch (IllegalArgumentException | IllegalAccessException e) {
                LOGGER.error(e.getMessage(), e);
            }
            
            jcoTbl.setValue(fieldKey, objValue);
        }
        
    }
    
    /**
     * Export ParameterList Setting
     *
     * @param function
     * @param object
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public static void setExportParamList(FunctionResult function, Object object, Locale locale) throws Exception {
        // Load all fields in the class (private included)
        Field[] attributes = object.getClass().getDeclaredFields();
        for (Field field : attributes) {
            // Dynamically read Attribute Name
            MapsRfcMappper annotation = field.getAnnotation(MapsRfcMappper.class);
            if (annotation == null)  {
                continue;
            }
            
            if (!validateField(annotation, TARGET_NAME_PARAMLIST, IPTT_SE_EXPORT)) {
                continue;
            }

            String fieldKey = annotation.fieldKey();
            int idxFieldKey = StringUtils.indexOf(fieldKey, SEPERATOR);
            if (idxFieldKey > 0) {
                fieldKey = StringUtils.split(fieldKey, SEPERATOR)[0];
            }
            field.setAccessible(true);
            if( LOGGER.isDebugEnabled() ) {
                LOGGER.debug("→ setExportParamList::annotation[name="+field.getName()+",fieldKey="+fieldKey+",type=" + field.getType() + "]");
            }
            if (field.getType() == byte[].class) {
                setProperty(object, field, fieldKey, function.getExportParameterList().getByteArray(fieldKey));
                continue;
            }
//            String classNm = function.getExportParameterList().getMetaData().getClassNameOfField(fieldKey);
//            logger.debug("→ setExportParamList::annotation[name="+field.getName()+",fieldKey="+fieldKey+",type=" + field.getType() + ",classNm="+classNm+"]");
//            if (StringUtils.startsWith(classNm, "byte")) {
//                setProperty(object, field, function.getExportParameterList().getByteArray(fieldKey));
//                continue;
//            }
            
            Object objValue = function.getExportParameterList().getValue(fieldKey);
            if (objValue == null) {
                String defaultVal = annotation.defaultVal();
                if (StringUtils.isEmpty(defaultVal)) {
                    continue;
                }
                int idxDefaultVal = StringUtils.indexOf(defaultVal, SEPERATOR);
                if (idxDefaultVal > 0) {
                    defaultVal = StringUtils.split(defaultVal, SEPERATOR)[1];
                }
                objValue = convertObjectValue(field, defaultVal);
            }
            
            setProperty(object, field, fieldKey, objValue);
        }
    }
    
    /**
     * RFC호출 결과 Structure정보 취득
     *
     * @param funcRslt
     * @param structureName
     * @param c
     * @return
     * @throws Exception
     */
    public static <T> T getExportStructure(FunctionResult funcRslt, String structureName, Class<? extends T> c) throws Exception {
        
        // 파라미터(TABLES) 추출
        JCoStructure jCoStrct = funcRslt.getExportStructure(structureName);
        
        T data = c.newInstance();
        
        MapsRfcMappperUtil.setExportStructureValue(structureName, jCoStrct, data);
        
        return data;
    }
    
    /**
     * RFC호출 결과 Table정보 취득
     *
     * @param funcRslt
     * @param tableName
     * @param c
     * @return
     * @throws Exception
     */
    public static <T> List<T> getExportTableValues(FunctionResult funcRslt, String tableName, Class<? extends T> c) throws Exception {
        
        // 파라미터(TABLES) 추출
        List<Map<String, Object>> lstData = funcRslt.getTable(tableName);

        List<T> datas = new ArrayList<>();

        int rnum = 1;
        for (Map<String, Object> tmpData : lstData) {
            
            T objData = c.newInstance();

            BeanUtils.setProperty(objData, "rnum", rnum);
            
            MapsRfcMappperUtil.setExportTableValue(tableName, tmpData, objData);
            
            datas.add(objData);
            rnum++;
        }
        
        return datas;
    }
    
    /**
     * RFC호출 결과 Table정보 취득(Paging결과)
     *
     * @param funcRslt
     * @param tableName
     * @param rfcIfCommVO
     * @param c
     * @return
     * @throws Exception
     */
    public static <T> List<T> getExportTablePaging(FunctionResult funcRslt, String tableName, MapsCommSapRfcIfCommVO rfcIfCommVO, Class<? extends T> c) throws Exception {

        // 파라미터(TABLES) 추출
        List<Map<String, Object>> lstData = funcRslt.getTable(tableName);

        List<T> datas = new ArrayList<>();

        int rcnt = 0;
        int rnum = rfcIfCommVO.getStartRow();
        for (Map<String, Object> tmpData : lstData) {
            
            T objData = c.newInstance();
            
            //if (rcnt == 0) { // 소팅후 페이징 처리를 위해서 제거
            BeanUtils.setProperty(objData, "totCnt", rfcIfCommVO.getTotCnt());
            //}
            BeanUtils.setProperty(objData, "rnum", rnum);
            
            MapsRfcMappperUtil.setExportTableValue(tableName, tmpData, objData);
            
            datas.add(objData);
            
            rcnt++;
            rnum++;
        }
        
        return datas;
    }

    /**
     * Export JCoStructure Values Setting
     *
     * @param strctName
     * @param strct
     * @param object
     * @throws Exception
     */
    public static void setExportStructureValue(String strctName, JCoStructure strct, Object object) throws Exception {
        // Load all fields in the class (private included)
        Field[] attributes = object.getClass().getDeclaredFields();
        for (Field field : attributes) {
            // Dynamically read Attribute Name
            MapsRfcMappper annotation = field.getAnnotation(MapsRfcMappper.class);
            if (annotation == null)  {
                continue;
            }
            
            if (!validateField(annotation, strctName, IPTT_SE_EXPORT)) {
                continue;
            }

            String fieldKey = annotation.fieldKey();
            int idxFieldKey = StringUtils.indexOf(fieldKey, SEPERATOR);
            if (idxFieldKey > 0) {
                fieldKey = StringUtils.split(fieldKey, SEPERATOR)[1];
            }
            //logger.debug("→ setExportStructureValue::annotation[name="+field.getName()+",fieldKey="+fieldKey+"]");
            
            field.setAccessible(true);
            
            Object objValue = strct.getValue(fieldKey);
            if (objValue == null) {
                String defaultVal = annotation.defaultVal();
                if (StringUtils.isEmpty(defaultVal)) {
                    continue;
                }
                int idxDefaultVal = StringUtils.indexOf(defaultVal, SEPERATOR);
                if (idxDefaultVal > 0) {
                    defaultVal = StringUtils.split(defaultVal, SEPERATOR)[1];
                }
                objValue = convertObjectValue(field, defaultVal);
            }
            
            setProperty(object, field, fieldKey, objValue);
        }
    }
    
    /**
     * Export Table Values Setting
     *
     * @param map
     * @param object
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public static void setExportTableValue(String tableName, Map<String, Object> map, Object object) throws Exception {
        // Load all fields in the class (private included)
        Field[] attributes = object.getClass().getDeclaredFields();
        for (Field field : attributes) {
            // Dynamically read Attribute Name
            MapsRfcMappper annotation = field.getAnnotation(MapsRfcMappper.class);
            if (annotation == null)  {
                continue;
            }
            
            if (!validateField(annotation, tableName, IPTT_SE_EXPORT)) {
                continue;
            }

            String fieldKey = annotation.fieldKey();
            int idxFieldKey = StringUtils.indexOf(fieldKey, SEPERATOR);
            if (idxFieldKey > 0) {
                fieldKey = StringUtils.split(fieldKey, SEPERATOR)[1];
            }
            //logger.debug("→ setExportTableValue::annotation[name="+field.getName()+",fieldKey="+fieldKey+"]");
            
            field.setAccessible(true);
            
            Object objValue = map.get(fieldKey);
            if (objValue == null) {
                String defaultVal = annotation.defaultVal();
                if (StringUtils.isEmpty(defaultVal)) {
                    continue;
                }
                int idxDefaultVal = StringUtils.indexOf(defaultVal, SEPERATOR);
                if (idxDefaultVal > 0) {
                    defaultVal = StringUtils.split(defaultVal, SEPERATOR)[1];
                }
                objValue = convertObjectValue(field, defaultVal);
            }
            
            setProperty(object, field, fieldKey, objValue);
        }
    }
    
    /**
     * RFC호출 결과 Table정보 취득(CRUD결과 포함) 
     *
     * @param funcRslt
     * @param tableName
     * @param c
     * @return
     * @throws Exception
     */
    public static <T> List<T> getExportTableResultValues(FunctionResult funcRslt, String tableName, Class<? extends T> c) throws Exception {

        // 파라미터(TABLES) 추출
        List<Map<String, Object>> lstData = funcRslt.getTable(tableName);

        List<T> datas = new ArrayList<>();
        
        for (Map<String, Object> tmpData : lstData) {
            
            T objData = c.newInstance();
            
            MapsRfcMappperUtil.setExportTableResultValue(tableName, tmpData, objData);
            
            datas.add(objData);
        }
        
        return datas;
    }
    
    /**
     * Export Table Values Setting(Include Processing Result Message)
     *
     * @param map
     * @param object
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public static void setExportTableResultValue(String tableName, Map<String, Object> map, Object object) throws Exception {
        
        setExportTableValue(tableName, map, object);
        
        int i = 0;
        for (String filedKey: RESULT_INFO_KEY) {
            
            Object objValue = map.get(filedKey);
            
            BeanUtils.setProperty(object, RESULT_INFO_NAME[i], objValue);
            
            i++;
        }
    }
    
    /**
     * String → Field Class 변환
     *
     * @param field
     * @param str
     * @return
     */
    public static Object convertObjectValue(Field field, String str) {

        Object objValue = null;
        
        if (field.getType() == int.class || field.getType() == Integer.class) {
            objValue = new Integer(str).intValue();
        } else if (field.getType() == Date.class) {
            objValue = DateUtil.stringToDate(str);
        } else if (field.getType() == BigDecimal.class) {
            objValue = new BigDecimal(str);
        } else {
            objValue = StringUtils.trim(str);
        }
        
        return objValue;
    }
    
    /**
     * Object를 Field 값에 셋팅
     *
     * @param field
     * @param obj
     * @param value
     * @throws Exception
     */
    public static void setProperty(Object obj, Field field, String fieldKey, Object value) throws Exception {
       
        if (field.getType() == String.class) {
            if (ArrayUtils.contains(COMM_TIME_FIELDS, fieldKey)) {
                BeanUtils.setProperty(obj, field.getName(), DateUtil.toString((Date)value, "HHmmss", MapsConstants.DFLT_LOCALE));
            } else {
                BeanUtils.setProperty(obj, field.getName(), StringUtils.trim(value.toString()));
            }
        } else if (field.getType() == byte[].class) {
            BeanUtils.copyProperty(obj, field.getName(), value);
        } else {
            BeanUtils.setProperty(obj, field.getName(), value);
        }
    }
}
