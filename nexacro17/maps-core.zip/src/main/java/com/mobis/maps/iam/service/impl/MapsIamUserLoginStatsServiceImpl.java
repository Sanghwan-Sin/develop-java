package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.service.MapsIamUserLoginStatsService;
import com.mobis.maps.iam.service.dao.MapsIamUserLoginStatsMDAO;
import com.mobis.maps.iam.util.MapsIamUtil;
import com.mobis.maps.iam.vo.MapsIamUserLoginStatsVO;

/**
 * <pre>
 * 사용자 로그인 통계 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamUserLoginStatsServiceImpl.java
 * @Description : 사용자 로그인 통계에 대한 서비스 구현.
 * @author DT048058
 * @since 2020. 5. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 7.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsIamUserLoginStatsService")
public class MapsIamUserLoginStatsServiceImpl extends HService implements MapsIamUserLoginStatsService {

    @Resource(name = "mapsIamMobisUserService")
    MapsIamMobisUserService mapsIamMobisUserService;
    
    @Resource(name="mapsIamUserLoginStatsMDAO")
    private MapsIamUserLoginStatsMDAO mapsIamUserLoginStatsMDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserLoginStatsService#selectUserLoginStatsMainList(com.mobis.maps.iam.vo.MapsIamUserLoginStatsVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserLoginStatsVO> selectUserLoginStatsMainList(MapsIamUserLoginStatsVO iamUserLoginStatsVO
            , LoginInfoVO loginInfo) throws Exception {
        
        if (!StringUtils.equals(MapsIamConstants.ORGNZT_SE_CD_MOBIS, loginInfo.getOrgnztSeCd())) {
            iamUserLoginStatsVO.setBsnOrgnztCd(loginInfo.getBsnOrgnztCd());
        }
        MapsIamUtil.addOrgnztSeCd(iamUserLoginStatsVO.getSysSeCd(), iamUserLoginStatsVO, loginInfo);
        MapsIamUtil.addOrgnztCd(iamUserLoginStatsVO, loginInfo, mapsIamMobisUserService);

        iamUserLoginStatsVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserLoginStatsVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        List<MapsIamUserLoginStatsVO> lstMain = mapsIamUserLoginStatsMDAO.selectUserLoginStatsMainList(iamUserLoginStatsVO);
        
        return lstMain;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserLoginStatsService#selectUserLoginStatsDetailList(com.mobis.maps.iam.vo.MapsIamUserLoginStatsVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserLoginStatsVO> selectUserLoginStatsDetailList(MapsIamUserLoginStatsVO iamUserLoginStatsVO
            , LoginInfoVO loginInfo) throws Exception {
        
        if (!StringUtils.equals(MapsIamConstants.ORGNZT_SE_CD_MOBIS, loginInfo.getOrgnztSeCd())) {
            iamUserLoginStatsVO.setBsnOrgnztCd(loginInfo.getBsnOrgnztCd());
        }
        MapsIamUtil.addOrgnztSeCd(iamUserLoginStatsVO.getSysSeCd(), iamUserLoginStatsVO, loginInfo);
        MapsIamUtil.addOrgnztCd(iamUserLoginStatsVO, loginInfo, mapsIamMobisUserService);
        
        List<MapsIamUserLoginStatsVO> lstDetail = mapsIamUserLoginStatsMDAO.selectUserLoginStatsDetailList(iamUserLoginStatsVO);
        
        return lstDetail;
    }

}
