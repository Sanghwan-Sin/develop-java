package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 사용자개별 메뉴 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserIndvdlzMenuVO.java
 * @Description : 사용자개별 메뉴에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 23.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserIndvdlzMenuVO extends MapsIamUserMenuVO {
    /** 권한여부 */
    private String authorYn;

    /**
     * @return the authorYn
     */
    public String getAuthorYn() {
        return authorYn;
    }
    /**
     * @param authorYn the authorYn to set
     */
    public void setAuthorYn(String authorYn) {
        this.authorYn = authorYn;
    }
}
