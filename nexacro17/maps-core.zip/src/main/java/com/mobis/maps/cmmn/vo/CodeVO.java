package com.mobis.maps.cmmn.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CodeVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 29.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class CodeVO {
    /** 코드그룹 */
    private String codeGroup;
    /** 코드그룹명 */
    private String codeGroupNm;
    /** 코드 */
    private String code;
    /** 코드명 */
    private String codeNm;
    /** 코드참고1 */
    private String codeRefer1;
    /** 코드참고2 */
    private String codeRefer2;
    /** 코드참고3 */
    private String codeRefer3;
    /** 코드참고4 */
    private String codeRefer4;
    /** 코드참고5 */
    private String codeRefer5;
    /**
     * @return the codeGroup
     */
    public String getCodeGroup() {
        return codeGroup;
    }
    /**
     * @param codeGroup the codeGroup to set
     */
    public void setCodeGroup(String codeGroup) {
        this.codeGroup = codeGroup;
    }
    /**
     * @return the codeGroupNm
     */
    public String getCodeGroupNm() {
        return codeGroupNm;
    }
    /**
     * @param codeGroupNm the codeGroupNm to set
     */
    public void setCodeGroupNm(String codeGroupNm) {
        this.codeGroupNm = codeGroupNm;
    }
    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
    /**
     * @return the codeNm
     */
    public String getCodeNm() {
        return codeNm;
    }
    /**
     * @param codeNm the codeNm to set
     */
    public void setCodeNm(String codeNm) {
        this.codeNm = codeNm;
    }
    /**
     * @return the codeRefer1
     */
    public String getCodeRefer1() {
        return codeRefer1;
    }
    /**
     * @param codeRefer1 the codeRefer1 to set
     */
    public void setCodeRefer1(String codeRefer1) {
        this.codeRefer1 = codeRefer1;
    }
    /**
     * @return the codeRefer2
     */
    public String getCodeRefer2() {
        return codeRefer2;
    }
    /**
     * @param codeRefer2 the codeRefer2 to set
     */
    public void setCodeRefer2(String codeRefer2) {
        this.codeRefer2 = codeRefer2;
    }
    /**
     * @return the codeRefer3
     */
    public String getCodeRefer3() {
        return codeRefer3;
    }
    /**
     * @param codeRefer3 the codeRefer3 to set
     */
    public void setCodeRefer3(String codeRefer3) {
        this.codeRefer3 = codeRefer3;
    }
    /**
     * @return the codeRefer4
     */
    public String getCodeRefer4() {
        return codeRefer4;
    }
    /**
     * @param codeRefer4 the codeRefer4 to set
     */
    public void setCodeRefer4(String codeRefer4) {
        this.codeRefer4 = codeRefer4;
    }
    /**
     * @return the codeRefer5
     */
    public String getCodeRefer5() {
        return codeRefer5;
    }
    /**
     * @param codeRefer5 the codeRefer5 to set
     */
    public void setCodeRefer5(String codeRefer5) {
        this.codeRefer5 = codeRefer5;
    }
}
