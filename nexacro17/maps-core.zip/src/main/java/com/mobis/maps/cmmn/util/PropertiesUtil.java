package com.mobis.maps.cmmn.util;

import java.util.Calendar;

import able.com.service.prop.PropertyService;

import org.apache.commons.lang3.StringUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.property.MapsDBProperties;
import com.mobis.maps.cmmn.spring.SpringApplicationContext;

/**
 * <pre>
 * 프로퍼티
 * </pre>
 *
 * @ClassName   : PropertiesUtil.java
 * @Description : 프로퍼티 관리.
 * @author Sin Sanghwan
 * @since 2019. 8. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 6.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class PropertiesUtil {
    
    protected final static Logger LOGGER = LoggerFactory.getLogger(PropertiesUtil.class);

    private static PropertyService properties;
    
    private static MapsDBProperties dbProperties;
    
    private static StandardPBEStringEncryptor configurationEncryptor;
    
    private static Calendar lastmodify;
    
    public static PropertyService getProperties() {
        
        if (properties == null) {
            properties = (PropertyService) SpringApplicationContext.getBean("propertiesService");
        }
        
        return properties;
    }
    
    public static MapsDBProperties getDbProperties() {
        
        if (dbProperties == null) {
            dbProperties = (MapsDBProperties) SpringApplicationContext.getBean("dbProperties");
            if (!dbProperties.isLoaded()) {
                dbProperties.load();
            }
            PropertiesUtil.lastmodify = dbProperties.getDbLastmodify();
        }
        
        return dbProperties;
    }
    
    public static StandardPBEStringEncryptor getConfigurationEncryptor() {
        
        if (configurationEncryptor == null) {
            configurationEncryptor = (StandardPBEStringEncryptor) SpringApplicationContext.getBean("configurationEncryptor");
        }
        
        return configurationEncryptor;
    }

    public static void reLoadDbProperty() {
        
        Calendar calAfter = dbProperties.getDbLastmodify();
        
        if (calAfter.compareTo(PropertiesUtil.lastmodify) > 0) {
            
            getDbProperties().clear();
            
            getDbProperties().load();

            PropertiesUtil.lastmodify = calAfter;
        }
    }

    public static boolean getBoolean(String key) {
        return getProperties().getBoolean(key);
    }
    
    public static boolean getBoolean(String key, boolean val) {
        return getProperties().getBoolean(key, val);
    }
    
    public static double getDouble(String key) {
        return getProperties().getDouble(key);
    }
    
    public static double getDouble(String key, double val) {
        return getProperties().getDouble(key, val);
    }
    
    public static float getFloat(String key) {
        return getProperties().getFloat(key);
    }
    
    public static float getFloat(String key, float val) {
        return getProperties().getFloat(key, val);
    }
    
    public static int getInt(String key) {
        return getProperties().getInt(key);
    }
    
    public static int getInt(String key, int val) {
        return getProperties().getInt(key, val);
    }
    
    public static long getLong(String key) {
        return getProperties().getLong(key);
    }
    
    public static long getLong(String key, long val) {
        return getProperties().getLong(key, val);
    }
    
    public static String getString(String key) {
        return getProperties().getString(key);
    }
    
    public static String getString(String key, String val) {
        return getProperties().getString(key, val);
    }
    
    public static String[] getStringArray(String key) {
        return getProperties().getStringArray(key);
    }
    
    public static String getDbValue(String key) {

        String value = "";
        
        Object obj = getDbProperties().get(key);
        if (obj != null) {
            value = String.valueOf(obj);
        }
        return value;
    }

    public static String getValue(String key) {
        
        String value = getDbValue(key);
        
        if (StringUtils.isBlank(value)) {
            value = getProperties().getString(key);
        }
        
        return value;
    }

    /**
     * @return the lastmodify
     */
    public static Calendar getLastmodify() {
        return lastmodify;
    }
    
    /**
     * 프로퍼티 암호화문자열 복호화
     *
     * @param encptVal
     * @return
     */
    public static String getDecrypt(String encptVal) {
        
        String decptVal = getConfigurationEncryptor().decrypt(encptVal);
        
        return decptVal;
    }
    
    /**
     * 프로퍼티 문자열 암호화
     *
     * @param val
     * @return
     */
    public static String getEncrypt(String val) {
        
        String encptVal = getConfigurationEncryptor().encrypt(val);
        
        return encptVal;
    }
 
    /**
     * MAPS 시스템 구분 코드 취득
     *
     * @return
     */
    public static String getMapsSysSeCd() {
        
        return getString("system.code");
    }
    
    /**
     * MAPS URL 취득
     *
     * @param sysSeCd
     * @return
     */
    public static String getMapsUrl(String sysSeCd) {
        if (MapsConstants.SYS_SE_CD_NMGN.equals(sysSeCd)) {
            return getString("url.nmgn");
        } else if (MapsConstants.SYS_SE_CD_SRS.equals(sysSeCd)) {
            return getString("url.srs");
        } else if (MapsConstants.SYS_SE_CD_DCS.equals(sysSeCd)) {
            return getString("url.dcs");
        } else if (MapsConstants.SYS_SE_CD_IAM.equals(sysSeCd)) {
            return getString("url.iam");
        }
        return null;
    }
}
