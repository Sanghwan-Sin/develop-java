package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 권한별 사용자 항목
 * </pre>
 *
 * @ClassName   : MapsIamAuthorUserVO.java
 * @Description : 권한별 사용자에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 12.     DT048058     	최초 생성
 * </pre>
 */
public class MapsIamAuthorUserVO extends MapsIamUserVO {
    /** 사용자권한ID */
    private String userAuthorId;
    /** 권한ID */
    private String authorId;
    /**
     * @return the userAuthorId
     */
    public String getUserAuthorId() {
        return userAuthorId;
    }
    /**
     * @param userAuthorId the userAuthorId to set
     */
    public void setUserAuthorId(String userAuthorId) {
        this.userAuthorId = userAuthorId;
    }
    /**
     * @return the authorId
     */
    public String getAuthorId() {
        return authorId;
    }
    /**
     * @param authorId the authorId to set
     */
    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }
}
