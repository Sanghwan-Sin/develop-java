package com.mobis.maps.iam.util;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.util.MapsCommExcelUtil;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.vo.MapsIamAuthorExcelUpldVO;
import com.mobis.maps.iam.vo.MapsIamAuthorMenuVO;
import com.mobis.maps.iam.vo.MapsIamAuthorUserVO;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;

/**
 * <pre>
 * 권한 액셀업로드 유틸리티
 * </pre>
 *
 * @ClassName   : MapsIamAuthorExcelUpldUtil.java
 * @Description : 권한 액셀업로드에 대한 유틸리티를 정의.
 * @author DT048058
 * @since 2020. 9. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 9.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamAuthorExcelUpldUtil {

    protected final static Logger logger = LoggerFactory.getLogger(MapsIamAuthorExcelUpldUtil.class);

    /** XLSX액셀파일 확장자 */
//    private static final String FILE_EXTENTION_EXCEL_XLSX = ".xlsx";
    /** 처리유형확인용(권한마스터) */
    private static final String PROCESS_TYPES_MASTER = "C|U|D";
    /** 처리유형확인용(권한마스터) */
    private static final String PROCESS_TYPES_MENU = "C|D";
    /** 처리유형확인용(권한사용자) */
    private static final String PROCESS_TYPES_USER = "C|D";

    /** 메뉴유형확인용 */
    private static final String MENU_TYPES = "M|S";
    
    /** 시트명(권한마스터) */
    private static final String SHEET_NAME_MASTER = "AUTHORITY_MST";
    /** 시트명(권한메뉴) */
    private static final String SHEET_NAME_MENU = "AUTHORITY_MENU";
    /** 시트명(권한사용자) */
    private static final String SHEET_NAME_USER = "AUTHORITY_USER";

    /** 처리시작행(권한마스터) */
    private static final int START_ROW_MASTER = 1;
    /** 처리시작행(권한메뉴) */
    private static final int START_ROW_MENU = 1;
    /** 처리시작행(권한사용자) */
    private static final int START_ROW_USER = 1;

    /** 처리종료열(권한마스터) */
    private static final short END_COL_MASTER = 10;
    /** 처리종료열(권한마스터) */
    private static final short END_COL_MENU = 6;
    /** 처리종료열(권한마스터) */
    private static final short END_COL_USER = 5;
    
    /**
     * Statements
     *
     * @param iamAuthorExcelUpldVO
     * @param loginInfo
     * @throws Exception
     */
    public static void pasing(MapsIamAuthorExcelUpldVO iamAuthorExcelUpldVO, LoginInfoVO loginInfo) throws Exception {

        File fAuthorExcel = iamAuthorExcelUpldVO.getExcelFile();
        
//        String fileNm = fAuthorExcel.getName();
//        if (StringUtils.endsWithIgnoreCase(fileNm, FILE_EXTENTION_EXCEL_XLSX)) {
//            
//        } else {
////            HSSFWorkbook wb = MapsCommExcelUtil.createWorkbookXls(file);
//            throw new MapsBizException("지원하지 않는 액셀 파일입니다.");
//        }
        
        XSSFWorkbook wb = MapsCommExcelUtil.createWorkbook(fAuthorExcel);
        
        setAuthors(wb, iamAuthorExcelUpldVO, loginInfo);

        setAuthorMenus(wb, iamAuthorExcelUpldVO, loginInfo);
        
        setAuthorUsers(wb, iamAuthorExcelUpldVO, loginInfo);
    }
    

    public static String getErrorString(List<String> errMsgs) {
        
        StringBuilder sbErrMsg = new StringBuilder();

        for (String errMsg: errMsgs) {
            if (sbErrMsg.length() > 0) {
                sbErrMsg.append("\n\r");
            }
            sbErrMsg.append(errMsg);
        }
        
        return sbErrMsg.toString();
    }
    
    /**
     * Statements
     *
     * @param wb
     * @param iamAuthorExcelUpldVO
     * @throws Exception
     */
    private static void setAuthors(XSSFWorkbook wb, MapsIamAuthorExcelUpldVO iamAuthorExcelUpldVO, LoginInfoVO loginInfo) throws Exception {

        List<MapsIamAuthorVO> authors = new ArrayList<MapsIamAuthorVO>();

        XSSFSheet sheet = wb.getSheet(SHEET_NAME_MASTER);
        
        int lastRowNum = sheet.getLastRowNum();
        if (lastRowNum < 0) {
            return;
        }

        boolean isError = false;
        Map<String, Integer> mChkAuthorId = new HashMap<String, Integer>();
        int rowCnt = 0;
        for (int i = START_ROW_MASTER; i <= lastRowNum; i++) {
            
            XSSFRow row = sheet.getRow(i);
            if (row == null) {
                continue;
            }

            /* 권한마스터 정보 취득 및 설정 */
            MapsIamAuthorVO authorVO = new MapsIamAuthorVO();
            authorVO.setRnum(i);
            for (short c = 0; c < END_COL_MASTER; c++) {
                
                XSSFCell cell = row.getCell(c);
                if (cell == null) {
                    continue;
                }

                switch (c) {
                    case 1 :
                        authorVO.setProcTy(cell.getRichStringCellValue().getString());
                        break;
                    case 2 :
                        authorVO.setAuthorId(cell.getStringCellValue());
                        break;
                    case 4 :
                        authorVO.setSysSeCd(cell.getRichStringCellValue().getString());
                        break;
                    case 6 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        authorVO.setBsnOrgnztCd(cell.getRichStringCellValue().getString());
                        break;
                    case 7 :
                        authorVO.setAuthorNm(cell.getStringCellValue());
                        break;
                    case 8 :
                        authorVO.setAuthorDc(cell.getStringCellValue());
                        break;
                    case 9 :
                        authorVO.setUseYn(cell.getStringCellValue());
                        break;
                    default:
                        continue;
                }
            }
            
            /* 권한마스터 정합성체크 */
            List<String> errors = new ArrayList<String>();
            String procTy = authorVO.getProcTy();
            String authorId = authorVO.getAuthorId();

            if (StringUtils.isBlank(procTy) || !procTy.matches(PROCESS_TYPES_MASTER)) {
                // 처리유형 은 유효하지 않은 값입니다.
                errors.add(MapsIamValidatorUtil.getMessageByWordId("EC00000011", "WI000000296", loginInfo.getUserLcale()));
            } else {
                MapsIamValidatorUtil.setRowType(authorVO);
            }
            if (StringUtils.isBlank(authorId)) {
                // 권한ID는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000048", loginInfo.getUserLcale()));
                authorId = "BLANK".concat(String.valueOf(i));
            } else {
                Integer iChkRow = mChkAuthorId.get(authorId);
                if (iChkRow != null) {
                    errors.add(iChkRow.intValue() + "행에 이미 입력한 권한ID입니다.");
                } else {
                    mChkAuthorId.put(authorId, new Integer(i));
                }
            }
            if (StringUtils.isBlank(authorVO.getSysSeCd())) {
                // 시스템은 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("W0000000070", loginInfo.getUserLcale()));
            }
            if (StringUtils.isBlank(authorVO.getBsnOrgnztCd())) {
                // 모비스법인은 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000237", loginInfo.getUserLcale()));
            }
            if (StringUtils.isBlank(authorVO.getAuthorNm())) {
                // 권한명은 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000049", loginInfo.getUserLcale()));
            }
            if (StringUtils.isBlank(authorVO.getUseYn())) {
                // 사용여부는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("W0000000041", loginInfo.getUserLcale()));
            }
            // 권한마스터정보 애러내용 추가
            if (errors.isEmpty()) {
                authorVO.setMsgTy(MapsConstants.MESSAGE_TYPE_SUCCESS);
                // 권한마스터 매핑 정보 추가
                iamAuthorExcelUpldVO.addAuthorIdMapngRow(rowCnt, authorId);
                rowCnt++;
            } else {
                authorVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                authorVO.setMsg(getErrorString(errors));
                isError = true;
            }

            // 권한마스터정보 추가
            authors.add(authorVO);
        }
        iamAuthorExcelUpldVO.setAuthors(authors);
        
        if (isError) {
            iamAuthorExcelUpldVO.addError("권한마스터 액셀업로드 처리중 오류가 발생했습니다.");
        }
    }

    /**
     * Statements
     *
     * @param wb
     * @param iamAuthorParserInfoVO
     * @throws Exception
     */
    private static void setAuthorMenus(XSSFWorkbook wb, MapsIamAuthorExcelUpldVO iamAuthorExcelUpldVO, LoginInfoVO loginInfo) throws Exception {

        XSSFSheet sheet = wb.getSheet(SHEET_NAME_MENU);
        
        int lastRowNum = sheet.getLastRowNum();
        if (lastRowNum < 0) {
            return;
        }

        boolean isError = false;
        for (int i = START_ROW_MENU; i <= lastRowNum; i++) {
            
            XSSFRow row = sheet.getRow(i);
            if (row == null) {
                continue;
            }

            /* 권한메뉴 정보 취득 및 설정 */
            MapsIamAuthorMenuVO iamAuthorMenuVO = new MapsIamAuthorMenuVO();
            iamAuthorMenuVO.setRnum(i);
            for (short c = 0; c < END_COL_MENU; c++) {
                
                XSSFCell cell = row.getCell(c);
                if (cell == null) {
                    continue;
                }

                switch (c) {
                    case 1 :
                        iamAuthorMenuVO.setProcTy(cell.getRichStringCellValue().getString());
                        break;
                    case 2 :
                        iamAuthorMenuVO.setAuthorId(cell.getStringCellValue());
                        break;
                    case 3 :
                        iamAuthorMenuVO.setMenuId(cell.getStringCellValue());
                        break;
                    case 5 :
                        iamAuthorMenuVO.setMenuTyCd(cell.getRichStringCellValue().getString());
                        break;
                    default:
                        continue;
                }
            }
            
            /* 권한메뉴 정합성체크 */
            List<String> errors = new ArrayList<String>();
            String procTy = iamAuthorMenuVO.getProcTy();
            String authorId = iamAuthorMenuVO.getAuthorId();

            if (StringUtils.isBlank(procTy) || !procTy.matches(PROCESS_TYPES_MENU)) {
                // 처리유형 은 유효하지 않은 값입니다.
                errors.add(MapsIamValidatorUtil.getMessageByWordId("EC00000011", "WI000000296", loginInfo.getUserLcale()));
            } else {
                MapsIamValidatorUtil.setRowType(iamAuthorMenuVO);
            }
            if (StringUtils.isBlank(authorId)) {
                // 권한ID는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000048", loginInfo.getUserLcale()));
                authorId = "BLANK";
            }
            if (StringUtils.isBlank(iamAuthorMenuVO.getMenuId())) {
                // 시스템은 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("W0000000070", loginInfo.getUserLcale()));
            }
            if (StringUtils.isBlank(iamAuthorMenuVO.getMenuTyCd())) {
                // 메뉴유형은 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000055", loginInfo.getUserLcale()));
            } else {
                if (!iamAuthorMenuVO.getMenuTyCd().matches(MENU_TYPES)) {
                    // 메뉴유형 은 유효하지 않은 값입니다.
                    errors.add(MapsIamValidatorUtil.getMessageByWordId("EC00000011", "WI000000055", loginInfo.getUserLcale()));
                }
                if (StringUtils.equals(iamAuthorMenuVO.getMenuTyCd(), MapsIamConstants.MENU_TYPE_CD_SCREEN)) {
                    iamAuthorMenuVO.setScrinId(iamAuthorMenuVO.getMenuId());
                }
            }
            // 권한메뉴정보 애러내용 추가
            if (errors.isEmpty()) {
                iamAuthorMenuVO.setMsgTy(MapsConstants.MESSAGE_TYPE_SUCCESS);
            } else {
                iamAuthorMenuVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                iamAuthorMenuVO.setMsg(getErrorString(errors));
                isError = true;
            }

            // 권한메뉴정보 추가
            iamAuthorExcelUpldVO.addAuthorMenu(authorId, iamAuthorMenuVO);
        }
        
        if (isError) {
            iamAuthorExcelUpldVO.addError("권한메뉴 액셀업로드 처리중 오류가 발생했습니다.");
        }
        
    }

    /**
     * Statements
     *
     * @param wb
     * @param iamAuthorParserInfoVO
     * @throws Exception
     */
    private static void setAuthorUsers(XSSFWorkbook wb, MapsIamAuthorExcelUpldVO iamAuthorExcelUpldVO, LoginInfoVO loginInfo) throws Exception {

        XSSFSheet sheet = wb.getSheet(SHEET_NAME_USER);
        
        int lastRowNum = sheet.getLastRowNum();
        if (lastRowNum < 0) {
            return;
        }

        boolean isError = false;
        for (int i = START_ROW_USER; i <= lastRowNum; i++) {
            
            XSSFRow row = sheet.getRow(i);
            if (row == null) {
                continue;
            }

            /* 권한사용자 정보 취득 및 설정 */
            MapsIamAuthorUserVO iamAuthorUserVO = new MapsIamAuthorUserVO();
            iamAuthorUserVO.setRnum(i);
            for (short c = 0; c < END_COL_USER; c++) {
                
                XSSFCell cell = row.getCell(c);
                if (cell == null) {
                    continue;
                }

                switch (c) {
                    case 1 :
                        iamAuthorUserVO.setProcTy(cell.getRichStringCellValue().getString());
                        break;
                    case 2 :
                        iamAuthorUserVO.setUserAuthorId(cell.getStringCellValue());
                        break;
                    case 3 :
                        iamAuthorUserVO.setAuthorId(cell.getStringCellValue());
                        break;
                    case 4 :
                        iamAuthorUserVO.setUserSeqId(cell.getStringCellValue());
                        break;
                    default:
                        continue;
                }
            }
            
            /* 권한사용자 정합성체크 */
            List<String> errors = new ArrayList<String>();
            String authorId = iamAuthorUserVO.getAuthorId();
            String procTy = iamAuthorUserVO.getProcTy();

            if (StringUtils.isBlank(procTy) || !procTy.matches(PROCESS_TYPES_USER)) {
                // 처리유형 은 유효하지 않은 값입니다.
                errors.add(MapsIamValidatorUtil.getMessageByWordId("EC00000011", "WI000000296", loginInfo.getUserLcale()));
            } else {
                MapsIamValidatorUtil.setRowType(iamAuthorUserVO);
            }
            if (StringUtils.isBlank(iamAuthorUserVO.getUserAuthorId())) {
                // 사용자권한ID는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000298", loginInfo.getUserLcale()));
            }
            if (StringUtils.isBlank(authorId)) {
                // 권한ID는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000048", loginInfo.getUserLcale()));
                authorId = "BLANK";
            }
            if (StringUtils.isBlank(iamAuthorUserVO.getUserSeqId())) {
                // 계정ID는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("W0000003561", loginInfo.getUserLcale()));
            }
            // 권한사용자정보 애러내용 추가
            if (errors.isEmpty()) {
                iamAuthorUserVO.setMsgTy(MapsConstants.MESSAGE_TYPE_SUCCESS);
            } else {
                iamAuthorUserVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                iamAuthorUserVO.setMsg(getErrorString(errors));
                isError = true;
            }

            // 권한사용자정보 추가
            iamAuthorExcelUpldVO.addAuthorUser(authorId, iamAuthorUserVO);
        }
        
        if (isError) {
            iamAuthorExcelUpldVO.addError("권한사용자 액셀업로드 처리중 오류가 발생했습니다.");
        }
        
    }
}
