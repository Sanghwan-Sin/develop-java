package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * 사용자 화면 접속 통계 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinConectStatsVO.java
 * @Description : 사용자 화면 접속 통계에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 5. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 7.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserScrinStatsVO extends MapsIamCommVO {
    /* 조회조건 */
    /** 시작일자 */
    private Date strtDt;
    /** 종료일자 */
    private Date endDt;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 조직구분코드 */
    private String orgnztSeCd;
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 조직코드 */
    private String orgnztCd;
    /* 사용자 화면 접속 통계 */
    /** 조직코드 */
    private String orgnztNm;
    /** 사용자ID */
    private String userId;
    /** 사용자명 */
    private String userNm;
    /** 화면ID */
    private String scrinId;
    /** 화면코드 */
    private String scrinCd;
    /** 화면명 */
    private String scrinNm;
    /** 접속일시 */
    private Date conectDt;
    /** 접속건수 */
    private int conectCnt;
    /**
     * @return the strtDt
     */
    public Date getStrtDt() {
        return strtDt;
    }
    /**
     * @param strtDt the strtDt to set
     */
    public void setStrtDt(Date strtDt) {
        this.strtDt = strtDt;
    }
    /**
     * @return the endDt
     */
    public Date getEndDt() {
        return endDt;
    }
    /**
     * @param endDt the endDt to set
     */
    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the orgnztSeCd
     */
    public String getOrgnztSeCd() {
        return orgnztSeCd;
    }
    /**
     * @param orgnztSeCd the orgnztSeCd to set
     */
    public void setOrgnztSeCd(String orgnztSeCd) {
        this.orgnztSeCd = orgnztSeCd;
    }
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the orgnztCd
     */
    public String getOrgnztCd() {
        return orgnztCd;
    }
    /**
     * @param orgnztCd the orgnztCd to set
     */
    public void setOrgnztCd(String orgnztCd) {
        this.orgnztCd = orgnztCd;
    }
    /**
     * @return the orgnztNm
     */
    public String getOrgnztNm() {
        return orgnztNm;
    }
    /**
     * @param orgnztNm the orgnztNm to set
     */
    public void setOrgnztNm(String orgnztNm) {
        this.orgnztNm = orgnztNm;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userNm
     */
    public String getUserNm() {
        return userNm;
    }
    /**
     * @param userNm the userNm to set
     */
    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the scrinCd
     */
    public String getScrinCd() {
        return scrinCd;
    }
    /**
     * @param scrinCd the scrinCd to set
     */
    public void setScrinCd(String scrinCd) {
        this.scrinCd = scrinCd;
    }
    /**
     * @return the scrinNm
     */
    public String getScrinNm() {
        return scrinNm;
    }
    /**
     * @param scrinNm the scrinNm to set
     */
    public void setScrinNm(String scrinNm) {
        this.scrinNm = scrinNm;
    }
    /**
     * @return the conectDt
     */
    public Date getConectDt() {
        return conectDt;
    }
    /**
     * @param conectDt the conectDt to set
     */
    public void setConectDt(Date conectDt) {
        this.conectDt = conectDt;
    }
    /**
     * @return the conectCnt
     */
    public int getConectCnt() {
        return conectCnt;
    }
    /**
     * @param conectCnt the conectCnt to set
     */
    public void setConectCnt(int conectCnt) {
        this.conectCnt = conectCnt;
    }

}
