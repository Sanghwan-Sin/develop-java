package com.mobis.maps.sapjco.manager;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class DestinationConfig {
    
    String poolCapacity;
    String peakLimit;
    String mshost;
    String msserv;
    String ashost;
    String gwhost;
    String gwserv;
    String sysnr;
    String r3name;
    String group;
    String client;
    String user;
    String passwd;
    String lang;
    
    public String getToString() {
        /*
        StringBuilder sb = new StringBuilder();
        sb.append("[poolCapacity=" + poolCapacity);
        sb.append(",peakLimit=" + peakLimit);
        sb.append(",mshost=" + mshost);
        sb.append(",msserv=" + msserv);
        sb.append(",ashost=" + ashost);
        sb.append(",gwhost=" + gwhost);
        sb.append(",gwserv=" + gwserv);
        sb.append(",sysnr=" + sysnr);
        sb.append(",r3name=" + r3name);
        sb.append(",group=" + group);
        sb.append(",client=" + client);
        sb.append(",user=" + user);
        sb.append(",passwd=" + passwd);
        sb.append(",lang=" + lang);
        //return sb.toString();
         
         */
        return ToStringBuilder.reflectionToString(this, ToStringStyle.DEFAULT_STYLE);
    }
    /**
     * @return the poolCapacity
     */
    public String getPoolCapacity() {
        return poolCapacity;
    }
    /**
     * @param poolCapacity the poolCapacity to set
     */
    public void setPoolCapacity(String poolCapacity) {
        this.poolCapacity = poolCapacity;
    }
    /**
     * @return the peakLimit
     */
    public String getPeakLimit() {
        return peakLimit;
    }
    /**
     * @param peakLimit the peakLimit to set
     */
    public void setPeakLimit(String peakLimit) {
        this.peakLimit = peakLimit;
    }
    /**
     * @return the mshost
     */
    public String getMshost() {
        return mshost;
    }
    /**
     * @param mshost the mshost to set
     */
    public void setMshost(String mshost) {
        this.mshost = mshost;
    }
    /**
     * @return the msserv
     */
    public String getMsserv() {
        return msserv;
    }
    /**
     * @param msserv the msserv to set
     */
    public void setMsserv(String msserv) {
        this.msserv = msserv;
    }
    /**
     * @return the ashost
     */
    public String getAshost() {
        return ashost;
    }
    /**
     * @param ashost the ashost to set
     */
    public void setAshost(String ashost) {
        this.ashost = ashost;
    }
    /**
     * @return the gwhost
     */
    public String getGwhost() {
        return gwhost;
    }
    /**
     * @param gwhost the gwhost to set
     */
    public void setGwhost(String gwhost) {
        this.gwhost = gwhost;
    }
    /**
     * @return the gwserv
     */
    public String getGwserv() {
        return gwserv;
    }
    /**
     * @param gwserv the gwserv to set
     */
    public void setGwserv(String gwserv) {
        this.gwserv = gwserv;
    }
    /**
     * @return the sysnr
     */
    public String getSysnr() {
        return sysnr;
    }
    /**
     * @param sysnr the sysnr to set
     */
    public void setSysnr(String sysnr) {
        this.sysnr = sysnr;
    }
    /**
     * @return the r3name
     */
    public String getR3name() {
        return r3name;
    }
    /**
     * @param r3name the r3name to set
     */
    public void setR3name(String r3name) {
        this.r3name = r3name;
    }
    /**
     * @return the group
     */
    public String getGroup() {
        return group;
    }
    /**
     * @param group the group to set
     */
    public void setGroup(String group) {
        this.group = group;
    }
    /**
     * @return the client
     */
    public String getClient() {
        return client;
    }
    /**
     * @param client the client to set
     */
    public void setClient(String client) {
        this.client = client;
    }
    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }
    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }
    /**
     * @return the passwd
     */
    public String getPasswd() {
        return passwd;
    }
    /**
     * @param passwd the passwd to set
     */
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }
    /**
     * @return the lang
     */
    public String getLang() {
        return lang;
    }
    /**
     * @param lang the lang to set
     */
    public void setLang(String lang) {
        this.lang = lang;
    }
    
}