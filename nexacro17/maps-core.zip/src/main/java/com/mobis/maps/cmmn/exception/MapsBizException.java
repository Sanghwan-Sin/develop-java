package com.mobis.maps.cmmn.exception;

import java.util.Locale;

import able.com.exception.BizException;

import org.springframework.context.MessageSource;

/**
 * <pre>
 * 업무예외처리
 * </pre>
 *
 * @ClassName   : ValidatorException.java
 * @Description : 업무에 대한 예외처리.
 * @author Sin Sanghwan
 * @since 2019. 9. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 10.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class MapsBizException extends BizException {

    /** (long)serialVersionUID */
    private static final long serialVersionUID = 3967397406565710989L;
    
    public MapsBizException() {
        super();
    }

    public MapsBizException(MessageSource messageSource
            , String messageKey
            , Exception wrappedException) {
        super(messageSource, messageKey, wrappedException);
    }

    public MapsBizException(MessageSource messageSource
            , String messageKey
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, locale, wrappedException);
    }

    public MapsBizException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, wrappedException);
    }

    public MapsBizException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, locale, wrappedException);
    }

    public MapsBizException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , String defaultMessage
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, wrappedException);
    }

    public MapsBizException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , String defaultMessage
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, locale, wrappedException);
    }

    public MapsBizException(MessageSource messageSource
            , String messageKey) {
        super(messageSource, messageKey);
    }

    public MapsBizException(String defaultMessage
            , Exception wrappedException) {
        super(defaultMessage, wrappedException);
    }

    public MapsBizException(String defaultMessage
            , Object[] messageParameters
            , Exception wrappedException) {
        super(defaultMessage, messageParameters, wrappedException);
    }

    public MapsBizException(String defaultMessage) {
        super(defaultMessage);
    }
}
