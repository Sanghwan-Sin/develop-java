package com.mobis.maps.cmmn.constants;

/**
 * <pre>
 * Excel 의 종류를 enum 으로 정의
 * XLS  = 오피스 2007 이전 버전
 * XLSX = 오피스 2007 이후 버전
 * </pre>
 *
 * @ClassName   : ExcelType.java
 * @Description : Excel 의 종류를 enum 으로 정의
 * @author Sin Sanghwan
 * @since 2019. 8. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 6.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public enum ExcelType {

    NULL
    , XLS
    , XLSX
}
