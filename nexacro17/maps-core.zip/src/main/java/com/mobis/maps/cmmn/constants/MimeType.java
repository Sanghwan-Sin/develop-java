package com.mobis.maps.cmmn.constants;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MimeType.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 27.     DT048058     	최초 생성
 * </pre>
 */

public enum MimeType {
//      aac("audio/aac", "AAC 오디오 파일")
//    , abw("application/x-abiword", "AbiWord 문서")
//    , arc("application/octet-stream", "아카이브 문서 (인코딩된 다중 파일)")
//    , avi("video/x-msvideo", "AVI: Audio Video Interleave")
//    , azw("application/vnd.amazon.ebook", "아마존 킨들 전자책 포맷")
//    , bin("application/octet-stream", "모든 종류의 이진 데이터")
//    , bz("application/x-bzip", "BZip 아카이브")
//    , bz2("application/x-bzip2", "BZip2 아카이브")
//    , csh("application/x-csh", "C-Shell 스크립트")
//    , css("text/css", "Cascading Style Sheets (CSS)")
      csv("text/csv", "Comma-separated values (CSV)")
    , doc("application/msword", "Microsoft Word")
    , dot("application/msword", "Microsoft Word")
    , docx("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "Microsoft Word")
    , dotx("application/vnd.openxmlformats-officedocument.wordprocessingml.template", "Microsoft Word")
    , docm("application/vnd.ms-word.document.macroEnabled.12", "Microsoft Word")
    , dotm("application/vnd.ms-word.template.macroEnabled.12", "Microsoft Word")
//    , epub("application/epub+zip", "Electronic publication (EPUB)")
    , gif("image/gif", "Graphics Interchange Format (GIF)")
//    , htm("text/html", "HyperText Markup Language (HTML)")
//    , html("text/html", "HyperText Markup Language (HTML)")
//    , ico("image/x-icon", "Icon 포맷")
//    , ics("text/calendar", "iCalendar 포맷")
//    , jar("application/java-archive", "Java 아카이브 (JAR)")
    , jpeg("image/jpeg", "JPEG 이미지")
    , jpg("image/jpeg", "JPEG 이미지")
//    , js("application/js", "JavaScript (ECMAScript)")
//    , json("application/json", "JSON 포맷")
//    , mdb("application/vnd.ms-access", "Microsoft Access")
//    , mid("audio/midi", "Musical Instrument Digital Interface (MIDI)")
//    , midi("audio/midi", "Musical Instrument Digital Interface (MIDI)")
//    , mpeg("video/mpeg", "MPEG 비디오")
//    , mpkg("application/vnd.apple.installer+xml", "Apple Installer Package")
//    , odp("application/vnd.oasis.opendocument.presentation", "OpenDocuemnt 프리젠테이션 문서")
//    , ods("application/vnd.oasis.opendocument.spreadsheet", "OpenDocuemnt 스프레드시트 문서")
//    , odt("application/vnd.oasis.opendocument.text", "OpenDocument 텍스트 문서")
//    , oga("audio/ogg", "OGG 오디오")
//    , ogv("video/ogg", "OGG 비디오")
//    , ogx("application/ogg", "OGG")
    , pdf("application/pdf", "Adobe Portable Document Format (PDF)")
    , png("image/png", "PNG 이미지")
    , ppt("application/vnd.ms-powerpoint", "Microsoft PowerPoint")
    , pot("application/vnd.ms-powerpoint", "Microsoft PowerPoint")
    , pps("application/vnd.ms-powerpoint", "Microsoft PowerPoint")
    , ppa("application/vnd.ms-powerpoint", "Microsoft PowerPoint")
    , pptx("application/vnd.openxmlformats-officedocument.presentationml.presentation", "Microsoft PowerPoint")
    , potx("application/vnd.openxmlformats-officedocument.presentationml.template", "Microsoft PowerPoint")
    , ppsx("application/vnd.openxmlformats-officedocument.presentationml.slideshow", "Microsoft PowerPoint")
    , ppam("application/vnd.ms-powerpoint.addin.macroEnabled.12", "Microsoft PowerPoint")
    , pptm("application/vnd.ms-powerpoint.presentation.macroEnabled.12", "Microsoft PowerPoint")
    , potm("application/vnd.ms-powerpoint.template.macroEnabled.12", "Microsoft PowerPoint")
    , ppsm("application/vnd.ms-powerpoint.slideshow.macroEnabled.12", "Microsoft PowerPoint")
    , rar("application/x-rar-compressed", "RAR 아카이브")
//    , rtf("application/rtf", "Rich Text Format (RTF)")
//    , sh("application/x-sh", "Bourne 쉘 스크립트")
    , svg("image/svg+xml", "Scalable Vector Graphics (SVG)")
//    , swf("application/x-shockwave-flash", "Small web format (SWF)혹은 Adobe Flash document")
    , tar("application/x-tar", "Tape Archive (TAR)")
//    , tif("image/tiff", "Tagged Image File Format (TIFF)")
//    , tiff("image/tiff", "Tagged Image File Format (TIFF)")
//    , ttf("application/x-font-ttf", "TrueType Font")
//    , vsd("application/vnd.visio", "Microsft Visio")
    , wav("audio/x-wav", "Waveform Audio Format")
//    , weba("audio/webm", "WEBM 오디오")
//    , webm("video/webm", "WEBM 비디오")
//    , webp("image/webp", "WEBP 이미지")
//    , woff("application/x-font-woff", "Web Open Font Format (WOFF)")
//    , xhtml("application/xhtml+xml", "XHTML")
    , xls("application/vnd.ms-excel", "Microsoft Excel")
    , xlt("application/vnd.ms-excel", "Microsoft Excel")
    , xla("application/vnd.ms-excel", "Microsoft Excel")
    , xlsx("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Microsoft Excel")
    , xltx("application/vnd.openxmlformats-officedocument.spreadsheetml.template", "Microsoft Excel")
    , xlsm("application/vnd.ms-excel.sheet.macroEnabled.12", "Microsoft Excel")
    , xltm("application/vnd.ms-excel.template.macroEnabled.12", "Microsoft Excel")
    , xlam("application/vnd.ms-excel.addin.macroEnabled.12", "Microsoft Excel")
    , xlsb("application/vnd.ms-excel.sheet.binary.macroEnabled.12", "Microsoft Excel")
//    , xml("application/xml", "XML")
//    , xul("application/vnd.mozilla.xul+xml", "XUL")
    , zip("application/zip", "ZIP archive")
    ;

      
    private String mimeTy;
    private String desc;
      
    private MimeType(String mimeTy, String desc) {
        this.mimeTy = mimeTy;
        this.desc = desc;
    }
    
    public static MimeType get(String fileExt) {
        
        for (MimeType mimeType: values()) {
            if (StringUtils.equals(StringUtils.lowerCase(fileExt), mimeType.name())) {
                return mimeType;
            }
        }
        
        return null;
    }
    
    public static MimeType getByFileNm(String fileNm) {
        /*
        String[] fileNmInfo = StringUtils.split(fileNm, ".");
        if (fileNmInfo.length != 2) {
            return null;
        }
        */
        String ext = FilenameUtils.getExtension(fileNm);
        if(StringUtils.isEmpty(ext) ){
            return null;
        }
        
        for (MimeType mimeType: values()) {
            if (StringUtils.equals(StringUtils.lowerCase(ext), mimeType.name())) {
                return mimeType;
            }
        }
        
        return null;
    }
    
    public boolean isImage() {
        if (this == gif) {
            return true;
        } else if (this == jpeg) {
            return true;
        } else if (this == jpg) {
            return true;
        } else if (this == png) {
            return true;
        } else if (this == svg) {
            return true;
        }
        return false;
    }

    public boolean isPdf() {
        return this == pdf;
    }
    
    /**
     * @return the mimeTy
     */
    public String getMimeTy() {
        return mimeTy;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }
}
