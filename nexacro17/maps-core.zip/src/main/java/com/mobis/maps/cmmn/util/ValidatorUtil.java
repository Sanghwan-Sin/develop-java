package com.mobis.maps.cmmn.util;

import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.ValidatorException;

/**
 * <pre>
 * Validator 유틸리티
 * </pre>
 *
 * @ClassName   : ValidatorUtil.java
 * @Description : Validator에 대한 유틸리티를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 10.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class ValidatorUtil {
    
    private static Logger logger = LoggerFactory.getLogger(ValidatorUtil.class);

    /**
     * VO Validation
     *
     * @param obj
     * @param validator
     * @throws ValidatorException
     */
    public static void validate(Object obj, Validator validator) throws ValidatorException {
        validate(obj, validator, null);
    }

    /**
     * vo validate (filters에 예외처리 field값 가능버전)
     *
     * @param obj
     * @param validator
     * @param filters 예외처리 field값
     * @throws ValidatorException
     */
    public static void validate(Object obj, Validator validator, String[] filters) throws ValidatorException {

        String classNm = obj.getClass().getSimpleName();
        
        BindingResult bindingResult = new BeanPropertyBindingResult(obj, classNm);
        
        validator.validate(obj, bindingResult);
        
        if (bindingResult.hasErrors()) {

            ValidatorException validatorException = new ValidatorException(bindingResult);
            throw validatorException;
        }
    }

    /**
     *
     * VO List Validation
     *
     * @param lst
     * @param validator
     * @throws ValidatorException
     */
    public static void validate(List<?> lst, Validator validator) throws ValidatorException {
        validate(lst, validator, null);
    }

    /**
     * VO List Validation (filters에 예외처리 field값 가능버전)
     *
     * @param lst
     * @param validator
     * @param filters 예외처리 field값
     * @throws ValidatorException
     */
    public static void validate(List<?> lst, Validator validator, String[] filters) throws ValidatorException {

        
        BindingResult bindingResult = null;
        
        for (int i = 0; i < lst.size(); i++) {
            
            Object obj = lst.get(i);
            
            String classNm = obj.getClass().getSimpleName();
            
            bindingResult = new BeanPropertyBindingResult(obj, classNm);

            validator.validate(obj, bindingResult);
            
            if (bindingResult.hasErrors()) {

                ValidatorException validatorException = new ValidatorException(bindingResult);
                throw validatorException;
            }
        }
    }

    /**
     * codes arry중 filter string이 포함되었는지 검사
     *
     * @param codes
     * @param filter
     * @return
     */
    public static boolean checkFilter(String[] codes, String[] filter) {
        
        if (codes == null || codes.length == 0) {
            if (logger.isDebugEnabled()) {
                logger.debug("→ checkFilter::codes is null");
            }
            return false;
        }
        
        if (filter == null || filter.length == 0) {
            if (logger.isDebugEnabled()) {
                logger.debug("→ checkFilter::filter is null");
            }
            return false;
        }
        
        return checkRoopFilter(codes, filter);
    }

    /**
     * Statements
     *
     * @param codes
     * @param filter
     * @return
     */
    private static boolean checkRoopFilter(String[] codes, String[] filter) {
        for (int i = 0; i < codes.length; i++) {
            if (logger.isDebugEnabled()) {
                logger.debug("→ checkFilter::codes[" + i + "]="+codes[i]);
            }
            for (int j = 0; j < filter.length; j++) {
                if (i == 0 && logger.isDebugEnabled()) {
                    logger.debug("→ checkFilter::filter[" + i + "]="+filter[i]);
                }
                if (StringUtils.contains(codes[i], filter[j])) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * getErrorMessages
     *
     * @param bindingResult
     */
    public static String getErrorMessages(BindingResult bindingResult) {
        
        StringBuilder sb = new StringBuilder();

        for (ObjectError error : bindingResult.getAllErrors()) {
            
            sb.append(error.getDefaultMessage()).append("\n");
        }

        return sb.toString();
    }

    /**
     * setFirstErrorMessage
     *
     * @param e
     * @param code
     * @param args
     */
    public static void setFirstErrorMessage(ValidatorException e, String codeIn, Object[] argsIn) {
        String code = codeIn; 
        Object[] args = argsIn;
        BindingResult bindingResult = e.getBindingResult();
        int index = 0;
        for (ObjectError error : bindingResult.getAllErrors()) {
            String message = error.getDefaultMessage();
            String[] msgInfos = StringUtils.split(message, "|");
            int i = 0;
            for (String msgInfo : msgInfos) {
                if (i > 0) {
                    args = ArrayUtils.add(args, msgInfo);
                } else {
                    code = msgInfo;
                }
                i++;
            }
            if( index == 0 ){
                break;
            }
            index ++;
            
        }
        logger.error("code=" + code);
    }
    
    /**
     * getErrorMessages
     *
     * @param e
     * @param messageSource
     * @param locale
     * @return
     */
    public static String getErrorMessages(ValidatorException e, MessageSource messageSource, Locale locale) {
        
        BindingResult bindingResult = e.getBindingResult();
        
        StringBuilder sbMsg = new StringBuilder();
        for (ObjectError error : bindingResult.getAllErrors()) {
            String code = null;
            Object[] args = new Object[0];
            String message = error.getDefaultMessage();
            String[] msgInfos = StringUtils.split(message, "|");
            int i = 0;
            for (String msgInfo: msgInfos) {
                if (i > 0) {
                    args = ArrayUtils.add(args, msgInfo);
                } else {
                    code = msgInfo;
                }
                i++;
            }
            sbMsg.append(messageSource.getMessage(code, args, locale)).append("\n");
        }

        return sbMsg.toString();
    }

    /**
     * getErrorMessage
     *
     * @param e
     */
    public static String getErrorMessage(ValidatorException e, MessageSource messageSource, Locale locale) {
        
        BindingResult bindingResult = e.getBindingResult();
        String message = null;
        int index = 0 ;
        for (ObjectError error : bindingResult.getAllErrors()) {
            String msg = error.getDefaultMessage();
            String code = null;
            Object[] args = new Object[0];
            String[] msgInfos = StringUtils.split(msg, "|");
            int i = 0;
            for (String msgInfo: msgInfos) {
                if (i > 0) {
                    args = ArrayUtils.add(args, msgInfo);
                } else {
                    code = msgInfo;
                }
                i++;
            }
            message = messageSource.getMessage(code, args, locale);
            if( index == 0 ){
                break;
            }
            index ++;
        }

        return message;
    }

    /**
     * 암호 체크
     *
     * @param pwd
     * @return
     */
    public static final String PATTERN_PASSWORD = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{8,12}$";
    public static final String PATTERN_PDA_PASSWORD = "^(?=.*[A-Z])(?=.*\\d)[A-Z\\d]{8}$";
    public static boolean isUserPwd(String sysSeCd, String pwd) {

        boolean isUserPwd = false;
        Pattern p = null;
        try {
            if (StringUtils.equals(sysSeCd, MapsConstants.SYS_SE_CD_PDA)) {
                // 8자리에 대문자 1자리 이상 한자리 숫자 한자리이상
                p = Pattern.compile(PATTERN_PDA_PASSWORD);
            } else {
                //1. 가장 많이 사용되는 최소 8자리에 숫자, 문자, 특수문자 각각 1개 이상 포함
                p = Pattern.compile(PATTERN_PASSWORD);
                //2. 최소 8자리에 대문자 1자리 소문자 한자리 숫자 한자리
                //p = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,12}$");
                //3. 최소 8자리에 대문자 1자리 소문자 1자리 숫자 1자리 특수문자 1자리
                //p = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,12}$");
            }
            Matcher m = p.matcher(pwd);
            isUserPwd = m.matches();
        } catch (Exception e) {
            isUserPwd = false;
        }
        
        return isUserPwd;
    }

    /**
     * E-mail 체크
     *
     * @param email
     * @return
     */
    public static final String PATTERN_EMAIL = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    public static boolean isEmail(String email) {

        boolean isEmail = false;
        try {
            Pattern p = Pattern.compile(PATTERN_EMAIL);
            Matcher m = p.matcher(email);
            isEmail = m.matches();
        } catch (Exception e) {
            isEmail = false;
        }
        
        return isEmail;
    }
    
    /**
     * IP주소 체크
     *
     * @param ipAdres
     * @return
     */
    public static final String PATTERN_IP_ADDRESS = "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$";
    public static boolean isIpAdres(String ipAdres) {

        boolean isIpAdres = false;
        try {
            Pattern p = Pattern.compile(PATTERN_IP_ADDRESS);
            Matcher m = p.matcher(ipAdres);
            isIpAdres = m.matches();
        } catch (Exception e) {
            isIpAdres = false;
        }
        
        return isIpAdres;
    }
}
