package com.mobis.maps.comm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.comm.service.MapsCommAuthenticService;
import com.mobis.maps.comm.service.dao.MapsCommAuthenticMDAO;
import com.mobis.maps.comm.vo.MapsCommAuthenticVO;

/**
 * <pre>
 * MAPS인증(화면, URL) 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommAuthenticServiceImpl.java
 * @Description : MAPS인증(화면, URL)에 대한 서비스를 구현.
 * @author DT048058
 * @since 2020. 7. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 21.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsCommAuthenticService")
public class MapsCommAuthenticServiceImpl extends HService implements MapsCommAuthenticService {

    @Resource(name="mapsCommAuthenticMDAO")
    private MapsCommAuthenticMDAO mapsCommAuthenticMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommAuthenticService#selectScrinInfo(com.mobis.maps.comm.vo.MapsCommAuthenticVO)
     */
    @Override
    public MapsCommAuthenticVO selectScrinInfo(MapsCommAuthenticVO commAuthenticVO) throws Exception {

        MapsCommAuthenticVO scrinInfo = mapsCommAuthenticMDAO.selectScrinInfo(commAuthenticVO);
        
        return scrinInfo;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommAuthenticService#selectAuthenticScrin(com.mobis.maps.comm.vo.MapsCommAuthenticVO)
     */
    @Override
    public List<MapsCommAuthenticVO> selectAuthenticScrin(MapsCommAuthenticVO commAuthenticVO) throws Exception {
        
        List<MapsCommAuthenticVO> lstScrin = mapsCommAuthenticMDAO.selectAuthenticScrin(commAuthenticVO);
        
        return lstScrin;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommAuthenticService#selectAuthenticPopupScrin(com.mobis.maps.comm.vo.MapsCommAuthenticVO)
     */
    @Override
    public List<MapsCommAuthenticVO> selectAuthenticPopupScrin(MapsCommAuthenticVO commAuthenticVO) throws Exception {
        
        List<MapsCommAuthenticVO> lstPopupScrin = mapsCommAuthenticMDAO.selectAuthenticPopupScrin(commAuthenticVO);
        
        return lstPopupScrin;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommAuthenticService#selecttNlognAuthenticPopupScrin(com.mobis.maps.comm.vo.MapsCommAuthenticVO)
     */
    @Override
    public List<MapsCommAuthenticVO> selecttNlognAuthenticPopupScrin(MapsCommAuthenticVO commAuthenticVO) throws Exception {
        
        List<MapsCommAuthenticVO> lstPopupScrin = mapsCommAuthenticMDAO.selectNlognAuthenticPopupScrin(commAuthenticVO);
        
        return lstPopupScrin;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommAuthenticService#selectAuthenticSvcUrl(com.mobis.maps.comm.vo.MapsCommAuthenticVO)
     */
    @Override
    public List<MapsCommAuthenticVO> selectAuthenticSvcUrl(MapsCommAuthenticVO commAuthenticVO) throws Exception {
        
        List<MapsCommAuthenticVO> lstSvcUrl = mapsCommAuthenticMDAO.selectAuthenticSvcUrl(commAuthenticVO);
        
        return lstSvcUrl;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommAuthenticService#selectNlognAuthenticSvcUrl(com.mobis.maps.comm.vo.MapsCommAuthenticVO)
     */
    @Override
    public List<MapsCommAuthenticVO> selectNlognAuthenticSvcUrl(MapsCommAuthenticVO commAuthenticVO) throws Exception {
        
        List<MapsCommAuthenticVO> lstSvcUrl = mapsCommAuthenticMDAO.selectNlognAuthenticSvcUrl(commAuthenticVO);
        
        return lstSvcUrl;
    }

}
