package com.mobis.maps.comm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;

/**
 * <pre>
 * SAP 첨부파일합계2 항목
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcFileSum2VO.java
 * @Description : SAP 첨부파일합계2에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 3.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommSapAtchFileCntVO extends MapsCommSapRfcIfCommVO {
    /** File Server ID */
    @MapsRfcMappper( targetName="P|IT_ATTACH_SUM", ipttSe="I|E", fieldKey="I_FSCODE|FSCODE" )
    private String fscode;
    /** Reference Number */
    @MapsRfcMappper( targetName="I_REF_NO_T|IT_ATTACH_SUM", ipttSe="I|E", fieldKey="REF_NO|REF_NO" )
    private String refNo;
    /** File Sum */
    @MapsRfcMappper( targetName="IT_ATTACH_SUM", ipttSe="E", fieldKey="REF_NO_SUM" )
    private Integer refNoSum;
    /** File ID */
    @MapsRfcMappper( targetName="IT_ATTACH_SUM", ipttSe="E", fieldKey="FILE_SEQNO" )
    private String fileSeqno;
    /** File Name */
    @MapsRfcMappper( targetName="IT_ATTACH_SUM", ipttSe="E", fieldKey="FILE_NAME" )
    private String fileName;
    /** File Extension */
    @MapsRfcMappper( targetName="IT_ATTACH_SUM", ipttSe="E", fieldKey="FILE_EXT" )
    private String fileExt;
    /** File Length (Byte) */
    @MapsRfcMappper( targetName="IT_ATTACH_SUM", ipttSe="E", fieldKey="FILE_LEN" )
    private Integer fileLen;
    /** File Length(KB) - Char20 */
    @MapsRfcMappper( targetName="IT_ATTACH_SUM", ipttSe="E", fieldKey="FILE_LEN_KB" )
    private String fileLenKb;
    /** Size(KB) */
    @MapsRfcMappper( targetName="IT_ATTACH_SUM", ipttSe="E", fieldKey="FILE_LEN_KB_INT" )
    private Integer fileLenKbInt;
    /** File Length(MB) - Char20 */
    @MapsRfcMappper( targetName="IT_ATTACH_SUM", ipttSe="E", fieldKey="FILE_LEN_MB" )
    private String fileLenMb;
    /** Size(MB) */
    @MapsRfcMappper( targetName="IT_ATTACH_SUM", ipttSe="E", fieldKey="FILE_LEN_MB_INT" )
    private Integer fileLenMbInt;
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the refNoSum
     */
    public Integer getRefNoSum() {
        return refNoSum;
    }
    /**
     * @param refNoSum the refNoSum to set
     */
    public void setRefNoSum(Integer refNoSum) {
        this.refNoSum = refNoSum;
    }
    /**
     * @return the fileSeqno
     */
    public String getFileSeqno() {
        return fileSeqno;
    }
    /**
     * @param fileSeqno the fileSeqno to set
     */
    public void setFileSeqno(String fileSeqno) {
        this.fileSeqno = fileSeqno;
    }
    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }
    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    /**
     * @return the fileExt
     */
    public String getFileExt() {
        return fileExt;
    }
    /**
     * @param fileExt the fileExt to set
     */
    public void setFileExt(String fileExt) {
        this.fileExt = fileExt;
    }
    /**
     * @return the fileLen
     */
    public Integer getFileLen() {
        return fileLen;
    }
    /**
     * @param fileLen the fileLen to set
     */
    public void setFileLen(Integer fileLen) {
        this.fileLen = fileLen;
    }
    /**
     * @return the fileLenKb
     */
    public String getFileLenKb() {
        return fileLenKb;
    }
    /**
     * @param fileLenKb the fileLenKb to set
     */
    public void setFileLenKb(String fileLenKb) {
        this.fileLenKb = fileLenKb;
    }
    /**
     * @return the fileLenKbInt
     */
    public Integer getFileLenKbInt() {
        return fileLenKbInt;
    }
    /**
     * @param fileLenKbInt the fileLenKbInt to set
     */
    public void setFileLenKbInt(Integer fileLenKbInt) {
        this.fileLenKbInt = fileLenKbInt;
    }
    /**
     * @return the fileLenMb
     */
    public String getFileLenMb() {
        return fileLenMb;
    }
    /**
     * @param fileLenMb the fileLenMb to set
     */
    public void setFileLenMb(String fileLenMb) {
        this.fileLenMb = fileLenMb;
    }
    /**
     * @return the fileLenMbInt
     */
    public Integer getFileLenMbInt() {
        return fileLenMbInt;
    }
    /**
     * @param fileLenMbInt the fileLenMbInt to set
     */
    public void setFileLenMbInt(Integer fileLenMbInt) {
        this.fileLenMbInt = fileLenMbInt;
    }
}
