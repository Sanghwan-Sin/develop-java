package com.mobis.maps.comm.service;

import java.util.List;

import com.mobis.maps.comm.vo.MapsCommDbTblColVO;

/**
 * <pre>
 * 테이블컬럼정보 서비스
 * </pre>
 *
 * @ClassName   : MapsCommDbTblColService.java
 * @Description : 테이블컬럼정보에 대한 서비스를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsCommDbTblColService {

    /**
     * 테이블컬럼정보 리스트 조회
     *
     * @param commDbTblColVO
     * @return
     * @throws Exception
     */
    public List<MapsCommDbTblColVO> selectDbTblColList(MapsCommDbTblColVO commDbTblColVO) throws Exception;
}
