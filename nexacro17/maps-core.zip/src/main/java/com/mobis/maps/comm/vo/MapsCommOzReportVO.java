package com.mobis.maps.comm.vo;

import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommOzReportVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 4. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 27.     oh.dongwon     	최초 생성
 * </pre>
 */

public class MapsCommOzReportVO extends MapsCommSapRfcIfCommVO {
    /** I_CHNNL_YN */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CHNNL_YN" )
    private String iChnnlYn;
    /** I_OZ_RFC_NAME */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_OZ_RFC_NAME" )
    private String iOzRfcName;
    
    /** ALV control: Field name of internal table field */
    @MapsRfcMappper( targetName="I_RFC_PARAM_T", ipttSe="I", fieldKey="FIELDNAME" )
    private String fieldname;
    /** ALV Control: Cell Content */
    @MapsRfcMappper( targetName="I_RFC_PARAM_T", ipttSe="I", fieldKey="VALUE" )
    private String value;
    
    /** I_SYSID */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_SYSID" )
    private String iSysid;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_OZ_URL" )
    private String eOzUrl;
    
    @MapsRfcMappper( ipttSe="E", fieldKey="E_OZ_SEQNO" )
    private String eOzSeqno; 
    
    // ex> http://nmgn-dev.mobis.co.kr/oz80 이런식으로 도메인 저장용
    private String systemOzUrl;
    
    // ERP YN 
    private String iErpYn;
    
    // 멀티 폼용으로 formData 리턴
    private String formData;
    
    // 멀티 폼용으로 formData input
    private String reportName;
    
    // 멀티 폼용으로 formData input
    private String ozSeqNo;
    
    
    
    
    /**
     * @return the eOzSeqno
     */
    public String geteOzSeqno() {
        return eOzSeqno;
    }
    /**
     * @param eOzSeqno the eOzSeqno to set
     */
    public void seteOzSeqno(String eOzSeqno) {
        this.eOzSeqno = eOzSeqno;
    }
    /**
     * @return the formData
     */
    public String getFormData() {
        return formData;
    }
    /**
     * @param formData the formData to set
     */
    public void setFormData(String formData) {
        this.formData = formData;
    }
    /**
     * @return the reportName
     */
    public String getReportName() {
        return reportName;
    }
    /**
     * @param reportName the reportName to set
     */
    public void setReportName(String reportName) {
        this.reportName = reportName;
    }
    /**
     * @return the ozSeqNo
     */
    public String getOzSeqNo() {
        return ozSeqNo;
    }
    /**
     * @param ozSeqNo the ozSeqNo to set
     */
    public void setOzSeqNo(String ozSeqNo) {
        this.ozSeqNo = ozSeqNo;
    }
    /**
     * @return the iErpYn
     */
    public String getiErpYn() {
        return iErpYn;
    }
    /**
     * @param iErpYn the iErpYn to set
     */
    public void setiErpYn(String iErpYn) {
        this.iErpYn = iErpYn;
    }
    /**
     * @return the systemOzUrl
     */
    public String getSystemOzUrl() {
        return systemOzUrl;
    }
    /**
     * @param systemOzUrl the systemOzUrl to set
     */
    public void setSystemOzUrl(String systemOzUrl) {
        this.systemOzUrl = systemOzUrl;
    }
    /**
     * @return the iChnnlYn
     */
    public String getiChnnlYn() {
        return iChnnlYn;
    }
    /**
     * @param iChnnlYn the iChnnlYn to set
     */
    public void setiChnnlYn(String iChnnlYn) {
        this.iChnnlYn = iChnnlYn;
    }
    /**
     * @return the iOzRfcName
     */
    public String getiOzRfcName() {
        return iOzRfcName;
    }
    /**
     * @param iOzRfcName the iOzRfcName to set
     */
    public void setiOzRfcName(String iOzRfcName) {
        this.iOzRfcName = iOzRfcName;
    }
    /**
     * @return the fieldname
     */
    public String getFieldname() {
        return fieldname;
    }
    /**
     * @param fieldname the fieldname to set
     */
    public void setFieldname(String fieldname) {
        this.fieldname = fieldname;
    }
    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }
    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }
    /**
     * @return the iSysid
     */
    public String getiSysid() {
        return iSysid;
    }
    /**
     * @param iSysid the iSysid to set
     */
    public void setiSysid(String iSysid) {
        this.iSysid = iSysid;
    }
    /**
     * @return the eOzUrl
     */
    public String geteOzUrl() {
        return eOzUrl;
    }
    /**
     * @param eOzUrl the eOzUrl to set
     */
    public void seteOzUrl(String eOzUrl) {
        this.eOzUrl = eOzUrl;
    }
    
    
    

}
