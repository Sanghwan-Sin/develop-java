package com.mobis.maps.cmmn.exception;

import java.util.Locale;

import org.springframework.context.MessageSource;

/**
 * <pre>
 * 세션 예외처리
 * </pre>
 *
 * @ClassName   : MapsSessionException.java
 * @Description : 세션에 대한 예외처리.
 * @author DT048058
 * @since 2020. 3. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 24.     DT048058     	최초 생성
 * </pre>
 */

public class MapsSessionException extends MapsBizException {

    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = -4331213163640024009L;

    public MapsSessionException() {
        super();
    }

    public MapsSessionException(MessageSource messageSource
            , String messageKey
            , Exception wrappedException) {
        super(messageSource, messageKey, wrappedException);
    }

    public MapsSessionException(MessageSource messageSource
            , String messageKey
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, locale, wrappedException);
    }

    public MapsSessionException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, wrappedException);
    }

    public MapsSessionException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, locale, wrappedException);
    }

    public MapsSessionException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , String defaultMessage
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, wrappedException);
    }

    public MapsSessionException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , String defaultMessage
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, locale, wrappedException);
    }

    public MapsSessionException(MessageSource messageSource
            , String messageKey) {
        super(messageSource, messageKey);
    }

    public MapsSessionException(String defaultMessage
            , Exception wrappedException) {
        super(defaultMessage, wrappedException);
    }

    public MapsSessionException(String defaultMessage
            , Object[] messageParameters
            , Exception wrappedException) {
        super(defaultMessage, messageParameters, wrappedException);
    }

    public MapsSessionException(String defaultMessage) {
        super(defaultMessage);
    }
}
