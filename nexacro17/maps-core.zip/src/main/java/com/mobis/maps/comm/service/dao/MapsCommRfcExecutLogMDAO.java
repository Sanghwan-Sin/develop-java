package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommRfcExecutLogVO;

/**
 * <pre>
 * RFC실행로그 데이터처리 정의
 * </pre>
 *
 * @ClassName   : MapsCommRfcExecutLogMDAO.java
 * @Description : RFC실행로그에 대한 데이터를 처리를 정의.
 * @author DT048058
 * @since 2020. 2. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 7.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsCommRfcExecutLogMDAO")
public interface MapsCommRfcExecutLogMDAO {

    /**
     * RFC실행로그 페이징 리스트 조회
     *
     * @param commRfcExecutLogVO
     * @return
     * @throws Exception
     */
    public List<MapsCommRfcExecutLogVO> selectRfcExecutLogPgList(MapsCommRfcExecutLogVO commRfcExecutLogVO) throws Exception;

    /**
     * RFC실행로그 입출력데이터 리스트 조회
     *
     * @param commRfcExecutLogVO
     * @return
     * @throws Exception
     */
    public List<MapsCommRfcExecutLogVO> selectRfcExecutLogDataList(MapsCommRfcExecutLogVO commRfcExecutLogVO) throws Exception;
}
