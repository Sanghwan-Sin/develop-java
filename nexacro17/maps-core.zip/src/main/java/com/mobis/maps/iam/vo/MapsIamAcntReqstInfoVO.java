package com.mobis.maps.iam.vo;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

/**
 * <pre>
 * 계정신청정보 항목
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstInfoVO.java
 * @Description : 계정신청정보에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamAcntReqstInfoVO extends MapsIamUserVO {
    /* 조회조건 */
    /** 일시구분코드 */
    private String dtSeCd;
    /* 계정신청정보 */
    /** 계정신청번호 */
    private String acntReqstNo;
    /** 사용희망일 */
    private Date useHopeDe;
    /** 신청상태코드 */
    private String reqstSttusCd;
    /** 신청내용 */
    private String reqstCn;
    /** 신청일시 */
    private Date reqstDt;
    /** 승인상태코드 */
    private String apprvSttusCd;
    /** 승인일시 */
    private Date apprvDt;
    /** 승인사용자순번ID */
    private String apprvId;
    /** 승인자명 */
    private String apprvNm;
    /** 승인내용 */
    private String apprvCn;
    /** 사용자기본ID */
    private String originUserBassId;
    /** 변경구분코드 */
    private String changeSeCd;
    /** 전암호 */
    private String bfePwd;
    /* 상태변경정보 */
    /** 변경일시 */
    private Date changeDt;
    /** 변경자ID */
    private String changeId;
    
    public void appendApprvCn(String apprvCn) {
        if (StringUtils.isNotEmpty(this.apprvCn)) {
            this.apprvCn.concat("\n");
        } else {
            this.apprvCn = "";
        }
        this.apprvCn = this.apprvCn.concat(apprvCn);
    }
    /**
     * @return the dtSeCd
     */
    public String getDtSeCd() {
        return dtSeCd;
    }
    /**
     * @param dtSeCd the dtSeCd to set
     */
    public void setDtSeCd(String dtSeCd) {
        this.dtSeCd = dtSeCd;
    }
    /**
     * @return the acntReqstNo
     */
    public String getAcntReqstNo() {
        return acntReqstNo;
    }
    /**
     * @param acntReqstNo the acntReqstNo to set
     */
    public void setAcntReqstNo(String acntReqstNo) {
        this.acntReqstNo = acntReqstNo;
    }
    /**
     * @return the useHopeDe
     */
    public Date getUseHopeDe() {
        return useHopeDe;
    }
    /**
     * @param useHopeDe the useHopeDe to set
     */
    public void setUseHopeDe(Date useHopeDe) {
        this.useHopeDe = useHopeDe;
    }
    /**
     * @return the reqstSttusCd
     */
    public String getReqstSttusCd() {
        return reqstSttusCd;
    }
    /**
     * @param reqstSttusCd the reqstSttusCd to set
     */
    public void setReqstSttusCd(String reqstSttusCd) {
        this.reqstSttusCd = reqstSttusCd;
    }
    /**
     * @return the reqstCn
     */
    public String getReqstCn() {
        return reqstCn;
    }
    /**
     * @param reqstCn the reqstCn to set
     */
    public void setReqstCn(String reqstCn) {
        this.reqstCn = reqstCn;
    }
    /**
     * @return the reqstDt
     */
    public Date getReqstDt() {
        return reqstDt;
    }
    /**
     * @param reqstDt the reqstDt to set
     */
    public void setReqstDt(Date reqstDt) {
        this.reqstDt = reqstDt;
    }
    /**
     * @return the apprvSttusCd
     */
    public String getApprvSttusCd() {
        return apprvSttusCd;
    }
    /**
     * @param apprvSttusCd the apprvSttusCd to set
     */
    public void setApprvSttusCd(String apprvSttusCd) {
        this.apprvSttusCd = apprvSttusCd;
    }
    /**
     * @return the apprvDt
     */
    public Date getApprvDt() {
        return apprvDt;
    }
    /**
     * @param apprvDt the apprvDt to set
     */
    public void setApprvDt(Date apprvDt) {
        this.apprvDt = apprvDt;
    }
    /**
     * @return the apprvId
     */
    public String getApprvId() {
        return apprvId;
    }
    /**
     * @param apprvId the apprvId to set
     */
    public void setApprvId(String apprvId) {
        this.apprvId = apprvId;
    }
    /**
     * @return the apprvNm
     */
    public String getApprvNm() {
        return apprvNm;
    }
    /**
     * @param apprvNm the apprvNm to set
     */
    public void setApprvNm(String apprvNm) {
        this.apprvNm = apprvNm;
    }
    /**
     * @return the apprvCn
     */
    public String getApprvCn() {
        return apprvCn;
    }
    /**
     * @param apprvCn the apprvCn to set
     */
    public void setApprvCn(String apprvCn) {
        this.apprvCn = apprvCn;
    }
    /**
     * @return the originUserBassId
     */
    public String getOriginUserBassId() {
        return originUserBassId;
    }
    /**
     * @param originUserBassId the originUserBassId to set
     */
    public void setOriginUserBassId(String originUserBassId) {
        this.originUserBassId = originUserBassId;
    }
    /**
     * @return the changeSeCd
     */
    public String getChangeSeCd() {
        return changeSeCd;
    }
    /**
     * @param changeSeCd the changeSeCd to set
     */
    public void setChangeSeCd(String changeSeCd) {
        this.changeSeCd = changeSeCd;
    }
    /**
     * @return the bfePwd
     */
    public String getBfePwd() {
        return bfePwd;
    }
    /**
     * @param bfePwd the bfePwd to set
     */
    public void setBfePwd(String bfePwd) {
        this.bfePwd = bfePwd;
    }
    /**
     * @return the changeDt
     */
    public Date getChangeDt() {
        return changeDt;
    }
    /**
     * @param changeDt the changeDt to set
     */
    public void setChangeDt(Date changeDt) {
        this.changeDt = changeDt;
    }
    /**
     * @return the changeId
     */
    public String getChangeId() {
        return changeId;
    }
    /**
     * @param changeId the changeId to set
     */
    public void setChangeId(String changeId) {
        this.changeId = changeId;
    }
    
}
