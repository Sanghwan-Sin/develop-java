package com.mobis.maps.smpl.service.impl;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.util.FileUploadUtil;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.smpl.service.MapsSmplService;
import com.mobis.maps.smpl.vo.MapsSmplAtchFileVO;
import com.mobis.maps.smpl.vo.MapsSmplFileUpVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Service("mapsSmplService")
public class MapsSmplServiceImpl extends HService implements MapsSmplService {

    @Resource(name="mapsCommFileService")
    private MapsCommFileService mapsCommFileService;
    
    
    /*
     * @see com.mobis.maps.smpl.service.MapsSmplService#multiSmplAtchFile(com.mobis.maps.smpl.vo.MapsSmplAtchFileVO, java.util.List)
     */
    @Override
    public int multiSmplAtchFile(MapsSmplAtchFileVO smplAtchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception {

        AtchFileSe atchFileSe = AtchFileSe.get(smplAtchFileVO.getAtchSe());
        
        int procCnt = mapsCommFileService.multiAtchFile(atchFileSe, smplAtchFileVO, atchFiles);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplService#selectFileUpload(javax.servlet.http.HttpServletRequest, java.lang.String)
     */
    @Override
    public MapsSmplFileUpVO selectFileUpload(HttpServletRequest request, String atchSe) throws Exception {

        MapsAtchFileVO atchFileVO = new MapsAtchFileVO();
        List<MapsAtchFileVO> atchFiles = null;
        
        File fUp = null;
        try {
            
            fUp = mapsCommFileService.selectFileUpload(request);
            
            atchFileVO.setAtchSe(atchSe);
            atchFileVO.setAtchId("2");
            
            atchFiles = mapsCommFileService.selectAtchFileList(atchFileVO);
        
        } finally {
            if (fUp != null) {
                FileUploadUtil.removeFile(fUp);
            }
        }

        MapsSmplFileUpVO smplFileUp = new MapsSmplFileUpVO();
        smplFileUp.setAtchFileVO(atchFileVO);
        smplFileUp.setAtchFiles(atchFiles);
        
        return smplFileUp;
    }

}
