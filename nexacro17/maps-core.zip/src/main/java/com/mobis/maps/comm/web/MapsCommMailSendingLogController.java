package com.mobis.maps.comm.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommMailSendingLogService;
import com.mobis.maps.comm.vo.MapsCommMailSendingLogVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommMailSendingLogController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 1.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 1.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class MapsCommMailSendingLogController extends HController{

    @Resource(name = "mapsCommMailSendingLogService")
    private MapsCommMailSendingLogService mapsCommMailSendingLogService;

    /**
     * Mail Logging 리스트 조회
     *
     * @param loggingVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectMailLoggingList.do")
    public NexacroResult selectMailLoggingList(@ParamDataSet(name="dsInput") MapsCommMailSendingLogVO loggingVO
                                             , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommMailSendingLogVO> rtnVo = mapsCommMailSendingLogService.selectMailLoggingList(loggingVO, loginInfo);
        
        result.addDataSet("dsOutput", rtnVo);
        
        return result;
    }
}
