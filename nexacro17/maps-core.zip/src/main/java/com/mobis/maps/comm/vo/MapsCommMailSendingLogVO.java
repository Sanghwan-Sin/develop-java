package com.mobis.maps.comm.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommMailSendingLogVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 1.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 1.     jiyongdo     	최초 생성
 * </pre>
 */

public class MapsCommMailSendingLogVO  extends MapsCommCodeGroupVO {
    
    private int    rnum       ;
    private String salesOrg   ;
    private String emailSn    ;
    private String sndngProgrm;
    private String sndngSe    ;
    private String creatDt    ;
    private String sndngDt    ;
    private String errorMssage;
    private String htmlYn     ;
    private String sndngEmail ;
    private String recptnEmail;
    private String recptnCc   ;
    private String recptnBcc  ;
    private String emailRply  ;
    private String emailSj    ;
    private String emailBdt   ;
    private String atchYn     ;
    private String refCol1    ;
    private String refCol2    ;
    private String refCol3    ;
    private String refCol4    ;
    private String refCol5    ;
    private String registId   ;
//    private String registDt   ;
    private String updtId     ;
//    private String updtDt     ;
    private String creatStrDt;
    private String creatFnsDt  ;  
    private String program;
    
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the salesOrg
     */
    public String getSalesOrg() {
        return salesOrg;
    }
    /**
     * @param salesOrg the salesOrg to set
     */
    public void setSalesOrg(String salesOrg) {
        this.salesOrg = salesOrg;
    }
    /**
     * @return the emailSn
     */
    public String getEmailSn() {
        return emailSn;
    }
    /**
     * @param emailSn the emailSn to set
     */
    public void setEmailSn(String emailSn) {
        this.emailSn = emailSn;
    }
    /**
     * @return the sndngProgrm
     */
    public String getSndngProgrm() {
        return sndngProgrm;
    }
    /**
     * @param sndngProgrm the sndngProgrm to set
     */
    public void setSndngProgrm(String sndngProgrm) {
        this.sndngProgrm = sndngProgrm;
    }
    /**
     * @return the sndngSe
     */
    public String getSndngSe() {
        return sndngSe;
    }
    /**
     * @param sndngSe the sndngSe to set
     */
    public void setSndngSe(String sndngSe) {
        this.sndngSe = sndngSe;
    }
    /**
     * @return the creatDt
     */
    public String getCreatDt() {
        return creatDt;
    }
    /**
     * @param creatDt the creatDt to set
     */
    public void setCreatDt(String creatDt) {
        this.creatDt = creatDt;
    }
    /**
     * @return the sndngDt
     */
    public String getSndngDt() {
        return sndngDt;
    }
    /**
     * @param sndngDt the sndngDt to set
     */
    public void setSndngDt(String sndngDt) {
        this.sndngDt = sndngDt;
    }
    /**
     * @return the errorMssage
     */
    public String getErrorMssage() {
        return errorMssage;
    }
    /**
     * @param errorMssage the errorMssage to set
     */
    public void setErrorMssage(String errorMssage) {
        this.errorMssage = errorMssage;
    }
    /**
     * @return the htmlYn
     */
    public String getHtmlYn() {
        return htmlYn;
    }
    /**
     * @param htmlYn the htmlYn to set
     */
    public void setHtmlYn(String htmlYn) {
        this.htmlYn = htmlYn;
    }
    /**
     * @return the sndngEmail
     */
    public String getSndngEmail() {
        return sndngEmail;
    }
    /**
     * @param sndngEmail the sndngEmail to set
     */
    public void setSndngEmail(String sndngEmail) {
        this.sndngEmail = sndngEmail;
    }
    /**
     * @return the recptnEmail
     */
    public String getRecptnEmail() {
        return recptnEmail;
    }
    /**
     * @param recptnEmail the recptnEmail to set
     */
    public void setRecptnEmail(String recptnEmail) {
        this.recptnEmail = recptnEmail;
    }
    /**
     * @return the recptnCc
     */
    public String getRecptnCc() {
        return recptnCc;
    }
    /**
     * @param recptnCc the recptnCc to set
     */
    public void setRecptnCc(String recptnCc) {
        this.recptnCc = recptnCc;
    }
    /**
     * @return the recptnBcc
     */
    public String getRecptnBcc() {
        return recptnBcc;
    }
    /**
     * @param recptnBcc the recptnBcc to set
     */
    public void setRecptnBcc(String recptnBcc) {
        this.recptnBcc = recptnBcc;
    }
    /**
     * @return the emailRply
     */
    public String getEmailRply() {
        return emailRply;
    }
    /**
     * @param emailRply the emailRply to set
     */
    public void setEmailRply(String emailRply) {
        this.emailRply = emailRply;
    }
    /**
     * @return the emailSj
     */
    public String getEmailSj() {
        return emailSj;
    }
    /**
     * @param emailSj the emailSj to set
     */
    public void setEmailSj(String emailSj) {
        this.emailSj = emailSj;
    }
    /**
     * @return the emailBdt
     */
    public String getEmailBdt() {
        return emailBdt;
    }
    /**
     * @param emailBdt the emailBdt to set
     */
    public void setEmailBdt(String emailBdt) {
        this.emailBdt = emailBdt;
    }
    /**
     * @return the atchYn
     */
    public String getAtchYn() {
        return atchYn;
    }
    /**
     * @param atchYn the atchYn to set
     */
    public void setAtchYn(String atchYn) {
        this.atchYn = atchYn;
    }
    /**
     * @return the refCol1
     */
    public String getRefCol1() {
        return refCol1;
    }
    /**
     * @param refCol1 the refCol1 to set
     */
    public void setRefCol1(String refCol1) {
        this.refCol1 = refCol1;
    }
    /**
     * @return the refCol2
     */
    public String getRefCol2() {
        return refCol2;
    }
    /**
     * @param refCol2 the refCol2 to set
     */
    public void setRefCol2(String refCol2) {
        this.refCol2 = refCol2;
    }
    /**
     * @return the refCol3
     */
    public String getRefCol3() {
        return refCol3;
    }
    /**
     * @param refCol3 the refCol3 to set
     */
    public void setRefCol3(String refCol3) {
        this.refCol3 = refCol3;
    }
    /**
     * @return the refCol4
     */
    public String getRefCol4() {
        return refCol4;
    }
    /**
     * @param refCol4 the refCol4 to set
     */
    public void setRefCol4(String refCol4) {
        this.refCol4 = refCol4;
    }
    /**
     * @return the refCol5
     */
    public String getRefCol5() {
        return refCol5;
    }
    /**
     * @param refCol5 the refCol5 to set
     */
    public void setRefCol5(String refCol5) {
        this.refCol5 = refCol5;
    }
    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }
    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }
    /**
     * @return the updtId
     */
    public String getUpdtId() {
        return updtId;
    }
    /**
     * @param updtId the updtId to set
     */
    public void setUpdtId(String updtId) {
        this.updtId = updtId;
    }
    /**
     * @return the creatStrDt
     */
    public String getCreatStrDt() {
        return creatStrDt;
    }
    /**
     * @param creatStrDt the creatStrDt to set
     */
    public void setCreatStrDt(String creatStrDt) {
        this.creatStrDt = creatStrDt;
    }
    /**
     * @return the creatFnsDt
     */
    public String getCreatFnsDt() {
        return creatFnsDt;
    }
    /**
     * @param creatFnsDt the creatFnsDt to set
     */
    public void setCreatFnsDt(String creatFnsDt) {
        this.creatFnsDt = creatFnsDt;
    }
    /**
     * @return the program
     */
    public String getProgram() {
        return program;
    }
    /**
     * @param program the program to set
     */
    public void setProgram(String program) {
        this.program = program;
    }
    
}
