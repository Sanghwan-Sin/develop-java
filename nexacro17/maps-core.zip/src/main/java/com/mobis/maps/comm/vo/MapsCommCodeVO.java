package com.mobis.maps.comm.vo;

/**
 * <pre>
 * 공통 코드 항목
 * </pre>
 *
 * @ClassName : MapsCommCodeVO.java
 * @Description : 공통 코드 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 29.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class MapsCommCodeVO extends MapsCommCodeGroupVO {
    /** 상위코드 */ 
    private String upperCode;
    /** 코드 */
    private String code;
    /** 코드명 */
    private String codeNm;
    /** 항목ID */
    private String iemId;
    /** 용어ID */ 
    private String wordId;
    /** 단축용어사용코드 */
    private String abbrevWordUseCd;
    /** 원본용어 */
    private String orginlWord;
    /** 표시순서 */
    private int indictOrdr;
    /** 코드참고1 */
    private String codeRefer1;
    /** 코드참고2 */
    private String codeRefer2;
    /** 코드참고3 */
    private String codeRefer3;
    /** 코드참고4 */
    private String codeRefer4;
    /** 코드참고5 */
    private String codeRefer5;
    /* 부가적인 항목 정의 */
    /** 코드컬럼명 */
    private String codeColNm;
    /** 표시타입(K:코드,V:코드명) */
    private String dispTy;
    /** 콤보타이틀타입(A:전체,S:선택) */
    private String cboSjTy;
    /** 콤보타입이 "S" 또는 "A" 인경우 표시할 문자 항목ID */
    private String cboDfltId;
    /** 콤보타입이 "S" 또는 "A" 인경우 초기값 */
    private String cboDfltVal;
    /** SAP언어키 */
    private String aspLangKey;
    /**
     * @return the upperCode
     */
    public String getUpperCode() {
        return upperCode;
    }
    /**
     * @param upperCode the upperCode to set
     */
    public void setUpperCode(String upperCode) {
        this.upperCode = upperCode;
    }
    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
    /**
     * @return the codeNm
     */
    public String getCodeNm() {
        return codeNm;
    }
    /**
     * @param codeNm the codeNm to set
     */
    public void setCodeNm(String codeNm) {
        this.codeNm = codeNm;
    }
    /**
     * @return the iemId
     */
    public String getIemId() {
        return iemId;
    }
    /**
     * @param iemId the iemId to set
     */
    public void setIemId(String iemId) {
        this.iemId = iemId;
    }
    /**
     * @return the wordId
     */
    public String getWordId() {
        return wordId;
    }
    /**
     * @param wordId the wordId to set
     */
    public void setWordId(String wordId) {
        this.wordId = wordId;
    }
    /**
     * @return the abbrevWordUseCd
     */
    public String getAbbrevWordUseCd() {
        return abbrevWordUseCd;
    }
    /**
     * @param abbrevWordUseCd the abbrevWordUseCd to set
     */
    public void setAbbrevWordUseCd(String abbrevWordUseCd) {
        this.abbrevWordUseCd = abbrevWordUseCd;
    }
    /**
     * @return the orginlWord
     */
    public String getOrginlWord() {
        return orginlWord;
    }
    /**
     * @param orginlWord the orginlWord to set
     */
    public void setOrginlWord(String orginlWord) {
        this.orginlWord = orginlWord;
    }
    /**
     * @return the indictOrdr
     */
    public int getIndictOrdr() {
        return indictOrdr;
    }
    /**
     * @param indictOrdr the indictOrdr to set
     */
    public void setIndictOrdr(int indictOrdr) {
        this.indictOrdr = indictOrdr;
    }
    /**
     * @return the codeRefer1
     */
    public String getCodeRefer1() {
        return codeRefer1;
    }
    /**
     * @param codeRefer1 the codeRefer1 to set
     */
    public void setCodeRefer1(String codeRefer1) {
        this.codeRefer1 = codeRefer1;
    }
    /**
     * @return the codeRefer2
     */
    public String getCodeRefer2() {
        return codeRefer2;
    }
    /**
     * @param codeRefer2 the codeRefer2 to set
     */
    public void setCodeRefer2(String codeRefer2) {
        this.codeRefer2 = codeRefer2;
    }
    /**
     * @return the codeRefer3
     */
    public String getCodeRefer3() {
        return codeRefer3;
    }
    /**
     * @param codeRefer3 the codeRefer3 to set
     */
    public void setCodeRefer3(String codeRefer3) {
        this.codeRefer3 = codeRefer3;
    }
    /**
     * @return the codeRefer4
     */
    public String getCodeRefer4() {
        return codeRefer4;
    }
    /**
     * @param codeRefer4 the codeRefer4 to set
     */
    public void setCodeRefer4(String codeRefer4) {
        this.codeRefer4 = codeRefer4;
    }
    /**
     * @return the codeRefer5
     */
    public String getCodeRefer5() {
        return codeRefer5;
    }
    /**
     * @param codeRefer5 the codeRefer5 to set
     */
    public void setCodeRefer5(String codeRefer5) {
        this.codeRefer5 = codeRefer5;
    }
    /**
     * @return the codeColNm
     */
    public String getCodeColNm() {
        return codeColNm;
    }
    /**
     * @param codeColNm the codeColNm to set
     */
    public void setCodeColNm(String codeColNm) {
        this.codeColNm = codeColNm;
    }
    /**
     * @return the dispTy
     */
    public String getDispTy() {
        return dispTy;
    }
    /**
     * @param dispTy the dispTy to set
     */
    public void setDispTy(String dispTy) {
        this.dispTy = dispTy;
    }
    /**
     * @return the cboSjTy
     */
    public String getCboSjTy() {
        return cboSjTy;
    }
    /**
     * @param cboSjTy the cboSjTy to set
     */
    public void setCboSjTy(String cboSjTy) {
        this.cboSjTy = cboSjTy;
    }
    /**
     * @return the cboDfltId
     */
    public String getCboDfltId() {
        return cboDfltId;
    }
    /**
     * @param cboDfltId the cboDfltId to set
     */
    public void setCboDfltId(String cboDfltId) {
        this.cboDfltId = cboDfltId;
    }
    /**
     * @return the cboDfltVal
     */
    public String getCboDfltVal() {
        return cboDfltVal;
    }
    /**
     * @param cboDfltVal the cboDfltVal to set
     */
    public void setCboDfltVal(String cboDfltVal) {
        this.cboDfltVal = cboDfltVal;
    }
    /**
     * @return the aspLangKey
     */
    public String getAspLangKey() {
        return aspLangKey;
    }
    /**
     * @param aspLangKey the aspLangKey to set
     */
    public void setAspLangKey(String aspLangKey) {
        this.aspLangKey = aspLangKey;
    }

}
