package com.mobis.maps.cmmn.listener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.spring.SpringApplicationContext;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommLoginService;

@WebListener
public class MapsSessionListener implements HttpSessionListener {
    protected Logger logger = LoggerFactory.getLogger(MapsSessionListener.class);
    
    @Override
    public void sessionCreated(HttpSessionEvent se) {
    }
    
    /*
     * @세션이 끊길때 listener 정의 ==> 로그 아웃 처리
     */
    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        LoginInfoVO loginInfo = (LoginInfoVO) se.getSession().getAttribute(MapsConstants.SSS_LOGIN_INFO);
        if( loginInfo != null ){
            // 로그 아웃 처리 진행
            /* 서비스 정의 */
            MapsCommLoginService mapsCommLoginService = (MapsCommLoginService) SpringApplicationContext.getBean("mapsCommLoginService");
            try {
                logger.info("****************** MapsSessionListener LOGOUT 처리 START *************[" + loginInfo.getUserId() + "]");
                mapsCommLoginService.updateLoginOutInfo(loginInfo);
            } catch (Exception e) {
                logger.info("updateLoginOutInfo Exception." + e.getLocalizedMessage());
            }
        }
        
    }
}