package com.mobis.maps.sapjco.manager;

import com.mobis.maps.cmmn.exception.MapsRuntimeException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.ext.Environment;

/**
 * @Classname DestinationManager
 * @Description Destination, Monitoring, Function, FuntionTemaplate 제공
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * 
 * @Modification Information
 * since            author      description
 * =============    ========    ==================================================
 * 2019. 05. 18.    DT045877    최초 생성
 */
public class DestinationManager {

    /**
     * Constructor
     *
     * @param destinationProvider
     * @throws JCoException
     */
    public DestinationManager(DestinationProvider destinationProvider) throws JCoException {
        Environment.registerDestinationDataProvider(destinationProvider);
    }
    
    /**
     * JCoDestination 객체 반환
     *
     * @param dest
     * @return
     * @throws JCoException
     */
    public JCoDestination getDestination(String dest) throws JCoException {
        JCoDestination destination = JCoDestinationManager.getDestination(dest);
        if (destination == null) {
            throw new MapsRuntimeException("JCoDestination '" + dest + "' not found");
        }
        return destination;
    }
    
    /**
     * Funcion 객체 반환
     * @param rfcName
     * @return 
     * @throws JCoException
     */
    public Function getFunction(JCoDestination jcoDestination, String rfcName) throws JCoException {
        JCoFunction jcoFunction = jcoDestination.getRepository().getFunction(rfcName);
        if (jcoFunction == null) {
            throw new MapsRuntimeException("Function '" + rfcName + "' not found");
        }
        return new Function(jcoDestination, jcoFunction);
    }
    
    /**
     * FunctionTemplate 객체 반환
     * @param rfcName
     * @return
     * @throws JCoException
     */
    public FunctionTemplate getFunctionTemplate(JCoDestination jcoDestination, String rfcName) throws JCoException {
        JCoFunctionTemplate jcoFunctionTemplate = jcoDestination.getRepository().getFunctionTemplate(rfcName);
        if (jcoFunctionTemplate == null) {
            throw new MapsRuntimeException("FunctionTemplate '" + rfcName + "' not found");
        }
        return new FunctionTemplate(jcoDestination, jcoFunctionTemplate);
    }
}