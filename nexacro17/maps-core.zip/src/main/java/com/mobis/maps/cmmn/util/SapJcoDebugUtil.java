package com.mobis.maps.cmmn.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoMetaData;
import com.sap.conn.jco.JCoParameterList;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SapJcoDebugUtil.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 3. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 12.     oh.dongwon     	최초 생성
 * </pre>
 */

public class SapJcoDebugUtil {
    protected final static Logger LOGGER = LoggerFactory.getLogger(SapJcoDebugUtil.class);
    /**
     * print debug
     *
     * @param input
     */
    public static void printDebug(String input){
        if( LOGGER.isDebugEnabled() ){
            LOGGER.debug(input);
        }
    }
    
    /**
     * Statements
     *
     * @param jcoFunction
     */
    public static void printFunctionMetaInfo(JCoFunction jcoFunction){
        
        if( !LOGGER.isDebugEnabled() ){
            return;
        }
        if( jcoFunction == null ){
            printDebug( "******* jcoFunction IS NULL ");
            return;
        }
        printDebug( "[" +  jcoFunction.getName() + "] START ***********");
        List<String> importStructure = new ArrayList<String>();
        JCoParameterList importParamList =  jcoFunction.getImportParameterList();
        setStructureAndPrint(importParamList.getMetaData() , importStructure);
        for(int i = 0 ; i< importStructure.size(); i++){
            String structureName = importStructure.get(i);
            JCoMetaData jcoMeta = jcoFunction.getImportParameterList().getStructure(structureName).getMetaData();
            printMetaInfo(jcoMeta , structureName);
        }
        List<String> exportStructure = new ArrayList<String>();
        JCoParameterList exportParamList =  jcoFunction.getExportParameterList();
        setStructureAndPrint(exportParamList.getMetaData() , exportStructure);
        for(int i = 0 ; i< exportStructure.size(); i++){
            String structureName = exportStructure.get(i);
            JCoMetaData jcoMeta = jcoFunction.getExportParameterList().getStructure(structureName).getMetaData();
            printMetaInfo(jcoMeta , structureName);
        }
        List<String> tableStructure = new ArrayList<String>();
        setStructureAndPrint(jcoFunction.getTableParameterList().getMetaData() , tableStructure);
        for(int i = 0 ; i< tableStructure.size(); i++){
            String tableName = tableStructure.get(i);
            JCoMetaData jcoMeta = jcoFunction.getTableParameterList().getTable(tableName).getMetaData();
            printMetaInfo(jcoMeta , tableName);
        }
        printDebug( "[" +  jcoFunction.getName() + "] END   ***********");
    }
    
    
    /**
     * SAPJCO 메타 출력
     *
     * @param meta
     */
    public static void setStructureAndPrint(JCoMetaData meta ,List<String> importStructure ){
        String metaName = meta.getName();
        printDebug( "  [" + metaName + "] START ***********");
        
        int fieldCnt = meta.getFieldCount();
        for(int i = 0 ; i < fieldCnt ; i++){
            String desc = meta.getDescription(i);
            String name = meta.getName(i);
            String typeString = meta.getTypeAsString(i);
            int typeInt = meta.getType(i);
            
            if( typeInt == 17 || typeInt == 99) {
                importStructure.add(name);
            }
            printDebug("      [" +  metaName + "].[" + name + "] Type [" + typeString + "] Desc [" + desc +"]");
        }
        printDebug( "  [" + metaName + "] END *************");
    }
    
    /**
     * SAPJCO 메타 출력
     *
     * @param meta
     */
    public static void printMetaInfo(JCoMetaData meta , String refName ){
        String metaName = meta.getName();
        if(StringUtils.isNotEmpty(refName)){
            metaName = refName + "(" + metaName + ")";
        }
        printDebug( "    [" + metaName + "] START **************");
        int fieldCnt = meta.getFieldCount();
        for(int i = 0 ; i < fieldCnt ; i++){
            String desc = meta.getDescription(i);
            String name = meta.getName(i);
            String typeString = meta.getTypeAsString(i);
            int typeInt = meta.getType(i);
            printDebug( "      [" +  refName + "].[" + name + "] type [" + typeString + "] desc [" + desc +"] typeInt [" + typeInt + "]");
        }
        printDebug( "    [" + metaName + "] END   **************");
    }

}
