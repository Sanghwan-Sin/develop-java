package com.mobis.maps.comm.constants;

/**
 * <pre>
 * RFC 데이터 타입
 * </pre>
 *
 * @ClassName   : RfcDataTy.java
 * @Description : RFC 데이터 타입을 정의.
 * @author Sin Sanghwan
 * @since 2019. 10. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 14.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public enum RfcDataTy {
    
      String("S")
    , Integer("I")
    , Float("F")
    , Number("N")
    , Currency("C")
    , Structure("V")
    , List("L")
    , Date("D")
    , Datetime("T")
    , Binary("B")
    ;
    
    /** RFC 데이터 타입 */
    private String code;
    
    private RfcDataTy(String code) {
        this.code = code;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
}
