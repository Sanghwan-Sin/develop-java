package com.mobis.maps.cmmn.excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.ExcelBindingException;
import com.mobis.maps.cmmn.secure.DocPsrvUtil;
import com.mobis.maps.cmmn.spring.SpringApplicationContext;
import com.mobis.maps.cmmn.util.FileUploadUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.util.WebUtil;

/**
 * <pre>
 * Excel파일 유틸리티
 * </pre>
 *
 * @ClassName   : ExcelUtil.java
 * @Description : Excel파일 처리에 대한 유틸리티를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 6.     Sin Sanghwan        최초 생성
 * </pre>
 */
public class ExcelUtil {

    private static Logger logger = LoggerFactory.getLogger(ExcelUtil.class);
    
    private final static String SUB_EXCEL = "excel";
    
    private final static String PROFILE_DEFAULT = WebUtil.SERVER_PROFILE_LOCAL;
    
    /** 엑셀 업로드 제한건수 */
    private final static int EXCEL_UPLOAD_MAX_CNT = 5000;
    
    /** message source */
    private static MessageSource messageSource;
    
    public static MessageSource getMessageSource() {
        
        if (messageSource == null) {
            messageSource = (MessageSource) SpringApplicationContext.getBean("messageSource");
        }
        
        return messageSource;
    }
    
    /**
     * 엑셀 파일 Import
     *
     * @param request
     * @param startRow
     * @param endCell
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(HttpServletRequest request, int startRow, int endCell) throws Exception {
        return importExcelToList(request, startRow, endCell, 0);
    }

    /**
     * 엑셀 파일 Import
     *
     * @param request
     * @param startRow
     * @param endCell
     * @param sheetNo
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(HttpServletRequest request, int startRow, int endCell, int sheetNo) throws Exception {
        return importExcelToList(request, startRow, endCell, sheetNo, MapsConstants.YN_YES);
    }
    
    /**
     * 엑셀 파일 Import
     *
     * @param request
     * @param startRow
     * @param endCell
     * @param sheetNo
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(HttpServletRequest request, int startRow, int endCell, int sheetNo, String drmFlag) throws Exception {
        String paramName = null;
        MultipartFile multipartFile = null;
        FileOutputStream fos = null;
        File file = null;
        try {
            MultipartHttpServletRequest mptRequest = (MultipartHttpServletRequest) request;
            Iterator<?> fileIter = mptRequest.getFileNames();
            if (fileIter.hasNext()) {
                paramName = (String) fileIter.next();
                List<MultipartFile> mFiles = mptRequest.getFiles(paramName);
                multipartFile = mFiles.get(0);
            }
            if (multipartFile == null) {
                //ECI0000002 : 업로드된 액셀파일이 없습니다.
                throw new ExcelBindingException(getMessageSource(), "ECI0000002");
            }
            file = getStoredFile(multipartFile.getOriginalFilename());
            fos = new FileOutputStream(file);
            fos.write(multipartFile.getBytes());
            fos.close();
        } catch (Exception e) {
            //ECI0000000 : 액셀파일 업로드를 실패하였습니다.
            throw new ExcelBindingException(getMessageSource(), "ECI0000001");
        } finally {
            if (fos != null) {
                fos.close();
            }
        }
        String profile = WebUtil.getServerProfile(request);
        return importExcelToList(file, startRow, endCell, sheetNo, drmFlag , profile);
    }

    /**
     * 엑셀 파일 Import
     *
     * @param request
     * @param startRow
     * @param endCell
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(MultipartHttpServletRequest request, int startRow, int endCell) throws Exception {
        return importExcelToList(request, startRow, endCell, 0);
    }

    /**
     * 엑셀 파일 Import
     *
     * @param request
     * @param startRow
     * @param endCell
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(MultipartHttpServletRequest request, int startRow, int endCell, int sheetNo) throws Exception {
        return importExcelToList(request, startRow, endCell, sheetNo, MapsConstants.YN_YES);
    }

    /**
     * 엑셀 파일 Import
     *
     * @param request
     * @param startRow
     * @param endCell
     * @param sheetNo
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(MultipartHttpServletRequest request, int startRow, int endCell, int sheetNo, String drmFlag) throws Exception {
        String paramName = null;
        MultipartFile multipartFile = null;
        FileOutputStream fos = null;
        File file = null;
        try {
            Iterator<?> fileIter = request.getFileNames();
            if (fileIter.hasNext()) {
                paramName = (String) fileIter.next();
                List<MultipartFile> mFiles = request.getFiles(paramName);
                multipartFile = mFiles.get(0);
            }
            if (multipartFile == null) {
                //ECI0000002 : 업로드된 액셀파일이 없습니다.
                throw new ExcelBindingException(getMessageSource(), "ECI0000002");
            }
            file = getStoredFile(multipartFile.getOriginalFilename());
            fos = new FileOutputStream(file);
            fos.write(multipartFile.getBytes());
            fos.close();
        } catch (Exception e) {
            //ECI0000001 : 액셀파일 업로드를 실패하였습니다.
            throw new ExcelBindingException(getMessageSource(), "ECI0000001");
        } finally {
            if (fos != null) {fos.close();}
        }
        
        String profile = WebUtil.getServerProfile(request);
        return importExcelToList(file, startRow, endCell, sheetNo, drmFlag , profile);
    }

    /**
     * 엑셀 파일 Import
     *
     * @param multipartFile
     * @param startRow
     * @param endCell
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(MultipartFile multipartFile, int startRow, int endCell) throws Exception {
        return importExcelToList(multipartFile, startRow, endCell, 0);
    }
    
    /**
     * 엑셀 파일 Import
     *
     * @param multipartFile
     * @param startRow
     * @param endCell
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(MultipartFile multipartFile, int startRow, int endCell, int sheetNo) throws Exception {
        return importExcelToList(multipartFile, startRow, endCell, sheetNo, MapsConstants.YN_YES , PROFILE_DEFAULT);
    }
    
    /**
     * 엑셀 파일 Import
     *
     * @param multipartFile
     * @param startRow
     * @param endCell
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(MultipartFile multipartFile, int startRow, int endCell, int sheetNo, String drmFlag ,String serverProfile ) throws Exception {
        FileOutputStream fos = null;
        File file = null;
        try {
            file = getStoredFile(multipartFile.getOriginalFilename());
            fos = new FileOutputStream(file);
            fos.write(multipartFile.getBytes());
        } catch (Exception e) {
            //ECI0000001 : 액셀파일 업로드를 실패하였습니다.
            throw new ExcelBindingException(getMessageSource(), "ECI0000001");
        } finally {
            if (fos != null) {
                fos.close();
            }
        }
        return importExcelToList(file, startRow, endCell, sheetNo, drmFlag,serverProfile );
    }


    /**
     * 엑셀 파일 Import
     *
     * @param file
     * @param startRow 행
     * @param endCell 열(MAX을 행을 지정해야 String[]에 값을 Set함
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(File file, int startRow, int endCell ) throws Exception {
        return importExcelToList(file, startRow, endCell, 0 , "" , PROFILE_DEFAULT);
    }
    /**
     * 엑셀 파일 Import
     *
     * @param file
     * @param startRow 행
     * @param endCell 열(MAX을 행을 지정해야 String[]에 값을 Set함
     * @param sheetNo 시트지정
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(File file, int startRow, int endCell, int sheetNo ) throws Exception {
        return importExcelToList(file, startRow, endCell, sheetNo, MapsConstants.YN_YES , PROFILE_DEFAULT);
    }
    
    /**
     * 엑셀 파일 Import
     *
     * @param file
     * @param startRow 행
     * @param endCell 열(MAX을 행을 지정해야 String[]에 값을 Set함
     * @param sheetNo 시트지정
     * @return
     *  - List<String[]> 으로 반환
     *  - 리스트 Row는 엑셀에 Row와 같고 String[]은 Col의 값과 같음
     * @throws IOException
     * @throws ExcelBindingException
     * @throws Exception
     */
    public static List<String[]> importExcelToList(File file, int startRow, int endCell, int sheetNo, String drmFlag , String serverProfile) throws Exception {
        if (file == null) {
            return null;
        }
        String fileNm = file.getName();
        File fDec;
        List<String[]> list = null;
        String prop = PropertiesUtil.getValue("DS_SCDS_PROP");
        // SRS
        if ((StringUtils.isNotBlank(prop)) // SRS에만 service linker 등록해둠
                && (!StringUtils.equals(serverProfile, WebUtil.SERVER_PROFILE_LOCAL)) // 로컬 개발환경 skip
                // && StringUtils.equalsIgnoreCase(drmFlag, MapsConstants.YN_YES)
        ) { // DRM Flag 가 "Y" DRM 복호화 처리
            if (logger.isDebugEnabled()) {
                logger.debug("→ importExcelToList::DRM 복호화 처리");
            }
            fDec = DocPsrvUtil.decryptScDsFile(file);
        } else {
            fDec = file;
        }

        if (StringUtils.endsWithIgnoreCase(fileNm, ".xlsx")) {
            list = importExcel(fDec, startRow, endCell, sheetNo);
        } else {
            list = importExcelXls(fDec, startRow, endCell, sheetNo);
        }
        return list;
    }

    /**
     * 액셀데이터가져오기(XLSX)
     *
     * @param file
     * @param startRow
     * @param endCell
     * @param sheetNo
     * @return
     * @throws Exception
     */
    private static List<String[]> importExcel(File file, int startRow , int endCell , int sheetNo) throws Exception {

        List<String[]> list = new ArrayList<String[]>();
        FileInputStream fis = null;
        try{
            fis = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sheet = wb.getSheetAt(sheetNo);
            
            int lastRowNum = sheet.getLastRowNum();
            if (lastRowNum < 0) {
                return list;
            }
            if( lastRowNum >= EXCEL_UPLOAD_MAX_CNT ){
                throw new ExcelBindingException( getMessageSource(), "EC00000015", new String[]{"Excel Upload" ,"5000 row"}  ,null );
            }
            for (int i = startRow; i <= lastRowNum; i++) {
                XSSFRow row = sheet.getRow(i);
                if (row == null) {
                    continue;
                }
//                if (endCell > row.getLastCellNum()) {
//                    endCell = row.getLastCellNum();
//                }
                String[] arrCellVal = null;
                for (short j = 0; j < endCell; j++) {
                    String cellVal = null;
                    XSSFCell cell = row.getCell(j);
                    if (cell != null) {
                        switch (cell.getCellType()) {
                            case XSSFCell.CELL_TYPE_STRING:
                                cellVal = cell.getRichStringCellValue().getString();
                                break;
                            case XSSFCell.CELL_TYPE_NUMERIC:
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cellVal = cell.getRichStringCellValue().getString();
                                break;
                            case XSSFCell.CELL_TYPE_FORMULA:
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cellVal = cell.getStringCellValue();
                                break;
                            default:
                                cellVal = cell.getStringCellValue();
                        }
                    }
                    arrCellVal = ArrayUtils.add(arrCellVal, StringUtils.defaultString(cellVal));
                }

                list.add(arrCellVal);
            }
        } catch(IOException e) {
            //ECI0000003 : 액셀데이터 가져오기에 실패하였습니다.
            throw new ExcelBindingException(getMessageSource(), "ECI0000003");
        } finally {
            if (fis != null) {
                fis.close();
            }
        }
        return list;
    }

    /**
     * 액셀데이터가져오기(XLS)
     *
     * @param file
     * @param startRow
     * @param endCell
     * @param sheetNo
     * @return
     * @throws Exception
     */
    private static List<String[]> importExcelXls(File file, int startRow, int endCell, int sheetNo) throws Exception {
        
        List<String[]> list = new ArrayList<String[]>();
        FileInputStream fis = null;
        try{
            fis = new FileInputStream(file);
            HSSFWorkbook wb = new HSSFWorkbook(fis);
            HSSFSheet sheet = wb.getSheetAt(sheetNo);
            int lastRowNum = sheet.getLastRowNum(); 
            if (lastRowNum < 0) {
                return list;
            }
            
            if( lastRowNum >= EXCEL_UPLOAD_MAX_CNT ){
                throw new ExcelBindingException( getMessageSource(), "EC00000015", new String[]{"Excel Upload" ,"5000 row"}  ,null );
            }
            
            
            for (int i = startRow; i <= sheet.getLastRowNum(); i++) {
                HSSFRow row = sheet.getRow(i);
                if (row == null) {
                    continue;
                }
//                if (endCell > row.getLastCellNum()) {
//                    endCell = row.getLastCellNum();
//                }
                String[] arrCellVal = null;
                for (int j = 0; j < endCell; j++) {
                    String cellVal = null;
                    HSSFCell cell = row.getCell(j);
                    if (cell != null) {
                        switch (cell.getCellType()) {
                            case HSSFCell.CELL_TYPE_STRING:
                                cellVal = cell.getRichStringCellValue().getString();
                                break;
                            case HSSFCell.CELL_TYPE_NUMERIC:
                                cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                                cellVal = cell.getRichStringCellValue().getString();
                                break;
                            case HSSFCell.CELL_TYPE_FORMULA:
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cellVal = cell.getStringCellValue();
                                break;
                            default:
                                cellVal = cell.getStringCellValue();
                        }
                    }
                    arrCellVal = ArrayUtils.add(arrCellVal, StringUtils.defaultString(cellVal));
                }
                list.add(arrCellVal);
            }
        } catch(IOException e) {
            //ECI0000003 : 액셀데이터 가져오기에 실패하였습니다.
            throw new ExcelBindingException(getMessageSource(), "ECI0000003");
        } finally {
            if (fis != null) {
                fis.close();
            }
        }
        return list;
    }
    
    /**
     * 액셀저장파일
     *
     * @param fileNm
     * @return
     * @throws IOException 
     */
    private static File getStoredFile(String fileNm) throws IOException {
        
        String filePath = FileUploadUtil.getStoredFolderFullPath(SUB_EXCEL);
        
        File file = new File(filePath, fileNm);

        FileUploadUtil.createFile(file);
        
        return file;
    }

}
