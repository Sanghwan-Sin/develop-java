package com.mobis.maps.comm.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommOrgnztVO;
import com.mobis.maps.comm.vo.ScrinConectInfoVO;

/**
 * <pre>
 * MAPS공통서비스 정의
 * </pre>
 *
 * @ClassName   : MapsCommService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 30.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsCommService {

    /**
     * 화면접속정보 등록
     *
     * @param request
     * @param loginInfo
     * @throws Exception
     */
    public void insertScrinConectInfo(HttpServletRequest request, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 화면접속정보 등록
     *
     * @param connectInfo
     * @param loginInfo
     * @throws Exception
     */
    public void insertScrinConectInfo(ScrinConectInfoVO connectInfo, LoginInfoVO loginInfo) throws Exception;

    /**
     * 조직 페이징리스트 조회
     *
     * @param commOrgnztVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommOrgnztVO> selectOrgnztPgList(MapsCommOrgnztVO commOrgnztVO) throws Exception;

    /**
     * 조직명 조회
     *
     * @param commOrgnztVO
     * @return
     * @throws Exception
     */
    public MapsCommOrgnztVO selectOrgnztNm(MapsCommOrgnztVO commOrgnztVO) throws Exception;
}
