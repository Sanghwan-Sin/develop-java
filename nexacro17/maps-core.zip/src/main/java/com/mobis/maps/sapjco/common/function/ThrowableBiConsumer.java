package com.mobis.maps.sapjco.common.function;

import java.util.function.BiConsumer;

import com.mobis.maps.cmmn.exception.MapsRuntimeException;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ThrowableBiConsumer.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 5. 8.     DT045877     	최초 생성
 * </pre>
 */
@FunctionalInterface
public interface ThrowableBiConsumer<T, U> {
    /**
     * @see
     * java.util.function.Consumer
     * 
     * @param t
     * input parameter type T
     * 
     * @param u
     * input parameter type U
     * 
     * @throws Exception
     */
    void accept(T t, U u) throws Exception;
    
    /**
     * throws Exception lambda to throws RuntimeException lambda
     * @param biConsumer
     * @return
     * @since
     * 0.6
     */
    public static <T, U> BiConsumer<T, U> runtime(ThrowableBiConsumer<T, U> biConsumer) {
        return (t, u) -> {
            try {
                biConsumer.accept(t, u);
            } catch (Exception e) {
                throw new MapsRuntimeException(e);
            }
        };
    }
    
    /**
     * ignore exception<br>
     * this method recommend only special situation 
     * @param biConsumer
     * @return
     * @since
     * 1.1
     */
    public static <T, U> BiConsumer<T, U> ignore(ThrowableBiConsumer<T, U> biConsumer) {
        return (t, u) -> {
            try {
                biConsumer.accept(t, u);
            } catch (Exception e) {
            }
        };
    }
}
