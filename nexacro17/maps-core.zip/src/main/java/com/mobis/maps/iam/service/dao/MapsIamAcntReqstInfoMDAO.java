package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.iam.vo.MapsIamAcntReqstAuthorVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstLangVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstPermIpVO;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;

/**
 * <pre>
 * 계정신청 데이터처리
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstInfoMDAO.java
 * @Description : 계정신청에 대한 데이터처리를 정의.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsIamAcntReqstInfoMDAO")
public interface MapsIamAcntReqstInfoMDAO {

    /**
     * 계정신청정보 조회
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamAcntReqstInfoVO selectAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 사용자기본정보 조회(Email)
     *
     * @param iamUserBassInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamUserBassInfoVO selectUserBassInfoByEmail(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception;
    
    /**
     * 계정존재 조회
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamUserVO selectAcntExst(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 계정신청정보 존재조회
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamAcntReqstInfoVO selectHasAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 계정신청정보 존재조회(By조직별 이메일)
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamAcntReqstInfoVO selectAcntReqstInfoByOrgnztEmail(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 사용자기본메일 존재조회
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamAcntReqstInfoVO selectHasUserBassEmail(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 사용자순번ID 조회(By 사용자기본ID)
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public String selectUserSeqIdByUserBassId(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 사용자순번ID 조회(By 이메일)
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public String selectUserSeqIdByEmail(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 사용자순번ID 조회(By 조직별 이메일)
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public String selectUserSeqIdByOrgnztEmail(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 관리자이메일 리스트 조회
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectMngrEmailList(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 계정신청 등록
     *
     * @param iamAcntReqstInfoVO
     * @throws Exception
     */
    public void insertAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;

    /**
     * 계정신청정보 수정
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public int updateAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 계정신청정보 삭제
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public int deleteAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 계정신청상태이력 등록
     *
     * @param iamAcntReqstInfoVO
     * @throws Exception
     */
    public void insertAcntReqstSttusChghst(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;

    /**
     * 계정신청언어 리스트 조회
     *
     * @param iamAcntReqstLangVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAcntReqstLangVO> selectAcntReqstLangList(MapsIamAcntReqstLangVO iamAcntReqstLangVO) throws Exception;

    /**
     * 계정신청언어 조회
     *
     * @param iamAcntReqstLangVO
     * @return
     * @throws Exception
     */
    public MapsIamAcntReqstLangVO selectAcntReqstLang(MapsIamAcntReqstLangVO iamAcntReqstLangVO) throws Exception;

    /**
     * 계정신청언어 등록
     *
     * @param iamAcntReqstLangVO
     * @throws Exception
     */
    public void insertAcntReqstLang(MapsIamAcntReqstLangVO iamAcntReqstLangVO) throws Exception;

    /**
     * 계정신청언어 전체 삭제
     *
     * @param iamAcntReqstLangVO
     * @return
     * @throws Exception
     */
    public int deleteAllAcntReqstLang(MapsIamAcntReqstLangVO iamAcntReqstLangVO) throws Exception;

    /**
     * 계정신청허용IP 리스트 조회
     *
     * @param iamAcntReqstPermIpVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAcntReqstPermIpVO> selectAcntReqstPermIpList(MapsIamAcntReqstPermIpVO iamAcntReqstPermIpVO) throws Exception;
    
    /**
     * 계정신청허용IP 조회
     *
     * @param iamAcntReqstPermIpVO
     * @return
     * @throws Exception
     */
    public MapsIamAcntReqstPermIpVO selectAcntReqstPermIp(MapsIamAcntReqstPermIpVO iamAcntReqstPermIpVO) throws Exception;

    /**
     * 계정신청허용IP 등록
     *
     * @param iamAcntReqstPermIpVO
     * @throws Exception
     */
    public void insertAcntReqstPermIp(MapsIamAcntReqstPermIpVO iamAcntReqstPermIpVO) throws Exception;
    
    /**
     * 계정신청허용IP 전체 삭제
     *
     * @param iamAcntReqstPermIpVO
     * @throws Exception
     */
    public void deleteAllAcntReqstPermIp(MapsIamAcntReqstPermIpVO iamAcntReqstPermIpVO) throws Exception;

    /**
     * 권한마스트 리스트 조회
     *
     * @param iamAcntReqstAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectAuthorMstList(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * [비로그인]권한마스트 리스트 조회
     *
     * @param iamAcntReqstAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectNlognAuthorMstList(MapsIamAuthorVO iamAuthorVO) throws Exception;
    
    /**
     * 계정신청권한 리스트 조회
     *
     * @param iamAcntReqstAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAcntReqstAuthorVO> selectAcntReqstAuthorList(MapsIamAcntReqstAuthorVO iamAcntReqstAuthorVO) throws Exception;

    /**
     * 계정신청권한 조회
     *
     * @param iamAcntReqstAuthorVO
     * @return
     * @throws Exception
     */
    public MapsIamAcntReqstAuthorVO selectAcntReqstAuthor(MapsIamAcntReqstAuthorVO iamAcntReqstAuthorVO) throws Exception;

    /**
     * 계정신청권한 등록
     *
     * @param iamAcntReqstAuthorVO
     * @throws Exception
     */
    public void insertAcntReqstAuthor(MapsIamAcntReqstAuthorVO iamAcntReqstAuthorVO) throws Exception;

    /**
     * 계정신청권한 전체 삭제
     *
     * @param iamAcntReqstAuthorVO
     * @return
     * @throws Exception
     */
    public int deleteAllAcntReqstAuthor(MapsIamAcntReqstAuthorVO iamAcntReqstAuthorVO) throws Exception;
    
    /**
     * 계정신청정보 승인/반려 
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public int updateAcntReqstApprv(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;

    /**
     * 계정신청 사용자기본정보 등록
     *
     * @param iamAcntReqstInfoVO
     * @throws Exception
     */
    public void insertAcntReqstUserBassInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 계정신청 사용자기본정보 변경이력 등록
     *
     * @param iamAcntReqstInfoVO
     * @throws Exception
     */
    public void insertAcntReqstUserBassChghst(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;

    /**
     * 계정신청 사용자 등록
     *
     * @param iamAcntReqstInfoVO
     * @throws Exception
     */
    public void insertAcntReqstUser(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 계정신청 사용자변경이력 등록
     *
     * @param iamAcntReqstInfoVO
     * @throws Exception
     */
    public void insertAcntReqstUserChghst(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 계정신청 사용자암호변경이력 등록
     *
     * @param iamAcntReqstInfoVO
     * @throws Exception
     */
    public void insertAcntReqstUserPwdChghst(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;
    
    /**
     * 계정신청 사용자언어 등록
     *
     * @param iamAcntReqstLangVO
     * @throws Exception
     */
    public void insertAcntReqstUserLang(MapsIamAcntReqstLangVO iamAcntReqstLangVO) throws Exception;
    
    /**
     * 계정신청 사용자허용IP 등록
     *
     * @param iamAcntReqstPermIpVO
     * @throws Exception
     */
    public void insertAcntReqstUserPermIp(MapsIamAcntReqstPermIpVO iamAcntReqstPermIpVO) throws Exception;

    /**
     * 계정신청 사용자권한 등록
     *
     * @param iamAcntReqstAuthorVO
     * @throws Exception
     */
    public void insertAcntReqstUserAuthor(MapsIamAcntReqstAuthorVO iamAcntReqstAuthorVO) throws Exception;
    
}
