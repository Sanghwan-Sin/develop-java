package com.mobis.maps.comm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;

/**
 * <pre>
 * SAP 첨부파일작성정보 항목
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcFileInfoVO.java
 * @Description : SAP 첨부파일작성정보에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 3.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommSapAtchFileInfoVO extends MapsCommSapRfcIfCommVO {

    /** File Server ID */
    @MapsRfcMappper( targetName="P|ES_ATTACH_COUNT|ES_CREATE|ES_MASTER|IT_ATTACH_SUM", paramTrgtNm="INFO|COUNT|SUM", ipttSe="I|E", fieldKey="I_FSCODE|FSCODE" )
    private String fscode;
    /** Reference Number */
    @MapsRfcMappper( targetName="P|ES_ATTACH_COUNT|ES_CREATE|IT_ATTACH_SUM", paramTrgtNm="INFO|COUNT", ipttSe = "I|E", fieldKey="I_REF_NO|REF_NO" )
    private String refNo;
    /** Reference Number */
    @MapsRfcMappper( targetName="I_REF_NO_T", ipttSe="I", fieldKey="REF_NO" )
    private String iRefNo;
    /** File Server Directory Code */
    @MapsRfcMappper( targetName="ES_CONFIG|ES_MASTER", ipttSe="E", fieldKey="FSDIRCD" )
    private String fsdircd;
    /** ROOT */
    @MapsRfcMappper( targetName="ES_CONFIG", ipttSe="E", fieldKey="ROOTDIR" )
    private String rootdir;
    /** Directory name */
    @MapsRfcMappper( targetName="ES_CONFIG", ipttSe="E", fieldKey="DIRNAME" )
    private String dirname;
    /** File Max Length (Byte) */
    @MapsRfcMappper( targetName="ES_CONFIG", ipttSe="E", fieldKey="FILE_MAX_LEN" )
    private Long fileMaxLen;
    /** File Max Count */
    @MapsRfcMappper( targetName="ES_CONFIG", ipttSe="E", fieldKey="FILE_MAX_COUNT" )
    private Integer fileMaxCount;
    /** File ID */
    @MapsRfcMappper( targetName="ES_CREATE", ipttSe="E", fieldKey="FILE_SEQNO" )
    private String fileSeqno;
    /** File Sum */
    @MapsRfcMappper( targetName="ES_CREATE|ES_ATTACH_COUNT|IT_ATTACH_SUM", ipttSe="E", fieldKey="REF_NO_SUM" )
    private Integer refNoSum;
    /** File Path (Legacy) */
    @MapsRfcMappper( targetName="ES_CREATE", ipttSe="E", fieldKey="FILE_PATH_LEG" )
    private String filePathLeg;
    /** File Server Desc */
    @MapsRfcMappper( targetName="ES_MASTER", ipttSe="E", fieldKey="FSCODE_TXT" )
    private String fscodeTxt;
    /** Module */
    @MapsRfcMappper( targetName="ES_MASTER", ipttSe="E", fieldKey="ZMODULE" )
    private String zmodule;
    /** Path (Ex: /Module/File Server ID) */
    @MapsRfcMappper( targetName="ES_MASTER", ipttSe="E", fieldKey="FSCODE_PATH" )
    private String fscodePath;
    /** Active */
    @MapsRfcMappper( targetName="ES_MASTER", ipttSe="E", fieldKey="ACTIVE" )
    private String active;
    /** File Server 저장 테이블 */
    @MapsRfcMappper( targetName="ES_MASTER", ipttSe="E", fieldKey="TABNAME" )
    private String tabname;
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the iRefNo
     */
    public String getiRefNo() {
        return iRefNo;
    }
    /**
     * @param iRefNo the iRefNo to set
     */
    public void setiRefNo(String iRefNo) {
        this.iRefNo = iRefNo;
    }
    /**
     * @return the fsdircd
     */
    public String getFsdircd() {
        return fsdircd;
    }
    /**
     * @param fsdircd the fsdircd to set
     */
    public void setFsdircd(String fsdircd) {
        this.fsdircd = fsdircd;
    }
    /**
     * @return the rootdir
     */
    public String getRootdir() {
        return rootdir;
    }
    /**
     * @param rootdir the rootdir to set
     */
    public void setRootdir(String rootdir) {
        this.rootdir = rootdir;
    }
    /**
     * @return the dirname
     */
    public String getDirname() {
        return dirname;
    }
    /**
     * @param dirname the dirname to set
     */
    public void setDirname(String dirname) {
        this.dirname = dirname;
    }
    /**
     * @return the fileMaxLen
     */
    public Long getFileMaxLen() {
        return fileMaxLen;
    }
    /**
     * @param fileMaxLen the fileMaxLen to set
     */
    public void setFileMaxLen(Long fileMaxLen) {
        this.fileMaxLen = fileMaxLen;
    }
    /**
     * @return the fileMaxCount
     */
    public Integer getFileMaxCount() {
        return fileMaxCount;
    }
    /**
     * @param fileMaxCount the fileMaxCount to set
     */
    public void setFileMaxCount(Integer fileMaxCount) {
        this.fileMaxCount = fileMaxCount;
    }
    /**
     * @return the fileSeqno
     */
    public String getFileSeqno() {
        return fileSeqno;
    }
    /**
     * @param fileSeqno the fileSeqno to set
     */
    public void setFileSeqno(String fileSeqno) {
        this.fileSeqno = fileSeqno;
    }
    /**
     * @return the refNoSum
     */
    public Integer getRefNoSum() {
        return refNoSum;
    }
    /**
     * @param refNoSum the refNoSum to set
     */
    public void setRefNoSum(Integer refNoSum) {
        this.refNoSum = refNoSum;
    }
    /**
     * @return the filePathLeg
     */
    public String getFilePathLeg() {
        return filePathLeg;
    }
    /**
     * @param filePathLeg the filePathLeg to set
     */
    public void setFilePathLeg(String filePathLeg) {
        this.filePathLeg = filePathLeg;
    }
    /**
     * @return the fscodeTxt
     */
    public String getFscodeTxt() {
        return fscodeTxt;
    }
    /**
     * @param fscodeTxt the fscodeTxt to set
     */
    public void setFscodeTxt(String fscodeTxt) {
        this.fscodeTxt = fscodeTxt;
    }
    /**
     * @return the zmodule
     */
    public String getZmodule() {
        return zmodule;
    }
    /**
     * @param zmodule the zmodule to set
     */
    public void setZmodule(String zmodule) {
        this.zmodule = zmodule;
    }
    /**
     * @return the fscodePath
     */
    public String getFscodePath() {
        return fscodePath;
    }
    /**
     * @param fscodePath the fscodePath to set
     */
    public void setFscodePath(String fscodePath) {
        this.fscodePath = fscodePath;
    }
    /**
     * @return the active
     */
    public String getActive() {
        return active;
    }
    /**
     * @param active the active to set
     */
    public void setActive(String active) {
        this.active = active;
    }
    /**
     * @return the tabname
     */
    public String getTabname() {
        return tabname;
    }
    /**
     * @param tabname the tabname to set
     */
    public void setTabname(String tabname) {
        this.tabname = tabname;
    }
}
