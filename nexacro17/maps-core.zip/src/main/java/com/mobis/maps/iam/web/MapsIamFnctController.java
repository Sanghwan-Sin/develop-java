package com.mobis.maps.iam.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamFnctService;
import com.mobis.maps.iam.vo.MapsIamFnctEstnUrlVO;
import com.mobis.maps.iam.vo.MapsIamFnctVO;

/**
 * <pre>
 * Function관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamFnctController.java
 * @Description : Function관리에 대한 컨트롤러 정의
 * @author DT048657
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     DT048657     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamFnctController extends HController {

    @Resource(name = "mapsIamFnctService")
    private MapsIamFnctService mapsIamFnctService;
    
    /**
     * Function관리 조회
     *
     * @param iamMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectFnctPgList.do")
    public NexacroResult selectFnctPgList(
            @ParamDataSet(name="dsInput") MapsIamFnctVO iamFnctVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamFnctVO> fnctInfos = mapsIamFnctService.selectFnctPgList(iamFnctVO, loginInfo);
        
        result.addDataSet("dsOutput", fnctInfos);
        
        return result;
    }
    
    /**
     * Function관리 저장
     *
     * @param fnctInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiFnctInfo.do")
    public NexacroResult multiFnctInfo(
            @ParamDataSet(name="dsInput") List<MapsIamFnctVO> fnctInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamFnctService.multiFnctInfo(fnctInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * Function관리 액셀다운로드
     *
     * @param iamFnctVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectFnctListExcelDown.do")
    public NexacroResult selectFnctListExcelDown(
            @ParamDataSet(name="dsInput") MapsIamFnctVO iamFnctVO, NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        iamFnctVO.setExcelDwnlYn(MapsConstants.YN_YES);
        iamFnctVO.setPgNum(1);
        iamFnctVO.setPgSize(iamFnctVO.getTotMaxCnt());

        List<MapsIamFnctVO> fnctInfos =mapsIamFnctService.selectFnctPgList(iamFnctVO, loginInfo);

        result.addDataSet("dsOutput", fnctInfos);

        return result;
    }
        
    /**
     * Function관리 엑셀업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectFnctListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectFnctListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<String[]> lstCellVal = ExcelUtil.importExcelToList(request, 1, 9, 0, "N");

        List<MapsIamFnctVO> fnctInfos = new ArrayList<MapsIamFnctVO>();
        
        if (lstCellVal != null && !lstCellVal.isEmpty()) {

            for (String[] arrCellVal: lstCellVal) {

                MapsIamFnctVO iamFnctVO = new MapsIamFnctVO();

                iamFnctVO.setSysSeCd(arrCellVal[1]);
                iamFnctVO.setFnctSeCd(arrCellVal[3]);
                iamFnctVO.setFnctNm(arrCellVal[4]);
                iamFnctVO.setFnctUrl(arrCellVal[5]);
                iamFnctVO.setCompnId(arrCellVal[6]);
                iamFnctVO.setFnctDc(arrCellVal[7]);
                iamFnctVO.setUseYn(arrCellVal[8]);
                
                fnctInfos.add(iamFnctVO);
            }
        }

        result.addDataSet("dsOutput", fnctInfos);

        return result;

    }

    /**
     * Function확장URL 리스트 조회
     *
     * @param iamFnctEstnUrlVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectFnctEstnUrlList.do")
    public NexacroResult selectFnctEstnUrlList(
            @ParamDataSet(name="dsInput") MapsIamFnctEstnUrlVO iamFnctEstnUrlVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamFnctEstnUrlVO> fnctEstnUrls = mapsIamFnctService.selectFnctEstnUrlList(iamFnctEstnUrlVO, loginInfo);
        
        result.addDataSet("dsOutput", fnctEstnUrls);
        
        return result;
    }
    
    /**
     * Function확장URL 저장
     *
     * @param fnctEstnUrls
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiFnctEstnUrl.do")
    public NexacroResult multiFnctEstnUrl(
            @ParamDataSet(name="dsInput") List<MapsIamFnctEstnUrlVO> fnctEstnUrls
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamFnctService.multiFnctEstnUrl(fnctEstnUrls, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
}
