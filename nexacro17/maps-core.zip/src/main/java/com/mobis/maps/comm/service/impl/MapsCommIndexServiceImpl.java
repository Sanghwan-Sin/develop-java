package com.mobis.maps.comm.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import able.com.service.HService;
import able.com.util.crypto.AES256CryptoService;
import able.com.util.fmt.DateUtil;

import org.apache.commons.lang.LocaleUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.secure.SecureUtils;
import com.mobis.maps.cmmn.util.HttpUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.comm.service.MapsCommIndexService;
import com.mobis.maps.comm.vo.MapsCommIndexVO;

/**
 * <pre>
 * 초기화면로드 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommIndexServiceImpl.java
 * @Description : 초기화면로드에 대하 서비스 구현.
 * @author DT048058
 * @since 2019. 12. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 4.     DT048058     	최초 생성
 * </pre>
 */
/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommIndexServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     oh.dongwon     	최초 생성
 * </pre>
 */
@Service("mapsCommIndexService")
public class MapsCommIndexServiceImpl extends HService implements MapsCommIndexService {

    @Resource(name="aes256CryptoService")
    private AES256CryptoService aes256CryptoService;
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommIndexService#selecSapSdilInfo(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selecSapSdilInfo(HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        if (logger.isDebugEnabled()) {
            logger.debug("→ selecSapSdilInfo::start");
            logger.debug("→ selecSapSdilInfo::RequestURL=" + request.getRequestURI());
            logger.debug("→ selecSapSdilInfo::ssoEncData=" + request.getParameter("ssoEncData"));
        }
        /* 기본 정보 */
        String df = "yyyy.MM.dd HH:mm:ss.SSS";
        Locale locale = Locale.getDefault();
        /* 암복호화 정보 */
        String encData = null;  // 암호화된 QueryString
        String decData = null;  // 복호화된 QueryString
        Map<String, List<String>> params = null;    // 복호화 파라미터
        /* 복호화 파라미터 데이터 */
        String sapLangCd = null;    // SAP언어코드
        String userId = null;       // 사용자ID
        String scrinCd = null;      // 화면ID
        Calendar carExpried = Calendar.getInstance();   // 페이지 만료일시
        String dfExpried = "yyyyMMddHHmmss"; // 년월일시분초
        
        String cnSulInnerNo = ""; //품의내부번호
        String sancItemCd = ""; //결재항목코드
        
        
        /* 복호화 */
        // 을지 파라메터는 다음과 같이 전달된다.
        // cnSulInnerNo=품의내부번호&sancItemCd=결재항목코드&timestamp=년월일시분초 ==> 암호화 되어
        // ssoEncData=암호화된값 
        encData = request.getParameter("ssoEncData");
        //encData = request.getQueryString();
        if (StringUtils.isBlank(encData)) {
            if (logger.isDebugEnabled()) {
                logger.debug("→ selecSapSdilInfo::encData[" + encData + "]");
            }
            throw new MapsBizException(messageSource, "ECI0000020");   //암호화된 파라미터정보가 없습니다.
        }
        request.setAttribute("encData", encData);
        // QueryString 복호화
        decData = SecureUtils.decryptAES256Cipher(encData);
        // QueryString 파라미터정보맵 취득
        params = HttpUtil.parseQueryString(decData);
        if (params.isEmpty()) {
            logger.error("★ selecSapSdilInfo::Parameter is null");
            throw new MapsBizException(messageSource, "ECI0000021");    //복호화된 파라미터정보가 없습니다.
        }
        
        
        /* 파리미터정보 설정 */
        // 품의내부번호임시
        cnSulInnerNo = HttpUtil.getParseQueryStringValue(params, "cnSulInnerNo");
        // 결재항목코드임시
        sancItemCd = HttpUtil.getParseQueryStringValue(params, "sancItemCd");
        // 언어 한국어로 하드코딩
        sapLangCd =  "ko_KR";
        locale =  LocaleUtils.toLocale(sapLangCd);
        // 사용자ID 취득
        userId = "MAPSWF2";
        // 화면ID ==> 없음
        scrinCd = "";
        // 페이지만료일시 취득
        String expriedDt = HttpUtil.getParseQueryStringValue(params, "timestamp");
        if (logger.isDebugEnabled()) {
            logger.debug("→ selecSapSdilInfo::encData[" + encData + "][sapLangCd=" + sapLangCd + ",userId=" + userId  + ",cnSulInnerNo=" + cnSulInnerNo + ",sancItemCd=" + sancItemCd + ",scrinCd=" + scrinCd + ",expried=" + expriedDt + "]");
        }
        //locale = getLocale(sapLangCd);
        if (StringUtils.isBlank(userId)) {
            throw new MapsBizException(messageSource, "ECI0000022");   //사용자ID는 필수입력입니다.
        }
        if (NumberUtils.isDigits(expriedDt)) {
            carExpried.setTime(DateUtil.stringToDate(expriedDt, dfExpried));
            Calendar now = Calendar.getInstance();
            now.add(Calendar.SECOND, -120);
            if (carExpried.before(now)) {
                logger.error("★ selecSapSdilInfo::Expried[now=" + DateUtil.toString(now.getTime(), df, locale) + ",ms=" + DateUtil.toString(carExpried.getTime(), df, locale) + "]");
                throw new MapsBizException(messageSource, "ECI0000023");   //페이지가 만료되었습니다.
            }
        } else {
            throw new MapsBizException(messageSource, "ECI0000024");    //만료일시 형식이 아닙니다.
        }
        
        /* 세션초기화 */
        HttpSession session = request.getSession(true);
        //session.invalidate();
        /* 세션설정 */
        //session = request.getSession();
        session.setAttribute("locale", locale);
        session.setAttribute("userId", userId);
        session.setAttribute("scrinCd", scrinCd);
        session.setAttribute("expried", carExpried);
        session.setAttribute("sancItemCd", sancItemCd);
        session.setAttribute("cnSulInnerNo", cnSulInnerNo);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selecSapSdilInfo::end");
        }
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommIndexService#selectWorkflowSancVal(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public MapsCommIndexVO selectWorkflowSancVal(MapsCommIndexVO inVo) throws Exception {
        String tmpData = "20991231121901"; // 임시로 미래 날짜 셋팅
        // create instance of Random class 
        //Random rand = new Random(); 
        // Generate random integers in range 0 to 58 + 1 
        //String secStr  = ( rand.nextInt(59) + 1 ) + "";
        //tmpData = tmpData+ secStr;
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectWorkflowSancVal::tmpData : " + tmpData);
        }
        //encData = SecureUtils.encryptAES256Cipher("cnSulInnerNo=" + cnSulInnerNo + "&sancItemCd=" + sancItemCd + "&timestamp=" + DateUtil.toString(carExpried.getTime(), dfExpried, locale));
        String encData = "";//= SecureUtils.encryptAES256Cipher("cnSulInnerNo=" + inVo.getCnSulInnerNo() + "&sancItemCd=" + inVo.getSancItemCd() + "&timestamp=" + tmpData);
        
        String  decData = "";
        if( StringUtils.isBlank(inVo.getGubunFlag())) {
            encData = SecureUtils.encryptAES256Cipher("cnSulInnerNo=" + inVo.getCnSulInnerNo() + "&sancItemCd=" + inVo.getSancItemCd() + "&timestamp=" + tmpData);
            decData = SecureUtils.decryptAES256Cipher(encData);
        }else{
            if( StringUtils.equals(inVo.getGubunFlag(), "PORTAL" )  ){
                encData = SecureUtils.encryptAES256ForMapsSso("USER_ID=" + inVo.getUsrId() + "&locale=" + inVo.getLocale() + "&timestamp=" + tmpData);
                decData = SecureUtils.decryptAES256ForMapsSso(encData);
            }
        }
        
        decData = SecureUtils.decryptAES256Cipher(encData);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectWorkflowSancVal::decData : " + tmpData);
        }
        
        MapsCommIndexVO outVo = new MapsCommIndexVO();
        outVo.setSsoEncData(encData);
        
        return outVo;
    }
    
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommIndexService#selectSsoCheckMap(java.lang.String, java.lang.String)
     */
    @Override
    public Map<String,String> selectSsoCheckMap(String usrIdIn , String randomNum) throws Exception {
        
        String url =  PropertiesUtil.getDbValue("IMOBIS_SSO_URL") ; 
        if(StringUtils.isBlank(url)){
            url =  "http://ucdev.imobis.co.kr";
        }
        String rtnBody ="";
        String outUsrId = "";
        String retrunValueWS = "";
        String rtnValue = "";
        String url4Post = url + "/SSOService/SSOInfoService.asmx/GetStrSSOResult";
        // timeout 설정
        RequestConfig requestConfig = RequestConfig.custom()
                                    .setSocketTimeout(10*1000)
                                    .setConnectTimeout(10*1000)
                                    .setConnectionRequestTimeout(10*1000)
                                    .build();
        
        /*
        String url4Get = url + "/SSOService/SSOInfoService.asmx/GetSSOResult?StrUserID=" + usrId + "&strRamdomNum=" +  randomNum;
        HttpGet httpGet = new HttpGet(url4Get);
        httpGet.setConfig(requestConfig);
        httpGet.setHeader("Accept", "application/json");
        */
        
        //HttpClient httpclient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url4Post);
        httpPost.setConfig(requestConfig);
        // Request parameters and other properties.
        List<BasicNameValuePair> params = new ArrayList<BasicNameValuePair>(2);
        params.add(new BasicNameValuePair("StrUserID",usrIdIn));
        params.add(new BasicNameValuePair("strRamdomNum", randomNum));
        httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
        try{
            CloseableHttpClient httpClient = HttpClientBuilder.create().build();
            CloseableHttpResponse response = httpClient.execute(httpPost);
            if (response.getStatusLine().getStatusCode() == 200) {
                ResponseHandler<String> handler = new BasicResponseHandler();
                rtnBody = handler.handleResponse(response);
                String bodyCutStr = StringUtils.substringBetween(rtnBody, "<string xmlns=\"http://tempuri.org/\">", "</string>");
                String[] rtnVal = StringUtils.split(bodyCutStr , ";");
                if( logger.isErrorEnabled() ){
                    logger.error("→ imobis WEB SERVICE RTN : all        [" + rtnBody + "]");
                    logger.error("→ imobis WEB SERVICE RTN : bodyCutStr [" + bodyCutStr + "]");
                }
                
                
                if( rtnVal != null && rtnVal.length > 0  ){
                    outUsrId = rtnVal[0];
                    retrunValueWS = rtnVal[1];
                    if( !StringUtils.equals( StringUtils.lowerCase(retrunValueWS) ,"true") ){
                        rtnValue = "iMOBIS SSO Error.";
                    }
                }else{
                    rtnValue = "iMOBIS SSO Error.";
                }
                if( logger.isErrorEnabled() ){
                    logger.error("→ imobis WEB SERVICE RTN : outUsrId        [" + outUsrId + "]");
                    logger.error("→ imobis WEB SERVICE RTN : retrunValueWS   [" + retrunValueWS + "]");
                }
            }else{
                rtnValue = "iMOBIS SSO Error.";
            }
        }catch(ClientProtocolException e){
            rtnValue = "iMOBIS SSO Error.";
        }catch(IOException e){
            rtnValue = "iMOBIS SSO Error.";
        }catch(Exception e){
            rtnValue = "iMOBIS SSO Error.";
        }
        HashMap<String,String> rtnMap = new HashMap<String,String>();
        rtnMap.put("RTNERRMSG",rtnValue);
        rtnMap.put("OUTUSRID",outUsrId);
        rtnMap.put("RTNVALUE",retrunValueWS);
        
        
        return rtnMap;
    }
    
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommIndexService#selectSsoFromPortalCheck(java.lang.String)
     */
    @Override
    public HashMap<String, String> selectSsoFromPortalCheck(String ssoEncData) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSsoFromPortalCheck::start");
        }
        
        
        /* 기본 정보 */
        String df = "yyyy.MM.dd HH:mm:ss.SSS";
        Locale locale = Locale.getDefault();
        /* 암복호화 정보 */
        String encData = null;  // 암호화된 QueryString
        String decData = null;  // 복호화된 QueryString
        Map<String, List<String>> params = null;    // 복호화 파라미터
        /* 복호화 파라미터 데이터 */
        String sapLangCd = null;    // SAP언어코드
        String userId = null;       // 사용자ID
        Calendar carExpried = Calendar.getInstance();   // 페이지 만료일시
        String dfExpried = "yyyyMMddHHmmss"; // 년월일시분초
        
        
        /* 복호화 */
        // 포탈로부터 SSO는 다음과 같이 전달된다.
        // USER_ID=로그인ID&timestamp=년월일시분초(현재시각)&locale=언어코드
        // ssoEncData=암호화된값 
        encData = ssoEncData;
        if (StringUtils.isBlank(encData)) {
            if (logger.isDebugEnabled()) {
                logger.debug("→ selectSsoFromPortalCheck::encData[" + encData + "]");
            }
            throw new MapsBizException(messageSource, "ECI0000020");   //암호화된 파라미터정보가 없습니다.
        }
        // QueryString 복호화
        decData = SecureUtils.decryptAES256ForMapsSso(encData);
        // QueryString 파라미터정보맵 취득
        params = HttpUtil.parseQueryString(decData);
        if (params.isEmpty()) {
            logger.error("★ selectSsoFromPortalCheck::Parameter is null");
            throw new MapsBizException(messageSource, "ECI0000021");    //복호화된 파라미터정보가 없습니다.
        }
        
        
        /* 파리미터정보 설정 */
        sapLangCd =  HttpUtil.getParseQueryStringValue(params, "locale");
        // 사용자ID 취득
        userId = HttpUtil.getParseQueryStringValue(params, "USER_ID");
        // 페이지만료일시 취득
        String expriedDt = HttpUtil.getParseQueryStringValue(params, "timestamp");
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSsoFromPortalCheck::encData[" + encData + "][sapLangCd=" + sapLangCd + ",userId=" + userId +  ",expriedDt=" + expriedDt + "]" );
        }
        //locale = getLocale(sapLangCd);
        if (StringUtils.isBlank(userId)) {
            throw new MapsBizException(messageSource, "ECI0000022");   //사용자ID는 필수입력입니다.
        }
        if (NumberUtils.isDigits(expriedDt)) {
            carExpried.setTime(DateUtil.stringToDate(expriedDt, dfExpried));
            Calendar now = Calendar.getInstance();
            now.add(Calendar.SECOND, -150);
            if (carExpried.before(now)) {
                logger.error("★ selectSsoFromPortalCheck::Expried[now=" + DateUtil.toString(now.getTime(), df, locale) + ",ms=" + DateUtil.toString(carExpried.getTime(), df, locale) + "]");
                throw new MapsBizException(messageSource, "ECI0000023");   //페이지가 만료되었습니다.
            }
        } else {
            throw new MapsBizException(messageSource, "ECI0000024");    //만료일시 형식이 아닙니다.
        }
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSsoFromPortalCheck::end");
        }
        
        
        HashMap<String,String> rtnMap = new HashMap<String,String>();
        rtnMap.put("IMOBIS_SESSION_LOCALECD", sapLangCd);
        rtnMap.put("IMOBIS_SESSION_USERID", userId);
        return rtnMap;
    }
}
