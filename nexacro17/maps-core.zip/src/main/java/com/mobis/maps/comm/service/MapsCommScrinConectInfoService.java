package com.mobis.maps.comm.service;

import com.mobis.maps.comm.vo.MapsCommScrinConectInfoVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;

/**
 * <pre>
 * 화면접속정보 서비스
 * </pre>
 *
 * @ClassName   : MapsCommScrinConectInfoService.java
 * @Description : 화면접속정보에 대한 서비스를 정의한다.
 * @author DT048058
 * @since 2020. 1. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 30.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsCommScrinConectInfoService {

    /**
     * 화면정보 조회
     *
     * @param commScrinConectInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamScreenVO selectScrinInfo(MapsCommScrinConectInfoVO commScrinConectInfoVO) throws Exception;
    
    /**
     * 화면접속정보 등록
     *
     * @param commScrinConectInfoVO
     * @throws Exception
     */
    public void insertScrinConectInfo(MapsCommScrinConectInfoVO commScrinConectInfoVO) throws Exception;
    
}
