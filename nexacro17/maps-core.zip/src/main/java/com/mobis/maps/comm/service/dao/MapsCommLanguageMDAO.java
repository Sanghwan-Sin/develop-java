package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommLanguageVO;
import com.mobis.maps.comm.vo.MapsCommScrinFnctVO;

/**
 * <pre>
 * 다국어 관리 데이터처리
 * </pre>
 *
 * @ClassName   : MapsCommLanguageMDAO.java
 * @Description : 다국어 관리 데이터처를 정의.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
@Mapper("mapsCommLanguageMDAO")
public interface MapsCommLanguageMDAO {

    /**
     * 다국어 리스트 조회
     *
     * @param commLanVO
     * @return
     * @throws Exception
     */
    public List<MapsCommLanguageVO> selectLangList(MapsCommLanguageVO commLangVO) throws Exception;
    
    /**
     * 화면기능 리스트 조회
     *
     * @param commScrinFnctVO
     * @return
     * @throws Exception
     */
    public List<MapsCommScrinFnctVO> selectScrinFnctList(MapsCommScrinFnctVO commScrinFnctVO)  throws Exception;
    
    /**
     * 용어 조회
     *
     * @param commLanVO
     * @return
     * @throws Exception
     */
    public String selectWord(MapsCommLanguageVO commLangVO)  throws Exception;
    
}
