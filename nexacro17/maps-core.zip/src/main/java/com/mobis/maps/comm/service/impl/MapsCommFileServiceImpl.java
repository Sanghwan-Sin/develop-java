package com.mobis.maps.comm.service.impl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.service.HService;
import able.com.service.file.FileDownloadService;
import able.com.service.file.FileUploadService;
import able.com.service.file.FileVO;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartException;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.constants.MimeType;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.exception.MapsRuntimeException;
import com.mobis.maps.cmmn.exception.MapsTmplatDwnlException;
import com.mobis.maps.cmmn.util.FileUploadUtil;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.constants.MapsCommExcelTmplat;
import com.mobis.maps.comm.constants.MapsSapRfcInfo;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.constants.SapAtchSysId;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.comm.service.MapsCommSapAtchFileService;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.comm.service.dao.MapsCommAtchFileMDAO;
import com.mobis.maps.comm.vo.MapsCommFileExtVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileCntVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * 공통 파일 관리 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommFileServiceImpl.java
 * @Description : 공통 파일 관리에 대한 서비스를 구현.
 * @author Sin Sanghwan
 * @since 2019. 8. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 8.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Service("mapsCommFileService")
public class MapsCommFileServiceImpl extends HService implements MapsCommFileService {
    
    private final static String SYSID_KEY = "sapcode.pc.sys.id" ;
    private final static String MANDT_KEY = "sapcode.pc.sys.client";
   
    
    @Resource(name="fileUploadService")
    private FileUploadService fileUploadService;
    
    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
        
    @Resource(name="mapsCommAtchFileMDAO")
    private MapsCommAtchFileMDAO mapsCommAtchFileMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectAtchFileList(java.lang.String, java.lang.String)
     */
    @Override
    public List<MapsAtchFileVO> selectAtchFileList(MapsAtchFileVO atchFileVO) throws Exception {
        //logger.debug("→ selectAtchFile.start[atchSe=" + atchFileVO.getAtchSe() + ",atchId=" + atchFileVO.getAtchId() + "]");
        
        List<MapsAtchFileVO> lstAtchFile = mapsCommAtchFileMDAO.selectAtchFileList(atchFileVO);
        
        return lstAtchFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#multiAtchFile(com.mobis.maps.cmmn.constants.AtchFileSe, java.lang.Object, java.util.List)
     */
    @Override
    public int multiAtchFile(AtchFileSe atchFileSe
            , Object atchFileBaseInfo
            , List<MapsAtchFileVO> atchFiles) throws Exception {
        
        String atchId = atchFileSe.getAtchId(atchFileBaseInfo);
       
        return multiAtchFile(atchFileSe.name(), atchId, atchFiles);
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#multiAtchFile(java.lang.String, java.lang.String, java.util.List)
     */
    @Override
    public int multiAtchFile(String atchSe
            , String atchId
            , List<MapsAtchFileVO> atchFiles) throws Exception {
        
        int procCnt = 0;
        
        for (MapsAtchFileVO atchFile: atchFiles) {
            
            atchFile.setAtchSe(atchSe);
            atchFile.setAtchId(atchId);
            
            mapsCommAtchFileMDAO.insertAtchFile(atchFile);
            
            procCnt++;
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#deleteAtchFile(com.mobis.maps.cmmn.vo.MapsAtchFileVO)
     */
    @Override
    public int deleteAtchFile(MapsAtchFileVO atchFileVO) throws Exception {
        
        int procCnt = 0;

        MapsAtchFileVO atchFile = mapsCommAtchFileMDAO.selectAtchFile(atchFileVO);
        
        if (atchFile != null) {
            
            procCnt = mapsCommAtchFileMDAO.deleteAtchFile(atchFile);
            
            FileUploadUtil.removeFile(atchFile.getStoredFileFullPath());
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#deleteAtchFileAll(java.lang.String, java.lang.String)
     */
    @Override
    public int deleteAtchFileAll(MapsAtchFileVO atchFileVO) throws Exception {

        List<MapsAtchFileVO> lstAtchFile = mapsCommAtchFileMDAO.selectAtchFileList(atchFileVO);
        
        int procCnt = 0;
        
        procCnt = mapsCommAtchFileMDAO.deleteAtchFileAll(atchFileVO);
        
        for (MapsAtchFileVO atchFile: lstAtchFile) {

            FileUploadUtil.removeFile(atchFile.getStoredFileFullPath());
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectAtchFileUpload(javax.servlet.http.HttpServletRequest, java.lang.String, java.lang.String)
     */
    @Override
    public List<MapsAtchFileVO> selectAtchFileUpload(HttpServletRequest request, String atchSe) throws Exception {
            
        AtchFileSe atchFileGubn = AtchFileSe.get(atchSe);
        
        String storedFilePath = FileUploadUtil.getStoredFolder(atchFileGubn.getSubFolder());
        
        List<FileVO> lstFile = null;
        try {
            lstFile = fileUploadService.upload(request, storedFilePath);
        } catch (MultipartException e) {
            throw new MapsBizException(e.getMessage(), e);
        }
        
        List<MapsAtchFileVO> lstAtchFile = new ArrayList<MapsAtchFileVO>();
        for (FileVO fileVO: lstFile) {
            
            MapsAtchFileVO atchFile = new MapsAtchFileVO();
            BeanUtils.copyProperties(atchFile, fileVO);
            
            atchFile.setAtchSe(atchSe);
            atchFile.setFolderPath(storedFilePath);
            
            lstAtchFile.add(atchFile);
        }
        
        return lstAtchFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectAtchFileDownload(com.mobis.maps.cmmn.vo.MapsAtchFileVO, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selectAtchFileDownload(
            MapsAtchFileVO atchFileVO
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        MapsAtchFileVO atchFile = mapsCommAtchFileMDAO.selectAtchFile(atchFileVO);
        
        String folderPath = FileUploadUtil.getFileFolder(atchFile.getFolderPath());
//        if (logger.isDebugEnabled()) {
//            logger.debug("→ selectAtchFileDownload[folderPath=" + folderPath + "]");
//        }
        String browser = this.getBrowser(request);
        String originalFileNm = this.getEncodedFileName(atchFile.getOriginalFileName(), browser , true);
        atchFile.setOriginalFileName(originalFileNm);
        
        
        atchFile.setFolderPath(folderPath);
        
        FileDownloadService.fileDown(atchFile, request, response);
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectAtchFileImageViewer(com.mobis.maps.cmmn.vo.MapsAtchFileVO, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selectAtchFileImageViewer(
            MapsAtchFileVO atchFileVO
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        
        MapsAtchFileVO atchFile = mapsCommAtchFileMDAO.selectAtchFile(atchFileVO);
        
        String folderPath = FileUploadUtil.getFileFolder(atchFile.getFolderPath());
        
        File file = new File(folderPath, atchFile.getStoredFileName());
        
        //logger.debug("→ selectAtchFileImageViewer::file1[path=" + file.getPath() + "]");
        // 파일이 없으면 NO IMAGE 호출
        if (file == null || !file.exists() || !file.isFile()) {
            String noImgPath = request.getSession().getServletContext().getRealPath("/ui/_resource_/_images_/img_noimg.png");
            file = new File(noImgPath);
        }
        if (file.exists() && file.isFile()) {

            selectFileDownload(file, atchFile.getOriginalFileName(), request, response, true);
        }
        
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectFileUpload(javax.servlet.http.HttpServletRequest)
     */
    @Override
    public File selectFileUpload(HttpServletRequest request) throws Exception {
        
        String storedFilePath = FileUploadUtil.getStoredFolder("upload");
        
        List<FileVO> lstFile = fileUploadService.upload(request, storedFilePath);
        
        FileVO fileVO = lstFile.get(0);
        
        File fUp = new File(FileUploadUtil.getFileFolder(storedFilePath, fileVO.getStoredFileName()));
//        if (logger.isDebugEnabled()) {
//            logger.debug("→ selectFileUpload::fUp[folderPath=" + fUp.getPath() + "]");
//        }
        
        return fUp;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectTmplatFileDownload(java.lang.String, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selectTmplatFileDownload(String tmplatId
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        String fileNm = tmplatId.concat(".xlsx");

        try {
            String tmplatPath = request.getSession().getServletContext().getRealPath("/templates/" + fileNm);
            if (logger.isDebugEnabled()) {
                logger.debug("→ selectTmplatDownload::request[tmplatPath=" + tmplatPath + "]");
            }
    
            FileDownloadService.fileDown(tmplatPath, fileNm, request, response);
        } catch (Exception e) {
            throw new MapsTmplatDwnlException(e.getMessage(), e);
        }
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectExcelTmplatFileDownload(java.lang.String, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selectExcelTmplatFileDownload(String tmplatId
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        
        MapsCommExcelTmplat commExcelTmplat = MapsCommExcelTmplat.getMapsCommExcelTmplat(tmplatId);
        
        if (commExcelTmplat == null) {
            throw new MapsTmplatDwnlException(messageSource, "ECI0000016");    //액셀 템플릿 설정을 확인하여 주시기 바랍니다.
        }

//        File fTmplat = commExcelTmplat.getTmplatFile();
//        if (logger.isDebugEnabled()) {
//            logger.debug("→ selectTmplatDownload::"+tmplatId+"[tmplatPath=" + fTmplat.getPath() + "]");
//        }
        InputStream is = commExcelTmplat.getTmplatStream();
        String fileNm = commExcelTmplat.getFileNm();
        int fileSize = is.available();
        
        try {
            selectFileDownload(is, fileNm, fileSize, request, response, false);
        } catch (Exception e) {
            throw new MapsTmplatDwnlException(e.getMessage(), e);
        }
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectScrinNm(java.lang.String, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsIamScreenVO selectScrinNm(String scrinId, LoginInfoVO loginInfo) throws Exception {
        // 화면명 조회 조건 설정
        MapsIamScreenVO iamScreenCondVO = new MapsIamScreenVO();
        iamScreenCondVO.setScrinId(scrinId);
        iamScreenCondVO.setLangCd(loginInfo.getLangCd());
        // 화면명 조회
        MapsIamScreenVO iamScreenVO = mapsCommAtchFileMDAO.selectScrinNm(iamScreenCondVO);
        
        return iamScreenVO;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectMnlFileDownload(java.lang.String, java.lang.String, com.mobis.maps.cmmn.vo.LoginInfoVO, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selectMnlFileDownload(String scrinId
            , String dwnlMode
            , LoginInfoVO loginInfo
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        
        String fileNm = scrinId.concat(".pdf");

        try {
            /* 메뉴얼 패스 취득 */
            String mnlPath = request.getSession().getServletContext().getRealPath("/manual/" + fileNm);
            if (logger.isDebugEnabled()) {
                logger.debug("→ selectMnlFileDownload::request[fileNm="+fileNm+",mnlPath=" + mnlPath + "]");
            }
            File fMnl = new File(mnlPath);
            if (!fMnl.exists()) {
                // 메뉴얼을 찾을 수 없습니다.
                throw new MapsTmplatDwnlException(messageSource, "ECI0000089", loginInfo.getUserLcale(), null);
            }
            
            /* 화면명취득 */
            // 화면명 조회
            MapsIamScreenVO iamScreenVO = selectScrinNm(scrinId, loginInfo);
            if (iamScreenVO == null) {
                // 메뉴얼을 찾을 수 없습니다.
                throw new MapsTmplatDwnlException(messageSource, "ECI0000089", loginInfo.getUserLcale(), null);
            }
            // 메뉴얼파일명 설정
            StringBuilder sbFileNm = new StringBuilder();
            sbFileNm.append("[");
            sbFileNm.append(iamScreenVO.getScrinCd());
            sbFileNm.append("]");
            sbFileNm.append(FileUploadUtil.convertDwlnFileNm(iamScreenVO.getScrinNm()));
            sbFileNm.append(".pdf");

            /* 메뉴얼 다운로드 */
            selectFileDownload(new File(mnlPath), sbFileNm.toString(), request, response, StringUtils.equals(dwnlMode, "V"));
        } catch (Exception e) {
            throw new MapsTmplatDwnlException(e.getMessage(), e);
        }
    }

    /**
     * RFC 시스템 취득
     *
     * @param commSapRfcIfCommVO
     * @return
     * @throws Exception
     */
    private RfcSapSys selectGetRfcSapSys(MapsCommSapRfcIfCommVO commSapRfcIfCommVO) throws Exception {
        RfcSapSys rfcSapSys = RfcSapSys.get(commSapRfcIfCommVO.getSysId());
        if (rfcSapSys == null) {
            return RfcSapSys.PC;
        }
        return rfcSapSys;
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapAtchFileList(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileVO> selectSapAtchFileList(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileList::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_LIST;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_LIST, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<MapsCommSapAtchFileVO> lstSapFiles = MapsRfcMappperUtil.getExportTableValues(funcRslt, FIELD_TARGET_IT_ATTACH, MapsCommSapAtchFileVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileList::end");
        }
        
        return lstSapFiles;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileVO selectSapAtchFileDetail(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileDetail::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_CONTENT;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_CONTENT, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileVO commSapAtchFile = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileDetail::end");
        }
        
        return commSapAtchFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapAtchFileCnt(com.mobis.maps.comm.vo.MapsCommSapAtchFileInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileInfoVO selectSapAtchFileCnt(MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileCnt::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_COUNT;
        commSapAtchFileInfoVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileInfoVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileInfoVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_COUNT, commSapAtchFileInfoVO);
        
        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileInfoVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileInfoVO sapAtchFileCntInfo = MapsRfcMappperUtil.getExportStructure(funcRslt, FIELD_TARGET_ES_ATTACH_COUNT, MapsCommSapAtchFileInfoVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileCnt::end");
        }
        
        return sapAtchFileCntInfo;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapAtchFileCntList(com.mobis.maps.comm.vo.MapsCommSapAtchFileCntVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileCntVO> selectSapAtchFileCntList(MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , List<MapsCommSapAtchFileCntVO> refNos
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileCntList::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_ITEM_SUM;
        commSapAtchFileCntVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileCntVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileCntVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, commSapAtchFileCntVO);
        
        for (MapsCommSapAtchFileCntVO refNoVO : refNos) {
            MapsRfcMappperUtil.appendImportStructureTableRow(func, FIELD_TARGET_I_REF_NO_T, refNoVO);
        }
        

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileCntVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<MapsCommSapAtchFileCntVO> lstSapAtchFileCnt = MapsRfcMappperUtil.getExportTableValues(funcRslt, FIELD_TARGET_IT_ATTACH_SUM, MapsCommSapAtchFileCntVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileCntList::end");
        }
        
        return lstSapAtchFileCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapAtchFileSumryCnt(com.mobis.maps.comm.vo.MapsCommSapAtchFileCntVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileCntVO> selectSapAtchFileSumryCnt(MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , List<MapsCommSapAtchFileCntVO> refNos
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileSumryCnt::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_ITEM_SUM2;
        commSapAtchFileCntVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileCntVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileCntVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, commSapAtchFileCntVO);
        for (MapsCommSapAtchFileCntVO refNoVO : refNos) {
            MapsRfcMappperUtil.appendImportStructureTableRow(func, FIELD_TARGET_I_REF_NO_T, refNoVO);
        }

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileCntVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<MapsCommSapAtchFileCntVO> lstSapFileSumryCnt = MapsRfcMappperUtil.getExportTableValues(funcRslt,  FIELD_TARGET_IT_ATTACH_SUM, MapsCommSapAtchFileCntVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileSumryCnt::end");
        }
        
        return lstSapFileSumryCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapAtchFileInfo(com.mobis.maps.comm.vo.MapsCommSapAtchFileInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, MapsCommSapAtchFileInfoVO> selectSapAtchFileRegistInfo(MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileInfo::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_CREATE_INFO;
        commSapAtchFileInfoVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileInfoVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileInfoVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_INFO, commSapAtchFileInfoVO);
        
        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileInfoVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        Map<String, MapsCommSapAtchFileInfoVO> mSapFileInfo = new HashMap<String, MapsCommSapAtchFileInfoVO>();
        
        MapsCommSapAtchFileInfoVO esConfig = MapsRfcMappperUtil.getExportStructure(funcRslt, FIELD_TARGET_ES_CONFIG, MapsCommSapAtchFileInfoVO.class);
        mSapFileInfo.put(MAP_KEY_ES_CONFIG, esConfig);
        MapsCommSapAtchFileInfoVO esMaster = MapsRfcMappperUtil.getExportStructure(funcRslt, FIELD_TARGET_ES_MASTER, MapsCommSapAtchFileInfoVO.class);
        mSapFileInfo.put(MAP_KEY_ES_MASTER, esMaster);
        MapsCommSapAtchFileInfoVO esCreate = MapsRfcMappperUtil.getExportStructure(funcRslt, FIELD_TARGET_ES_CREATE, MapsCommSapAtchFileInfoVO.class);
        mSapFileInfo.put(MAP_KEY_ES_CREATE, esCreate);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileInfo::end");
        }
        
        return mSapFileInfo;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#multiSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileVO> multiSapAtchFile(
            MapsCommSapAtchFileVO commSapAtchFileVO
            , List<MapsCommSapAtchFileVO> sapAtchFiles
            , LoginInfoVO loginInfo) throws Exception {
        
        List<MapsCommSapAtchFileVO> rsltSapFiles = new ArrayList<MapsCommSapAtchFileVO>();
        for (MapsCommSapAtchFileVO commSapAtchFile: sapAtchFiles) {
            MapsCommSapAtchFileVO rsltMapsFile = insertSapAtchFile(commSapAtchFile, loginInfo);
            rsltSapFiles.add(rsltMapsFile);
        }
        return rsltSapFiles;
    }


//    /**
//     * Statements
//     *
//     * @param commSapAtchFileChkVO
//     * @param loginInfo
//     * @return
//     * @throws Exception
//     */
//    private MapsCommSapAtchFileChkVO selectSapAtchFileChk(MapsCommSapAtchFileChkVO commSapAtchFileChkVO
//            , LoginInfoVO loginInfo) throws Exception {
//        if (logger.isDebugEnabled()) {
//            logger.debug("→ selectSapAtchFileChk::start");
//        }
//        /* RFC Function 취득 */
//        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_CONTENT;
//        commSapAtchFileChkVO.setIfCode(sapRfcInfo.getIfCode());
//        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileVO));
//
//        /* RFC 파라미터(Import) 셋팅 */
//        // 공통파라미터(Import) 셋팅
//        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileChkVO);
//        // 파라미터(Import) 셋팅
//        MapsRfcMappperUtil.setImportParamList(func, commSapAtchFileChkVO);
//
//        /* RFC 호출 */
//        // RFC 호출 실행
//        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
//        // RFC 호출 공통결과 정보 추출
//        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileChkVO);
//        
//        /* RFC 호출 조회정보 추출 */
//        // 조회정보 매핑정보 생성
//        MapsCommSapAtchFileChkVO esFileChk = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileChkVO.class);
//        
//        if (logger.isDebugEnabled()) {
//            logger.debug("→ selectSapAtchFileChk::end");
//        }
//        return esFileChk;
//    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#insertSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileVO insertSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ insertSapAtchFile::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_CREATE;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_CREATE, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        // RFC 호출 애러처리
        if (StringUtils.equals(commSapAtchFileVO.getMsgType(), MapsConstants.MESSAGE_TYPE_ERROR)) {
            throw new MapsBizException(commSapAtchFileVO.getMsg());
        }
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileVO rsltSapFile = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ insertSapAtchFile::end");
        }
        
        return rsltSapFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#updateSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileVO updateSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ updateSapAtchFile::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_UPDATE;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_UPDATE, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        // RFC 호출 애러처리
        if (StringUtils.equals(commSapAtchFileVO.getMsgType(), MapsConstants.MESSAGE_TYPE_ERROR)) {
            throw new MapsBizException(commSapAtchFileVO.getMsg());
        }
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileVO rsltSapFile = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ updateSapAtchFile::end");
        }
        
        return rsltSapFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#deleteSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileVO deleteSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ deleteSapAtchFile::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_DELETE;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_DELETE, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        // RFC 호출 애러처리
        if (StringUtils.equals(commSapAtchFileVO.getMsgType(), MapsConstants.MESSAGE_TYPE_ERROR)) {
            throw new MapsBizException(commSapAtchFileVO.getMsg());
        }
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileVO rsltSapFile = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ deleteSapAtchFile::end");
        }
        
        return rsltSapFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#deleteAllSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileVO> deleteAllSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ deleteAllSapAtchFile::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_DELETE_ALL;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name(), selectGetRfcSapSys(commSapAtchFileVO));

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_ALL_DELETE, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        // RFC 호출 애러처리
        if (StringUtils.equals(commSapAtchFileVO.getMsgType(), MapsConstants.MESSAGE_TYPE_ERROR)) {
            throw new MapsBizException(commSapAtchFileVO.getMsg());
        }
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<MapsCommSapAtchFileVO> rsltSapFiles = MapsRfcMappperUtil.getExportTableValues(funcRslt,  FIELD_TARGET_IT_ATTACH, MapsCommSapAtchFileVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ deleteAllSapAtchFile::end");
        }
        
        return rsltSapFiles;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#deleteSelectdSapAtchFile(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileVO> deleteSelectdSapAtchFile(List<MapsCommSapAtchFileVO> sapAtchFiles
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ deleteSelectdSapAtchFile::start");
        }
        
        List<MapsCommSapAtchFileVO> rsltSapFiles = new ArrayList<MapsCommSapAtchFileVO>();
        
        for (MapsCommSapAtchFileVO commSapAtchFileVO: sapAtchFiles) {
        
            if (!StringUtils.equals(commSapAtchFileVO.getRowSe(), MapsConstants.ROW_SE_DELETE)) {
                continue;
            }
            
            MapsCommSapAtchFileVO rsltSapFile = deleteSapAtchFile(commSapAtchFileVO, loginInfo);
            rsltSapFiles.add(rsltSapFile);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("→ deleteSelectdSapAtchFile::end");
        }
        return rsltSapFiles;
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapAtchFileUpload(javax.servlet.http.HttpServletRequest, java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileVO> selectSapAtchFileUpload(
            HttpServletRequest request
            , String sysSeCd
            , String sysId
            , String fscode
            , String refNo
            , String sameFileNmWithRefNo
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileUpload.start[sysSeCd=" + sysSeCd + ",sysId=" + sysId +",fscode=" + fscode +",refNo=" + refNo +",sameFileNmWithRefNo=" + sameFileNmWithRefNo +"]");
        }
        List<MapsCommSapAtchFileVO> lstSapAtchFile = new ArrayList<MapsCommSapAtchFileVO>();
        
        AtchFileSe atchFileGubn = AtchFileSe.SAPATCH;
        
        String storedFilePath = FileUploadUtil.getStoredFolder(atchFileGubn.getSubFolder());
        
        List<FileVO> lstFile = fileUploadService.upload(request, storedFilePath);
        for (FileVO fileVO: lstFile) {
            
            String fileNm = fileVO.getOriginalFileName();
            long fileSize = fileVO.getFileSize();
            File fOriginalFile = new File(fileVO.getFolderPath(), fileVO.getStoredFileName());
            String fileSysid = SapAtchSysId.get(sysSeCd).name();
            if (logger.isDebugEnabled()) {
                logger.debug("→ selectSapAtchFileUpload.init::FileVO[fileSysid="+fileSysid+",fileNm="+fileNm+",fileSize="+fileSize+",fOriginalFile="+fOriginalFile.getPath()+"]");
            }
            
            MapsCommSapAtchFileVO sapAtchFile = new MapsCommSapAtchFileVO();
            sapAtchFile.setRnum(sapAtchFile.getRnum() + 1);
            sapAtchFile.setFileSysid(fileSysid);
            sapAtchFile.setFscode(fscode);
            sapAtchFile.setRefNo(refNo);
            
            // 파일명을 셋팅하게 해달라는 요구사항
            if(StringUtils.equals(sameFileNmWithRefNo, "Y")){
                String ext = FilenameUtils.getExtension(fileNm); // returns "txt"
                String fileNmRefNo = refNo + "." + ext;
                logger.debug("→ selectSapAtchFileUpload.sameFileNmWithRefNo Y ::fileNmRefNo :" + fileNmRefNo + "]");
                sapAtchFile.setFileName(fileNmRefNo);
            }else{
                sapAtchFile.setFileName(fileNm);
            }
            sapAtchFile.setFileLen(fileSize);
            sapAtchFile.setOriginalFile(fOriginalFile);

            lstSapAtchFile.add(sapAtchFile);
        }

        int rnum = 0;
        File fDest = null;
        try {
            
            MapsCommSapAtchFileInfoVO aspAtchFileInfo = new MapsCommSapAtchFileInfoVO();
            aspAtchFileInfo.setSysId(sysId);
            aspAtchFileInfo.setFscode(fscode);
            aspAtchFileInfo.setRefNo(refNo);
            for (MapsCommSapAtchFileVO sapAtchFile: lstSapAtchFile) {
                
                //2020.05.28 lee.jp  수정 
                sapAtchFile.setSysId(sysId);
                rnum = sapAtchFile.getRnum();
                fDest = null;
                
                Map<String, MapsCommSapAtchFileInfoVO> mFileInfo = selectSapAtchFileRegistInfo(aspAtchFileInfo, loginInfo);
                /* */
                MapsCommSapAtchFileInfoVO sapAtchFileInfoConfig = mFileInfo.get(MapsCommSapAtchFileService.MAP_KEY_ES_CONFIG);
                String rootdir = sapAtchFileInfoConfig.getRootdir();
                long fileMaxLen = sapAtchFileInfoConfig.getFileMaxLen();
                int fileMaxCount = sapAtchFileInfoConfig.getFileMaxCount();
                if (logger.isDebugEnabled()) {
                    logger.debug("→ selectSapAtchFileUpload::sapAtchFileInfoConfig["+rnum+"][rootdir="+rootdir+",fileMaxLen="+fileMaxLen+",fileMaxCount="+fileMaxCount+"]");
                }
                
                long fileLen = sapAtchFile.getFileLen();
                if (fileLen > fileMaxLen) {
                    throw new MapsBizException(messageSource, "ECI0000017", new String[]{String.valueOf(fileMaxLen)}, loginInfo.getUserLcale(), null);   //등록 가능한 파일사이즈는 " + fileMaxLen + "Byte입니다.
                }
                /* */
                MapsCommSapAtchFileInfoVO sapAtchFileInfoMaster = mFileInfo.get(MapsCommSapAtchFileService.MAP_KEY_ES_MASTER);

                /* */
                MapsCommSapAtchFileInfoVO sapAtchFileInfoCreate = mFileInfo.get(MapsCommSapAtchFileService.MAP_KEY_ES_CREATE);
                int fileCnt = sapAtchFileInfoCreate.getRefNoSum();
                if (fileCnt >= fileMaxCount) {
                    throw new MapsBizException(messageSource, "ECI0000018", new String[]{String.valueOf(fileMaxCount)}, loginInfo.getUserLcale(), null);   //등록 가능한 파일은 " + fileMaxCount + "건입니다.
                }
                String filePathLeg = sapAtchFileInfoCreate.getFilePathLeg();
                String fileSeqno = sapAtchFileInfoCreate.getFileSeqno();
                
                /* 저장파일패스정보 설정 */
                String filePath = rootdir.concat(filePathLeg).concat(fileSeqno);
                if (logger.isDebugEnabled()) {
                    logger.debug("→ selectSapAtchFileUpload::sapAtchFileInfoMaster["+rnum+"][filePathLeg="+filePathLeg+",fileSeqno="+fileSeqno+",filePath="+filePath+"]");
                }
                sapAtchFile.setFileSeqno(fileSeqno);
                sapAtchFile.setFilePath(filePath);
                
                MapsCommSapAtchFileVO rsltSapAtchFile = null;
                File fOrigin = sapAtchFile.getOriginalFile();
                if (fOrigin.exists()) {
                    
                    fDest = FileUploadUtil.getSapFilePath(sapAtchFile.getFilePath());
                    if (!fDest.getParentFile().exists()) {
                        
                        FileUtils.forceMkdir(fDest.getParentFile());
                    }

                    FileUtils.moveFile(fOrigin, fDest);

                    rsltSapAtchFile = insertSapAtchFile(sapAtchFile, loginInfo);
//                    if (fOrigin.renameTo(fDest)) {
//
//                    } else {
//                        throw new BizException("이동중 애러가 발생했습니다.");
//                    }
                } else {
                    throw new MapsBizException(messageSource, "ECI0000019");   //원본파일이 존재하지 않습니다.
                }
                sapAtchFile = rsltSapAtchFile;
                if (logger.isDebugEnabled()) {
                    logger.debug("→ selectSapAtchFileUpload::insert["+rnum+"][MsgType="+sapAtchFile.getMsgType()+",Message="+sapAtchFile.getMsg()+"]");
                }
            }
        } catch (Exception e) {
            if (fDest != null && fDest.exists()) {
                fDest.delete();
            }
            MapsCommSapAtchFileVO errSapAtchFile = lstSapAtchFile.get(rnum - 1);
            errSapAtchFile.setMsgType(MapsConstants.MESSAGE_TYPE_ERROR);
            errSapAtchFile.setMsg(e.getMessage());
            if (logger.isDebugEnabled()) {
                logger.debug("→ selectSapAtchFileUpload::error["+rnum+"][MsgType="+errSapAtchFile.getMsgType()+",Message="+errSapAtchFile.getMsg()+"]");
            }
        } finally {
            for (FileVO fileVO: lstFile) {
                File fOrigin = new File(fileVO.getFolderPath(), fileVO.getStoredFileName());
                if (fOrigin.exists()) {
                    boolean isDeleted = fOrigin.delete();
                    if (logger.isDebugEnabled()) {
                        logger.debug("→ selectSapAtchFileUpload.finally::FileVO[fOrigin=" + fOrigin.getPath() + ",isDeleted=" + isDeleted +"]");
                    }
                }
            }
        }
        return lstSapAtchFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapAtchFileDownload(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selectSapAtchFileDownload(
            MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        MapsCommSapAtchFileVO commSapAtchFile = selectSapAtchFileDetail(commSapAtchFileVO, loginInfo);
        
        File file = FileUploadUtil.getSapFilePath(commSapAtchFile.getFilePath());
        if (file.exists() && file.isFile()) {

            selectFileDownload(file, commSapAtchFile.getFileName(), request, response, false);
        }
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapImageFileViewer(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selectSapImageFileViewer(
            MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        MapsCommSapAtchFileVO commSapAtchFile = selectSapAtchFileDetail(commSapAtchFileVO, loginInfo);

        File file = FileUploadUtil.getSapFilePath(commSapAtchFile.getFilePath());
        // 파일이 없으면 NO IMAGE 호출
        if (file == null || !file.exists() || !file.isFile()) {
            String noImgPath = request.getSession().getServletContext().getRealPath("/ui/_resource_/_images_/img_noimg.png");
            file = new File(noImgPath);
        }
        if (file.exists() && file.isFile()) {

            selectFileDownload(file, commSapAtchFile.getFileName(), request, response, true);
        }
    }

    /**
     * File Download
     *
     * @param file
     * @param fileNm
     * @param request
     * @param response
     * @param isViewer
     * @throws Exception
     */
    @Override
    public void selectFileDownload(File file, String fileNm, HttpServletRequest request, HttpServletResponse response, boolean isViewer) throws Exception {
        selectFileDownload(new FileInputStream(file), fileNm, (int)file.length(), request, response, isViewer);
    }

//    /**
//     * File Download
//     *
//     * @param buf
//     * @param fileNm
//     * @param request
//     * @param response
//     * @param isViewer
//     * @throws Exception
//     */
//    private void selectFileDownload(byte[] buf, String fileNm, HttpServletRequest request, HttpServletResponse response, boolean isViewer) throws Exception {
//
//        selectFileDownload(new ByteArrayInputStream(buf), fileNm, buf.length, request, response, isViewer);
//    }
    
    /**
     * File Download
     *
     * @param response
     * @param fileNm
     * @param fileBuf
     * @throws Exception
     */
    @Override
    public void selectFileDownload(InputStream is, String fileNm, int fileSize, HttpServletRequest request, HttpServletResponse response, boolean isViewer) throws Exception {

        //String header = request.getHeader("User-Agent");
        String browser = this.getBrowser(request);
        // 브라우저별 파일명 인코딩 진행
        String fileNmEncoded = this.getEncodedFileName(fileNm, browser ,false);
        // 추가 수정 ==> 파일명에 , 있는 경우 대응(크롬은 파일명에 , 가 있으면 오류남);
        //response.setHeader("Content-Disposition", "attachment;filename=\"" + fileNmEncoded + "\"");
        if ( browser.contains("Chrome") ) {
            response.setHeader("Content-Disposition", "attachment; filename=\"" + fileNmEncoded + "\"");
        } else {
            response.setHeader("Content-Disposition", "attachment;filename=" + fileNmEncoded + ";");
        }
        
        
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectFiledown::[fileNm=" + fileNm + ",fileSize=" + fileSize +",encodeFileNm=" +fileNmEncoded +"]");
        }
        if (isViewer) {
            MimeType mimeType = MimeType.getByFileNm(fileNm);
            if (mimeType == null) {
                throw new MapsBizException(messageSource, "EC00000011", new String[]{ "MIME TYPE" }, null);
            }
            if (mimeType.isImage() || mimeType.isPdf()) {
                response.setContentType(mimeType.getMimeTy());
                response.setHeader("Content-Disposition", "inline;filename=" + fileNmEncoded + ";");
                response.setHeader("Content-Type", mimeType.getMimeTy());
            } else {
                throw new MapsBizException(messageSource, "EC00000011", new String[]{ "MIME TYPE" }, null);
            }
        } else {
            response.setContentType("application/download; UTF-8");
            response.setContentLength(fileSize);
            response.setHeader("Content-Type", "application/octet-stream");
            response.setHeader("Content-Transfer-Encoding", "binary;");
        }
        response.setHeader("Pragma", "no-cache;");
        response.setHeader("Expires", "-1;");
        
        BufferedInputStream fin = null;
        BufferedOutputStream outs = null;
        try {
            fin = new BufferedInputStream(is);
            outs = new BufferedOutputStream(response.getOutputStream());
            
            int bytes = 0;
            byte[] readByte = new byte[4096];
            while((bytes = fin.read(readByte)) > 0){
                outs.write(readByte, 0, bytes);
                outs.flush();
            }
        } catch (Exception e) {
            throw new MapsBizException(e.getMessage());
        } finally {
            if (fin != null) {
                try {
                    fin.close();
                } catch (IOException e) {
                    logger.error(MessageUtil.getErrorLog(e.getStackTrace()));
                }
            }
            if (outs != null) {
                try {
                    outs.flush();
                    outs.close();
                } catch (IOException e) {
                    logger.error(MessageUtil.getErrorLog(e.getStackTrace()));
                }
            }
        }
    }
    

    /**
     * 파일 다운로드 시 Cilent의 브라우저에 따라 파일명의 인코딩 설정
     *
     * @param filename
     * @param browser
     * @return
     * @throws Exception
     */
    private String getEncodedFileName(String filename, String browser , boolean useAbleFrame) throws Exception {
        
           String encodedFilename = null;
           if (browser.equals("MSIE")) {
            // 한글 파일명 깨짐현상을 해결하기 위해 URLEncoder.encode 메소드를 사용하는데,
               // 파일명에 공백이 존재할 경우 URLEncoder.encode 메소드에의해 공백이 '+' 로 변환됩니다.
               // 변환된 '+' 값을 다시 공백으로(%20)으로 replace처리하시면 됩니다.
               // \\+의 의미는 정규표현식에서 역슬래시(\)는 확장문자로
               // 역슬래시 다음에 일반문자가 오면 특수문자로 취급하고 
               // 역슬래시 다음에 특수문자가 오면 그 문자 자체를 의미 
               // 기존 파일명에 있던 '+' 는 URLEncoder.encode() 메소드에 의해 '%2B' 로 변환이 됩니다.
               // 일반 첨부파일일때는 동작하지 않아서 일단 온파일그대로
               // ableFramework FileDownloadService 일때는 그냥 넘겨야 한다. 
               // encodedFilename = URLEncoder.encode(filename, "UTF-8").replaceAll("\\+", "%20");
               if(useAbleFrame ){
                   encodedFilename = filename;
               }else{
                   encodedFilename = URLEncoder.encode(filename, "UTF-8").replaceAll("\\+", "%20");
               }
           } else if (browser.equals("Firefox")) {
                encodedFilename = "\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
           } else if (browser.equals("Opera")) {
                encodedFilename = "\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
           } else if (browser.equals("Chrome")) {
              StringBuffer sb = new StringBuffer();
              for (int i = 0; i < filename.length(); i++) {
                          char c = filename.charAt(i);
                          if (c > '~') {
                              sb.append(URLEncoder.encode("" + c, "UTF-8"));
                          } else {
                                // ASCII문자(0X00 ~ 0X7E)는 URLEncoder.encode를 적용하지 않는다.     
                              sb.append(c);
                          }
              }
              encodedFilename = sb.toString();
           } else {
              throw new MapsRuntimeException("Not supported browser");
           }
           return encodedFilename;
    }
    
    /**
     * request를 가지고 user request를 확인
     *
     * @param request
     * @return
     */
    private String getBrowser(HttpServletRequest request) {
        String userAgent = request.getHeader("User-Agent");
        if (userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("Trident") > -1) {
            // IE 버전 별 체크 >> Trident/7.0(IE 11), Trident/6.0(IE 10), Trident/5.0(IE 9) , Trident/4.0(IE 8)
            return "MSIE";
        } else if (userAgent.indexOf("Chrome") > -1) {
            return "Chrome";
        } else if (userAgent.indexOf("Opera") > -1) {
            return "Opera";
        } else if (userAgent.indexOf("Firefox") > -1) {
            return "Firefox";
        }
        return "Safari";
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectAtchFileExtInfo(com.mobis.maps.comm.vo.MapsCommFileExtVO)
     */
    @Override
    public List<MapsCommFileExtVO> selectAtchFileExtInfo(MapsCommFileExtVO atchFile) throws Exception {
        String sysId = PropertiesUtil.getString(SYSID_KEY);
        String mandt = PropertiesUtil.getString(MANDT_KEY); 
        atchFile.setSysId(sysId);
        atchFile.setMandt(mandt);
        return mapsCommAtchFileMDAO.selectAtchFileExtInfo(atchFile);
    }



    /*
     * @see com.mobis.maps.comm.service.MapsCommFileService#selectSapAtchFileUploadMulti(javax.servlet.http.HttpServletRequest, java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileVO> selectSapAtchFileUploadMulti(
            HttpServletRequest request
            , String sysSeCd
            , String sysId
            , String fscode
            , String sameFileNmWithRefNo
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileUploadMulti.start[sysSeCd=" + sysSeCd + ",sysId=" + sysId +",fscode=" + fscode +",sameFileNmWithRefNo=" + sameFileNmWithRefNo +"]");
        }
        List<MapsCommSapAtchFileVO> lstSapAtchFile = new ArrayList<MapsCommSapAtchFileVO>();
        
        AtchFileSe atchFileGubn = AtchFileSe.SAPATCH;
        
        String storedFilePath = FileUploadUtil.getStoredFolder(atchFileGubn.getSubFolder());
        
        List<FileVO> lstFile = fileUploadService.upload(request, storedFilePath);
        
        for (FileVO fileVO: lstFile) {
            String refNo = fileVO.getParamName(); // REF_NO
            String fileNm = fileVO.getOriginalFileName();
            long fileSize = fileVO.getFileSize();
            File fOriginalFile = new File(fileVO.getFolderPath(), fileVO.getStoredFileName());
            String fileSysid = SapAtchSysId.get(sysSeCd).name();
            
            if (logger.isDebugEnabled()) {
                logger.debug("→ selectSapAtchFileUploadMulti.init::FileVO[ParamName="+refNo+",fileSysid="+fileSysid+",fileNm="+fileNm+",fileSize="+fileSize+",fOriginalFile="+fOriginalFile.getPath()+"]");
            }
            
            MapsCommSapAtchFileVO sapAtchFile = new MapsCommSapAtchFileVO();
            sapAtchFile.setRnum(sapAtchFile.getRnum() + 1);
            sapAtchFile.setFileSysid(fileSysid);
            sapAtchFile.setFscode(fscode);
            sapAtchFile.setRefNo(refNo);
            
            // 파일명을 셋팅하게 해달라는 요구사항
            if(StringUtils.equals(sameFileNmWithRefNo, "Y")){
                String ext = FilenameUtils.getExtension(fileNm); // returns "txt"
                String fileNmRefNo = refNo + "." + ext;
                logger.debug("→ selectSapAtchFileUploadMulti.sameFileNmWithRefNo Y ::fileNmRefNo :" + fileNmRefNo + "]");
                sapAtchFile.setFileName(fileNmRefNo);
            }else{
                sapAtchFile.setFileName(fileNm);
            }
            sapAtchFile.setFileLen(fileSize);
            sapAtchFile.setOriginalFile(fOriginalFile);

            lstSapAtchFile.add(sapAtchFile);
        }

        
        int rnum = 0;
        File fDest = null;
        try {
            
            MapsCommSapAtchFileInfoVO aspAtchFileInfo = new MapsCommSapAtchFileInfoVO();
            aspAtchFileInfo.setSysId(sysId);
            aspAtchFileInfo.setFscode(fscode);
            for (MapsCommSapAtchFileVO sapAtchFile: lstSapAtchFile) {
                
                //2020.05.28 lee.jp  수정 
                sapAtchFile.setSysId(sysId);
                rnum = sapAtchFile.getRnum();
                fDest = null;
                
                // select SAP Attach Info
                aspAtchFileInfo.setRefNo(sapAtchFile.getRefNo());
                Map<String, MapsCommSapAtchFileInfoVO> mFileInfo = selectSapAtchFileRegistInfo(aspAtchFileInfo, loginInfo);
                // ***
                MapsCommSapAtchFileInfoVO sapAtchFileInfoConfig = mFileInfo.get(MapsCommSapAtchFileService.MAP_KEY_ES_CONFIG);
                String rootdir = sapAtchFileInfoConfig.getRootdir();
                long fileMaxLen = sapAtchFileInfoConfig.getFileMaxLen();
                int fileMaxCount = sapAtchFileInfoConfig.getFileMaxCount();
                if (logger.isDebugEnabled()) {
                    logger.debug("→ selectSapAtchFileUploadMulti::sapAtchFileInfoConfig["+rnum+"][rootdir="+rootdir+",fileMaxLen="+fileMaxLen+",fileMaxCount="+fileMaxCount+"]");
                }
                
                long fileLen = sapAtchFile.getFileLen();
                if (fileLen > fileMaxLen) {
                    throw new MapsBizException(messageSource, "ECI0000017", new String[]{String.valueOf(fileMaxLen)}, loginInfo.getUserLcale(), null);   //등록 가능한 파일사이즈는 " + fileMaxLen + "Byte입니다.
                }
                // ***
                MapsCommSapAtchFileInfoVO sapAtchFileInfoMaster = mFileInfo.get(MapsCommSapAtchFileService.MAP_KEY_ES_MASTER);

                // ***
                MapsCommSapAtchFileInfoVO sapAtchFileInfoCreate = mFileInfo.get(MapsCommSapAtchFileService.MAP_KEY_ES_CREATE);
                int fileCnt = sapAtchFileInfoCreate.getRefNoSum();
                if (fileCnt >= fileMaxCount) {
                    throw new MapsBizException(messageSource, "ECI0000018", new String[]{String.valueOf(fileMaxCount)}, loginInfo.getUserLcale(), null);   //등록 가능한 파일은 " + fileMaxCount + "건입니다.
                }
                String filePathLeg = sapAtchFileInfoCreate.getFilePathLeg();
                String fileSeqno = sapAtchFileInfoCreate.getFileSeqno();
                
                // *** 저장파일패스정보 설정
                String filePath = rootdir.concat(filePathLeg).concat(fileSeqno);
                if (logger.isDebugEnabled()) {
                    logger.debug("→ selectSapAtchFileUploadMulti::sapAtchFileInfoMaster["+rnum+"][filePathLeg="+filePathLeg+",fileSeqno="+fileSeqno+",filePath="+filePath+"]");
                }
                sapAtchFile.setFileSeqno(fileSeqno);
                sapAtchFile.setFilePath(filePath);
                
                MapsCommSapAtchFileVO rsltSapAtchFile = null;
                File fOrigin = sapAtchFile.getOriginalFile();
                if (fOrigin.exists()) {
                    
                    fDest = FileUploadUtil.getSapFilePath(sapAtchFile.getFilePath());
                    if (!fDest.getParentFile().exists()) {
                        
                        FileUtils.forceMkdir(fDest.getParentFile());
                    }

                    FileUtils.moveFile(fOrigin, fDest);

                    rsltSapAtchFile = insertSapAtchFile(sapAtchFile, loginInfo);
//                    if (fOrigin.renameTo(fDest)) {
//
//                    } else {
//                        throw new BizException("이동중 애러가 발생했습니다.");
//                    }
                } else {
                    throw new MapsBizException(messageSource, "ECI0000019");   //원본파일이 존재하지 않습니다.
                }
                sapAtchFile = rsltSapAtchFile;
                if (logger.isDebugEnabled()) {
                    logger.debug("→ selectSapAtchFileUploadMulti::insert["+rnum+"][MsgType="+sapAtchFile.getMsgType()+",Message="+sapAtchFile.getMsg()+"]");
                }
            }
        } catch (Exception e) {
            if (fDest != null && fDest.exists()) {
                fDest.delete();
            }
            MapsCommSapAtchFileVO errSapAtchFile = lstSapAtchFile.get(rnum - 1);
            errSapAtchFile.setMsgType(MapsConstants.MESSAGE_TYPE_ERROR);
            errSapAtchFile.setMsg(e.getMessage());
            if (logger.isDebugEnabled()) {
                logger.debug("→ selectSapAtchFileUploadMulti::error["+rnum+"][MsgType="+errSapAtchFile.getMsgType()+",Message="+errSapAtchFile.getMsg()+"]");
            }
        } finally {
            for (FileVO fileVO: lstFile) {
                File fOrigin = new File(fileVO.getFolderPath(), fileVO.getStoredFileName());
                if (fOrigin.exists()) {
                    boolean isDeleted = fOrigin.delete();
                    if (logger.isDebugEnabled()) {
                        logger.debug("→ selectSapAtchFileUploadMulti.finally::FileVO[fOrigin=" + fOrigin.getPath() + ",isDeleted=" + isDeleted +"]");
                    }
                }
            }
        }
        return lstSapAtchFile;

    }
}
