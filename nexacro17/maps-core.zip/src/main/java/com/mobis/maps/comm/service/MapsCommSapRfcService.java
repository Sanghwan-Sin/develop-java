package com.mobis.maps.comm.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapDestInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcBassInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIpttInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrFieldVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrMstVO;

/**
 * <pre>
 * RFC 관리 서비스
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcService.java
 * @Description : RFC 관리 서비스를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 6.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public interface MapsCommSapRfcService {
    
    public static final String RFC_FIELD_ID_IS_IFCOMM = "IS_IFCOMM";
    public static final String RFC_FIELD_ID_ES_RETURN = "ES_RETURN";

    /**
     * RFC META DATA정보 조회
     *
     * @param commSapRfcBassInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapRfcInfoVO selectSapRfcMetaDataInfo(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * RFC 정보 액셀 파일을 업로드 한다
     *
     * @param sysId
     * @param request
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapRfcInfoVO selectSapRfcInfoFileUpload(String sysId, HttpServletRequest request, LoginInfoVO loginInfo) throws Exception;

    /**
     * RFC 정보 파일 업로드 등록
     *
     * @param commSapRfcInfoVO
     * @return
     * @throws Exception
     */
    public int multiSapRfcInfoFileUpload(MapsCommSapRfcInfoVO commSapRfcInfoVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * RFC 기본정보 리스트를 조회한다
     * @return
     * @throws Exception
     */
    public List<MapsCommSapRfcBassInfoVO> selectSapRfcBassInfoPgList(MapsCommSapRfcInfoVO commSapRfcInfoVO) throws Exception;

    /**
     * RFC 정보 조회
     *
     * @param commSapRfcBassInfoVO
     * @return
     * @throws Exception
     */
    public MapsCommSapRfcInfoVO selectSapRfcInfoDetail(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO) throws Exception;
    
    /**
     * RFC 기본정보 저장
     *
     * @param commSapRfcBassInfoVO
     * @throws Exception
     */
    public int multiSapRfcBassInfo(List<MapsCommSapRfcBassInfoVO> sapRfcBassInfos, LoginInfoVO loginInfo) throws Exception;

    /**
     * RFC 입출력정보 저장
     *
     * @param commSapRfcBassInfoVO
     * @throws Exception
     */
    public int multiSapRfcIpttInfo(List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * RFC 구조체마스터 저장
     *
     * @param sapRfcStrctrInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapRfcStrctrMstVO selectSapRfcStrctrMast(MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * RFC 구조체마스터 저장
     *
     * @param sapRfcStrctrInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiSapRfcStrctrMast(List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * RFC 구조체필드정보 저장
     *
     * @param sapRfcStrctrFields
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiSapRfcStrctrFieldInfo(List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFields, LoginInfoVO loginInfo) throws Exception;

    /**
     * SAP Destination 정보
     *
     * @param commSapRfcInfoVO
     * @return
     * @throws Exception
     */
    public MapsCommSapDestInfoVO selectSapDestInfo(MapsCommSapRfcInfoVO commSapRfcInfoVO) throws Exception;
}
