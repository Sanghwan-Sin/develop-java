package com.mobis.maps.comm.constants;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * <pre>
 * 액셀탬플릿 정보
 * </pre>
 *
 * @ClassName   : MapsTmplatExcelFile.java
 * @Description : 액셀탬플릿 정보를 관리.
 * @author DT048058
 * @since 2020. 6. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 24.     DT048058     	최초 생성
 * </pre>
 */

public enum MapsCommExcelTmplat {

      COMM001("comm", "MapsTemplateMessageList.xlsx")           // 메세지관리
    , COMM002("comm", "MapsTemplatePropertiesList.xlsx")        // 프로퍼티관리
    , COMM003("comm", "MapsTemplateAdministStdWordList.xlsx")   // 행정표준용어관리
    , COMM004("comm", "MapsTemplateSapRfcInfo.xlsx")            // RFC관리
    , COMM005("comm", "MapsTemplateSapRfcBassInfoList.xlsx")    // RFC기본정보관리
    , IAM000("iam", "MapsTemplateWordDictionalyList.xlsx")      // 용어사전관리
    , IAM001("iam", "MapsTemplateFunctionList.xlsx")            // 기능관리
    , IAM002("iam", "MapsTemplateScreenList.xlsx")              // 화면관리
    , IAM003("iam", "MapsTemplateScreenComponentList.xlsx")     // 화면컴포넌트관리
    , IAM004("iam", "MapsTemplateScreenFunctionList.xlsx")      // 화면기능관리
    , IAM005("iam", "MapsTemplateScreenUrlList.xlsx")           // 화면URL관리
    , IAM006("iam", "MapsTemplateAuthority.xlsx")               // 권한관리
    , IAM007("iam", "MapsTemplateUserBasicInfo.xlsx")           // 사용자기본정보
    , IAM008("iam", "MapsTemplateUserInfo.xlsx")                // 계정정보
    ;
    
    public final static String TMPLAT_EXCEL_ROOT = "/templates/excel/";
    
    private String subPath;
    private String fileNm;
    private MapsCommExcelTmplat(String subPath, String fileNm) {
        this.subPath = subPath;
        this.fileNm = fileNm;
    }
    
    public static MapsCommExcelTmplat getMapsCommExcelTmplat(String tmplatId) {
        
        for (MapsCommExcelTmplat commExcelTmplat: MapsCommExcelTmplat.values()) {
            if (StringUtils.equals(commExcelTmplat.name(), tmplatId)) {
                return commExcelTmplat;
            }
        }
        return null;
    }
    
    public File getTmplatFile() throws IOException {
        
        StringBuilder sbFilePath = new StringBuilder();
        sbFilePath.append(TMPLAT_EXCEL_ROOT);
        sbFilePath.append(getSubPath());
        sbFilePath.append("/");
        sbFilePath.append(this.name());
        sbFilePath.append(".xlsx");
        
        Resource resource = new ClassPathResource(sbFilePath.toString());
        
        return resource.getFile();
    }

    public InputStream getTmplatStream() throws IOException {
        
        StringBuilder sbFilePath = new StringBuilder();
        sbFilePath.append(TMPLAT_EXCEL_ROOT);
        sbFilePath.append(getSubPath());
        sbFilePath.append("/");
        sbFilePath.append(this.name());
        sbFilePath.append(".xlsx");
        
        Resource resource = new ClassPathResource(sbFilePath.toString());
        
        return resource.getInputStream();
    }
    
    /**
     * @return the subPath
     */
    public String getSubPath() {
        return subPath;
    }

    /**
     * @return the fileNm
     */
    public String getFileNm() {
        return fileNm;
    }
}
