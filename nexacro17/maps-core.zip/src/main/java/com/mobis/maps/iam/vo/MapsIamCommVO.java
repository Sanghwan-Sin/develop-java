package com.mobis.maps.iam.vo;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * IAM시스템 공통 항목
 * </pre>
 *
 * @ClassName   : MapsIamCommVO.java
 * @Description : IAM시스템에 대한 공통 항목을 정의.
 * @author DT048058
 * @since 2020. 6. 15.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 15.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamCommVO extends PgBascVO {
    /* 조회정보 */
    /** 조직구분코드 */
    private String[] orgnztSeCds;
    /** 영업조직코드 */
    private String[] bsnOrgnztCds;
    /** 조직코드 */
    private String[] orgnztCds;
    /** 계정유형코드 */
    private String[] acntTyCds;
    /* 로그인계정정보 */
    /** 시스템구분코드 */
    private String acntSysSeCd;
    /** 영업조직코드 */
    private String acntBsnOrgnztCd;
    /** 조직구분코드 */
    private String acntOrgnztSeCd;
    /** 조직코드 */
    private String acntOrgnztCd;
    /** 딜러코드 */
    private String acntDealerCd;
    /** 계정유형코드 */
    private String acntAcntTyCd;
    /* 데이터처리결과정보 */
    /** 처리유형[C:신규, U:수정, D:삭제] */
    private String procTy;
    /** 메세지유형[S:성공, E:오류] */
    private String msgTy;
    /** 메세지 */
    private String msg;
    
    /**
     * 조회조건[조직구분코드]추가
     *
     * @param orgnztSeCd
     */
    public void addOrgnztSeCd(String orgnztSeCd) {
        if (!ArrayUtils.contains(orgnztSeCds, orgnztSeCd)) {
            this.orgnztSeCds = ArrayUtils.add(orgnztSeCds, orgnztSeCd);
        }
    }
    
    /**
     * 조회조건[영업조직코드]추가
     *
     * @param orgnztCd
     */
    public void addBsnOrgnztCd(String bsnOrgnztCd) {
        if (!ArrayUtils.contains(bsnOrgnztCds, bsnOrgnztCd)) {
            this.bsnOrgnztCds = ArrayUtils.add(bsnOrgnztCds, bsnOrgnztCd);
        }
    }
    
    /**
     * 조회조건[조직코드]추가
     *
     * @param orgnztCd
     */
    public void addOrgnztCd(String orgnztCd) {
        if (StringUtils.isNotBlank(orgnztCd)) {
            if (!ArrayUtils.contains(orgnztCds, orgnztCd)) {
                this.orgnztCds = ArrayUtils.add(orgnztCds, orgnztCd);
            }
        }
    }
    
    /**
     * 조회조건[계정유형코드]추가
     *
     * @param acntTyCd
     */
    public void addAcntTyCd(String acntTyCd) {
        if (StringUtils.isNotBlank(acntTyCd)) {
            if (!ArrayUtils.contains(acntTyCds, acntTyCd)) {
                this.acntTyCds = ArrayUtils.add(acntTyCds, acntTyCd);
            }
        }
    }
    
    /**
     * @return the orgnztSeCds
     */
    public String[] getOrgnztSeCds() {
        return orgnztSeCds;
    }
    /**
     * @param orgnztSeCds the orgnztSeCds to set
     */
    public void setOrgnztSeCds(String[] orgnztSeCds) {
        this.orgnztSeCds = orgnztSeCds;
    }
    /**
     * @return the orgnztCds
     */
    public String[] getOrgnztCds() {
        return orgnztCds;
    }
    /**
     * @param orgnztCds the orgnztCds to set
     */
    public void setOrgnztCds(String[] orgnztCds) {
        this.orgnztCds = orgnztCds;
    }
    /**
     * @return the acntTyCds
     */
    public String[] getAcntTyCds() {
        return acntTyCds;
    }
    /**
     * @param acntTyCds the acntTyCds to set
     */
    public void setAcntTyCds(String[] acntTyCds) {
        this.acntTyCds = acntTyCds;
    }
    /**
     * @return the acntSysSeCd
     */
    public String getAcntSysSeCd() {
        return acntSysSeCd;
    }
    /**
     * @param acntSysSeCd the acntSysSeCd to set
     */
    public void setAcntSysSeCd(String acntSysSeCd) {
        this.acntSysSeCd = acntSysSeCd;
    }
    /**
     * @return the acntBsnOrgnztCd
     */
    public String getAcntBsnOrgnztCd() {
        return acntBsnOrgnztCd;
    }
    /**
     * @param acntBsnOrgnztCd the acntBsnOrgnztCd to set
     */
    public void setAcntBsnOrgnztCd(String acntBsnOrgnztCd) {
        this.acntBsnOrgnztCd = acntBsnOrgnztCd;
    }
    /**
     * @return the acntOrgnztSeCd
     */
    public String getAcntOrgnztSeCd() {
        return acntOrgnztSeCd;
    }
    /**
     * @param acntOrgnztSeCd the acntOrgnztSeCd to set
     */
    public void setAcntOrgnztSeCd(String acntOrgnztSeCd) {
        this.acntOrgnztSeCd = acntOrgnztSeCd;
    }
    /**
     * @return the acntOrgnztCd
     */
    public String getAcntOrgnztCd() {
        return acntOrgnztCd;
    }
    /**
     * @param acntOrgnztCd the acntOrgnztCd to set
     */
    public void setAcntOrgnztCd(String acntOrgnztCd) {
        this.acntOrgnztCd = acntOrgnztCd;
    }
    /**
     * @return the acntDealerCd
     */
    public String getAcntDealerCd() {
        return acntDealerCd;
    }
    /**
     * @param acntDealerCd the acntDealerCd to set
     */
    public void setAcntDealerCd(String acntDealerCd) {
        this.acntDealerCd = acntDealerCd;
    }
    /**
     * @return the acntAcntTyCd
     */
    public String getAcntAcntTyCd() {
        return acntAcntTyCd;
    }
    /**
     * @param acntAcntTyCd the acntAcntTyCd to set
     */
    public void setAcntAcntTyCd(String acntAcntTyCd) {
        this.acntAcntTyCd = acntAcntTyCd;
    }
    /**
     * @return the procTy
     */
    public String getProcTy() {
        return procTy;
    }
    /**
     * @param procTy the procTy to set
     */
    public void setProcTy(String procTy) {
        this.procTy = procTy;
    }
    /**
     * @return the msgTy
     */
    public String getMsgTy() {
        return msgTy;
    }
    /**
     * @param msgTy the msgTy to set
     */
    public void setMsgTy(String msgTy) {
        this.msgTy = msgTy;
    }
    /**
     * @return the msg
     */
    public String getMsg() {
        return msg;
    }
    /**
     * @param msg the msg to set
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }

}
