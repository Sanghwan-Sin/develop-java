package com.mobis.maps.cmmn.util;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mobis.maps.cmmn.vo.FixedFieldLenVO;
import com.mobis.maps.cmmn.vo.FixedFieldTestVO;




/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FiexedFieldLenTxtFileUtil.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 2. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 21.     oh.dongwon     	최초 생성
 * </pre>
 */

public class FiexedFieldLenTxtToVoUtil {
    
    private static Logger logger = LoggerFactory.getLogger(FiexedFieldLenTxtToVoUtil.class);
    
    /**
     * field 딜리미터 
     */
    private String fieldFillDelim = " ";
    
    /**
     * row 간의 딜리미터
     */
    private String rowDelim = "\r\n";
    
    
    /**
     * String array로 입력된것을 vo의 arraylist로 정규화
     *
     * @param rowDelim
     */
    private void doMakeDefinition() {
        if( this.definition == null ){
            return;
        }
        String[] rowDelim = this.definition;
        for(int  i = 0 ; i < rowDelim.length; i++){
            String val = rowDelim[i];
            
            String[] splitVal  = StringUtils.split(val , ",");
            // obj명 추출
            String objName = splitVal[0];
            
            // start loc, end loc추출
            String startEndVal = splitVal[1];
            String[] startEndValDelim = StringUtils.split(startEndVal , "~");
            int start = Integer.parseInt(startEndValDelim[0]);
            int end = Integer.parseInt(startEndValDelim[1]);
            
            // arraylist방식으로 추출
            FixedFieldLenVO vo = new FixedFieldLenVO();
            vo.setObjName(objName);
            vo.setStart(start);
            vo.setEnd(end);
            definionList.add(vo);
        }
    }
    
    
    /**
     * o의 인자로 문자열 리턴
     *
     * @param o
     * @param desc
     * @return
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws NoSuchMethodException
     */
    private static String doOneLine(Object o , FixedFieldLenVO desc) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException{
        String strVal = org.apache.commons.beanutils.BeanUtils.getProperty(o, desc.getObjName());
        return strVal;
    }
    
    
    
    
    
    /**
     * List<T> c로 실제 문자열 생성
     *
     * @param c
     * @return
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws NoSuchMethodException
     */
    public  <T> String getFiexedFieldTxt( List<T> c ) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException{
        
        doMakeDefinition();
        
        List<FixedFieldLenVO> definitionList = this.definionList;
        
        if( c == null ){
            return "";
        }
        
        if( definitionList == null ){
            return "";
        }
        
        String rtn = "";
        
        int definitionSize =  definitionList.size();
        int size = c.size();
        
        for(int i = 0 ; i < size ; i++){
            T objData = c.get(i);
            for(int j = 0 ; j < definitionSize ; j++){
                FixedFieldLenVO definitionVO = definitionList.get(j);
                //String objectName = definitionVO.getObjName();
                String objectValue = doOneLine(objData,definitionVO);
                
                int byteLen =  byteLength(objectValue);
                int stringSize = ( definitionVO.getEnd() - definitionVO.getStart() ) -  byteLen; 
                
                objectValue = objectValue + StringUtils.repeat(fieldFillDelim, stringSize);
                rtn = rtn + objectValue;
                if( j == (definitionSize-1) ){
                    rtn = rtn + rowDelim;
                }
            }
        }
        return rtn;
    }
    
    
    /**
     * Object를 Field 값에 셋팅
     *
     * @param field
     * @param obj
     * @param value
     * @throws Exception
     */
    public static void setProperty(Object obj, Field field, Object value) throws Exception {
       
        if (field.getType() == String.class) {
            BeanUtils.setProperty(obj, field.getName(), StringUtils.trim(value.toString()));
        } else if (field.getType() == byte[].class) {
            BeanUtils.copyProperty(obj, field.getName(), value);
        } else {
            BeanUtils.setProperty(obj, field.getName(), value);
        }
    }
    
    public <T> List<T> getExportTxtValues( String inputTxt, Class<? extends T> c) throws Exception {
        
        doMakeDefinition();
        
        List<FixedFieldLenVO> definitionList = this.definionList;
        
        if( StringUtils.isEmpty(inputTxt) ){
            return null;
        }
        
        if( definitionList == null ){
            return null;
        }
        
        
        
        int definitionSize =  definitionList.size();
        
        String[] strInputSplit = StringUtils.split(inputTxt , rowDelim);
        // rowdelim으로 split한값이 없으면 return
        if( strInputSplit.length < 1 ){
            return null;
        }
        List<T> datas = new ArrayList<>();
        
        for(int i = 0 ; i < strInputSplit.length ; i++){
            String splitStr = strInputSplit[i];
            T objData = c.newInstance();
            for(int j = 0 ; j < definitionSize ; j++){
                FixedFieldLenVO definitionVO = definitionList.get(j);
                int start = definitionVO.getStart();
                int end  = definitionVO.getEnd();
                String substrVal = StringUtils.substring(splitStr, start, end);
                
                
                substrVal = StringUtils.stripEnd(substrVal,fieldFillDelim);
                BeanUtils.setProperty(objData, definitionVO.getObjName(), substrVal);
            }
            datas.add(objData);
            
        }
        
        return datas;
    }
    

    
    /**
     * Statements
     *
     * @param args
     * @throws Exception 
     */
    public static void main(String[] args) throws Exception {
        
        // c:\\test\\test.sql 에다음 내용의 샘플 txt(제일 앞쪽 스페이스는 제거해 주세요)
        /*
        idinput     name     address    telNo      
        idinput1    name11   address2   telNo33    
        idinput12   name112  address22  telNo333   
        */
        
        File inputFile = new File("c:\\test\\test.sql");
        String inputStr = FileUtils.readFileToString(inputFile);
        
        
        /** util 초기화 **/
        FiexedFieldLenTxtToVoUtil convertUtil = new FiexedFieldLenTxtToVoUtil();
        /**
         *  fixed length 정의
         *  ex> 아래의 예제 설명
         *  0~12    byte 까지  TXT 에서 잘라서 VO의 id로 구성
         *  12~21   byte 까지  TXT 에서 잘라서 VO의 name로 구성
         *  21~32   byte 까지  TXT 에서 잘라서 VO의 address로 구성
         *  32~42   byte 까지  TXT 에서 잘라서 VO의 telNo로 구성
         */
        String[] rowDefinition = {"id,0~12" , "name,12~21" , "address,21~32" , "telNo,32~42"} ;
        convertUtil.setDefinition(rowDefinition);
        /** 
         *  field 딜리미터 설정 (입력하지 않으면 " " 스페이스문자)
         **/
        convertUtil.setFieldFillDelim(" ");
        
        
        /** 
         *  row 의 식별인자 (입력하지 않으면 "\r\n"
         **/        
        convertUtil.setRowDelim("\r\n");
        // 샘플 vo list구성
        List<FixedFieldTestVO> sampleList = convertUtil.getExportTxtValues(inputStr,FixedFieldTestVO.class);
        if(logger.isDebugEnabled()){
            logger.debug(" vo Size :",sampleList.size());
        }
        
    }

    /**
     * @return the fieldFillDelim
     */
    public String getFieldFillDelim() {
        return fieldFillDelim;
    }

    /**
     * @param fieldFillDelim the fieldFillDelim to set
     */
    public void setFieldFillDelim(String fieldFillDelim) {
        this.fieldFillDelim = fieldFillDelim;
    }

    /**
     * @return the rowDelim
     */
    public String getRowDelim() {
        return rowDelim;
    }

    /**
     * @param rowDelim the rowDelim to set
     */
    public void setRowDelim(String rowDelim) {
        this.rowDelim = rowDelim;
    }

    private String [] definition;
    public List<FixedFieldLenVO> definionList = new ArrayList<FixedFieldLenVO>();
    
    
    /**
     * 한글 bytt length return
     *
     * @param input
     * @return
     */
    private int byteLength(String input) {
        if( StringUtils.isEmpty(input)){
            return 0;
        }
        return input.getBytes().length; 
    }

    /**
     * UTF8 ==> EUC_KR encode
     *
     * @param helloString
     * @return
     * @throws UnsupportedEncodingException 
     */
    public static String encodeEucKR(String inputStr) throws UnsupportedEncodingException{
        Charset eucKRCharset = Charset.forName("EUC-KR");
        CharBuffer sourceBuffer = CharBuffer.wrap(inputStr.toCharArray());
        ByteBuffer resultByteBuffer = eucKRCharset.encode(sourceBuffer);
        byte[] resultBytes =  resultByteBuffer.array();
        // EUC-KR 의 String 을 생성할 때, 두번째 인자값으로 인코딩 정보를 넣어준다.
        //return new String(resultBytes);
        return new String(resultBytes, eucKRCharset);
        // 만약 인코딩 정보를 넣지 않는다면 에러 스트링이(�, 0xfffd) 이 출력될 것이다. 
    }

    public static String encodeUtf8(String inputStr) throws UnsupportedEncodingException{
        
        Charset utf8Charset = Charset.forName("UTF-8");
        CharBuffer sourceBuffer = CharBuffer.wrap(inputStr.toCharArray());
        ByteBuffer resultByteBuffer = utf8Charset.encode(sourceBuffer);
        byte[] resultBytes =  resultByteBuffer.array();
        // EUC-KR 의 String 을 생성할 때, 두번째 인자값으로 인코딩 정보를 넣어준다.
        return new String(resultBytes, utf8Charset);
        // 만약 인코딩 정보를 넣지 않는다면 에러 스트링이(�, 0xfffd) 이 출력될 것이다.
         
    }
    
    public static void pringBytes(String input ){
        //System.out.println("########### printByte START");
        logger.debug("########### printByte START");
        logger.debug("########### printByte input" + input);
        //byte[] bytes = input.getBytes();
        //for (int i = 0; i < bytes.length; i++) {
        //    byte b = bytes[i];
            //System.out.println(b);
            //logger.debug(b);
        //}
        logger.debug("########### printByte END");
        //System.out.println("########### printByte   END");
    }
    

    /**
     * @return the definition
     */
    public String[] getDefinition() {
        return definition;
    }

    /**
     * @param definition the definition to set
     */
    public void setDefinition(String[] definition) {
        this.definition = definition;
    }

}
