package com.mobis.maps.iam.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamAcntReqstSttusService;
import com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO;

/**
 * <pre>
 * 계정신청현황 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstSttusController.java
 * @Description : 계정신청현황에 대한 컨트롤러를 정의.
 * @author DT048058
 * @since 2020. 3. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 30.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamAcntReqstSttusController extends HController {

    @Resource(name = "mapsIamAcntReqstSttusService")
    private MapsIamAcntReqstSttusService mapsIamAcntReqstSttusService;
    
    /**
     * 계정신청현황 페이징리스트 조회
     *
     * @param iamAcntReqstInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAcntReqstSttusPgList.do")
    public NexacroResult selectAcntReqstSttusPgList(
            @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamAcntReqstInfoVO> acntReqstSttus = mapsIamAcntReqstSttusService.selectAcntReqstSttusPgList(iamAcntReqstInfoVO, loginInfo);
                
        result.addDataSet("dsOutput", acntReqstSttus);        
        
        return result;
    }
    
    /**
     * 계정신청현황 액셀다운로드
     *
     * @param iamAcntReqstInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAcntReqstSttusListExcelDown.do")
    public NexacroResult selectAcntReqstSttusListExcelDown(
            @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        iamAcntReqstInfoVO.setExcelDwnlYn(MapsConstants.YN_YES);
        iamAcntReqstInfoVO.setPgNum(1);
        iamAcntReqstInfoVO.setPgSize(iamAcntReqstInfoVO.getTotMaxCnt());
        
        List<MapsIamAcntReqstInfoVO> acntReqstSttus = mapsIamAcntReqstSttusService.selectAcntReqstSttusPgList(iamAcntReqstInfoVO, loginInfo);

        result.addDataSet("dsOutput", acntReqstSttus);

        return result;
    }

    /**
     * 계정신청현황(마스터사용자) 페이징리스트 조회
     *
     * @param iamAcntReqstInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAcntReqstSttusMasterPgList.do")
    public NexacroResult selectAcntReqstSttusMasterPgList(
            @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamAcntReqstInfoVO> acntReqstSttus = mapsIamAcntReqstSttusService.selectAcntReqstSttusMasterPgList(iamAcntReqstInfoVO, loginInfo);
                
        result.addDataSet("dsOutput", acntReqstSttus);        
        
        return result;
    }
    
    /**
     * 계정신청현황(마스터사용자) 액셀다운로드
     *
     * @param iamAcntReqstInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectAcntReqstSttusMasterListExcelDown.do")
    public NexacroResult selectAcntReqstSttusMasterListExcelDown(
            @ParamDataSet(name="dsInput") MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        iamAcntReqstInfoVO.setExcelDwnlYn(MapsConstants.YN_YES);
        iamAcntReqstInfoVO.setPgNum(1);
        iamAcntReqstInfoVO.setPgSize(iamAcntReqstInfoVO.getTotMaxCnt());
        
        List<MapsIamAcntReqstInfoVO> acntReqstSttus = mapsIamAcntReqstSttusService.selectAcntReqstSttusMasterPgList(iamAcntReqstInfoVO, loginInfo);

        result.addDataSet("dsOutput", acntReqstSttus);

        return result;
    }
}
