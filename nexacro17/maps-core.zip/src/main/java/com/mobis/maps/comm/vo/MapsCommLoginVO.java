package com.mobis.maps.comm.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommLoginVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 28.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsCommLoginVO {
    /* 로그인 파라매터 */    
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 사용자ID */
    private String userId;
    /** 사용자암호 */
    private String userPwd;
    /** 언어코드 */
    private String langCd;
    /** 아이디 저장 여부 */
    private String saveIdYn;
    /* 로그인 정보 */
    /** 암호변경여부 */
    private String pwdChangeYn;
    /** 로그인한 url */
    private String requestUrl;
    /** ssoFlag */
    private String ssoFlag;
    /** preLoginFlag 중복로그인질문에서 Y를 선택한경우"LOGIN이 넘어옴" */
    private String preLoginFlag;
    
    
    
    /**
     * @return the preLoginFlag
     */
    public String getPreLoginFlag() {
        return preLoginFlag;
    }
    /**
     * @param preLoginFlag the preLoginFlag to set
     */
    public void setPreLoginFlag(String preLoginFlag) {
        this.preLoginFlag = preLoginFlag;
    }
    /**
     * @return the ssoFlag
     */
    public String getSsoFlag() {
        return ssoFlag;
    }
    /**
     * @param ssoFlag the ssoFlag to set
     */
    public void setSsoFlag(String ssoFlag) {
        this.ssoFlag = ssoFlag;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userPwd
     */
    public String getUserPwd() {
        return userPwd;
    }
    /**
     * @param userPwd the userPwd to set
     */
    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }
    /**
     * @return the langCd
     */
    public String getLangCd() {
        return langCd;
    }
    /**
     * @param langCd the langCd to set
     */
    public void setLangCd(String langCd) {
        this.langCd = langCd;
    }
    /**
     * @return the saveIdYn
     */
    public String getSaveIdYn() {
        return saveIdYn;
    }
    /**
     * @param saveIdYn the saveIdYn to set
     */
    public void setSaveIdYn(String saveIdYn) {
        this.saveIdYn = saveIdYn;
    }
    /**
     * @return the pwdChangeYn
     */
    public String getPwdChangeYn() {
        return pwdChangeYn;
    }
    /**
     * @param pwdChangeYn the pwdChangeYn to set
     */
    public void setPwdChangeYn(String pwdChangeYn) {
        this.pwdChangeYn = pwdChangeYn;
    }
    /**
     * @return the requestUrl
     */
    public String getRequestUrl() {
        return requestUrl;
    }
    /**
     * @param requestUrl the requestUrl to set
     */
    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }
}
