package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommPropVO;

/**
 * <pre>
 * 프로퍼티 관리 데이터처리
 * </pre>
 *
 * @ClassName   : MapsCommPropMDAO.java
 * @Description : 프로퍼티 관리 데이터처리를 정의.
 * @author DT048058
 * @since 2019. 12. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 18.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsCommPropMDAO")
public interface MapsCommPropMDAO {

    /**
     * 프로퍼티 리스트 조회
     *
     * @param commPropSearchVO
     * @return
     * @throws Exception
     */
    public List<MapsCommPropVO> selectPropPgList(MapsCommPropVO commPropVO) throws Exception;

    /**
     * 프로퍼티 조회
     *
     * @param commPropVO
     * @return
     * @throws Exception
     */
    public MapsCommPropVO selectPropInfo(MapsCommPropVO commPropVO) throws Exception;
    
    /**
     * 프로퍼티 저장
     *
     * @param commPropVO
     * @throws Exception
     */
    public void insertPropInfo(MapsCommPropVO commPropVO) throws Exception;
    
    /**
     * 프로퍼티 수정
     *
     * @param commPropVO
     * @return
     * @throws Exception
     */
    public int updatePropInfo(MapsCommPropVO commPropVO) throws Exception;
    
    /**
     * 프로퍼티 삭제
     *
     * @param commPropVO
     * @return
     * @throws Exception
     */
    public int deletePropInfo(MapsCommPropVO commPropVO) throws Exception;
}
