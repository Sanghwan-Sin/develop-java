package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.iam.vo.MapsIamAuthorMenuScnFnctVO;
import com.mobis.maps.iam.vo.MapsIamAuthorMenuVO;
import com.mobis.maps.iam.vo.MapsIamAuthorSetupVO;
import com.mobis.maps.iam.vo.MapsIamAuthorUserVO;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsIamAuthorMDAO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 최은삼
 * @since 2019. 12. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 13.     최은삼     	최초 생성
 * </pre>
 */
@Mapper("mapsIamAuthorMDAO")
public interface MapsIamAuthorMDAO {

    /**
     * 권한 리스트 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectAuthorList(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한 페이징리스트 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectAuthorPgList(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public MapsIamAuthorVO selectAuthorInfo(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한 저장
     *
     * @param iamAuthorVO
     * @throws Exception
     */
    public void insertAuthorInfo(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한 수정
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public int updateAuthorInfo(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한 삭제
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public int deleteAuthorInfo(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한 변경이력 페이징 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectAuthorChghstPgList(MapsIamAuthorVO iamAuthorVO) throws Exception;
    
    /**
     * 권한 변경이력 등록
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public void insertAuthorChghst(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한별 메뉴 리스트 조회
     *
     * @param imAuthorMenuVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorMenuVO> selectAuthorMenuScrinList(MapsIamAuthorMenuVO imAuthorMenuVO) throws Exception;

    /**
     * 권한별 메뉴 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public MapsIamAuthorMenuVO selectAuthorMenuInfo(MapsIamAuthorMenuVO imAuthorMenuVO) throws Exception;

    /**
     * 권한별 메뉴 등록
     *
     * @param iamAuthorVO
     * @throws Exception
     */
    public void insertAuthorMenu(MapsIamAuthorMenuVO imAuthorMenuVO) throws Exception;

    /**
     * 권한별 메뉴 가져오기등록
     *
     * @param iamAuthorVO
     * @throws Exception
     */
    public void insertImportAuthorMenu(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한별 메뉴 삭제
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public int deleteAuthorMenu(MapsIamAuthorMenuVO imAuthorMenuVO) throws Exception;
    
    /**
     * 권한별 메뉴 전체 삭제
     *
     * @param imAuthorMenuVO
     * @return
     * @throws Exception
     */
    public int deleteAllAuthorMenu(MapsIamAuthorMenuVO imAuthorMenuVO) throws Exception;

    /**
     * 권한별 화면 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public MapsIamAuthorMenuVO selectAuthorScrinInfo(MapsIamAuthorMenuVO imAuthorMenuVO) throws Exception;

    /**
     * 권한별 화면 등록
     *
     * @param iamAuthorVO
     * @throws Exception
     */
    public void insertAuthorScrin(MapsIamAuthorMenuVO imAuthorMenuVO) throws Exception;

    /**
     * 권한별 화면 가져오기등록
     *
     * @param iamAuthorVO
     * @throws Exception
     */
    public void insertImportAuthorScrin(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한별 화면 삭제
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public int deleteAuthorScrin(MapsIamAuthorMenuVO imAuthorMenuVO) throws Exception;
    
    /**
     * 권한별 화면 전체 삭제
     *
     * @param imAuthorMenuVO
     * @return
     * @throws Exception
     */
    public int deleteAllAuthorScrin(MapsIamAuthorMenuVO imAuthorMenuVO) throws Exception;

    /**
     * 권한별 화면 기능 리스트 조회
     *
     * @param iamAuthorMenuScnFnctVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorMenuScnFnctVO> selectAuthorScrinFnctList(MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO) throws Exception;

    /**
     * 권한별 화면 기능 기능 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public MapsIamAuthorMenuScnFnctVO selectAuthorScrinFnctInfo(MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO) throws Exception;

    /**
     * 권한별 화면기능 등록
     *
     * @param iamAuthorVO
     * @throws Exception
     */
    public void insertAuthorScrinFnct(MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO) throws Exception;
    
    /**
     * 권한별 화면기능 전체 등록
     *
     * @param iamAuthorMenuScnFnctVO
     * @throws Exception
     */
    public void insertAllAuthorScrinFnct(MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO) throws Exception;
    
    /**
     * 권한별 화면기능 가져오기등록
     *
     * @param iamAuthorVO
     * @throws Exception
     */
    public void insertImportAuthorScrinFnct(MapsIamAuthorVO iamAuthorVO) throws Exception;

    /**
     * 권한별 화면기능 삭제
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public int deleteAuthorScrinFnct(MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO) throws Exception;
    
    /**
     * 권한별 화면ID에 대한 화면기능 전체 삭제
     *
     * @param iamAuthorMenuScnFnctVO
     * @return
     * @throws Exception
     */
    public int deleteAllAuthorScrinFnctByScrinId(MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO) throws Exception;
    
    /**
     * 권한별 화면기능 전체 삭제
     *
     * @param iamAuthorMenuScnFnctVO
     * @return
     * @throws Exception
     */
    public int deleteAllAuthorScrinFnct(MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO) throws Exception;

    /**
     * 권한설정 변경이력 페이징 조회
     *
     * @param iamAuthorSetupVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorSetupVO> selectAuthorSetupChghstPgList(MapsIamAuthorSetupVO iamAuthorSetupVO) throws Exception;

    /**
     * Statements
     *
     * @param iamAuthorSetupVO
     * @return
     * @throws Exception
     */
    public int insertAuthorSetupChghst(MapsIamAuthorSetupVO iamAuthorSetupVO) throws Exception;
    
    /**
     * 권한설정변경이력 일괄등록
     *
     * @param iamAuthorSetupVO
     * @return
     * @throws Exception
     */
    public int insertAllAuthorSetupChghst(MapsIamAuthorSetupVO iamAuthorSetupVO) throws Exception;
    
    /**
     * 권한별 사용자 리스트 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorUserVO> selectAuthorUserPgList(MapsIamAuthorUserVO iamAuthorUserVO) throws Exception;

    /**
     * 권한 사용자 조회
     *
     * @param iamAuthorUserVO
     * @return
     * @throws Exception
     */
    public MapsIamAuthorUserVO selectAuthorUser(MapsIamAuthorUserVO iamAuthorUserVO) throws Exception;

    /**
     * 권한 사용자 조회(사용자순번ID)
     *
     * @param iamAuthorUserVO
     * @return
     * @throws Exception
     */
    public MapsIamAuthorUserVO selectAuthorUserByUserSeqId(MapsIamAuthorUserVO iamAuthorUserVO) throws Exception;
    
    /**
     * 권한별 사용자 등록
     *
     * @param iamUserVO
     * @throws Exception
     */
    public void insertAuthorUser(MapsIamAuthorUserVO iamAuthorUserVO) throws Exception;

    /**
     * 권한별 사용자 수정
     *
     * @param iamUserVO
     * @throws Exception
     */
    public void updateAuthorUser(MapsIamAuthorUserVO iamAuthorUserVO) throws Exception;

    /**
     * 권한별 사용자 삭제
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int deleteAuthorUser(MapsIamAuthorUserVO iamAuthorUserVO) throws Exception;

    /**
     * 권한별 사용자 전체 삭제
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int deleteAllAuthorUser(MapsIamAuthorUserVO iamAuthorUserVO) throws Exception;
    
}
