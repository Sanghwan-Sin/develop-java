package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 대리점, 딜러 항목을 정의
 * </pre>
 *
 * @ClassName   : MapsIamDistVO.java
 * @Description : 대리점, 딜러 항목을 정의
 * @author 최은삼
 * @since 2019. 12. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 13.     최은삼     	최초 생성
 * </pre>
 */

public class MapsIamDistVO extends MapsIamCommVO {
    
    /* 조회조건 */
    private String sysSeCd;
    private String corpCd;
    private String acntTyCd;
        
    /* 데이터항목 */
    /** 영업조직 */
    private String vkorg;
    /** 유통경로 */
    private String vtweg;
    /** 고객번호 */
    private String kunnr;
    /** 서비스타입 */
    private String zservty;
    /** 영업소 */
    private String vkbur;
    /** L-REGION */
    private String zlregio;
    /** M-REGION */
    private String zmregio;
    /** S-REGION */
    private String zsregio;
    /** 고객상태 */
    private String zcustat;
    /** AS-IS고객코드 */
    private String zsacutm;
    /** 사업자등록번호 */
    private String stcd2;
    /** 국가코드 */
    private String land1Gp;
    /** 도시 */
    private String ort01Gp;
    /** 상세주소 */
    private String strasGp;
    /** 우편번호 */
    private String pstlz;
    /** 이메일 */
    private String zemail;
    /** 전화번호 */
    private String ztelno1;
    /** H/K구분자 */
    private String kvgr1;
    /** 고객유형 */
    private String kvgr2;
    /** 고객세부유형 */
    private String kvgr3;
    /** CustomerType */
    private String kvgr4;
    /** 대리점코드 */
    private String zkunnr;
    /** 딜러코드 */
    private String zdealer;
    /** 대표대리점코드 */
    private String zkunn2;
    /** 대표딜러코드 */
    private String zdeale2;   
    /** 영업조직이름 */
    private String zvknam;
    /** 대리점상호 */
    private String zkunam;
    /** 딜러코드상호 */
    private String zdlrnam;
    /** 서브딜러상호 */
    private String zsubdrn;
    
    
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the corpCd
     */
    public String getCorpCd() {
        return corpCd;
    }
    /**
     * @param corpCd the corpCd to set
     */
    public void setCorpCd(String corpCd) {
        this.corpCd = corpCd;
    }
    /**
     * @return the acntTyCd
     */
    public String getAcntTyCd() {
        return acntTyCd;
    }
    /**
     * @param acntTyCd the acntTyCd to set
     */
    public void setAcntTyCd(String acntTyCd) {
        this.acntTyCd = acntTyCd;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the zservty
     */
    public String getZservty() {
        return zservty;
    }
    /**
     * @param zservty the zservty to set
     */
    public void setZservty(String zservty) {
        this.zservty = zservty;
    }
    /**
     * @return the vkbur
     */
    public String getVkbur() {
        return vkbur;
    }
    /**
     * @param vkbur the vkbur to set
     */
    public void setVkbur(String vkbur) {
        this.vkbur = vkbur;
    }
    /**
     * @return the zlregio
     */
    public String getZlregio() {
        return zlregio;
    }
    /**
     * @param zlregio the zlregio to set
     */
    public void setZlregio(String zlregio) {
        this.zlregio = zlregio;
    }
    /**
     * @return the zmregio
     */
    public String getZmregio() {
        return zmregio;
    }
    /**
     * @param zmregio the zmregio to set
     */
    public void setZmregio(String zmregio) {
        this.zmregio = zmregio;
    }
    /**
     * @return the zsregio
     */
    public String getZsregio() {
        return zsregio;
    }
    /**
     * @param zsregio the zsregio to set
     */
    public void setZsregio(String zsregio) {
        this.zsregio = zsregio;
    }
    /**
     * @return the zcustat
     */
    public String getZcustat() {
        return zcustat;
    }
    /**
     * @param zcustat the zcustat to set
     */
    public void setZcustat(String zcustat) {
        this.zcustat = zcustat;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the stcd2
     */
    public String getStcd2() {
        return stcd2;
    }
    /**
     * @param stcd2 the stcd2 to set
     */
    public void setStcd2(String stcd2) {
        this.stcd2 = stcd2;
    }
    /**
     * @return the land1Gp
     */
    public String getLand1Gp() {
        return land1Gp;
    }
    /**
     * @param land1Gp the land1Gp to set
     */
    public void setLand1Gp(String land1Gp) {
        this.land1Gp = land1Gp;
    }
    /**
     * @return the ort01Gp
     */
    public String getOrt01Gp() {
        return ort01Gp;
    }
    /**
     * @param ort01Gp the ort01Gp to set
     */
    public void setOrt01Gp(String ort01Gp) {
        this.ort01Gp = ort01Gp;
    }
    /**
     * @return the strasGp
     */
    public String getStrasGp() {
        return strasGp;
    }
    /**
     * @param strasGp the strasGp to set
     */
    public void setStrasGp(String strasGp) {
        this.strasGp = strasGp;
    }
    /**
     * @return the pstlz
     */
    public String getPstlz() {
        return pstlz;
    }
    /**
     * @param pstlz the pstlz to set
     */
    public void setPstlz(String pstlz) {
        this.pstlz = pstlz;
    }
    /**
     * @return the zemail
     */
    public String getZemail() {
        return zemail;
    }
    /**
     * @param zemail the zemail to set
     */
    public void setZemail(String zemail) {
        this.zemail = zemail;
    }
    /**
     * @return the ztelno1
     */
    public String getZtelno1() {
        return ztelno1;
    }
    /**
     * @param ztelno1 the ztelno1 to set
     */
    public void setZtelno1(String ztelno1) {
        this.ztelno1 = ztelno1;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the kvgr2
     */
    public String getKvgr2() {
        return kvgr2;
    }
    /**
     * @param kvgr2 the kvgr2 to set
     */
    public void setKvgr2(String kvgr2) {
        this.kvgr2 = kvgr2;
    }
    /**
     * @return the kvgr3
     */
    public String getKvgr3() {
        return kvgr3;
    }
    /**
     * @param kvgr3 the kvgr3 to set
     */
    public void setKvgr3(String kvgr3) {
        this.kvgr3 = kvgr3;
    }
    /**
     * @return the kvgr4
     */
    public String getKvgr4() {
        return kvgr4;
    }
    /**
     * @param kvgr4 the kvgr4 to set
     */
    public void setKvgr4(String kvgr4) {
        this.kvgr4 = kvgr4;
    }
    /**
     * @return the zkunnr
     */
    public String getZkunnr() {
        return zkunnr;
    }
    /**
     * @param zkunnr the zkunnr to set
     */
    public void setZkunnr(String zkunnr) {
        this.zkunnr = zkunnr;
    }
    /**
     * @return the zdealer
     */
    public String getZdealer() {
        return zdealer;
    }
    /**
     * @param zdealer the zdealer to set
     */
    public void setZdealer(String zdealer) {
        this.zdealer = zdealer;
    }
    /**
     * @return the zkunn2
     */
    public String getZkunn2() {
        return zkunn2;
    }
    /**
     * @param zkunn2 the zkunn2 to set
     */
    public void setZkunn2(String zkunn2) {
        this.zkunn2 = zkunn2;
    }
    /**
     * @return the zdeale2
     */
    public String getZdeale2() {
        return zdeale2;
    }
    /**
     * @param zdeale2 the zdeale2 to set
     */
    public void setZdeale2(String zdeale2) {
        this.zdeale2 = zdeale2;
    }
    /**
     * @return the zvknam
     */
    public String getZvknam() {
        return zvknam;
    }
    /**
     * @param zvknam the zvknam to set
     */
    public void setZvknam(String zvknam) {
        this.zvknam = zvknam;
    }
    /**
     * @return the zkunam
     */
    public String getZkunam() {
        return zkunam;
    }
    /**
     * @param zkunam the zkunam to set
     */
    public void setZkunam(String zkunam) {
        this.zkunam = zkunam;
    }
    /**
     * @return the zdlrnam
     */
    public String getZdlrnam() {
        return zdlrnam;
    }
    /**
     * @param zdlrnam the zdlrnam to set
     */
    public void setZdlrnam(String zdlrnam) {
        this.zdlrnam = zdlrnam;
    }
    /**
     * @return the zsubdrn
     */
    public String getZsubdrn() {
        return zsubdrn;
    }
    /**
     * @param zsubdrn the zsubdrn to set
     */
    public void setZsubdrn(String zsubdrn) {
        this.zsubdrn = zsubdrn;
    }        
    
}
