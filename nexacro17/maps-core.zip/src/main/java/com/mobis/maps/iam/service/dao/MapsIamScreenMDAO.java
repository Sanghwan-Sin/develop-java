package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;
import able.com.vo.HMap;

import com.mobis.maps.iam.vo.MapsIamScreenVO;
import com.mobis.maps.iam.vo.MapsIamScrinUrlVO;

/**
 * <pre>
 * 화면관리 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsIamScreenMDAO.java
 * @Description : 화면관리 데이터처를 정의.
 * @author DT048657
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     DT048657     	최초 생성
 * </pre>
 */
@Mapper("mapsIamScreenMDAO")
public interface MapsIamScreenMDAO {
    
    /**
     * 화면관리 리스트 조회
     *
     * @param commScreenVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScreenVO> selectScreenPgList(MapsIamScreenVO iamScreenVO) throws Exception;
    
    /**
     * 화면정보 조회
     *
     * @param iamScreenVO
     * @return
     * @throws Exception
     */
    public MapsIamScreenVO selectScreenInfo(MapsIamScreenVO iamScreenVO) throws Exception;
    
    /**
     * 다음 화면관리코드 조회
     *
     * @param iamScreenVO
     * @return
     * @throws Exception
     */
    public HMap selectNextScreenCd(MapsIamScreenVO iamScreenVO) throws Exception;
        
    /**
     * 화면관리 저장
     *
     * @param iamScreenVO
     * @throws Exception
     */
    public void insertScreenInfo(MapsIamScreenVO iamScreenVO) throws Exception;
        
    /**
     * 화면관리 수정
     *
     * @param iamScreenVO
     * @return
     * @throws Exception
     */
    public int updateScreenInfo(MapsIamScreenVO iamScreenVO) throws Exception;
    
    /**
     * 화면관리 삭제 수정
     *
     * @param iamScreenVO
     * @return
     * @throws Exception
     */
    public int updateDeleteScreenInfo(MapsIamScreenVO iamScreenVO) throws Exception;
    
    /**
     * 화면관리 삭제
     *
     * @param iamScreenVO
     * @return
     * @throws Exception
     */
    public int deleteScreenInfo(MapsIamScreenVO iamScreenVO) throws Exception;

    /**
     * 화면URL관리 리스트 조회
     *
     * @param iamScrinUrlVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScrinUrlVO> selectScrinUrlList(MapsIamScrinUrlVO iamScrinUrlVO) throws Exception;

    /**
     * 화면URL관리 조회
     *
     * @param iamScrinUrlVO
     * @return
     * @throws Exception
     */
    public MapsIamScrinUrlVO selectScrinUrl(MapsIamScrinUrlVO iamScrinUrlVO) throws Exception;

    /**
     * 화면URL관리 UK 조회
     *
     * @param iamScrinUrlVO
     * @return
     * @throws Exception
     */
    public MapsIamScrinUrlVO selectScrinUrlByUk(MapsIamScrinUrlVO iamScrinUrlVO) throws Exception;
    
    /**
     * 화면URL관리 등록
     *
     * @param iamScrinUrlVO
     * @throws Exception
     */
    public void insertScrinUrl(MapsIamScrinUrlVO iamScrinUrlVO) throws Exception;
    
    /**
     * 화면URL관리 수정
     *
     * @param iamScrinUrlVO
     * @return
     * @throws Exception
     */
    public int updateScrinUrl(MapsIamScrinUrlVO iamScrinUrlVO) throws Exception;
    
    /**
     * 화면URL관리 삭제
     *
     * @param iamScrinUrlVO
     * @return
     * @throws Exception
     */
    public int deleteScrinUrl(MapsIamScrinUrlVO iamScrinUrlVO) throws Exception;
    
    /**
     * 화면관리 팝업 리스트 조회
     *
     * @param commScreenVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScreenVO> selectScreenPgPopList(MapsIamScreenVO commScreenVO) throws Exception;

}
