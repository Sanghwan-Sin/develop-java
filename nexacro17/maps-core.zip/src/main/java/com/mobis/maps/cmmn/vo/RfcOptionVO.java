package com.mobis.maps.cmmn.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : RfcOptionVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 14.     DT048058     	최초 생성
 * </pre>
 */

public class RfcOptionVO {
    /** 값 */
    private Object val;
    /** ABAP: ID: I/E (포함/제외된 값) */
    private String sign;
    /** ABAP: 선택옵션 (EQ/BT/CP/...) */
    private String option;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    private Object low;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    private Object high;
    /**
     * @return the val
     */
    public Object getVal() {
        return val;
    }
    /**
     * @param val the val to set
     */
    public void setVal(Object val) {
        this.val = val;
    }
    /**
     * @return the sign
     */
    public String getSign() {
        return sign;
    }
    /**
     * @param sign the sign to set
     */
    public void setSign(String sign) {
        this.sign = sign;
    }
    /**
     * @return the option
     */
    public String getOption() {
        return option;
    }
    /**
     * @param option the option to set
     */
    public void setOption(String option) {
        this.option = option;
    }
    /**
     * @return the low
     */
    public Object getLow() {
        return low;
    }
    /**
     * @param low the low to set
     */
    public void setLow(Object low) {
        this.low = low;
    }
    /**
     * @return the high
     */
    public Object getHigh() {
        return high;
    }
    /**
     * @param high the high to set
     */
    public void setHigh(Object high) {
        this.high = high;
    }
}
