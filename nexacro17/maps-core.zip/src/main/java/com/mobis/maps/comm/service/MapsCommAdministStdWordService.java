package com.mobis.maps.comm.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommAdministStdWordVO;

/**
 * <pre>
 * 행정표준용어 서비스
 * </pre>
 *
 * @ClassName   : MapsCommAdministStdWordService.java
 * @Description : 행정표준용어에 대한 서비스를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsCommAdministStdWordService {

    /**
     * 행정표준용어 리스트 조회
     *
     * @param commAdministStdWordVO
     * @return
     * @throws Exception
     */
    public List<MapsCommAdministStdWordVO> selectAdministStdWordPgList(MapsCommAdministStdWordVO commAdministStdWordVO) throws Exception;
    
    /**
     * 행정표준용어 저장
     *
     * @param loginInfo
     * @return
     */
    public int multiAdministStdWord(LoginInfoVO loginInfo, List<MapsCommAdministStdWordVO> administStdWords) throws Exception;
    
    /**
     * 행정표준영문약어 조회
     *
     * @param administStdWords
     * @return
     * @throws Exception
     */
    public List<MapsCommAdministStdWordVO> selectAdministStdEngAbrv(List<MapsCommAdministStdWordVO> administStdWords) throws Exception;
}
