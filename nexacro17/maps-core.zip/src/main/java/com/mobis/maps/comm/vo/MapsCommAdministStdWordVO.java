package com.mobis.maps.comm.vo;

import java.util.Date;

/**
 * <pre>
 * 행정표준용어 항목
 * </pre>
 *
 * @ClassName   : MapsCommAdministStdWordVO.java
 * @Description : 행정표준용어에 대한 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsCommAdministStdWordVO extends PgBascVO {
    /** 번호 */ 
    private int seq;
    /** 용어구분 */ 
    private String wordSe;
    /** 용어명 */ 
    private String wordNm;
    /** 용어영문명 */ 
    private String wordEngNm;
    /** 영문약어명 */ 
    private String engAbrvNm;
    /** 용어정의 */ 
    private String wordDfn;
    /** 주제영역 */ 
    private String themaRelm;
    /** 등록일 */ 
    private Date rgsde;
    /** 사용여부 */ 
    private String useYn;
    
    /**
     * @return the seq
     */
    public int getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(int seq) {
        this.seq = seq;
    }
    /**
     * @return the wordSe
     */
    public String getWordSe() {
        return wordSe;
    }
    /**
     * @param wordSe the wordSe to set
     */
    public void setWordSe(String wordSe) {
        this.wordSe = wordSe;
    }
    /**
     * @return the wordNm
     */
    public String getWordNm() {
        return wordNm;
    }
    /**
     * @param wordNm the wordNm to set
     */
    public void setWordNm(String wordNm) {
        this.wordNm = wordNm;
    }
    /**
     * @return the wordEngNm
     */
    public String getWordEngNm() {
        return wordEngNm;
    }
    /**
     * @param wordEngNm the wordEngNm to set
     */
    public void setWordEngNm(String wordEngNm) {
        this.wordEngNm = wordEngNm;
    }
    /**
     * @return the engAbrvNm
     */
    public String getEngAbrvNm() {
        return engAbrvNm;
    }
    /**
     * @param engAbrvNm the engAbrvNm to set
     */
    public void setEngAbrvNm(String engAbrvNm) {
        this.engAbrvNm = engAbrvNm;
    }
    /**
     * @return the wordDfn
     */
    public String getWordDfn() {
        return wordDfn;
    }
    /**
     * @param wordDfn the wordDfn to set
     */
    public void setWordDfn(String wordDfn) {
        this.wordDfn = wordDfn;
    }
    /**
     * @return the themaRelm
     */
    public String getThemaRelm() {
        return themaRelm;
    }
    /**
     * @param themaRelm the themaRelm to set
     */
    public void setThemaRelm(String themaRelm) {
        this.themaRelm = themaRelm;
    }
    /**
     * @return the rgsde
     */
    public Date getRgsde() {
        return rgsde;
    }
    /**
     * @param rgsde the rgsde to set
     */
    public void setRgsde(Date rgsde) {
        this.rgsde = rgsde;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
}
