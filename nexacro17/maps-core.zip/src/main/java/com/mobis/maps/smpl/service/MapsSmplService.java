package com.mobis.maps.smpl.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.smpl.vo.MapsSmplAtchFileVO;
import com.mobis.maps.smpl.vo.MapsSmplFileUpVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsSmplService {

    public int multiSmplAtchFile(MapsSmplAtchFileVO smplAtchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception;

    public MapsSmplFileUpVO selectFileUpload(HttpServletRequest request, String atchSe) throws Exception;
}
