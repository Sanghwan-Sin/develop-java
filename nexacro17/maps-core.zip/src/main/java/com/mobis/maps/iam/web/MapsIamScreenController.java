package com.mobis.maps.iam.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamScreenService;
import com.mobis.maps.iam.vo.MapsIamFnctVO;
import com.mobis.maps.iam.vo.MapsIamScreenCompnVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;
import com.mobis.maps.iam.vo.MapsIamScrinUrlVO;
import com.mobis.maps.iam.vo.MapsIamWordDicaryVO;

/**
 * <pre>
 * 화면관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamScreenController.java
 * @Description : 화면관리에 대한 컨트롤러 정의
 * @author DT048657
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     DT048657     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamScreenController extends HController {

    @Resource(name = "mapsIamScreenService")
    private MapsIamScreenService mapsIamScreenService;
    
    /**
     * 화면관리 조회
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenPgList.do")
    public NexacroResult selectScreenPgList(
            @ParamDataSet(name="dsInput") MapsIamScreenVO iamScreenVO
            , NexacroResult result) throws Exception {
        
        List<MapsIamScreenVO> screenInfos = mapsIamScreenService.selectScreenPgList(iamScreenVO);
        
        result.addDataSet("dsOutput", screenInfos);
        
        return result;
    }
    
    /**
     * 화면 상세 저장 
     * 
     * @param screenInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiScreenInfo.do")
    public NexacroResult multiScreenInfo(
            @ParamDataSet(name="dsInput") List<MapsIamScreenVO> screenInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamScreenService.multiScreenInfo(screenInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
       
    /**
     * 화면관리 액셀다운로드
     *
     * @param iamScreenVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenListExcelDown.do")
    public NexacroResult selectScreenListExcelDown(
            @ParamDataSet(name="dsInput") MapsIamScreenVO iamScreenVO
            , NexacroResult result) throws Exception {

        iamScreenVO.setExcelDwnlYn(MapsConstants.YN_YES);
        iamScreenVO.setPgNum(1);
        iamScreenVO.setPgSize(iamScreenVO.getTotMaxCnt());

        List<MapsIamScreenVO> screenInfos = mapsIamScreenService.selectScreenPgList(iamScreenVO);

        result.addDataSet("dsOutput", screenInfos);

        return result;
    }
        
    /**
     * 화면관리 엑셀업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectScreenListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<MapsIamScreenVO> scrinInfos = new ArrayList<MapsIamScreenVO>();

        List<String[]> lstCellVal = ExcelUtil.importExcelToList(request, 1, 13, 0, "N");
        
        if (lstCellVal != null && !lstCellVal.isEmpty()) {

            for (String[] arrCellVal : lstCellVal) {

                MapsIamScreenVO iamScreenVO = new MapsIamScreenVO();
                
                iamScreenVO.setSysSeCd(arrCellVal[1]);
                iamScreenVO.setScrinCd(arrCellVal[2]);
                iamScreenVO.setWordId(arrCellVal[3]);
                iamScreenVO.setAbbrevWordUseCd(arrCellVal[5]);
                iamScreenVO.setScrinUrl(arrCellVal[6]);
                iamScreenVO.setPopupYn(arrCellVal[7]);
                iamScreenVO.setScrinDc(arrCellVal[8]);
                iamScreenVO.setDrmScrinYn(arrCellVal[9]);
                iamScreenVO.setDrmFileYn(arrCellVal[10]);
                iamScreenVO.setIndvdlinfoUseYn(arrCellVal[11]);
                iamScreenVO.setUseYn(arrCellVal[12]);
                
                scrinInfos.add(iamScreenVO);
            }
        }

        result.addDataSet("dsOutput", scrinInfos);

        return result;
    }
    
    
    /**
     * 화면관리 팝업 조회
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenPgPopList.do")
    public NexacroResult selectScreenPgPopList(
            @ParamDataSet(name="dsInput") MapsIamScreenVO iamScreenVO
            , NexacroResult result) throws Exception {
        
        List<MapsIamScreenVO> ScreenInfos = mapsIamScreenService.selectScreenPgPopList(iamScreenVO);
        
        result.addDataSet("dsOutput", ScreenInfos);
        
        return result;
    }
    
    /**
     * 화면 컨포넌트 페이징 조회
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenCompnPgList.do")
    public NexacroResult selectScreenCompnPgList(
            @ParamDataSet(name="dsInput") MapsIamScreenCompnVO iamScreenCompnVO
            , NexacroResult result) throws Exception {
        
        List<MapsIamScreenCompnVO> screenCompnInfos = mapsIamScreenService.selectScreenCompnPgList(iamScreenCompnVO);
        
        result.addDataSet("dsOutput", screenCompnInfos);
        
        return result;
    }

    /**
     * 화면 컨포넌트 조회
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenCompnList.do")
    public NexacroResult selectScreenCompnList(
            @ParamDataSet(name="dsInput") MapsIamScreenCompnVO iamScreenCompnVO
            , NexacroResult result) throws Exception {
        
        List<MapsIamScreenCompnVO> screenCompnInfos = mapsIamScreenService.selectScreenCompnList(iamScreenCompnVO);
        
        result.addDataSet("dsOutput", screenCompnInfos);
        
        return result;
    }
    
    /**
     * 화면 컴포넌트 저장 
     * 
     * @param screenCompnInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiScreenCompnInfo.do")
    public NexacroResult multiScreenCompnInfo(
            @ParamDataSet(name="dsInput") List<MapsIamScreenCompnVO> screenCompnInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamScreenService.multiScreenCompnInfo(screenCompnInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    
    /**
     * 화면 컴포넌트 액셀다운로드
     *
     * @param iamScreenCompnVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenCompnListExcelDown.do")
    public NexacroResult selectScreenCompnListExcelDown(
            @ParamDataSet(name="dsInput") MapsIamScreenCompnVO iamScreenCompnVO
            , NexacroResult result) throws Exception {

        List<MapsIamScreenCompnVO> screenCompnInfos = mapsIamScreenService.selectScreenCompnList(iamScreenCompnVO);

        result.addDataSet("dsOutput", screenCompnInfos);

        return result;
    }
        
    /**
     * 화면 컴포넌트 엑셀업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenCompnListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectScreenCompnListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamScreenCompnVO> scrinCompnInfos = new ArrayList<MapsIamScreenCompnVO>();

        List<String[]> lstCellVal = ExcelUtil.importExcelToList(request, 1, 5, 0, "N");
        
        if (lstCellVal != null && !lstCellVal.isEmpty()) {

            for (String[] arrCellVal : lstCellVal) {

                MapsIamScreenCompnVO iamScrinCompnVO = new MapsIamScreenCompnVO();
                
                iamScrinCompnVO.setScrinId(arrCellVal[0]);
                iamScrinCompnVO.setCompnId(arrCellVal[1]);
                iamScrinCompnVO.setWordId(arrCellVal[2]);
                iamScrinCompnVO.setAbbrevWordUseCd(arrCellVal[4]);
                if (StringUtils.isNotBlank(iamScrinCompnVO.getWordId())) {
                    MapsIamWordDicaryVO iamWdDic = mapsIamScreenService.selectScreenCompnWdDic(iamScrinCompnVO, loginInfo);
                    if (iamWdDic != null) {
                        iamScrinCompnVO.setOrginlWord(iamWdDic.getOrginlWord());
                        iamScrinCompnVO.setAbbrevWord1(iamWdDic.getAbbrevWord1());
                        iamScrinCompnVO.setAbbrevWord2(iamWdDic.getAbbrevWord2());
                        iamScrinCompnVO.setAbbrevWord3(iamWdDic.getAbbrevWord3());
                        iamScrinCompnVO.setAbbrevWord4(iamWdDic.getAbbrevWord4());
                        iamScrinCompnVO.setAbbrevWord5(iamWdDic.getAbbrevWord5());
                    }
                }
                
                scrinCompnInfos.add(iamScrinCompnVO);
            }
        }

        result.addDataSet("dsOutput", scrinCompnInfos);

        return result;
    }
    
    
    /**
     * 화면 Function 페이징 조회
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenFnctPgList.do")
    public NexacroResult selectScreenFnctPgList(
            @ParamDataSet(name="dsInput") MapsIamFnctVO iamFnctVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamFnctVO> screenFnctInfos = mapsIamScreenService.selectScreenFnctPgList(iamFnctVO, loginInfo);
        
        result.addDataSet("dsOutput", screenFnctInfos);
        
        return result;
    }
    
    /**
     * 화면 Function 조회
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenFnctList.do")
    public NexacroResult selectScreenFnctList(
            @ParamDataSet(name="dsInput") MapsIamFnctVO iamFnctVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamFnctVO> screenFnctInfos = mapsIamScreenService.selectScreenFnctList(iamFnctVO, loginInfo);
        
        result.addDataSet("dsOutput", screenFnctInfos);
        
        return result;
    }
    
    /**
     * 화면 Function 저장 
     * 
     * @param screenCompnInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiScreenFnctInfo.do")
    public NexacroResult multiScreenFnctInfo(
            @ParamDataSet(name="dsInput") List<MapsIamFnctVO> screenFnctInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamScreenService.multiScreenFnctInfo(screenFnctInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    
    /**
     * 화면 Function 액셀다운로드
     *
     * @param iamScreenFnctVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenFnctListExcelDown.do")
    public NexacroResult selectScreenFnctListExcelDown(
            @ParamDataSet(name="dsInput") MapsIamFnctVO iamScreenFnctVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamFnctVO> screenFnctInfos = mapsIamScreenService.selectScreenFnctList(iamScreenFnctVO, loginInfo);

        result.addDataSet("dsOutput", screenFnctInfos);

        return result;
    }
        
    /**
     * 화면 Function 엑셀업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScreenFnctListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectScreenFnctListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<MapsIamFnctVO> scrinFnctInfos = new ArrayList<MapsIamFnctVO>();

        List<String[]> lstCellVal = ExcelUtil.importExcelToList(request, 1, 3, 0, "N");
        
        if (lstCellVal != null && !lstCellVal.isEmpty()) {

            for (String[] arrCellVal : lstCellVal) {

                MapsIamFnctVO iamScrinFnctVO  =  new MapsIamFnctVO();

                iamScrinFnctVO.setScrinId(arrCellVal[0]);
                iamScrinFnctVO.setFnctId(arrCellVal[1]);
                iamScrinFnctVO.setCompnId(arrCellVal[2]);
                
                scrinFnctInfos.add(iamScrinFnctVO);
            }
        }

        result.addDataSet("dsOutput", scrinFnctInfos);

        return result;
    }

    /**
     * 화면URL관리 리스트 조회
     *
     * @param iamScrinUrlVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectScrinUrlList.do")
    public NexacroResult selectScrinUrlList(
            @ParamDataSet(name="dsInput") MapsIamScrinUrlVO iamScrinUrlVO
            , NexacroResult result) throws Exception {
        
        List<MapsIamScrinUrlVO> scrinUrls = mapsIamScreenService.selectScrinUrlList(iamScrinUrlVO);
        
        result.addDataSet("dsOutput", scrinUrls);
        
        return result;
    }
    
    /**
     * 화면URL관리 저장 
     *
     * @param scrinUrls
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiScrinUrlInfo.do")
    public NexacroResult multiScrinUrlInfo(
            @ParamDataSet(name="dsInput") List<MapsIamScrinUrlVO> scrinUrls
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamScreenService.multiScrinUrlInfo(scrinUrls, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
}
