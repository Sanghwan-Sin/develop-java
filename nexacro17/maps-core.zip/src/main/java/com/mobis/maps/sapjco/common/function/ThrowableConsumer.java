package com.mobis.maps.sapjco.common.function;

import java.util.function.Consumer;

import com.mobis.maps.cmmn.exception.MapsRuntimeException;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ThrowableConsumer.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 5. 8.     DT045877     	최초 생성
 * </pre>
 */
@FunctionalInterface
public interface ThrowableConsumer<T> {
    /**
     * @see
     * java.util.function.Consumer
     * 
     * @param t
     * input parameter type T
     * 
     * @throws Exception
     */
    void accept(T t) throws Exception;
    
    /**
     * throws Exception lambda to throws RuntimeException lambda
     * @param consumer
     * @return
     * @since
     * 0.6
     */
    public static <T> Consumer<T> runtime(ThrowableConsumer<T> consumer) {
        return t -> {
            try {
                consumer.accept(t);
            } catch (Exception e) {
                throw new MapsRuntimeException(e);
            }
        };
    }
    
    /**
     * ignore exception<br>
     * this method recommend only special situation 
     * @param consumer
     * @return
     * @since
     * 1.1
     */
    public static <T> Consumer<T> ignore(ThrowableConsumer<T> consumer) {
        return t -> {
            try {
                consumer.accept(t);
            } catch (Exception e) {
            }
        };
    }
}