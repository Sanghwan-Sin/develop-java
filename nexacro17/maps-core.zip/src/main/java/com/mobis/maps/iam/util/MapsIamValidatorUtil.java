package com.mobis.maps.iam.util;

import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.spring.SpringApplicationContext;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.comm.service.MapsCommCodeService;
import com.mobis.maps.comm.service.MapsCommLanguageService;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.vo.MapsIamCommVO;
import com.mobis.maps.iam.vo.MapsIamMobisOrgnztVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserOrgnztVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * Iam정합성 유딜리티
 * </pre>
 *
 * @ClassName   : MapsIamValidatorUtil.java
 * @Description : Iam정합성에 대한 유딜리티를 정의.
 * @author DT048058
 * @since 2020. 9. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 14.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamValidatorUtil {

    protected final static Logger logger = LoggerFactory.getLogger(MapsIamValidatorUtil.class);

    private static MapsCommCodeService mapsCommCodeService;
    private static MapsCommLanguageService mapsCommLanguageService;
    private static MapsIamMobisUserService mapsIamMobisUserService;
    
    public static MapsCommCodeService getMapsCommCodeService() {
        
        if (mapsCommCodeService == null) {
            mapsCommCodeService = (MapsCommCodeService)SpringApplicationContext.getBean("MapsCommCodeService");
        }
        
        return mapsCommCodeService;
    }
    
    public static MapsCommLanguageService getMapsCommLanguageService() {
        
        if (mapsCommLanguageService == null) {
            mapsCommLanguageService = (MapsCommLanguageService)SpringApplicationContext.getBean("mapsCommLanguageService");
        }
        
        return mapsCommLanguageService;
    }
    
    public static MapsIamMobisUserService getMapsIamMobisUserService() {
        
        if (mapsIamMobisUserService == null) {
            mapsIamMobisUserService = (MapsIamMobisUserService)SpringApplicationContext.getBean("mapsIamMobisUserService");
        }
        
        return mapsIamMobisUserService;
    }
    
    /**
     * Nexacro Dataset 설정
     *
     * @param iamCommVO
     */
    public static void setRowType(MapsIamCommVO iamCommVO) {
        
        String procTy = iamCommVO.getProcTy();
        
        if (StringUtils.equals(MapsConstants.CRUD_CREATE, procTy)) {
            iamCommVO.setRowType(DataSet.ROW_TYPE_INSERTED);
        } else if (StringUtils.equals(MapsConstants.CRUD_UPDATE, procTy)) {
            iamCommVO.setRowType(DataSet.ROW_TYPE_UPDATED);
        } else if (StringUtils.equals(MapsConstants.CRUD_DELETE, procTy)) {
            iamCommVO.setRowType(DataSet.ROW_TYPE_DELETED);
        }
    }
    
    /**
     * IAM서버 여부
     *
     * @return
     */
    public static boolean isIamServer() {
        return StringUtils.equals(PropertiesUtil.getMapsSysSeCd(), MapsConstants.SYS_SE_CD_IAM);
    }
    
    /**
     * IT운영자
     *
     * @param acntTyCd
     * @return
     */
    public static boolean isSystemUser(String acntTyCd) {
        return MapsIamConstants.ACCOUNT_TYPE_CD_SYSTEM.equals(acntTyCd);
    }

    /**
     * 마스터사용자
     *
     * @param acntTyCd
     * @return
     */
    public static boolean isMasterUser(String acntTyCd) {
        return MapsIamConstants.ACCOUNT_TYPE_CD_MASTER.equals(acntTyCd);
    }

    /**
     * 일반사용자
     *
     * @param acntTyCd
     * @return
     */
    public static boolean isNormalUser(String acntTyCd) {
        return MapsIamConstants.ACCOUNT_TYPE_CD_NOMAL.equals(acntTyCd);
    }

    /**
     * 조직구분에 대한 모비스본사 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isMobis(String orgnztSeCd) {
        return StringUtils.equals(orgnztSeCd, MapsConstants.ORGNZT_SE_CD_MOBIS);
    }

    /**
     * 조직구분에 대한 모비스법인 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isMobisCpr(String orgnztSeCd) {
        return StringUtils.equals(orgnztSeCd, MapsConstants.ORGNZT_SE_CD_MOBIS);
    }
    
    /**
     * 조직구분에 대한 일반대리점 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isGnrlDist(String orgnztSeCd) {
        return StringUtils.equals(orgnztSeCd, MapsConstants.ORGNZT_SE_CD_GENERAL_DISTRIBUTORS);
    }

    /**
     * 조직구분에 대한 국내외협력업체 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isVendor(String orgnztSeCd) {
        return StringUtils.equals(orgnztSeCd, MapsConstants.ORGNZT_SE_CD_VENDOR);
    }
    
    /**
     * 조직구분에 대한 직배대리점 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isDirectDist(String orgnztSeCd) {
        return StringUtils.equals(orgnztSeCd, MapsConstants.ORGNZT_SE_CD_DIRECT_DISTRIBUTORS);
    }
    
    /**
     * 조직구분에 대한 직배딜러 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isDirectDealer(String orgnztSeCd) {
        return StringUtils.equals(orgnztSeCd, MapsConstants.ORGNZT_SE_CD_DIRECT_DEALER);
    }
    
    /**
     * 조직구분에 대한 PDA 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isPda(String orgnztSeCd) {
        return StringUtils.equals(orgnztSeCd, MapsConstants.ORGNZT_SE_CD_PDA);
    }
    
    private static String regexMobisOrgnzt;
    public static String getRegexMobisOrgnzt() {
        if (regexMobisOrgnzt == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(MapsConstants.ORGNZT_SE_CD_GENERAL_DISTRIBUTORS);
            sb.append("|");
            sb.append(MapsConstants.ORGNZT_SE_CD_VENDOR);
            sb.append("|");
            sb.append(MapsConstants.ORGNZT_SE_CD_DIRECT_DISTRIBUTORS);
            sb.append("|");
            sb.append(MapsConstants.ORGNZT_SE_CD_DIRECT_DEALER);
            regexMobisOrgnzt = sb.toString();
        }
        return regexMobisOrgnzt;
    }
    
    /**
     * 모비스조직 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isMobisOrgnzt(String orgnztSeCd) {
        
        return !orgnztSeCd.matches(getRegexMobisOrgnzt());//orgnztSeCd.matches("M|C|P");
    }
    
    /**
     * 모비스조직외 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isNotMobisOrgnzt(String orgnztSeCd) {
        return orgnztSeCd.matches(getRegexMobisOrgnzt());
    }

    /**
     * 사용자ID 자동채번 여부
     *
     * @param orgnztSeCd
     * @return
     */
    public static boolean isAutoCountUserId(String orgnztSeCd) {
        /*
         *  계정ID 자동 채번
         *  - 계정ID를 채번하는 조직구분코드(N:국내외 협력업체/G:일반대리점)를 구분자("|") 로 설정 예)"G|N"
         */
        String autoUserIdOrgnztSeCds = PropertiesUtil.getDbValue(MapsIamConstants.DBPROP_KEY_USER_ID_SEQ);
        
        return StringUtils.contains(autoUserIdOrgnztSeCds, orgnztSeCd);
    }
    
    /**
     * 메세지 조회(용어ID 사용)
     *
     * @param msgCd
     * @param wordId
     * @param locale
     * @return
     */
    public static String getMessageByWordId(String msgCd, String wordId, Locale locale) {
        return getMessageByWordId(msgCd, new String[]{wordId}, MapsIamConstants.ABBREV_WORD_USE_CD_ORIGINAL, locale);
    }

    /**
     * 메세지 조회(용어ID 사용)
     *
     * @param msgCd
     * @param wordId
     * @param abbrevWordUseCd
     * @param locale
     * @return
     */
    public static String getMessageByWordId(String msgCd, String[] wordIds, Locale locale) {
        return getMessageByWordId(msgCd, wordIds, MapsIamConstants.ABBREV_WORD_USE_CD_ORIGINAL, locale);
    }

    /**
     * 메세지 조회(용어ID 사용)
     *
     * @param msgCd
     * @param wordId
     * @param abbrevWordUseCd
     * @param locale
     * @return
     */
    public static String getMessageByWordId(String msgCd, String wordId, String abbrevWordUseCd, Locale locale) {
        return getMessageByWordId(msgCd, new String[]{wordId}, abbrevWordUseCd, locale);
    }
    
    /**
     * 메세지 조회(용어ID 사용)
     *
     * @param msgCd
     * @param wordIds
     * @param abbrevWordUseCd
     * @param locale
     * @return
     */
    public static String getMessageByWordId(String msgCd, String[] wordIds, String abbrevWordUseCd, Locale locale) {

        Object[] args = new Object[0];
        for (String wordId: wordIds) {
            String word = null;
            try {
                word = getMapsCommLanguageService().selectWord(wordId, abbrevWordUseCd, locale);
            } catch (Exception ex) {
                word = wordId;
            }
            args = ArrayUtils.add(args, word);
        }
        
        return MessageUtil.getMessage(msgCd, args, locale);
    }

    public static String getMessageInValied(String wordId, Locale locale) {
        return MapsIamValidatorUtil.getMessageByWordId("EC00000011", wordId, locale);
    }
    
    /**
     * 필수항목 예외 메세지
     *
     * @param wordId
     * @param locale
     * @return
     */
    public static String getMessageRequired(String wordId, Locale locale) {
        return MapsIamValidatorUtil.getMessageByWordId("EC00000001", wordId, locale);
    }

    /**
     * 필수항목 정합성 체크
     *
     * @param obj
     * @param wordId
     * @param locale
     * @throws MapsBizException
     */
    public static void validateRequired(Object obj, String wordId, Locale locale) throws MapsBizException {
        
        boolean isRequired = false;
        if(obj instanceof String && StringUtils.isBlank((String)obj)) {
            isRequired = true;
        } else if (obj == null) {
            isRequired = true;
        }
        if (isRequired) {
            String msg = MapsIamValidatorUtil.getMessageByWordId("EC00000001", wordId, locale);
            throw new MapsBizException(msg);
        }
    }

    /**
     * 일반사용자인 경우 예외처리 
     *
     * @param loginInfo
     * @throws Exception
     */
    public static void validateOperatorUser(LoginInfoVO loginInfo) throws Exception {
        if (MapsIamValidatorUtil.isNormalUser(loginInfo.getAcntTyCd())) {
            //해당 서비스에 대한 권한이 없습니다.
            throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000010", loginInfo.getUserLcale(), null);
        }
    }

    /**
     * IT운영자가 아닌 경우 예외처리 
     *
     * @param loginInfo
     * @throws Exception
     */
    public static void validateNotSystemUser(LoginInfoVO loginInfo) throws Exception {
        if (!MapsIamValidatorUtil.isSystemUser(loginInfo.getAcntTyCd())) {
            //해당 서비스에 대한 권한이 없습니다.
            throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000010", loginInfo.getUserLcale(), null);
        }
    }
    
    /**
     * 조직정보 정합성 체크
     *
     * @param orgnztSeCd
     * @param bsnOrgnztCd
     * @param orgnztCd
     * @param dealerCd
     * @param loginInfo
     * @throws Exception
     */
    public static void validateOrgnztInfo(MapsIamUserOrgnztVO iamUserOrgnztVO, LoginInfoVO loginInfo) throws Exception {

        String orgnztSeCd = iamUserOrgnztVO.getOrgnztSeCd();
        String bsnOrgnztCd = iamUserOrgnztVO.getBsnOrgnztCd();
        String orgnztCd = iamUserOrgnztVO.getOrgnztCd();
        String dealerCd = iamUserOrgnztVO.getDealerCd();
        
        /* 필수항목체크 */
        //조직구분은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(orgnztSeCd, "WI000000001", loginInfo.getUserLcale());
        //모비스법인은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(bsnOrgnztCd, "WI000000237", loginInfo.getUserLcale());
        //모비스본사의 모비스법인코드가 아닙니다.
        if (orgnztSeCd.equals(MapsConstants.ORGNZT_SE_CD_MOBIS)
                && !bsnOrgnztCd.equals(MapsConstants.BSN_ORGNZT_CD_MOBIS)) {
            throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000077", loginInfo.getUserLcale(), null);
        }
        //조직코드는 필수 항목입니다.
        if (isNotMobisOrgnzt(orgnztSeCd)) {
            MapsIamValidatorUtil.validateRequired(orgnztCd, "WI000000002", loginInfo.getUserLcale());
        }
        //딜러코드는 필수 항목입니다.
        if (StringUtils.equals(orgnztSeCd, MapsConstants.ORGNZT_SE_CD_DIRECT_DEALER)) {
            MapsIamValidatorUtil.validateRequired(dealerCd, "WI000000003", loginInfo.getUserLcale());
        }
        
        /* 로그인 사용자에 대한 계정유형별 체크 */
        String loginOrgnztSeCd = loginInfo.getOrgnztSeCd();
        String loginBsnOrgnztCd = loginInfo.getBsnOrgnztCd();
        String loginOrgnztCd = loginInfo.getOrgnztCd();
        String loginAcntTyCd = loginInfo.getAcntTyCd();
        if (StringUtils.equals(loginAcntTyCd, MapsIamConstants.ACCOUNT_TYPE_CD_MASTER)) {
            if (StringUtils.equals(loginOrgnztSeCd, MapsIamConstants.ORGNZT_SE_CD_CORPORATION) && !loginBsnOrgnztCd.equals(bsnOrgnztCd)) {
                //현재 사용자 권한으로 모비스법인을 변경 설정할 수 없습니다.
                throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000013", loginInfo.getUserLcale(), null);
            }
            if (!isMobisOrgnzt(loginOrgnztSeCd) && !loginOrgnztSeCd.equals(orgnztSeCd)) {
                //현재 사용자 권한으로 조직구분을 변경 설정할 수 없습니다.
                throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000014", loginInfo.getUserLcale(), null);
            }
            //일반대리점의 사용자가 대표대리점 사용자이면
            if (StringUtils.equals(loginOrgnztSeCd, MapsIamConstants.ORGNZT_SE_CD_GENERAL_DISTRIBUTOR) && loginInfo.isRepZkunnr()) {
                MapsIamMobisOrgnztVO iamMobisOrgnztVO = new MapsIamMobisOrgnztVO();
                iamMobisOrgnztVO.setBsnOrgnztCd(loginBsnOrgnztCd);
                iamMobisOrgnztVO.setOrgnztCd(loginOrgnztCd);
                List<MapsOrgnztDistVO> mobisOrgnzts = getMapsIamMobisUserService().selectOrgnztDistInfoList(loginInfo);
                boolean hasSubZkunnr = false;
                for (MapsOrgnztDistVO iamMobisOrgnzt: mobisOrgnzts) {
                    if (StringUtils.equals(iamMobisOrgnzt.getKunnr(), orgnztCd)) {
                        hasSubZkunnr = true;
                        break;
                    }
                }
                if (!hasSubZkunnr) {
                    //현재 사용자 권한으로 조직을 변경 설정할 수 없습니다.
                    throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000015", loginInfo.getUserLcale(), null);
                }
            } else {
                if (!loginOrgnztCd.equals(orgnztCd)) {
                    //현재 사용자 권한으로 조직을 변경 설정할 수 없습니다.
                    throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000015", loginInfo.getUserLcale(), null);
                }
            }
        }
    }

    /**
     * 시스템구분코드에 대한 시스템구분코드 정합성 체크
     *
     * @param sysSeCd
     * @param orgnztSeCd
     * @param loginInfo
     * @throws Exception
     */
    public static void validateOrgnztSeCdBySysSeCd(String sysSeCd, String orgnztSeCd, LoginInfoVO loginInfo) throws Exception {
        // 조직구분은 유효하지 않는 값입니다.
        if (sysSeCd.equals(MapsConstants.SYS_SE_CD_NMGN)) {
            if (!orgnztSeCd.matches("M|C|G")) {
                throw new MapsBizException(MapsIamValidatorUtil.getMessageInValied("WI000000001", loginInfo.getUserLcale()));
            }
        } else if (sysSeCd.equals(MapsConstants.SYS_SE_CD_SRS)) {
            if (!orgnztSeCd.matches("M|C|N")) {
                throw new MapsBizException(MapsIamValidatorUtil.getMessageInValied("WI000000001", loginInfo.getUserLcale()));
            }
        } else if (sysSeCd.equals(MapsConstants.SYS_SE_CD_PDA)) {
            if (!orgnztSeCd.matches("M|C|P")) {
                throw new MapsBizException(MapsIamValidatorUtil.getMessageInValied("WI000000001", loginInfo.getUserLcale()));
            }
        } else if (sysSeCd.equals(MapsConstants.SYS_SE_CD_DCS)) {
            if (!orgnztSeCd.matches("M|C|D|E")) {
                throw new MapsBizException(MapsIamValidatorUtil.getMessageInValied("WI000000001", loginInfo.getUserLcale()));
            }
        } else {
            if (!orgnztSeCd.matches("M|C")) {
                throw new MapsBizException(MapsIamValidatorUtil.getMessageInValied("WI000000001", loginInfo.getUserLcale()));
            }
        }
    }
    
    /**
     * 사용자기본정보에 대한 사용자조직정보 정합성체크
     *
     * @param iamUserBassInfoVO
     * @param iamUserVO
     * @param loginInfo
     * @throws Exception
     */
    public static void validateOrgnztByUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {

        //등록된 사용자기본정보가 없습니다.
        if (iamUserBassInfoVO == null) {
            throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000044", loginInfo.getUserLcale(), null);    
        }
//        if (MapsIamValidatorUtil.isNotMobisOrgnzt(iamUserBassInfoVO.getOrgnztSeCd())) {
//            if (MapsIamValidatorUtil.isNormalUser(iamUserVO.getAcntTyCd())) {
//                if (!StringUtils.equals(iamUserBassInfoVO.getOrgnztSeCd(), iamUserVO.getOrgnztSeCd())) {
//                    // 사용자기본정보의 조직구분코드와 동일한 값으로 조직구분을 입력하세요.
//                    throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000072", loginInfo.getUserLcale(), null);    
//                }
//                if (!StringUtils.equals(iamUserBassInfoVO.getBsnOrgnztCd(), iamUserVO.getBsnOrgnztCd())) {
//                    // 사용자기본정보의 모비스법인코드와 동일한 값으로 모비스법인을 입력하세요.
//                    throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000073", loginInfo.getUserLcale(), null);    
//                }
//                if (!StringUtils.equals(iamUserBassInfoVO.getOrgnztCd(), iamUserVO.getOrgnztCd())) {
//                    // 사용자기본정보의 조직코드와 동일한 값으로 조직을 입력하세요.
//                    throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000074", loginInfo.getUserLcale(), null);    
//                }
//                if (MapsIamValidatorUtil.isDirectDealer(iamUserVO.getOrgnztSeCd())) {
//                    if (!StringUtils.equals(iamUserBassInfoVO.getDealerCd(), iamUserVO.getDealerCd())) {
//                        // 사용자기본정보의 딜러코드와 동일한 값으로 딜러을 입력하세요.
//                        throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000075", loginInfo.getUserLcale(), null);    
//                    }
//                }
//            }
//        } else if (MapsIamValidatorUtil.isMobisCpr(iamUserBassInfoVO.getOrgnztSeCd())) {
//            if (!StringUtils.equals(iamUserBassInfoVO.getBsnOrgnztCd(), iamUserVO.getBsnOrgnztCd())) {
//                // 사용자기본정보의 모비스법인코드와 동일한 값으로 모비스법인을 입력하세요.
//                throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000073", loginInfo.getUserLcale(), null);    
//            }
//        }
    }

    private static String regexNmgnDist;
    public static String getRegexNmgnDist() {
        if (regexNmgnDist == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(MapsIamConstants.NMGN_KDGRP_XPORT_MOBIS);
            sb.append("|");
            sb.append(MapsIamConstants.NMGN_KDGRP_XPORT_DIST);
            sb.append("|");
            sb.append(MapsIamConstants.NMGN_KDGRP_XPORT_LOCAL);
            regexNmgnDist = sb.toString();
        }
        return regexNmgnDist;
    }

    /**
     * 대리점 조직 정합성 체크
     *
     * @param iamUserOrgnztVO
     * @param locale
     * @return
     * @throws Exception
     */
    public static MapsOrgnztDistVO validateDistOrgnzt(MapsIamUserOrgnztVO iamUserOrgnztVO, Locale locale) throws Exception {
        
        if (!isGnrlDist(iamUserOrgnztVO.getOrgnztSeCd())) {
            return null;
        }
        
        MapsOrgnztDistVO orgnztDistVO = getMapsIamMobisUserService().selectDistOrgnztInfo(iamUserOrgnztVO);
        if (orgnztDistVO == null) {
            // 등록된 대리점 정보가 없습니다.
            throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000086", locale, null);    
        }
        
        String kdgrp = orgnztDistVO.getKdgrp();
        if (StringUtils.isBlank(kdgrp) || !kdgrp.matches(getRegexNmgnDist())) {
            // 사용할 수 없는 대리점입니다.(고객그룹:{0})
            throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000087", new String[]{orgnztDistVO.getKdgrp()}, locale, null);    
        }
        
        return orgnztDistVO;
    }
    
    /**
     * 계정신청 대리점 조직 정합성 체크
     *
     * @param iamUserOrgnztVO
     * @param locale
     * @throws Exception
     */
    public static MapsOrgnztDistVO validateAcntReqstDistOrgnzt(MapsIamUserOrgnztVO iamUserOrgnztVO, Locale locale) throws Exception {
        
        MapsOrgnztDistVO orgnztDistVO = validateDistOrgnzt(iamUserOrgnztVO, locale);
        if (orgnztDistVO == null) {
            return null;
        }

        String kdgrp = orgnztDistVO.getKdgrp();
        if (MapsIamConstants.NMGN_KDGRP_XPORT_MOBIS.equals(kdgrp)) {
            // 계정신청 할 수 없는 대리점입니다.(고객그룹:{0})
            throw new MapsBizException(MessageUtil.getMessageSource(), "ECI0000088", new String[]{orgnztDistVO.getKdgrp()}, locale, null);    
        }
        
        return orgnztDistVO;
    }
}
