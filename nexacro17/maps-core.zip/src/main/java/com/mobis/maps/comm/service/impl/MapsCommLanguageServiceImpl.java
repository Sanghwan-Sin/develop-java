package com.mobis.maps.comm.service.impl;

import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommLanguageService;
import com.mobis.maps.comm.service.dao.MapsCommLanguageMDAO;
import com.mobis.maps.comm.vo.MapsCommLanguageVO;
import com.mobis.maps.comm.vo.MapsCommScrinFnctVO;

/**
 * <pre>
 * 다국어 관리 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommLanguageServiceImpl.java
 * @Description : 다국어 관리 서비스 구현.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
@Service("mapsCommLanguageService")
public class MapsCommLanguageServiceImpl extends HService implements MapsCommLanguageService {
    
    @Resource(name="mapsCommLanguageMDAO")
    private MapsCommLanguageMDAO mapsCommLanguageMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommLanguageService#selectLangList(com.mobis.maps.comm.vo.MapsCommLanguageVO)
     */
    @Override
    public List<MapsCommLanguageVO> selectLangList(MapsCommLanguageVO commLangVO) throws Exception {
        
        commLangVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        
        List<MapsCommLanguageVO> langInfos = mapsCommLanguageMDAO.selectLangList(commLangVO);
        
        return langInfos;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLanguageService#selectScrinFuncList(com.mobis.maps.comm.vo.MapsCommScrinFnctVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommScrinFnctVO> selectScrinFuncList(MapsCommScrinFnctVO commScrinFnctVO, LoginInfoVO loginInfo) throws Exception {
        
        commScrinFnctVO.setUserSeqId(loginInfo.getUserSeqId());
        
        List<MapsCommScrinFnctVO> fnctInfos = mapsCommLanguageMDAO.selectScrinFnctList(commScrinFnctVO);
        
        return fnctInfos;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLanguageService#selectWord(java.lang.String, java.lang.String, java.util.Locale)
     */
    @Override
    public String selectWord(String wordId, String abbrevWordUseCd, Locale locale) throws Exception {
        
        MapsCommLanguageVO commLangVO = new MapsCommLanguageVO();
        commLangVO.setWordId(wordId);
        commLangVO.setAbbrevWordUseCd(abbrevWordUseCd);
        commLangVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        commLangVO.setLangCd(MapsConstants.DFLT_LOCALE.toString());
        if (locale != null) {
            commLangVO.setLangCd(locale.toString());
        }
        
        return mapsCommLanguageMDAO.selectWord(commLangVO);
    }

}
