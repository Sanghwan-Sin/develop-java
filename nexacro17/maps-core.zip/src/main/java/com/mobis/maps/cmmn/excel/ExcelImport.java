package com.mobis.maps.cmmn.excel;

import java.util.Iterator;
import java.util.List;

import com.mobis.maps.cmmn.excel.support.RowMapper;
import com.mobis.maps.cmmn.exception.ExcelBindingException;

/**
 * <pre>
 * ExcelImport
 * </pre>
 *
 * @ClassName   : ExcelImport.java
 * @Description : ExcelImport
 * @author Sin Sanghwan
 * @since 2019. 8. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 6.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public interface ExcelImport extends ExcelFile {

    /** 첫번째 Row 가 컬럼 헤더이름인가? */
    public boolean isFirstRowisCellHeader();
    
    public void setFirstRowisCellHeader(boolean firstRowisCellHeader);

    /** 헤더 목록을 반환한다. */
    public List<String> getHeaders();

    /** Excel을 Row별로 pojoClass 에 바인딩 후 순차접근 */
    public <E> Iterator<E> iterator(Class<E> pojoClass) throws ExcelBindingException;

    /** Excel을 Row별로 pojoClass 에 바인딩 후 순차접근 */
    public <E> Iterator<E> iterator(RowMapper<E> dataReader) throws ExcelBindingException;

}
