package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommAdministStdWordVO;

/**
 * <pre>
 * 행정표준용어 데이터처리
 * </pre>
 *
 * @ClassName   : MapsCommAdministStdWordMDAO.java
 * @Description : 행정표준용어에 대한 데이터처리를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Mapper("mapsCommAdministStdWordMDAO")
public interface MapsCommAdministStdWordMDAO {

    /**
     * 행정표준용어 리스트 조회
     *
     * @param commAdministStdWordVO
     * @return
     * @throws Exception
     */
    public List<MapsCommAdministStdWordVO> selectAdministStdWordPgList(MapsCommAdministStdWordVO commAdministStdWordVO) throws Exception;
    
    /**
     * 행정표준용어 조회
     *
     * @param commAdministStdWordVO
     * @return
     * @throws Exception
     */
    public MapsCommAdministStdWordVO selectAdministStdWord(MapsCommAdministStdWordVO commAdministStdWordVO) throws Exception;
    
    /**
     * 행정표준용어 등록
     *
     * @param commAdministStdWordVO
     * @throws Exception
     */
    public void insertAdministStdWord(MapsCommAdministStdWordVO commAdministStdWordVO) throws Exception;
    
    /**
     * 행정표준용어 수정
     *
     * @param commAdministStdWordVO
     * @return
     * @throws Exception
     */
    public int updateAdministStdWord(MapsCommAdministStdWordVO commAdministStdWordVO) throws Exception;
    
    /**
     * 행정표준용어 삭제
     *
     * @param commAdministStdWordVO
     * @return
     * @throws Exception
     */
    public int deleteAdministStdWord(MapsCommAdministStdWordVO commAdministStdWordVO) throws Exception;
    
    /**
     * 행정표준영문약어 리스트 조회
     *
     * @param commAdministStdWordVO
     * @return
     * @throws Exception
     */
    public List<MapsCommAdministStdWordVO> selectAdministStdEngAbrvList(MapsCommAdministStdWordVO commAdministStdWordVO) throws Exception;
}
