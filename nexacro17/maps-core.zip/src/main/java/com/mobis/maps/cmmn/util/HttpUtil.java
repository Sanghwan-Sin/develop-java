package com.mobis.maps.cmmn.util;

import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : HttpUtil.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 5.     DT048058     	최초 생성
 * </pre>
 */

public class HttpUtil {

    public static Map<String, List<String>> parseQueryString(String queryString) throws Exception {
        
        Map<String, List<String>> params = new LinkedHashMap<String, List<String>>();

        String[] arrParam = StringUtils.split(queryString, "&");
        
        for (String param : arrParam) {
            
            int idx = param.indexOf("=");
            
            String key = idx > 0 ? URLDecoder.decode(param.substring(0, idx), "UTF-8") : param;
            if (!params.containsKey(key)) {
                params.put(key, new LinkedList<String>());
            }
            
            String value = idx > 0 && param.length() > idx + 1 ? URLDecoder.decode(param.substring(idx + 1), "UTF-8") : null;
            params.get(key).add(value);
        }
        
        return params;
    }
    
    public static String getParseQueryStringValue(Map<String, List<String>> params, String key) throws Exception {

        String value = null;
        
        if (params.containsKey(key)) {
            List<String> values = params.get(key);
            if (!values.isEmpty()) {
                value = values.get(0);
            }
        }
        
        return value;
    }
    
    public static List<String> getParseQueryStringValues(Map<String, List<String>> params, String key) throws Exception {
        
        List<String> values = null;
        
        if (params.containsKey(key)) {
            values = params.get(key);
        }
        
        return values;
    }
}
