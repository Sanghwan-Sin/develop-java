package com.mobis.maps.comm.vo;

import java.util.Date;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommSapDestConectInfoVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 24.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommSapDestConectInfoVO {
    /** Destination ID */
    private String destId;
    /** System ID */
    private String sysId;
    /** Protocol */
    private String prtcl;
    /** Thread ID */
    private String threadId;
    /** Thread Name */
    private String threadNm;
    /** Connection Type */
    private String conectTy;
    /** Connection Handle */
    private String conectHndl;
    /** State */
    private String state;
    /** ABAP System Number */
    private String abapSysNum;
    /** ABAP Host */
    private String abapHost;
    /** ABAP Client */
    private String abapClnt;
    /** ABAP Language */
    private String abapLang;
    /** ABAP User */
    private String abapUser;
    /** Application Name */
    private String aplctnNm;
    /** Session ID */
    private String sesionId;
    /** Conv ID */
    private String convId;
    /** DSR Passport */
    private String dsrPassport;
    /** Function Module Name */
    private String fncModuleNm;
    /** Last Activity Timestamp */
    private Date lastActvtyDt;
    /** Last Activity Timestamp */
    private String lastActvtyDate;
    
    /**
     * @return the destId
     */
    public String getDestId() {
        return destId;
    }
    /**
     * @param destId the destId to set
     */
    public void setDestId(String destId) {
        this.destId = destId;
    }
    /**
     * @return the sysId
     */
    public String getSysId() {
        return sysId;
    }
    /**
     * @param sysId the sysId to set
     */
    public void setSysId(String sysId) {
        this.sysId = sysId;
    }
    /**
     * @return the prtcl
     */
    public String getPrtcl() {
        return prtcl;
    }
    /**
     * @param prtcl the prtcl to set
     */
    public void setPrtcl(String prtcl) {
        this.prtcl = prtcl;
    }
    /**
     * @return the threadId
     */
    public String getThreadId() {
        return threadId;
    }
    /**
     * @param threadId the threadId to set
     */
    public void setThreadId(String threadId) {
        this.threadId = threadId;
    }
    /**
     * @return the threadNm
     */
    public String getThreadNm() {
        return threadNm;
    }
    /**
     * @param threadNm the threadNm to set
     */
    public void setThreadNm(String threadNm) {
        this.threadNm = threadNm;
    }
    /**
     * @return the conectTy
     */
    public String getConectTy() {
        return conectTy;
    }
    /**
     * @param conectTy the conectTy to set
     */
    public void setConectTy(String conectTy) {
        this.conectTy = conectTy;
    }
    /**
     * @return the conectHndl
     */
    public String getConectHndl() {
        return conectHndl;
    }
    /**
     * @param conectHndl the conectHndl to set
     */
    public void setConectHndl(String conectHndl) {
        this.conectHndl = conectHndl;
    }
    /**
     * @return the state
     */
    public String getState() {
        return state;
    }
    /**
     * @param state the state to set
     */
    public void setState(String state) {
        this.state = state;
    }
    /**
     * @return the abapSysNum
     */
    public String getAbapSysNum() {
        return abapSysNum;
    }
    /**
     * @param abapSysNum the abapSysNum to set
     */
    public void setAbapSysNum(String abapSysNum) {
        this.abapSysNum = abapSysNum;
    }
    /**
     * @return the abapHost
     */
    public String getAbapHost() {
        return abapHost;
    }
    /**
     * @param abapHost the abapHost to set
     */
    public void setAbapHost(String abapHost) {
        this.abapHost = abapHost;
    }
    /**
     * @return the abapClnt
     */
    public String getAbapClnt() {
        return abapClnt;
    }
    /**
     * @param abapClnt the abapClnt to set
     */
    public void setAbapClnt(String abapClnt) {
        this.abapClnt = abapClnt;
    }
    /**
     * @return the abapLang
     */
    public String getAbapLang() {
        return abapLang;
    }
    /**
     * @param abapLang the abapLang to set
     */
    public void setAbapLang(String abapLang) {
        this.abapLang = abapLang;
    }
    /**
     * @return the abapUser
     */
    public String getAbapUser() {
        return abapUser;
    }
    /**
     * @param abapUser the abapUser to set
     */
    public void setAbapUser(String abapUser) {
        this.abapUser = abapUser;
    }
    /**
     * @return the aplctnNm
     */
    public String getAplctnNm() {
        return aplctnNm;
    }
    /**
     * @param aplctnNm the aplctnNm to set
     */
    public void setAplctnNm(String aplctnNm) {
        this.aplctnNm = aplctnNm;
    }
    /**
     * @return the sesionId
     */
    public String getSesionId() {
        return sesionId;
    }
    /**
     * @param sesionId the sesionId to set
     */
    public void setSesionId(String sesionId) {
        this.sesionId = sesionId;
    }
    /**
     * @return the convId
     */
    public String getConvId() {
        return convId;
    }
    /**
     * @param convId the convId to set
     */
    public void setConvId(String convId) {
        this.convId = convId;
    }
    /**
     * @return the dsrPassport
     */
    public String getDsrPassport() {
        return dsrPassport;
    }
    /**
     * @param dsrPassport the dsrPassport to set
     */
    public void setDsrPassport(String dsrPassport) {
        this.dsrPassport = dsrPassport;
    }
    /**
     * @return the fncModuleNm
     */
    public String getFncModuleNm() {
        return fncModuleNm;
    }
    /**
     * @param fncModuleNm the fncModuleNm to set
     */
    public void setFncModuleNm(String fncModuleNm) {
        this.fncModuleNm = fncModuleNm;
    }
    /**
     * @return the lastActvtyDt
     */
    public Date getLastActvtyDt() {
        return lastActvtyDt;
    }
    /**
     * @param lastActvtyDt the lastActvtyDt to set
     */
    public void setLastActvtyDt(Date lastActvtyDt) {
        this.lastActvtyDt = lastActvtyDt;
    }
    /**
     * @return the lastActvtyDate
     */
    public String getLastActvtyDate() {
        return lastActvtyDate;
    }
    /**
     * @param lastActvtyDate the lastActvtyDate to set
     */
    public void setLastActvtyDate(String lastActvtyDate) {
        this.lastActvtyDate = lastActvtyDate;
    }
}
