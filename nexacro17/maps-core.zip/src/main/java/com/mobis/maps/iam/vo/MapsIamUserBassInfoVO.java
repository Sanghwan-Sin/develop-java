package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * 사용자기본정보 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserBassInfoVO.java
 * @Description : 사용자기본정보에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 12.     DT048058     	최초 생성
 * </pre>
 */
public class MapsIamUserBassInfoVO extends MapsIamUserOrgnztVO {
    /* 조회조건 */
    /** 시작일자 */
    private Date strtDt;
    /** 종료일자 */
    private Date endDt;
    /* 사용자기본정보 */
    /** 사용자기본ID */
    private String userBassId;
    /** 사용자명 */
    private String userNm;
    /** 이메일주소 */
    private String email;
    /** 휴대전화번호 */
    private String moblphonNo;
    /** 사무실전화번호 */
    private String offmTelno;
    /** 팩스전화번호 */
    private String faxTelno;
    /** 사용여부 */
    private String useYn;
    /** 삭제여부 */
    private String delYn;
    /* 변경이력 */
    /** 변경구분코드 */
    private String changeSeCd;
    /** 변경자ID */
    private String changeId;
    /** 변경일시 */
    private Date changeDt;
    /**
     * @return the strtDt
     */
    public Date getStrtDt() {
        return strtDt;
    }
    /**
     * @param strtDt the strtDt to set
     */
    public void setStrtDt(Date strtDt) {
        this.strtDt = strtDt;
    }
    /**
     * @return the endDt
     */
    public Date getEndDt() {
        return endDt;
    }
    /**
     * @param endDt the endDt to set
     */
    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }
    /**
     * @return the userBassId
     */
    public String getUserBassId() {
        return userBassId;
    }
    /**
     * @param userBassId the userBassId to set
     */
    public void setUserBassId(String userBassId) {
        this.userBassId = userBassId;
    }
    /**
     * @return the userNm
     */
    public String getUserNm() {
        return userNm;
    }
    /**
     * @param userNm the userNm to set
     */
    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the moblphonNo
     */
    public String getMoblphonNo() {
        return moblphonNo;
    }
    /**
     * @param moblphonNo the moblphonNo to set
     */
    public void setMoblphonNo(String moblphonNo) {
        this.moblphonNo = moblphonNo;
    }
    /**
     * @return the offmTelno
     */
    public String getOffmTelno() {
        return offmTelno;
    }
    /**
     * @param offmTelno the offmTelno to set
     */
    public void setOffmTelno(String offmTelno) {
        this.offmTelno = offmTelno;
    }
    /**
     * @return the faxTelno
     */
    public String getFaxTelno() {
        return faxTelno;
    }
    /**
     * @param faxTelno the faxTelno to set
     */
    public void setFaxTelno(String faxTelno) {
        this.faxTelno = faxTelno;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }
    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    /**
     * @return the changeSeCd
     */
    public String getChangeSeCd() {
        return changeSeCd;
    }
    /**
     * @param changeSeCd the changeSeCd to set
     */
    public void setChangeSeCd(String changeSeCd) {
        this.changeSeCd = changeSeCd;
    }
    /**
     * @return the changeId
     */
    public String getChangeId() {
        return changeId;
    }
    /**
     * @param changeId the changeId to set
     */
    public void setChangeId(String changeId) {
        this.changeId = changeId;
    }
    /**
     * @return the changeDt
     */
    public Date getChangeDt() {
        return changeDt;
    }
    /**
     * @param changeDt the changeDt to set
     */
    public void setChangeDt(Date changeDt) {
        this.changeDt = changeDt;
    }
}
