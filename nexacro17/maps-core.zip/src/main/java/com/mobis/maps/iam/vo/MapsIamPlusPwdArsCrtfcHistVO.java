package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsIamPlusPwdArsCrtfcHist.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2021. 1. 2.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2021. 1. 2.     oh.dongwon     	최초 생성
 * </pre>
 */

public class MapsIamPlusPwdArsCrtfcHistVO {
    
    /** ARS 인증 ID */
    private String crtfcSeqId;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 사용자ID */
    private String userId;
    /** PDA --> ARS호출 결과 코드 */
    private String arsCallResultCd;
    /** ARS 인증 일시 */
    private Date pwdArsCrtfcDt;
    /** ARS --> PDA RESPONSE 코드 */
    private String arsResResultCd;
    /** 생성자ID */
    private String registId;
    /** 생성일시 */
    private Date registDt;
    /** 수정자ID */
    private String updtId;
    /** 수정일시 */
    private Date updtDt;
    /**
     * @return the crtfcSeqId
     */
    public String getCrtfcSeqId() {
        return crtfcSeqId;
    }
    /**
     * @param crtfcSeqId the crtfcSeqId to set
     */
    public void setCrtfcSeqId(String crtfcSeqId) {
        this.crtfcSeqId = crtfcSeqId;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    
    /**
     * @return the arsCallResultCd
     */
    public String getArsCallResultCd() {
        return arsCallResultCd;
    }
    /**
     * @param arsCallResultCd the arsCallResultCd to set
     */
    public void setArsCallResultCd(String arsCallResultCd) {
        this.arsCallResultCd = arsCallResultCd;
    }
    /**
     * @return the pwdArsCrtfcDt
     */
    public Date getPwdArsCrtfcDt() {
        return pwdArsCrtfcDt;
    }
    /**
     * @param pwdArsCrtfcDt the pwdArsCrtfcDt to set
     */
    public void setPwdArsCrtfcDt(Date pwdArsCrtfcDt) {
        this.pwdArsCrtfcDt = pwdArsCrtfcDt;
    }
    
    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }
    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }
    /**
     * @return the registDt
     */
    public Date getRegistDt() {
        return registDt;
    }
    /**
     * @param registDt the registDt to set
     */
    public void setRegistDt(Date registDt) {
        this.registDt = registDt;
    }
    /**
     * @return the updtId
     */
    public String getUpdtId() {
        return updtId;
    }
    /**
     * @param updtId the updtId to set
     */
    public void setUpdtId(String updtId) {
        this.updtId = updtId;
    }
    /**
     * @return the updtDt
     */
    public Date getUpdtDt() {
        return updtDt;
    }
    /**
     * @param updtDt the updtDt to set
     */
    public void setUpdtDt(Date updtDt) {
        this.updtDt = updtDt;
    }
    /**
     * @return the arsResResultCd
     */
    public String getArsResResultCd() {
        return arsResResultCd;
    }
    /**
     * @param arsResResultCd the arsResResultCd to set
     */
    public void setArsResResultCd(String arsResResultCd) {
        this.arsResResultCd = arsResResultCd;
    }
    
    
    
    

}
