package com.mobis.maps.comm.vo;

import java.util.Calendar;
import java.util.Date;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsLoggingEventVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 30.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommDbLoggingEventVO extends PgBascVO {
    
    private String strtDt;
    private long strtTs;
    private String endDt;
    private long endTs;
    
    private int eventId;
    private Date eventDt;
    private long timestmp;
    private String formattedMessage;
    private String loggerName;
    private String levelString;
    private String threadName;
    private int referenceFlag;
    private String arg0;
    private String arg1;
    private String arg2;
    private String arg3;
    private String callerFilename;
    private String callerClass;
    private String callerMethod;
    private String callerLine;

    
    /**
     * @return the strtDt
     */
    public String getStrtDt() {
        return strtDt;
    }
    /**
     * @param strtDt the strtDt to set
     */
    public void setStrtDt(String strtDt) {
        this.strtDt = strtDt;
    }
    /**
     * @return the strtTs
     */
    public long getStrtTs() {
        return strtTs;
    }
    /**
     * @param strtTs the strtTs to set
     */
    public void setStrtTs(long strtTs) {
        this.strtTs = strtTs;
    }
    /**
     * @return the endDt
     */
    public String getEndDt() {
        return endDt;
    }
    /**
     * @param endDt the endDt to set
     */
    public void setEndDt(String endDt) {
        this.endDt = endDt;
    }
    /**
     * @return the endTs
     */
    public long getEndTs() {
        return endTs;
    }
    /**
     * @param endTs the endTs to set
     */
    public void setEndTs(long endTs) {
        this.endTs = endTs;
    }
    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }
    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    /**
     * @return the eventDt
     */
    public Date getEventDt() {
        return eventDt;
    }
    /**
     * @param eventDt the eventDt to set
     */
    public void setEventDt(Date eventDt) {
        this.eventDt = eventDt;
    }
    /**
     * @return the timestmp
     */
    public long getTimestmp() {
        return timestmp;
    }
    /**
     * @param timestmp the timestmp to set
     */
    public void setTimestmp(long timestmp) {
        this.timestmp = timestmp;
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestmp);
        this.eventDt = cal.getTime();
    }
    /**
     * @return the formattedMessage
     */
    public String getFormattedMessage() {
        return formattedMessage;
    }
    /**
     * @param formattedMessage the formattedMessage to set
     */
    public void setFormattedMessage(String formattedMessage) {
        this.formattedMessage = formattedMessage;
    }
    /**
     * @return the loggerName
     */
    public String getLoggerName() {
        return loggerName;
    }
    /**
     * @param loggerName the loggerName to set
     */
    public void setLoggerName(String loggerName) {
        this.loggerName = loggerName;
    }
    /**
     * @return the levelString
     */
    public String getLevelString() {
        return levelString;
    }
    /**
     * @param levelString the levelString to set
     */
    public void setLevelString(String levelString) {
        this.levelString = levelString;
    }
    /**
     * @return the threadName
     */
    public String getThreadName() {
        return threadName;
    }
    /**
     * @param threadName the threadName to set
     */
    public void setThreadName(String threadName) {
        this.threadName = threadName;
    }
    /**
     * @return the referenceFlag
     */
    public int getReferenceFlag() {
        return referenceFlag;
    }
    /**
     * @param referenceFlag the referenceFlag to set
     */
    public void setReferenceFlag(int referenceFlag) {
        this.referenceFlag = referenceFlag;
    }
    /**
     * @return the arg0
     */
    public String getArg0() {
        return arg0;
    }
    /**
     * @param arg0 the arg0 to set
     */
    public void setArg0(String arg0) {
        this.arg0 = arg0;
    }
    /**
     * @return the arg1
     */
    public String getArg1() {
        return arg1;
    }
    /**
     * @param arg1 the arg1 to set
     */
    public void setArg1(String arg1) {
        this.arg1 = arg1;
    }
    /**
     * @return the arg2
     */
    public String getArg2() {
        return arg2;
    }
    /**
     * @param arg2 the arg2 to set
     */
    public void setArg2(String arg2) {
        this.arg2 = arg2;
    }
    /**
     * @return the arg3
     */
    public String getArg3() {
        return arg3;
    }
    /**
     * @param arg3 the arg3 to set
     */
    public void setArg3(String arg3) {
        this.arg3 = arg3;
    }
    /**
     * @return the callerFilename
     */
    public String getCallerFilename() {
        return callerFilename;
    }
    /**
     * @param callerFilename the callerFilename to set
     */
    public void setCallerFilename(String callerFilename) {
        this.callerFilename = callerFilename;
    }
    /**
     * @return the callerClass
     */
    public String getCallerClass() {
        return callerClass;
    }
    /**
     * @param callerClass the callerClass to set
     */
    public void setCallerClass(String callerClass) {
        this.callerClass = callerClass;
    }
    /**
     * @return the callerMethod
     */
    public String getCallerMethod() {
        return callerMethod;
    }
    /**
     * @param callerMethod the callerMethod to set
     */
    public void setCallerMethod(String callerMethod) {
        this.callerMethod = callerMethod;
    }
    /**
     * @return the callerLine
     */
    public String getCallerLine() {
        return callerLine;
    }
    /**
     * @param callerLine the callerLine to set
     */
    public void setCallerLine(String callerLine) {
        this.callerLine = callerLine;
    }
}
