package com.mobis.maps.sapjco.manager;

import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.sap.conn.jco.ext.DestinationDataEventListener;
import com.sap.conn.jco.ext.DestinationDataProvider;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : TestDest.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 7. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 18.     DT045877     	최초 생성
 * </pre>
 */
public class DestinationProvider implements DestinationDataProvider {
    
    private Map<Object, Object> destinationConfigList;
    
    @Override
    public Properties getDestinationProperties(String destinationName) {
        if (destinationConfigList.containsKey(destinationName)) {
            DestinationConfig destinationConfig = (DestinationConfig)destinationConfigList.get(destinationName);
            //System.out.println("→ getDestinationProperties.start[destinationName="+destinationName+"]");
            //System.out.println("→ getDestinationProperties.start[destinationConfig="+destinationConfig.getToString()+"]");
            Properties prop = new Properties();            
            
            prop.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, destinationConfig.getPoolCapacity());
            prop.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, destinationConfig.getPeakLimit());
            if (destinationName.startsWith("pc")) {
                prop.setProperty(DestinationDataProvider.JCO_MSHOST, destinationConfig.getMshost());
                prop.setProperty(DestinationDataProvider.JCO_MSSERV, destinationConfig.getMsserv());
                prop.setProperty(DestinationDataProvider.JCO_GROUP, destinationConfig.getGroup());
            } else {
                // pw 환경 운영 환경이 되어서야 메시지 서버 사용
                if( StringUtils.endsWith(destinationConfig.getR3name(), "P") ){
                    prop.setProperty(DestinationDataProvider.JCO_MSHOST, destinationConfig.getMshost());
                    prop.setProperty(DestinationDataProvider.JCO_MSSERV, destinationConfig.getMsserv());
                    prop.setProperty(DestinationDataProvider.JCO_GROUP, destinationConfig.getGroup());
                }else{
                    prop.setProperty(DestinationDataProvider.JCO_ASHOST, destinationConfig.getAshost());
                    prop.setProperty(DestinationDataProvider.JCO_GWHOST, destinationConfig.getGwhost());
                    prop.setProperty(DestinationDataProvider.JCO_GWSERV, destinationConfig.getGwserv());
                    prop.setProperty(DestinationDataProvider.JCO_SYSNR, destinationConfig.getSysnr());
                }
            }
            prop.setProperty(DestinationDataProvider.JCO_R3NAME, destinationConfig.getR3name());
            prop.setProperty(DestinationDataProvider.JCO_CLIENT, destinationConfig.getClient());
            prop.setProperty(DestinationDataProvider.JCO_USER, destinationConfig.getUser());
            prop.setProperty(DestinationDataProvider.JCO_PASSWD, destinationConfig.getPasswd());
            prop.setProperty(DestinationDataProvider.JCO_LANG, destinationConfig.getLang());           
            return prop;
        }
        
        return null;
    }

    @Override
    public void setDestinationDataEventListener(DestinationDataEventListener eventListener) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public boolean supportsEvents() {
        return false;
    }

    /**
     * @return Destination 정보
     */
    public Map<Object, Object> getDestinationConfigList() {
        return this.destinationConfigList;
    }

    /**
     * @param destinationConfigList Destination 정보
     */
    public void setDestinationConfigList(Map<Object, Object> destinationConfigList) {
        this.destinationConfigList = destinationConfigList;
    }
}