package com.mobis.maps.iam.vo;

import java.util.List;

/**
 * <pre>
 * 계정신청정보 항목
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstVO.java
 * @Description : 계정신청에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamAcntReqstVO {
    /** 계정신청번호 */
    private String acntReqstNo;
    /** 사용자ID */
    private String userId;
    /** Email */
    private String email;
    /** 언어코드 */
    private String langCd;
    /** 계정신청정보 */
    private MapsIamAcntReqstInfoVO iamAcntReqstInfo;
    /** 계정신청언어 */
    private List<MapsIamAcntReqstLangVO> acntReqstLangs;
    /** 계정신청허용IP */
    private List<MapsIamAcntReqstPermIpVO> acntReqstPermIps;
    /** 계정신청허용IP */
    private List<MapsIamAcntReqstAuthorVO> acntReqstAuthors;
    /**
     * @return the acntReqstNo
     */
    public String getAcntReqstNo() {
        return acntReqstNo;
    }
    /**
     * @param acntReqstNo the acntReqstNo to set
     */
    public void setAcntReqstNo(String acntReqstNo) {
        this.acntReqstNo = acntReqstNo;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the langCd
     */
    public String getLangCd() {
        return langCd;
    }
    /**
     * @param langCd the langCd to set
     */
    public void setLangCd(String langCd) {
        this.langCd = langCd;
    }
    /**
     * @return the iamAcntReqstInfo
     */
    public MapsIamAcntReqstInfoVO getIamAcntReqstInfo() {
        return iamAcntReqstInfo;
    }
    /**
     * @param iamAcntReqstInfo the iamAcntReqstInfo to set
     */
    public void setIamAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfo) {
        this.iamAcntReqstInfo = iamAcntReqstInfo;
    }
    /**
     * @return the acntReqstLangs
     */
    public List<MapsIamAcntReqstLangVO> getAcntReqstLangs() {
        return acntReqstLangs;
    }
    /**
     * @param acntReqstLangs the acntReqstLangs to set
     */
    public void setAcntReqstLangs(List<MapsIamAcntReqstLangVO> acntReqstLangs) {
        this.acntReqstLangs = acntReqstLangs;
    }
    /**
     * @return the acntReqstPermIps
     */
    public List<MapsIamAcntReqstPermIpVO> getAcntReqstPermIps() {
        return acntReqstPermIps;
    }
    /**
     * @param acntReqstPermIps the acntReqstPermIps to set
     */
    public void setAcntReqstPermIps(List<MapsIamAcntReqstPermIpVO> acntReqstPermIps) {
        this.acntReqstPermIps = acntReqstPermIps;
    }
    /**
     * @return the acntReqstAuthors
     */
    public List<MapsIamAcntReqstAuthorVO> getAcntReqstAuthors() {
        return acntReqstAuthors;
    }
    /**
     * @param acntReqstAuthors the acntReqstAuthors to set
     */
    public void setAcntReqstAuthors(List<MapsIamAcntReqstAuthorVO> acntReqstAuthors) {
        this.acntReqstAuthors = acntReqstAuthors;
    }
}
