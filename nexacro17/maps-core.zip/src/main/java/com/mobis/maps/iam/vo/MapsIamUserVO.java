package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * 사용자 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserVO.java
 * @Description : 사용자에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 12.     DT048058     	최초 생성
 * </pre>
 */
public class MapsIamUserVO extends MapsIamUserBassInfoVO {
/* 사용자기본정보 항목 */
    /** 사용자기본_조직구분코드 */
    private String userBassOrgnztSeCd;
    /** 사용자기본_영업조직코드 */
    private String userBassBsnOrgnztCd;
    /** 사용자기본_조직코드 */
    private String userBassOrgnztCd;
    /** 사용자기본_조직명 */
    private String userBassOrgnztNm;
    /** 사용자기본_딜러코드 */
    private String userBassDealerCd;
    /** 사용자기본_딜러먕 */
    private String userBassDealerNm;
    /** 사용자기본_사용여부 */
    private String userBassUseYn;
    /** 사용자기본_삭제여부 */
    private String userBassDelYn;
/* 사용자 항목 */
    /** 사용자순번ID */
    private String userSeqId;
    /** 관리자순번ID */
    private String mngrId;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 사용자ID */
    private String userId;
    /** 사용자암호 */
    private String userPwd;
    /** PWD_CHK_YN DB암호화로 패스워드는 서버에서 체크 1: 비번동일 0 : 실패**/
    private String pwdChkYn;
    /** 구사용자ID */
    private String asisUserId;
    /** 계정유형코드 */
    private String acntTyCd;
    /** 계정잠금여부 */
    private String acntLockYn;
    /** 계정잠금사유코드 */
    private String acntLockResnCd;
    /** 타임존코드 */
    private String tzoneCd;
    /** 허용IP사용여부 */
    private String permIpUseYn;
    /** 개인정보수집이용동의여부 */
    private String indvdlinfoColctUseAgreYn;
    /** 개인정보수집이용동의일시 */
    private Date indvdlinfoColctUseAgreDt;
    /** 사용시작일 */
    private Date useBgnde;
    /** 사용종료일 */
    private Date useEndde;
    /** 암호만료일시 */
    private Date pwdEndDt;
    /** 암호오류횟수 */
    private int pwdErrorCo;
    /** 암호초기화여부 */
    private String pwdInitlYn;
    /** 암호변경일시 */
    private Date pwdChangeDt;
    /** 최종로그인일시 */
    private Date lastLoginDt;
    /** 최종로그인IP주소 */
    private String lastLoginIpAdres;
/* 기타정보 */
    /** 계정상태코드 */
    private String acntSttusCd;
    /** 암호오류최대횟수 */
    private int pwdErrorMaxCo;
/* 등록정보 */
    /** 암호변경주기일수 */
    private int pwdChageCyclDayCnt;
/* 암호변경정보 */
    /** 암호변경구분코드 */
    private String pwdChageSeCd;
    /** 현재사용자암호 */
    private String curUserPwd;
    /** 재확인사용자암호 */
    private String reUserPwd;
    /** 시스템명 */
    private String sysSeNm;
    
    
    
    /**
     * @return the sysSeNm
     */
    public String getSysSeNm() {
        return sysSeNm;
    }
    /**
     * @param sysSeNm the sysSeNm to set
     */
    public void setSysSeNm(String sysSeNm) {
        this.sysSeNm = sysSeNm;
    }
    /**
     * @return the userBassOrgnztSeCd
     */
    public String getUserBassOrgnztSeCd() {
        return userBassOrgnztSeCd;
    }
    /**
     * @return the pwdChkYn
     */
    public String getPwdChkYn() {
        return pwdChkYn;
    }
    /**
     * @param pwdChkYn the pwdChkYn to set
     */
    public void setPwdChkYn(String pwdChkYn) {
        this.pwdChkYn = pwdChkYn;
    }
    /**
     * @param userBassOrgnztSeCd the userBassOrgnztSeCd to set
     */
    public void setUserBassOrgnztSeCd(String userBassOrgnztSeCd) {
        this.userBassOrgnztSeCd = userBassOrgnztSeCd;
    }
    /**
     * @return the userBassBsnOrgnztCd
     */
    public String getUserBassBsnOrgnztCd() {
        return userBassBsnOrgnztCd;
    }
    /**
     * @param userBassBsnOrgnztCd the userBassBsnOrgnztCd to set
     */
    public void setUserBassBsnOrgnztCd(String userBassBsnOrgnztCd) {
        this.userBassBsnOrgnztCd = userBassBsnOrgnztCd;
    }
    /**
     * @return the userBassOrgnztCd
     */
    public String getUserBassOrgnztCd() {
        return userBassOrgnztCd;
    }
    /**
     * @param userBassOrgnztCd the userBassOrgnztCd to set
     */
    public void setUserBassOrgnztCd(String userBassOrgnztCd) {
        this.userBassOrgnztCd = userBassOrgnztCd;
    }
    /**
     * @return the userBassOrgnztNm
     */
    public String getUserBassOrgnztNm() {
        return userBassOrgnztNm;
    }
    /**
     * @param userBassOrgnztNm the userBassOrgnztNm to set
     */
    public void setUserBassOrgnztNm(String userBassOrgnztNm) {
        this.userBassOrgnztNm = userBassOrgnztNm;
    }
    /**
     * @return the userBassDealerCd
     */
    public String getUserBassDealerCd() {
        return userBassDealerCd;
    }
    /**
     * @param userBassDealerCd the userBassDealerCd to set
     */
    public void setUserBassDealerCd(String userBassDealerCd) {
        this.userBassDealerCd = userBassDealerCd;
    }
    /**
     * @return the userBassDealerNm
     */
    public String getUserBassDealerNm() {
        return userBassDealerNm;
    }
    /**
     * @param userBassDealerNm the userBassDealerNm to set
     */
    public void setUserBassDealerNm(String userBassDealerNm) {
        this.userBassDealerNm = userBassDealerNm;
    }
    /**
     * @return the userBassUseYn
     */
    public String getUserBassUseYn() {
        return userBassUseYn;
    }
    /**
     * @param userBassUseYn the userBassUseYn to set
     */
    public void setUserBassUseYn(String userBassUseYn) {
        this.userBassUseYn = userBassUseYn;
    }
    /**
     * @return the userBassDelYn
     */
    public String getUserBassDelYn() {
        return userBassDelYn;
    }
    /**
     * @param userBassDelYn the userBassDelYn to set
     */
    public void setUserBassDelYn(String userBassDelYn) {
        this.userBassDelYn = userBassDelYn;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    /**
     * @return the mngrId
     */
    public String getMngrId() {
        return mngrId;
    }
    /**
     * @param mngrId the mngrId to set
     */
    public void setMngrId(String mngrId) {
        this.mngrId = mngrId;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userPwd
     */
    public String getUserPwd() {
        return userPwd;
    }
    /**
     * @param userPwd the userPwd to set
     */
    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }
    /**
     * @return the asisUserId
     */
    public String getAsisUserId() {
        return asisUserId;
    }
    /**
     * @param asisUserId the asisUserId to set
     */
    public void setAsisUserId(String asisUserId) {
        this.asisUserId = asisUserId;
    }
    /**
     * @return the acntTyCd
     */
    public String getAcntTyCd() {
        return acntTyCd;
    }
    /**
     * @param acntTyCd the acntTyCd to set
     */
    public void setAcntTyCd(String acntTyCd) {
        this.acntTyCd = acntTyCd;
    }
    /**
     * @return the acntLockYn
     */
    public String getAcntLockYn() {
        return acntLockYn;
    }
    /**
     * @param acntLockYn the acntLockYn to set
     */
    public void setAcntLockYn(String acntLockYn) {
        this.acntLockYn = acntLockYn;
    }
    /**
     * @return the acntLockResnCd
     */
    public String getAcntLockResnCd() {
        return acntLockResnCd;
    }
    /**
     * @param acntLockResnCd the acntLockResnCd to set
     */
    public void setAcntLockResnCd(String acntLockResnCd) {
        this.acntLockResnCd = acntLockResnCd;
    }
    /**
     * @return the tzoneCd
     */
    public String getTzoneCd() {
        return tzoneCd;
    }
    /**
     * @param tzoneCd the tzoneCd to set
     */
    public void setTzoneCd(String tzoneCd) {
        this.tzoneCd = tzoneCd;
    }
    /**
     * @return the permIpUseYn
     */
    public String getPermIpUseYn() {
        return permIpUseYn;
    }
    /**
     * @param permIpUseYn the permIpUseYn to set
     */
    public void setPermIpUseYn(String permIpUseYn) {
        this.permIpUseYn = permIpUseYn;
    }
    /**
     * @return the indvdlinfoColctUseAgreYn
     */
    public String getIndvdlinfoColctUseAgreYn() {
        return indvdlinfoColctUseAgreYn;
    }
    /**
     * @param indvdlinfoColctUseAgreYn the indvdlinfoColctUseAgreYn to set
     */
    public void setIndvdlinfoColctUseAgreYn(String indvdlinfoColctUseAgreYn) {
        this.indvdlinfoColctUseAgreYn = indvdlinfoColctUseAgreYn;
    }
    /**
     * @return the indvdlinfoColctUseAgreDt
     */
    public Date getIndvdlinfoColctUseAgreDt() {
        return indvdlinfoColctUseAgreDt;
    }
    /**
     * @param indvdlinfoColctUseAgreDt the indvdlinfoColctUseAgreDt to set
     */
    public void setIndvdlinfoColctUseAgreDt(Date indvdlinfoColctUseAgreDt) {
        this.indvdlinfoColctUseAgreDt = indvdlinfoColctUseAgreDt;
    }
    /**
     * @return the useBgnde
     */
    public Date getUseBgnde() {
        return useBgnde;
    }
    /**
     * @param useBgnde the useBgnde to set
     */
    public void setUseBgnde(Date useBgnde) {
        this.useBgnde = useBgnde;
    }
    /**
     * @return the useEndde
     */
    public Date getUseEndde() {
        return useEndde;
    }
    /**
     * @param useEndde the useEndde to set
     */
    public void setUseEndde(Date useEndde) {
        this.useEndde = useEndde;
    }
    /**
     * @return the pwdEndDt
     */
    public Date getPwdEndDt() {
        return pwdEndDt;
    }
    /**
     * @param pwdEndDt the pwdEndDt to set
     */
    public void setPwdEndDt(Date pwdEndDt) {
        this.pwdEndDt = pwdEndDt;
    }
    /**
     * @return the pwdErrorCo
     */
    public int getPwdErrorCo() {
        return pwdErrorCo;
    }
    /**
     * @param pwdErrorCo the pwdErrorCo to set
     */
    public void setPwdErrorCo(int pwdErrorCo) {
        this.pwdErrorCo = pwdErrorCo;
    }
    /**
     * @return the pwdInitlYn
     */
    public String getPwdInitlYn() {
        return pwdInitlYn;
    }
    /**
     * @param pwdInitlYn the pwdInitlYn to set
     */
    public void setPwdInitlYn(String pwdInitlYn) {
        this.pwdInitlYn = pwdInitlYn;
    }
    /**
     * @return the pwdChangeDt
     */
    public Date getPwdChangeDt() {
        return pwdChangeDt;
    }
    /**
     * @param pwdChangeDt the pwdChangeDt to set
     */
    public void setPwdChangeDt(Date pwdChangeDt) {
        this.pwdChangeDt = pwdChangeDt;
    }
    /**
     * @return the lastLoginDt
     */
    public Date getLastLoginDt() {
        return lastLoginDt;
    }
    /**
     * @param lastLoginDt the lastLoginDt to set
     */
    public void setLastLoginDt(Date lastLoginDt) {
        this.lastLoginDt = lastLoginDt;
    }
    /**
     * @return the lastLoginIpAdres
     */
    public String getLastLoginIpAdres() {
        return lastLoginIpAdres;
    }
    /**
     * @param lastLoginIpAdres the lastLoginIpAdres to set
     */
    public void setLastLoginIpAdres(String lastLoginIpAdres) {
        this.lastLoginIpAdres = lastLoginIpAdres;
    }
    /**
     * @return the acntSttusCd
     */
    public String getAcntSttusCd() {
        return acntSttusCd;
    }
    /**
     * @param acntSttusCd the acntSttusCd to set
     */
    public void setAcntSttusCd(String acntSttusCd) {
        this.acntSttusCd = acntSttusCd;
    }
    /**
     * @return the pwdErrorMaxCo
     */
    public int getPwdErrorMaxCo() {
        return pwdErrorMaxCo;
    }
    /**
     * @param pwdErrorMaxCo the pwdErrorMaxCo to set
     */
    public void setPwdErrorMaxCo(int pwdErrorMaxCo) {
        this.pwdErrorMaxCo = pwdErrorMaxCo;
    }
    /**
     * @return the pwdChageCyclDayCnt
     */
    public int getPwdChageCyclDayCnt() {
        return pwdChageCyclDayCnt;
    }
    /**
     * @param pwdChageCyclDayCnt the pwdChageCyclDayCnt to set
     */
    public void setPwdChageCyclDayCnt(int pwdChageCyclDayCnt) {
        this.pwdChageCyclDayCnt = pwdChageCyclDayCnt;
    }
    /**
     * @return the pwdChageSeCd
     */
    public String getPwdChageSeCd() {
        return pwdChageSeCd;
    }
    /**
     * @param pwdChageSeCd the pwdChageSeCd to set
     */
    public void setPwdChageSeCd(String pwdChageSeCd) {
        this.pwdChageSeCd = pwdChageSeCd;
    }
    /**
     * @return the curUserPwd
     */
    public String getCurUserPwd() {
        return curUserPwd;
    }
    /**
     * @param curUserPwd the curUserPwd to set
     */
    public void setCurUserPwd(String curUserPwd) {
        this.curUserPwd = curUserPwd;
    }
    /**
     * @return the reUserPwd
     */
    public String getReUserPwd() {
        return reUserPwd;
    }
    /**
     * @param reUserPwd the reUserPwd to set
     */
    public void setReUserPwd(String reUserPwd) {
        this.reUserPwd = reUserPwd;
    }
}
