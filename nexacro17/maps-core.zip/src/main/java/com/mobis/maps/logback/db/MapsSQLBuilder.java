package com.mobis.maps.logback.db;

import com.mobis.maps.logback.db.names.MapsColumnName;
import com.mobis.maps.logback.db.names.MapsTableName;

import ch.qos.logback.classic.db.names.DBNameResolver;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSQLBuilder.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 7.     DT048058     	최초 생성
 * </pre>
 */

public class MapsSQLBuilder {

    
    static String buildInsertPropertiesSQL(DBNameResolver dbNameResolver) {
        StringBuilder sqlBuilder = new StringBuilder("INSERT INTO COMNDB.");
        sqlBuilder.append(dbNameResolver.getTableName(MapsTableName.T_LOGGING_PROPERTY)).append(" (");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.EVENT_ID)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.MAPPED_KEY)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.MAPPED_VALUE)).append(") ");
        sqlBuilder.append("VALUES (?, ?, ?)");
        return sqlBuilder.toString();
    }

    static String buildInsertExceptionSQL(DBNameResolver dbNameResolver) {
        StringBuilder sqlBuilder = new StringBuilder("INSERT INTO COMNDB.");
        sqlBuilder.append(dbNameResolver.getTableName(MapsTableName.T_LOGGING_EXCEPTION)).append(" (");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.EVENT_ID)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.I)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.TRACE_LINE)).append(") ");
        sqlBuilder.append("VALUES (?, ?, ?)");
        return sqlBuilder.toString();
    }

    static String buildInsertSQL(DBNameResolver dbNameResolver) {
        StringBuilder sqlBuilder = new StringBuilder("INSERT INTO COMNDB.");
        sqlBuilder.append(dbNameResolver.getTableName(MapsTableName.T_LOGGING)).append(" (");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.TIMESTMP)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.FORMATTED_MESSAGE)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.LOGGER_NAME)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.LEVEL_STRING)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.THREAD_NAME)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.REFERENCE_FLAG)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.ARG0)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.ARG1)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.ARG2)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.ARG3)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.CALLER_FILENAME)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.CALLER_CLASS)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.CALLER_METHOD)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsColumnName.CALLER_LINE)).append(") ");
        sqlBuilder.append("VALUES (?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        return sqlBuilder.toString();
    }
}
