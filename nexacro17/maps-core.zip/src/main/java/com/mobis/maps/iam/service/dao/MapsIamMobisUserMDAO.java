package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.iam.vo.MapsIamMobisOrgnztVO;
import com.mobis.maps.iam.vo.MapsIamMobisUserVO;
import com.mobis.maps.iam.vo.MapsIamUserOrgnztVO;

/**
 * <pre>
 * 모비스사용자 데이터처리
 * </pre>
 *
 * @ClassName   : MapsIamMobisUserMDAO.java
 * @Description : 모비스사용자에 대한 데이터처리를 정의.
 * @author DT048058
 * @since 2020. 4. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 17.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsIamMobisUserMDAO")
public interface MapsIamMobisUserMDAO {

    /**
     * 모비스 조직 트리리스트 조회
     *
     * @param iamMobisOrgnztVO
     * @return
     * @throws Exception
     */
    public List<MapsIamMobisOrgnztVO> selectMobisOrgnztTreeList(MapsIamMobisOrgnztVO iamMobisOrgnztVO) throws Exception;

    /**
     * 모비스 사용자 페이징리스트 조회
     *
     * @param iamMobisUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamMobisUserVO> selectMobisUserPgList(MapsIamMobisUserVO iamMobisUserVO) throws Exception;

    /**
     * 모비스 사용자 트리리스트 조회
     *
     * @param iamMobisUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamMobisUserVO> selectMobisUserTreeList(MapsIamMobisUserVO iamMobisUserVO) throws Exception;

    /**
     * 대표하위대리점 리스트 조회
     *
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsOrgnztDistVO> selectOrgnztDistInfoList(LoginInfoVO loginInfoVO) throws Exception;

    /**
     * 대리점 고객그룹 리스트 조회
     *
     * @param loginInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsOrgnztDistVO> selectDistKdGrpList(LoginInfoVO loginInfoVO) throws Exception;

    /**
     * 대리점 조직 정보 조회
     *
     * @param iamUserOrgnztVO
     * @return
     * @throws Exception
     */
    public MapsOrgnztDistVO selectDistOrgnztInfo(MapsIamUserOrgnztVO iamUserOrgnztVO) throws Exception;

    /**
     * 콤보타이틀용어명 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public MapsOrgnztDistVO selectCboSjWordNm(MapsCommCodeVO commCodeVO) throws Exception;
    
}
