package com.mobis.maps.comm.web;

import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.vo.HMap;
import able.com.web.HController;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsLoginException;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommLoginService;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.comm.vo.MapsCommLoginVO;
import com.mobis.maps.comm.vo.MapsCommSapLoginVO;
import com.mobis.maps.comm.vo.MapsOpenSdiScrinInfoVO;
import com.mobis.maps.iam.vo.MapsIamLoginHistVO;

/**
 * <pre>
 * 로그인 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommLoginController.java
 * @Description : 로그인에 대한 컨트롤러를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 28.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommLoginController extends HController {

    @Resource(name = "mapsCommLoginService")
    private MapsCommLoginService mapsCommLoginService;

    /**
     * 로그인 초기화
     *
     * @param commLoginVO
     * @param request
     * @param response
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/selectLoginInit.do")
    public NexacroResult selectLoginInit(@ParamDataSet(name="dsInput") MapsCommLoginVO commLoginVO
            , HttpServletRequest request
            , HttpServletResponse response
            , NexacroResult result) throws Exception {
        // SSO START
        HttpSession session = request.getSession(true);
        String ssoUserId = (String)session.getAttribute("IMOBIS_SESSION_USERID");
        if(logger.isDebugEnabled()){
            logger.debug("ssoUserId : " + ssoUserId);
        }
        // SSO END       
        MapsCommLoginVO loginInitInfo = mapsCommLoginService.selectLoginInit(commLoginVO, request, response);
        
        // SSO START
        loginInitInfo.setSsoFlag("");
        // SSO 인경우 ssoFlag에 값을 넣어서 자동로그인하게 해준다. ==> 보안 주의
        if(StringUtils.isNoneBlank(ssoUserId)){
            loginInitInfo.setSsoFlag("Y");
        }
        // SSO END
        
        result.addDataSet("dsOutput", loginInitInfo);

        MapsCommCodeVO commCodeVO = new MapsCommCodeVO();
        commCodeVO.setCodeRefer1(loginInitInfo.getSysSeCd());
        List<CodeVO> codes = mapsCommLoginService.selectLoginLangList(commCodeVO);
        result.addDataSet("dsOutputLang", codes);
        
        
        
        return result;
    }

    //공통프레임 컴포넌트 메세지키(/src/main/resources/message/message-maps.properties에 정의)
    private static final String[] COMM_COMPN_MSG_KEYS = {
          "leftFrame.icon.menu"
        , "leftFrame.icon.bookmark"
        , "leftFrame.icon.userInfo"
        , "mdiFrame.icon.bookmark"
        , "mdiFrame.icon.manual"
    };
    /**
     * 메세지정보 조회
     *
     * @param locale
     * @return
     * @throws Exception
     */
    private List<HMap> selectMsgInfo(Locale locale) throws Exception {
        return MessageUtil.getAllMessages(locale, COMM_COMPN_MSG_KEYS);
    }
    
    /**
     * 메세지정보 조회
     *
     * @param commLoginVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/selectLoginMsgInfo.do")
    public NexacroResult selectLoginMsgInfo(@ParamDataSet(name="dsInput") MapsCommLoginVO commLoginVO
            , NexacroResult result) throws Exception {
        
        result.addDataSet("dsOutput", selectMsgInfo(MessageUtil.getLocale(commLoginVO.getLangCd())));

        return result;
    }
    
    /**
     * 로그인 초기화(TODO:삭제예정)
     *
     * @param commLoginVO
     * @param request
     * @param response
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/selectLoginInit2.do")
    public NexacroResult selectLoginInit2(@ParamDataSet(name = "dsInput") MapsCommLoginVO commLoginVO
            , HttpServletRequest request
            , HttpServletResponse response
            , NexacroResult result) throws Exception {
        return selectLoginInit(commLoginVO, request, response, result);
    }
    
    /**
     * 로그인
     *
     * @param commLoginVO
     * @param request
     * @param response
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/selectLoginInfo.do")
    public NexacroResult selectLoginInfo(@ParamDataSet(name="dsInput") MapsCommLoginVO commLoginVO
            , HttpServletRequest request
            , HttpServletResponse response
            , NexacroResult result) throws Exception {
        
        // SSO START
        // IMOBIS_SESSION_USERID 세션 값이 존재하면 해당 값으로 로그인 진행
        HttpSession session = request.getSession(true);
        String ssoUserId = (String)session.getAttribute("IMOBIS_SESSION_USERID");
        if(logger.isDebugEnabled()){
            logger.debug("ssoUserId : " + ssoUserId);
        }
        
        // sso 인경우 체크 한다.
        commLoginVO.setSsoFlag("");
        if( StringUtils.isNotBlank(ssoUserId) ){
            commLoginVO.setSsoFlag("Y");
            commLoginVO.setUserId(ssoUserId);
        }
        session.setAttribute("IMOBIS_SESSION_USERID" , "");
        // SSO END
        
        MapsIamLoginHistVO iamLoginHistVO = new MapsIamLoginHistVO();
        
        LoginInfoVO loginInfo = null;
        try {

            loginInfo = mapsCommLoginService.selectLoginInfo(commLoginVO, iamLoginHistVO, request, response);

            if (StringUtils.equals(iamLoginHistVO.getSuccesYn(), MapsConstants.YN_YES)) {

                loginInfo = (LoginInfoVO) BeanUtils.cloneBean(getSessionAttribute(MapsConstants.SSS_LOGIN_INFO));

                result.addDataSet("dsOutput", loginInfo);
                result.addDataSet("dsOutputOrgnzt", getSessionAttribute(MapsConstants.SSS_ORGNZT_INFO));
                result.addDataSet("dsOutputMsgInfo", selectMsgInfo(loginInfo.getUserLcale()));
                result.addDataSet("dsOutputMenuInfo", mapsCommLoginService.selectMenuListByUser(loginInfo));
                result.addDataSet("dsOutputBkmkInfo", mapsCommLoginService.selectUserScrinBkmkList(loginInfo));
                result.addDataSet("dsOutputUserMenu", mapsCommLoginService.selectUserInfoManageMenuList(loginInfo));
                result.addDataSet("dsOutputUserLang", mapsCommLoginService.selectUserLangList(loginInfo));
                result.addDataSet("dsOutputAuthorList", getSessionAttribute(MapsConstants.SSS_AUTHOR_LIST));
            }

        } catch (MapsLoginException e) {

            iamLoginHistVO.setSuccesYn(MapsConstants.YN_NO);
            
            String msgKey = e.getMessageKey();
            if (StringUtils.equals(msgKey, "EC00000052")            // 계정잠김            
                    || StringUtils.equals(msgKey, "QCM0000002")     // 중복로그인인경우
                ) {
                
                loginInfo = (LoginInfoVO) BeanUtils.cloneBean(getSessionAttribute(MapsConstants.SSS_LOCK_LOGIN_INFO));
                
                result.addDataSet("dsOutput", loginInfo);
            } else {
                throw e;
            }
        } catch (Exception e) {
            iamLoginHistVO.setSuccesYn(MapsConstants.YN_NO);
            iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_SYSTEM);
            throw e;
        } finally {
            
            mapsCommLoginService.insertLoginHist(iamLoginHistVO);
            
            if (loginInfo != null) {
                loginInfo.setLastLoginIpAdres(null);
                loginInfo.setLoginIpAdres(null);
            }
        }

        return result;
    }

    /**
     * 로그아웃
     *
     * @param request
     * @param response
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/selectLogout.do")
    public NexacroResult selectLogout(@ParamDataSet(name = "dsInput") MapsCommLoginVO commLoginVO
            , HttpServletRequest request
            , HttpServletResponse response
            , NexacroResult result) throws Exception {

        mapsCommLoginService.selectLogout(request, response);

        return result;
    }

    @RequestMapping(path = "/comm/selectSapLoginInit.do")
    public NexacroResult selectSapLoginInit(HttpServletRequest request
            , HttpServletResponse response
            , NexacroResult result) throws Exception {

        MapsCommSapLoginVO commSapLoginVO = mapsCommLoginService.selectSapLoginInit(request, response);

        result.addDataSet("dsOutput", commSapLoginVO);

        return result;
    }

    /**
     * 로그인 언어 목록 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectLoginLangList.do")
    public NexacroResult selectLoginLangList(@ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (loginInfo != null) {
            commCodeVO.setLangCd(loginInfo.getUserLcale().toString());
        } else {
            commCodeVO.setLangCd(MapsConstants.DFLT_LOCALE.toString());
        }

        List<CodeVO> codes = mapsCommLoginService.selectLoginLangList(commCodeVO);
        result.addDataSet("dsOutput", codes);
        return result;
    }

    /**
     * 화면캡쳐방지용 채널시스템 화면오픈 로그인
     *
     * @param request
     * @param response
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/comm/selectSapLoginInfo.do")
    public NexacroResult selectSapLoginInfo(@ParamDataSet(name="dsInput") MapsCommSapLoginVO commSapLoginVO
            , HttpServletRequest request
            , HttpServletResponse response
            , NexacroResult result) throws Exception {

        MapsOpenSdiScrinInfoVO openSdiScrinInfo = mapsCommLoginService.selectSapLoginInfo(commSapLoginVO, request, response);

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (logger.isDebugEnabled()) {
            logger.debug("selectSapLoginInfo.LoginInfoVO[LangCd" + loginInfo.getLangCd() + "]");
            logger.debug("selectSapLoginInfo request.getSession().getId() : " + request.getSession().getId());
            
        }
        result.addDataSet("dsOutput", loginInfo);
        result.addDataSet("dsOutputOpenSdiScrin", openSdiScrinInfo);
        result.addDataSet("dsOutputMsgInfo", selectMsgInfo(loginInfo.getUserLcale()));

        return result;
    }
}
