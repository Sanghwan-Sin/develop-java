package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.iam.vo.MapsIamLoginHistVO;
import com.mobis.maps.iam.vo.MapsIamPlusPwdArsCrtfcHistVO;
import com.mobis.maps.iam.vo.MapsIamUserAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserIndvdlzMenuVO;
import com.mobis.maps.iam.vo.MapsIamUserIndvdlzScrinFnctVO;
import com.mobis.maps.iam.vo.MapsIamUserLangVO;
import com.mobis.maps.iam.vo.MapsIamUserMenuVO;
import com.mobis.maps.iam.vo.MapsIamUserPermIpVO;
import com.mobis.maps.iam.vo.MapsIamUserPwdChghstVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinConectHistVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinFnctVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;

/**
 * <pre>
 * 사용자관리 데이터처리
 * </pre>
 *
 * @ClassName   : MapsIamUserMDAO.java
 * @Description : 사용자관리에 대한 데이터처리를 정의.
 * @author DT048058
 * @since 2020. 3. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 19.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsIamUserMDAO")
public interface MapsIamUserMDAO {

    /**
     * 사용자 페이징리스트 조회
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectUserPgList(MapsIamUserVO iamUserVO) throws Exception;

    /**
     * 사용자 페이징리스트 팝업 조회
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectPopupUserPgList(MapsIamUserVO iamUserVO) throws Exception;

    /**
     * 사용자 조회
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public MapsIamUserVO selectUser(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자 조회(By 사용자ID)
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public MapsIamUserVO selectUserByUserId(MapsIamUserVO iamUserVO) throws Exception;

    /**
     * 사용자순번ID 조회(By 사용자기본ID)
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public String selectUserSeqIdByUserBassId(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자순번ID 조회(By 조직별 이메일)
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public String selectUserSeqIdByOrgnztEmail(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 동일 BASSID 중복 체크
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public String selectUserDuplCheck(MapsIamUserVO iamUserVO) throws Exception;
    

    /**
     * 사용자 저장
     *
     * @param iamUserVO
     * @throws Exception
     */
    public void insertUser(MapsIamUserVO iamUserVO) throws Exception;

    /**
     * 사용자 수정
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateUser(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자 삭제 수정
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateDeleteUser(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자 삭제
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int deleteUser(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자 개인정보수집및이용동의 수정
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateUserIndvdlinfoColctUseAgre(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자 계정잠김 해제
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateUserUnlock(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자암호 수정
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateUserPwd(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자 암호만료일 연장
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateUserPwdEndDtExtn(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 일반사용자 수정
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateNomalUser(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자 퇴사
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public int updateRetireUser(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자 변경이력 페이징리스트 조회
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectUserChghstPgList(MapsIamUserVO iamUserVO) throws Exception;

    /**
     * 사용자 변경이력 등록
     *
     * @param iamUserVO
     * @throws Exception
     */
    public void insertUserChghst(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자허용IP 리스트 조회
     *
     * @param iamUserPermIpVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserPermIpVO> selectUserPermIpList(MapsIamUserPermIpVO iamUserPermIpVO) throws Exception;
    
    /**
     * 사용자허용IP 조회
     *
     * @param iamUserPermIpVO
     * @return
     * @throws Exception
     */
    public MapsIamUserPermIpVO selectUserPermIp(MapsIamUserPermIpVO iamUserPermIpVO) throws Exception;

    /**
     * 사용자허용IP 등록
     *
     * @param iamUserPermIpVO
     * @throws Exception
     */
    public void insertUserPermIp(MapsIamUserPermIpVO iamUserPermIpVO) throws Exception;
    
    /**
     * 사용자허용IP 수정
     *
     * @param iamUserPermIpVO
     * @return
     * @throws Exception
     */
    public int updateUserPermIp(MapsIamUserPermIpVO iamUserPermIpVO) throws Exception;
    
    /**
     * 사용자허용IP 삭제
     *
     * @param iamUserPermIpVO
     * @return
     * @throws Exception
     */
    public int deleteUserPermIp(MapsIamUserPermIpVO iamUserPermIpVO) throws Exception;
    
    /**
     * 사용자허용IP 전체삭제
     *
     * @param iamUserPermIpVO
     * @return
     * @throws Exception
     */
    public int deleteAllUserPermIp(MapsIamUserPermIpVO iamUserPermIpVO) throws Exception;

    /**
     * 사용자언어 리스트 조회
     *
     * @param iamUserLangVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserLangVO> selectUserLangList(MapsIamUserLangVO iamUserLangVO) throws Exception;
    
    /**
     * 사용자언어 조회
     *
     * @param iamUserPermIpVO
     * @return
     * @throws Exception
     */
    public MapsIamUserLangVO selectUserLang(MapsIamUserLangVO iamUserLangVO) throws Exception;

    /**
     * 사용자언어 등록
     *
     * @param iamUserLangVO
     * @throws Exception
     */
    public void insertUserLang(MapsIamUserLangVO iamUserLangVO) throws Exception;
    
    /**
     * 사용자언어 수정
     *
     * @param iamUserPermIpVO
     * @return
     * @throws Exception
     */
    public int updateUserLang(MapsIamUserLangVO iamUserLangVO) throws Exception;
    
    /**
     * 사용자언어 삭제
     *
     * @param iamUserPermIpVO
     * @return
     * @throws Exception
     */
    public int deleteUserLang(MapsIamUserLangVO iamUserLangVO) throws Exception;
    
    /**
     * 사용자언어 전체삭제
     *
     * @param iamUserLangVO
     * @return
     * @throws Exception
     */
    public int deleteAllUserLang(MapsIamUserLangVO iamUserLangVO) throws Exception;
    
    /**
     * 사용자암호변경이력 페이징리스트 조회
     *
     * @param iamUserPwdChghstVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserPwdChghstVO> selectUserPwdChghstPgList(MapsIamUserPwdChghstVO iamUserPwdChghstVO) throws Exception;

    /**
     * 사용자암호변경이력 등록
     *
     * @param iamUserPwdChghstVO
     * @throws Exception
     */
    public void insertUserPwdChghst(MapsIamUserPwdChghstVO iamUserPwdChghstVO) throws Exception;
    
    /**
     * 사용자권한 리스트 조회
     *
     * @param iamUserAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserAuthorVO> selectUserAuthorList(MapsIamUserAuthorVO iamUserAuthorVO) throws Exception;

    /**
     * 사용자권한 등록
     *
     * @param iamUserAuthorVO
     * @throws Exception
     */
    public void insertUserAuthor(MapsIamUserAuthorVO iamUserAuthorVO) throws Exception;

    /**
     * 사용자권한 수정
     *
     * @param iamUserAuthorVO
     * @throws Exception
     */
    public int updateUserAuthor(MapsIamUserAuthorVO iamUserAuthorVO) throws Exception;

    /**
     * 사용자권한 삭제
     *
     * @param iamUserAuthorVO
     * @throws Exception
     */
    public int deleteUserAuthor(MapsIamUserAuthorVO iamUserAuthorVO) throws Exception;
    
    /**
     * 사용자개별메뉴 리스트 조회
     *
     * @param iamUserIndvdlzMenuVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserIndvdlzMenuVO> selectUserIndvdlzMenuList(MapsIamUserIndvdlzMenuVO iamUserIndvdlzMenuVO) throws Exception;
    
    /**
     * 사용자개별메뉴 등록
     *
     * @param iamUserIndvdlzMenuVO
     * @throws Exception
     */
    public void insertUserIndvdlzMenu(MapsIamUserIndvdlzMenuVO iamUserIndvdlzMenuVO) throws Exception;
    
    /**
     * 사용자개별메뉴 삭제
     *
     * @param iamUserIndvdlzMenuVO
     * @throws Exception
     */
    public int deleteUserIndvdlzMenu(MapsIamUserIndvdlzMenuVO iamUserIndvdlzMenuVO) throws Exception;
    
    /**
     * 사용자개별화면 등록
     *
     * @param iamUserIndvdlzMenuVO
     * @throws Exception
     */
    public void insertUserIndvdlzScrin(MapsIamUserIndvdlzMenuVO iamUserIndvdlzMenuVO) throws Exception;
    
    /**
     * 사용자개별화면 삭제
     *
     * @param iamUserIndvdlzMenuVO
     * @throws Exception
     */
    public int deleteUserIndvdlzScrin(MapsIamUserIndvdlzMenuVO iamUserIndvdlzMenuVO) throws Exception;

    /**
     * 사용자개별 화면기능 리스트 조회
     *
     * @param iamUserIndvdlzScrinFnctVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserIndvdlzScrinFnctVO> selectUserIndvdlzScrinFnctList(MapsIamUserIndvdlzScrinFnctVO iamUserIndvdlzScrinFnctVO) throws Exception;
    
    /**
     * 사용자개별화면기능 등록
     *
     * @param iamUserIndvdlzScrinFnctVO
     * @throws Exception
     */
    public void insertUserIndvdlzScrinFnct(MapsIamUserIndvdlzScrinFnctVO iamUserIndvdlzScrinFnctVO) throws Exception;
    
    /**
     * 사용자개별화면기능 삭제
     *
     * @param iamUserIndvdlzScrinFnctVO
     * @throws Exception
     */
    public int deleteUserIndvdlzScrinFnct(MapsIamUserIndvdlzScrinFnctVO iamUserIndvdlzScrinFnctVO) throws Exception;

    /**
     * 사용자개별화면 일괄 삭제
     *
     * @param iamUserIndvdlzScrinFnctVO
     * @return
     * @throws Exception
     */
    public int deleteAllUserIndvdlzScrinFnct(MapsIamUserIndvdlzScrinFnctVO iamUserIndvdlzScrinFnctVO) throws Exception;

    /**
     * 사용자메뉴 리스트 조회
     *
     * @param iamUserMenuVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserMenuVO> selectUserMenuList(MapsIamUserMenuVO iamUserMenuVO) throws Exception;

    /**
     * 사용자화면기능 리스트 조회
     *
     * @param iamUserScrinFnctVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinFnctVO> selectUserScrinFnctList(MapsIamUserScrinFnctVO iamUserScrinFnctVO) throws Exception;

    /**
     * 로그인이력 페이징리스트 조회
     *
     * @param iamLoginHistVO
     * @return
     * @throws Exception
     */
    public List<MapsIamLoginHistVO> selectLoginHistPgList(MapsIamLoginHistVO iamLoginHistVO) throws Exception;

    /**
     * 사용자화면접속이력 페이징리스트 조회
     *
     * @param imUserScrinConectHistVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinConectHistVO> selectUserScrinConectHistPgList(MapsIamUserScrinConectHistVO imUserScrinConectHistVO) throws Exception;

    /**
     * ID 찾기 사용자리스트 조회
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectFindIdUserList(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 사용자정보 조회(초기화암호용)
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public MapsIamUserVO selectUserInfoByInitPwd(MapsIamUserVO iamUserVO) throws Exception;

    /**
     * 관리자 이메일 리스트 조회
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectMngrEmailList(MapsIamUserVO iamUserVO) throws Exception;
    
    /**
     * 대리점관리자 이메일 리스트 조회
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectDistMngrEmailList(MapsIamUserVO iamUserVO) throws Exception;

    /**
     * 대표대리점 관리자 이메일 리스트 조회
     *
     * @param orgnztDistVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectReqDistMngrEmailList(MapsOrgnztDistVO orgnztDistVO) throws Exception;

    /**
     * IT운영자 메일 리스트 조회
     *
     * @param iamUserVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserVO> selectItOprtrMngrEmailList(MapsIamUserVO iamUserVO) throws Exception;
    
    
    /**
     * ARS 인증 조회
     *
     * @param iamPlusPwdArsCrtfcHistVO
     * @return
     * @throws Exception
     */
    public MapsIamPlusPwdArsCrtfcHistVO selectPlusPwdArsCrtfcHist(MapsIamPlusPwdArsCrtfcHistVO iamPlusPwdArsCrtfcHistVO) throws Exception;
    
    
    /**
     * ARS 인증 등록
     *
     * @param iamPlusPwdArsCrtfcHistVO
     * @throws Exception
     */
    public int insertPlusPwdArsCrtfcHist(MapsIamPlusPwdArsCrtfcHistVO iamPlusPwdArsCrtfcHistVO) throws Exception;
    
    /**
     * ARS 인증 UPDATE
     *
     * @param iamPlusPwdArsCrtfcHistVO
     * @throws Exception
     */
    public int updatePlusPwdArsCrtfcHist(MapsIamPlusPwdArsCrtfcHistVO iamPlusPwdArsCrtfcHistVO) throws Exception;
}
