package com.mobis.maps.iam.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.exception.ExcelBindingException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamWordDicaryService;
import com.mobis.maps.iam.vo.MapsIamWordDicaryVO;

/**
 * <pre>
 * 용어사전 관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommWordDicaryController.java
 * @Description : 용어사전 관리에 대한 컨트롤러 정의.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamWordDicaryController extends HController {

    @Resource(name = "mapsIamWordDicaryService")
    private MapsIamWordDicaryService mapsIamWordDicaryService;
    
    /**
     * 용어사전 조회
     *
     * @param IamMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectWdDicPgList.do")
    public NexacroResult selectWdDicPgList(
            @ParamDataSet(name="dsInput") MapsIamWordDicaryVO iamWdDicVO
            , NexacroResult result) throws Exception {
        
        List<MapsIamWordDicaryVO> wdDicInfos = mapsIamWordDicaryService.selectWdDicPgList(iamWdDicVO);
        
        result.addDataSet("dsOutput", wdDicInfos);
        
        return result;
    }
    
    /**
     * 용어사전 저장
     *
     * @param wdDicInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiWdDicInfo.do")
    public NexacroResult multiWdDicInfo(
            @ParamDataSet(name="dsInput") List<MapsIamWordDicaryVO> wdDicInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamWordDicaryService.multiWdDicInfo(wdDicInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 용어사전 액셀다운로드
     *
     * @param iamWdDicVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectWdDicListExcelDown.do")
    public NexacroResult selectWdDicListExcelDown(            
            @ParamDataSet(name="dsInput") MapsIamWordDicaryVO iamWdDicVO
            , NexacroResult result) throws Exception {

        iamWdDicVO.setExcelDwnlYn(MapsConstants.YN_YES);
        iamWdDicVO.setPgNum(1);
        iamWdDicVO.setPgSize(iamWdDicVO.getTotMaxCnt());

        List<MapsIamWordDicaryVO> wdDicInfos = mapsIamWordDicaryService.selectWdDicPgList(iamWdDicVO);

        result.addDataSet("dsOutput", wdDicInfos);

        return result;
    }
        
    /**
     * 용어사전 엑셀업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectWdDicListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectWdDicListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<MapsIamWordDicaryVO> wdDicInfos = new ArrayList<MapsIamWordDicaryVO>();

        List<String[]> lstCellVal = ExcelUtil.importExcelToList(request, 1, 11, 0, "N");
        
        if (lstCellVal != null && !lstCellVal.isEmpty()) {

            for (String[] arrCellVal : lstCellVal) {

                MapsIamWordDicaryVO iamWdDicVO = new MapsIamWordDicaryVO();               
                
                iamWdDicVO.setWordId(arrCellVal[0]);
                iamWdDicVO.setLangCd(arrCellVal[2]);
                iamWdDicVO.setOrginlWord(arrCellVal[3]);
                iamWdDicVO.setAbbrevWord1(arrCellVal[4]);
                iamWdDicVO.setAbbrevWord2(arrCellVal[5]);
                iamWdDicVO.setAbbrevWord3(arrCellVal[6]);
                iamWdDicVO.setAbbrevWord4(arrCellVal[7]);
                iamWdDicVO.setAbbrevWord5(arrCellVal[8]);
                iamWdDicVO.setWordDc(arrCellVal[9]);
                iamWdDicVO.setUseYn(arrCellVal[10]);
                iamWdDicVO.setRefrnLangCd(MapsConstants.DFLT_LOCALE.toString());
                
                if (StringUtils.isNotBlank(iamWdDicVO.getWordId())) {
                    
                    MapsIamWordDicaryVO refrnWdDicVO = mapsIamWordDicaryService.selectWdDicInfoByRefrnLangCd(iamWdDicVO);
                    if (refrnWdDicVO == null) {
                        throw new ExcelBindingException(messageSource, "EC00000011", new String[]{"Word ID(=" + iamWdDicVO.getWordId() + ")"}, null);
                    }
                    iamWdDicVO.setRefrnOrginlWord(refrnWdDicVO.getOrginlWord());
                    iamWdDicVO.setRefrnAbbrevWord1(refrnWdDicVO.getAbbrevWord1());
                    iamWdDicVO.setRefrnAbbrevWord2(refrnWdDicVO.getAbbrevWord2());
                    iamWdDicVO.setRefrnAbbrevWord3(refrnWdDicVO.getAbbrevWord3());
                    iamWdDicVO.setRefrnAbbrevWord4(refrnWdDicVO.getAbbrevWord4());
                    iamWdDicVO.setRefrnAbbrevWord5(refrnWdDicVO.getAbbrevWord5());
                    iamWdDicVO.setRefrnWordDc(refrnWdDicVO.getWordDc());
                    iamWdDicVO.setRefrnUseYn(refrnWdDicVO.getUseYn());
                }

                wdDicInfos.add(iamWdDicVO);
            }
        }

        result.addDataSet("dsOutput", wdDicInfos);

        return result;
    }
    
    
    /**
     * 용어사전 팝업 조회
     *
     * @param iamWdDicVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectWdDicPgPopList.do")
    public NexacroResult selectWdDicPgPopList(
            @ParamDataSet(name="dsInput") MapsIamWordDicaryVO iamWdDicVO, NexacroResult result) throws Exception {
        
        List<MapsIamWordDicaryVO> wdDicInfos = mapsIamWordDicaryService.selectWdDicPgPopList(iamWdDicVO);
        
        result.addDataSet("dsOutput", wdDicInfos);
        
        return result;
    }
}
