package com.mobis.maps.comm.web;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.secure.WebSecurityUtil;
import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.util.WebUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommService;
import com.mobis.maps.comm.vo.FormGoVO;
import com.mobis.maps.comm.vo.MapsCommOrgnztVO;

/**
 * <pre>
 * 초기화면로드 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommIndexController.java
 * @Description : 초기화면로드 컨트롤러를 정의.
 * @author DT048058
 * @since 2019. 12. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 4.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommController extends HController {

    @Resource(name = "mapsCommService")
    private MapsCommService mapsCommService;

    /**
     * 시스템Datetime
     *
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectServerDatetime.do")
    public NexacroResult selectServerDatetime(NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Locale locale = Locale.getDefault();
        if (loginInfo != null) {
            locale = loginInfo.getUserLcale();
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss", locale);
        Calendar now = Calendar.getInstance(locale);
        //long dte = System.currentTimeMillis();
        
        result.addVariable("svrDt", sdf.format(now.getTime()));
        
        return result;
    }
    
    /**
     * 넥사크로 화면오픈시 세션 및 보안 체크 진행
     *  comm은 세션체크를 하지 않아 comn으로 진행
     *  dispatcher-servlet.xml참조
     *
     * @param model
     * @param request
     * @param response
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectAction.do", method = { RequestMethod.POST, RequestMethod.GET })
    public NexacroResult selectAction(Model model
            , HttpServletRequest request
            , HttpServletResponse response , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        WebUtil.getAuthByParameter(model, request);
        
        String svcUrl = StringUtils.defaultString((String)request.getAttribute("svcUrl"));
        if (StringUtils.isNotBlank(svcUrl)){
            svcUrl = WebSecurityUtil.convertXSSParam(svcUrl);
            request.setAttribute("targetSvcUrl", svcUrl);
        }
        mapsCommService.insertScrinConectInfo(request, loginInfo);
        //String svcFullSvcUrl = "/ui" + svcUrl;
        String svcFullSvcUrl = getPureUrl(request) + "/ui" + svcUrl;
        FormGoVO formGo = new FormGoVO();
        formGo.setOutFormUrl(svcFullSvcUrl);
        if (logger.isDebugEnabled()) {
            logger.debug("→ action.end[svcFullSvcUrl=" + svcFullSvcUrl + "]");
        }
        result.addDataSet("dsFormName" , formGo );
        return result;
    }
    
    /**
     * http://localhost:8080/aa/aa.do ==> http://localhost:8080 추출
     *
     * @param request
     * @return
     */
    private String getPureUrl(HttpServletRequest request){
        String url = request.getRequestURL().toString();
        String uri = request.getRequestURI();
        return StringUtils.remove(url, uri);
    }
    
    
    
    /**
     * 프로퍼티 리로드
     *
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/propReload.do")
    public String propReload(NexacroResult result) throws Exception {

        PropertiesUtil.reLoadDbProperty();

        return "comm/propReload";
    }
    
    /**
     * 웹에디터 호출(Summernote)
     *
     * @param mode
     * @param lang
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/summernote.do")
    public String summernote(
              @RequestParam("mode") String mode
            , @RequestParam("lang") String lang
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        
        if (StringUtils.isBlank(mode) || !mode.matches("V|E")) {
            request.setAttribute("mode", "V");
        } else {
            request.setAttribute("mode", mode);
        }
        if (StringUtils.isBlank(lang)) {
            request.setAttribute("lang", "en-US");
        } else {
            request.setAttribute("lang", lang);
        }
        
        return "comm/summernote";
    }
    
    /**
     * 웹에디터 호출(Naver SmartEditor2)
     *
     * @param mode
     * @param lang
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/smarteditor2.do")
    public String smarteditor2(
            @RequestParam("mode") String mode
          , @RequestParam("lang") String lang
          , HttpServletRequest request
          , HttpServletResponse response) throws Exception {

        if (StringUtils.isBlank(mode) || !mode.matches("V|E")) {
            request.setAttribute("mode", "V");
        } else {
            request.setAttribute("mode", mode);
        }
        if (StringUtils.isBlank(lang)) {
            request.setAttribute("lang", "en_US");
        } else {
            request.setAttribute("lang", lang);
        }

        return "comm/smarteditor2";
    }
    
    /**
     * 웹에디터 호출(Daum)
     *
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/daumpostcode.do") 
    public String daumpostcode(
            HttpServletRequest request
          , HttpServletResponse response) throws Exception {
        return "comm/daumpostcode";
    }

    /**
     * 조직 페이징리스트 조회
     *
     * @param commOrgnztVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/nlogn/selectOrgnztPgList.do")
    public NexacroResult selectOrgnztPgList(
            @ParamDataSet(name="dsInput") MapsCommOrgnztVO commOrgnztVO
            , NexacroResult result) throws Exception {
        
        List<MapsCommOrgnztVO> orgnztInfos = mapsCommService.selectOrgnztPgList(commOrgnztVO);
        
        result.addDataSet("dsOutput", orgnztInfos);
        
        return result;
    }

    /**
     * 조직명 조회
     *
     * @param commOrgnztVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/nlogn/selectOrgnztNm.do")
    public NexacroResult selectOrgnztNm(
              @ParamDataSet(name="dsInput") MapsCommOrgnztVO commOrgnztVO
            , NexacroResult result) throws Exception {
        
        MapsCommOrgnztVO orgnztNm = mapsCommService.selectOrgnztNm(commOrgnztVO);
        
        result.addDataSet("dsOutput", orgnztNm);
        
        return result;
    }
}
