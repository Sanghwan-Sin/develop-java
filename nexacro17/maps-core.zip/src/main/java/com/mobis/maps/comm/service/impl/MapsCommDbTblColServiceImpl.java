package com.mobis.maps.comm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.comm.service.MapsCommDbTblColService;
import com.mobis.maps.comm.service.dao.MapsCommDbTblColMDAO;
import com.mobis.maps.comm.vo.MapsCommDbTblColVO;

/**
 * <pre>
 * 테이블컬럼정보 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommDbTblColServiceImpl.java
 * @Description : 테이블컬럼정보에 대한 서비스를 구현.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Service("mapsCommDbTblColService")
public class MapsCommDbTblColServiceImpl extends HService implements MapsCommDbTblColService {


    @Resource(name = "mapsCommDbTblColMDAO")
    private MapsCommDbTblColMDAO mapsCommDbTblColMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommDbTblColService#selectDbTblColList(com.mobis.maps.comm.vo.MapsCommDbTblColVO)
     */
    @Override
    public List<MapsCommDbTblColVO> selectDbTblColList(MapsCommDbTblColVO commDbTblColVO) throws Exception {
        
        List<MapsCommDbTblColVO> lstDbTblCol = mapsCommDbTblColMDAO.selectDbTblColList(commDbTblColVO);
        
        return lstDbTblCol;
    }

}
