package com.mobis.maps.comm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommMsgService;
import com.mobis.maps.comm.service.dao.MapsCommMsgMDAO;
import com.mobis.maps.comm.vo.MapsCommMsgVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 메세지 관리 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommMsgServiceImpl.java
 * @Description : 메세지 관리 서비스 구현.
 * @author Sin Sanghwan
 * @since 2019. 8. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 26.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Service("mapsCommMsgService")
public class MapsCommMsgServiceImpl extends HService implements MapsCommMsgService {
    
    @Resource(name="mapsCommMsgMDAO")
    private MapsCommMsgMDAO mapsCommMsgMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommMsgService#selectMsgPgList(com.mobis.maps.comm.vo.MapsCommMsgVO)
     */
    @Override
    public List<MapsCommMsgVO> selectMsgPgList(MapsCommMsgVO commMsgVO) throws Exception {
        
        List<MapsCommMsgVO> msgInfos = mapsCommMsgMDAO.selectMsgPgList(commMsgVO);
        
        return msgInfos;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommMsgService#multiMsgInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiMsgInfo(List<MapsCommMsgVO> msgInfos, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        for (MapsCommMsgVO commMsg: msgInfos) {
            
            int rowType = commMsg.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            commMsg.setRegistId(loginInfo.getUserSeqId());
            commMsg.setUpdtId(loginInfo.getUserSeqId());
            
            MapsCommMsgVO resultCommMsg = null;
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    resultCommMsg = mapsCommMsgMDAO.selectMsgInfo(commMsg);
                    if (resultCommMsg != null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Message Info"}, null);
                    }
                    mapsCommMsgMDAO.insertMsgInfo(commMsg);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    mapsCommMsgMDAO.updateMsgInfo(commMsg);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    resultCommMsg = mapsCommMsgMDAO.selectMsgInfo(commMsg);
                    if (resultCommMsg == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Message Info"}, null);
                    }
                    mapsCommMsgMDAO.deleteMsgInfo(commMsg);
                    break;
                default :
                    break;
                    
            }
            procCnt++;
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommMsgService#selectMsgInfoByRefrnLang(com.mobis.maps.comm.vo.MapsCommMsgVO)
     */
    @Override
    public MapsCommMsgVO selectMsgInfoByRefrnLang(MapsCommMsgVO commMsgVO) throws Exception {

        MapsCommMsgVO msgInfo = mapsCommMsgMDAO.selectMsgInfoByRefrnLang(commMsgVO);
        
        return msgInfo;
    }

}
