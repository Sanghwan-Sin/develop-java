package com.mobis.maps.iam.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO;

/**
 * <pre>
 * 계정신청현황 서비스
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstSttusService.java
 * @Description : 계정신청현황에 대한 서비스를 정의.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsIamAcntReqstSttusService {

    /**
     * 계정신청현황 페이징리스트 조회
     *
     * @param iamAcntReqstInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamAcntReqstInfoVO> selectAcntReqstSttusPgList(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, LoginInfoVO loginInfo) throws Exception;
    

    /**
     * 계정신청현황(마스터사용자) 페이징리스트 조회
     *
     * @param iamAcntReqstInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamAcntReqstInfoVO> selectAcntReqstSttusMasterPgList(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, LoginInfoVO loginInfo) throws Exception;
}
