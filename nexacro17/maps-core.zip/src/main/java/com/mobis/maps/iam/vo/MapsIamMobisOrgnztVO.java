package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 모비스조직 항목
 * </pre>
 *
 * @ClassName   : MapsCommMobisOrgnztVO.java
 * @Description : 모비스 조직에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 4. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 14.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamMobisOrgnztVO extends MapsIamCommVO {
    /** 상위조직구분 */
    private String upperOrgztCd;
    /** 조직레벨 */
    private int orgnztLevel;
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 조직코드 */
    private String orgnztCd;
    /** 조직명 */
    private String orgnztNm;
    /** 조직구분 */
    private String orgnztSe;
    /**
     * @return the upperOrgztCd
     */
    public String getUpperOrgztCd() {
        return upperOrgztCd;
    }
    /**
     * @param upperOrgztCd the upperOrgztCd to set
     */
    public void setUpperOrgztCd(String upperOrgztCd) {
        this.upperOrgztCd = upperOrgztCd;
    }
    /**
     * @return the orgnztLevel
     */
    public int getOrgnztLevel() {
        return orgnztLevel;
    }
    /**
     * @param orgnztLevel the orgnztLevel to set
     */
    public void setOrgnztLevel(int orgnztLevel) {
        this.orgnztLevel = orgnztLevel;
    }
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the orgnztCd
     */
    public String getOrgnztCd() {
        return orgnztCd;
    }
    /**
     * @param orgnztCd the orgnztCd to set
     */
    public void setOrgnztCd(String orgnztCd) {
        this.orgnztCd = orgnztCd;
    }
    /**
     * @return the orgnztNm
     */
    public String getOrgnztNm() {
        return orgnztNm;
    }
    /**
     * @param orgnztNm the orgnztNm to set
     */
    public void setOrgnztNm(String orgnztNm) {
        this.orgnztNm = orgnztNm;
    }
    /**
     * @return the orgnztSe
     */
    public String getOrgnztSe() {
        return orgnztSe;
    }
    /**
     * @param orgnztSe the orgnztSe to set
     */
    public void setOrgnztSe(String orgnztSe) {
        this.orgnztSe = orgnztSe;
    }

}
