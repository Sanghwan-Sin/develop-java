package com.mobis.maps.comm.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommOzReportService;
import com.mobis.maps.comm.vo.MapsCommOzReportVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommDbTblColController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommOzReportController extends HController {
    
    @Resource(name = "mapsCommOzReportService")
    private MapsCommOzReportService mapsCommOzReportService;
    
    /**
     * 오즈리포트 폼 조회
     *
     * @param List<MapsCommOzReportVO> mapsCommOzReportList
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectCommMapsOzReport.do")
    public NexacroResult selectCommMapsOzReport(
             @ParamDataSet(name="dsInput") List<MapsCommOzReportVO> mapsCommOzReportList
            , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsCommOzReportVO mapsCommOzReportVO = mapsCommOzReportService.selectCommMapsOzReport(loginInfo, mapsCommOzReportList);
        
        List<MapsCommOzReportVO> mapsCommOzReportListRtn = new ArrayList<MapsCommOzReportVO>();
        mapsCommOzReportListRtn.add(mapsCommOzReportVO);
        result.addDataSet("dsRtn", mapsCommOzReportListRtn);
        return result;
    }
    
    /**
     * 오즈리포트 폼 멀티건 조회
     *
     * @param List<MapsCommOzReportVO> mapsCommOzReportList
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectCommMapsOzReportMulti.do")
    public NexacroResult selectCommMapsOzReportMulti(
             @ParamDataSet(name="dsInput") List<MapsCommOzReportVO> mapsCommOzReportList
            , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsCommOzReportVO mapsCommOzReportVO = mapsCommOzReportService.selectCommMapsOzReportMulti(loginInfo, mapsCommOzReportList);
        
        List<MapsCommOzReportVO> mapsCommOzReportListRtn = new ArrayList<MapsCommOzReportVO>();
        mapsCommOzReportListRtn.add(mapsCommOzReportVO);
        result.addDataSet("dsRtn", mapsCommOzReportListRtn);
        return result;
    }
    /**
     * 오즈 팝업 호출용 웹브라우저 컨트롤
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/comm/selectOzPop.do")
    public String selectOzPop( HttpServletRequest request, HttpServletResponse response) {
        return "comm/ozpopup";
    }
}
