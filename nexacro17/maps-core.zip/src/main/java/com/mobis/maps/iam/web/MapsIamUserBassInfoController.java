package com.mobis.maps.iam.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamUserBassInfoService;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;

/**
 * <pre>
 * 사용자기본정보 컨드롤러
 * </pre>
 *
 * @ClassName   : MapsIamUserBassInfoController.java
 * @Description : 사용자기본정보에 대한 컨드롤러를 정의
 * @author DT048058
 * @since 2020. 3. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 17.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamUserBassInfoController extends HController {
    
    @Resource(name = "mapsIamUserBassInfoService")
    private MapsIamUserBassInfoService mapsIamUserBassInfoService;

    /**
     * 사용자기본정보 페이징리스트 조회
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserBassInfoPgList.do")
    public NexacroResult selectUserBassInfoPgList(
            @ParamDataSet(name="dsInput") MapsIamUserBassInfoVO iamUserBassInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserBassInfoVO> userBassInfos = mapsIamUserBassInfoService.selectUserBassInfoPgList(iamUserBassInfoVO, loginInfo);
                
        result.addDataSet("dsOutput", userBassInfos);        
        
        return result;
    }
    
    /**
     * 사용자기본정보 액셀다운로드
     *
     * @param iamFnctVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserBassInfoListExcelDown.do")
    public NexacroResult selectUserBassInfoListExcelDown(
            @ParamDataSet(name="dsInput") MapsIamUserBassInfoVO iamUserBassInfoVO, NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        iamUserBassInfoVO.setExcelDwnlYn(MapsConstants.YN_YES);
        iamUserBassInfoVO.setPgNum(1);
        iamUserBassInfoVO.setPgSize(iamUserBassInfoVO.getTotMaxCnt());

        List<MapsIamUserBassInfoVO> userBassInfos =mapsIamUserBassInfoService.selectUserBassInfoPgList(iamUserBassInfoVO, loginInfo);

        result.addDataSet("dsOutput", userBassInfos);

        return result;
    }
        
    /**
     * 사용자기본정보 엑셀업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserBassInfoListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectUserBassInfoListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<String[]> lstCellVal = ExcelUtil.importExcelToList(request, 1, 16, 0, "N");

        List<MapsIamUserBassInfoVO> userBassInfos = new ArrayList<MapsIamUserBassInfoVO>();
        
        if (lstCellVal != null && !lstCellVal.isEmpty()) {

            int rnum = 1;
            for (String[] arrCellVal: lstCellVal) {
                
                MapsIamUserBassInfoVO userBassInfoVO = new MapsIamUserBassInfoVO();
                userBassInfoVO.setRnum(rnum);
                userBassInfoVO.setProcTy(arrCellVal[1]);
                if (StringUtils.equals(userBassInfoVO.getProcTy(), MapsConstants.CRUD_CREATE)) {
                    userBassInfoVO.setRowSe(MapsConstants.ROW_SE_CREATE);
                } else if (StringUtils.equals(userBassInfoVO.getProcTy(), MapsConstants.CRUD_UPDATE)) {
                    userBassInfoVO.setRowSe(MapsConstants.ROW_SE_UPDATE);
                } else if (StringUtils.equals(userBassInfoVO.getProcTy(), MapsConstants.CRUD_DELETE)) {
                    userBassInfoVO.setRowSe(MapsConstants.ROW_SE_DELETE);
                }
                userBassInfoVO.setUserBassId(arrCellVal[2]);
                userBassInfoVO.setUserNm(arrCellVal[3]);
                userBassInfoVO.setOrgnztSeCd(arrCellVal[5]);
                userBassInfoVO.setBsnOrgnztCd(arrCellVal[7]);
                userBassInfoVO.setOrgnztCd(arrCellVal[8]);
                userBassInfoVO.setDealerCd(arrCellVal[9]);
                userBassInfoVO.setEmail(arrCellVal[10]);
                userBassInfoVO.setMoblphonNo(arrCellVal[11]);
                userBassInfoVO.setOffmTelno(arrCellVal[12]);
                userBassInfoVO.setFaxTelno(arrCellVal[13]);
                userBassInfoVO.setUseYn(arrCellVal[14]);
                userBassInfoVO.setDelYn(arrCellVal[15]);
                
                userBassInfos.add(userBassInfoVO);
                rnum++;
            }
        }

        result.addDataSet("dsOutput", userBassInfos);

        return result;

    }

    /**
     * 사용자기본정보 조회
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserBassInfo.do")
    public NexacroResult selectUserBassInfo(
            @ParamDataSet(name="dsInput") MapsIamUserBassInfoVO iamUserBassInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        MapsIamUserBassInfoVO userBassInfo = mapsIamUserBassInfoService.selectUserBassInfo(iamUserBassInfoVO, loginInfo);
                
        result.addDataSet("dsOutput", userBassInfo);        
        
        return result;
    }
    
    /**
     * 사용자기본정보 저장
     *
     * @param userBassInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiUserBassInfo.do")
    public NexacroResult multiUserBassInfo(
            @ParamDataSet(name="dsInput") List<MapsIamUserBassInfoVO> userBassInfos
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamUserBassInfoService.multiUserBassInfo(userBassInfos, loginInfo);

        result.addVariable("procCnt", procCnt);  
        
        return result;
    }
    
    /**
     * 사용자기본정보 등록
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/insertUserBassInfo.do")
    public NexacroResult insertUserBassInfo(
            @ParamDataSet(name="dsInput") MapsIamUserBassInfoVO iamUserBassInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamUserBassInfoService.insertUserBassInfo(iamUserBassInfoVO, loginInfo);

        result.addVariable("procCnt", procCnt);  
        
        return result;
    }
    
    /**
     * 사용자기본정보 수정
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateUserBassInfo.do")
    public NexacroResult updateUserBassInfo(
            @ParamDataSet(name="dsInput") MapsIamUserBassInfoVO iamUserBassInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamUserBassInfoService.updateUserBassInfo(iamUserBassInfoVO, loginInfo);

        result.addVariable("procCnt", procCnt);  
        
        return result;
    }
    
    /**
     * 사용자기본정보 삭제
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/deleteUserBassInfo.do")
    public NexacroResult deleteUserBassInfo(
            @ParamDataSet(name="dsInput") MapsIamUserBassInfoVO iamUserBassInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamUserBassInfoService.deleteUserBassInfo(iamUserBassInfoVO, loginInfo);

        result.addVariable("procCnt", procCnt);  
        
        return result;
    }
    
    /**
     * 사용자기본변경이력 페이징조회
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserBassChghstPgList.do")
    public NexacroResult selectUserBassChghstPgList(
            @ParamDataSet(name="dsInput") MapsIamUserBassInfoVO iamUserBassInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserBassInfoVO> userBassChghsts = mapsIamUserBassInfoService.selectUserBassChghstPgList(iamUserBassInfoVO, loginInfo);
                
        result.addDataSet("dsOutput", userBassChghsts);        
        
        return result;
    }
    
    /**
     * 사용자기본정보 페이징리스트 팝업조회
     *
     * @param iamUserBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectPopupUserBassInfoPgList.do")
    public NexacroResult selectPopupUserBassInfoPgList(
            @ParamDataSet(name="dsInput") MapsIamUserBassInfoVO iamUserBassInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserBassInfoVO> userBassInfos = mapsIamUserBassInfoService.selectPopupUserBassInfoPgList(iamUserBassInfoVO, loginInfo);
                
        result.addDataSet("dsOutput", userBassInfos);        
        
        return result;
    }
}
