package com.mobis.maps.comm.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.util.ValidatorUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.RfcLangCd;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommSapRfcService;
import com.mobis.maps.comm.vo.MapsCommSapDestInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcBassInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIpttInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrFieldVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrMstVO;

/**
 * <pre>
 * RFC 정보 관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcController.java
 * @Description : RFC 정보 관리에 대한 컨트롤러를 정의한다.
 * @author Sin Sanghwan
 * @since 2019. 9. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 6.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommSapRfcController extends HController {
    
    @Resource
    private Validator validator;
    
    @Resource(name = "mapsCommSapRfcService")
    private MapsCommSapRfcService mapsCommSapRfcService;

    /**
     * RFC 정보 화면초기화 정보
     *
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectSapRfcInit.do")
    public NexacroResult selectSapRfcInit(NexacroResult result) throws Exception {

        result.addDataSet("dsOutputSysId", RfcSapSys.getCodeList());
        
        return result;
    }
    
    /**
     * RFC META DATA정보 조회
     *
     * @param commSapRfcBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectSapRfcMetaDataInfo.do")
    public NexacroResult selectSapRfcMetaDataInfo(
            @ParamDataSet(name="dsInput") MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        MapsCommSapRfcInfoVO commSapRfcInfoVO = mapsCommSapRfcService.selectSapRfcMetaDataInfo(commSapRfcBassInfoVO, loginInfo);

        result.addDataSet("dsOutputRfcBassInfo", commSapRfcInfoVO.getSapRfcBassInfos());
        result.addDataSet("dsOutputRfcIpttInfo", commSapRfcInfoVO.getSapRfcIpttInfos());
        result.addDataSet("dsOutputRfcStrctrMst", commSapRfcInfoVO.getSapRfcStrctrInfos());
        result.addDataSet("dsOutputRfcStrctrField", commSapRfcInfoVO.getSapRfcStrctrFieldInfos());
        
        return result;
    }

    /**
     * RFC 정보 파일 업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectSapRfcInfoFileUpload.do", method = { RequestMethod.GET, RequestMethod.POST })
    public NexacroResult selectSapRfcInfoFileUpload(@RequestParam("sysId") String sysId
            , HttpServletRequest request, NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapRfcInfoFileUpload.start[sysId=" + sysId + "]");
        }
        MapsCommSapRfcInfoVO commSapRfcInfoVO = mapsCommSapRfcService.selectSapRfcInfoFileUpload(sysId, request, loginInfo);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapRfcInfoFileUpload.getSapRfcBassInfos[size=" + commSapRfcInfoVO.getSapRfcBassInfos().size() + "]");
            logger.debug("→ selectSapRfcInfoFileUpload.getSapRfcIpttInfos[size=" + commSapRfcInfoVO.getSapRfcIpttInfos().size() + "]");
            logger.debug("→ selectSapRfcInfoFileUpload.getSapRfcStrctrInfos[size=" + commSapRfcInfoVO.getSapRfcStrctrInfos().size() + "]");
            logger.debug("→ selectSapRfcInfoFileUpload.getSapRfcStrctrFields[size=" + commSapRfcInfoVO.getSapRfcStrctrFieldInfos().size() + "]");
        }
        result.addDataSet("dsOutputRfcBassInfo", commSapRfcInfoVO.getSapRfcBassInfos());
        result.addDataSet("dsOutputRfcIpttInfo", commSapRfcInfoVO.getSapRfcIpttInfos());
        result.addDataSet("dsOutputRfcStrctrMst", commSapRfcInfoVO.getSapRfcStrctrInfos());
        result.addDataSet("dsOutputRfcStrctrField", commSapRfcInfoVO.getSapRfcStrctrFieldInfos());

        return result;
    }

    /**
     * RFC 기본정보 저장
     *
     * @param sapRfcBassInfoVO
     * @param sapRfcIpttInfos
     * @param sapRfcStrctrInfos
     * @param sapRfcStrctrFieldInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/multiSapRfcInfoFileUpload.do")
    public NexacroResult multiSapRfcInfoFileUpload(
            @ParamDataSet(name="dsInputRfcBassInfo") List<MapsCommSapRfcBassInfoVO> sapRfcBassInfos
            , @ParamDataSet(name="dsInputRfcIpttInfo") List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos
            , @ParamDataSet(name="dsInputRfcStrctrMst") List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos
            , @ParamDataSet(name="dsInputRfcStrctrField") List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos
            , NexacroResult result) throws Exception {
        
        ValidatorUtil.validate(sapRfcBassInfos, validator);
        ValidatorUtil.validate(sapRfcIpttInfos, validator);
        ValidatorUtil.validate(sapRfcStrctrInfos, validator);
        ValidatorUtil.validate(sapRfcStrctrFieldInfos, validator);
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        MapsCommSapRfcInfoVO commSapRfcInfoVO = new MapsCommSapRfcInfoVO();
        commSapRfcInfoVO.setSapRfcBassInfos(sapRfcBassInfos);
        commSapRfcInfoVO.setSapRfcIpttInfos(sapRfcIpttInfos);
        commSapRfcInfoVO.setSapRfcStrctrInfos(sapRfcStrctrInfos);
        commSapRfcInfoVO.setSapRfcStrctrFieldInfos(sapRfcStrctrFieldInfos);
        
        int procCnt = mapsCommSapRfcService.multiSapRfcInfoFileUpload(commSapRfcInfoVO, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * RFC 기본정보 리스트 조회
     *
     * @param commSapRfcBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectSapRfcBassInfoPgList.do")
    public NexacroResult selectSapRfcBassInfoPgList(
            @ParamDataSet(name="dsInput") MapsCommSapRfcInfoVO commSapRfcInfoVO
            , NexacroResult result) throws Exception {

        //LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommSapRfcBassInfoVO> lstRfcBassInfo = mapsCommSapRfcService.selectSapRfcBassInfoPgList(commSapRfcInfoVO);
        
        result.addDataSet("dsOutput", lstRfcBassInfo);
        
        return result;
    }

    /**
     * RFC 정보 조회
     *
     * @param commSapRfcBassInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectSapRfcInfoDetail.do")
    public NexacroResult selectSapRfcInfoDetail(
            @ParamDataSet(name="dsInput") MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO
            , NexacroResult result) throws Exception {
        
        //LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        MapsCommSapRfcInfoVO commSapRfcInfoVO= mapsCommSapRfcService.selectSapRfcInfoDetail(commSapRfcBassInfoVO);

        result.addDataSet("dsOutputRfcIpttInfo", commSapRfcInfoVO.getSapRfcIpttInfos());
        result.addDataSet("dsOutputRfcStrctrMst", commSapRfcInfoVO.getSapRfcStrctrInfos());
        result.addDataSet("dsOutputRfcStrctrField", commSapRfcInfoVO.getSapRfcStrctrFieldInfos());
        
        return result;
    }

    /**
     * RFC 기본정보 저장
     *
     * @param sapRfcBassInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/multiSapRfcBassInfo.do")
    public NexacroResult multiSapRfcBassInfo(
            @ParamDataSet(name="dsInput") List<MapsCommSapRfcBassInfoVO> sapRfcBassInfos
            , NexacroResult result) throws Exception {
        
        ValidatorUtil.validate(sapRfcBassInfos, validator);
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsCommSapRfcService.multiSapRfcBassInfo(sapRfcBassInfos, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * RFC 입출력정보 저장
     *
     * @param sapRfcIpttInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/multiSapRfcIpttInfo.do")
    public NexacroResult multiSapRfcIpttInfo(
            @ParamDataSet(name="dsInput") List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos
            , NexacroResult result) throws Exception {
        
        ValidatorUtil.validate(sapRfcIpttInfos, validator);
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsCommSapRfcService.multiSapRfcIpttInfo(sapRfcIpttInfos, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * RFC 구조체마스터 조회
     *
     * @param commSapRfcStrctrMstVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectSapRfcStrctrMast.do")
    public NexacroResult selectSapRfcStrctrMast(
            @ParamDataSet(name="dsInput") MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO
            , NexacroResult result) throws Exception {
        
        ValidatorUtil.validate(commSapRfcStrctrMstVO, validator);
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
                
        MapsCommSapRfcStrctrMstVO commSapRfcStrctrMst= mapsCommSapRfcService.selectSapRfcStrctrMast(commSapRfcStrctrMstVO, loginInfo);
        
        result.addDataSet("dsOutput", commSapRfcStrctrMst);
        
        return result;
    }
    
    /**
     * RFC 구조체마스터 저장
     *
     * @param sapRfcStrctrInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/multiSapRfcStrctrMast.do")
    public NexacroResult multiSapRfcStrctrMast(
            @ParamDataSet(name="dsInput") List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos
            , NexacroResult result) throws Exception {

        ValidatorUtil.validate(sapRfcStrctrInfos, validator);
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsCommSapRfcService.multiSapRfcStrctrMast(sapRfcStrctrInfos, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * RFC 구조체필드정보 저장
     *
     * @param sapRfcStrctrFieldInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/multiSapRfcStrctrFieldInfo.do")
    public NexacroResult multiSapRfcStrctrFieldInfo(
            @ParamDataSet(name="dsInput") List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos
            , NexacroResult result) throws Exception {
        
        ValidatorUtil.validate(sapRfcStrctrFieldInfos, validator);
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsCommSapRfcService.multiSapRfcStrctrFieldInfo(sapRfcStrctrFieldInfos, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }


    /**
     * Statements
     *
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectSapDestInfoInit.do")
    public NexacroResult selectSapDestInfoInit(NexacroResult result) throws Exception {
        
        //LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        result.addDataSet("dsOutputSapSys", RfcSapSys.getCodeList());
        result.addDataSet("dsOutputSapLangCd", RfcLangCd.getCodeList());
        
        return result;
    }
    /**
     * Statements
     *
     * @param commSapRfcInfoVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectSapDestInfo.do")
    public NexacroResult selectSapDestInfo(
            @ParamDataSet(name="dsInput") MapsCommSapRfcInfoVO commSapRfcInfoVO
            , NexacroResult result) throws Exception {
        
        //LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        MapsCommSapDestInfoVO commSapDestInfoVO = mapsCommSapRfcService.selectSapDestInfo(commSapRfcInfoVO);

        result.addDataSet("dsOutput", commSapDestInfoVO);
        result.addDataSet("dsOutputConect", commSapDestInfoVO.getDestConectInfos());
        
        return result;
    }
}
