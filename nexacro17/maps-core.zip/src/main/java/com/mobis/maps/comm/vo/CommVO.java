package com.mobis.maps.comm.vo;

import java.util.Date;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.util.PropertiesUtil;

/**
 * <pre>
 * MAPS공통 항목
 * </pre>
 *
 * @ClassName   : CommonVO.java
 * @Description : MAPS공통에 대한 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 7. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 16.     Sin Sanghwan       최초 생성
 * </pre>
 */

public class CommVO {

    @SuppressWarnings("unused")
    private static final long serialVersionUID = 1L;
    /** MAPS시스템구분코드(maps.properties에 정의) */
    private String mapsSysSeCd;
    /** 언어코드 */
    private String langCd;
    /** 디폴트언어코드 */
    private String dfltLangCd;
    /** RFC PC시스템ID */
    private String rfcPcSysId;
    /** RFC PC클라이언트 */
    private String rfcPcClient;
    /** RFC PW시스템ID */
    private String rfcPwSysId;
    /** RFC PW클라이언트 */
    private String rfcPwClient;
    /** RFC PS시스템ID */
    private String rfcPsSysId;
    /** RFC PS클라이언트 */
    private String rfcPsClient;
    /** Local Timestemp */
    private Date localDt;
    /** 등록자ID */
    private String registId;
    /** 등록일시 */
    private Date registDt;
    /** 수정자ID */
    private String updtId;
    /** 수정일시 */
    private Date updtDt;
    
    public CommVO() {
        this.langCd = MapsConstants.DFLT_LOCALE.toString();
        this.dfltLangCd = MapsConstants.DFLT_LOCALE.toString();
        this.mapsSysSeCd = PropertiesUtil.getMapsSysSeCd();
    }
    
    /**
     * @return the mapsSysSeCd
     */
    public String getMapsSysSeCd() {
        return mapsSysSeCd;
    }
    /**
     * @param mapsSysSeCd the mapsSysSeCd to set
     */
    public void setMapsSysSeCd(String mapsSysSeCd) {
        this.mapsSysSeCd = mapsSysSeCd;
    }
    /**
     * @return the langCd
     */
    public String getLangCd() {
        return langCd;
    }
    /**
     * @param langCd the langCd to set
     */
    public void setLangCd(String langCd) {
        this.langCd = langCd;
    }
    /**
     * @return the dfltLangCd
     */
    public String getDfltLangCd() {
        return dfltLangCd;
    }
    /**
     * @param dfltLangCd the dfltLangCd to set
     */
    public void setDfltLangCd(String dfltLangCd) {
        this.dfltLangCd = dfltLangCd;
    }
    /**
     * @return the rfcPcSysId
     */
    public String getRfcPcSysId() {
        return rfcPcSysId;
    }
    /**
     * @param rfcPcSysId the rfcPcSysId to set
     */
    public void setRfcPcSysId(String rfcPcSysId) {
        this.rfcPcSysId = rfcPcSysId;
    }
    /**
     * @return the rfcPcClient
     */
    public String getRfcPcClient() {
        return rfcPcClient;
    }
    /**
     * @param rfcPcClient the rfcPcClient to set
     */
    public void setRfcPcClient(String rfcPcClient) {
        this.rfcPcClient = rfcPcClient;
    }
    /**
     * @return the rfcPwSysId
     */
    public String getRfcPwSysId() {
        return rfcPwSysId;
    }
    /**
     * @param rfcPwSysId the rfcPwSysId to set
     */
    public void setRfcPwSysId(String rfcPwSysId) {
        this.rfcPwSysId = rfcPwSysId;
    }
    /**
     * @return the rfcPwClient
     */
    public String getRfcPwClient() {
        return rfcPwClient;
    }
    /**
     * @param rfcPwClient the rfcPwClient to set
     */
    public void setRfcPwClient(String rfcPwClient) {
        this.rfcPwClient = rfcPwClient;
    }
    /**
     * @return the rfcPsSysId
     */
    public String getRfcPsSysId() {
        return rfcPsSysId;
    }
    /**
     * @param rfcPsSysId the rfcPsSysId to set
     */
    public void setRfcPsSysId(String rfcPsSysId) {
        this.rfcPsSysId = rfcPsSysId;
    }
    /**
     * @return the rfcPsClient
     */
    public String getRfcPsClient() {
        return rfcPsClient;
    }
    /**
     * @param rfcPsClient the rfcPsClient to set
     */
    public void setRfcPsClient(String rfcPsClient) {
        this.rfcPsClient = rfcPsClient;
    }
    /**
     * @return the localDt
     */
    public Date getLocalDt() {
        return localDt;
    }
    /**
     * @param localDt the localDt to set
     */
    public void setLocalDt(Date localDt) {
        this.localDt = localDt;
    }
    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }
    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }
    /**
     * @return the registDt
     */
    public Date getRegistDt() {
        return registDt;
    }
    /**
     * @param registDt the registDt to set
     */
    public void setRegistDt(Date registDt) {
        this.registDt = registDt;
    }
    /**
     * @return the updtId
     */
    public String getUpdtId() {
        return updtId;
    }
    /**
     * @param updtId the updtId to set
     */
    public void setUpdtId(String updtId) {
        this.updtId = updtId;
    }
    /**
     * @return the updtDt
     */
    public Date getUpdtDt() {
        return updtDt;
    }
    /**
     * @param updtDt the updtDt to set
     */
    public void setUpdtDt(Date updtDt) {
        this.updtDt = updtDt;
    }
}
