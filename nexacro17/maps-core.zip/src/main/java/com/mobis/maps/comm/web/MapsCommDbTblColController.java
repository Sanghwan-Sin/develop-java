package com.mobis.maps.comm.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.util.ValidatorUtil;
import com.mobis.maps.comm.service.MapsCommDbTblColService;
import com.mobis.maps.comm.vo.MapsCommDbTblColVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommDbTblColController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommDbTblColController extends HController {
    
    @Resource
    private Validator validator;

    @Resource(name = "mapsCommDbTblColService")
    private MapsCommDbTblColService mapsCommDbTblColService;
    
    /**
     * 테이블 컬럼정보 리스트 조회
     *
     * @param commDbTblColVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectCommDbTblColList.do")
    public NexacroResult selectCommDbTblColList(
            @ParamDataSet(name="dsInput") MapsCommDbTblColVO commDbTblColVO
            , NexacroResult result) throws Exception {

        ValidatorUtil.validate(commDbTblColVO, validator);
        
        List<MapsCommDbTblColVO> dbTblCols = mapsCommDbTblColService.selectDbTblColList(commDbTblColVO);
        
        result.addDataSet("dsOutput", dbTblCols);
        
        return result;
    }
}
