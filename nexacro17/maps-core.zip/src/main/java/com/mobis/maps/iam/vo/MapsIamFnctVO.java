package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 기능관리 항목
 * </pre>
 *
 * @ClassName   : MapsCommFnctVO.java
 * @Description : 기능관리 항목을 정의
 * @author DT048657
 * @since 2019. 9. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 6.     DT048657     	최초 생성
 * </pre>
 */
public class MapsIamFnctVO extends MapsIamCommVO {
    /* 기능관리관련항목 */
    /** 기능ID */
    private String fnctId;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 기능구분[U:URL, P:팝업] */
    private String fnctSeCd;
    /** 기능명 */
    private String fnctNm;
    /** 팝업화면ID */
    private String popupScrinId;
    /**팝업화면명 */
    private String popupScrinNm;
    /** 컴포넌트ID */
    private String compnId;
    /** 기능URL */
    private String fnctUrl;
    /** 기능설명 */
    private String fnctDc;
    /** 사용여부 */
    private String useYn;
    /* 화면별기능관련항목 */
    /** 화면기능ID */
    private String scrinFnctId;
    /** 화면ID */
    private String scrinId;
    /** 화면ID */
    private String scrinNm;
    
    /**
     * @return the fnctId
     */
    public String getFnctId() {
        return fnctId;
    }
    /**
     * @param fnctId the fnctId to set
     */
    public void setFnctId(String fnctId) {
        this.fnctId = fnctId;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the fnctSeCd
     */
    public String getFnctSeCd() {
        return fnctSeCd;
    }
    /**
     * @param fnctSeCd the fnctSeCd to set
     */
    public void setFnctSeCd(String fnctSeCd) {
        this.fnctSeCd = fnctSeCd;
    }
    /**
     * @return the fnctNm
     */
    public String getFnctNm() {
        return fnctNm;
    }
    /**
     * @param fnctNm the fnctNm to set
     */
    public void setFnctNm(String fnctNm) {
        this.fnctNm = fnctNm;
    }
    /**
     * @return the popupScrinId
     */
    public String getPopupScrinId() {
        return popupScrinId;
    }
    /**
     * @param popupScrinId the popupScrinId to set
     */
    public void setPopupScrinId(String popupScrinId) {
        this.popupScrinId = popupScrinId;
    }
    /**
     * @return the popupScrinNm
     */
    public String getPopupScrinNm() {
        return popupScrinNm;
    }
    /**
     * @param popupScrinNm the popupScrinNm to set
     */
    public void setPopupScrinNm(String popupScrinNm) {
        this.popupScrinNm = popupScrinNm;
    }
    /**
     * @return the compnId
     */
    public String getCompnId() {
        return compnId;
    }
    /**
     * @param compnId the compnId to set
     */
    public void setCompnId(String compnId) {
        this.compnId = compnId;
    }
    /**
     * @return the fnctUrl
     */
    public String getFnctUrl() {
        return fnctUrl;
    }
    /**
     * @param fnctUrl the fnctUrl to set
     */
    public void setFnctUrl(String fnctUrl) {
        this.fnctUrl = fnctUrl;
    }
    /**
     * @return the fnctDc
     */
    public String getFnctDc() {
        return fnctDc;
    }
    /**
     * @param fnctDc the fnctDc to set
     */
    public void setFnctDc(String fnctDc) {
        this.fnctDc = fnctDc;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * @return the scrinFnctId
     */
    public String getScrinFnctId() {
        return scrinFnctId;
    }
    /**
     * @param scrinFnctId the scrinFnctId to set
     */
    public void setScrinFnctId(String scrinFnctId) {
        this.scrinFnctId = scrinFnctId;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the scrinNm
     */
    public String getScrinNm() {
        return scrinNm;
    }
    /**
     * @param scrinNm the scrinNm to set
     */
    public void setScrinNm(String scrinNm) {
        this.scrinNm = scrinNm;
    }
    
}
