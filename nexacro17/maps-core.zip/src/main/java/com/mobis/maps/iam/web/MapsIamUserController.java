package com.mobis.maps.iam.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamUserService;
import com.mobis.maps.iam.vo.MapsIamLoginHistVO;
import com.mobis.maps.iam.vo.MapsIamUserAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserExcelUpldVO;
import com.mobis.maps.iam.vo.MapsIamUserIndvdlzMenuVO;
import com.mobis.maps.iam.vo.MapsIamUserIndvdlzScrinFnctVO;
import com.mobis.maps.iam.vo.MapsIamUserLangVO;
import com.mobis.maps.iam.vo.MapsIamUserMenuVO;
import com.mobis.maps.iam.vo.MapsIamUserPermIpVO;
import com.mobis.maps.iam.vo.MapsIamUserPwdChghstVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinConectHistVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinFnctVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;

/**
 * <pre>
 * 사용자 관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamUserController.java
 * @Description : 사용자 관리 컨트롤러
 * @author 최은삼
 * @since 2019. 12. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 13.     최은삼     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamUserController extends HController {
    
    @Resource(name = "mapsIamUserService")
    private MapsIamUserService mapsIamUserService;
    
    /**
     * 사용자 페이징리스트 조회
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserPgList.do")
    public NexacroResult selectUserPgList(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserVO> userInfos = mapsIamUserService.selectUserPgList(iamUserVO, loginInfo);
                
        result.addDataSet("dsOutput", userInfos);        
        
        return result;
    }
    
    /**
     * 사용자 리스트 액셀다운로드
     *
     * @param iamFnctVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserListExcelDown.do")
    public NexacroResult selectFnctListExcelDown(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        iamUserVO.setExcelDwnlYn(MapsConstants.YN_YES);
        iamUserVO.setPgNum(1);
        iamUserVO.setPgSize(iamUserVO.getTotMaxCnt());

        List<MapsIamUserVO> userInfos = mapsIamUserService.selectUserPgList(iamUserVO, loginInfo);

        result.addDataSet("dsOutput", userInfos);

        return result;
    }
    
    /**
     * 사용자 저장 
     *
     * @param iamUserInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiUser.do")
    public NexacroResult multiUser(
            @ParamDataSet(name="dsInput") List<MapsIamUserVO> iamUserInfos
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.multiUser(iamUserInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 권한정보 파일업로드 저장
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiUserInfoFiileUpload.do", method = { RequestMethod.GET, RequestMethod.POST })
    public NexacroResult multiUserInfoFiileUpload(HttpServletRequest request, HttpServletResponse response, NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        // 사용자액셀업로드정보
        MapsIamUserExcelUpldVO iamUserExcelUpldVO = new MapsIamUserExcelUpldVO();

        try {
            mapsIamUserService.multiUserInfoFiileUpload(request, response, iamUserExcelUpldVO, loginInfo);
        } catch (MapsBizException e) {
            iamUserExcelUpldVO.addError(e.getMessage());
        }
        result.addVariable("isError", iamUserExcelUpldVO.hasError());
        if (iamUserExcelUpldVO.hasError()) {
            iamUserExcelUpldVO.setErrorCode(-1);
            iamUserExcelUpldVO.setErrorMsg(iamUserExcelUpldVO.toErrorString());
            result.addDataSet("dsOutputExcelUpld", iamUserExcelUpldVO);
        }
        //사용자정보 취득
        result.addDataSet("dsOutputUser", iamUserExcelUpldVO.getUsers());
        //사용자별권한정보 취득
        result.addDataSet("dsOutputUserAuthor", iamUserExcelUpldVO.getUserAuthors());

        return result;
    }

    /**
     * 사용작 계정잠김 해제
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateUserUnlock.do")
    public NexacroResult updateUserUnlock(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.updateUserUnlock(iamUserVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 사용자 암호초기화(사용자)
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateUserResetPwd02.do")
    public NexacroResult updateUserResetPwd02(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.updateUserResetPwd02(iamUserVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 사용자 암호초기화(암호만료)
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateUserResetPwd03.do")
    public NexacroResult updateUserResetPwd03(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.updateUserResetPwd03(iamUserVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 사용자 암호초기화(암호변경횟수초과)
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateUserResetPwd04.do")
    public NexacroResult updateUserResetPwd04(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.updateUserResetPwd04(iamUserVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 사용자 암호초기화(관리자암호초기화)
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateUserResetPwd05.do")
    public NexacroResult updateUserResetPwd05(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.updateUserResetPwd05(iamUserVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * 사용자 암호만료일 연장
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateUserPwdEndDtExtn.do")
    public NexacroResult updateUserPwdEndDtExtn(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.updateUserPwdEndDtExtn(iamUserVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 사용자변경이력 페이징리스트 조회
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserChghstPgList.do")
    public NexacroResult selectUserChghstPgList(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserVO> userInfos = mapsIamUserService.selectUserChghstPgList(iamUserVO, loginInfo);
                
        result.addDataSet("dsOutput", userInfos);        
        
        return result;
    }

    /**
     * 사용자허용IP 리스트 조회
     *
     * @param iamUserPermIpVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserPermIpList.do")
    public NexacroResult selectUserPermIpList(
            @ParamDataSet(name="dsInput") MapsIamUserPermIpVO iamUserPermIpVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserPermIpVO> userPermIps = mapsIamUserService.selectUserPermIpList(iamUserPermIpVO, loginInfo);
                
        result.addDataSet("dsOutput", userPermIps);        
        
        return result;
    }

    /**
     * 사용자허용IP 저장
     *
     * @param userPermIps
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiUserPermIp.do")
    public NexacroResult multiUserPermIp(
            @ParamDataSet(name="dsInput") List<MapsIamUserPermIpVO> userPermIps
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.multiUserPermIp(userPermIps, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 사용자언어 리스트 조회
     *
     * @param iamUserLangVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserLangList.do")
    public NexacroResult selectUserLangList(
            @ParamDataSet(name="dsInput") MapsIamUserLangVO iamUserLangVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserLangVO> userLangs = mapsIamUserService.selectUserLangList(iamUserLangVO, loginInfo);
                
        result.addDataSet("dsOutput", userLangs);        
        
        return result;
    }
    
    /**
     * 사용자언어 저장
     *
     * @param userLangs
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiUserLang.do")
    public NexacroResult multiUserLang(
            @ParamDataSet(name="dsInput") List<MapsIamUserLangVO> userLangs
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.multiUserLang(userLangs, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 사용자암호변경이력 페이징리스트 조회
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserPwdChghstPgList.do")
    public NexacroResult selectUserPwdChghstPgList(
            @ParamDataSet(name="dsInput") MapsIamUserPwdChghstVO iamUserPwdChghstVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserPwdChghstVO> userPwdChghsts = mapsIamUserService.selectUserPwdChghstPgList(iamUserPwdChghstVO, loginInfo);
                
        result.addDataSet("dsOutput", userPwdChghsts);        
        
        return result;
    }

    /**
     * 사용자권한 리스트 조회
     *
     * @param iamUserAuthorVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserAuthorList.do")
    public NexacroResult selectUserAuthorList(
            @ParamDataSet(name="dsInput") MapsIamUserAuthorVO iamUserAuthorVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserAuthorVO> userAuthors = mapsIamUserService.selectUserAuthorList(iamUserAuthorVO, loginInfo);
                
        result.addDataSet("dsOutput", userAuthors);        
        
        return result;
    }
    
    /**
     * 사용자권한 저장
     *
     * @param userAuthors
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiUserAuthor.do")
    public NexacroResult multiUserAuthor(
            @ParamDataSet(name="dsInput") List<MapsIamUserAuthorVO> userAuthors
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.multiUserAuthor(userAuthors, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * 사용자개별메뉴 리스트 조회
     *
     * @param iamUserMenuVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserIndvdlzMenuList.do")
    public NexacroResult selectUserIndvdlzMenuList(
            @ParamDataSet(name="dsInput") MapsIamUserIndvdlzMenuVO iamUserIndvdlzMenuVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserIndvdlzMenuVO> userIndvdlzMenus = mapsIamUserService.selectUserIndvdlzMenuList(iamUserIndvdlzMenuVO, loginInfo);
                
        result.addDataSet("dsOutput", userIndvdlzMenus);        
        
        return result;
    }

    /**
     * 사용자개별 메뉴 저장
     *
     * @param userIndvdlzMenus
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiUserIndvdlzMenu.do")
    public NexacroResult multiUserIndvdlzMenu(
            @ParamDataSet(name="dsInput") List<MapsIamUserIndvdlzMenuVO> userIndvdlzMenus
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.multiUserIndvdlzMenu(userIndvdlzMenus, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    

    /**
     * 사용자개별 화면기능 리스트 조회
     *
     * @param iamUserIndvdlzScrinFnctVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserIndvdlzScrinFnctList.do")
    public NexacroResult selectUserIndvdlzScrinFnctList(
            @ParamDataSet(name="dsInput") MapsIamUserIndvdlzScrinFnctVO iamUserIndvdlzScrinFnctVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserIndvdlzScrinFnctVO> userIndvdlzScrinFncts = mapsIamUserService.selectUserIndvdlzScrinFnctList(iamUserIndvdlzScrinFnctVO, loginInfo);
                
        result.addDataSet("dsOutput", userIndvdlzScrinFncts);        
        
        return result;
    }
    
    /**
     * 사용자개별 화면기능 저장
     *
     * @param userIndvdlzScrinFncts
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiUserIndvdlzScrinFnct.do")
    public NexacroResult multiUserIndvdlzScrinFnct(
            @ParamDataSet(name="dsInput") List<MapsIamUserIndvdlzScrinFnctVO> userIndvdlzScrinFncts
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.multiUserIndvdlzScrinFnct(userIndvdlzScrinFncts, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * 사용자메뉴 리스트 조회
     *
     * @param iamUserMenuVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserMenuList.do")
    public NexacroResult selectUserMenuList(
            @ParamDataSet(name="dsInput") MapsIamUserMenuVO iamUserMenuVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserMenuVO> userAuthors = mapsIamUserService.selectUserMenuList(iamUserMenuVO, loginInfo);
                
        result.addDataSet("dsOutput", userAuthors);        
        
        return result;
    }

    /**
     * 사용자화면기능 리스트 조회
     *
     * @param iamUserScrinFnctVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserScrinFnctList.do")
    public NexacroResult selectUserScrinFnctList(
            @ParamDataSet(name="dsInput") MapsIamUserScrinFnctVO iamUserScrinFnctVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserScrinFnctVO> userAuthors = mapsIamUserService.selectUserScrinFnctList(iamUserScrinFnctVO, loginInfo);
                
        result.addDataSet("dsOutput", userAuthors);        
        
        return result;
    }

    /**
     * 로그인이력 페이징리스트 조회
     *
     * @param iamLoginHistVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectLoginHistPgList.do")
    public NexacroResult selectLoginHistPgList(
            @ParamDataSet(name="dsInput") MapsIamLoginHistVO iamLoginHistVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamLoginHistVO> loginHists = mapsIamUserService.selectLoginHistPgList(iamLoginHistVO, loginInfo);
                
        result.addDataSet("dsOutput", loginHists);        
        
        return result;
    }
    
    /**
     * 사용자화면접속이력 페이징리스트 조회
     *
     * @param imUserScrinConectHistVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserScrinConectHistPgList.do")
    public NexacroResult selectUserScrinConectHistPgList(
            @ParamDataSet(name="dsInput") MapsIamUserScrinConectHistVO imUserScrinConectHistVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserScrinConectHistVO> userScrinConectHists = mapsIamUserService.selectUserScrinConectHistPgList(imUserScrinConectHistVO, loginInfo);
                
        result.addDataSet("dsOutput", userScrinConectHists);        
        
        return result;
    }
    
    /**
     * 사용자 페이징리스트 팝업 조회
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectPopupUserPgList.do")
    public NexacroResult selectPopupUserPgList(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {
        
        List<MapsIamUserVO> userInfos = mapsIamUserService.selectPopupUserPgList(iamUserVO);
                
        result.addDataSet("dsOutput", userInfos);        
        
        return result;
    }

    /**
     * 사용자계정해제
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/updateAcntUnlock.do")
    public NexacroResult updateAcntUnlock(
              @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {

        int procCnt = mapsIamUserService.updateAcntUnlock(iamUserVO);

        result.addVariable("procCnt", procCnt);
        result.addDataSet("dsOutput", iamUserVO);

        return result;
    }
    
    /**
     * 사용자 ID찾기 조회
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/selectFindUserId.do")
    public NexacroResult selectFindUserId(
              @ParamDataSet(name = "dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {
        
        //List<MapsIamUserVO> userInfos = 
        mapsIamUserService.selectFindUserId(iamUserVO);

        //result.addDataSet("dsOutput", userInfos);

        return result;
    }

    /**
     * 사용자비밀번호 찾기 조회
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/nlogn/updateFindUserPwd.do")
    public NexacroResult updateFindUserPwd(
              @ParamDataSet(name = "dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {

        int procCnt = mapsIamUserService.updateFindUserPwd(iamUserVO);

        result.addVariable("procCnt", procCnt);
        result.addDataSet("dsOutput", iamUserVO);

        return result;
    }

    /**
     * 로그인 사용자정보 수정
     *
     * @param iamUserBassInfoVO
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateLoginUserInfo.do")
    public NexacroResult updateLoginUserInfo(
            @ParamDataSet(name="dsInputUserBassInfo") MapsIamUserBassInfoVO iamUserBassInfoVO
          , @ParamDataSet(name="dsInputUserInfo") MapsIamUserVO iamUserVO
          , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.updateLoginUserInfo(iamUserBassInfoVO, iamUserVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 계정 개인정보수집및이용동의
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateAcntIndvdlinfoColctUseAgre.do")
    public NexacroResult updateAcntIndvdlinfoColctUseAgre(
              @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.updateAcntIndvdlinfoColctUseAgre(iamUserVO, loginInfo);

        result.addVariable("procCnt", procCnt);

        return result;
    }

    /**
     * 일반사용자 페이징리스트 조회
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectNormalUserPgList.do")
    public NexacroResult selectNormalUserPgList(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<MapsIamUserVO> userInfos = mapsIamUserService.selectNormalUserPgList(iamUserVO, loginInfo);

        result.addDataSet("dsOutput", userInfos);      
        
        return result;
    }

    /**
     * 일반사용자 저장
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiNormalUser.do")
    public NexacroResult multiNormalUser(
            @ParamDataSet(name="dsInput") List<MapsIamUserVO> iamUsers
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamUserService.multiNormalUser(iamUsers, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 사용자 퇴사
     *
     * @param iamUserVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/updateRetireUser.do")
    public NexacroResult updateRetireUser(
            @ParamDataSet(name="dsInput") MapsIamUserVO iamUserVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamUserService.updateRetireUser(iamUserVO, loginInfo);

        result.addVariable("procCnt", procCnt);
        
        return result;
    }
}
