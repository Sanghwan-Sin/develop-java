package com.mobis.maps.comm.constants;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SapAtchSysId.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 3. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 6.     DT048058     	최초 생성
 * </pre>
 */

public enum SapAtchSysId {

      MGN("M")
    , SRS("S")
    ;
    
    private String sysSeCd;
    private SapAtchSysId(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    
    public static SapAtchSysId get(String sysSeCd) {
        for (SapAtchSysId sapAtchSysId: SapAtchSysId.values()) {
            if (sapAtchSysId.getSysSeCd().equals(sysSeCd)) {
                return sapAtchSysId;
            }
        }
        return null;
    }
    
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
}
