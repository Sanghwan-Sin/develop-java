package com.mobis.maps.comm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.RfcLangCd;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommRfcExecutLogService;
import com.mobis.maps.comm.service.dao.MapsCommRfcExecutLogMDAO;
import com.mobis.maps.comm.vo.MapsCommRfcExecutLogVO;

/**
 * <pre>
 * RFC실행로그 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommRfcExecutLogServiceImpl.java
 * @Description : RFC실행로그에 대한 서비스를 구현.
 * @author DT048058
 * @since 2020. 2. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 7.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsCommRfcExecutLogService")
public class MapsCommRfcExecutLogServiceImpl extends HService implements MapsCommRfcExecutLogService {
    
    @Resource(name="mapsCommRfcExecutLogMDAO")
    private MapsCommRfcExecutLogMDAO mapsCommRfcExecutLogMDAO;
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommRfcExecutLogService#selectRfcExecutLogInit()
     */
    @Override
    public Map<String, Object> selectRfcExecutLogInit() throws Exception {

        Map<String, Object> mInit = new HashMap<String, Object>();
        
        mInit.put("dsOutputSysId", RfcSapSys.getRfcCodeList());
        mInit.put("dsOutputRfcLang", RfcLangCd.getCodeList());
        
        return mInit;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommRfcExecutLogService#selectRfcExecutLogPgList(com.mobis.maps.comm.vo.MapsCommRfcExecutLogVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommRfcExecutLogVO> selectRfcExecutLogPgList(MapsCommRfcExecutLogVO commRfcExecutLogVO,
            LoginInfoVO loginInfo) throws Exception {
        
        List<MapsCommRfcExecutLogVO> lstRfcExecutLog = mapsCommRfcExecutLogMDAO.selectRfcExecutLogPgList(commRfcExecutLogVO);
        
        return lstRfcExecutLog;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommRfcExecutLogService#selectRfcExecutLogDataList(com.mobis.maps.comm.vo.MapsCommRfcExecutLogVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommRfcExecutLogVO> selectRfcExecutLogDataList(MapsCommRfcExecutLogVO commRfcExecutLogVO
            , LoginInfoVO loginInfo) throws Exception {
        
        List<MapsCommRfcExecutLogVO> lstRfcExecutLogData = mapsCommRfcExecutLogMDAO.selectRfcExecutLogDataList(commRfcExecutLogVO);
        
        return lstRfcExecutLogData;
    }

}
