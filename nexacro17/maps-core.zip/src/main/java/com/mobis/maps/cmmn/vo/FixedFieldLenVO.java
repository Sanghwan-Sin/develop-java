package com.mobis.maps.cmmn.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FiexeFieldLenVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 2. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 21.     oh.dongwon     	최초 생성
 * </pre>
 */

public class FixedFieldLenVO {
    private int start;
    private int end;
    private String objName;
    private String fieldType;
    
    /**
     * @return the start
     */
    public int getStart() {
        return start;
    }
    /**
     * @param start the start to set
     */
    public void setStart(int start) {
        this.start = start;
    }
    /**
     * @return the end
     */
    public int getEnd() {
        return end;
    }
    /**
     * @param end the end to set
     */
    public void setEnd(int end) {
        this.end = end;
    }
    /**
     * @return the objName
     */
    public String getObjName() {
        return objName;
    }
    /**
     * @param objName the objName to set
     */
    public void setObjName(String objName) {
        this.objName = objName;
    }
    /**
     * @return the fieldType
     */
    public String getFieldType() {
        return fieldType;
    }
    /**
     * @param fieldType the fieldType to set
     */
    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }
    
}
