package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.SapCodeVO;
import com.mobis.maps.comm.vo.MapsCommCodeGroupVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;

/**
 * <pre>
 * 공통코드 데이터처리
 * </pre>
 *
 * @ClassName   : MapsCommCodeMDAO.java
 * @Description : 공통코드에 대한 데이터처리를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 29.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Mapper("mapsCommCodeMDAO")
public interface MapsCommCodeMDAO {
    
    /**
     * 공통코드 전체리스트 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public List<MapsCommCodeVO> selectCommCodeAllPgList(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * 공통코드그룹 리스트 조회
     *
     * @param commCodeGroupVO
     * @return
     * @throws Exception
     */
    public List<MapsCommCodeGroupVO> selectCommCodeGroupPgList(MapsCommCodeGroupVO commCodeGroupVO) throws Exception;
    
    /**
     * 공통코드그룹 조회
     *
     * @param commCodeGroupVO
     * @return
     * @throws Exception
     */
    public MapsCommCodeGroupVO selectCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO) throws Exception;

    /**
     * 공통코드그룹 등록
     *
     * @param commCodeGroupVO
     * @throws Exception
     */
    public void insertCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO) throws Exception;
    
    /**
     * 공통코드그룹 수정
     *
     * @param commCodeGroupVO
     * @return
     * @throws Exception
     */
    public int updateCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO) throws Exception;
    
    /**
     * 공통코드그룹 삭제(논리)
     *
     * @param commCodeGroupVO
     * @return
     * @throws Exception
     */
    public int updateDelCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO) throws Exception;
    
    /**
     * 공통코드 전체삭제(논리)
     *
     * @param commCodeGroupVO
     * @return
     * @throws Exception
     */
    public int updateDelCommCodeAll(MapsCommCodeGroupVO commCodeGroupVO) throws Exception;
    
    /**
     * 공통코드그룹 삭제
     *
     * @param commCodeGroupVO
     * @return
     * @throws Exception
     */
    public int deleteCommCodeGroup(MapsCommCodeGroupVO commCodeGroupVO) throws Exception;
    
    /**
     * 공통코드 전체삭제
     *
     * @param commCodeGroupVO
     * @return
     * @throws Exception
     */
    public int deleteCommCodeAll(MapsCommCodeGroupVO commCodeGroupVO) throws Exception;
    
    /**
     * 공통코드 리스트 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public List<MapsCommCodeVO> selectCommCodePgList(MapsCommCodeVO commCodeVO) throws Exception;
    
    /**
     * 공통코드 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public MapsCommCodeVO selectCommCode(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * 공통코드 등록
     *
     * @param commCodeVO
     * @throws Exception
     */
    public void insertCommCode(MapsCommCodeVO commCodeVO) throws Exception;
    
    /**
     * 공통코드 수정
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public int updateCommCode(MapsCommCodeVO commCodeVO) throws Exception;
    
    /**
     * 공통코드 삭제
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public int deleteCommCode(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * 코드 리스트 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public List<CodeVO> selectCodeList(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * 하위코드 리스트 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public List<CodeVO> selectLwprtCodeList(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * 코드명 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public CodeVO selectCodeNm(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * 코드용어명 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public String selectCodeWordNm(MapsCommCodeVO commCodeVO) throws Exception;
    
    /**
     * SAP코드 리스트 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public List<SapCodeVO> selectSapCodeList(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * SAP코드명 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public SapCodeVO selectSapCodeNm(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * Domain코드 리스트 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public List<CodeVO> selectDomnCodeList(MapsCommCodeVO commCodeVO) throws Exception;

    /**
     * Domain코드명 조회
     *
     * @param commCodeVO
     * @return
     * @throws Exception
     */
    public CodeVO selectDomnCodeNm(MapsCommCodeVO commCodeVO) throws Exception;
}
