package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommOrgnztVO;

/**
 * <pre>
 * MAPS공통 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsCommMDAO.java
 * @Description : MAPS공통에 대한 데이터 처리를 정의한다.
 * @author DT048058
 * @since 2020. 1. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 30.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsCommMDAO")
public interface MapsCommMDAO {
    
    /**
     * 조직 페이징리스트 조회
     *
     * @param commOrgnztVO
     * @return
     * @throws Exception
     */
    public List<MapsCommOrgnztVO> selectOrgnztPgList(MapsCommOrgnztVO commOrgnztVO) throws Exception;
    
    /**
     * 조직명 조회
     *
     * @param commOrgnztVO
     * @return
     * @throws Exception
     */
    public MapsCommOrgnztVO selectOrgnztNm(MapsCommOrgnztVO commOrgnztVO) throws Exception;
}
