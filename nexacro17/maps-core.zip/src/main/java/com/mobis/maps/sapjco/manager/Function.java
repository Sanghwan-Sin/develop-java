package com.mobis.maps.sapjco.manager;

import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : Function.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 5. 8.     DT045877     	최초 생성
 * </pre>
 */
public class Function {
    
    final JCoDestination destination;
    final JCoFunction function;

    /**
     * @param jCoFunction
     * @see FunctionTemplate
     */
    Function(JCoDestination destination, JCoFunction jCoFunction) {
        this.destination = destination;
        this.function = jCoFunction;
    }

    public String getMessageServerInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append(destination.getMessageServerHost());
        sb.append(":");
        sb.append(destination.getMessageServerService());
        sb.append("|");
        sb.append(destination.getR3Name());
        sb.append("|");
        sb.append(destination.getClient());
        sb.append("|");
        sb.append(destination.getLanguage());
        return sb.toString();
    }
    
    public String getMessageServerHost() {
        StringBuilder sb = new StringBuilder();
//        sb.append("ApplicationServerHost=" + destination.getApplicationServerHost());
//        sb.append(",GatewayHost=" + destination.getGatewayHost());
//        sb.append(",MessageServerHost=" + destination.getMessageServerHost());
//        sb.append(",TPHost=" + destination.getTPHost());
        sb.append(destination.getMessageServerHost());
        sb.append(":");
        sb.append(destination.getMessageServerService());
        return sb.toString();
    }
    
    public String getR3Name() {
        return destination.getR3Name();
    }
    
    public String getClient() {
        return destination.getClient();
    }
    
    public String getLanguage() {
        return destination.getLanguage();
    }
    
    /**
     * Statements
     *
     * @return
     */
    public JCoFunction getJcoFunction(){
        return this.function;
    }
    /**
     * get Function Name
     *
     * @return
     */
    public String getName() {
        return function.getName();
    }

    /**
     * get import parameters
     * @return
     */
    public JCoParameterList getImportParameterList() {
        return function.getImportParameterList();
    }

    /**
     * get table parameters
     * @return
     */
    public JCoParameterList getTableParameterList() {
        return function.getTableParameterList();
    }
    
    /**
     * get structure that will imported
     *
     * @param structureName
     * @return
     */
    public JCoStructure getImportStructure(String structureName) {
        return getImportParameterList().getStructure(structureName);
    }

    /**
     * get table that will imported
     * @param structureName
     * @return
     */
    public JCoTable getImportStructureTable(String structureName) {
        return getImportParameterList().getTable(structureName);
    }

    /**
     * get table that will imported
     * @param tableName
     * @return
     */
    public JCoTable getImportTableParameter(String tableName) {
        return function.getTableParameterList().getTable(tableName);
    }

    /**
     * execute and return SapFunctionResult
     * @return
     * @throws JCoException
     */
    public FunctionResult execute() throws JCoException {
        function.execute(destination);
        return new FunctionResult(function, destination);
    }
}