package com.mobis.maps.logback.db.names;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSapRfcColumnName.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 7.     DT048058     	최초 생성
 * </pre>
 */

public enum MapsSapRfcColumnName {
    
    EVENT_ID, 

    SYS_ID, RFC_ID, RFC_SERVER, RFC_CLIENT, RFC_LANG, SCRIN_ID, USER_ID, LGI_IP_ADRES, THREAD_NM, LOG_LEVEL, LOG_IPTT, LOG_MSG, LOG_DT, 
    
    /* MDC */ 
    RFC_IPTT_SE, RFC_FIELD, RFC_DATA_TY, RFC_DATA, 

    I, TRACE_LINE
    ;
}
