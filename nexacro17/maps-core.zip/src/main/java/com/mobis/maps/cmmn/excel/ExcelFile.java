package com.mobis.maps.cmmn.excel;

import com.mobis.maps.cmmn.constants.ExcelType;

/**
 * <pre>
 * xcel 파일 모델 인터페이스
 * </pre>
 *
 * @ClassName   : ExcelFile.java
 * @Description : xcel 파일 모델 인터페이스
 * @author Sin Sanghwan
 * @since 2019. 8. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 6.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public interface ExcelFile {

    /** 파일이름 */
    public String getName();

    /** 종류 ( XLS, XLSX ) */
    public ExcelType getType();

}