package com.mobis.maps.sapjco.common.function;

import java.util.function.Function;

import com.mobis.maps.cmmn.exception.MapsRuntimeException;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ThrowableFunction.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 5. 8.     DT045877     	최초 생성
 * </pre>
 */
@FunctionalInterface
public interface ThrowableFunction<T, R> {
    /**
     * @see
     * java.util.function.Function
     * 
     * @param t
     * input parameter type T
     * 
     * @return
     * output return
     * 
     * @throws Exception
     */
    R apply(T t) throws Exception;
    
    /**
     * throws Exception lambda to throws RuntimeException lambda
     * @param function
     * @return
     * @since
     * 0.6
     */
    public static <T, R> Function<T, R> runtime(ThrowableFunction<T, R> function) {
        return t -> {
            try {
                return function.apply(t);
            } catch (Exception e) {
                throw new MapsRuntimeException(e);
            }
        };
    }
}