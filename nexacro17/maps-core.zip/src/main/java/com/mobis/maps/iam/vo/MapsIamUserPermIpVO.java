package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 사용자관리 허용IP 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserPermIpVO.java
 * @Description : 사용자관리의 허용IP에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 19.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserPermIpVO extends MapsIamCommVO {
    /** 사용자허용IP관리ID */
    private String userPermIpManageId;
    /** 사용자순번ID */
    private String userSeqId;
    /** 허용IP주소 */
    private String permIpAdres;
    /**
     * @return the userPermIpManageId
     */
    public String getUserPermIpManageId() {
        return userPermIpManageId;
    }
    /**
     * @param userPermIpManageId the userPermIpManageId to set
     */
    public void setUserPermIpManageId(String userPermIpManageId) {
        this.userPermIpManageId = userPermIpManageId;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    /**
     * @return the permIpAdres
     */
    public String getPermIpAdres() {
        return permIpAdres;
    }
    /**
     * @param permIpAdres the permIpAdres to set
     */
    public void setPermIpAdres(String permIpAdres) {
        this.permIpAdres = permIpAdres;
    }
}
