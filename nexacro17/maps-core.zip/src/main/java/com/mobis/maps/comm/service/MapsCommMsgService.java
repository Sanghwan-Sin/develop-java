package com.mobis.maps.comm.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommMsgVO;

/**
 * <pre>
 * 메세지 관리 서비스
 * </pre>
 *
 * @ClassName   : MapsCommMsgService.java
 * @Description : 메세지 관리 서비스를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 26.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsCommMsgService {
    
    /**
     * 메세지 리스트 조회
     *
     * @param commMsgSearchVO
     * @return
     * @throws Exception
     */
    public List<MapsCommMsgVO> selectMsgPgList(MapsCommMsgVO commMsgVO) throws Exception;

    /**
     * 메세지 등록
     *
     * @param msgInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiMsgInfo(List<MapsCommMsgVO> msgInfos, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 참조언어에 대한 메세지 조회
     *
     * @param commMsgVO
     * @return
     * @throws Exception
     */
    public MapsCommMsgVO selectMsgInfoByRefrnLang(MapsCommMsgVO commMsgVO) throws Exception;
}
