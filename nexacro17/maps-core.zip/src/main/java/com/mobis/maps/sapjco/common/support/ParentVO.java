package com.mobis.maps.sapjco.common.support;

import java.lang.reflect.Method;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ParentVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author      : DT045877
 * @since       : 2019. 5. 15.
 * @version     : 1.0
 * @see
 * @Modification Information
 * <pre>
 * since            author        description
 * =============    ==========    ===========================
 * 2019.5.15.       DT045877      최초 생성
 * </pre>
 */

public class ParentVO {
    /**
     * VO의 전체 field값을 반환한다
     * 
     * @return
     */
    public String printAllData() {        
        Method[] methods;
        StringBuffer dataValue = new StringBuffer();

        try {
            methods = this.getClass().getDeclaredMethods();
            for (Method method: methods) {
                if (method.getName().startsWith("set")) {
                    continue;
                }
                dataValue.append(method.getName().substring(3).toUpperCase());
                dataValue.append("=");
                dataValue.append(method.invoke(this));    
                dataValue.append(", ");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return (dataValue.toString().length() == 0 ? null : dataValue.toString().substring(0, dataValue.length() - 2));
    }
    
    /**
     * VO의 전체 field중 특정 field의 값을 반환한다
     * 
     * @param field
     * @return
     */
    public String printData(String field) {
        Method method;
        String dataValue = null;
        
        try {
            method = this.getClass().getMethod("get" + field.substring(0, 1).toUpperCase() + field.substring(1));
            dataValue = (String)method.invoke(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return dataValue;
    }
}