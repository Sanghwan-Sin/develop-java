package com.mobis.maps.comm.vo;

/**
 * <pre>
 * MAPS인증(화면, URL) 항목
 * </pre>
 *
 * @ClassName   : MapsCommAuthenticVO.java
 * @Description : MAPS인증(화면, URL)에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 7. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 21.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommAuthenticVO extends CommVO {
    
    /** 메뉴ID */
    private String menuId;
    /** 화면ID */
    private String scrinId;
    /** 화면ID */
    private String scrinNm;
    /** 화면URL */
    private String scrinUrl;
    /** 팝업여부 */
    private String popupYn;
    /** 서비스URL */
    private String svcUrl;
    /** 오픈타입 */
    private String openTy;
    /** 사용자순번ID */
    private String userSeqId;
    
    /**
     * @return the menuId
     */
    public String getMenuId() {
        return menuId;
    }
    /**
     * @param menuId the menuId to set
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the scrinNm
     */
    public String getScrinNm() {
        return scrinNm;
    }
    /**
     * @param scrinNm the scrinNm to set
     */
    public void setScrinNm(String scrinNm) {
        this.scrinNm = scrinNm;
    }
    /**
     * @return the scrinUrl
     */
    public String getScrinUrl() {
        return scrinUrl;
    }
    /**
     * @param scrinUrl the scrinUrl to set
     */
    public void setScrinUrl(String scrinUrl) {
        this.scrinUrl = scrinUrl;
    }
    /**
     * @return the popupYn
     */
    public String getPopupYn() {
        return popupYn;
    }
    /**
     * @param popupYn the popupYn to set
     */
    public void setPopupYn(String popupYn) {
        this.popupYn = popupYn;
    }
    /**
     * @return the svcUrl
     */
    public String getSvcUrl() {
        return svcUrl;
    }
    /**
     * @param svcUrl the svcUrl to set
     */
    public void setSvcUrl(String svcUrl) {
        this.svcUrl = svcUrl;
    }
    /**
     * @return the openTy
     */
    public String getOpenTy() {
        return openTy;
    }
    /**
     * @param openTy the openTy to set
     */
    public void setOpenTy(String openTy) {
        this.openTy = openTy;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    
}
