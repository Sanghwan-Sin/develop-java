package com.mobis.maps.cmmn.vo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceFileInfoTestVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author hong.minho
 * @since 2020. 7. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 29.     hong.minho     	최초 생성
 * </pre>
 */
public class InvoiceFileInfoTestVO {
    
    private String eHead;
    private String eTail;
   
    private Date invDate;
    private String zfptld;
    private String zfpldv;
    private String zshptp;
    private String zfcarnm;
    private String zfvyno;
    private String zfhblno;
    private Date zfobdt;
    private BigDecimal noOfBox;
    private BigDecimal noOfLine;
    private BigDecimal freCost;
    private BigDecimal zfobpr;
    private String contNum;
    private String outBoxNum;
    private String inBoxNum;
    private String zordnoE;
    private String zordln;
    private String zordls;
    private String zmatnrInput;
    private String confMatnr;
    private String splyMatnr;
    private BigDecimal netpr;
    private BigDecimal zcfmqty;
    private BigDecimal shipQty;
    private BigDecimal zboqty;
    private BigDecimal zcancqty;
    private BigDecimal shipValue;
    private BigDecimal totShipQty;
    private String zamdcf;
    private String land1;
    private BigDecimal zweig;
    private BigDecimal outBoxGrwei;
    private BigDecimal outBoxNtgew;
    private BigDecimal outBoxLeng;
    private BigDecimal outBoxWid;
    private BigDecimal outBoxHei;
    private BigDecimal inBoxGrwei;
    private BigDecimal inBoxNtgew;
    private BigDecimal inBoxLeng;
    private BigDecimal inBoxWid;
    private BigDecimal inBoxHei;
    private String ccngn;
    private BigDecimal zfcifamt;
    private String invoice;
    private String intTrade;
    
    
    /**
     * @return the eHead
     */
    public String geteHead() {
        return eHead;
    }

    /**
     * @param eHead the eHead to set
     */
    public void seteHead(String eHead) {
        this.eHead = eHead;
    }

    /**
     * @return the eTail
     */
    public String geteTail() {
        return eTail;
    }

    /**
     * @param eTail the eTail to set
     */
    public void seteTail(String eTail) {
        this.eTail = eTail;
    }

    /**
     * @return the invDate
     */
    public Date getInvDate() {
        return invDate;
    }

    /**
     * @param invDate the invDate to set
     */
    public void setInvDate(Date invDate) {
        this.invDate = invDate;
    }

    /**
     * @return the zfptld
     */
    public String getZfptld() {
        return zfptld;
    }

    /**
     * @param zfptld the zfptld to set
     */
    public void setZfptld(String zfptld) {
        this.zfptld = zfptld;
    }

    /**
     * @return the zfpldv
     */
    public String getZfpldv() {
        return zfpldv;
    }

    /**
     * @param zfpldv the zfpldv to set
     */
    public void setZfpldv(String zfpldv) {
        this.zfpldv = zfpldv;
    }

    /**
     * @return the zshptp
     */
    public String getZshptp() {
        return zshptp;
    }

    /**
     * @param zshptp the zshptp to set
     */
    public void setZshptp(String zshptp) {
        this.zshptp = zshptp;
    }

    /**
     * @return the zfcarnm
     */
    public String getZfcarnm() {
        return zfcarnm;
    }

    /**
     * @param zfcarnm the zfcarnm to set
     */
    public void setZfcarnm(String zfcarnm) {
        this.zfcarnm = zfcarnm;
    }

    /**
     * @return the zfvyno
     */
    public String getZfvyno() {
        return zfvyno;
    }

    /**
     * @param zfvyno the zfvyno to set
     */
    public void setZfvyno(String zfvyno) {
        this.zfvyno = zfvyno;
    }

    /**
     * @return the zfhblno
     */
    public String getZfhblno() {
        return zfhblno;
    }

    /**
     * @param zfhblno the zfhblno to set
     */
    public void setZfhblno(String zfhblno) {
        this.zfhblno = zfhblno;
    }

    /**
     * @return the zfobdt
     */
    public Date getZfobdt() {
        return zfobdt;
    }

    /**
     * @param zfobdt the zfobdt to set
     */
    public void setZfobdt(Date zfobdt) {
        this.zfobdt = zfobdt;
    }

    /**
     * @return the noOfBox
     */
    public BigDecimal getNoOfBox() {
        return noOfBox;
    }

    /**
     * @param noOfBox the noOfBox to set
     */
    public void setNoOfBox(BigDecimal noOfBox) {
        this.noOfBox = noOfBox;
    }

    /**
     * @return the noOfLine
     */
    public BigDecimal getNoOfLine() {
        return noOfLine;
    }

    /**
     * @param noOfLine the noOfLine to set
     */
    public void setNoOfLine(BigDecimal noOfLine) {
        this.noOfLine = noOfLine;
    }

    /**
     * @return the freCost
     */
    public BigDecimal getFreCost() {
        return freCost;
    }

    /**
     * @param freCost the freCost to set
     */
    public void setFreCost(BigDecimal freCost) {
        this.freCost = freCost;
    }

    /**
     * @return the zfobpr
     */
    public BigDecimal getZfobpr() {
        return zfobpr;
    }

    /**
     * @param zfobpr the zfobpr to set
     */
    public void setZfobpr(BigDecimal zfobpr) {
        this.zfobpr = zfobpr;
    }

    /**
     * @return the contNum
     */
    public String getContNum() {
        return contNum;
    }

    /**
     * @param contNum the contNum to set
     */
    public void setContNum(String contNum) {
        this.contNum = contNum;
    }

    /**
     * @return the outBoxNum
     */
    public String getOutBoxNum() {
        return outBoxNum;
    }

    /**
     * @param outBoxNum the outBoxNum to set
     */
    public void setOutBoxNum(String outBoxNum) {
        this.outBoxNum = outBoxNum;
    }

    /**
     * @return the inBoxNum
     */
    public String getInBoxNum() {
        return inBoxNum;
    }

    /**
     * @param inBoxNum the inBoxNum to set
     */
    public void setInBoxNum(String inBoxNum) {
        this.inBoxNum = inBoxNum;
    }

    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }

    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }

    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }

    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }

    /**
     * @return the zordls
     */
    public String getZordls() {
        return zordls;
    }

    /**
     * @param zordls the zordls to set
     */
    public void setZordls(String zordls) {
        this.zordls = zordls;
    }

    /**
     * @return the zmatnrInput
     */
    public String getZmatnrInput() {
        return zmatnrInput;
    }

    /**
     * @param zmatnrInput the zmatnrInput to set
     */
    public void setZmatnrInput(String zmatnrInput) {
        this.zmatnrInput = zmatnrInput;
    }

    /**
     * @return the confMatnr
     */
    public String getConfMatnr() {
        return confMatnr;
    }

    /**
     * @param confMatnr the confMatnr to set
     */
    public void setConfMatnr(String confMatnr) {
        this.confMatnr = confMatnr;
    }

    /**
     * @return the splyMatnr
     */
    public String getSplyMatnr() {
        return splyMatnr;
    }

    /**
     * @param splyMatnr the splyMatnr to set
     */
    public void setSplyMatnr(String splyMatnr) {
        this.splyMatnr = splyMatnr;
    }

    /**
     * @return the netpr
     */
    public BigDecimal getNetpr() {
        return netpr;
    }

    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(BigDecimal netpr) {
        this.netpr = netpr;
    }

    /**
     * @return the zcfmqty
     */
    public BigDecimal getZcfmqty() {
        return zcfmqty;
    }

    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(BigDecimal zcfmqty) {
        this.zcfmqty = zcfmqty;
    }

    /**
     * @return the shipQty
     */
    public BigDecimal getShipQty() {
        return shipQty;
    }

    /**
     * @param shipQty the shipQty to set
     */
    public void setShipQty(BigDecimal shipQty) {
        this.shipQty = shipQty;
    }

    /**
     * @return the zboqty
     */
    public BigDecimal getZboqty() {
        return zboqty;
    }

    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(BigDecimal zboqty) {
        this.zboqty = zboqty;
    }

    /**
     * @return the zcancqty
     */
    public BigDecimal getZcancqty() {
        return zcancqty;
    }

    /**
     * @param zcancqty the zcancqty to set
     */
    public void setZcancqty(BigDecimal zcancqty) {
        this.zcancqty = zcancqty;
    }

    /**
     * @return the shipValue
     */
    public BigDecimal getShipValue() {
        return shipValue;
    }

    /**
     * @param shipValue the shipValue to set
     */
    public void setShipValue(BigDecimal shipValue) {
        this.shipValue = shipValue;
    }

    /**
     * @return the totShipQty
     */
    public BigDecimal getTotShipQty() {
        return totShipQty;
    }

    /**
     * @param totShipQty the totShipQty to set
     */
    public void setTotShipQty(BigDecimal totShipQty) {
        this.totShipQty = totShipQty;
    }

    /**
     * @return the zamdcf
     */
    public String getZamdcf() {
        return zamdcf;
    }

    /**
     * @param zamdcf the zamdcf to set
     */
    public void setZamdcf(String zamdcf) {
        this.zamdcf = zamdcf;
    }

    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }

    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }

    /**
     * @return the zweig
     */
    public BigDecimal getZweig() {
        return zweig;
    }

    /**
     * @param zweig the zweig to set
     */
    public void setZweig(BigDecimal zweig) {
        this.zweig = zweig;
    }

    /**
     * @return the outBoxGrwei
     */
    public BigDecimal getOutBoxGrwei() {
        return outBoxGrwei;
    }

    /**
     * @param outBoxGrwei the outBoxGrwei to set
     */
    public void setOutBoxGrwei(BigDecimal outBoxGrwei) {
        this.outBoxGrwei = outBoxGrwei;
    }

    /**
     * @return the outBoxNtgew
     */
    public BigDecimal getOutBoxNtgew() {
        return outBoxNtgew;
    }

    /**
     * @param outBoxNtgew the outBoxNtgew to set
     */
    public void setOutBoxNtgew(BigDecimal outBoxNtgew) {
        this.outBoxNtgew = outBoxNtgew;
    }

    /**
     * @return the outBoxLeng
     */
    public BigDecimal getOutBoxLeng() {
        return outBoxLeng;
    }

    /**
     * @param outBoxLeng the outBoxLeng to set
     */
    public void setOutBoxLeng(BigDecimal outBoxLeng) {
        this.outBoxLeng = outBoxLeng;
    }

    /**
     * @return the outBoxWid
     */
    public BigDecimal getOutBoxWid() {
        return outBoxWid;
    }

    /**
     * @param outBoxWid the outBoxWid to set
     */
    public void setOutBoxWid(BigDecimal outBoxWid) {
        this.outBoxWid = outBoxWid;
    }

    /**
     * @return the outBoxHei
     */
    public BigDecimal getOutBoxHei() {
        return outBoxHei;
    }

    /**
     * @param outBoxHei the outBoxHei to set
     */
    public void setOutBoxHei(BigDecimal outBoxHei) {
        this.outBoxHei = outBoxHei;
    }

    /**
     * @return the inBoxGrwei
     */
    public BigDecimal getInBoxGrwei() {
        return inBoxGrwei;
    }

    /**
     * @param inBoxGrwei the inBoxGrwei to set
     */
    public void setInBoxGrwei(BigDecimal inBoxGrwei) {
        this.inBoxGrwei = inBoxGrwei;
    }

    /**
     * @return the inBoxNtgew
     */
    public BigDecimal getInBoxNtgew() {
        return inBoxNtgew;
    }

    /**
     * @param inBoxNtgew the inBoxNtgew to set
     */
    public void setInBoxNtgew(BigDecimal inBoxNtgew) {
        this.inBoxNtgew = inBoxNtgew;
    }

    /**
     * @return the inBoxLeng
     */
    public BigDecimal getInBoxLeng() {
        return inBoxLeng;
    }

    /**
     * @param inBoxLeng the inBoxLeng to set
     */
    public void setInBoxLeng(BigDecimal inBoxLeng) {
        this.inBoxLeng = inBoxLeng;
    }

    /**
     * @return the inBoxWid
     */
    public BigDecimal getInBoxWid() {
        return inBoxWid;
    }

    /**
     * @param inBoxWid the inBoxWid to set
     */
    public void setInBoxWid(BigDecimal inBoxWid) {
        this.inBoxWid = inBoxWid;
    }

    /**
     * @return the inBoxHei
     */
    public BigDecimal getInBoxHei() {
        return inBoxHei;
    }

    /**
     * @param inBoxHei the inBoxHei to set
     */
    public void setInBoxHei(BigDecimal inBoxHei) {
        this.inBoxHei = inBoxHei;
    }

    /**
     * @return the ccngn
     */
    public String getCcngn() {
        return ccngn;
    }

    /**
     * @param ccngn the ccngn to set
     */
    public void setCcngn(String ccngn) {
        this.ccngn = ccngn;
    }

    /**
     * @return the zfcifamt
     */
    public BigDecimal getZfcifamt() {
        return zfcifamt;
    }

    /**
     * @param zfcifamt the zfcifamt to set
     */
    public void setZfcifamt(BigDecimal zfcifamt) {
        this.zfcifamt = zfcifamt;
    }

    /**
     * @return the invoice
     */
    public String getInvoice() {
        return invoice;
    }

    /**
     * @param invoice the invoice to set
     */
    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }

    /**
     * @return the intTrade
     */
    public String getIntTrade() {
        return intTrade;
    }

    /**
     * @param intTrade the intTrade to set
     */
    public void setIntTrade(String intTrade) {
        this.intTrade = intTrade;
    }

}
