package com.mobis.maps.comm.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommLanguageService;
import com.mobis.maps.comm.vo.MapsCommLanguageVO;
import com.mobis.maps.comm.vo.MapsCommScrinFnctVO;

/**
 * <pre>
 * 다국어 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommLanguageController.java
 * @Description : 다국어 대한 컨트롤러 정의.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommLanguageController extends HController {

    @Resource(name = "mapsCommLanguageService")
    private MapsCommLanguageService mapsCommLanguageService;
    
    /**
     * 다국어 조회
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectLangList.do")
    public NexacroResult selectLangList(
            @ParamDataSet(name="dsInput") MapsCommLanguageVO commLanVO
            , NexacroResult result) throws Exception {
        
        List<MapsCommLanguageVO> lanInfos = mapsCommLanguageService.selectLangList(commLanVO);
                
        result.addDataSet("dsOutput", lanInfos);
        
        return result;
    }
    
    /**
     * 다국어 조회
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectLangFnctList.do")
    public NexacroResult selectLangFnctList(
            @ParamDataSet(name="dsInput") MapsCommLanguageVO commLanVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommLanguageVO> lanInfos = mapsCommLanguageService.selectLangList(commLanVO);
        
        MapsCommScrinFnctVO commScrinFnctVO = new MapsCommScrinFnctVO();
        commScrinFnctVO.setScrinId(commLanVO.getScrinId());
        List<MapsCommScrinFnctVO> scrinFncts = mapsCommLanguageService.selectScrinFuncList(commScrinFnctVO, loginInfo);
        
        result.addDataSet("dsOutput", lanInfos);
        result.addDataSet("dsOutputFnct", scrinFncts);
        
        return result;
    }
    
}
