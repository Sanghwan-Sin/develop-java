package com.mobis.maps.comm.vo;

import com.mobis.maps.cmmn.util.WebUtil;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ScrinConectInfoVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 7. 1.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 1.     oh.dongwon     	최초 생성
 * </pre>
 */

public class ScrinConectInfoVO {
    
    
    private String sysSeCd ;
    private String menuId  ;
    private String scrinId ;
    
    private String serverNm;
    
    private String userAgent;
    private String brwsrNm;
    private String conectIpAdres;
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the menuId
     */
    public String getMenuId() {
        return menuId;
    }
    /**
     * @param menuId the menuId to set
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the serverNm
     */
    public String getServerNm() {
        return serverNm;
    }
    /**
     * @param serverNm the serverNm to set
     */
    public void setServerNm(String serverNm) {
        this.serverNm = serverNm;
    }
    /**
     * @return the userAgent
     */
    public String getUserAgent() {
        return userAgent;
    }
    /**
     * @param userAgent the userAgent to set
     */
    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }
    /**
     * @return the brwsrNm
     */
    public String getBrwsrNm() {
        return brwsrNm;
    }
    /**
     * @param brwsrNm the brwsrNm to set
     */
    public void setBrwsrNm(String brwsrNm) {
        this.brwsrNm = brwsrNm;
    }
    /**
     * @return the conectIpAdres
     */
    public String getConectIpAdres() {
        return conectIpAdres;
    }
    /**
     * @param conectIpAdres the conectIpAdres to set
     */
    public void setConectIpAdres(String conectIpAdres) {
        this.conectIpAdres = conectIpAdres;
    }
    
    
    

}
