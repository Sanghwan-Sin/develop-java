package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 계정신청권한 항목
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstAuthorVO.java
 * @Description : 계정신청권한에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamAcntReqstAuthorVO extends MapsIamCommVO {
    /** 계정신청번호 */
    private String acntReqstNo;
    /** 권한ID */
    private String authorId;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 권한명 */
    private String authorNm;
    /* 승인정보 */
    /** 사용자권한순번 */
    private int userAuthorSeq;
    /** 사용자순번ID */
    private String userSeqId;
    /**
     * @return the acntReqstNo
     */
    public String getAcntReqstNo() {
        return acntReqstNo;
    }
    /**
     * @param acntReqstNo the acntReqstNo to set
     */
    public void setAcntReqstNo(String acntReqstNo) {
        this.acntReqstNo = acntReqstNo;
    }
    /**
     * @return the authorId
     */
    public String getAuthorId() {
        return authorId;
    }
    /**
     * @param authorId the authorId to set
     */
    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the authorNm
     */
    public String getAuthorNm() {
        return authorNm;
    }
    /**
     * @param authorNm the authorNm to set
     */
    public void setAuthorNm(String authorNm) {
        this.authorNm = authorNm;
    }
    /**
     * @return the userAuthorSeq
     */
    public int getUserAuthorSeq() {
        return userAuthorSeq;
    }
    /**
     * @param userAuthorSeq the userAuthorSeq to set
     */
    public void setUserAuthorSeq(int userAuthorSeq) {
        this.userAuthorSeq = userAuthorSeq;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
}
