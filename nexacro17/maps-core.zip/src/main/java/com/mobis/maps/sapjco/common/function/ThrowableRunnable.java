package com.mobis.maps.sapjco.common.function;

import com.mobis.maps.cmmn.exception.MapsRuntimeException;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ThrowableRunnable.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 5. 8.     DT045877     	최초 생성
 * </pre>
 */
@FunctionalInterface
public interface ThrowableRunnable {
    /**
     * @see
     * java.lang.Runnable
     * 
     * @throws
     * Exception
     */
    void run() throws Exception;
    
    /**
     * throws Exception lambda to throws RuntimeException lambda
     * @param runnable
     * @return
     * @since
     * 0.6
     */
    public static Runnable runtime(ThrowableRunnable runnable) {
        return () -> {
            try {
                runnable.run();
            } catch (Exception e) {
                throw new MapsRuntimeException(e);
            }
        };
    }
    
    /**
     * ignore exception<br>
     * this method recommend only special situation 
     * @param runnable
     * @return
     * @since
     * 1.1
     */
    public static Runnable ignore(ThrowableRunnable runnable) {
        return () -> {
            try {
                runnable.run();
            } catch (Exception e) {
            }
        };
    }
}