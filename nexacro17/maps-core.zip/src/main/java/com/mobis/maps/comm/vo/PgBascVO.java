package com.mobis.maps.comm.vo;

import able.com.ui.adaptor.nexacro.data.DataSetRowTypeAccessor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PgBascVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class PgBascVO extends CommVO implements DataSetRowTypeAccessor {
    /** Nexacro행구분[] */
    private int rowType;
    /** 행구분(N:Normal,I:Insert,U:update,D:Delete) */
    private String rowSe = "N";
    /** 체크여부 */
    private String chkYn = "N";
    /** 행번호 */
    private int rnum;
    /** 페이지번호 */
    private int pgNum = 1;
    /** 페이지단위 */
    private int pgSize = 10;
    /** 스크롤페이지번호 */
    private int idxPgNum = 1;
    /** 스크롤페이지단위 */
    private int idxPgSize = 10;
    /** 전체페이지수 */
    private int totPgCnt;
    /** 전체데이터수 */
    private int totCnt;
    /** 페이징타입[P:일반Paging, S:스크롤Paging] */
    private String pgType = "P";
    /** 스크롤페이지번호 */
    private int scrollPgNum = 1;
    /** 스크롤페이지단위 */
    private int scrollPgSize = 10000;
    /** 엑셀다운로드여부 */
    private String excelDwnlYn = "N";
    /** 전체건수여부 */
    private String totCntYn = "N";
    /** 전체최대건수 */
    private int totMaxCnt = 50000;
    /** 키워드타입 */
    private String kwrdTy;
    /** 키워드 */
    private String kwrd;

    /**
     * 조회 시작행
     *
     * @return
     */
    public int getStartRow() {
        return (pgNum -1) * pgSize; 
    }

    /**
     * 시작행번호
     *
     * @return
     */
    public int getStrtRnum() {
        return ((pgNum - 1) * pgSize) + 1;
    }

    /**
     * @return the rowType
     */
    public int getRowType() {
        return rowType;
    }
    /**
     * @param rowType the rowType to set
     */
    public void setRowType(int rowType) {
        this.rowType = rowType;
    }
    /**
     * @return the rowSe
     */
    public String getRowSe() {
        return rowSe;
    }
    /**
     * @param rowSe the rowSe to set
     */
    public void setRowSe(String rowSe) {
        this.rowSe = rowSe;
    }
    /**
     * @return the chkYn
     */
    public String getChkYn() {
        return chkYn;
    }
    /**
     * @param chkYn the chkYn to set
     */
    public void setChkYn(String chkYn) {
        this.chkYn = chkYn;
    }
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the pgNum
     */
    public int getPgNum() {
        return pgNum;
    }
    /**
     * @param pgNum the pgNum to set
     */
    public void setPgNum(int pgNum) {
        this.pgNum = pgNum;
    }
    /**
     * @return the pgSize
     */
    public int getPgSize() {
        return pgSize;
    }
    /**
     * @param pgSize the pgSize to set
     */
    public void setPgSize(int pgSize) {
        this.pgSize = pgSize;
    }
    /**
     * @return the idxPgNum
     */
    public int getIdxPgNum() {
        return idxPgNum;
    }
    /**
     * @param idxPgNum the idxPgNum to set
     */
    public void setIdxPgNum(int idxPgNum) {
        this.idxPgNum = idxPgNum;
    }
    /**
     * @return the idxPgSize
     */
    public int getIdxPgSize() {
        return idxPgSize;
    }
    /**
     * @param idxPgSize the idxPgSize to set
     */
    public void setIdxPgSize(int idxPgSize) {
        this.idxPgSize = idxPgSize;
    }
    /**
     * @return the totPgCnt
     */
    public int getTotPgCnt() {
        return totPgCnt;
    }
    /**
     * @param totPgCnt the totPgCnt to set
     */
    public void setTotPgCnt(int totPgCnt) {
        this.totPgCnt = totPgCnt;
    }
    /**
     * @return the totCnt
     */
    public int getTotCnt() {
        return totCnt;
    }
    /**
     * @param totCnt the totCnt to set
     */
    public void setTotCnt(int totCnt) {
        this.totCnt = totCnt;
    }
    /**
     * @return the pgType
     */
    public String getPgType() {
        return pgType;
    }
    /**
     * @param pgType the pgType to set
     */
    public void setPgType(String pgType) {
        this.pgType = pgType;
    }
    /**
     * @return the scrollPgNum
     */
    public int getScrollPgNum() {
        return scrollPgNum;
    }
    /**
     * @param scrollPgNum the scrollPgNum to set
     */
    public void setScrollPgNum(int scrollPgNum) {
        this.scrollPgNum = scrollPgNum;
    }
    /**
     * @return the scrollPgSize
     */
    public int getScrollPgSize() {
        return scrollPgSize;
    }
    /**
     * @param scrollPgSize the scrollPgSize to set
     */
    public void setScrollPgSize(int scrollPgSize) {
        this.scrollPgSize = scrollPgSize;
    }
    /**
     * @return the excelDwnlYn
     */
    public String getExcelDwnlYn() {
        return excelDwnlYn;
    }
    /**
     * @param excelDwnlYn the excelDwnlYn to set
     */
    public void setExcelDwnlYn(String excelDwnlYn) {
        this.excelDwnlYn = excelDwnlYn;
    }
    /**
     * @return the totCntYn
     */
    public String getTotCntYn() {
        return totCntYn;
    }
    /**
     * @param totCntYn the totCntYn to set
     */
    public void setTotCntYn(String totCntYn) {
        this.totCntYn = totCntYn;
    }
    /**
     * @return the totMaxCnt
     */
    public int getTotMaxCnt() {
        return totMaxCnt;
    }
    /**
     * @param totMaxCnt the totMaxCnt to set
     */
    public void setTotMaxCnt(int totMaxCnt) {
        this.totMaxCnt = totMaxCnt;
    }
    /**
     * @return the kwrdTy
     */
    public String getKwrdTy() {
        return kwrdTy;
    }
    /**
     * @param kwrdTy the kwrdTy to set
     */
    public void setKwrdTy(String kwrdTy) {
        this.kwrdTy = kwrdTy;
    }
    /**
     * @return the kwrd
     */
    public String getKwrd() {
        return kwrd;
    }
    /**
     * @param kwrd the kwrd to set
     */
    public void setKwrd(String kwrd) {
        this.kwrd = kwrd;
    }

}
