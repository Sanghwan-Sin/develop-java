package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.iam.vo.MapsIamUserScrinBkmkVO;

/**
 * <pre>
 * 사용자 화면 즐겨찾기 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinBkmkMDAO.java
 * @Description : 사용자 화면 즐겨찾기에 대한 데이터 처리를 정의.
 * @author DT048058
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsIamUserScrinBkmkMDAO")
public interface MapsIamUserScrinBkmkMDAO {
    
    /**
     * 사용자 화면 즐겨찾기 리스트 조회
     *
     * @param iamUserScrinBkmkVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinBkmkVO> selectUserScrinBkmkList(MapsIamUserScrinBkmkVO iamUserScrinBkmkVO) throws Exception;

    /**
     * 사용자 화면 즐겨찾기 등록
     *
     * @param iamUserScrinBkmkVO
     * @throws Exception
     */
    public void insertUserScrinBkmk(MapsIamUserScrinBkmkVO iamUserScrinBkmkVO) throws Exception;

    /**
     * 사용자 화면 즐겨찾기 삭제
     *
     * @param iamUserScrinBkmkVO
     * @throws Exception
     */
    public int deleteUserScrinBkmk(MapsIamUserScrinBkmkVO iamUserScrinBkmkVO) throws Exception;
}
