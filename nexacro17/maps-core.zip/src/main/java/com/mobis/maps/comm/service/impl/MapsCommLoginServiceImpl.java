package com.mobis.maps.comm.service.impl;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import able.com.service.HService;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsLoginException;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.util.WebUtil;
import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztCcpyVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztMobisVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztPdaVO;
import com.mobis.maps.cmmn.vo.SapCodeVO;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommCodeService;
import com.mobis.maps.comm.service.MapsCommLoginService;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.comm.service.dao.MapsCommLoginMDAO;
import com.mobis.maps.comm.vo.MapsCommAuthorVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.comm.vo.MapsCommLoginVO;
import com.mobis.maps.comm.vo.MapsCommMenuVO;
import com.mobis.maps.comm.vo.MapsCommSapLoginVO;
import com.mobis.maps.comm.vo.MapsCommUserScrinBkmkVO;
import com.mobis.maps.comm.vo.MapsOpenSdiScrinInfoVO;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.vo.MapsIamLoginHistVO;
import com.mobis.maps.iam.vo.MapsIamUserLangVO;
import com.mobis.maps.iam.vo.MapsIamUserPermIpVO;

/**
 * <pre>
 * 로그인 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommLoginServiceImpl.java
 * @Description : 로그인에 대한 서비스를 구현.
 * @author Sin Sanghwan
 * @since 2019. 8. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 28.     Sin Sanghwan       최초 생성
 * </pre>
 */
@Service("mapsCommLoginService")
public class MapsCommLoginServiceImpl extends HService implements MapsCommLoginService {

    @Resource(name = "mapsCommCodeService")
    private MapsCommCodeService mapsCommCodeService;
    
    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    @Resource(name="mapsCommLoginMDAO")
    private MapsCommLoginMDAO mapsCommLoginMDAO;
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectLoginInit(com.mobis.maps.comm.vo.MapsCommLoginVO, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public MapsCommLoginVO selectLoginInit(MapsCommLoginVO commLoginVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
        // SSO START
        HttpSession session = request.getSession(true);
        String ssoUserId = (String)session.getAttribute("IMOBIS_SESSION_USERID");
        
        // 로그인 세션 초기화
        if (request.getSession().getAttribute(MapsConstants.SSS_LOGIN_INFO) != null) {
            selectLogout(request, response);
        }
        
        HttpSession sessionNew = request.getSession(true);
        sessionNew.setAttribute("IMOBIS_SESSION_USERID" , ssoUserId);
        

        boolean isReal = true;
        String serverName = request.getServerName();
        logger.debug("→ selectLoginInit.start[serverName=" + serverName + "]");
        // local/dev/qa는 기본 ID셋팅
        if (StringUtils.contains(serverName, "localhost")
                || StringUtils.contains(serverName, "-dev")
                || StringUtils.contains(serverName, "-qa")
            ) {
            isReal = false;
        }
        
        String sysSeCd = commLoginVO.getSysSeCd();
        // 운영일때는 자동 id셋팅안한다.
        if (!isReal) {
            /* TEST용 코딩 SRS는 korea */
            // nMGN
            if (StringUtils.equals(sysSeCd, "M")) {
                commLoginVO.setUserId("CONTEST");
                commLoginVO.setUserPwd("maps2020!");
            // SRS
            } else if (StringUtils.equals(sysSeCd, "S")) {
                commLoginVO.setUserId("SRSUSER");
                commLoginVO.setUserPwd("maps2020!");
            // 수평전개
            } else if (StringUtils.equals(sysSeCd, "H")) {
                commLoginVO.setUserId("TESTUSER");
                commLoginVO.setUserPwd("maps2020!");
            // work flow 2(을지)
            } else if (StringUtils.equals(sysSeCd, "R")) {
                commLoginVO.setUserId("TESTUSER");
                commLoginVO.setUserPwd("maps2020!");
            // DDS
            } else if (StringUtils.equals(sysSeCd, "T")) {
                commLoginVO.setUserId("TESTDDS");
                commLoginVO.setUserPwd("maps2020!");
            // PDA
            } else if (StringUtils.equals(sysSeCd, "P")) {
                commLoginVO.setUserId("PDAUSER");
                commLoginVO.setUserPwd("maps2020!");
            // IAM
            } else if (StringUtils.equals(sysSeCd, "I")) {
                commLoginVO.setUserId("IAMITUSER");
                commLoginVO.setUserPwd("maps2020!");
            // 기타
            } else {
                commLoginVO.setUserId("CONTEST");
                commLoginVO.setUserPwd("maps2020!");
            }
        }

        //로그인 디폴트 언어코드 설정
        String langCd = PropertiesUtil.getDbValue(DBPROP_KEY_LOGIN_DEFAULT_LANG_CD);
        if (StringUtils.isBlank(langCd)) {
            if (sysSeCd.matches("S|H|R|T|I|P")) {
                Locale locale = new Locale("ko", "KR");
                langCd = locale.toString();
            } else {
                langCd = MapsConstants.DFLT_LOCALE.toString();
            }
        }
        commLoginVO.setLangCd(langCd);
        
        return commLoginVO;
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommCodeService#selectCodeList(com.mobis.maps.comm.vo.MapsCommCodeVO)
     */
    @Override
    public List<CodeVO> selectLoginLangList(MapsCommCodeVO commCodeVO) throws Exception {
        return mapsCommLoginMDAO.selectLoginLangList(commCodeVO);
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectLoginInfo(com.mobis.maps.comm.vo.MapsCommLoginVO, com.mobis.maps.iam.vo.MapsIamLoginHistVO, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public LoginInfoVO selectLoginInfo(MapsCommLoginVO commLoginVO
            , MapsIamLoginHistVO iamLoginHistVO 
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        /* 로그정보설정 */
        Locale userLocale = MessageUtil.getLocale(commLoginVO.getLangCd());
        String loginIpAdres = WebUtil.getUserIpAdres(request);
        
        commLoginVO.setUserId(StringUtils.trim(commLoginVO.getUserId()));
        commLoginVO.setUserPwd(StringUtils.trim(commLoginVO.getUserPwd()));

        /* 로그이력정보초기설정 */
        iamLoginHistVO.setSysSeCd(commLoginVO.getSysSeCd());
        iamLoginHistVO.setUserId(commLoginVO.getUserId());
        iamLoginHistVO.setLangCd(commLoginVO.getLangCd());
        iamLoginHistVO.setServerNm(request.getServerName());
        iamLoginHistVO.setLoginIpAdres(loginIpAdres);
        iamLoginHistVO.setSuccesYn(MapsConstants.YN_YES);
        
        /* 세션초기화 */
        HttpSession session = request.getSession(true);
        session.invalidate();
        /* 로그인정보설정 */
        LoginInfoVO loginInfoVO = mapsCommLoginMDAO.selectLoginInfo(commLoginVO);
        /* 로그인정보 정합성 체크 */
        selectValidateUserInfo(commLoginVO, iamLoginHistVO, loginInfoVO, userLocale, request);
        
        /* 로그정보에 대한 로그인 이력 정보 초기설정 */
        iamLoginHistVO.setLoginDt(loginInfoVO.getLoginDt());
        
        /* jsessionid 셋팅 */
        iamLoginHistVO.setJsessionid(session.getId());
        
        
        /* 로그인 성공 */
        loginInfoVO.setSessionId(session.getId());
        loginInfoVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        loginInfoVO.setUserLcale(userLocale);
        loginInfoVO.setLoginIpAdres(loginIpAdres);
        // TimeZone설정
        TimeZone userTz = TimeZone.getTimeZone(loginInfoVO.getTzId());
        userTz.setRawOffset(loginInfoVO.getTzRawOffset());
        loginInfoVO.setUserTz(userTz);
        
        /* 세션설정 */
        session = request.getSession();
        // RFC PC SYSTEM 설정
        loginInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        loginInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        // RFC PW SYSTEM 설정
        loginInfoVO.setRfcPwSysId(RfcSapSys.PW.getSysId());
        loginInfoVO.setRfcPwClient(RfcSapSys.PW.getClient());
        /* 영업조직명 조회 */
        MapsCommCodeVO commCodeVO = new MapsCommCodeVO();
        commCodeVO.setCodeGroup("CD-SD-0098");
        commCodeVO.setCodeColNm("codeRefer1");
        commCodeVO.setCodeRefer1(loginInfoVO.getBsnOrgnztCd());
        SapCodeVO codeVO = mapsCommCodeService.selectSapCodeNm(commCodeVO, loginInfoVO);
        if (codeVO != null) {
            loginInfoVO.setBsnOrgnztNm(codeVO.getCodeNm());
        }
        
        if (StringUtils.equals(commLoginVO.getSysSeCd(), MapsConstants.SYS_SE_CD_SRS)) {
            MapsOrgnztCcpyVO orgnztCcpyVO = mapsCommLoginMDAO.selectOrgnztCcpyInfo(loginInfoVO);
            if (orgnztCcpyVO != null) {
                loginInfoVO.setBsnOrgnztCd(orgnztCcpyVO.getBukrs());
                loginInfoVO.setBsnOrgnztNm(orgnztCcpyVO.getButxt());
                loginInfoVO.setOrgnztCd(orgnztCcpyVO.getLifnr());
                loginInfoVO.setOrgnztNm(orgnztCcpyVO.getName1());
                
                session.setAttribute(MapsConstants.SSS_ORGNZT_INFO, orgnztCcpyVO);
            }
        } else if (StringUtils.equals(commLoginVO.getSysSeCd(), MapsConstants.SYS_SE_CD_PDA)) {
            List<MapsOrgnztPdaVO> orgnztPdaVO = mapsCommLoginMDAO.selectOrgnztPdaInfo(loginInfoVO);
            if (orgnztPdaVO != null) {
                session.setAttribute(MapsConstants.SSS_ORGNZT_INFO, orgnztPdaVO);
            }
        } else if (StringUtils.equals(commLoginVO.getSysSeCd(), MapsConstants.SYS_SE_CD_NMGN)) {
            MapsOrgnztDistVO orgnztDistVO = mapsCommLoginMDAO.selectOrgnztDistInfo(loginInfoVO);
            if (orgnztDistVO != null) {
                loginInfoVO.setBsnOrgnztCd(orgnztDistVO.getVkorg());
                loginInfoVO.setBsnOrgnztNm(orgnztDistVO.getVkorgNm());
                loginInfoVO.setOrgnztCd(orgnztDistVO.getKunnr());
                loginInfoVO.setOrgnztNm(orgnztDistVO.getZkunam());
                loginInfoVO.setRepZkunnr(orgnztDistVO.getZkunnr().equals(orgnztDistVO.getZkunn2()));
                
                session.setAttribute(MapsConstants.SSS_ORGNZT_INFO, orgnztDistVO);
            }
        } else if (StringUtils.equals(commLoginVO.getSysSeCd(), MapsConstants.SYS_SE_CD_DCS)) {
            MapsOrgnztDistVO orgnztDistVO = new MapsOrgnztDistVO();
            session.setAttribute(MapsConstants.SSS_ORGNZT_INFO, orgnztDistVO);
        } else {
            MapsOrgnztMobisVO orgnztMobisVO = mapsCommLoginMDAO.selectOrgnztMobisInfo(loginInfoVO);
            if (orgnztMobisVO != null) {
                loginInfoVO.setOrgnztCd(orgnztMobisVO.getUserCurrentCode());
                loginInfoVO.setOrgnztNm(orgnztMobisVO.getUserCurrentNm());
                
                session.setAttribute(MapsConstants.SSS_ORGNZT_INFO, orgnztMobisVO);
            }
        }

        // 권한 리스트 셋팅 start
        MapsCommAuthorVO inParam = new MapsCommAuthorVO();
        inParam.setUserSeqId(loginInfoVO.getUserSeqId());
        inParam.setSysSeCd(loginInfoVO.getSysSeCd());
        List<MapsCommAuthorVO> mapsCommAuthorVOS  = mapsCommLoginMDAO.selectAuthorList(inParam);
        session.setAttribute(MapsConstants.SSS_AUTHOR_LIST, mapsCommAuthorVOS);
        // 권한 리스트 셋팅 end
        
        // 세션최대허용시간설정(초)
        //session.setMaxInactiveInterval(10);
        session.setAttribute(MapsConstants.SSS_LOGIN_INFO, loginInfoVO);
        
        return loginInfoVO;
    }
    
    /**
     * 로그인 정보 정합성 체크
     *
     * @param commLoginVO
     * @param iamLoginHistVO
     * @param loginInfoVO
     * @param userLocale
     * @throws Exception
     */
    private void selectValidateUserInfo(MapsCommLoginVO commLoginVO
            , MapsIamLoginHistVO iamLoginHistVO
            , LoginInfoVO loginInfoVO
            , Locale userLocale
            , HttpServletRequest request) throws Exception {
        //암호최대오류건수
        String pwdErrorMaxCo = PropertiesUtil.getDbValue(DBPROP_KEY_LOGIN_PW_ERR_CNT);
        if (!StringUtils.isNumeric(pwdErrorMaxCo)) {
            pwdErrorMaxCo = MapsConstants.DEFAULT_PASSWORD_MAX_ERROR_COUNT;
        }
        //시스템현재일시
        Calendar toDay = Calendar.getInstance(userLocale);
        
        
        ////////////////////
        // 2020.12.22 ~ 2020.01.03까지 nMGN/SRS는 로그인시 MAPS 시스템 오픈 준비중입니다. 이 표시 되어야 함.
        // PDA는 2020.12.28일까지 서비스가 제공 되어야 하므로,  메시지를 분리함.
        String loginFailMsgCd = "EC00000045";  
        // SRS // nMGN 인경우만 변경
        if (StringUtils.equals(commLoginVO.getSysSeCd(), MapsConstants.SYS_SE_CD_SRS)) {
            loginFailMsgCd = "ECM0000016";//MAPS 시스템 오픈 준비중입니다.
        } else if (StringUtils.equals(commLoginVO.getSysSeCd(), MapsConstants.SYS_SE_CD_NMGN)) {
            loginFailMsgCd = "ECM0000016"; //MAPS 시스템 오픈 준비중입니다.
        }
        
        
        
        /* 계정이 존재하는지 체크 */
        if (loginInfoVO == null
                || !StringUtils.equals(commLoginVO.getUserId(), loginInfoVO.getUserId())) {
            iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_NOT_HAS_USER);
            // SSO 연동시는 다른 메시지를 띄운다.
            if (StringUtils.equals(commLoginVO.getSsoFlag(), "Y")) {
                // 등록된 계정이 없습니다.
                throw new MapsLoginException(messageSource, "ECI0000049", userLocale, null);
            } else {
                throw new MapsLoginException(messageSource, loginFailMsgCd, new String[] { pwdErrorMaxCo }, userLocale, null);
            }
        }
        iamLoginHistVO.setLoginSeqId(loginInfoVO.getUserSeqId());
        
        
        
        
        /* 계정잠김 체크 */
        if (StringUtils.equals(loginInfoVO.getAcntLockYn(), MapsConstants.YN_YES)) {
            //- 004 : 계정잠김
            iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_ACCOUNT_LOCK);
            // 계정암호정보삭제
            loginInfoVO.setUserPwd(null);
            
            HttpSession session = request.getSession();
            session.setAttribute(MapsConstants.SSS_LOCK_LOGIN_INFO, loginInfoVO);
            throw new MapsLoginException(messageSource, "EC00000052", null, userLocale, null);
        }
        
        // SSO 인경우 체크 안함. 비번오류횟수/비번/만료기간 체크하지 않음
        if (!StringUtils.equals(commLoginVO.getSsoFlag(), "Y")) {
            /* 비밀번호 입력오류 체크 */
            if (loginInfoVO.getPwdErrorCo() >= Integer.parseInt(pwdErrorMaxCo)) {
                //- 101 : 비밀번호오류횟수초과
                iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_PASSWORD_OVER_COUNT);
                //throw new MapsLoginException(messageSource, "EC00000054", null, userLocale, Integer.parseInt(iamLoginHistVO.getFailrSeCd()));
                throw new MapsLoginException(messageSource, loginFailMsgCd, new String[]{pwdErrorMaxCo}, userLocale, null);
            }
        
            /* 비밀번호 체크 */
            if (!StringUtils.equals(loginInfoVO.getPwdChkYn(), "Y")) {
                //- 100 : 비밀번호입력시 오류
                iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_NOT_MATCH_PASSWORD);
                //throw new MapsLoginException(messageSource, "EC00000053", new String[]{String.valueOf(loginInfoVO.getPwdErrorCo() + 1)}, userLocale, Integer.parseInt(iamLoginHistVO.getFailrSeCd()));
                throw new MapsLoginException(messageSource, loginFailMsgCd, new String[]{pwdErrorMaxCo}, userLocale, null);
            }
            
            /* 비밀번호 만료기한 체크 */
            if (toDay.getTime().compareTo(loginInfoVO.getPwdEndDt()) > 0) {
                //- 102 : 비밀번호만료
                iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_END_PASSWORD);
                throw new MapsLoginException(messageSource, loginFailMsgCd, null, userLocale, null);
            }
        }
        
        /* 장기 미사용자 체크 */
        String notCnnectMaxDay = PropertiesUtil.getDbValue(DBPROP_KEY_IAM_LOGIN_NOT_CNNECT_MAX_DAY);
        if (StringUtils.isBlank(notCnnectMaxDay)) {
            notCnnectMaxDay = PropertiesUtil.getDbValue(DBPROP_KEY_LOGIN_NOT_CNNECT_MAX_DAY);
        }
        // nMGN 인경우 14,15번 대리점 만 90일 나머지는 30일로 추가 요청
        if( StringUtils.equals( loginInfoVO.getSysSeCd() , "M" ) ){
            // 조직코드(대리점 코드)
            String orgnztCd = loginInfoVO.getOrgnztCd();
            // 사용자 유형(M : 모비스  , G : 일반 대리점)
            String orgnztSeCd = loginInfoVO.getOrgnztSeCd();
            
            // 모비스 직원 또는 대리점 코드 없는 사람 == > 90일
            if( StringUtils.equals(orgnztSeCd, "M") || StringUtils.isBlank(orgnztCd)  ){
                notCnnectMaxDay = PropertiesUtil.getDbValue(DBPROP_KEY_LOGIN_NOT_CNNECT_MAX_DAY);
            // 대리점 직원이며, 조직코드가 존재하는 경우.
            }else if( StringUtils.equals(orgnztSeCd, "G") && StringUtils.isNotBlank(orgnztCd)  ){
                // 대리점 유형 조회 // 13,14,15 유형 중 13은 30일 나머지는 90일
                loginInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
                loginInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
                // 조직 조회
                MapsOrgnztDistVO orgnztDistVO = mapsCommLoginMDAO.selectOrgnztDistInfo(loginInfoVO);
                String kdgrp = orgnztDistVO.getKdgrp();
                // 13번 유형만 90일 적용
                if( StringUtils.equals(kdgrp, "13")){
                    notCnnectMaxDay = PropertiesUtil.getDbValue(DBPROP_KEY_LOGIN_NOT_CNNECT_MAX_DAY); 
                }            
            }
        }
        
        if (StringUtils.isNumeric(notCnnectMaxDay) && loginInfoVO.getLastLoginDt() != null) {
            Calendar calMax = Calendar.getInstance();
            calMax.setTime(loginInfoVO.getLastLoginDt());
            calMax.add(Calendar.DAY_OF_YEAR, Integer.parseInt(notCnnectMaxDay));
            if (toDay.getTime().compareTo(calMax.getTime()) > 0) {
                //- 200 : 장기미사용자
                iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_NOT_USED_LONG);
                throw new MapsLoginException(messageSource, "EC00000056", null, userLocale, null);
            }
        }
        
        /* 사용기간 체크 */
        if (loginInfoVO.getUseBgnde().compareTo(toDay.getTime()) >= 0
                || toDay.getTime().compareTo(loginInfoVO.getUseEndde()) >= 0) {
            //- 201 : 미사용기간
            iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_NOT_USED_PRIOD);
            throw new MapsLoginException(messageSource, "EC00000059", null, userLocale, null);
            
        }
        
        
        String dubLoginYn = PropertiesUtil.getDbValue(DBPROP_KEY_DUP_LOGIN_CHECK_YN); // 중복 로그인 체크하는 여부 "Y"인경우 중복 로그인 체크
        String userId = commLoginVO.getUserId();
        String duploginIds = PropertiesUtil.getDbValue("DUP_LOGIN_IDS");
        boolean iaMatchDupLoginList = WebUtil.isMatchArryString(userId, duploginIds);
        if (logger.isDebugEnabled()) {
            logger.debug("******************************::userId["+userId+"]");
            logger.debug("******************************::duploginIds["+duploginIds+"]");
            logger.debug("******************************::iaMatchDupLoginList["+iaMatchDupLoginList+"]");
        }
        // 중복로그인 허용 리스트에 존재하면 중복로그인 체크 안함.
        if( StringUtils.equals(dubLoginYn, "Y")  &&  iaMatchDupLoginList ){
            dubLoginYn = "N";
        }
        
        if(StringUtils.equals(dubLoginYn , "Y")){
            // The account is already logged in. Do you want to log in?  Y로 답한경우 
            if( StringUtils.isBlank( commLoginVO.getPreLoginFlag() ) ){
                // 중복로그인 체크 
                MapsIamLoginHistVO checkPreLogin = mapsCommLoginMDAO.selectPreLogin(loginInfoVO);
                String checkPreFlag = checkPreLogin.getPreLoginFlag();
                if( StringUtils.equals(checkPreFlag, PRE_LOGIN_CHECK_FLAG)){
                    loginInfoVO.setPreLoginFlag(PRE_LOGIN_CHECK_FLAG);
                    iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_PRE_LOGIN);
                    // 계정암호정보삭제
                    loginInfoVO.setUserPwd(null);
                    HttpSession session = request.getSession();
                    session.setAttribute(MapsConstants.SSS_LOCK_LOGIN_INFO, loginInfoVO);
                    // The account is already logged in. Do you want to log in?
                    throw new MapsLoginException(messageSource, "QCM0000002", null, userLocale, null);
                }
            }
        }
        
        
        /* 허용IP 체크 */
        if (StringUtils.equals(loginInfoVO.getPermIpUseYn(), MapsConstants.YN_YES)) {
            MapsIamUserPermIpVO iamUserPermIpVO = mapsCommLoginMDAO.selectUserPermIp(loginInfoVO);
            if (iamUserPermIpVO == null) {
                //- 002 : 허용IP사용시 오류
                iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_NOT_MATCH_IP);
                throw new MapsLoginException(messageSource, "EC00000050", null, userLocale, null);
            }
        }
        
        /* 설정 언어 체크 */
//        MapsIamUserLangVO iamUserLangVO = mapsCommLoginMDAO.selectUserLang(loginInfoVO);
//        if (iamUserLangVO == null) {
//            //- 003 : 미설정언어사용시
//            iamLoginHistVO.setFailrSeCd(MapsCommLoginService.FAILR_SE_CD_NOT_MATCH_LANG);
//            throw new MapsLoginException(messageSource, "EC00000051", null, userLocale, null);
//        }
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#insertLoginHist(com.mobis.maps.iam.vo.MapsIamLoginHistVO)
     */
    @Override
    public int insertLoginHist(MapsIamLoginHistVO iamLoginHistVO) throws Exception {
        
        int procCnt = 0;
        
        if (StringUtils.equals(iamLoginHistVO.getFailrSeCd(), MapsCommLoginService.FAILR_SE_CD_SYSTEM)
                || StringUtils.equals(iamLoginHistVO.getFailrSeCd(), MapsCommLoginService.FAILR_SE_CD_NOT_HAS_USER)) {
            return procCnt;
        } else if (StringUtils.equals(iamLoginHistVO.getFailrSeCd(), MapsCommLoginService.FAILR_SE_CD_PASSWORD_OVER_COUNT)
                || StringUtils.equals(iamLoginHistVO.getFailrSeCd(), MapsCommLoginService.FAILR_SE_CD_END_PASSWORD)
                || StringUtils.equals(iamLoginHistVO.getFailrSeCd(), MapsCommLoginService.FAILR_SE_CD_NOT_USED_LONG)
            ) {
            /* 계정잠김 여부 */
            if (StringUtils.equals(iamLoginHistVO.getFailrSeCd(), MapsCommLoginService.FAILR_SE_CD_PASSWORD_OVER_COUNT)) {
                iamLoginHistVO.setAcntLockResnCd(MapsIamConstants.ACNT_LOCK_RESN_CD_PASSWORD_OVER_COUNT);
            } else if (StringUtils.equals(iamLoginHistVO.getFailrSeCd(), MapsCommLoginService.FAILR_SE_CD_END_PASSWORD)) {
                iamLoginHistVO.setAcntLockResnCd(MapsIamConstants.ACNT_LOCK_RESN_CD_END_PASSWORD);
            } else if (StringUtils.equals(iamLoginHistVO.getFailrSeCd(), MapsCommLoginService.FAILR_SE_CD_NOT_USED_LONG)) {
                iamLoginHistVO.setAcntLockResnCd(MapsIamConstants.ACNT_LOCK_RESN_CD_NOT_USED_LONG);
            }
            iamLoginHistVO.setAcntLockYn(MapsConstants.YN_YES);
        }
        // 사용자정보 변경
        procCnt = mapsCommLoginMDAO.updateLoginInfoByLoginHist(iamLoginHistVO);
        // 사용자변경이력 등록
        if (StringUtils.equals(iamLoginHistVO.getAcntLockYn(), MapsConstants.YN_YES)) {
            mapsCommLoginMDAO.insertAcntLockUserChghst(iamLoginHistVO);
        }
        // 로그인이력 등록
        mapsCommLoginMDAO.insertLoginHist(iamLoginHistVO);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectMenuListByUser(com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommMenuVO> selectMenuListByUser(LoginInfoVO loginInfo) throws Exception {
        
        List<MapsCommMenuVO> lstMenu = mapsCommLoginMDAO.selectMenuListByUser(loginInfo);
        
        return lstMenu;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectUserScrinBkmkList(com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommUserScrinBkmkVO> selectUserScrinBkmkList(LoginInfoVO loginInfoVO) throws Exception {
        
        List<MapsCommUserScrinBkmkVO> lstUserScrinBkmk = mapsCommLoginMDAO.selectUserScrinBkmkList(loginInfoVO);
        
        return lstUserScrinBkmk;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectUserInfoManageMenuList(com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommMenuVO> selectUserInfoManageMenuList(LoginInfoVO loginInfo) throws Exception {

        List<MapsCommMenuVO> lstMenu = mapsCommLoginMDAO.selectUserInfoManageMenuList(loginInfo);
        
        return lstMenu;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectUserLangList(com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserLangVO> selectUserLangList(LoginInfoVO loginInfoVO) throws Exception {

        List<MapsIamUserLangVO> lstUserLang = mapsCommLoginMDAO.selectUserLangList(loginInfoVO);
        
        return lstUserLang;
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectLogout(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selectLogout(HttpServletRequest request, HttpServletResponse response) throws Exception {
        
        HttpSession session = request.getSession(true);
        session.invalidate();
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectSapLoginInit(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public MapsCommSapLoginVO selectSapLoginInit(HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        /* 세션 */
        HttpSession session = request.getSession();
        /* 로그인정보취득 */
        Locale locale = (Locale) session.getAttribute("locale");
        
        if( locale == null ){
            locale = Locale.KOREA;
        }
        
        String userId = (String) session.getAttribute("userId");
        String scrinCd = (String) session.getAttribute("scrinCd");
        String cnSulInnerNo = (String) session.getAttribute("cnSulInnerNo");
        String sancItemCd = (String) session.getAttribute("sancItemCd");
        
        
        selectLogout(request, response);
        
        MapsCommSapLoginVO commSapLoginVO = new MapsCommSapLoginVO();
        
        /*
        cnSulInnerNo001 sancItemCd001
        cnSulInnerNo002 sancItemCd002
        */
        
        // 디버깅 테스트용
        if( userId == null ){
            userId = "MAPSWF2";
            scrinCd = "";
            cnSulInnerNo = "cnSulInnerNo001";
            sancItemCd = "sancItemCd001";
        }
        
        commSapLoginVO.setUserId(userId);
        commSapLoginVO.setScrinCd(scrinCd);
        commSapLoginVO.setCnSulInnerNo(cnSulInnerNo);
        commSapLoginVO.setSancItemCd(sancItemCd);
        commSapLoginVO.setLangCd(locale.toString());
        
        return commSapLoginVO;
    }
    
    
    
    
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectSapLoginInfo(com.mobis.maps.comm.vo.MapsCommSapLoginVO, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public MapsOpenSdiScrinInfoVO selectSapLoginInfo(MapsCommSapLoginVO commSapLoginVO
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        
        /* 세션초기화 */
        HttpSession session = request.getSession(true);
        
        /* 로그인정보취득(WF2:결재 을지는 MAPSWF2 로 하드코딩(SAP에서 로그인정보 전달 없음).*/ 
        LoginInfoVO loginInfo = mapsCommLoginMDAO.selectSapLoginInfo(commSapLoginVO);
        // 결재 을지는 한국어로 결정
        loginInfo.setUserLcale(Locale.KOREA);
        /* 세션정보 설정 */
        LoginInfoVO loginInfoCheck = (LoginInfoVO)getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        logger.debug("******************************************************************************");
        logger.debug("********request.getSession().getId() : " + request.getSession().getId());
        logger.debug("********loginInfoCheck : " + loginInfoCheck);
        logger.debug("******************************************************************************");
        
        if( loginInfoCheck == null  ){
            session = request.getSession();
            session.setAttribute(MapsConstants.SSS_LOGIN_INFO, loginInfo);
        }
        /* 화면정보설정 */
        MapsOpenSdiScrinInfoVO openSdiScrinInfoVO = new MapsOpenSdiScrinInfoVO();
        return openSdiScrinInfoVO;
    }
    
    /**
     * Statements
     *
     * @param key
     * @return
     */
    private Object getSessionAttribute(String key) {
        try {
          HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
          return request.getSession().getAttribute(key);
        } catch (Exception exception) {
          return null;
        } 
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#updateLoginOutInfo(com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateLoginOutInfo(LoginInfoVO loginInfoVO) throws Exception {
        return mapsCommLoginMDAO.updateLoginOutInfo(loginInfoVO);
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommLoginService#selectLoginExpired(com.mobis.maps.iam.vo.MapsIamLoginHistVO)
     */
    @Override
    public MapsIamLoginHistVO selectLoginExpired(MapsIamLoginHistVO iamLoginHistVO) throws Exception {
        return mapsCommLoginMDAO.selectLoginExpired(iamLoginHistVO);
    }

}
