package com.mobis.maps.comm.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FormGoVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 4. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 23.     oh.dongwon     	최초 생성
 * </pre>
 */

public class FormGoVO {
    private String outFormUrl;

    /**
     * @return the outFormUrl
     */
    public String getOutFormUrl() {
        return outFormUrl;
    }

    /**
     * @param outFormUrl the outFormUrl to set
     */
    public void setOutFormUrl(String outFormUrl) {
        this.outFormUrl = outFormUrl;
    }
    
}
