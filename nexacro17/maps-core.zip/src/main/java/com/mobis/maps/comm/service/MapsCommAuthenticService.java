package com.mobis.maps.comm.service;

import java.util.List;

import com.mobis.maps.comm.vo.MapsCommAuthenticVO;

/**
 * <pre>
 * MAPS인증(화면, URL) 서비스
 * </pre>
 *
 * @ClassName   : MapsCommAuthenticService.java
 * @Description : MAPS인증(화면, URL)에 대한 서비스를 정의.
 * @author DT048058
 * @since 2020. 7. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 21.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsCommAuthenticService {
    
    /**
     * 화면정보 조회
     *
     * @param commAuthenticVO
     * @return
     * @throws Exception
     */
    public MapsCommAuthenticVO selectScrinInfo(MapsCommAuthenticVO commAuthenticVO) throws Exception;

    /**
     * MAPS인증(화면) 조회
     *
     * @param commAuthenticVO
     * @return
     * @throws Exception
     */
    public List<MapsCommAuthenticVO> selectAuthenticScrin(MapsCommAuthenticVO commAuthenticVO) throws Exception;

    /**
     * MAPS인증(팝업화면) 조회
     *
     * @param commAuthenticVO
     * @return
     * @throws Exception
     */
    public List<MapsCommAuthenticVO> selectAuthenticPopupScrin(MapsCommAuthenticVO commAuthenticVO) throws Exception;

    /**
     * 비로그인 MAPS인증(팝업화면) 조회
     *
     * @param commAuthenticVO
     * @return
     * @throws Exception
     */
    public List<MapsCommAuthenticVO> selecttNlognAuthenticPopupScrin(MapsCommAuthenticVO commAuthenticVO) throws Exception;

    /**
     * MAPS인증(서비스URL) 조회
     *
     * @param commAuthenticVO
     * @return
     * @throws Exception
     */
    public List<MapsCommAuthenticVO> selectAuthenticSvcUrl(MapsCommAuthenticVO commAuthenticVO) throws Exception;

    /**
     * 비로그인 MAPS인증(서비스URL) 조회
     *
     * @param commAuthenticVO
     * @return
     * @throws Exception
     */
    public List<MapsCommAuthenticVO> selectNlognAuthenticSvcUrl(MapsCommAuthenticVO commAuthenticVO) throws Exception;

}
