package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO;

/**
 * <pre>
 * 계정신청현황 데이터처리
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstSttusMDAO.java
 * @Description : 계정신청현황에 대한 데이터처리.
 * @author DT048058
 * @since 2020. 3. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 30.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsIamAcntReqstSttusMDAO")
public interface MapsIamAcntReqstSttusMDAO {

    /**
     * 계정신청현황 페이징리스트 조회
     *
     * @param iamAcntReqstInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAcntReqstInfoVO> selectAcntReqstSttusPgList(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception;

}
