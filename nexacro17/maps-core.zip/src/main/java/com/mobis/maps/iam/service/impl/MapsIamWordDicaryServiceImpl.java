package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamWordDicaryService;
import com.mobis.maps.iam.service.dao.MapsIamWordDicaryMDAO;
import com.mobis.maps.iam.vo.MapsIamWordDicaryVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 용어사전 관리 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommWordDicaryServiceImpl.java
 * @Description : 용어사전 관리 서비스 구현.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
@Service("mapsIamWordDicaryService")
public class MapsIamWordDicaryServiceImpl extends HService implements MapsIamWordDicaryService {
    
    @Resource(name="mapsIamWordDicaryMDAO")
    private MapsIamWordDicaryMDAO mapsIamWordDicaryMDAO;


    /*
     * @see com.mobis.maps.iam.service.MapsIamWordDicaryService#selectWdDicPgList(com.mobis.maps.iam.vo.MapsIamWordDicaryVO)
     */
    @Override
    public List<MapsIamWordDicaryVO> selectWdDicPgList(MapsIamWordDicaryVO iamWdDicVO) throws Exception {
        
        List<MapsIamWordDicaryVO> wdDicInfos = mapsIamWordDicaryMDAO.selectWdDicPgList(iamWdDicVO);
        
        return wdDicInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamWordDicaryService#selectWdDicInfoByLangWordId(com.mobis.maps.iam.vo.MapsIamWordDicaryVO)
     */
    @Override
    public MapsIamWordDicaryVO selectWdDicInfoByLangWordId(MapsIamWordDicaryVO iamWdDicVO) throws Exception {
        
        MapsIamWordDicaryVO wdDicVO = mapsIamWordDicaryMDAO.selectWdDicInfoByLangWordId(iamWdDicVO);
        
        return wdDicVO;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamWordDicaryService#multiWdDicInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiWdDicInfo(List<MapsIamWordDicaryVO> wdDicInfos, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        for (MapsIamWordDicaryVO iamWdDic: wdDicInfos) {
            
            int rowType = iamWdDic.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            iamWdDic.setRegistId(loginInfo.getUserSeqId());
            iamWdDic.setUpdtId(loginInfo.getUserSeqId());
            
            MapsIamWordDicaryVO resultCommWdDic = null;
                        
            switch (rowType) {
                case DataSet.ROW_TYPE_INSERTED :
//                    resultCommWdDic = mapsIamWordDicaryMDAO.selectWdDicInfoByOrginlWord(iamWdDic);
//                    if (resultCommWdDic != null) {
//                        throw new MapsBizException(messageSource, "IC00000008");
//                    }
                    mapsIamWordDicaryMDAO.insertWdDicInfo(iamWdDic);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    resultCommWdDic = mapsIamWordDicaryMDAO.selectWdDicInfo(iamWdDic);
                    if (resultCommWdDic != null) {
                        mapsIamWordDicaryMDAO.updateWdDicInfo(iamWdDic);
                    } else {
                        mapsIamWordDicaryMDAO.insertWdDicInfo(iamWdDic);
                    }
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    resultCommWdDic = mapsIamWordDicaryMDAO.selectWdDicInfo(iamWdDic);
                    if (resultCommWdDic == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[] { "Word Info" }, loginInfo.getUserLcale(), null);
                    }
                    if (StringUtils.equals(iamWdDic.getLangCd(), MapsConstants.DFLT_LOCALE.toString())) {
                        if (mapsIamWordDicaryMDAO.selectWdLangCnt(iamWdDic) > 0) {
                            throw new MapsBizException(messageSource, "ECI0000060", loginInfo.getUserLcale(), null);   //영어외에 등록된 용어가 있습니다.
                        }
                    }
                    mapsIamWordDicaryMDAO.deleteWdDicInfo(iamWdDic);
                    break;
                default:
                    continue;
            }
            procCnt++;
        }
        
        return procCnt;
    }
    
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamWordDicaryService#selectWdDicPgPopList(com.mobis.maps.iam.vo.MapsIamWordDicaryVO)
     */
    @Override
    public List<MapsIamWordDicaryVO> selectWdDicPgPopList(MapsIamWordDicaryVO iamWdDicVO) throws Exception {
        
        List<MapsIamWordDicaryVO> wdDicInfos = mapsIamWordDicaryMDAO.selectWdDicPgPopList(iamWdDicVO);
        
        return wdDicInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamWordDicaryService#selectWdDicInfoByRefrnLangCd(com.mobis.maps.iam.vo.MapsIamWordDicaryVO)
     */
    @Override
    public MapsIamWordDicaryVO selectWdDicInfoByRefrnLangCd(MapsIamWordDicaryVO iamWdDicVO) throws Exception {
        
        MapsIamWordDicaryVO wdDicInfo = mapsIamWordDicaryMDAO.selectWdDicInfoByRefrnLangCd(iamWdDicVO);
                
        return wdDicInfo;
    }

}
