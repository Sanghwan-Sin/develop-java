package com.mobis.maps.comm.vo;

import java.io.File;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;

/**
 * <pre>
 * SAP 첨부파일 항목 정의
 * </pre>
 *
 * @ClassName   : MapsSapRfcFileVO.java
 * @Description : SAP 첨부파일에 대한 항목을 정의.
 * @author DT048058
 * @since 2019. 12. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 27.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommSapAtchFileVO extends MapsCommSapRfcIfCommVO {
    /** File ID */
    @MapsRfcMappper( targetName="P|ES_ATTACH|IT_ATTACH", paramTrgtNm="CREATE|UPDATE|DELETE|CONTENT", ipttSe="I|E", fieldKey="I_FILE_SEQNO|FILE_SEQNO" )
    private String fileSeqno;
    /** File Server ID */
    @MapsRfcMappper( targetName="P|ES_ATTACH|IT_ATTACH", paramTrgtNm = "LIST|CREATE|UPDATE|DELETE|ALL_DELETE|CONTENT", ipttSe="I|E", fieldKey="I_FSCODE|FSCODE" )
    private String fscode;
    /** Reference Number */
    @MapsRfcMappper( targetName="P|ES_ATTACH|IT_ATTACH", paramTrgtNm = "LIST|CREATE|UPDATE|DELETE|ALL_DELETE", ipttSe="I|E", fieldKey="I_REF_NO|REF_NO" )
    private String refNo;
    /** Update Flag */
    @MapsRfcMappper( paramTrgtNm="CREATE", ipttSe = "I", fieldKey = "I_UPDATE_FLAG" )
    private String updateFlag;
    /** DD: 커밋이 실행되어야 하는지 표시 ('X','') */
    @MapsRfcMappper(paramTrgtNm="CREATE|UPDATE|DELETE|ALL_DELETE", ipttSe = "I", fieldKey = "I_EXCOMMIT")
    private String excommit;
    /** File ID (Update) */
    @MapsRfcMappper(paramTrgtNm = "UPDATE", ipttSe = "I", fieldKey = "I_FILE_SEQNO_UPDATE")
    private String fileSeqnoUpdate;
    /** Check Reference Number */
    @MapsRfcMappper(paramTrgtNm = "DELETE", ipttSe = "I", fieldKey = "I_CHK_REF_NO")
    private String chkRefNo;
    /** Relationship Type */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="REF_TYPE" )
    private String refType;
    /** Module */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZMODULE" )
    private String zmodule;
    /** File Path */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="FILE_PATH" )
    private String filePath;
    /** File Name (ex: abc.jpg) */
    @MapsRfcMappper( targetName="P|ES_ATTACH|IT_ATTACH", paramTrgtNm="CREATE|UPDATE", ipttSe="I|E", fieldKey="I_FILE_NAME|FILE_NAME" )
    private String fileName;
    /** File Extension */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="FILE_EXT" )
    private String fileExt;
    /** File Length (Byte) */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="FILE_LEN" )
    private Long fileLen;
    /** File System ID */
    @MapsRfcMappper( targetName="P|ES_ATTACH|IT_ATTACH", paramTrgtNm="CREATE|UPDATE", ipttSe="I|E", fieldKey="I_FILE_SYSID|FILE_SYSID" )
    private String fileSysid;
    /** 삭제지시자 */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="DELFL" )
    private String delfl;
    /** File Length(KB) - Char20 */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="FILE_LEN_KB" )
    private String fileLenKb;
    /** Size(KB) */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="FILE_LEN_KB_INT" )
    private Integer fileLenKbInt;
    /** File Length(MB) - Char20 */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="FILE_LEN_MB" )
    private String fileLenMb;
    /** Size(MB) */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="FILE_LEN_MB_INT" )
    private Integer fileLenMbInt;
    /** File Path (Legacy) */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="FILE_PATH_LEG" )
    private String filePathLeg;
    /** File Path (Legacy) - Include file */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="FILE_PATH_LEG2" )
    private String filePathLeg2;
    /** Create User */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZCRNAME" )
    private String zcrname;
    /** Create System Date */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZCRSDATE" )
    private Date zcrsdate;
    /** Create System Time */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZCRSTIME" )
    private String zcrstime;
    /** Create Local Date */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /** Create Local Time */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZCRLTIME" )
    private String zcrltime;
    /** Change User */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZUDNAME" )
    private String zudname;
    /** Change System Date */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZUDSDATE" )
    private Date zudsdate;
    /** Change System Time */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZUDSTIME" )
    private String zudstime;
    /** Change Local Date */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZUDLDATE" )
    private Date zudldate;
    /** Change Local Time */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZUDLTIME" )
    private String zudltime;
    /** ABAP System Field: Time Zone of Current User */
    @MapsRfcMappper( targetName="ES_ATTACH|IT_ATTACH", ipttSe="E", fieldKey="ZONLO" )
    private String zonlo;
    /** CHANNL 원본파일 */
    private File originalFile;
    /**
     * @return the fileSeqno
     */
    public String getFileSeqno() {
        return fileSeqno;
    }
    /**
     * @param fileSeqno the fileSeqno to set
     */
    public void setFileSeqno(String fileSeqno) {
        this.fileSeqno = fileSeqno;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the updateFlag
     */
    public String getUpdateFlag() {
        return updateFlag;
    }
    /**
     * @param updateFlag the updateFlag to set
     */
    public void setUpdateFlag(String updateFlag) {
        this.updateFlag = updateFlag;
    }
    /**
     * @return the excommit
     */
    public String getExcommit() {
        return excommit;
    }
    /**
     * @param excommit the excommit to set
     */
    public void setExcommit(String excommit) {
        this.excommit = excommit;
    }
    /**
     * @return the fileSeqnoUpdate
     */
    public String getFileSeqnoUpdate() {
        return fileSeqnoUpdate;
    }
    /**
     * @param fileSeqnoUpdate the fileSeqnoUpdate to set
     */
    public void setFileSeqnoUpdate(String fileSeqnoUpdate) {
        this.fileSeqnoUpdate = fileSeqnoUpdate;
    }
    /**
     * @return the chkRefNo
     */
    public String getChkRefNo() {
        return chkRefNo;
    }
    /**
     * @param chkRefNo the chkRefNo to set
     */
    public void setChkRefNo(String chkRefNo) {
        this.chkRefNo = chkRefNo;
    }
    /**
     * @return the refType
     */
    public String getRefType() {
        return refType;
    }
    /**
     * @param refType the refType to set
     */
    public void setRefType(String refType) {
        this.refType = refType;
    }
    /**
     * @return the zmodule
     */
    public String getZmodule() {
        return zmodule;
    }
    /**
     * @param zmodule the zmodule to set
     */
    public void setZmodule(String zmodule) {
        this.zmodule = zmodule;
    }
    /**
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }
    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }
    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    /**
     * @return the fileExt
     */
    public String getFileExt() {
        return fileExt;
    }
    /**
     * @param fileExt the fileExt to set
     */
    public void setFileExt(String fileExt) {
        this.fileExt = fileExt;
    }
    /**
     * @return the fileLen
     */
    public Long getFileLen() {
        return fileLen;
    }
    /**
     * @param fileLen the fileLen to set
     */
    public void setFileLen(Long fileLen) {
        this.fileLen = fileLen;
    }
    /**
     * @return the fileSysid
     */
    public String getFileSysid() {
        return fileSysid;
    }
    /**
     * @param fileSysid the fileSysid to set
     */
    public void setFileSysid(String fileSysid) {
        this.fileSysid = fileSysid;
    }
    /**
     * @return the delfl
     */
    public String getDelfl() {
        return delfl;
    }
    /**
     * @param delfl the delfl to set
     */
    public void setDelfl(String delfl) {
        this.delfl = delfl;
    }
    /**
     * @return the fileLenKb
     */
    public String getFileLenKb() {
        return fileLenKb;
    }
    /**
     * @param fileLenKb the fileLenKb to set
     */
    public void setFileLenKb(String fileLenKb) {
        this.fileLenKb = fileLenKb;
    }
    /**
     * @return the fileLenKbInt
     */
    public Integer getFileLenKbInt() {
        return fileLenKbInt;
    }
    /**
     * @param fileLenKbInt the fileLenKbInt to set
     */
    public void setFileLenKbInt(Integer fileLenKbInt) {
        this.fileLenKbInt = fileLenKbInt;
    }
    /**
     * @return the fileLenMb
     */
    public String getFileLenMb() {
        return fileLenMb;
    }
    /**
     * @param fileLenMb the fileLenMb to set
     */
    public void setFileLenMb(String fileLenMb) {
        this.fileLenMb = fileLenMb;
    }
    /**
     * @return the fileLenMbInt
     */
    public Integer getFileLenMbInt() {
        return fileLenMbInt;
    }
    /**
     * @param fileLenMbInt the fileLenMbInt to set
     */
    public void setFileLenMbInt(Integer fileLenMbInt) {
        this.fileLenMbInt = fileLenMbInt;
    }
    /**
     * @return the filePathLeg
     */
    public String getFilePathLeg() {
        return filePathLeg;
    }
    /**
     * @param filePathLeg the filePathLeg to set
     */
    public void setFilePathLeg(String filePathLeg) {
        this.filePathLeg = filePathLeg;
    }
    /**
     * @return the filePathLeg2
     */
    public String getFilePathLeg2() {
        return filePathLeg2;
    }
    /**
     * @param filePathLeg2 the filePathLeg2 to set
     */
    public void setFilePathLeg2(String filePathLeg2) {
        this.filePathLeg2 = filePathLeg2;
    }
    /**
     * @return the zcrname
     */
    public String getZcrname() {
        return zcrname;
    }
    /**
     * @param zcrname the zcrname to set
     */
    public void setZcrname(String zcrname) {
        this.zcrname = zcrname;
    }
    /**
     * @return the zcrsdate
     */
    public Date getZcrsdate() {
        return zcrsdate;
    }
    /**
     * @param zcrsdate the zcrsdate to set
     */
    public void setZcrsdate(Date zcrsdate) {
        this.zcrsdate = zcrsdate;
    }
    /**
     * @return the zcrstime
     */
    public String getZcrstime() {
        return zcrstime;
    }
    /**
     * @param zcrstime the zcrstime to set
     */
    public void setZcrstime(String zcrstime) {
        this.zcrstime = zcrstime;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zcrltime
     */
    public String getZcrltime() {
        return zcrltime;
    }
    /**
     * @param zcrltime the zcrltime to set
     */
    public void setZcrltime(String zcrltime) {
        this.zcrltime = zcrltime;
    }
    /**
     * @return the zudname
     */
    public String getZudname() {
        return zudname;
    }
    /**
     * @param zudname the zudname to set
     */
    public void setZudname(String zudname) {
        this.zudname = zudname;
    }
    /**
     * @return the zudsdate
     */
    public Date getZudsdate() {
        return zudsdate;
    }
    /**
     * @param zudsdate the zudsdate to set
     */
    public void setZudsdate(Date zudsdate) {
        this.zudsdate = zudsdate;
    }
    /**
     * @return the zudstime
     */
    public String getZudstime() {
        return zudstime;
    }
    /**
     * @param zudstime the zudstime to set
     */
    public void setZudstime(String zudstime) {
        this.zudstime = zudstime;
    }
    /**
     * @return the zudldate
     */
    public Date getZudldate() {
        return zudldate;
    }
    /**
     * @param zudldate the zudldate to set
     */
    public void setZudldate(Date zudldate) {
        this.zudldate = zudldate;
    }
    /**
     * @return the zudltime
     */
    public String getZudltime() {
        return zudltime;
    }
    /**
     * @param zudltime the zudltime to set
     */
    public void setZudltime(String zudltime) {
        this.zudltime = zudltime;
    }
    /**
     * @return the zonlo
     */
    public String getZonlo() {
        return zonlo;
    }
    /**
     * @param zonlo the zonlo to set
     */
    public void setZonlo(String zonlo) {
        this.zonlo = zonlo;
    }
    /**
     * @return the originalFile
     */
    public File getOriginalFile() {
        return originalFile;
    }
    /**
     * @param originalFile the originalFile to set
     */
    public void setOriginalFile(File originalFile) {
        this.originalFile = originalFile;
    }
}
