package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.iam.vo.MapsIamWordDicaryVO;

/**
 * <pre>
 * 용어사전 관리 데이터처리
 * </pre>
 *
 * @ClassName   : MapsCommWordDicaryMDAO.java
 * @Description : 용어사전 관리 데이터처를 정의.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
@Mapper("mapsIamWordDicaryMDAO")
public interface MapsIamWordDicaryMDAO {

    /**
     * 용어사전 리스트 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public List<MapsIamWordDicaryVO> selectWdDicPgList(MapsIamWordDicaryVO iamWdDicVO) throws Exception;
    
    /**
     * 용어사전 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public MapsIamWordDicaryVO selectWdDicInfo(MapsIamWordDicaryVO iamWdDicVO) throws Exception;
    
    /**
     * 용어별 언어 건수 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public int selectWdLangCnt(MapsIamWordDicaryVO iamWdDicVO) throws Exception;

    /**
     * 원본용어에 대한 용어사전 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public MapsIamWordDicaryVO selectWdDicInfoByOrginlWord(MapsIamWordDicaryVO iamWdDicVO) throws Exception;

    /**
     * 언어,용어ID에 대한 용어사전 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public MapsIamWordDicaryVO selectWdDicInfoByLangWordId(MapsIamWordDicaryVO iamWdDicVO) throws Exception;
    
    /**
     * 참조언어,용어ID에 대한 용어사전 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public MapsIamWordDicaryVO selectWdDicInfoByRefrnLangCd(MapsIamWordDicaryVO iamWdDicVO) throws Exception;
    
    /**
     * 용어사전 저장
     *
     * @param iamWdDicVO
     * @throws Exception
     */
    public void insertWdDicInfo(MapsIamWordDicaryVO iamWdDicVO) throws Exception;
        
    /**
     * 용어사전 수정
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public int updateWdDicInfo(MapsIamWordDicaryVO iamWdDicVO) throws Exception;
        
    /**
     * 용어사전 삭제
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public int deleteWdDicInfo(MapsIamWordDicaryVO iamWdDicVO) throws Exception;
    
    
    /**
     * 용어사전 팝업 리스트 조회
     *
     * @param iamWdDicVO
     * @return
     * @throws Exception
     */
    public List<MapsIamWordDicaryVO> selectWdDicPgPopList(MapsIamWordDicaryVO iamWdDicVO) throws Exception;

}
