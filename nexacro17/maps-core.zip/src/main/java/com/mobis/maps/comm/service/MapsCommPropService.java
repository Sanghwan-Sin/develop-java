package com.mobis.maps.comm.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommPropVO;

/**
 * <pre>
 * 프로퍼티 관리 서비스
 * </pre>
 *
 * @ClassName   : MapsCommPropService.java
 * @Description : 프로퍼티 관리 서비스를 정의.
 * @author DT048058
 * @since 2019. 12. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 18.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsCommPropService {
    
    /**
     * 프로퍼티 페이징리스트 조회
     *
     * @param commMsgSearchVO
     * @return
     * @throws Exception
     */
    public List<MapsCommPropVO> selectPropPgList(MapsCommPropVO commPropVO) throws Exception;

    /**
     * 프로퍼티 저장
     *
     * @param propInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiPropInfo(List<MapsCommPropVO> propInfos, LoginInfoVO loginInfo) throws Exception;

}
