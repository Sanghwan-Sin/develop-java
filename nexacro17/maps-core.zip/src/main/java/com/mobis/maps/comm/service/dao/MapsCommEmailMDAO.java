package com.mobis.maps.comm.service.dao;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.EmailSndngVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommEmailMDAO.java
 * @Description : 이메일등록(전송)
 * @author hong.minho
 * @since 2020. 4. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 13.     hong.minho     	최초 생성
 * </pre>
 */

@Mapper("mapsCommEmailMDAO")
public interface MapsCommEmailMDAO {

    /**
     * Email 등록(전송)
     *
     * @param vo - emailSn (이메일순번) 생성됨
     * @return
     * @throws Exception
     */
    void insertEmail(EmailSndngVO vo) throws Exception;


    /**
     * 첨부파일 등록(전송)
     *
     * @param vo
     * @throws Exception
     */
    void insertAttach(EmailSndngVO vo) throws Exception;
}
