package com.mobis.maps.cmmn.constants;

/**
 * <pre>
 * 암호화 메소드별 상수 정의
 * </pre>
 *
 * @ClassName   : SecureConstants.java
 * @Description : 암호화 메소드별 상수 정의
 * @author oh.dongwon
 * @since 2018. 5. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2018. 5. 18.     oh.dongwon     	최초 생성
 * </pre>
 */
public class SecureConstants {

	public static final String AES_ECB_PKCS5PADDING = "AES/ECB/PKCS5Padding";

	public static final String AES_CBC_PKCS5PADDING = "AES/CBC/PKCS5Padding";

	public static final String AES_ECB_NOPADDING = "AES/ECB/NoPadding";

	public static final String AES_CBC_NOPADDING = "AES/CBC/NoPadding";

	public static final String AES256_CIPHER_KEY_VALUE = "M0bisSecurity12#M0bisSecurity12#";
    
	public static final String AES256_CIPHER_IV_VALUE  = "2b7e151628aed2a6abf7158809cf4f3c";

	protected static final String CM_KEY_256_VALUE    = "BLUEQsiteUSE#MNSBLUEQsiteUSE#MNS";

	protected static final String CM_KEY_VALUE    = "BLUEQsiteUSE#MNS";

	protected static final String CM_IV_VALUE     = "SmartLOGIN201407";        // 128, 256 같은거 사용 함.

	protected static final String HAIMS_KEY_VALUE = "GSWBOSiteUseSjJs";

	protected static final String HAIMS_IV_VALUE  = "SmartLOGIN201411";

	protected static final String PF_KEY_VALUE    = "HKMCSALE12DOMAIN";

	protected static final String PF_IV_VALUE     = "";

	protected static final String OC_KEY_VALUE    = "BLUE&RED20160805";

	protected static final String OC_IV_VALUE     = "GSWLogin20160805";

	protected static final String DID_KEY_VALUE   = "DIDIfCarIo201610";

	protected static final String DID_IV_VALUE    = "GSWCarIoIf201610";

	protected static final String SOS_KEY_VALUE   = "SosCtiLink201705";

	protected static final String SOS_IV_VALUE    = "GswCtiLink201705";

	protected static final String VAN_KEY_VALUE   = "Rcpt20GswVanLink";

	protected static final String VAN_IV_VALUE    = "VanVhpoCset20Lnk";

	protected static final String PW_SALT_VALUE    = "GsWIfGszeSdGSEd";

	protected static final String AES256_KEY_VALUE = "603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4"; // length 64

	protected static final String AES256_IV_VALUE  = "000102030405060708090A0B0C0D0E0F"; // length 32

	protected static final String ARIA_KEY_VALUE   = "000102030405060708090A0B0C0D0E0F"; // length 32

	protected static final String TDES_KEY_VALUE   = "6e7ae0e33251ec91a7fb62c4b97c1a646d70ab016ba846b6"; //length 48

	protected static final String TDES_IV_VALUE    = "0001020304050607"; //16

	protected static final String SHA256_SALT_VALUE = "603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4"; //length 64

	public static final int SHA256_ITERATIOS_VALUE  = 100;
}
