package com.mobis.maps.comm.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.exception.ExcelBindingException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommMsgService;
import com.mobis.maps.comm.vo.MapsCommMsgVO;

/**
 * <pre>
 * 메세지 관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommMsgController.java
 * @Description : 메세지 관리에 대한 컨트롤러 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 27.   Sin Sanghwan     최초 생성
 * </pre>
 */
@Controller
public class MapsCommMsgController extends HController {

    @Resource(name = "mapsCommMsgService")
    private MapsCommMsgService mapsCommMsgService;
    
    /**
     * 메세지 페이징리스트 조회
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectMsgPgList.do")
    public NexacroResult selectMsgPgList(
            @ParamDataSet(name="dsInput") MapsCommMsgVO commMsgVO
            , NexacroResult result) throws Exception {
        
        List<MapsCommMsgVO> msgInfos = mapsCommMsgService.selectMsgPgList(commMsgVO);
        
        result.addDataSet("dsOutput", msgInfos);
        
        return result;
    }

    /**
     * 메세지 저장
     *
     * @param msgInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/multiMsgInfo.do")
    public NexacroResult multiMsgInfo(
            @ParamDataSet(name="dsInput") List<MapsCommMsgVO> msgInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsCommMsgService.multiMsgInfo(msgInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 메세지 액셀다운로드
     *
     * @param commMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectMsgListExcelDown.do")
    public NexacroResult selectMsgListExcelDown(
            @ParamDataSet(name="dsInput") MapsCommMsgVO commMsgVO
            , NexacroResult result) throws Exception {

        commMsgVO.setExcelDwnlYn(MapsConstants.YN_YES);
        commMsgVO.setPgNum(1);
        commMsgVO.setPgSize(commMsgVO.getTotMaxCnt());
        
        List<MapsCommMsgVO> msgInfos = mapsCommMsgService.selectMsgPgList(commMsgVO);

        result.addDataSet("dsOutput", msgInfos);

        return result;
    }
    
    /**
     * 메세지 업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectMsgListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectMsgListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<MapsCommMsgVO> msgInfos = new ArrayList<MapsCommMsgVO>();

        List<String[]> lstCellVal = ExcelUtil.importExcelToList(request, 1, 8, 0, "N");
        
        if (lstCellVal != null && !lstCellVal.isEmpty()) {

            for (String[] arrCellVal : lstCellVal) {

                MapsCommMsgVO commMsgVO = new MapsCommMsgVO();
                
                commMsgVO.setMsgCd(arrCellVal[4]);
                commMsgVO.setMsgLang(arrCellVal[6]);
                commMsgVO.setMsgNm(arrCellVal[7]);
                commMsgVO.setRefrnMsgLang(MapsConstants.DFLT_LOCALE.toString());
                
                if (StringUtils.isNotBlank(commMsgVO.getMsgCd())) {

                    MapsCommMsgVO refrnMsgVO = mapsCommMsgService.selectMsgInfoByRefrnLang(commMsgVO);
                    if (refrnMsgVO == null) {
                        throw new ExcelBindingException(messageSource, "EC00000011", new String[]{"Message Code(=" + commMsgVO.getMsgCd() + ")"}, null);
                    }
                    commMsgVO.setMsgSe(refrnMsgVO.getMsgSe());
                    commMsgVO.setMsgSys(refrnMsgVO.getMsgSys());
                    commMsgVO.setRefrnMsgNm(refrnMsgVO.getMsgNm());
                } else {
                    commMsgVO.setMsgSe(arrCellVal[1]);
                    commMsgVO.setMsgSys(arrCellVal[3]);
                }

                msgInfos.add(commMsgVO);
            }
        }

        result.addDataSet("dsOutput", msgInfos);

        return result;
    }
}
