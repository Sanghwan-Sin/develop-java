package com.mobis.maps.comm.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommDbLoggingService;
import com.mobis.maps.comm.vo.MapsCommDbLoggingEventPropVO;
import com.mobis.maps.comm.vo.MapsCommDbLoggingEventVO;

/**
 * <pre>
 * DB Logging 컨트롤러 정의
 * </pre>
 *
 * @ClassName   : MapsCommDbLoggingController.java
 * @Description : DB Logging에 대한 컨트롤러를 정의.
 * @author DT048058
 * @since 2019. 12. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 30.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommDbLoggingController extends HController {

    @Resource(name = "mapsCommDbLoggingService")
    private MapsCommDbLoggingService mapsCommDbLoggingService;
    
    /**
     * DB Logging Event 리스트 조회
     *
     * @param dbLoggingEventVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectDbLoggingEventPgList.do")
    public NexacroResult selectDbLoggingEventPgList(
            @ParamDataSet(name="dsInput") MapsCommDbLoggingEventVO dbLoggingEventVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommDbLoggingEventVO>  dbLoggingEvents = mapsCommDbLoggingService.selectDbLoggingEventPgList(dbLoggingEventVO, loginInfo);
        
        result.addDataSet("dsOutput", dbLoggingEvents);
        
        return result;
    }
    
    /**
     * DB Logging Event Property 리스트 조회
     *
     * @param dbLoggingEventVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectDbLoggingEventPropList.do")
    public NexacroResult selectDbLoggingEventPropList(
            @ParamDataSet(name="dsInput") MapsCommDbLoggingEventVO dbLoggingEventVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommDbLoggingEventPropVO>  dbLoggingEventProps = mapsCommDbLoggingService.selectDbLoggingEventPropList(dbLoggingEventVO, loginInfo);
        
        result.addDataSet("dsOutput", dbLoggingEventProps);
        
        return result;
    }
}
