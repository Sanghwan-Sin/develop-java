package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;
import able.com.vo.HMap;

import com.mobis.maps.iam.vo.MapsIamFnctEstnUrlVO;
import com.mobis.maps.iam.vo.MapsIamFnctVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;

/**
 * <pre>
 * Function관리 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsIamFnctMDAO.java
 * @Description : Function관리 데이터처를 정의.
 * @author DT048657
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     DT048657     	최초 생성
 * </pre>
 */
@Mapper("mapsIamFnctMDAO")
public interface MapsIamFnctMDAO {

    /**
     * Function관리 페이징 리스트 조회
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public List<MapsIamFnctVO> selectFnctPgList(MapsIamFnctVO iamFnctVO) throws Exception;
    
    /**
     * Function관리 조회
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public MapsIamFnctVO selectFnctInfo(MapsIamFnctVO iamFnctVO) throws Exception;
    
    /**
     * Function관리 조회(Function URL 중복확인)
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public MapsIamFnctVO selectFnctInfoByFnctUrl(MapsIamFnctVO iamFnctVO) throws Exception;
    
    /**
     * Function관리 조회(Scrieen ID 중복확인)
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public MapsIamFnctVO selectFnctInfoByScrinId(MapsIamFnctVO iamFnctVO) throws Exception;

    /**
     * 화면정보 조회
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public MapsIamScreenVO selectScrinInfo(MapsIamFnctVO iamFnctVO) throws Exception;

    /**
     * 다음 Function관리코드 조회
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public HMap selectNextFnctCd(MapsIamFnctVO iamFnctVO) throws Exception;
        
    /**
     * Function관리 저장
     *
     * @param iamFnctVO
     * @throws Exception
     */
    public void insertFnctInfo(MapsIamFnctVO iamFnctVO) throws Exception;
        
    /**
     * Function관리 수정
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public int updateFnctInfo(MapsIamFnctVO iamFnctVO) throws Exception;
        
    /**
     * Function관리 삭제
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public int deleteFnctInfo(MapsIamFnctVO iamFnctVO) throws Exception;
     
    /**
     * 화면 Function관리 페이징 리스트 조회
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public List<MapsIamFnctVO> selectScreenFnctPgList(MapsIamFnctVO iamFnctVO) throws Exception;
    
    /**
     * 화면 Function관리 리스트 조회
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public List<MapsIamFnctVO> selectScreenFnctList(MapsIamFnctVO iamFnctVO) throws Exception;
    
    /**
     * 화면 Function관리 저장
     *
     * @param iamFnctVO
     * @throws Exception
     */
    public void insertScreenFnctInfo(MapsIamFnctVO iamFnctVO) throws Exception;
        
    /**
     * 화면 Function관리 수정
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public int updateScreenFnctInfo(MapsIamFnctVO iamFnctVO) throws Exception;

        
    /**
     * 화면 Function관리 삭제
     *
     * @param iamFnctVO
     * @return
     * @throws Exception
     */
    public int deleteScreenFnctInfo(MapsIamFnctVO iamFnctVO) throws Exception;

    /**
     * 기능확장URL 리스트 조회
     *
     * @param iamFnctEstnUrlVO
     * @return
     * @throws Exception
     */
    public List<MapsIamFnctEstnUrlVO> selectFnctEstnUrlList(MapsIamFnctEstnUrlVO iamFnctEstnUrlVO) throws Exception;

    /**
     * 기능확장URL 조회
     *
     * @param iamFnctEstnUrlVO
     * @return
     * @throws Exception
     */
    public MapsIamFnctEstnUrlVO selectFnctEstnUrl(MapsIamFnctEstnUrlVO iamFnctEstnUrlVO) throws Exception;

    /**
     * 기능확장URL 등록
     *
     * @param iamFnctEstnUrlVO
     * @throws Exception
     */
    public void insertFnctEstnUrl(MapsIamFnctEstnUrlVO iamFnctEstnUrlVO) throws Exception;

    /**
     * 기능확장URL 삭제
     *
     * @param iamFnctEstnUrlVO
     * @throws Exception
     */
    public void deleteFnctEstnUrl(MapsIamFnctEstnUrlVO iamFnctEstnUrlVO) throws Exception;
}
