package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommSapRfcBassInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIpttInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrFieldVO;

/**
 * <pre>
 * RFC호출 데이터처리
 * </pre>
 *
 * @ClassName : MapsCommSapMDAO.java
 * @Description : RFC호출 데이터처리를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 26.     Sin Sanghwan     	최초 생성
 *               </pre>
 */
@Mapper("mapsCommSapMDAO")
public interface MapsCommSapMDAO {
    
    /**
     * RFC 정보를 조회한다
     *
     * @param commSapRfcBassInfoVO 
     * @return
     * @throws Exception
     */
    public MapsCommSapRfcBassInfoVO selectAspRfcBassInfo(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO) throws Exception;

    /**
     * RFC 입출력정보리스트를 조회한다
     *
     * @param commSapRfcIpttInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsCommSapRfcIpttInfoVO> selectAspRfcIpttInfoList(MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO) throws Exception;

    /**
     * RFC 구조체리스트를 조회한다
     *
     * @param commSapRfcIpttInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsCommSapRfcStrctrFieldVO> selectAspRfcStrctrFieldList(MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO) throws Exception;
}