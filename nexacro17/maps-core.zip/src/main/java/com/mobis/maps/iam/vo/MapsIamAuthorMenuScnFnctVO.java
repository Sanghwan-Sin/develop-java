package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 메뉴화면기능관리 항목
 * </pre>
 *
 * @ClassName   : MapsIamAuthorMenuScnFnctVO.java
 * @Description : 메뉴화면기능관리에 대한 항목을 정의
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
public class MapsIamAuthorMenuScnFnctVO extends MapsIamFnctVO {
    /* 조회조건 */
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 권한ID */
    private String authorId;
    /* 데이터항목 */
    /** 팝업화면ID */
    private String popupScrinId;
    /** 팝업화면명 */
    private String popupScrinNm;
    /** 팝업화면코드 */
    private String popupScrinCd;
    /* 인증관리 */
    /** 인증여부 */
    private String authorYn;
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the authorId
     */
    public String getAuthorId() {
        return authorId;
    }
    /**
     * @param authorId the authorId to set
     */
    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }
    /**
     * @return the popupScrinId
     */
    public String getPopupScrinId() {
        return popupScrinId;
    }
    /**
     * @param popupScrinId the popupScrinId to set
     */
    public void setPopupScrinId(String popupScrinId) {
        this.popupScrinId = popupScrinId;
    }
    /**
     * @return the popupScrinNm
     */
    public String getPopupScrinNm() {
        return popupScrinNm;
    }
    /**
     * @param popupScrinNm the popupScrinNm to set
     */
    public void setPopupScrinNm(String popupScrinNm) {
        this.popupScrinNm = popupScrinNm;
    }
    /**
     * @return the popupScrinCd
     */
    public String getPopupScrinCd() {
        return popupScrinCd;
    }
    /**
     * @param popupScrinCd the popupScrinCd to set
     */
    public void setPopupScrinCd(String popupScrinCd) {
        this.popupScrinCd = popupScrinCd;
    }
    /**
     * @return the authorYn
     */
    public String getAuthorYn() {
        return authorYn;
    }
    /**
     * @param authorYn the authorYn to set
     */
    public void setAuthorYn(String authorYn) {
        this.authorYn = authorYn;
    }
}
