package com.mobis.maps.comm.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommDbLoggingEventPropVO;
import com.mobis.maps.comm.vo.MapsCommDbLoggingEventVO;

/**
 * <pre>
 * DB Logging 서비스 정의
 * </pre>
 *
 * @ClassName   : MapsCommLoggingService.java
 * @Description : DB Logging에 대한 서비스를 정의.
 * @author DT048058
 * @since 2019. 12. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 30.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsCommDbLoggingService {

    /**
     * DB Logging Event 페이징 리스트 조회
     *
     * @param dbLoggingEventVO
     * @return
     * @throws Exception
     */
    public List<MapsCommDbLoggingEventVO> selectDbLoggingEventPgList(MapsCommDbLoggingEventVO dbLoggingEventVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * DB Logging Event Property 리스트 조회
     *
     * @param dbLoggingEventVO
     * @return
     * @throws Exception
     */
    public List<MapsCommDbLoggingEventPropVO> selectDbLoggingEventPropList(MapsCommDbLoggingEventVO dbLoggingEventVO, LoginInfoVO loginInfo) throws Exception;
}
