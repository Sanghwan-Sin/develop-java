package com.mobis.maps.comm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcFileChkVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 3. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 3.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommSapAtchFileChkVO extends MapsCommSapRfcIfCommVO {
    /** File System ID */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_FILE_SYSID" )
    private String fileSysid;
    /** File Server ID */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_FSCODE" )
    private String fscode;
    /** Reference Number */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REF_NO" )
    private String refNo;
    /** File ID */
    @MapsRfcMappper( targetName="IT_ATTACH", ipttSe="E", fieldKey="FILE_SEQNO" )
    private String fileSeqno;
    /** File Path (Legacy) */
    @MapsRfcMappper( targetName="IT_ATTACH", ipttSe="E", fieldKey="FILE_PATH_LEG" )
    private String filePathLeg;
    /** Upload File */
    @MapsRfcMappper( targetName="IT_ATTACH", ipttSe="E", fieldKey="FILE_NAME" )
    private String fileName;
    /** File Length (Byte) */
    @MapsRfcMappper( targetName="IT_ATTACH", ipttSe="E", fieldKey="FILE_LEN" )
    private Integer fileLen;
    /**
     * @return the fileSysid
     */
    public String getFileSysid() {
        return fileSysid;
    }
    /**
     * @param fileSysid the fileSysid to set
     */
    public void setFileSysid(String fileSysid) {
        this.fileSysid = fileSysid;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the fileSeqno
     */
    public String getFileSeqno() {
        return fileSeqno;
    }
    /**
     * @param fileSeqno the fileSeqno to set
     */
    public void setFileSeqno(String fileSeqno) {
        this.fileSeqno = fileSeqno;
    }
    /**
     * @return the filePathLeg
     */
    public String getFilePathLeg() {
        return filePathLeg;
    }
    /**
     * @param filePathLeg the filePathLeg to set
     */
    public void setFilePathLeg(String filePathLeg) {
        this.filePathLeg = filePathLeg;
    }
    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }
    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    /**
     * @return the fileLen
     */
    public Integer getFileLen() {
        return fileLen;
    }
    /**
     * @param fileLen the fileLen to set
     */
    public void setFileLen(Integer fileLen) {
        this.fileLen = fileLen;
    }
    
}
