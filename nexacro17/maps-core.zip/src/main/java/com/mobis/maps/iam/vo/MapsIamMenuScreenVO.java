package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 메뉴화면관리 항목
 * </pre>
 *
 * @ClassName   : MapsCommMenuScreenVO.java
 * @Description : 메뉴화면관리 항목을 정의
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
public class MapsIamMenuScreenVO extends MapsIamCommVO {
    
    /* 데이터항목 */
    /** 메뉴화면관리ID */
    private String menuScrinId;
    /** 메뉴ID */
    private String menuId;
    /** 화면ID */
    private String scrinId;
    /** 화면순서 */
    private String scrinOrdr;

    /* 화면마스터항목 */
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 단어ID */
    private String wordId;
    /** 화면명 */
    private String scrinNm;
    /** 약어1 */
    private String abbrevWord1;
    /** 약어2 */
    private String abbrevWord2;
    /** 약어3 */
    private String abbrevWord3;
    /** 약어4 */
    private String abbrevWord4;
    /** 약어5 */
    private String abbrevWord5;
    /** 원본용어 */
    private String orginlWord;
    /** 약어사용코드 */
    private String abbrevWordUseCd;
    /** 화면코드 */
    private String scrinCd;
    /** 화면별칭ID */
    private String scrinAliasId;
    /** 화면URL */
    private String scrinUrl;
    /** 화면설명 */
    private String scrinDc;
    /** DRM화면여부 */
    private String drmScrinYn;
    /** DRM파일여부 */
    private String drmFileYn;
    /** 팝업여부 */
    private String popupYn;
    /** 개인정보사용여부 */
    private String indvdlinfoUseYn;
    /** 표시여부 */
    private String indictYn;
    /** 사용여부 */
    private String useYn;
    /** 삭제여부 */
    private String delYn;
    
    /**
     * @return the menuScrinId
     */
    public String getMenuScrinId() {
        return menuScrinId;
    }
    /**
     * @param menuScrinId the menuScrinId to set
     */
    public void setMenuScrinId(String menuScrinId) {
        this.menuScrinId = menuScrinId;
    }
    /**
     * @return the menuId
     */
    public String getMenuId() {
        return menuId;
    }
    /**
     * @param menuId the menuId to set
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the scrinOrdr
     */
    public String getScrinOrdr() {
        return scrinOrdr;
    }
    /**
     * @param scrinOrdr the scrinOrdr to set
     */
    public void setScrinOrdr(String scrinOrdr) {
        this.scrinOrdr = scrinOrdr;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the wordId
     */
    public String getWordId() {
        return wordId;
    }
    /**
     * @param wordId the wordId to set
     */
    public void setWordId(String wordId) {
        this.wordId = wordId;
    }
    /**
     * @return the scrinNm
     */
    public String getScrinNm() {
        return scrinNm;
    }
    /**
     * @param scrinNm the scrinNm to set
     */
    public void setScrinNm(String scrinNm) {
        this.scrinNm = scrinNm;
    }
    /**
     * @return the abbrevWord1
     */
    public String getAbbrevWord1() {
        return abbrevWord1;
    }
    /**
     * @param abbrevWord1 the abbrevWord1 to set
     */
    public void setAbbrevWord1(String abbrevWord1) {
        this.abbrevWord1 = abbrevWord1;
    }
    /**
     * @return the abbrevWord2
     */
    public String getAbbrevWord2() {
        return abbrevWord2;
    }
    /**
     * @param abbrevWord2 the abbrevWord2 to set
     */
    public void setAbbrevWord2(String abbrevWord2) {
        this.abbrevWord2 = abbrevWord2;
    }
    /**
     * @return the abbrevWord3
     */
    public String getAbbrevWord3() {
        return abbrevWord3;
    }
    /**
     * @param abbrevWord3 the abbrevWord3 to set
     */
    public void setAbbrevWord3(String abbrevWord3) {
        this.abbrevWord3 = abbrevWord3;
    }
    /**
     * @return the abbrevWord4
     */
    public String getAbbrevWord4() {
        return abbrevWord4;
    }
    /**
     * @param abbrevWord4 the abbrevWord4 to set
     */
    public void setAbbrevWord4(String abbrevWord4) {
        this.abbrevWord4 = abbrevWord4;
    }
    /**
     * @return the abbrevWord5
     */
    public String getAbbrevWord5() {
        return abbrevWord5;
    }
    /**
     * @param abbrevWord5 the abbrevWord5 to set
     */
    public void setAbbrevWord5(String abbrevWord5) {
        this.abbrevWord5 = abbrevWord5;
    }
    /**
     * @return the orginlWord
     */
    public String getOrginlWord() {
        return orginlWord;
    }
    /**
     * @param orginlWord the orginlWord to set
     */
    public void setOrginlWord(String orginlWord) {
        this.orginlWord = orginlWord;
    }
    /**
     * @return the abbrevWordUseCd
     */
    public String getAbbrevWordUseCd() {
        return abbrevWordUseCd;
    }
    /**
     * @param abbrevWordUseCd the abbrevWordUseCd to set
     */
    public void setAbbrevWordUseCd(String abbrevWordUseCd) {
        this.abbrevWordUseCd = abbrevWordUseCd;
    }
    /**
     * @return the scrinCd
     */
    public String getScrinCd() {
        return scrinCd;
    }
    /**
     * @param scrinCd the scrinCd to set
     */
    public void setScrinCd(String scrinCd) {
        this.scrinCd = scrinCd;
    }
    /**
     * @return the scrinAliasId
     */
    public String getScrinAliasId() {
        return scrinAliasId;
    }
    /**
     * @param scrinAliasId the scrinAliasId to set
     */
    public void setScrinAliasId(String scrinAliasId) {
        this.scrinAliasId = scrinAliasId;
    }
    /**
     * @return the scrinUrl
     */
    public String getScrinUrl() {
        return scrinUrl;
    }
    /**
     * @param scrinUrl the scrinUrl to set
     */
    public void setScrinUrl(String scrinUrl) {
        this.scrinUrl = scrinUrl;
    }
    /**
     * @return the scrinDc
     */
    public String getScrinDc() {
        return scrinDc;
    }
    /**
     * @param scrinDc the scrinDc to set
     */
    public void setScrinDc(String scrinDc) {
        this.scrinDc = scrinDc;
    }
    /**
     * @return the drmScrinYn
     */
    public String getDrmScrinYn() {
        return drmScrinYn;
    }
    /**
     * @param drmScrinYn the drmScrinYn to set
     */
    public void setDrmScrinYn(String drmScrinYn) {
        this.drmScrinYn = drmScrinYn;
    }
    /**
     * @return the drmFileYn
     */
    public String getDrmFileYn() {
        return drmFileYn;
    }
    /**
     * @param drmFileYn the drmFileYn to set
     */
    public void setDrmFileYn(String drmFileYn) {
        this.drmFileYn = drmFileYn;
    }
    /**
     * @return the popupYn
     */
    public String getPopupYn() {
        return popupYn;
    }
    /**
     * @param popupYn the popupYn to set
     */
    public void setPopupYn(String popupYn) {
        this.popupYn = popupYn;
    }
    /**
     * @return the indvdlinfoUseYn
     */
    public String getIndvdlinfoUseYn() {
        return indvdlinfoUseYn;
    }
    /**
     * @param indvdlinfoUseYn the indvdlinfoUseYn to set
     */
    public void setIndvdlinfoUseYn(String indvdlinfoUseYn) {
        this.indvdlinfoUseYn = indvdlinfoUseYn;
    }
    /**
     * @return the indictYn
     */
    public String getIndictYn() {
        return indictYn;
    }
    /**
     * @param indictYn the indictYn to set
     */
    public void setIndictYn(String indictYn) {
        this.indictYn = indictYn;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }
    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    
}
