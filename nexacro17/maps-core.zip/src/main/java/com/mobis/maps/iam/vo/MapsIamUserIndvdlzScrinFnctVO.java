package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 사용자개별 화면기능 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserIndvdlzScrinFnctVO.java
 * @Description : 사용자개별 화면기능에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 23.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserIndvdlzScrinFnctVO extends MapsIamUserScrinFnctVO {
    /** 권한여부 */
    private String authorYn;

    /**
     * @return the authorYn
     */
    public String getAuthorYn() {
        return authorYn;
    }
    /**
     * @param authorYn the authorYn to set
     */
    public void setAuthorYn(String authorYn) {
        this.authorYn = authorYn;
    }
}
