package com.mobis.maps.smpl.vo;

import java.util.List;

import com.mobis.maps.cmmn.vo.MapsAtchFileVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplFileUpVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsSmplFileUpVO {

    private MapsAtchFileVO atchFileVO;
    
    private List<MapsAtchFileVO> atchFiles;
    
    /**
     * @return the atchFileVO
     */
    public MapsAtchFileVO getAtchFileVO() {
        return atchFileVO;
    }
    /**
     * @param atchFileVO the atchFileVO to set
     */
    public void setAtchFileVO(MapsAtchFileVO atchFileVO) {
        this.atchFileVO = atchFileVO;
    }
    /**
     * @return the atchFiles
     */
    public List<MapsAtchFileVO> getAtchFiles() {
        return atchFiles;
    }
    /**
     * @param atchFiles the atchFiles to set
     */
    public void setAtchFiles(List<MapsAtchFileVO> atchFiles) {
        this.atchFiles = atchFiles;
    }
}
