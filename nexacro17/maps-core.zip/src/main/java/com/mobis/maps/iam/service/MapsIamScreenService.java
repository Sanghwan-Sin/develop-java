package com.mobis.maps.iam.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamFnctVO;
import com.mobis.maps.iam.vo.MapsIamScreenCompnVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;
import com.mobis.maps.iam.vo.MapsIamScrinUrlVO;
import com.mobis.maps.iam.vo.MapsIamWordDicaryVO;

/**
 * <pre>
 * 화면관리 서비스
 * </pre>
 *
 * @ClassName   : MapsIamScreenService.java
 * @Description : 화면관리 서비스를 정의.
 * @author DT048657
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     DT048657     	최초 생성
 * </pre>
 */
public interface MapsIamScreenService {

    /**
     * 화면관리 리스트 조회
     *
     * @param iamScreenVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScreenVO> selectScreenPgList(MapsIamScreenVO iamScreenVO) throws Exception;
    
    /**
     * 화면정보 조회
     *
     * @param iamScreenVO
     * @return
     * @throws Exception
     */
    public MapsIamScreenVO selectScrinInfo(MapsIamScreenVO iamScreenVO) throws Exception;

    /**
     * 화면관리 등록
     *
     * @param ScreenInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiScreenInfo(List<MapsIamScreenVO> screenInfos, LoginInfoVO loginInfo) throws Exception;

    /**
     * 화면관리 팝업 리스트 조회
     *
     * @param iamScreenVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScreenVO> selectScreenPgPopList(MapsIamScreenVO iamScreenVO) throws Exception;

    /**
     * 화면컴포넌트관리 페이징 리스트 조회
     *
     * @param iamScreenCompnVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScreenCompnVO> selectScreenCompnPgList(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception;

    /**
     * 화면컴포넌트관리 리스트 조회
     *
     * @param iamScreenCompnVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScreenCompnVO> selectScreenCompnList(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception;

    /**
     * 화면컴포넌트 용어사전조회
     *
     * @param iamScreenCompnVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsIamWordDicaryVO selectScreenCompnWdDic(MapsIamScreenCompnVO iamScreenCompnVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 화면컴포넌트 등록
     *
     * @param screenCompnInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiScreenCompnInfo(List<MapsIamScreenCompnVO> screenCompnInfos, LoginInfoVO loginInfo) throws Exception;

    /**
     * Function관리 페이징 리스트 조회
     *
     * @param commFnctVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamFnctVO> selectScreenFnctPgList(MapsIamFnctVO iamFnctVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * Function관리 리스트 조회
     *
     * @param commFnctVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamFnctVO> selectScreenFnctList(MapsIamFnctVO iamFnctVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * Function관리 등록
     *
     * @param screenFnctInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiScreenFnctInfo(List<MapsIamFnctVO> screenFnctInfos, LoginInfoVO loginInfo) throws Exception;

    /**
     * 화면URL관리 리스트 조회
     *
     * @param commFnctVO
     * @return
     * @throws Exception
     */
    public List<MapsIamScrinUrlVO> selectScrinUrlList(MapsIamScrinUrlVO iamScrinUrlVO) throws Exception;

    /**
     * 화면URL관리 등록
     *
     * @param scrinUrls
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiScrinUrlInfo(List<MapsIamScrinUrlVO> scrinUrls, LoginInfoVO loginInfo) throws Exception;

}
