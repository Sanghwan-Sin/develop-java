package com.mobis.maps.iam.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.service.HService;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.secure.SecureUtils;
import com.mobis.maps.cmmn.util.FileUploadUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.util.ValidatorUtil;
import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.comm.constants.MapsCommEmailTmplat;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommCodeService;
import com.mobis.maps.comm.service.MapsCommEmailService;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.comm.vo.EmailSndngVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamAuthorService;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.service.MapsIamUserBassInfoService;
import com.mobis.maps.iam.service.MapsIamUserService;
import com.mobis.maps.iam.service.dao.MapsIamUserMDAO;
import com.mobis.maps.iam.util.MapsIamUserExcelUpldUtil;
import com.mobis.maps.iam.util.MapsIamUtil;
import com.mobis.maps.iam.util.MapsIamValidatorUtil;
import com.mobis.maps.iam.vo.MapsIamLoginHistVO;
import com.mobis.maps.iam.vo.MapsIamPlusPwdArsCrtfcHistVO;
import com.mobis.maps.iam.vo.MapsIamUserAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserExcelUpldVO;
import com.mobis.maps.iam.vo.MapsIamUserIndvdlzMenuVO;
import com.mobis.maps.iam.vo.MapsIamUserIndvdlzScrinFnctVO;
import com.mobis.maps.iam.vo.MapsIamUserLangVO;
import com.mobis.maps.iam.vo.MapsIamUserMenuVO;
import com.mobis.maps.iam.vo.MapsIamUserPermIpVO;
import com.mobis.maps.iam.vo.MapsIamUserPwdChghstVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinConectHistVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinFnctVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 사용자관리 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamUserServiceImpl.java
 * @Description : 사용자관리에 대한 서비스를 구현.
 * @author DT048058
 * @since 2020. 3. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 19.     DT048058       최초 생성
 * </pre>
 */
@Service("mapsIamUserService")
public class MapsIamUserServiceImpl extends HService implements MapsIamUserService {

    @Resource(name = "mapsCommCodeService")
    private MapsCommCodeService mapsCommCodeService;

    @Resource(name = "mapsCommFileService")
    private MapsCommFileService mapsCommFileService;
    
    @Resource(name = "mapsCommEmailService")
    private MapsCommEmailService mapsCommEmailService;

    @Resource(name = "mapsIamAuthorService")
    private MapsIamAuthorService mapsIamAuthorService;
    
    @Resource(name = "mapsIamMobisUserService")
    MapsIamMobisUserService mapsIamMobisUserService;
    
    @Resource(name = "mapsIamUserBassInfoService")
    private MapsIamUserBassInfoService mapsIamUserBassInfoService;
    
    @Resource(name = "mapsIamUserMDAO")
    private MapsIamUserMDAO mapsIamUserMDAO;
    
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserPgList(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserVO> selectUserPgList(MapsIamUserVO iamUserVO
            , LoginInfoVO loginInfo) throws Exception {

        iamUserVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        if (StringUtils.isBlank(iamUserVO.getOrgnztSeCd())) {
            MapsIamUtil.addOrgnztSeCd(iamUserVO.getSysSeCd(), iamUserVO, loginInfo);
        }
        if (StringUtils.isBlank(iamUserVO.getOrgnztCd())) {
            MapsIamUtil.addOrgnztCd(iamUserVO, loginInfo, mapsIamMobisUserService);
        }
        if (StringUtils.isBlank(iamUserVO.getAcntTyCd())) {
            MapsIamUtil.addAcntTyCd(iamUserVO, loginInfo);
        }

        // 암호만료일자 정보 설정
        iamUserVO.setPwdChageCyclDayCnt(selectGetPropPwdChageCyclDayCnt());
        // 암호실패최대건수 정보 설정
        selectSetPropPwdErrorMaxCo(iamUserVO);
        
        List<MapsIamUserVO> userInfos = mapsIamUserMDAO.selectUserPgList(iamUserVO);
        
        return userInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectNormalUserPgList(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserVO> selectNormalUserPgList(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {

        iamUserVO.setSysSeCd(loginInfo.getSysSeCd());
        iamUserVO.setOrgnztSeCd(loginInfo.getOrgnztSeCd());
        iamUserVO.setBsnOrgnztCd(loginInfo.getBsnOrgnztCd());
        MapsIamUtil.addOrgnztCd(iamUserVO, loginInfo, mapsIamMobisUserService);
        if (MapsConstants.ORGNZT_SE_CD_DIRECT_DEALER.equals(loginInfo.getOrgnztSeCd())) {
            iamUserVO.setDealerCd(loginInfo.getDealerCd());
        }
        iamUserVO.setAcntTyCd(MapsIamConstants.ACCOUNT_TYPE_CD_NOMAL);
        iamUserVO.setDelYn(MapsConstants.YN_NO);
        iamUserVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserVO.setRfcPcClient(RfcSapSys.PC.getClient());

        // 암호만료일자 정보 설정
        iamUserVO.setPwdChageCyclDayCnt(selectGetPropPwdChageCyclDayCnt());
        // 암호실패최대건수 정보 설정
        selectSetPropPwdErrorMaxCo(iamUserVO);
        
        List<MapsIamUserVO> userInfos = mapsIamUserMDAO.selectUserPgList(iamUserVO);
        
        return userInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectGetPropInitlUserPwd()
     */
    @Override
    public String selectGetPropInitlUserPwd(String usrId ,String sysSeCd) throws MapsBizException {
        /*
        String userPwd = PropertiesUtil.getDbValue(MapsIamConstants.DBPROP_KEY_INITL_USER_PWD);
        if (StringUtils.isBlank(userPwd)) {
            throw new MapsBizException(messageSource, "EC00000001", new String[]{"User Password"}, null);
        }*/
        // PDA 인경우 MAPS2020 8 자리
        if (StringUtils.equals(sysSeCd, MapsConstants.SYS_SE_CD_PDA)) {
            return MapsIamConstants.INITIAL_PW_PDA;
        } else {
            // 그 이외의 경우는 a# + 사용자계정
            return MapsIamConstants.INITIAL_PW_PREFIX + usrId;
        }
        
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectGetPropPwdChageCyclDayCnt()
     */
    @Override
    public int selectGetPropPwdChageCyclDayCnt() {

        String pwdChageCyclDayCnt = PropertiesUtil.getDbValue(MapsIamConstants.DBPROP_KEY_PWD_CHAGE_CYCL_DAY_CNT);
        if (NumberUtils.isNumber(pwdChageCyclDayCnt)) {
            return Integer.parseInt(pwdChageCyclDayCnt);
        }
        return MapsIamConstants.PWD_CHAGE_CYCL_DAY_CNT;
    }

    /**
     * 프로퍼티 암호실패최대건수 설정
     *
     * @param iamUserVO
     */
    private void selectSetPropPwdErrorMaxCo(MapsIamUserVO iamUserVO) {
        String pwdErrorMaxCo = PropertiesUtil.getDbValue(MapsIamConstants.DBPROP_KEY_PWD_ERROR_MAX_CO);
        if (StringUtils.isNumeric(pwdErrorMaxCo)) {
            iamUserVO.setPwdErrorMaxCo(Integer.parseInt(pwdErrorMaxCo));
        }
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserDetail(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsIamUserVO selectUserDetail(MapsIamUserVO iamUserVO
            , LoginInfoVO loginInfo) throws Exception {

        iamUserVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        MapsIamUserVO iamUserInfo = mapsIamUserMDAO.selectUser(iamUserVO);
        
        return iamUserInfo;
    }
    

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUser(java.lang.String)
     */
    @Override
    public MapsIamUserVO selectUser(String userSeqId) throws Exception {
        
        MapsIamUserVO reqIamUserVO = new  MapsIamUserVO();
        reqIamUserVO.setUserSeqId(userSeqId);
        
        return mapsIamUserMDAO.selectUser(reqIamUserVO);
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#multiUser(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiUser(List<MapsIamUserVO> iamUsers, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        for (MapsIamUserVO iamUserVO: iamUsers) {

            int rowType = iamUserVO.getRowType();
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }
            
            switch (rowType) {
                case DataSet.ROW_TYPE_INSERTED:
                    /* 사용자정보 */
                    String orgnztSeCd = iamUserVO.getOrgnztSeCd();

                    // 계정ID 채번 대상 조직구분코드 프로퍼티 취득
                    boolean isAutoUserId = MapsIamValidatorUtil.isAutoCountUserId(orgnztSeCd);
                    /* 사용자 등록정보 정합성체크 */
                    insertValidateUser(iamUserVO, isAutoUserId, loginInfo);
                    /* 사용자 등록 */
                    if (StringUtils.equals(iamUserVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
                        // 사용자기본ID가 사용자ID로 등록이 안된 경우 사용자기본ID를 사용
                        String newUserSeqId = mapsIamUserMDAO.selectUserSeqIdByUserBassId(iamUserVO);
                        if (StringUtils.isBlank(newUserSeqId)) {
                            iamUserVO.setUserId(iamUserVO.getUserBassId());
                        } else  if (isAutoUserId) {
                            // 계정ID 자동 채번
                            String newUserId = mapsIamUserBassInfoService.insertUserIdSeq(iamUserVO, loginInfo);
                            iamUserVO.setUserId(newUserId);
                        }
                    }
                    insertUser(iamUserVO, loginInfo);

                    /* 사용자 언어 등록 */
                    // 디폴트 사용자 언어 로케일 
                    Locale localeUserLang = MapsIamUtil.getDfltUserLangCd(iamUserVO.getSysSeCd());
                    // 사용자 언어 등록
                    MapsIamUserLangVO iamUserLangVO = new MapsIamUserLangVO();
                    iamUserLangVO.setUserSeqId(iamUserVO.getUserSeqId());
                    iamUserLangVO.setLangCd(localeUserLang.toString());
                    iamUserLangVO.setReprsntYn(MapsConstants.YN_YES);
                    iamUserLangVO.setRegistId(loginInfo.getUserSeqId());
                    iamUserLangVO.setUpdtId(loginInfo.getUserSeqId());
                    mapsIamUserMDAO.insertUserLang(iamUserLangVO);
                    
                    break;
                case DataSet.ROW_TYPE_UPDATED:
                    updateUser(iamUserVO, loginInfo);
                    break;
                case DataSet.ROW_TYPE_DELETED:
                    deleteUser(iamUserVO, loginInfo);
                    break;
            }
            procCnt++;
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#multiUserInfoFiileUpload(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, com.mobis.maps.iam.vo.MapsIamUserExcelUpldVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public void multiUserInfoFiileUpload(HttpServletRequest request, HttpServletResponse response, MapsIamUserExcelUpldVO iamUserExcelUpldVO, LoginInfoVO loginInfo) throws Exception {

        //해당 서비스에 대한 권한이 없습니다.
        MapsIamValidatorUtil.validateNotSystemUser(loginInfo);

        /* Excel업로드파일 취득 */
        File fAuthorExcel = mapsCommFileService.selectFileUpload(request);
        iamUserExcelUpldVO.setExcelFile(fAuthorExcel);
        //logger.debug("→ selectSapRfcInfoFileUpload.fUp[path=" + fUp.getPath() + "]");

        /* Excel업로드파일 파싱 */
        try {
            
            MapsIamUserExcelUpldUtil.pasing(iamUserExcelUpldVO, loginInfo);
        } finally {
            FileUploadUtil.removeFile(fAuthorExcel);
        }
        if (iamUserExcelUpldVO.hasError()) {
            return;
        }

        List<MapsIamUserVO> users = iamUserExcelUpldVO.getUsers();
        List<MapsIamUserAuthorVO> userAuthors = iamUserExcelUpldVO.getUserAuthors();
        for (MapsIamUserVO iamUserVO: users) {
            int rowType = iamUserVO.getRowType();
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }
            /* 사용자기본정보 취득 */
            String userSeqId = iamUserVO.getUserSeqId();
            String userBassId = iamUserVO.getUserBassId();
            String orgnztSeCd = iamUserVO.getOrgnztSeCd();
            
            switch (rowType) {
                case DataSet.ROW_TYPE_INSERTED:
                    try {
                        // 계정ID 채번 대상 조직구분코드 프로퍼티 취득
                        boolean isAutoUserId = MapsIamValidatorUtil.isAutoCountUserId(orgnztSeCd);
                        // 사용자기본정보 등록
                        if (StringUtils.equals(userBassId, MapsIamConstants.USER_BASS_ID_NEW)) {
                            // 사용자기본정보 취득
                            MapsIamUserBassInfoVO iamUserBassInfoVO = insertUserGetUserBassInfo(iamUserVO);
                            // 사용자기본정보 정합성 체크
                            mapsIamUserBassInfoService.insertValidateUserBassInfo(iamUserBassInfoVO, isAutoUserId, loginInfo);
                            if (isAutoUserId) {
                                String newUserBassId = mapsIamUserBassInfoService.insertUserIdSeq(iamUserBassInfoVO, loginInfo);
                                iamUserBassInfoVO.setUserBassId(newUserBassId);
                                if (StringUtils.equals(iamUserVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
                                    iamUserVO.setUserId(newUserBassId);
                                    isAutoUserId = false;
                                }
                            } else if (!StringUtils.equals(iamUserVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
                                iamUserBassInfoVO.setUserBassId(iamUserVO.getUserId());
                            }
                            // 사용자기본정보 등록
                            mapsIamUserBassInfoService.insertUserBassInfo(iamUserBassInfoVO, loginInfo);
                            // 사용자기본정보 등록후 신규생성된 
                            iamUserVO.setUserBassId(iamUserBassInfoVO.getUserBassId());
                        }
                        /* 사용자 등록정보 정합성체크 */
                        insertValidateUser(iamUserVO, isAutoUserId, loginInfo);
                        /* 사용자 등록 */
                        if (StringUtils.equals(iamUserVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
                            // 사용자기본ID가 사용자ID로 등록이 안된 경우 사용자기본ID를 사용
                            String newUserSeqId = mapsIamUserMDAO.selectUserSeqIdByUserBassId(iamUserVO);
                            if (StringUtils.isBlank(newUserSeqId)) {
                                iamUserVO.setUserId(iamUserVO.getUserBassId());
                            } else if (isAutoUserId) {
                                // 계정ID 자동 채번
                                String newUserId = mapsIamUserBassInfoService.insertUserIdSeq(iamUserVO, loginInfo);
                                iamUserVO.setUserId(newUserId);
                            }
                        }
                        /* 사용자 등록정보 등록 */
                        insertUser(iamUserVO, loginInfo);

                        /* 사용자 언어 등록 */
                        MapsIamUserLangVO iamUserLangVO = iamUserExcelUpldVO.getUserLang(userSeqId);
                        if (iamUserLangVO != null) {
                            iamUserLangVO.setUserSeqId(iamUserVO.getUserSeqId());
                            iamUserLangVO.setRegistId(loginInfo.getUserSeqId());
                            iamUserLangVO.setUpdtId(loginInfo.getUserSeqId());
                            mapsIamUserMDAO.insertUserLang(iamUserLangVO);
                        }
                        
                        /* 사용자별 권한 등록 */
                        List<Integer> mapngRowUserAuthors = iamUserExcelUpldVO.getMapngRowUserAuthor(userSeqId);
                        if (mapngRowUserAuthors != null && !mapngRowUserAuthors.isEmpty()) {
                            List<MapsIamUserAuthorVO> lstUserAuthor = new ArrayList<MapsIamUserAuthorVO>();
                            for (Integer row: mapngRowUserAuthors) {
                                MapsIamUserAuthorVO iamUserAuthorVO = userAuthors.get(row.intValue() - 1);
                                iamUserAuthorVO.setUserSeqId(iamUserVO.getUserSeqId());
                                lstUserAuthor.add(iamUserAuthorVO);
                            }
                            multiUserAuthor(lstUserAuthor, loginInfo, true);
                        }
                        
                        iamUserVO.setMsg("계정정보 등록 성공(Successful account information registration)");
                    } catch (Exception e) {
                        iamUserVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                        iamUserVO.setMsg(e.getMessage());
                        throw e;
                    }
                    break;
                case DataSet.ROW_TYPE_UPDATED:

                    try {
                        
                        updateUser(iamUserVO, loginInfo);
                        
                        iamUserVO.setMsg("계정정보 수정 성공(Successful account information update)");
                    } catch (Exception e) {
                        iamUserVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                        iamUserVO.setMsg(e.getMessage());
                        throw e;
                    }
                    break;
                case DataSet.ROW_TYPE_DELETED:

                    try {
                        
                        deleteUser(iamUserVO, loginInfo);
                    
                        iamUserVO.setMsg("계정정보 삭제 성공(Successful account information delete)");
                    } catch (Exception e) {
                        iamUserVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                        iamUserVO.setMsg(e.getMessage());
                        throw e;
                    }
                    break;
            }
        }
    }
    
    /**
     * 사용자 등록
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    private int insertUser(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        /* 사용자 등록정보 설정 */
        if (StringUtils.isBlank(iamUserVO.getMngrId())) {
            iamUserVO.setMngrId(loginInfo.getUserSeqId());
        }
        iamUserVO.setRegistId(loginInfo.getUserSeqId());
        iamUserVO.setUpdtId(loginInfo.getUserSeqId());
        // 초기 암호 설정
        iamUserVO.setUserPwd(selectGetPropInitlUserPwd(iamUserVO.getUserId() , iamUserVO.getSysSeCd()));
        // 암호만료일자 정보 설정
        iamUserVO.setPwdChageCyclDayCnt(selectGetPropPwdChageCyclDayCnt());

        /* 사용자정보 등록 */
        // 사용자 등록
        mapsIamUserMDAO.insertUser(iamUserVO);

        // 사용자변경이력 등록
        iamUserVO.setChangeSeCd(MapsConstants.CRUD_CREATE);
        iamUserVO.setChangeId(loginInfo.getUserSeqId());
        mapsIamUserMDAO.insertUserChghst(iamUserVO);

        // 사용자암호변경이력 등록
        iamUserVO.setCurUserPwd(iamUserVO.getUserPwd());
        insertUserPwdChghst(MapsIamConstants.PWD_CHAGE_SE_CD_NEW, iamUserVO, loginInfo);
        
        return 1;
    }

    /**
     * 사용자기본정보 항목 취득
     *
     * @param iamUserVO
     * @return
     */
    private MapsIamUserBassInfoVO insertUserGetUserBassInfo(MapsIamUserVO iamUserVO) {
        
        MapsIamUserBassInfoVO iamUserBassInfoVO = new MapsIamUserBassInfoVO();
        iamUserBassInfoVO.setRowType(iamUserVO.getRowType());
        iamUserBassInfoVO.setUserBassId(iamUserVO.getUserBassId());
        iamUserBassInfoVO.setUserNm(iamUserVO.getUserNm());
        iamUserBassInfoVO.setOrgnztSeCd(iamUserVO.getUserBassOrgnztSeCd());
        iamUserBassInfoVO.setBsnOrgnztCd(iamUserVO.getUserBassBsnOrgnztCd());
        iamUserBassInfoVO.setOrgnztCd(iamUserVO.getUserBassOrgnztCd());
        iamUserBassInfoVO.setDealerCd(iamUserVO.getUserBassDealerCd());
        iamUserBassInfoVO.setEmail(iamUserVO.getEmail());
        iamUserBassInfoVO.setMoblphonNo(iamUserVO.getMoblphonNo());
        iamUserBassInfoVO.setOffmTelno(iamUserVO.getOffmTelno());
        iamUserBassInfoVO.setFaxTelno(iamUserVO.getFaxTelno());
        iamUserBassInfoVO.setUseYn(iamUserVO.getUseYn());
        iamUserBassInfoVO.setDelYn(iamUserVO.getDelYn());
        
        return iamUserBassInfoVO;
    }
    
    /**
     * 사용자 등록 정합성 체크
     *
     * @param iamUserVO
     * @param isAutoUserId
     * @param loginInfo
     * @throws Exception
     */
    private void insertValidateUser(MapsIamUserVO iamUserVO, boolean isAutoUserId, LoginInfoVO loginInfo) throws Exception {

        //해당 서비스에 대한 권한이 없습니다.
        MapsIamValidatorUtil.validateOperatorUser(loginInfo);

        // 시스템은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getSysSeCd(), "W0000000070", loginInfo.getUserLcale());
        
        // 사용자기본ID은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUserBassId(), "W0000003564", loginInfo.getUserLcale());
        if (StringUtils.equalsIgnoreCase(iamUserVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
            if (!iamUserVO.getUserBassOrgnztSeCd().matches("G|N|D|E")) {
                // 사용할 수 없는 사용자기본ID입니다.
                throw new MapsBizException(messageSource, "ECI0000092", loginInfo.getUserLcale(), null);
            }
            iamUserVO.setUserBassId(MapsIamConstants.USER_BASS_ID_NEW);
        }
        
        // 사용자ID은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUserId(), "WI000000019", loginInfo.getUserLcale());
        if (StringUtils.equalsIgnoreCase(iamUserVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
            if (!iamUserVO.getOrgnztSeCd().matches("G|N|D|E")) {
                // 사용할 수 없는 사용자ID입니다.
                throw new MapsBizException(messageSource, "ECI0000093", loginInfo.getUserLcale(), null);
            }
            iamUserVO.setUserId(MapsIamConstants.USER_ID_NEW);
        } else {
            if (isAutoUserId) {
                // 사용자 ID가 자동 생성 대상인 경우 사용자 ID를 "NEW"로 입력해야합니다.
                throw new MapsBizException(messageSource, "ECI0000076", loginInfo.getUserLcale(), null);
                //iamUserVO.setUserId(MapsIamConstants.USER_ID_NEW);
            }
        }
        
        // 계정유형은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getAcntTyCd(), "WI000000015", loginInfo.getUserLcale());
        if (MapsIamValidatorUtil.isMasterUser(loginInfo.getAcntTyCd())
                && !StringUtils.equals(iamUserVO.getAcntTyCd(), MapsIamConstants.ACCOUNT_TYPE_CD_NOMAL)) {
            // 현재 사용자 권한으로 등록할 수 없는 계정 유형 입니다.
            throw new MapsBizException(messageSource, "ECI0000069", loginInfo.getUserLcale(), null);
        }

        // 사용자 등록 조직정보 정합성체크
        MapsIamValidatorUtil.validateOrgnztInfo(iamUserVO, loginInfo);
        // 조직구분은 유효하지 않는 값입니다.
        MapsIamValidatorUtil.validateOrgnztSeCdBySysSeCd(iamUserVO.getSysSeCd(), iamUserVO.getOrgnztSeCd(), loginInfo);
        // 사용자 등록 nMGN조직정보 정합성체크
        MapsIamValidatorUtil.validateDistOrgnzt(iamUserVO, loginInfo.getUserLcale());
        // 사용자ID는 사용자기본ID와 동일한 값으로 입력하세요.
        if (MapsIamValidatorUtil.isMobisOrgnzt(iamUserVO.getOrgnztSeCd())
                && !iamUserVO.getUserId().equals(iamUserVO.getUserBassId())) {
            
            // PLUS는 USER_BASS_ID에  W_ 가 붙는다.  P인경우 수정
            if( StringUtils.equals( iamUserVO.getSysSeCd()  , "P") ) {
                if( ! StringUtils.contains(iamUserVO.getUserBassId() , iamUserVO.getUserId()) ){
                    throw new MapsBizException(messageSource, "ECI0000071", loginInfo.getUserLcale(), null);
                }
            }else{
                throw new MapsBizException(messageSource, "ECI0000071", loginInfo.getUserLcale(), null);
            }
        }
        
        // 사용시작일자는 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUseBgnde(), "WI000000082", loginInfo.getUserLcale());
        
        // 사용종료일자는 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUseEndde(), "WI000000083", loginInfo.getUserLcale());
        
        // 타임존은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getTzoneCd(), "WI000000017", loginInfo.getUserLcale());
        
        // 사용여부는 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUseYn(), "W0000000041", loginInfo.getUserLcale());
        
        // 삭제여부는 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getDelYn(), "WI000000008", loginInfo.getUserLcale());
        
        /* 사용자기본정보 체크 */
        MapsIamUserBassInfoVO rsltIamUserBassInfoVO = mapsIamUserBassInfoService.selectUserBassInfo(iamUserVO, loginInfo); 
        MapsIamValidatorUtil.validateOrgnztByUserBassInfo(rsltIamUserBassInfoVO, iamUserVO, loginInfo);

        /* 중복 이에일 사용자 체크 */
        // 조직별 이메일에 해당하는 계정 조회
        String hasUserSeqId = mapsIamUserMDAO.selectUserSeqIdByOrgnztEmail(iamUserVO);
        if (StringUtils.isNotBlank(hasUserSeqId)) {
            //Email로 등록된 계정정보가 있습니다.
            throw new MapsBizException(messageSource, "ECI0000070", loginInfo.getUserLcale(), null);
        }
        
        // 신규ID가 아닌경우 사용자마스터에서 사용자ID에 해당하는 계정 조회
        if (!(isAutoUserId || StringUtils.equals(iamUserVO.getUserId(), MapsIamConstants.USER_ID_NEW))) {
            // 사용자 등록 정보 조회
            MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUserByUserId(iamUserVO);
            if (rsltUser != null) {
                // 이미 등록된 계정입니다.
                throw new MapsBizException(messageSource, "ECI0000048", loginInfo.getUserLcale(), null);
            }
        }
    }
    
    /**
     * 사용자 수정
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    private int updateUser(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        /* 사용자정보 수정 정합성 체크 */
        updateValidateUser(iamUserVO, loginInfo);

        // 사용자 수정
        iamUserVO.setRegistId(loginInfo.getUserSeqId());
        iamUserVO.setUpdtId(loginInfo.getUserSeqId());
        procCnt = mapsIamUserMDAO.updateUser(iamUserVO);
        if (procCnt != 1) {
            //수정된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000050", loginInfo.getUserLcale(), null);
        }

        // 사용자변경이력 등록
        iamUserVO.setChangeSeCd(MapsConstants.CRUD_UPDATE);
        iamUserVO.setChangeId(loginInfo.getUserSeqId());
        mapsIamUserMDAO.insertUserChghst(iamUserVO);
        
        return procCnt;
    }
    
    /**
     * 사용자 수정 정합성 체크
     *
     * @param iamUserVO
     * @param isAutoUserId
     * @param loginInfo
     * @throws Exception
     */
    private void updateValidateUser(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        //해당 서비스에 대한 권한이 없습니다.
        MapsIamValidatorUtil.validateOperatorUser(loginInfo);
        
        // 계정ID은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUserSeqId(), "W0000003561", loginInfo.getUserLcale());
        
        // 시스템은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getSysSeCd(), "W0000000070", loginInfo.getUserLcale());
        
        // 사용자ID은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUserId(), "WI000000019", loginInfo.getUserLcale());
        
        // 사용자 등록 정보 조회
        MapsIamUserVO rsltIamUserVO = mapsIamUserMDAO.selectUser(iamUserVO);
        if (rsltIamUserVO == null) {
            //등록된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);
        }
        
        // 계정유형은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getAcntTyCd(), "WI000000015", loginInfo.getUserLcale());
        
        // 사용자 등록 조직정보 정합성체크
        MapsIamValidatorUtil.validateOrgnztInfo(iamUserVO, loginInfo);
        
        // 조직구분은 유효하지 않는 값입니다.
        MapsIamValidatorUtil.validateOrgnztSeCdBySysSeCd(iamUserVO.getSysSeCd(), iamUserVO.getOrgnztSeCd(), loginInfo);
        
        // 사용자 등록 nMGN조직정보 정합성체크
        MapsIamValidatorUtil.validateDistOrgnzt(iamUserVO, loginInfo.getUserLcale());
        
        // 사용자ID는 사용자기본ID와 동일한 값으로 입력하세요.
        if (MapsIamValidatorUtil.isMobisOrgnzt(iamUserVO.getOrgnztSeCd())
                && !iamUserVO.getUserId().equals(iamUserVO.getUserBassId())) {
            // PLUS는 USER_BASS_ID에  W_ 가 붙는다.  P인경우 수정
            if( StringUtils.equals( iamUserVO.getSysSeCd()  , "P") ) {
                if( ! StringUtils.contains(iamUserVO.getUserBassId() , iamUserVO.getUserId()) ){
                    throw new MapsBizException(messageSource, "ECI0000071", loginInfo.getUserLcale(), null);
                }
            }else{
                throw new MapsBizException(messageSource, "ECI0000071", loginInfo.getUserLcale(), null);
            }
            //throw new MapsBizException(messageSource, "ECI0000071", loginInfo.getUserLcale(), null);
        }
        
        // 사용시작일자는 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUseBgnde(), "WI000000082", loginInfo.getUserLcale());
        
        // 사용종료일자는 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUseEndde(), "WI000000083", loginInfo.getUserLcale());
        
        // 타임존은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getTzoneCd(), "WI000000017", loginInfo.getUserLcale());
        
        // 사용여부는 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUseYn(), "W0000000041", loginInfo.getUserLcale());
        
        // 삭제여부는 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getDelYn(), "WI000000008", loginInfo.getUserLcale());
        
        /* 사용자기본정보 체크 */
        MapsIamUserBassInfoVO rsltIamUserBassInfoVO = mapsIamUserBassInfoService.selectUserBassInfo(iamUserVO, loginInfo); 
        MapsIamValidatorUtil.validateOrgnztByUserBassInfo(rsltIamUserBassInfoVO, iamUserVO, loginInfo);
    }

    /**
     * 사용자 삭제
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    private int deleteUser(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        /* 사용자정보 삭제 정합성 체크 */
        MapsIamUserVO rsltUser = deleteValidateUser(iamUserVO, loginInfo);

        // 사용자 삭제
        procCnt = mapsIamUserMDAO.updateDeleteUser(iamUserVO);
        //procCnt = mapsIamUserMDAO.deleteUser(iamUserVO);
        if (procCnt != 1) {
            //삭제된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000051", loginInfo.getUserLcale(), null);
        }
        
        // 사용자허용IP 삭제
        MapsIamUserPermIpVO iamUserPermIpVO = new MapsIamUserPermIpVO();
        iamUserPermIpVO.setUserSeqId(iamUserVO.getUserSeqId());
        mapsIamUserMDAO.deleteAllUserPermIp(iamUserPermIpVO);
        
        // 사용자언어 삭제
        MapsIamUserLangVO iamUserLangVO = new MapsIamUserLangVO();
        iamUserLangVO.setUserSeqId(iamUserVO.getUserSeqId());
        mapsIamUserMDAO.deleteAllUserLang(iamUserLangVO);
        
        // 사용자변경이력 등록
        rsltUser.setChangeSeCd(MapsConstants.CRUD_DELETE);
        rsltUser.setChangeId(loginInfo.getUserSeqId());
        mapsIamUserMDAO.insertUserChghst(rsltUser);
        
        return procCnt;
    }
    
    /**
     * 사용자 등록 정합성 체크
     *
     * @param iamUserVO
     * @param isAutoUserId
     * @param loginInfo
     * @throws Exception
     */
    private MapsIamUserVO deleteValidateUser(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {

        //해당 서비스에 대한 권한이 없습니다.
        MapsIamValidatorUtil.validateOperatorUser(loginInfo);
        
        // 계정ID은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUserSeqId(), "W0000003561", loginInfo.getUserLcale());
        
        // 시스템은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getSysSeCd(), "W0000000070", loginInfo.getUserLcale());
        
        // 사용자ID은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUserId(), "WI000000019", loginInfo.getUserLcale());

        MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUser(iamUserVO);
        if (rsltUser == null) {
            //등록된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);
        }
        
        return rsltUser;
    }
    
    /**
     * 사용자암호변경이력 등록
     *
     * @param pwdChageSeCd
     * @param iamUserVO
     * @param loginInfo
     * @throws Exception
     */
    private void insertUserPwdChghst(String pwdChageSeCd, MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {

        MapsIamUserPwdChghstVO iamUserPwdChghstVO = new MapsIamUserPwdChghstVO();
        iamUserPwdChghstVO.setUserSeqId(iamUserVO.getUserSeqId());
        iamUserPwdChghstVO.setPwdChageSeCd(pwdChageSeCd);
        iamUserPwdChghstVO.setBfePwd(iamUserVO.getCurUserPwd());
        iamUserPwdChghstVO.setUserPwd(iamUserVO.getUserPwd());
        iamUserPwdChghstVO.setPwdEndDt(iamUserVO.getPwdEndDt());
        iamUserPwdChghstVO.setChangeId(loginInfo.getUserSeqId());

        mapsIamUserMDAO.insertUserPwdChghst(iamUserPwdChghstVO);
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateUserUnlock(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateUserUnlock(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {

        
        MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUser(iamUserVO);
        if (rsltUser == null) {
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);    //등록된 계정이 없습니다.
        }
        // 사용자 계정잠김 해제 정보 설정
        iamUserVO.setPwdInitlYn(MapsConstants.YN_NO);
        
        String pwdChageSeCd = null;
        if (StringUtils.equals(MapsIamConstants.ACNT_LOCK_RESN_CD_PASSWORD_OVER_COUNT, rsltUser.getAcntLockResnCd())) {
            // 초기 암호 설정
            iamUserVO.setCurUserPwd(rsltUser.getUserPwd());
            iamUserVO.setUserPwd(selectGetPropInitlUserPwd( rsltUser.getUserId() , rsltUser.getSysSeCd() ));
            iamUserVO.setPwdInitlYn(MapsConstants.YN_YES);
            
            pwdChageSeCd = MapsIamConstants.PWD_CHAGE_SE_CD_ERROR;
        } else if (StringUtils.equals(MapsIamConstants.ACNT_LOCK_RESN_CD_END_PASSWORD, rsltUser.getAcntLockResnCd())) {
            // 초기 암호 설정
            iamUserVO.setCurUserPwd(rsltUser.getUserPwd());
            iamUserVO.setUserPwd(selectGetPropInitlUserPwd( rsltUser.getUserId() , rsltUser.getSysSeCd() ));
            iamUserVO.setPwdInitlYn(MapsConstants.YN_YES);
            // 암호만료일자 정보 설정
            iamUserVO.setPwdChageCyclDayCnt(selectGetPropPwdChageCyclDayCnt());
            
            pwdChageSeCd = MapsIamConstants.PWD_CHAGE_SE_CD_END;
        }
        iamUserVO.setAcntLockResnCd(rsltUser.getAcntLockResnCd());
        iamUserVO.setUpdtId(loginInfo.getUserSeqId());

        // 사용자 계정잠김 해제
        int procCnt = mapsIamUserMDAO.updateUserUnlock(iamUserVO);
        
        // 사용자변경이력 등록
        iamUserVO.setAcntLockYn(MapsConstants.YN_NO);
        iamUserVO.setAcntLockResnCd(null);
        iamUserVO.setChangeSeCd(MapsConstants.CRUD_UPDATE);
        iamUserVO.setChangeId(loginInfo.getUserSeqId());
        mapsIamUserMDAO.insertUserChghst(iamUserVO);
        
        // 사용자암호변경이력 등록
        if (StringUtils.isNotBlank(pwdChageSeCd)) {
            insertUserPwdChghst(pwdChageSeCd, iamUserVO, loginInfo);
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateUserResetPwd02(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateUserResetPwd02(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        MapsIamUserVO iamUserVOTemp = new MapsIamUserVO();
        
        // IF( A.USER_PWD  =  ENC_VARCHAR_INS( #{userPwd} ,10,'PWD','USER_PWD','T_USER_MST',USER(),CONNECTION_ID()) , 'Y', 'N') AS PWD_CHK_YN /* PASSWD 체크 */
        // curPwd로 위의 쿼리로 비교하기때문에 vo 새로 생성하고 curPwd를 userPwd에 셋팅
        BeanUtils.copyProperties(iamUserVOTemp, iamUserVO);
        iamUserVOTemp.setUserPwd(iamUserVO.getCurUserPwd());
        
        MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUser(iamUserVOTemp);
        if (rsltUser == null) {
            //등록된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);
        }
        
        if (!StringUtils.equals(iamUserVO.getUserSeqId(), loginInfo.getUserSeqId())) {
            //본인이 아닙니다.
            throw new MapsBizException(messageSource, "ECI0000052", loginInfo.getUserLcale(), null);
        }
        
        /* db 암호화 반영 */
        if (!StringUtils.equals( rsltUser.getPwdChkYn() , "Y" )) {
            //입력한 현재암호가 틀립니다.
            throw new MapsBizException(messageSource, "ECI0000053", loginInfo.getUserLcale(), null);
        }
        
        if (!ValidatorUtil.isUserPwd(iamUserVO.getSysSeCd(), iamUserVO.getUserPwd())) {
            if (StringUtils.equals(iamUserVO.getSysSeCd(), MapsConstants.SYS_SE_CD_PDA)) {
                // 최소 1 개의 숫자와 1 개의 영문 대문자를 포함한 8 자리 비밀번호를 입력하세요.
                throw new MapsBizException(messageSource, "ECM0000006", loginInfo.getUserLcale(), null);
            } else {
                // 최소 8자리에서 12자리이내의 숫자, 문자, 특수문자($@$!%*?&) 각각 1개 이상 포함한 암호를 입력하세요.
                throw new MapsBizException(messageSource, "ECI0000054", loginInfo.getUserLcale(), null);
            }
        }
        
        if (!StringUtils.equals(iamUserVO.getUserPwd(), iamUserVO.getReUserPwd())) {
            //입력한 암호와 재확인 암호가 틀립니다.
            throw new MapsBizException(messageSource, "ECI0000055", loginInfo.getUserLcale(), null);
        }

        iamUserVO.setPwdInitlYn(MapsConstants.YN_NO);
        
        int procCnt = updateUserResetPwd(iamUserVO, loginInfo);
        
        // 사용자암호변경이력 등록
        insertUserPwdChghst(MapsIamConstants.PWD_CHAGE_SE_CD_USER, iamUserVO, loginInfo);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateUserResetPwd03(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateUserResetPwd03(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUser(iamUserVO);
        if (rsltUser == null) {
            //등록된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);
        }
        // 초기 암호 설정
        iamUserVO.setCurUserPwd(rsltUser.getUserPwd());
        iamUserVO.setUserPwd(selectGetPropInitlUserPwd( rsltUser.getUserId() , rsltUser.getSysSeCd() ));
        iamUserVO.setPwdInitlYn(MapsConstants.YN_YES);

        int procCnt = updateUserResetPwd(iamUserVO, loginInfo);
        
        // 사용자암호변경이력 등록
        insertUserPwdChghst(MapsIamConstants.PWD_CHAGE_SE_CD_END, iamUserVO, loginInfo);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateUserResetPwd04(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateUserResetPwd04(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUser(iamUserVO);
        if (rsltUser == null) {
            //등록된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);
        }
        // 사용자 등록
        iamUserVO.setUpdtId(loginInfo.getUserSeqId());
        // 초기 암호 설정
        iamUserVO.setCurUserPwd(rsltUser.getUserPwd());
        iamUserVO.setUserPwd(selectGetPropInitlUserPwd( rsltUser.getUserId() , rsltUser.getSysSeCd() ));
        iamUserVO.setPwdInitlYn(MapsConstants.YN_YES);

        int procCnt = updateUserResetPwd(iamUserVO, loginInfo);
        
        // 사용자암호변경이력 등록
        insertUserPwdChghst(MapsIamConstants.PWD_CHAGE_SE_CD_ERROR, iamUserVO, loginInfo);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateUserResetPwd05(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateUserResetPwd05(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUser(iamUserVO);
        if (rsltUser == null) {
            //등록된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);
        }
        // 초기 암호 설정
        iamUserVO.setCurUserPwd(rsltUser.getUserPwd());
        iamUserVO.setUserPwd(selectGetPropInitlUserPwd( rsltUser.getUserId() , rsltUser.getSysSeCd()));
        iamUserVO.setPwdInitlYn(MapsConstants.YN_YES);

        int procCnt = updateUserResetPwd(iamUserVO, loginInfo);
        
        // 사용자암호변경이력 등록
        insertUserPwdChghst(MapsIamConstants.PWD_CHAGE_SE_CD_MANAGER_INIT, iamUserVO, loginInfo);
        
        return procCnt;
    }

    /**
     * 사용자암호변경
     *
     * @param iamUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    private int updateUserResetPwd(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        // 암호만료일자 정보 설정
        iamUserVO.setPwdChageCyclDayCnt(selectGetPropPwdChageCyclDayCnt());
        // 사용자 등록
        iamUserVO.setUpdtId(loginInfo.getUserSeqId());
        
        int procCnt = 0;
        
        procCnt = mapsIamUserMDAO.updateUserPwd(iamUserVO);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateUserPwdEndDtExtn(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateUserPwdEndDtExtn(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;

        MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUser(iamUserVO);
        if (rsltUser == null) {
            //등록된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);
        }
        
        if (!StringUtils.equals(iamUserVO.getUserSeqId(), loginInfo.getUserSeqId())) {
            //본인계정이 아닙니다.
            throw new MapsBizException(messageSource, "ECI0000056", loginInfo.getUserLcale(), null);
        }
        
        // 암호만료일자 정보 설정
        iamUserVO.setPwdChageCyclDayCnt(selectGetPropPwdChageCyclDayCnt());
        iamUserVO.setUpdtId(loginInfo.getUserSeqId());
        
        procCnt = mapsIamUserMDAO.updateUserPwdEndDtExtn(iamUserVO);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateLoginUserInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateLoginUserInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        procCnt = mapsIamUserBassInfoService.updateLoginUserBassInfo(iamUserBassInfoVO, loginInfo);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#multiNormalUser(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiNormalUser(List<MapsIamUserVO> iamUsers, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        for (MapsIamUserVO iamUserVO: iamUsers) {

            int rowType = iamUserVO.getRowType();
            if (rowType != DataSet.ROW_TYPE_UPDATED) {
                continue;
            }

            procCnt += updateNomalUser(iamUserVO, loginInfo);
            
            procCnt++;
        }
        
        return procCnt;
    }

    /**
     * 사용자 사용여부 수정
     *
     * @param iamUserVO
     * @param loginInfo
     * @param useYn
     * @return
     * @throws Exception
     */
    private int updateNomalUser(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;

        /* 입력파라미터 정합성체크 */
        // 계정ID은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUserSeqId(), "W0000003561", loginInfo.getUserLcale());
        // 사용여부는 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUseYn(), "W0000000041", loginInfo.getUserLcale());

        /* 사용자 정보 조회 */
        MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUser(iamUserVO);
        if (rsltUser == null) {
            //등록된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);
        }

        /* 일반사용자 정보정합성 체크 */
        // 로그인 조직구분코드 체크
        if (!StringUtils.equals(rsltUser.getOrgnztSeCd(), loginInfo.getOrgnztSeCd())
                || !StringUtils.equals(rsltUser.getBsnOrgnztCd(), loginInfo.getBsnOrgnztCd())
                || (!MapsIamValidatorUtil.isMobisCpr(loginInfo.getOrgnztSeCd()) && !StringUtils.equals(rsltUser.getOrgnztCd(), loginInfo.getOrgnztCd()))
                || (MapsIamValidatorUtil.isDirectDealer(loginInfo.getOrgnztSeCd()) && !StringUtils.equals(rsltUser.getDealerCd(), loginInfo.getDealerCd()))
                ) {
            //권한이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000007", loginInfo.getUserLcale(), null);
        }
        // 사용여부 변경여부 확인
        if (StringUtils.equals(iamUserVO.getUseYn(), rsltUser.getUseYn())) {
            return 0;
        }
        
        /* 일반사용자 수정 처리 */
        // 사용자정보 수정
        iamUserVO.setUpdtId(loginInfo.getUserSeqId());
        procCnt = mapsIamUserMDAO.updateNomalUser(iamUserVO);
        if (procCnt != 1) {
            // 일반사용자 수정 처리가 실패하였습니다.
            throw new MapsBizException(messageSource, "ECI0000084", loginInfo.getUserLcale(), null);
        }
        
        // 사용자변경이력 등록
        rsltUser.setChangeSeCd(MapsConstants.CRUD_UPDATE);
        rsltUser.setChangeId(loginInfo.getUserSeqId());
        rsltUser.setUseYn(iamUserVO.getUseYn());
        mapsIamUserMDAO.insertUserChghst(rsltUser);
        
        return procCnt;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateRetireUser(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateRetireUser(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;

        /* 입력파라미터 정합성체크 */
        // 계정ID은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserVO.getUserSeqId(), "W0000003561", loginInfo.getUserLcale());

        /* 사용자 정보 조회 */
        MapsIamUserVO rsltUser = mapsIamUserMDAO.selectUser(iamUserVO);
        if (rsltUser == null) {
            //등록된 계정이 없습니다.
            throw new MapsBizException(messageSource, "ECI0000049", loginInfo.getUserLcale(), null);
        }

        /* 사용자정보 정합성체크 */
        if (StringUtils.equals(rsltUser.getAcntLockResnCd(), MapsIamConstants.ACNT_LOCK_RESN_RETIREMENT)) {
            // 이미 퇴사 처리된 사용자입니다.
            throw new MapsBizException(messageSource, "ECI0000085", loginInfo.getUserLcale(), null);
        }
        
        /* 사용자 퇴사 처리 */
        // 사용자정보 수정
        iamUserVO.setUpdtId(loginInfo.getUserSeqId());
        procCnt = mapsIamUserMDAO.updateRetireUser(iamUserVO);
        if (procCnt != 1) {
            // 사용자 퇴사 처리가 실패하였습니다.
            throw new MapsBizException(messageSource, "ECI0000084", loginInfo.getUserLcale(), null);
        }
        
        // 사용자변경이력 등록
        rsltUser.setChangeSeCd(MapsConstants.CRUD_DELETE);
        rsltUser.setChangeId(loginInfo.getUserSeqId());
        rsltUser.setUseEndde(Calendar.getInstance().getTime());
        rsltUser.setAcntLockYn(MapsConstants.YN_YES);
        rsltUser.setAcntLockResnCd(MapsIamConstants.ACNT_LOCK_RESN_RETIREMENT);
        rsltUser.setUseYn(MapsConstants.YN_NO);
        rsltUser.setDelYn(MapsConstants.YN_YES);
        mapsIamUserMDAO.insertUserChghst(rsltUser);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserChghstPgList(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserVO> selectUserChghstPgList(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {

        iamUserVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        List<MapsIamUserVO> lstUserChghst = mapsIamUserMDAO.selectUserChghstPgList(iamUserVO);
        
        return lstUserChghst;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#multiUserPermIp(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiUserPermIp(List<MapsIamUserPermIpVO> userPermIps, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        for (MapsIamUserPermIpVO iamUserPermIpVO: userPermIps) {

            int rowType = iamUserPermIpVO.getRowType();
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }
            
            iamUserPermIpVO.setRegistId(loginInfo.getUserSeqId());
            iamUserPermIpVO.setUpdtId(loginInfo.getUserSeqId());
            
            switch (rowType) {
                case DataSet.ROW_TYPE_INSERTED:
                    mapsIamUserMDAO.insertUserPermIp(iamUserPermIpVO);
                    procCnt++;
                    break;
                case DataSet.ROW_TYPE_UPDATED:
                    procCnt += mapsIamUserMDAO.updateUserPermIp(iamUserPermIpVO);
                    break;
                case DataSet.ROW_TYPE_DELETED:
                    procCnt += mapsIamUserMDAO.deleteUserPermIp(iamUserPermIpVO);
                    break;
            }
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserPermIpList(com.mobis.maps.iam.vo.MapsIamUserPermIpVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserPermIpVO> selectUserPermIpList(MapsIamUserPermIpVO iamUserPermIpVO
            , LoginInfoVO loginInfo) throws Exception {
        
        List<MapsIamUserPermIpVO> lstUserPermIp = mapsIamUserMDAO.selectUserPermIpList(iamUserPermIpVO);
        
        return lstUserPermIp;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserLangList(com.mobis.maps.iam.MapsIamUserLangVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserLangVO> selectUserLangList(MapsIamUserLangVO iamUserLangVO
            , LoginInfoVO loginInfo) throws Exception {
        
        List<MapsIamUserLangVO> lstUserLang = mapsIamUserMDAO.selectUserLangList(iamUserLangVO);
        
        return lstUserLang;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#multiUserLang(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiUserLang(List<MapsIamUserLangVO> userLangs, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        for (MapsIamUserLangVO iamUserLangVO: userLangs) {

            int rowType = iamUserLangVO.getRowType();
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }
            
            iamUserLangVO.setRegistId(loginInfo.getUserSeqId());
            iamUserLangVO.setUpdtId(loginInfo.getUserSeqId());
            
            switch (rowType) {
                case DataSet.ROW_TYPE_INSERTED:
                    mapsIamUserMDAO.insertUserLang(iamUserLangVO);
                    procCnt++;
                    break;
                case DataSet.ROW_TYPE_UPDATED:
                    procCnt += mapsIamUserMDAO.updateUserLang(iamUserLangVO);
                    break;
                case DataSet.ROW_TYPE_DELETED:
                    procCnt += mapsIamUserMDAO.deleteUserLang(iamUserLangVO);
                    break;
            }
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserPwdChghstPgList(com.mobis.maps.iam.vo.MapsIamUserPwdChghstVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserPwdChghstVO> selectUserPwdChghstPgList(MapsIamUserPwdChghstVO iamUserPwdChghstVO
            , LoginInfoVO loginInfo) throws Exception {

        iamUserPwdChghstVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserPwdChghstVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        List<MapsIamUserPwdChghstVO> lstUserPwdChghst = mapsIamUserMDAO.selectUserPwdChghstPgList(iamUserPwdChghstVO);
        
        return lstUserPwdChghst;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserAuthorList(com.mobis.maps.iam.vo.MapsIamUserAuthorVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserAuthorVO> selectUserAuthorList(MapsIamUserAuthorVO iamUserAuthorVO
            , LoginInfoVO loginInfo) throws Exception {
        
        List<MapsIamUserAuthorVO> lstUserAuthor = mapsIamUserMDAO.selectUserAuthorList(iamUserAuthorVO);
        
        return lstUserAuthor;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#multiUserAuthor(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiUserAuthor(List<MapsIamUserAuthorVO> userAuthors, LoginInfoVO loginInfo) throws Exception {

        return multiUserAuthor(userAuthors, loginInfo, false);
    }
    
    /**
     * 사용자권한 등록
     *
     * @param userAuthors
     * @param loginInfo
     * @param isExcelUpload
     * @return
     * @throws Exception
     */
    private int multiUserAuthor(List<MapsIamUserAuthorVO> userAuthors, LoginInfoVO loginInfo, boolean isExcelUpload) throws Exception {

        int procCnt = 0;

        for (MapsIamUserAuthorVO iamUserAuthor : userAuthors) {

            int rowType = iamUserAuthor.getRowType();
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            iamUserAuthor.setRegistId(loginInfo.getUserSeqId());
            iamUserAuthor.setUpdtId(loginInfo.getUserSeqId());
            try {
                switch (rowType) {
                    case DataSet.ROW_TYPE_INSERTED :
    
                        mapsIamUserMDAO.insertUserAuthor(iamUserAuthor);
                        break;
                    case DataSet.ROW_TYPE_UPDATED :
    
                        mapsIamUserMDAO.updateUserAuthor(iamUserAuthor);
                        break;
                    case DataSet.ROW_TYPE_DELETED :
    
                        mapsIamUserMDAO.deleteUserAuthor(iamUserAuthor);
                        break;
                    default:
                        continue;
    
                }
                if (isExcelUpload) {
                    iamUserAuthor.setMsg("권한정보 등록 성공(Successful User Authority information registration)");
                }
            } catch (Exception e) {
                if (isExcelUpload) {
                    iamUserAuthor.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                    iamUserAuthor.setMsg(e.getMessage());
                }
                throw e;
            }
            procCnt++;
        }

        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserIndvdlzMenuList(com.mobis.maps.iam.vo.MapsIamUserIndvdlzMenuVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserIndvdlzMenuVO> selectUserIndvdlzMenuList(MapsIamUserIndvdlzMenuVO iamUserIndvdlzMenuVO
            , LoginInfoVO loginInfo) throws Exception {

        //로그인계정정보 설정
        MapsIamUtil.setLoginInfo(iamUserIndvdlzMenuVO, loginInfo);
        
        List<MapsIamUserIndvdlzMenuVO> lstUserIndvdlzMenu = mapsIamUserMDAO.selectUserIndvdlzMenuList(iamUserIndvdlzMenuVO);
        
        return lstUserIndvdlzMenu;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#multiUserIndvdlzMenu(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiUserIndvdlzMenu(List<MapsIamUserIndvdlzMenuVO> userIndvdlzMenus
            , LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        int delCnt = 0;
        for (MapsIamUserIndvdlzMenuVO iamUserIndvdlzMenuVO : userIndvdlzMenus) {

            int rowType = iamUserIndvdlzMenuVO.getRowType();
            if (rowType != DataSet.ROW_TYPE_UPDATED) {
                continue;
            }

            iamUserIndvdlzMenuVO.setRegistId(loginInfo.getUserSeqId());
            iamUserIndvdlzMenuVO.setUpdtId(loginInfo.getUserSeqId());

            if (StringUtils.equals(iamUserIndvdlzMenuVO.getMenuTyCd(), MapsIamConstants.MENU_TYPE_CD_MENU)) {
                // 사용자개별 메뉴 삭제
                delCnt = mapsIamUserMDAO.deleteUserIndvdlzMenu(iamUserIndvdlzMenuVO);
                if (logger.isDebugEnabled()) {
                    logger.debug("→ multiUserIndvdlzMenu.deleteUserIndvdlzMenu[delCnt=" + delCnt + "]");
                }
                // 사용자개별 메뉴 메뉴 등록
                if (StringUtils.equals(iamUserIndvdlzMenuVO.getAuthorYn(), MapsIamAuthorService.AUTHOR_FlAG_YES)) {
                    mapsIamUserMDAO.insertUserIndvdlzMenu(iamUserIndvdlzMenuVO);
                }
            } else if (StringUtils.equals(iamUserIndvdlzMenuVO.getMenuTyCd(), MapsIamConstants.MENU_TYPE_CD_SCREEN)) {
                // 권한별 화면기능 전체 삭제
                MapsIamUserIndvdlzScrinFnctVO iamUserIndvdlzScrinFnctVO = new MapsIamUserIndvdlzScrinFnctVO();
                iamUserIndvdlzScrinFnctVO.setUserSeqId(iamUserIndvdlzMenuVO.getUserSeqId());
                iamUserIndvdlzScrinFnctVO.setScrinId(iamUserIndvdlzMenuVO.getScrinId());
                mapsIamUserMDAO.deleteAllUserIndvdlzScrinFnct(iamUserIndvdlzScrinFnctVO);
                // 권한별 화면 삭제
                delCnt = mapsIamUserMDAO.deleteUserIndvdlzScrin(iamUserIndvdlzMenuVO);
                if (logger.isDebugEnabled()) {
                    logger.debug("→ multiUserIndvdlzMenu.deleteUserIndvdlzScrin[delCnt=" + delCnt + "]");
                }
                // 권한별 화면 등록
                if (StringUtils.equals(iamUserIndvdlzMenuVO.getAuthorYn(), MapsIamAuthorService.AUTHOR_FlAG_YES)) {
                    mapsIamUserMDAO.insertUserIndvdlzScrin(iamUserIndvdlzMenuVO);
                }
            }
            
            procCnt++;
        }

        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserIndvdlzScrinFnctList(com.mobis.maps.iam.vo.MapsIamUserIndvdlzScrinFnctVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserIndvdlzScrinFnctVO> selectUserIndvdlzScrinFnctList(MapsIamUserIndvdlzScrinFnctVO iamUserIndvdlzScrinFnctVO
            , LoginInfoVO loginInfo) throws Exception {
        
        //로그인계정정보 설정
        MapsIamUtil.setLoginInfo(iamUserIndvdlzScrinFnctVO, loginInfo);
        
        List<MapsIamUserIndvdlzScrinFnctVO> lstUserIndvdlzScrinFnct = mapsIamUserMDAO.selectUserIndvdlzScrinFnctList(iamUserIndvdlzScrinFnctVO);
        
        return lstUserIndvdlzScrinFnct;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#multiUserIndvdlzScrinFnct(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiUserIndvdlzScrinFnct(List<MapsIamUserIndvdlzScrinFnctVO> userIndvdlzScrinFncts
            , LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        int delCnt = 0;
        for (MapsIamUserIndvdlzScrinFnctVO iamUserIndvdlzScrinFnctVO : userIndvdlzScrinFncts) {

            int rowType = iamUserIndvdlzScrinFnctVO.getRowType();
            if (rowType != DataSet.ROW_TYPE_UPDATED) {
                continue;
            }

            iamUserIndvdlzScrinFnctVO.setRegistId(loginInfo.getUserSeqId());
            iamUserIndvdlzScrinFnctVO.setUpdtId(loginInfo.getUserSeqId());
            
            // 사용자개별 메뉴 삭제
            delCnt = mapsIamUserMDAO.deleteUserIndvdlzScrinFnct(iamUserIndvdlzScrinFnctVO);
            if (logger.isDebugEnabled()) {
                logger.debug("→ multiUserIndvdlzScrinFnct.deleteUserIndvdlzScrinFnct[delCnt=" + delCnt + "]");
            }
            // 사용자개별 메뉴 메뉴 등록
            if (StringUtils.equals(iamUserIndvdlzScrinFnctVO.getAuthorYn(), MapsIamAuthorService.AUTHOR_FlAG_YES)) {
                mapsIamUserMDAO.insertUserIndvdlzScrinFnct(iamUserIndvdlzScrinFnctVO);
            }
            
            procCnt++;
        }

        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserMenuList(com.mobis.maps.iam.vo.MapsIamUserMenuVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserMenuVO> selectUserMenuList(MapsIamUserMenuVO iamUserMenuVO
            , LoginInfoVO loginInfo) throws Exception {
        
        iamUserMenuVO.setDfltLangCd(loginInfo.getDfltLangCd());
        
        List<MapsIamUserMenuVO> lstUserMenu = mapsIamUserMDAO.selectUserMenuList(iamUserMenuVO);
        
        return lstUserMenu;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserScrinFnctList(com.mobis.maps.iam.vo.MapsIamUserScrinFnctVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserScrinFnctVO> selectUserScrinFnctList(MapsIamUserScrinFnctVO iamUserScrinFnctVO
            , LoginInfoVO loginInfo) throws Exception {
        
        iamUserScrinFnctVO.setDfltLangCd(loginInfo.getDfltLangCd());
        
        List<MapsIamUserScrinFnctVO> lstUserScrinFnct = mapsIamUserMDAO.selectUserScrinFnctList(iamUserScrinFnctVO);
        
        return lstUserScrinFnct;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectLoginHistPgList(com.mobis.maps.iam.vo.MapsIamLoginHistVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamLoginHistVO> selectLoginHistPgList(MapsIamLoginHistVO iamLoginHistVO
            , LoginInfoVO loginInfo) throws Exception {
        
        List<MapsIamLoginHistVO>  lstLoginHist = mapsIamUserMDAO.selectLoginHistPgList(iamLoginHistVO);
        
        return lstLoginHist;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserScrinConectHistPgList(com.mobis.maps.iam.vo.MapsIamUserScrinConectHistVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserScrinConectHistVO> selectUserScrinConectHistPgList(MapsIamUserScrinConectHistVO imUserScrinConectHistVO
            , LoginInfoVO loginInfo) throws Exception {
        
        List<MapsIamUserScrinConectHistVO>  lstUserScrinConectHist = mapsIamUserMDAO.selectUserScrinConectHistPgList(imUserScrinConectHistVO);
        
        return lstUserScrinConectHist;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectPopupUserPgList(com.mobis.maps.iam.vo.MapsIamUserVO)
     */
    @Override
    public List<MapsIamUserVO> selectPopupUserPgList(MapsIamUserVO iamUserVO) throws Exception {

        iamUserVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        List<MapsIamUserVO> userInfos = mapsIamUserMDAO.selectPopupUserPgList(iamUserVO);
        
        return userInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectFindUserId(com.mobis.maps.iam.vo.MapsIamUserVO)
     */
    @Override
    public List<MapsIamUserVO> selectFindUserId(MapsIamUserVO iamUserVO) throws Exception {

        iamUserVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        List<MapsIamUserVO> userInfos = mapsIamUserMDAO.selectFindIdUserList(iamUserVO);
        String langCd = iamUserVO.getLangCd();
        Locale locale = MapsIamUtil.getLocale(langCd);
        
        if (userInfos.isEmpty()) {
            //사용자명과 이메일을 확인해 주세요.
            throw new MapsBizException(messageSource, "ECM0000015",  locale , null);
        }
        // 이메일 발송
        updateFindUserId(userInfos , iamUserVO);
        return userInfos;
    }

    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateFindUserPwd(com.mobis.maps.iam.vo.MapsIamUserVO)
     */
    
    public int updateFindUserId(List<MapsIamUserVO> userInfos ,MapsIamUserVO rsltIamUser) throws Exception {

        int procCnt = 0;
        /*
        /* 계정 체크 */
        // 사용자정보 확인
        if (rsltIamUser == null) {
            // 사용자ID와 이메일을 확인해 주세요.
            throw new MapsBizException(messageSource, "ECI0000058",  null);
        }
        String langCd = rsltIamUser.getLangCd();
        Locale locale = MapsIamUtil.getLocale(langCd);
        
        StringBuffer sb = new StringBuffer();
        String userId = "";
        for (int i = 0 ; i < userInfos.size() ; i++ ){
            userId = userInfos.get(i).getUserId();
            sb.append("<li>");
            sb.append(userId);
            sb.append("</li>");
        }
        String findIdResult = sb.toString();
        MapsCommEmailTmplat emailFindPwd = MapsCommEmailTmplat.IAM008;
        String sysSeNm = emailFindPwd.getSysSeNm(mapsCommCodeService, rsltIamUser.getSysSeCd(), langCd);
        rsltIamUser.setSysSeNm(sysSeNm);
        
        /* 메일전송 */
        // 
        // 이메일제목
        String emailSj = emailFindPwd.getSj(messageSource, rsltIamUser, locale);
        // 이메일 내용
        Map<String, Object> mEmailData = new HashMap<String, Object>();
        mEmailData.put("sysSeNm", sysSeNm);
        mEmailData.put("idxUrl" , PropertiesUtil.getMapsUrl(rsltIamUser.getSysSeCd()));
        mEmailData.put("findIdResult", findIdResult);
        
        String emailCn = emailFindPwd.getCn(mEmailData, locale);
        // 이메일전송정보 설정
        EmailSndngVO emailSndngVO = new EmailSndngVO();
        emailSndngVO.setSndngProgrm(this.getClass().getName());
        emailSndngVO.setSndngEmail(MapsIamUtil.getHelpEmail());
        emailSndngVO.setRecptnEmail(rsltIamUser.getEmail()); // 
        emailSndngVO.setEmailSj(emailSj);
        emailSndngVO.setEmailBdt(emailCn);
        emailSndngVO.setHtmlYn("Y"); // HTML 여부
        emailSndngVO.setRegistId("SYSTEM"); // 등록자
        // 이메일전송정보 등록
        procCnt = mapsCommEmailService.insertEmail(emailSndngVO);

        return procCnt;
    }
    
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateFindUserPwd(com.mobis.maps.iam.vo.MapsIamUserVO)
     */
    @Override
    public int updateFindUserPwd(MapsIamUserVO iamUserVO) throws Exception {

        int procCnt = 0;
        
        String langCdInput = iamUserVO.getLangCd();
        Locale localeInput = MapsIamUtil.getLocale(langCdInput);
        
        
        /* 계정 체크 */
        MapsIamUserVO rsltIamUser = mapsIamUserMDAO.selectUserInfoByInitPwd(iamUserVO);
        // 사용자정보 확인
        if (rsltIamUser == null) {
            // 사용자ID와 이메일을 확인해 주세요.
            // locale 정보 입력해서 다국어 대응
            throw new MapsBizException(messageSource, "ECI0000058", localeInput, null);
        }
        if (MapsConstants.YN_YES.equals(rsltIamUser.getAcntLockYn())) {
            // 계정이 잠겨있습니다. 관리자에게 문의하여 주시기 바랍니다.
            // locale 정보 입력해서 다국어 대응
            throw new MapsBizException(messageSource, "ECI0000081", localeInput, null);
        }

        String langCd = rsltIamUser.getLangCd();
        Locale locale = MapsIamUtil.getLocale(langCd);
        
        /* 임시암호발급 */
        procCnt = updateIssuUserTmprPw(MapsIamConstants.PWD_CHAGE_SE_CD_FIND, rsltIamUser);
        
        /* 메일전송 */
        // 이메일템플릿
        MapsCommEmailTmplat emailFindPwd = MapsCommEmailTmplat.IAM001;
        // 이메일제목
        String emailSj = emailFindPwd.getSj(messageSource, rsltIamUser, locale);
        // 이메일 내용
        Map<String, Object> mEmailData = new HashMap<String, Object>();
        mEmailData.put("sysSeNm", emailFindPwd.getSysSeNm(mapsCommCodeService, rsltIamUser.getSysSeCd(), langCd));
        mEmailData.put("idxUrl", PropertiesUtil.getMapsUrl(rsltIamUser.getSysSeCd()));
        mEmailData.put("userNm", rsltIamUser.getUserNm());
        mEmailData.put("userPwd", rsltIamUser.getUserPwd());
        mEmailData.put("initPwdChageDayCnt", MapsIamConstants.INIT_PWD_CHAGE_DAY_CNT);
        String emailCn = emailFindPwd.getCn(mEmailData, locale);
        // 이메일전송정보 설정
        EmailSndngVO emailSndngVO = new EmailSndngVO();
        emailSndngVO.setSndngProgrm(this.getClass().getName());
        emailSndngVO.setSndngEmail(MapsIamUtil.getHelpEmail());
        emailSndngVO.setRecptnEmail(MapsIamUtil.getEmail(rsltIamUser)); // MAIL TO
        emailSndngVO.setEmailSj(emailSj);
        emailSndngVO.setEmailBdt(emailCn);
        emailSndngVO.setHtmlYn("Y"); // HTML 여부
        emailSndngVO.setRegistId(rsltIamUser.getUserSeqId()); // 등록자
        // 이메일전송정보 등록
        procCnt = mapsCommEmailService.insertEmail(emailSndngVO);

        /* 조회정보설정 */
        iamUserVO.setUserSeqId(rsltIamUser.getUserSeqId());
        iamUserVO.setUserNm(rsltIamUser.getUserNm());
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectMngrEmailList(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.MapsOrgnztDistVO, boolean)
     */
    @Override
    public List<MapsIamUserVO> selectMngrEmailList(MapsIamUserVO iamUserVO, MapsOrgnztDistVO orgnztDistVO, boolean isIncludeOprtr) throws Exception {

        List<MapsIamUserVO> mngrEmails = null;
        
        if (MapsConstants.SYS_SE_CD_NMGN.equals(iamUserVO.getSysSeCd())) {
            if (MapsIamConstants.NMGN_KDGRP_XPORT_MOBIS.equals(iamUserVO.getKdgrp())) {
                mngrEmails = mapsIamUserMDAO.selectMngrEmailList(iamUserVO);
                if (orgnztDistVO.isReqDist()) {
                    mngrEmails.addAll(mapsIamUserMDAO.selectReqDistMngrEmailList(orgnztDistVO));
                }
            } else {
                mngrEmails = mapsIamUserMDAO.selectDistMngrEmailList(iamUserVO);
            }
        } else {
            mngrEmails = mapsIamUserMDAO.selectMngrEmailList(iamUserVO);
        }
        
        if (isIncludeOprtr && (mngrEmails == null || mngrEmails.isEmpty())) {
            mngrEmails = mapsIamUserMDAO.selectItOprtrMngrEmailList(iamUserVO);
        }

        return mngrEmails;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#selectUserUnlock(com.mobis.maps.iam.vo.MapsIamUserVO)
     */
    @Override
    public int updateAcntUnlock(MapsIamUserVO iamUserVO) throws Exception {

        int procCnt = 0;
        
        /* 계정 체크 */
        MapsIamUserVO rsltIamUser = mapsIamUserMDAO.selectUserInfoByInitPwd(iamUserVO);
        // 사용자정보 확인
        if (rsltIamUser == null) {
            // 사용자ID와 이메일을 확인해 주세요.
            throw new MapsBizException(messageSource, "ECI0000058",  null);
        }
        if (!MapsConstants.YN_YES.equals(rsltIamUser.getAcntLockYn())) {
            // 계정이 잠겨있지 않습니다.
            throw new MapsBizException(messageSource, "ECI0000082", null);
        }
        
        /* 조회정보설정 */
        iamUserVO.setUserSeqId(rsltIamUser.getUserSeqId());
        iamUserVO.setUserNm(rsltIamUser.getUserNm());
        
        /* 메일정보 초기화 */
        // 이메일템플릿
        MapsCommEmailTmplat emailTmplat = null;
        // 이메일내용 설정
        Map<String, Object> mEmailData = new HashMap<String, Object>();
        mEmailData.put("userNm", rsltIamUser.getUserNm());
        mEmailData.put("idxUrl", PropertiesUtil.getMapsUrl(rsltIamUser.getSysSeCd()));
        // 이메일전송정보 설정
        EmailSndngVO emailSndngVO = new EmailSndngVO();
        emailSndngVO.setSndngProgrm(this.getClass().getName());
        emailSndngVO.setHtmlYn("Y"); // HTML 여부
        emailSndngVO.setRegistId(rsltIamUser.getUserSeqId()); // 등록자
        // 코드명조회 설정
        MapsCommCodeVO commCodeVO = new MapsCommCodeVO();

        // 언어설정
        String langCd = rsltIamUser.getLangCd();
        Locale locale = MapsIamUtil.getLocale(langCd);
        if (MapsIamConstants.ACNT_LOCK_RESN_CD_PASSWORD_OVER_COUNT.equals(rsltIamUser.getAcntLockResnCd())) {
            
            /* 임시암호발급 */
            procCnt = updateIssuUserTmprPw(MapsIamConstants.PWD_CHAGE_SE_CD_UNLOCK, rsltIamUser);

            /* 메일정보 설정 */
            // 이메일템플릿
            emailTmplat = MapsCommEmailTmplat.IAM002;
            // 이메일내용
            mEmailData.put("sysSeCd", rsltIamUser.getSysSeCd());
            mEmailData.put("sysSeNm", emailTmplat.getSysSeNm(mapsCommCodeService, rsltIamUser.getSysSeCd(), langCd));
            mEmailData.put("userPwd", rsltIamUser.getUserPwd());
            mEmailData.put("initPwdChageDayCnt", MapsIamConstants.INIT_PWD_CHAGE_DAY_CNT);

            // 이메일전송정보 설정
            emailSndngVO.setEmailSj(emailTmplat.getSj(messageSource, rsltIamUser, locale));
            emailSndngVO.setEmailBdt(emailTmplat.getCn(mEmailData, locale));
            emailSndngVO.setSndngEmail(MapsIamUtil.getHelpEmail());
            emailSndngVO.setRecptnEmail(MapsIamUtil.getEmail(rsltIamUser)); // MAIL TO
        } else {

            MapsOrgnztDistVO orgnztDistVO = mapsIamMobisUserService.selectDistOrgnztInfo(rsltIamUser);
            /* 메일정보 설정 */
            List<MapsIamUserVO> mngrMails = selectMngrEmailList(rsltIamUser, orgnztDistVO, false);
            if (mngrMails == null || mngrMails.isEmpty()) {
                // 등록된 관리자가 없습니다.
                throw new MapsBizException(messageSource, "ECI0000083", locale,  null);
            }
            // 언어설정
            langCd = mngrMails.get(0).getLangCd();
            locale = MapsIamUtil.getLocale(langCd);
            commCodeVO.setLangCd(locale.toString());
            // 이메일템플릿
            emailTmplat = MapsCommEmailTmplat.IAM007;
            // 이메일내용
            mEmailData.put("userId", rsltIamUser.getUserId());
            // 시스템구분코드 및 코드명 설정
            mEmailData.put("sysSeCd", rsltIamUser.getSysSeCd());
            mEmailData.put("sysSeNm", emailTmplat.getSysSeNm(mapsCommCodeService, rsltIamUser.getSysSeCd(), langCd));
            // 계정잠김사유코드 및 계정잠김사유명 설정
            commCodeVO.setCodeGroup("C000000036");
            commCodeVO.setCode(rsltIamUser.getAcntLockResnCd());
            CodeVO acntLockResnNmVO = mapsCommCodeService.selectCodeNm(commCodeVO);
            mEmailData.put("acntLockResnCd", acntLockResnNmVO.getCode());
            mEmailData.put("acntLockResnNm", acntLockResnNmVO.getCodeNm());
            // 이메일전송정보 설정
            emailSndngVO.setEmailSj(emailTmplat.getSj(messageSource, rsltIamUser, locale));
            emailSndngVO.setEmailBdt(emailTmplat.getCn(mEmailData, locale));
            emailSndngVO.setSndngEmail(rsltIamUser.getEmail());
            emailSndngVO.setRecptnEmail(MapsIamUtil.getMngrEmailTo(mngrMails)); // MAIL TO
        }

        /* 메일전송 */
        // 이메일전송정보 등록
        procCnt = mapsCommEmailService.insertEmail(emailSndngVO);
        
        return procCnt;
    }
    
    /**
     * 사용자 임시암호 발급
     *
     * @param iamUserVO
     * @throws Exception
     */
    private int updateIssuUserTmprPw(String pwdChageSeCd, MapsIamUserVO iamUserVO) throws Exception {

        int procCnt = 0;

        /* 임시암호변경 등록 */
        // 임시암호 발행
        String userPwd = SecureUtils.getTmprPwd(10);//selectGetPropInitlUserPwd();
        // 암호변경정보 설정
        iamUserVO.setPwdChageSeCd(pwdChageSeCd);
        iamUserVO.setCurUserPwd(iamUserVO.getUserPwd());
        iamUserVO.setUserPwd(userPwd);
        iamUserVO.setPwdInitlYn(MapsConstants.YN_YES);
        iamUserVO.setPwdChageCyclDayCnt(MapsIamConstants.INIT_PWD_CHAGE_DAY_CNT);
        iamUserVO.setUpdtId(iamUserVO.getUserSeqId());
        // 암호변경
        procCnt = mapsIamUserMDAO.updateUserPwd(iamUserVO);
        if (procCnt != 1) {
            // 임시비밀번호 발급에 실패하였습니다.
            throw new MapsBizException(messageSource, "ECI0000059", null);
        }
        
        /* 사용자암호변경이력 등록 */
        // 사용자암호변경이력 등록정보 설정
        MapsIamUserPwdChghstVO iamUserPwdChghstVO = new MapsIamUserPwdChghstVO();
        iamUserPwdChghstVO.setUserSeqId(iamUserVO.getUserSeqId());
        iamUserPwdChghstVO.setPwdChageSeCd(iamUserVO.getPwdChageSeCd());
        iamUserPwdChghstVO.setBfePwd(iamUserVO.getCurUserPwd());
        iamUserPwdChghstVO.setUserPwd(iamUserVO.getUserPwd());
        iamUserPwdChghstVO.setPwdEndDt(iamUserVO.getPwdEndDt());
        iamUserPwdChghstVO.setChangeId(iamUserVO.getUserSeqId());
        // 사용자암호변경이력 등록
        mapsIamUserMDAO.insertUserPwdChghst(iamUserPwdChghstVO);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updateAcntIndvdlinfoColctUseAgre(com.mobis.maps.iam.vo.MapsIamUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateAcntIndvdlinfoColctUseAgre(MapsIamUserVO iamUserVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        /* 정합성체크 */
        if (!StringUtils.equals(iamUserVO.getUserSeqId(), loginInfo.getUserSeqId())) {
            // 본인이 아닙니다.
            throw new MapsBizException(messageSource, "ECI0000052", loginInfo.getUserLcale(), null);
        }
        if (!StringUtils.equals(iamUserVO.getSysSeCd(), loginInfo.getSysSeCd())) {
            // 본인이 아닙니다.
            throw new MapsBizException(messageSource, "ECI0000052", loginInfo.getUserLcale(), null);
        }
        if (!StringUtils.equals(iamUserVO.getUserId(), loginInfo.getUserId())) {
            // 본인이 아닙니다.
            throw new MapsBizException(messageSource, "ECI0000052", loginInfo.getUserLcale(), null);
        }
        // 개인정보 수집 및 이용에 동의하셔야합니다. 
        if (!StringUtils.equals(iamUserVO.getIndvdlinfoColctUseAgreYn(), MapsConstants.YN_YES)) {
            throw new MapsBizException(messageSource, "ECI0000091", loginInfo.getUserLcale(), null);
        }

        /* 수정정보 설정 */
        iamUserVO.setUpdtId(loginInfo.getUserSeqId());

        // 사용자 개인정보수집및이용동의 수정
        procCnt = mapsIamUserMDAO.updateUserIndvdlinfoColctUseAgre(iamUserVO);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#insertPlusPwdArsCrtfcHist(com.mobis.maps.iam.vo.MapsIamPlusPwdArsCrtfcHistVO)
     */
    @Override
    public int insertPlusPwdArsCrtfcHist(MapsIamPlusPwdArsCrtfcHistVO iamPlusPwdArsCrtfcHistVO) throws Exception {
        // TODO Auto-generated method stub
        return 0;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserService#updatePlusPwdArsCrtfcHist(com.mobis.maps.iam.vo.MapsIamPlusPwdArsCrtfcHistVO)
     */
    @Override
    public int updatePlusPwdArsCrtfcHist(MapsIamPlusPwdArsCrtfcHistVO iamPlusPwdArsCrtfcHistVO) throws Exception {
        // TODO Auto-generated method stub
        return 0;
    }
    
    
    
}
