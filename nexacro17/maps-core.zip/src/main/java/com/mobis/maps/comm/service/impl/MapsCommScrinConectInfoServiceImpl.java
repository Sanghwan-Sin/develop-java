package com.mobis.maps.comm.service.impl;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.comm.service.MapsCommScrinConectInfoService;
import com.mobis.maps.comm.service.dao.MapsCommScrinConectInfoMDAO;
import com.mobis.maps.comm.vo.MapsCommScrinConectInfoVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommScrinConectInfoServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 30.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsCommScrinConectInfoService")
public class MapsCommScrinConectInfoServiceImpl extends HService implements MapsCommScrinConectInfoService {

    @Resource(name = "mapsCommScrinConectInfoMDAO")
    private MapsCommScrinConectInfoMDAO mapsCommScrinConectInfoMDAO;
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommScrinConectInfoService#insertScrinConectInfo(com.mobis.maps.comm.vo.MapsCommScrinConectInfoVO)
     */
    @Override
    public void insertScrinConectInfo(MapsCommScrinConectInfoVO commScrinConectInfoVO) throws Exception {
        
        mapsCommScrinConectInfoMDAO.insertScrinConectInfo(commScrinConectInfoVO);

    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommScrinConectInfoService#selectScrinInfo(com.mobis.maps.comm.vo.MapsCommScrinConectInfoVO)
     */
    @Override
    public MapsIamScreenVO selectScrinInfo(MapsCommScrinConectInfoVO commScrinConectInfoVO) throws Exception {

        MapsIamScreenVO scrinInfo = mapsCommScrinConectInfoMDAO.selectScrinInfo(commScrinConectInfoVO);
        
        return scrinInfo;
    }

}
