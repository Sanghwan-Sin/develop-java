package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamMenuService;
import com.mobis.maps.iam.service.dao.MapsIamMenuMDAO;
import com.mobis.maps.iam.vo.MapsIamMenuScreenVO;
import com.mobis.maps.iam.vo.MapsIamMenuVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 메뉴 관리 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamMenuServiceImpl.java
 * @Description : 메뉴 관리 서비스 구현.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
@Service("mapsIamMenuService")
public class MapsIamMenuServiceImpl extends HService implements MapsIamMenuService {
    
    @Resource(name="mapsIamMenuMDAO")
    private MapsIamMenuMDAO mapsIamMenuMDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamMenuService#selectMenuList(com.mobis.maps.iam.vo.MapsIamMenuVO)
     */
    @Override
    public List<MapsIamMenuVO> selectMenuList(MapsIamMenuVO iamMenuVO) throws Exception {
        
        List<MapsIamMenuVO> menuInfos = mapsIamMenuMDAO.selectMenuList(iamMenuVO);
        
        return menuInfos;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamMenuService#selectMenuScreenList(com.mobis.maps.iam.vo.MapsIamMenuVO)
     */
    @Override
    public List<MapsIamMenuScreenVO> selectMenuScreenList(MapsIamMenuVO iamMenuVO) throws Exception {
        
        List<MapsIamMenuScreenVO> menuScreenInfos = mapsIamMenuMDAO.selectMenuScreenList(iamMenuVO);
        
        return menuScreenInfos;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamMenuService#multiMenuInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiMenuInfo(List<MapsIamMenuVO> menuInfos, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        for (MapsIamMenuVO iamMenu: menuInfos) {
            
            int rowType = iamMenu.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            iamMenu.setRegistId(loginInfo.getUserSeqId());
            iamMenu.setUpdtId(loginInfo.getUserSeqId()); 
            
            if (MapsConstants.LEVEL0_MENU_ID.equals(iamMenu.getParntsMenuId())){
                throw new MapsBizException(messageSource, "EC00000014", new String[]{iamMenu.getOrginlWord()}, null);                
            }
            
            MapsIamMenuVO resultIamMenu = null;
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    resultIamMenu = mapsIamMenuMDAO.selectMenuInfo(iamMenu);
                    if (resultIamMenu != null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Menu Info"}, null);
                    }
                    mapsIamMenuMDAO.insertMenuInfo(iamMenu);
                    break;
                case DataSet.ROW_TYPE_UPDATED :

                    mapsIamMenuMDAO.updateMenuInfo(iamMenu);
                    break;
                case DataSet.ROW_TYPE_DELETED :                    
                    mapsIamMenuMDAO.deleteMenuScreenInfoByMenuId(iamMenu);
                    mapsIamMenuMDAO.deleteMenuInfo(iamMenu);
                    break;
                default :
                    continue;
                    
            }
            procCnt++;
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamMenuService#multiMenuScreenInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiMenuScreenInfo(List<MapsIamMenuScreenVO> menuScreenInfos, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        for (MapsIamMenuScreenVO iamMenuScreen: menuScreenInfos) {
            
            int rowType = iamMenuScreen.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            iamMenuScreen.setRegistId(loginInfo.getUserSeqId());
            iamMenuScreen.setUpdtId(loginInfo.getUserSeqId());
            
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :                    
                    mapsIamMenuMDAO.insertMenuScreenInfo(iamMenuScreen);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    mapsIamMenuMDAO.updateMenuScreenInfo(iamMenuScreen);                                       
                    break;
                case DataSet.ROW_TYPE_DELETED :                    
                    mapsIamMenuMDAO.deleteMenuScreenInfo(iamMenuScreen);
                    break;
                default :
                    continue;
                    
            }
            procCnt++;
        }
        
        return procCnt;
    }


}
