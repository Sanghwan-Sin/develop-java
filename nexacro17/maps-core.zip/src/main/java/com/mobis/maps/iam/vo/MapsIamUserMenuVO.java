package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 사용자별 메뉴 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserMenuVO.java
 * @Description : 사용자별 메뉴에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 23.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserMenuVO extends MapsIamMenuVO {
    /** 사용자순번ID */
    private String userSeqId;

    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }

    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
}
