package com.mobis.maps.comm.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommIndexVO.java
 * @Description : 결재을지 테스트용
 * @author oh.dongwon
 * @since 2020. 5. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 11.     oh.dongwon     	최초 생성
 * </pre>
 */

public class MapsCommIndexVO {
    
    /** 결재 내부번호 **/
    private String cnSulInnerNo;
    /** 결재 항목코드**/
    private String sancItemCd;
    /** 결재 암호화데이터**/
    private String ssoEncData;
    /** SSO Test용 usrId**/
    private String usrId;
    /** SSO Test용 RandomNum**/
    private String randomNum;
    /** SSO Test용 locale**/
    private String locale;
    /** SSO Test용 gubunFlag**/
    private String gubunFlag;
    
    
    
    
    /**
     * @return the gubunFlag
     */
    public String getGubunFlag() {
        return gubunFlag;
    }
    /**
     * @param gubunFlag the gubunFlag to set
     */
    public void setGubunFlag(String gubunFlag) {
        this.gubunFlag = gubunFlag;
    }
    /**
     * @return the usrId
     */
    public String getUsrId() {
        return usrId;
    }
    /**
     * @param usrId the usrId to set
     */
    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }
    /**
     * @return the randomNum
     */
    public String getRandomNum() {
        return randomNum;
    }
    /**
     * @param randomNum the randomNum to set
     */
    public void setRandomNum(String randomNum) {
        this.randomNum = randomNum;
    }
    /**
     * @return the locale
     */
    public String getLocale() {
        return locale;
    }
    /**
     * @param locale the locale to set
     */
    public void setLocale(String locale) {
        this.locale = locale;
    }
    /**
     * @return the cnSulInnerNo
     */
    public String getCnSulInnerNo() {
        return cnSulInnerNo;
    }
    /**
     * @param cnSulInnerNo the cnSulInnerNo to set
     */
    public void setCnSulInnerNo(String cnSulInnerNo) {
        this.cnSulInnerNo = cnSulInnerNo;
    }
    /**
     * @return the sancItemCd
     */
    public String getSancItemCd() {
        return sancItemCd;
    }
    /**
     * @param sancItemCd the sancItemCd to set
     */
    public void setSancItemCd(String sancItemCd) {
        this.sancItemCd = sancItemCd;
    }
    /**
     * @return the ssoEncData
     */
    public String getSsoEncData() {
        return ssoEncData;
    }
    /**
     * @param ssoEncData the ssoEncData to set
     */
    public void setSsoEncData(String ssoEncData) {
        this.ssoEncData = ssoEncData;
    }
    
    
}
