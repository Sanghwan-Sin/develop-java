package com.mobis.maps.iam.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.spring.SpringApplicationContext;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.util.MapsCommExcelUtil;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamAuthorService;
import com.mobis.maps.iam.service.MapsIamUserBassInfoService;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserExcelUpldVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 권한 액셀업로드 유틸리티
 * </pre>
 *
 * @ClassName   : MapsIamUserExcelUpldUtil.java
 * @Description : 권한 액셀업로드에 대한 유틸리티를 정의.
 * @author DT048058
 * @since 2020. 9. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 9.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserExcelUpldUtil {

    protected final static Logger logger = LoggerFactory.getLogger(MapsIamUserExcelUpldUtil.class);

    /** XLSX액셀파일 확장자 */
//    private static final String FILE_EXTENTION_EXCEL_XLSX = ".xlsx";
    /** 처리유형확인용(사용자) */
    private static final String PROCESS_TYPES_USER = "C|U|D";
    /** 처리유형확인용(사용자권한) */
    private static final String PROCESS_TYPES_AUTHOR = "C|D";
    
    /** 시트명(사용자) */
    private static final String SHEET_NAME_USER = "USER_MST";
    /** 시트명(사용자권한) */
    private static final String SHEET_NAME_AUTHOR = "USER_AUTHORITY";

    /** 처리시작행(사용자) */
    private static final int START_ROW_USER = 1;
    /** 처리시작행(사용자권한) */
    private static final int START_ROW_AUTHOR = 1;

    /** 처리종료열(사용자) */
    private static final short END_COL_USER = 36;
    /** 처리종료열(사용자) */
    private static final short END_COL_AUTHOR = 5;
    
    private static MapsIamAuthorService mapsIamAuthorService;
    public static MapsIamAuthorService getMapsIamAuthorService() {
        
        if (mapsIamAuthorService == null) {
            mapsIamAuthorService = (MapsIamAuthorService)SpringApplicationContext.getBean("mapsIamAuthorService");
        }
        
        return mapsIamAuthorService;
    }

    private static MapsIamUserBassInfoService mapsIamUserBassInfoService;
    public static MapsIamUserBassInfoService getMapsIamUserBassInfoService() {
        
        if (mapsIamUserBassInfoService == null) {
            mapsIamUserBassInfoService = (MapsIamUserBassInfoService)SpringApplicationContext.getBean("mapsIamUserBassInfoService");
        }
        
        return mapsIamUserBassInfoService;
    }
    
    
    /**
     * Statements
     *
     * @param iamAuthorParserInfoVO
     * @throws Exception
     */
    public static void pasing(MapsIamUserExcelUpldVO iamUserExcelUpldVO, LoginInfoVO loginInfo) throws Exception {

        File fAuthorExcel = iamUserExcelUpldVO.getExcelFile();
        
//        String fileNm = fAuthorExcel.getName();
//        if (StringUtils.endsWithIgnoreCase(fileNm, FILE_EXTENTION_EXCEL_XLSX)) {
//            
//        } else {
////            HSSFWorkbook wb = MapsCommExcelUtil.createWorkbookXls(file);
//            throw new MapsBizException("지원하지 않는 액셀 파일입니다.");
//        }
        
        XSSFWorkbook wb = MapsCommExcelUtil.createWorkbook(fAuthorExcel);
        
        setUsers(wb, iamUserExcelUpldVO, loginInfo);
        
        setUserAuthors(wb, iamUserExcelUpldVO, loginInfo);
    }
    

    public static String getErrorString(List<String> errMsgs) {
        
        StringBuilder sbErrMsg = new StringBuilder();

        for (String errMsg: errMsgs) {
            if (sbErrMsg.length() > 0) {
                sbErrMsg.append("\n\r");
            }
            sbErrMsg.append(errMsg);
        }
        
        return sbErrMsg.toString();
    }
    
    /**
     * 사용자 정보 설정
     *
     * @param wb
     * @param iamUserExcelUpldVO
     * @param loginInfo
     * @throws Exception
     */
    private static void setUsers(XSSFWorkbook wb, MapsIamUserExcelUpldVO iamUserExcelUpldVO, LoginInfoVO loginInfo) throws Exception {

        List<MapsIamUserVO> users = new ArrayList<MapsIamUserVO>();

        XSSFSheet sheet = wb.getSheet(SHEET_NAME_USER);
        
        int lastRowNum = sheet.getLastRowNum();
        if (lastRowNum < 0) {
            return;
        }

        boolean isError = false;
        for (int i = START_ROW_USER; i <= lastRowNum; i++) {
            
            XSSFRow row = sheet.getRow(i);
            if (row == null) {
                continue;
            }

            /* 사용자 정보 취득 및 설정 */
            MapsIamUserVO iamUserVO = new MapsIamUserVO();
            iamUserVO.setRnum(i);
            for (short c = 0; c < END_COL_USER; c++) {
                
                XSSFCell cell = row.getCell(c);
                if (cell == null) {
                    continue;
                }

                switch (c) {
                    case 1 :
                        iamUserVO.setProcTy(cell.getRichStringCellValue().getString());
                        break;
                    case 2 :
                        iamUserVO.setUserSeqId(cell.getStringCellValue());
                        break;
                    case 4 :
                        iamUserVO.setSysSeCd(cell.getRichStringCellValue().getString());
                        break;
                    case 5 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setUserId(cell.getStringCellValue());
                        if (StringUtils.equalsIgnoreCase(iamUserVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
                            iamUserVO.setUserId(MapsIamConstants.USER_ID_NEW);
                        }
                        break;
                    case 6 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setUserBassId(cell.getStringCellValue());
                        if (StringUtils.equalsIgnoreCase(iamUserVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
                            iamUserVO.setUserBassId(MapsIamConstants.USER_BASS_ID_NEW);
                        }
                        break;
                    case 7 :
                        iamUserVO.setEmail(cell.getStringCellValue());
                        break;
                    case 8 :
                        iamUserVO.setUserNm(cell.getStringCellValue());
                        break;
                    case 10 :
                        iamUserVO.setUserBassOrgnztSeCd(cell.getRichStringCellValue().getString());
                        break;
                    case 12 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setUserBassBsnOrgnztCd(cell.getRichStringCellValue().getString());
                        break;
                    case 13 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setUserBassOrgnztCd(cell.getStringCellValue());
                        break;
                    case 14 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setUserBassDealerCd(cell.getStringCellValue());
                        break;
                    case 15 :
                        iamUserVO.setMoblphonNo(cell.getStringCellValue());
                        break;
                    case 16 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setOffmTelno(cell.getStringCellValue());
                        break;
                    case 17 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setFaxTelno(cell.getStringCellValue());
                        break;
                    case 19 :
                        iamUserVO.setAcntTyCd(cell.getRichStringCellValue().getString());
                        break;
                    case 21 :
                        iamUserVO.setOrgnztSeCd(cell.getRichStringCellValue().getString());
                        break;
                    case 23 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setBsnOrgnztCd(cell.getRichStringCellValue().getString());
                        break;
                    case 24 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setOrgnztCd(cell.getStringCellValue());
                        break;
                    case 25 :
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        iamUserVO.setDealerCd(cell.getStringCellValue());
                        break;
                    case 26 :
                        iamUserVO.setUseBgnde(cell.getDateCellValue());
                        break;
                    case 27 :
                        iamUserVO.setUseEndde(cell.getDateCellValue());
                        break;
                    case 29 :
                        iamUserVO.setLangCd(cell.getRichStringCellValue().getString());
                        break;
                    case 31 :
                        iamUserVO.setTzoneCd(cell.getRichStringCellValue().getString());
                        break;
                    case 32 :
                        iamUserVO.setAsisUserId(cell.getStringCellValue());
                        break;
                    case 33 :
                        iamUserVO.setMngrId(cell.getStringCellValue());
                        break;
                    case 34 :
                        iamUserVO.setUseYn(cell.getStringCellValue());
                        break;
                    case 35 :
                        iamUserVO.setDelYn(cell.getStringCellValue());
                        break;
                    default:
                        continue;
                }
            }
            
            /* 사용자 정합성체크 */
            List<String> errors = new ArrayList<String>();
            String procTy = iamUserVO.getProcTy();
            String userSeqId = iamUserVO.getUserSeqId();

            if (StringUtils.isBlank(procTy) || !procTy.matches(PROCESS_TYPES_USER)) {
                // 처리유형 은 유효하지 않은 값입니다.
                errors.add(MapsIamValidatorUtil.getMessageByWordId("EC00000011", "WI000000296", loginInfo.getUserLcale()));
            } else {
                MapsIamValidatorUtil.setRowType(iamUserVO);
            }
            if (StringUtils.isBlank(userSeqId)) {
                // 계정ID는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("W0000003561", loginInfo.getUserLcale()));
            } else {
                // 사용자 매핑 정보 추가
                Integer iChkRow = iamUserExcelUpldVO.getMapngRowUserSeqId(userSeqId);
                if (iChkRow != null) {
                    errors.add(iChkRow.intValue() + "행에 이미 입력한 계정ID입니다.");
                } else {
                    iamUserExcelUpldVO.setMapngRowUserSeqId(userSeqId, i);
                }
            }
            if (StringUtils.isBlank(iamUserVO.getSysSeCd())) {
                // 시스템은 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("W0000000070", loginInfo.getUserLcale()));
            } else {
                if (!MapsIamValidatorUtil.isIamServer()
                        && !StringUtils.equals(loginInfo.getSysSeCd(), iamUserVO.getSysSeCd())) {
                    // 해당 시스템만 입력하세요.
                    errors.add("로그인한 시스템과 동일한 시스템만 처리 가능합니다.");
                }
            }
            if (StringUtils.isBlank(iamUserVO.getUserId())) {
                // 사용자ID은 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000019", loginInfo.getUserLcale()));
            }
            if (StringUtils.isBlank(iamUserVO.getUserBassId())) {
                // 사용자기본ID은 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("W0000003564", loginInfo.getUserLcale()));
            }
            if (iamUserVO.getRowType() == DataSet.ROW_TYPE_INSERTED) {
                if (StringUtils.equals(iamUserVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
                    if (StringUtils.isBlank(iamUserVO.getEmail())) {
                        // 이메일은 필수 항목입니다.
                        errors.add(MapsIamValidatorUtil.getMessageRequired("W0000003560", loginInfo.getUserLcale()));
                    } else {
                        // 이메일 매핑 정보 추가
                        Integer iChkRow = iamUserExcelUpldVO.getMapngRowEmail(iamUserVO.getEmail());
                        if (iChkRow != null) {
                            errors.add(iChkRow.intValue() + "행에 이미 입력한 이메일입니다.");
                        } else {
                            iamUserExcelUpldVO.setMapngRowEmail(iamUserVO.getEmail(), i);
                            
                            MapsIamUserBassInfoVO rsltEmailChkUserBassInfo = getMapsIamUserBassInfoService().selectHasUserBassInfo(iamUserVO);
                            if (rsltEmailChkUserBassInfo != null
                                    && StringUtils.isNotBlank(rsltEmailChkUserBassInfo.getUserBassId())) {
                                errors.add("사용자기본정보에 이미 등록된 이메일입니다.");
                            }
                        }
                    }
                    if (StringUtils.isBlank(iamUserVO.getUserNm())) {
                        // 사용자명은 필수 항목입니다.
                        errors.add(MapsIamValidatorUtil.getMessageRequired("W0000003562", loginInfo.getUserLcale()));
                    }
                    if (StringUtils.isBlank(iamUserVO.getUserBassOrgnztSeCd())) {
                        // 사용자기본조직의 조직구분은 필수 항목입니다.
                        errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000001", loginInfo.getUserLcale()));
                    } else {
                        if (MapsIamValidatorUtil.isMobisOrgnzt(iamUserVO.getUserBassOrgnztSeCd())) {
                            // 사원번호로 사용자기본ID를 입력하세요.
                            errors.add(MessageUtil.getMessage("ECI0000079", loginInfo.getUserLcale()));
                        }
                    }
                    if (StringUtils.isBlank(iamUserVO.getUserBassBsnOrgnztCd())) {
                        // 사용자기본조직의 모비스법인은 필수 항목입니다.
                        errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000237", loginInfo.getUserLcale()));
                    }
                    if (StringUtils.isNotBlank(iamUserVO.getUserBassOrgnztSeCd())) {
                        if (MapsIamValidatorUtil.isNotMobisOrgnzt(iamUserVO.getUserBassOrgnztSeCd())
                                && StringUtils.isBlank(iamUserVO.getUserBassOrgnztCd())) {
                            //조직코드는 필수 항목입니다.
                            errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000002", loginInfo.getUserLcale()));
                        }
                        if (MapsIamValidatorUtil.isDirectDealer(iamUserVO.getUserBassOrgnztSeCd())
                                && StringUtils.isBlank(iamUserVO.getUserBassDealerCd())) {
                            //딜러코드는 필수 항목입니다.
                            errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000003", loginInfo.getUserLcale()));
                        }
                    }
                } else {
                    MapsIamUserBassInfoVO rsltUserBassInfo = getMapsIamUserBassInfoService().selectUserBassInfo(iamUserVO, loginInfo);
                    if (rsltUserBassInfo == null) {
                        //등록된 사용자기본정보가 없습니다.
                        errors.add(MessageUtil.getMessageSource().getMessage("ECI0000044", null, loginInfo.getUserLcale()));
                    } else {
                        iamUserVO.setUserNm(rsltUserBassInfo.getUserNm());
                        iamUserVO.setEmail(rsltUserBassInfo.getEmail());
                        iamUserVO.setUserBassOrgnztSeCd(rsltUserBassInfo.getOrgnztSeCd());
                        iamUserVO.setUserBassBsnOrgnztCd(rsltUserBassInfo.getBsnOrgnztCd());
                        iamUserVO.setUserBassOrgnztCd(rsltUserBassInfo.getOrgnztCd());
                        iamUserVO.setUserBassDealerCd(rsltUserBassInfo.getDealerCd());
                        iamUserVO.setMoblphonNo(rsltUserBassInfo.getMoblphonNo());
                        iamUserVO.setOffmTelno(rsltUserBassInfo.getOffmTelno());
                        iamUserVO.setFaxTelno(rsltUserBassInfo.getFaxTelno());
                        if (rsltUserBassInfo.getUseYn().equals(MapsConstants.YN_NO)) {
                            //사용하지 않는 사용자기본정보 입니다.
                            errors.add("사용하지 않는 사용자기본정보 입니다.");
                        }
                        if (rsltUserBassInfo.getDelYn().equals(MapsConstants.YN_YES)) {
                            //삭제된 사용자기본정보 입니다.
                            errors.add("삭제된 사용자기본정보 입니다.");
                        }
                    }
                }
            }

            if (iamUserVO.getRowType() != DataSet.ROW_TYPE_DELETED) {
                if (StringUtils.isBlank(iamUserVO.getAcntTyCd())) {
                    // 계정유형은 필수 항목입니다.
                    errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000015", loginInfo.getUserLcale()));
                }
                if (StringUtils.isBlank(iamUserVO.getOrgnztSeCd())) {
                    // 조직구분은 필수 항목입니다.
                    errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000001", loginInfo.getUserLcale()));
                }
                if (StringUtils.isBlank(iamUserVO.getBsnOrgnztCd())) {
                    // 모비스법인은 필수 항목입니다.
                    errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000237", loginInfo.getUserLcale()));
                }
                if (StringUtils.isNotBlank(iamUserVO.getOrgnztSeCd())) {
                    if (MapsIamValidatorUtil.isNotMobisOrgnzt(iamUserVO.getOrgnztSeCd())) {
                        if (StringUtils.isBlank(iamUserVO.getOrgnztCd())) {
                            //조직코드는 필수 항목입니다.
                            errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000002", loginInfo.getUserLcale()));
                        }
                    } else {
                        if (!iamUserVO.getUserId().equals(iamUserVO.getUserBassId())) {
                            errors.add("사용자ID는 사용자기본ID와 동일한 사번으로 입력하세요.");
                        }
                    }
                    if (MapsIamValidatorUtil.isDirectDealer(iamUserVO.getOrgnztSeCd())
                            && StringUtils.isBlank(iamUserVO.getDealerCd())) {
                        //딜러코드는 필수 항목입니다.
                        errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000003", loginInfo.getUserLcale()));
                    }
                    try {
                        // 조직구분은 유효하지 않는 값입니다.
                        MapsIamValidatorUtil.validateOrgnztSeCdBySysSeCd(iamUserVO.getSysSeCd(), iamUserVO.getOrgnztSeCd(), loginInfo);
                    } catch (Exception e) {
                        errors.add(e.getMessage());
                    }
                }
                if (iamUserVO.getUseBgnde() == null) {
                    // 사용시작일자은 필수 항목입니다.
                    errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000082", loginInfo.getUserLcale()));
                }
                if (iamUserVO.getUseEndde() == null) {
                    // 사용종료일자은 필수 항목입니다.
                    errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000083", loginInfo.getUserLcale()));
                }
                if (StringUtils.isBlank(iamUserVO.getLangCd())) {
                    // 언어는 필수 항목입니다.
                    errors.add(MapsIamValidatorUtil.getMessageRequired("W0000000026", loginInfo.getUserLcale()));
                } else {
                    iamUserExcelUpldVO.putUserLang(iamUserVO.getUserSeqId(), iamUserVO.getLangCd());
                }
                if (StringUtils.isBlank(iamUserVO.getTzoneCd())) {
                    // 타임존은 필수 항목입니다.
                    errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000017", loginInfo.getUserLcale()));
                }
                if (StringUtils.isBlank(iamUserVO.getUseYn())) {
                    // 사용여부는 필수 항목입니다.
                    errors.add(MapsIamValidatorUtil.getMessageRequired("W0000000041", loginInfo.getUserLcale()));
                }
                if (StringUtils.isBlank(iamUserVO.getDelYn())) {
                    // 삭제여부는 필수 항목입니다.
                    errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000008", loginInfo.getUserLcale()));
                }
            }
            // 사용자정보 애러내용 추가
            if (errors.isEmpty()) {
                iamUserVO.setMsgTy(MapsConstants.MESSAGE_TYPE_SUCCESS);
                iamUserVO.setMsg("액셀업로드 성공(Success Excel Uploaded)");
            } else {
                iamUserVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                iamUserVO.setMsg(getErrorString(errors));
                isError = true;
            }

            // 사용자정보 추가
            users.add(iamUserVO);
        }
        iamUserExcelUpldVO.setUsers(users);
        
        if (isError) {
            iamUserExcelUpldVO.addError("사용자 액셀업로드 처리중 오류가 발생했습니다.");
        }
    }

    /**
     * 사용자별 권한 정보 설정
     *
     * @param wb
     * @param iamUserExcelUpldVO
     * @param loginInfo
     * @throws Exception
     */
    private static void setUserAuthors(XSSFWorkbook wb, MapsIamUserExcelUpldVO iamUserExcelUpldVO, LoginInfoVO loginInfo) throws Exception {

        List<MapsIamUserAuthorVO> userAuthors = new ArrayList<MapsIamUserAuthorVO>();
        
        XSSFSheet sheet = wb.getSheet(SHEET_NAME_AUTHOR);
        
        int lastRowNum = sheet.getLastRowNum();
        if (lastRowNum < 0) {
            return;
        }

        boolean isError = false;
        for (int i = START_ROW_AUTHOR; i <= lastRowNum; i++) {
            
            XSSFRow row = sheet.getRow(i);
            if (row == null) {
                continue;
            }

            /* 사용자권한 정보 취득 및 설정 */
            MapsIamUserAuthorVO iamUserAuthorVO = new MapsIamUserAuthorVO();
            iamUserAuthorVO.setRnum(i);
            for (short c = 0; c < END_COL_AUTHOR; c++) {
                
                XSSFCell cell = row.getCell(c);
                if (cell == null) {
                    continue;
                }

                switch (c) {
                    case 1 :
                        iamUserAuthorVO.setProcTy(cell.getRichStringCellValue().getString());
                        break;
                    case 2 :
                        iamUserAuthorVO.setUserAuthorId(cell.getStringCellValue());
                        break;
                    case 3 :
                        iamUserAuthorVO.setUserSeqId(cell.getStringCellValue());
                        break;
                    case 4 :
                        iamUserAuthorVO.setAuthorId(cell.getStringCellValue());
                        break;
                    default:
                        continue;
                }
            }
            
            /* 사용자권한 정합성체크 */
            List<String> errors = new ArrayList<String>();
            String procTy = iamUserAuthorVO.getProcTy();
            String userSeqId = iamUserAuthorVO.getUserSeqId();

            if (StringUtils.isBlank(procTy) || !procTy.matches(PROCESS_TYPES_AUTHOR)) {
                // 처리유형 은 유효하지 않은 값입니다.
                errors.add(MapsIamValidatorUtil.getMessageByWordId("EC00000011", "WI000000296", loginInfo.getUserLcale()));
            } else {
                MapsIamValidatorUtil.setRowType(iamUserAuthorVO);
            }
            if (StringUtils.isBlank(iamUserAuthorVO.getUserAuthorId())) {
                // 사용자권한ID는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000298", loginInfo.getUserLcale()));
            }
            if (StringUtils.isBlank(userSeqId)) {
                // 계정ID는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("W0000003561", loginInfo.getUserLcale()));
                userSeqId = "BLANK";
            } else {
                Integer iChkRow = iamUserExcelUpldVO.getMapngRowUserSeqId(userSeqId);
                if (iChkRow == null) {
                    iamUserExcelUpldVO.addError("사용자마스터(USER_MST)시트에 입력되지 않은 계정ID입니다.");
                }
            }
            if (StringUtils.isBlank(iamUserAuthorVO.getAuthorId())) {
                // 권한ID는 필수 항목입니다.
                errors.add(MapsIamValidatorUtil.getMessageRequired("WI000000048", loginInfo.getUserLcale()));
            } else {
                // 권한ID 매핑 정보 추가
                MapsIamAuthorVO iamAuthorVO = iamUserExcelUpldVO.getMapngAuthorId(iamUserAuthorVO.getAuthorId());
                if (iamAuthorVO == null) {
                    iamAuthorVO = getMapsIamAuthorService().selectAuthorInfo(iamUserAuthorVO, loginInfo);
                    if (iamAuthorVO == null) {
                        iamAuthorVO = new MapsIamAuthorVO();
                        iamAuthorVO.setRowType(DataSet.ROW_TYPE_DELETED);
                        iamAuthorVO.setAuthorId(iamUserAuthorVO.getAuthorId());
                    } else {
                        iamAuthorVO.setRowType(DataSet.ROW_TYPE_NORMAL);
                    }
                    iamUserExcelUpldVO.setMapngAuthorId(iamUserAuthorVO.getAuthorId(), iamAuthorVO);
                }
                if (iamAuthorVO.getRowType() == DataSet.ROW_TYPE_DELETED) {
                    errors.add("권한마스터 정보가 없습니다.");
                } else {
                    if (!StringUtils.equals(iamAuthorVO.getUseYn(), MapsConstants.YN_YES)) {
                        errors.add("사용하지 않는 권한입니다.");
                    }
                    Integer iRowUser = iamUserExcelUpldVO.getMapngRowUserSeqId(userSeqId);
                    if (iRowUser != null) {
                        MapsIamUserVO iamUserVO = iamUserExcelUpldVO.getUsers().get(iRowUser.intValue() - 1);
                        if (!StringUtils.equals(iamUserVO.getBsnOrgnztCd(), iamAuthorVO.getBsnOrgnztCd())) {
                            errors.add("동일한 모비스법인코드에 해당하는 권한을 입력해 주세요.");
                        }
                    }
                }
            }
            // 사용자권한정보 애러내용 추가
            if (errors.isEmpty()) {
                iamUserAuthorVO.setMsgTy(MapsConstants.MESSAGE_TYPE_SUCCESS);
                iamUserAuthorVO.setMsg("액셀업로드 성공(Success Excel Uploaded)");
            } else {
                iamUserAuthorVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                iamUserAuthorVO.setMsg(getErrorString(errors));
                isError = true;
            }

            // 사용자권한정보 추가
            userAuthors.add(iamUserAuthorVO);
            // 사용자권한정보 매핑행 추가
            iamUserExcelUpldVO.addMapngRowUserAuthor(userSeqId, i);
        }
        iamUserExcelUpldVO.setUserAuthors(userAuthors);
        
        if (isError) {
            iamUserExcelUpldVO.addError("사용자권한 액셀업로드 처리중 오류가 발생했습니다.");
        }
        
    }
}
