package com.mobis.maps.comm.service;

import java.util.List;

import able.com.exception.BizException;

import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.vo.EmailSndngVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommEmailService.java
 * @Description : 이메일등록(전송)
 * @author hong.minho
 * @since 2020. 4. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 13.     hong.minho     	최초 생성
 * </pre>
 */

public interface MapsCommEmailService {

    /**
     * Email + 첨부파일 전송 
     *
     * @param emailVo
     * @param fileVos
     * @throws BizException
     * @throws Exception
     */
    public void multiSendEmail(EmailSndngVO emailVo, List<MapsAtchFileVO> fileVos) throws BizException, Exception;

    
    /**
     * Email 등록(전송)
     *
     * @param vo
     * @return emailSn (이메일순번)
     * @throws BizException
     * @throws Exception
     */
    public int insertEmail(EmailSndngVO vo) throws BizException, Exception;
    
}
