package com.mobis.maps.iam.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinStatsVO;

/**
 * <pre>
 * 사용자 화면 통계 서비스
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinStatsService.java
 * @Description : 사용자 화면 통계에 대한 서비스를 정의.
 * @author DT048058
 * @since 2020. 5. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 7.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsIamUserScrinStatsService {

    /**
     * 사용자 화면 접속 통계 메인 리스트 조회
     *
     * @param iamUserScrinStatsVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinStatsVO> selectUserScrinStatsMainList(MapsIamUserScrinStatsVO iamUserScrinStatsVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자 화면 접속 통계 상세 리스트 조회
     *
     * @param iamUserScrinStatsVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinStatsVO> selectUserScrinStatsDetailList(MapsIamUserScrinStatsVO iamUserScrinStatsVO, LoginInfoVO loginInfo) throws Exception;
    
}
