package com.mobis.maps.comm.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;

import able.com.service.HService;
import able.com.util.fmt.DateUtil;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.MDC;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.util.NexacroUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.util.SapJcoDebugUtil;
import com.mobis.maps.cmmn.util.WebUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.RfcDataTy;
import com.mobis.maps.comm.constants.RfcIpttSe;
import com.mobis.maps.comm.constants.RfcJCoDest;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.comm.service.dao.MapsCommSapMDAO;
import com.mobis.maps.comm.vo.MapsCommSapRfcBassInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIpttInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrFieldVO;
import com.mobis.maps.sapjco.manager.Destination;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFieldIterator;
import com.sap.conn.jco.JCoParameterFieldIterator;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * RFC호출 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCmmnSapServiceImpl.java
 * @Description : RFC호출에 대한 서비스를 구현.
 * @author Sin Sanghwan
 * @since 2019. 7. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 29.     Sin Sanghwan       최초 생성
 * </pre>
 */
@Service("mapsCmmnSapService")
public class MapsCommSapServiceImpl extends HService implements MapsCommSapService {
    
    @Resource(name = "mapsCommSapMDAO")
    private MapsCommSapMDAO mapsCommSapMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectDestination(java.util.Locale)
     */
    @Override
    public Destination selectDestination(Locale local) throws Exception {
        
        return selectDestination(local, RfcSapSys.PC);
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectDestination(java.util.Locale, com.mobis.maps.comm.constants.RfcSapSys)
     */
    @Override
    public Destination selectDestination(Locale local, RfcSapSys rfcSapSys) throws Exception {

        RfcJCoDest rfcLangTy = RfcJCoDest.getByLocale(rfcSapSys, local);
        if (rfcLangTy == null) {
            rfcLangTy = RfcJCoDest.PC_EN;
        }
        
        return rfcLangTy.getDestination();
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectDestination(com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Destination selectDestination(LoginInfoVO loginInfo) throws Exception {
        
        return selectDestination(loginInfo, RfcSapSys.PC);
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectDestination(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.comm.constants.RfcSapSys)
     */
    @Override
    public Destination selectDestination(LoginInfoVO loginInfo, RfcSapSys rfcSapSys) throws Exception {
        if( loginInfo == null ){
            return RfcJCoDest.PC_KO.getDestination();
        }
        RfcJCoDest rfcLangTy  = RfcJCoDest.get(rfcSapSys, loginInfo.getRfcServerLang());
        
        if (rfcLangTy == null) {
            rfcLangTy = RfcJCoDest.PC_EN;
        }
        return rfcLangTy.getDestination();
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectFunction(com.mobis.maps.cmmn.vo.LoginInfoVO, java.lang.String)
     */
    @Override
    public Function selectFunction(LoginInfoVO loginInfo, String rfcId) throws Exception {
        
        return selectFunction(loginInfo, rfcId, RfcSapSys.PC);
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectFunction(com.mobis.maps.cmmn.vo.LoginInfoVO, java.lang.String, boolean)
     */
    @Override
    public Function selectFunction(LoginInfoVO loginInfo, String rfcId , boolean debugYn) throws Exception {
        return selectFunction(loginInfo, rfcId, RfcSapSys.PC , debugYn);
    }
    
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectFunction(com.mobis.maps.cmmn.vo.LoginInfoVO, java.lang.String, com.mobis.maps.comm.constants.RfcSapSys)
     */
    @Override
    public Function selectFunction(LoginInfoVO loginInfo, String rfcId, RfcSapSys rfcSapSys) throws Exception {
        // Destination 생성
        Destination destination = selectDestination(loginInfo, rfcSapSys);
        // RFC 생성
        Function function = destination.getFunction(rfcId);
        return function;
    }
    
    
    @Override
    public Function selectFunction(LoginInfoVO loginInfo, String rfcId, RfcSapSys rfcSapSys , boolean debugYn) throws Exception {
        // Destination 생성
        Destination destination = selectDestination(loginInfo, rfcSapSys);
        // RFC 생성
        Function function = destination.getFunction(rfcId);
        // debug 정보 출력
        if(debugYn ){
            SapJcoDebugUtil.printFunctionMetaInfo(function.getJcoFunction() );
        }
        return function;
    }
    
    
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectSetRfcIfComm(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.sapjco.manager.Function, com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO)
     */
    @Override
    public void selectSetRfcIfComm(LoginInfoVO loginInfo, Function function, MapsCommSapRfcIfCommVO commSapRfcIfCommVO) throws Exception {
        /* 로그인정보 설정 */
        String now = DateUtil.getCurrentDateTime("yyyyMMddHHmmss");
        Date nowDate = DateUtil.stringToDate(now.substring(0, 8), "yyyyMMdd");
        String sNowTime = now.substring(8);
//        Date nowTime = DateUtil.stringToDate(now.substring(8), "HHmmss");
        
        String localDt = "";
        //TODO 넥사크로 관련 디펜던시 제거 ==> local time가져오는 부분은 넥사크로/miplatform등에 디펜던시 존재
        if( NexacroUtil.getGdsLocalDt() != null ){
            localDt = DateUtil.toString(NexacroUtil.getGdsLocalDt(), "yyyyMMddHHmmss", loginInfo.getUserLcale());
        }else{
            localDt = DateUtil.getCurrentDateTime("yyyyMMddHHmmss");
        }
        Date localDate = DateUtil.stringToDate(localDt.substring(0, 8), "yyyyMMdd");
        String sLocalTime = localDt.substring(8);
//        Date localTime = DateUtil.stringToDate(localDt.substring(8), "HHmmss");

        commSapRfcIfCommVO.setVkorg(loginInfo.getBsnOrgnztCd());    // 영업조직
        commSapRfcIfCommVO.setBukRs(loginInfo.getBsnOrgnztCd());    // 회사코드
        commSapRfcIfCommVO.setTzone(loginInfo.getRfcTzone());       // 사용자시간대(채널)
        commSapRfcIfCommVO.setSpras(loginInfo.getRfcLang());        // 사용자언어(채널)
        commSapRfcIfCommVO.setZcrname(StringUtils.left(loginInfo.getUserId(), 12));    // Create User
        commSapRfcIfCommVO.setZcrsdate(nowDate);                    // Create System Date
        commSapRfcIfCommVO.setZcrstime(sNowTime);                   // Create System Time //임시수정-hong
        commSapRfcIfCommVO.setZcrldate(localDate);                  // Create Local Date
        commSapRfcIfCommVO.setZcrltime(sLocalTime);                 // Create Local Time //임시수정-hong
        commSapRfcIfCommVO.setZusrnm(loginInfo.getUserNm());        // Channel사용자이름
        commSapRfcIfCommVO.setZiamid(loginInfo.getUserSeqId());     // IAM 식별자
        commSapRfcIfCommVO.setZchnsysid(loginInfo.getSysSeCd());    // Channel System ID
        commSapRfcIfCommVO.setZchnid(loginInfo.getUserId());        // Channel Login ID
        
        /* RFC호출 공통정보 설정 */
        JCoStructure jsIfComm = function.getImportStructure("IS_IFCOMM");
        jsIfComm.setValue("IFCODE", commSapRfcIfCommVO.getIfCode());        // 인터페이스ID
        jsIfComm.setValue("TIMESTAMP_I", now);                              // Import Timestamp (YYYYMMDDhhmmss)
        jsIfComm.setValue("BUKRS", commSapRfcIfCommVO.getBukRs());          // 회사코드
        jsIfComm.setValue("VKORG", commSapRfcIfCommVO.getVkorg());          // 영업조직
        jsIfComm.setValue("SPRAS", commSapRfcIfCommVO.getSpras());          // 사용자언어(채널)
        jsIfComm.setValue("TZONE", commSapRfcIfCommVO.getTzone());          // 사용자시간대(채널)
        jsIfComm.setValue("ZCRNAME", commSapRfcIfCommVO.getZcrname());      // Create User
        jsIfComm.setValue("ZCRSDATE", commSapRfcIfCommVO.getZcrsdate());    // Create System Date
        jsIfComm.setValue("ZCRSTIME", commSapRfcIfCommVO.getZcrstime());    // Create System Time
        jsIfComm.setValue("ZCRLDATE", commSapRfcIfCommVO.getZcrldate());    // Create Local Date
        jsIfComm.setValue("ZCRLTIME", commSapRfcIfCommVO.getZcrltime());    // Create Local Time
        jsIfComm.setValue("ZUSRNM", commSapRfcIfCommVO.getZusrnm());        // Channel사용자이름
        jsIfComm.setValue("ZIAMID", commSapRfcIfCommVO.getZiamid());        // IAM 식별자
        jsIfComm.setValue("ZCHNSYSID", commSapRfcIfCommVO.getZchnsysid());  // Channel System ID
        jsIfComm.setValue("ZCHNID", commSapRfcIfCommVO.getZchnid());        // Channel Login ID
        
        /* RFC호출 페이징정보 설정 */
        if (StringUtils.equals(commSapRfcIfCommVO.getPgType(), "S")) {
            jsIfComm.setValue("PGCNUM", commSapRfcIfCommVO.getScrollPgNum());   // 현재페이지번호
            jsIfComm.setValue("PGSIZE", commSapRfcIfCommVO.getScrollPgSize());  // 페이징사이즈
        } else if (StringUtils.equals( commSapRfcIfCommVO.getPgType(), "P")) {
            jsIfComm.setValue("PGCNUM", commSapRfcIfCommVO.getPgNum());         // 현재페이지번호
            jsIfComm.setValue("PGSIZE", commSapRfcIfCommVO.getPgSize());        // 페이징사이즈
        }
        if (StringUtils.equals(commSapRfcIfCommVO.getExcelDwnlYn(), "Y")) {
            jsIfComm.setValue("PGCNUM", 1);                                     // 현재페이지번호
            jsIfComm.setValue("PGSIZE", commSapRfcIfCommVO.getTotMaxCnt());     // 페이징사이즈
        }
        /* 사용자언어 설정 */
        commSapRfcIfCommVO.setLcale(loginInfo.getUserLcale());
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectExecute(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.sapjco.manager.Function)
     */
    @Override
    public FunctionResult selectExecute(LoginInfoVO loginInfo, Function function) throws Exception {
        
        return selectExecute(loginInfo, function, true);
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectExecute(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.sapjco.manager.Function, boolean)
     */
    @Override
    public FunctionResult selectExecute(LoginInfoVO loginInfo, Function function, boolean isLog) throws Exception {

        String scrinId = NexacroUtil.getGdsScrinId();
        Random r = new Random();
        String logId = DateUtil.getCurrentDateTime("yyyyMMddHHmmssSSS") + r.nextInt(100);
        if (isLog) {
            selectExecuteLogStrt(logId, scrinId, loginInfo, function);
        }
        FunctionResult funcRslt = null;
        try {
            funcRslt = function.execute();
        } catch (Exception e) {
            selectExecuteLogException(logId, scrinId, loginInfo, function, isLog, e);
            throw e;
        }
        if (isLog) {
            selectExecuteLogEnd(logId, scrinId, loginInfo, funcRslt);
        }
        return funcRslt;
    }
    
    /**
     * RFC실행로그 시작
     *
     * @param logId
     * @param scrinId
     * @param loginInfo
     * @param function
     */
    private void selectExecuteLogStrt(String logId, String scrinId, LoginInfoVO loginInfo, Function function) {
        
        if (logger.isInfoEnabled()) {
            try {
                MDC.clear();
                String funcNm = function.getName();
                JCoParameterList importParams = function.getImportParameterList();
                if (importParams != null) {
                    JCoParameterFieldIterator pfi = importParams.getParameterFieldIterator();
                    while (pfi.hasNextField()) {
                        JCoField field = pfi.nextField();
                        String fieldNm = field.getName();
                        if (field.isTable()) {
                            MDC.put("IP|" + fieldNm + "|T", importParams.toXML(fieldNm));
                        } else if (field.isStructure()) {
                            MDC.put("IP|" + fieldNm + "|S", importParams.toXML(fieldNm));
                        } else {
                            MDC.put("IP|" + fieldNm + "|V", importParams.toXML(fieldNm));
                        }
                    }
                }
                JCoParameterList importTblParams = function.getTableParameterList();
                if (importTblParams != null) {
                    JCoFieldIterator fi = importTblParams.getFieldIterator();
                    while (fi.hasNextField()) {
                        JCoField field = fi.nextField();
                        String fieldNm = field.getName();
                        JCoTable table = importTblParams.getTable(fieldNm);
                        if (table.isEmpty()) {
                            continue;
                        }
                        MDC.put("IT|" + fieldNm + "|T", table.toXML());
                    }
                }
                logger.info("RFC[{}.{}][" + logId + "]::{}|{}|{}|{}|{}"
                        , function.getR3Name()
                        , funcNm
                        , "START"
                        , function.getMessageServerHost()
                        , function.getClient()
                        , function.getLanguage()
                        , scrinId
                        , loginInfo.getUserId()
                        , loginInfo.getLoginIpAdres()
                        );
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
    }

    /**
     * RFC실행로그 예외
     *
     * @param logId
     * @param scrinId
     * @param loginInfo
     * @param function
     * @param isLog
     * @param e
     */
    private void selectExecuteLogException(String logId, String scrinId, LoginInfoVO loginInfo, Function function, boolean isLog, Exception e) {
        if (logger.isErrorEnabled()) {
            try {
                MDC.clear();
                String funcNm = function.getName();
                if (!isLog) {
                    JCoParameterList importParams = function.getImportParameterList();
                    if (importParams != null) {
                        JCoParameterFieldIterator pfi = importParams.getParameterFieldIterator();
                        while (pfi.hasNextField()) {
                            JCoField field = pfi.nextField();
                            String fieldNm = field.getName();
                            if (field.isTable()) {
                                MDC.put("IP|" + fieldNm + "|T", importParams.toXML(fieldNm));
                            } else if (field.isStructure()) {
                                MDC.put("IP|" + fieldNm + "|S", importParams.toXML(fieldNm));
                            } else {
                                MDC.put("IP|" + fieldNm + "|V", importParams.toXML(fieldNm));
                            }
                        }
                    }
                    JCoParameterList importTblParams = function.getTableParameterList();
                    if (importTblParams != null) {
                        JCoFieldIterator fi = importTblParams.getFieldIterator();
                        while (fi.hasNextField()) {
                            JCoField field = fi.nextField();
                            String fieldNm = field.getName();
                            JCoTable table = importTblParams.getTable(fieldNm);
                            if (table.isEmpty()) {
                                continue;
                            }
                            MDC.put("IT|" + fieldNm + "|T", table.toXML());
                        }
                    }
                }
                logger.error(e.getMessage());
                logger.error("RFC[{}.{}][" + logId + "]::{}|{}|{}|{}|{}"
                        , function.getR3Name()
                        , funcNm
                        , "ERROR"
                        , function.getMessageServerHost()
                        , function.getClient()
                        , function.getLanguage()
                        , scrinId
                        , loginInfo.getUserId()
                        , loginInfo.getLoginIpAdres()
                        );
            } catch (Exception ex) {
                logger.error(ex.getMessage(), ex);
            }
        }
    }
    
    /**
     * RFC실행로그 종료
     *
     * @param logId
     * @param scrinId
     * @param loginInfo
     * @param funcRslt
     */
    private void selectExecuteLogEnd(String logId, String scrinId, LoginInfoVO loginInfo, FunctionResult funcRslt) {
        
        if (logger.isInfoEnabled()) {
            String profileStage = StringUtils.defaultString(PropertiesUtil.getString("profile.stage") , "DEV" );
            try {
                MDC.clear();
                String funcNm = funcRslt.getName();
                JCoParameterList exportParams = funcRslt.getExportParameterList();
                if (exportParams != null) {
                    JCoParameterFieldIterator pfi = exportParams.getParameterFieldIterator();
                    while (pfi.hasNextField()) {
                        JCoField field = pfi.nextField();
                        String fieldNm = field.getName();
                        if (field.isTable()) {
                            MDC.put("EP|" + fieldNm + "|T", exportParams.toXML(fieldNm));
                        } else if (field.isStructure()) {
                            MDC.put("EP|" + fieldNm + "|S", exportParams.toXML(fieldNm));
                        } else {
                            MDC.put("EP|" + fieldNm + "|V", exportParams.toXML(fieldNm));
                        }
                    }
                }
                JCoParameterList exportTblParams = funcRslt.getTableParameterList();
                if (exportTblParams != null) {
                    JCoFieldIterator fi = exportTblParams.getFieldIterator();
                    while (fi.hasNextField()) {
                        JCoField field = fi.nextField();
                        String fieldNm = field.getName();
                        JCoTable table = exportTblParams.getTable(fieldNm);
                        if (table.isEmpty()) {
                            continue;
                        }
                        // 운영환경인 경우 OUTPUT 테이블은 db에 insert 하지 않고 PRODUCTION Enviroment Data skip.
                        // 메시지만 남긴다.
                        if( StringUtils.equals( profileStage , WebUtil.SERVER_PROFILE_PRODUCTION) ){
                            MDC.put("ET||" + fieldNm + "|T", "PRODUCTION Enviroment Data skip.");
                        }else{
                            MDC.put("ET||" + fieldNm + "|T", table.toXML());
                        }
                    }
                }
                logger.info("RFC[{}.{}][" + logId + "]::{}|{}|{}|{}|{}"
                        , funcRslt.getR3Name()
                        , funcNm
                        , "END"
                        , funcRslt.getMessageServerHost()
                        , funcRslt.getClient()
                        , funcRslt.getLanguage()
                        , scrinId
                        , loginInfo.getUserId()
                        , loginInfo.getLoginIpAdres()
                        );
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectSetRfcResult(com.mobis.maps.sapjco.manager.FunctionResult, com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO)
     */
    @Override
    public void selectSetRfcResult(FunctionResult funcResult, MapsCommSapRfcIfCommVO commSapRfcIfCommVO) throws Exception {

        JCoStructure resReturn = funcResult.getExportStructure("ES_RETURN");
        // 파라미터(Export, Tables) 출력
        commSapRfcIfCommVO.setMsgType(resReturn.getString("MTYPE"));
        commSapRfcIfCommVO.setMsgId(resReturn.getString("MSGID"));
        commSapRfcIfCommVO.setMsgNo(resReturn.getString("MSGNO"));
        commSapRfcIfCommVO.setMsg(resReturn.getString("MESSAGE"));
        
        if (StringUtils.equals(commSapRfcIfCommVO.getPgType(), "S") || StringUtils.equals(commSapRfcIfCommVO.getPgType(), "P")) {
            String sTotCnt = StringUtils.trim(StringUtils.defaultString(resReturn.getString("TOTCNT"), "0"));
            if (NumberUtils.isNumber(sTotCnt)) {
                int totCnt = Integer.parseInt(sTotCnt);
                //logger.debug("→ selectGetRfcResult::resReturn[totCnt="+totCnt+"]");
                commSapRfcIfCommVO.setTotCnt(totCnt);
            }
        }
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectGetExportTablePgVO(com.mobis.maps.sapjco.manager.FunctionResult, com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO, java.lang.String, java.lang.Class)
     */
    @Override
    public <T> List<T> selectGetExportTablePgVO(FunctionResult result
            , MapsCommSapRfcIfCommVO commSapRfcIfCommVO
            , String rfcField
            , Class<? extends T> exportClass) throws Exception {
        
        // 파라미터(TABLES) 추출
        List<Map<String, Object>> lstData = result.getTable(rfcField);

        List<T> lstResult = new ArrayList<>();
        int rcnt = 0;
        int rnum = commSapRfcIfCommVO.getStrtRnum();
        for (Map<String, Object> tmpData : lstData) {
            T objData = exportClass.newInstance();
            if (rcnt == 0) {
                BeanUtils.setProperty(objData, "totCnt", commSapRfcIfCommVO.getTotCnt());
            }
            BeanUtils.setProperty(objData, "rnum", rnum);
            
            MapsRfcMappperUtil.setExportTableValue(rfcField, tmpData, objData);
            
            lstResult.add(objData);
            rcnt++;
            rnum++;
        }
        
        return lstResult;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectGetPgExportTable(com.mobis.maps.sapjco.manager.FunctionResult, com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO, java.lang.String, java.util.Map, java.lang.Class)
     */
    @Override
    public <T> List<T> selectGetExportTablePgVO(FunctionResult result
            , MapsCommSapRfcIfCommVO commSapRfcIfCommVO
            , String rfcField
            , Map<String, String> mapngInfo
            , Class<? extends T> exportClass) throws Exception {
        
        // 파라미터(TABLES) 추출
        List<Map<String, Object>> lstData = result.getTable(rfcField);

        List<T> lstResult = new ArrayList<>();
        int rcnt = 0;
        int rnum = commSapRfcIfCommVO.getStrtRnum();
        for (Map<String, Object> tmpData : lstData) {
            T objData = exportClass.newInstance();
            if (rcnt == 0) {
                BeanUtils.setProperty(objData, "totCnt", commSapRfcIfCommVO.getTotCnt());
            }
            BeanUtils.setProperty(objData, "rnum", rnum);
            
            Iterator<String>  i = mapngInfo.keySet().iterator();
            while (i.hasNext()) {
                String field = i.next();
                String name = mapngInfo.get(field);
                Object value = tmpData.get(field);
                BeanUtils.setProperty(objData, name, value);
            }
            lstResult.add(objData);
            rcnt++;
            rnum++;
        }
        
        return lstResult;
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectGetExportTablePgMap(com.mobis.maps.sapjco.manager.FunctionResult, com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO, java.lang.String, java.util.Map)
     */
    @Override
    public List<Map<String, Object>> selectGetExportTablePgMap(FunctionResult result
            , MapsCommSapRfcIfCommVO commSapRfcIfCommVO
            , String rfcField
            , Map<String, String> mapngInfo) throws Exception {
        
        // 파라미터(TABLES) 추출
        List<Map<String, Object>> lstData = result.getTable(rfcField);

        List<Map<String, Object>> lstResult = new ArrayList<>();
        int rcnt = 0;
        int rnum = commSapRfcIfCommVO.getStrtRnum();
        for (Map<String, Object> tmpData : lstData) {
            Map<String, Object> mData = new HashMap<String, Object>();
            mData.putAll(tmpData);
            if (rcnt == 0) {
                mData.put("totCnt", commSapRfcIfCommVO.getTotCnt());
            }
            mData.put("rnum", rnum);
            
            Iterator<String>  i = mapngInfo.keySet().iterator();
            while (i.hasNext()) {
                String field = i.next();
                String name = mapngInfo.get(field);
                Object value = tmpData.get(field);
                mData.put(name, value);
            }
            lstResult.add(mData);
            rcnt++;
            rnum++;
        }
        
        return lstResult;
    }
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectRfcList(com.mobis.maps.cmmn.vo.LoginInfoVO, java.lang.String, java.lang.Object)
     */
    @Override
    public <T> List<T> selectRfcList(LoginInfoVO loginInfo, String rfcId, Object imprtBean) throws Exception {
        
        return selectRfcList(loginInfo, rfcId, imprtBean, null);
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapService#selectRfcList(com.mobis.maps.cmmn.vo.LoginInfoVO, java.lang.String, java.lang.Object, java.lang.Class)
     */
    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> selectRfcList(LoginInfoVO loginInfo, String rfcId, Object imprtBean, Class<? extends T> exportClass) throws Exception {
        // RFC기본정보 조회
        MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO = selectAspRfcBassInfo(rfcId);
        if (commSapRfcBassInfoVO == null) {
            // {0} 은 유효하지 않은 값입니다.
            throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC_ID"}, loginInfo.getUserLcale(), null);
        }
        // RFC 호출 공통VO 설정
        MapsCommSapRfcIfCommVO commSapRfcIfCommVO = null;
        if (imprtBean instanceof MapsCommSapRfcIfCommVO) {
            commSapRfcIfCommVO = (MapsCommSapRfcIfCommVO)imprtBean;
        } else {
            // {0} 은 유효하지 않은 값입니다.
            throw new MapsBizException(messageSource, "EC00000011", new String[]{"RFC VO"}, loginInfo.getUserLcale(), null);
        }
        /* RFC입력정보 조회 */
        List<MapsCommSapRfcIpttInfoVO> sapRfcInputInfos = selectAspRfcIpttInfoList(loginInfo, rfcId, RfcIpttSe.Import.getCode());
        //logger.debug("→ selectRfcList::sapRfcInputInfos[size=" + sapRfcInputInfos.size() + "]");
        /* RFC출력정보 조회 */
        List<MapsCommSapRfcIpttInfoVO> sapRfcOnputInfos = selectAspRfcIpttInfoList(loginInfo, rfcId, RfcIpttSe.Export.getCode());
        //logger.debug("→ selectRfcList::sapRfcInputInfos[size=" + sapRfcOnputInfos.size() + "]");

        // RFC 생성
        Function function = selectFunction(loginInfo, commSapRfcBassInfoVO.getRfcId());
        // 공통파라미터(Import) 셋팅
        selectSetRfcIfComm(loginInfo, function, commSapRfcIfCommVO);
        // 파라미터(Import) 셋팅
        for (MapsCommSapRfcIpttInfoVO commSapRfcIpttInfo: sapRfcInputInfos) {
            if (StringUtils.equals(commSapRfcIpttInfo.getDataTy(), RfcDataTy.List.getCode())) {
                String name = JdbcUtils.convertUnderscoreNameToPropertyName(commSapRfcIpttInfo.getIemId());
                Object objRfcFieldValue = BeanUtils.getProperty(imprtBean, name);
                if (objRfcFieldValue == null) {
                    continue;
                }
                if (objRfcFieldValue instanceof List) {
                    /* RFC구조체필드정보 조회 */
                    List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos = selectAspRfcStrctrFieldList(loginInfo, commSapRfcIpttInfo.getStrctrId());
                    /* 파라미터(TABLES) 추출, 적재 */
                    JCoTable jcoTbl = function.getImportTableParameter(commSapRfcIpttInfo.getRfcField());
                    for (Object rfcFieldValue: (List<?>)objRfcFieldValue) {
                        jcoTbl.appendRow();
                        for (MapsCommSapRfcStrctrFieldVO commSapRfcStrctrField: sapRfcStrctrFieldInfos) {
                            String strctrFieldName = JdbcUtils.convertUnderscoreNameToPropertyName(commSapRfcStrctrField.getIemId());
                            String strctrFieldValue = (String)BeanUtils.getProperty(rfcFieldValue, strctrFieldName);
                            jcoTbl.setValue(commSapRfcStrctrField.getRfcField(), strctrFieldValue);
                        }
                    }
                }
            } else if (StringUtils.equals(commSapRfcIpttInfo.getDataTy(), RfcDataTy.Structure.getCode())) {
                String name = JdbcUtils.convertUnderscoreNameToPropertyName(commSapRfcIpttInfo.getIemId());
                Object objRfcFieldValue = BeanUtils.getProperty(imprtBean, name);
                /* RFC구조체필드정보 조회 */
                List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos = selectAspRfcStrctrFieldList(loginInfo, commSapRfcIpttInfo.getStrctrId());
                /* 파라미터(TABLES) 추출, 적재 */
                JCoStructure jcoStrctr = function.getImportStructure(commSapRfcIpttInfo.getRfcField());
                for (MapsCommSapRfcStrctrFieldVO commSapRfcStrctrField: sapRfcStrctrFieldInfos) {
                    String strctrFieldName = JdbcUtils.convertUnderscoreNameToPropertyName(commSapRfcStrctrField.getIemId());
                    String strctrFieldValue = (String)BeanUtils.getProperty(objRfcFieldValue, strctrFieldName);
                    jcoStrctr.setValue(commSapRfcStrctrField.getRfcField(), strctrFieldValue);
                }
            } else {
                String name = JdbcUtils.convertUnderscoreNameToPropertyName(commSapRfcIpttInfo.getIemId());
                String rfcFieldValue = (String)BeanUtils.getProperty(imprtBean, name);
                function.getImportParameterList().setValue(commSapRfcIpttInfo.getRfcField(), rfcFieldValue);
            }
        }
        
        // RFC 호출
        FunctionResult result = function.execute();
        // 파라미터(Export) 추출
        selectSetRfcResult(result, commSapRfcIfCommVO);
        // 결과(Export Tables) 설정
        List<T> lstResult = null;
        for (MapsCommSapRfcIpttInfoVO commSapRfcIpttInfo: sapRfcOnputInfos) {
            if (!StringUtils.equals(commSapRfcIpttInfo.getDataTy(), RfcDataTy.List.getCode())) {
                continue;
            }
            //
            String rfcFieldId = commSapRfcIpttInfo.getRfcField();
            /* RFC구조체필드정보 */
            List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos = selectAspRfcStrctrFieldList(loginInfo, commSapRfcIpttInfo.getStrctrId());
            //logger.debug("→ selectRfcList::sapRfcStrctrFieldInfos[size=" + sapRfcStrctrFieldInfos.size() + "]");
            Map<String, String> mapngInfo = new HashMap<String, String>();
            for (MapsCommSapRfcStrctrFieldVO commSapRfcStrctrField: sapRfcStrctrFieldInfos) {
                String fieldId = commSapRfcStrctrField.getRfcField();
                String name = JdbcUtils.convertUnderscoreNameToPropertyName(commSapRfcStrctrField.getIemId());
                mapngInfo.put(fieldId, name);
            }

            if (exportClass != null) {
                lstResult = selectGetExportTablePgVO(result, commSapRfcIfCommVO, rfcFieldId, mapngInfo, exportClass);
            } else {
                lstResult = (List<T>) selectGetExportTablePgMap(result, commSapRfcIfCommVO, rfcFieldId, mapngInfo);
            }
        }
        
        return lstResult;
    }
    
    /**
     * RFC 기본정보 조회
     *
     * @param rfcId
     * @return
     * @throws Exception
     */
    private MapsCommSapRfcBassInfoVO selectAspRfcBassInfo(String rfcId) throws Exception {

        MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO = new MapsCommSapRfcBassInfoVO();
        commSapRfcBassInfoVO.setRfcId(rfcId);
        
        MapsCommSapRfcBassInfoVO rsltRfcBassInfo = mapsCommSapMDAO.selectAspRfcBassInfo(commSapRfcBassInfoVO);
        
        return rsltRfcBassInfo;
    }
    
    /**
     * RFC 입출력정보리스트 조회
     *
     * @param loginInfo
     * @param rfcId
     * @param rfcIpttSe
     * @return
     * @throws Exception
     */
    private List<MapsCommSapRfcIpttInfoVO> selectAspRfcIpttInfoList(LoginInfoVO loginInfo, String rfcId, String rfcIpttSe) throws Exception {
        
        MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO = new MapsCommSapRfcIpttInfoVO();
        commSapRfcIpttInfoVO.setRfcId(rfcId);
        commSapRfcIpttInfoVO.setRfcIpttSe(rfcIpttSe);
        commSapRfcIpttInfoVO.setLangCd(loginInfo.getUserLcale().toString());
        commSapRfcIpttInfoVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        
        List<MapsCommSapRfcIpttInfoVO> lstRfcIpttInfo = mapsCommSapMDAO.selectAspRfcIpttInfoList(commSapRfcIpttInfoVO);
        
        return lstRfcIpttInfo;
    }
    
    /**
     * RFC 구조체필드리스트 조회
     *
     * @param loginInfo
     * @param strctrId
     * @return
     * @throws Exception
     */
    private List<MapsCommSapRfcStrctrFieldVO> selectAspRfcStrctrFieldList(LoginInfoVO loginInfo, String strctrId) throws Exception {
        
        MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO = new MapsCommSapRfcStrctrFieldVO();
        commSapRfcStrctrFieldVO.setStrctrId(strctrId);
        commSapRfcStrctrFieldVO.setLangCd(loginInfo.getUserLcale().toString());
        commSapRfcStrctrFieldVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        
        List<MapsCommSapRfcStrctrFieldVO> lstRfcStrctrFieldInfo = mapsCommSapMDAO.selectAspRfcStrctrFieldList(commSapRfcStrctrFieldVO);
        
        return lstRfcStrctrFieldInfo;
    }
}
