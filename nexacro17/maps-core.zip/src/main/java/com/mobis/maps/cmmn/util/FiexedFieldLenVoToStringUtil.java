package com.mobis.maps.cmmn.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.mobis.maps.cmmn.vo.FixedFieldLenVO;
import com.mobis.maps.cmmn.vo.FixedFieldTestVO;
import com.mobis.maps.cmmn.vo.InvoiceFileInfoTestVO;



/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FiexedFieldLenTxtFileUtil.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 2. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 21.     oh.dongwon     	최초 생성
 * </pre>
 */

public class FiexedFieldLenVoToStringUtil {
    
    
    
    /**
     * field 딜리미터 
     */
    private String fieldFillDelim = " ";
    
    /**
     * row 간의 딜리미터
     */
    private String rowDelim = "\r\n";
    
    
    /**
     * String array로 입력된것을 vo의 arraylist로 정규화
     *
     * @param rowDelim
     */
    private void doMakeDefinition() {
        if( this.definition == null ){
            return;
        }
        String[] rowDelim = this.definition;
        for(int  i = 0 ; i < rowDelim.length; i++){
            String val = rowDelim[i];
            
            String[] splitVal  = StringUtils.split(val , ",");
            // obj명 추출
            String objName = splitVal[0];
            
            // start loc, end loc추출
            String startEndVal = splitVal[1];
            String[] startEndValDelim = StringUtils.split(startEndVal , "~");
            int start = Integer.parseInt(startEndValDelim[0]);
            int end = Integer.parseInt(startEndValDelim[1]);
            
            // arraylist방식으로 추출
            FixedFieldLenVO vo = new FixedFieldLenVO();
            vo.setObjName(objName);
            vo.setStart(start);
            vo.setEnd(end);
            
            if (splitVal.length > 2) {
                vo.setFieldType(splitVal[2]); // Field Type
            }            
            
            definionList.add(vo);
        }
    }
    
    
    /**
     * o의 인자로 문자열 리턴
     *
     * @param o
     * @param desc
     * @return
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws NoSuchMethodException
     */
    private static String doOneLine(Object o , FixedFieldLenVO desc) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException{
        String strVal = org.apache.commons.beanutils.BeanUtils.getProperty(o, desc.getObjName());
        if (strVal == null || "null".equals(strVal.toLowerCase())) strVal = "";
        
        return strVal;
    }
    
    /**
     * List<T> c로 실제 문자열 생성
     *
     * @param lst
     * @return
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws NoSuchMethodException
     */
    public  <T> String getFiexedFieldTxt( List<T> lst ) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException{
        StringBuffer sBuf = new StringBuffer();
        SimpleDateFormat dformatter = new SimpleDateFormat("yyyyMMdd");
        
        doMakeDefinition();
        
        List<FixedFieldLenVO> definitionList = this.definionList;
        
        if (lst == null) {
            return "";
        }
        
        if (definitionList == null) {
            return "";
        }
        
        for (int idx = 0; idx < lst.size(); idx++) {
            T objData = lst.get(idx);
            for (int nCol = 0; nCol < definitionList.size(); nCol++) {
                FixedFieldLenVO definitionVO = definitionList.get(nCol);
                // String objectName = definitionVO.getObjName();
                String objectValue = doOneLine(objData, definitionVO);
                int fieldLen = definitionVO.getEnd() - definitionVO.getStart();
                
                if ("number".equals(definitionVO.getFieldType())) {
                    BigDecimal nVal = new BigDecimal(objectValue);
                    objectValue = nVal.setScale(0, 1).toString();
                    objectValue = StringUtils.leftPad(objectValue, fieldLen, "0");

                } else if ("curr".equals(definitionVO.getFieldType())) {
                    BigDecimal nVal = new BigDecimal(objectValue);
                    nVal = nVal.multiply(BigDecimal.valueOf(100));
                    objectValue = nVal.setScale(0, 1).toString();
                    objectValue = StringUtils.leftPad(objectValue, fieldLen, "0");
                    
                } else if ("date".equals(definitionVO.getFieldType())) {
                    StringBuffer sGetterNm = new StringBuffer();
                    sGetterNm.append("get").append(definitionVO.getObjName().substring(0, 1).toUpperCase())
                            .append(definitionVO.getObjName().substring(1));
                    
                    Method getter = objData.getClass().getMethod(sGetterNm.toString(), new Class[]{});
                    Date dt = (Date)getter.invoke(objData, (Object[])null);
                    
                    objectValue = dformatter.format(dt);
                    objectValue = StringUtils.rightPad(objectValue, fieldLen, fieldFillDelim);
                
                } else {
                    objectValue = StringUtils.rightPad(objectValue, fieldLen, fieldFillDelim);
                }
                
                if (objectValue.length() > fieldLen) {
                    objectValue = objectValue.substring(0, fieldLen);
                }
                
                sBuf.append(objectValue);
                
                if (nCol == (definitionList.size() - 1)) {
                    sBuf.append(rowDelim);
                }
            }
        }
        
        return sBuf.toString();
    }
    
    /**
     * Statements
     *
     * @param args
     * @throws IOException 
     * @throws NoSuchMethodException 
     * @throws InvocationTargetException 
     * @throws IllegalAccessException 
     */
    public static void main(String[] args) throws IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, Exception {
        
        /** util 초기화 **/
        FiexedFieldLenVoToStringUtil convertUtil = new FiexedFieldLenVoToStringUtil();
        
        /** fixed length 정의 **/
        String[] rowDefinition = new String[] {
            "invoice,0~10"             ,"invDate,10~18,date"       ,"zfptld,18~33"              ,"zfpldv,33~48"                 ,"zshptp,48~49"
           ,"zfcarnm,49~69"            ,"zfvyno,69~75"             ,"zfhblno,75~90"             ,"zfobdt,90~98,date"            ,"noOfBox,98~103,number"
           ,"noOfLine,103~108,number"  ,"freCost,108~119,curr"     ,"zfobpr,119~130,curr"       ,"contNum,130~150"              ,"outBoxNum,150~161"
           ,"inBoxNum,161~172"         ,"zordnoE,172~182"          ,"zordln,182~186,number"     ,"zordls,186~187"               ,"zmatnrInput,187~205"
           ,"confMatnr,205~223"        ,"splyMatnr,223~241"        ,"netpr,241~248,curr"        ,"zcfmqty,248~255,number"       ,"shipQty,255~262,number"
           ,"zboqty,262~269,number"    ,"zcancqty,269~276,number"  ,"shipValue,276~285,curr"    ,"totShipQty,285~292,number"    ,"zamdcf,292~294"
           ,"land1,294~296"            ,"zweig,296~303,number"     ,"outBoxGrwei,303~308,number","outBoxNtgew,308~313,number"   ,"outBoxLeng,313~316,number"
           ,"outBoxWid,316~319,number" ,"outBoxHei,319~322,number" ,"inBoxGrwei,322~327,number" ,"inBoxNtgew,327~332,number"    ,"inBoxLeng,332~335,number"
           ,"inBoxWid,335~338,number"  ,"inBoxHei,338~341,number"  ,"ccngn,341~351"             ,"intTrade,351~352"             ,"zfcifamt,352~361,curr"
        };
        convertUtil.setDefinition(rowDefinition);
        
        // *** field 딜리미터 설정 (입력하지 않으면 " " 스페이스문자)
        convertUtil.setFieldFillDelim(" ");
        
        // *** row 의 식별인자 (입력하지 않으면 "\r\n"
        convertUtil.setRowDelim("\r\n");
        
        // 샘플 vo list구성
//        List<FixedFieldTestVO> sampleList = sampleList();
        List<InvoiceFileInfoTestVO> sampleList2 = sampleList2();
        /** 
         *  실제 구성된 txt파일 리턴
         **/        
        String rtn = convertUtil.getFiexedFieldTxt(sampleList2);
        
        System.out.println(rtn);
    }

    /**
     * Statements
     *
     * @return
     */
    private static List<FixedFieldTestVO> sampleList() {
        List<FixedFieldTestVO> fixedFieldTestVOs = new ArrayList<FixedFieldTestVO>();
        FixedFieldTestVO vo = new FixedFieldTestVO();
        vo.setId("1id");
        vo.setName("1name");
        vo.setAddress("1address");
        vo.setTelNo("1telno");
        fixedFieldTestVOs.add(vo);
        
        vo = new FixedFieldTestVO();
        vo.setId("2한글다라마바사abcd");
        vo.setName("2name");
        vo.setAddress("2address");
        vo.setTelNo("2telno");
        fixedFieldTestVOs.add(vo);
        
        vo = new FixedFieldTestVO();
        vo.setId("3id");
        vo.setName("3name");
        vo.setAddress("3address");
        vo.setTelNo("3telno");
        fixedFieldTestVOs.add(vo);
        return fixedFieldTestVOs;
    }
    
    private static List<InvoiceFileInfoTestVO> sampleList2() throws Exception {
        List<InvoiceFileInfoTestVO> lst = new ArrayList<>();
        
        SimpleDateFormat dtFormat = new SimpleDateFormat("yyyyMMdd");
        
        InvoiceFileInfoTestVO vo = new InvoiceFileInfoTestVO();
        vo.setInvoice("A0A00487");
        vo.setInvDate(dtFormat.parse("20200111"));
        vo.setZfptld("SEOUL(INCHEON),");
        vo.setZfpldv("SANTIAGO, CHILE");
        vo.setZshptp("A");
        vo.setZfcarnm("NH");
        vo.setZfvyno("868");
        vo.setZfhblno("SEL0534561");
        vo.setZfobdt(dtFormat.parse("20200114"));
        vo.setNoOfBox(new BigDecimal("4"));
        vo.setNoOfLine(new BigDecimal("13"));
        vo.setFreCost(new BigDecimal("0"));
        vo.setZfobpr(new BigDecimal("584.99"));
        vo.setContNum("");
        vo.setOutBoxNum("AW001007028");
        vo.setInBoxNum("");
        vo.setZordnoE("B07ABX0AAE");
        vo.setZordln("0008");
        vo.setZordls("");
        vo.setZmatnrInput("571003J100");
        vo.setConfMatnr("571003J100");
        vo.setSplyMatnr("571003J100");
        vo.setNetpr(new BigDecimal("108.03"));
        vo.setZcfmqty(new BigDecimal("1"));
        vo.setShipQty(new BigDecimal("1"));
        vo.setZboqty(new BigDecimal("0"));
        vo.setZcancqty(new BigDecimal("0"));
        vo.setShipValue(new BigDecimal("108.03"));
        vo.setTotShipQty(new BigDecimal("0"));
        vo.setZamdcf("");
        vo.setLand1("KR");
        vo.setZweig(new BigDecimal("2"));
        vo.setOutBoxGrwei(new BigDecimal("8"));
        vo.setOutBoxNtgew(new BigDecimal("7"));
        vo.setOutBoxLeng(new BigDecimal("60"));
        vo.setOutBoxWid(new BigDecimal("40"));
        vo.setOutBoxHei(new BigDecimal("40"));
        vo.setInBoxGrwei(new BigDecimal("0"));
        vo.setInBoxNtgew(new BigDecimal("0"));
        vo.setInBoxLeng(new BigDecimal("0"));
        vo.setInBoxWid(new BigDecimal("0"));
        vo.setInBoxHei(new BigDecimal("0"));
        vo.setCcngn("8413609090");
//        vo.setInt("");
        vo.setZfcifamt(new BigDecimal("0"));
        
        lst.add(vo);

        vo = new InvoiceFileInfoTestVO();
        vo.setInvoice("A0A00487");
        vo.setInvDate(dtFormat.parse("20200111"));
        vo.setZfptld("SEOUL(INCHEON),");
        vo.setZfpldv("SANTIAGO, CHILE");
        vo.setZshptp("A");
        vo.setZfcarnm("NH");
        vo.setZfvyno("868");
        vo.setZfhblno("SEL0534561");
        vo.setZfobdt(dtFormat.parse("20200114"));
        vo.setNoOfBox(new BigDecimal("4"));
        vo.setNoOfLine(new BigDecimal("13"));
        vo.setFreCost(new BigDecimal("0"));
        vo.setZfobpr(new BigDecimal("584.99"));
        vo.setContNum("");
        vo.setOutBoxNum("AW001007028");
        vo.setInBoxNum("");
        vo.setZordnoE("B07ABX0AAE");
        vo.setZordln("0008");
        vo.setZordls("");
        vo.setZmatnrInput("571003J100");
        vo.setConfMatnr("571003J100");
        vo.setSplyMatnr("571003J100");
        vo.setNetpr(new BigDecimal("108.03"));
        vo.setZcfmqty(new BigDecimal("1"));
        vo.setShipQty(new BigDecimal("1"));
        vo.setZboqty(new BigDecimal("0"));
        vo.setZcancqty(new BigDecimal("0"));
        vo.setShipValue(new BigDecimal("108.03"));
        vo.setTotShipQty(new BigDecimal("0"));
        vo.setZamdcf("");
        vo.setLand1("KR");
        vo.setZweig(new BigDecimal("2"));
        vo.setOutBoxGrwei(new BigDecimal("8"));
        vo.setOutBoxNtgew(new BigDecimal("7"));
        vo.setOutBoxLeng(new BigDecimal("60"));
        vo.setOutBoxWid(new BigDecimal("40"));
        vo.setOutBoxHei(new BigDecimal("40"));
        vo.setInBoxGrwei(new BigDecimal("0"));
        vo.setInBoxNtgew(new BigDecimal("0"));
        vo.setInBoxLeng(new BigDecimal("0"));
        vo.setInBoxWid(new BigDecimal("0"));
        vo.setInBoxHei(new BigDecimal("0"));
        vo.setCcngn("8413609090");
//        vo.setInt("");
        vo.setZfcifamt(new BigDecimal("0"));
        
        lst.add(vo);

        
        return lst;
    }
    
    
    
    
    /**
     * @return the fieldFillDelim
     */
    public String getFieldFillDelim() {
        return fieldFillDelim;
    }

    /**
     * @param fieldFillDelim the fieldFillDelim to set
     */
    public void setFieldFillDelim(String fieldFillDelim) {
        this.fieldFillDelim = fieldFillDelim;
    }

    /**
     * @return the rowDelim
     */
    public String getRowDelim() {
        return rowDelim;
    }

    /**
     * @param rowDelim the rowDelim to set
     */
    public void setRowDelim(String rowDelim) {
        this.rowDelim = rowDelim;
    }

    private String [] definition;
    public List<FixedFieldLenVO> definionList = new ArrayList<FixedFieldLenVO>();
    
    
    /**
     * 한글 bytt length return
     *
     * @param input
     * @return
     */
    private int byteLength(String input) {
        if( StringUtils.isEmpty(input)){
            return 0;
        }
        return input.getBytes().length; 
    }

    /**
     * UTF8 ==> EUC_KR encode
     *
     * @param helloString
     * @return
     * @throws UnsupportedEncodingException 
     */
    public static String encodeEucKR(String inputStr) throws UnsupportedEncodingException{
        Charset eucKRCharset = Charset.forName("EUC-KR");
        CharBuffer sourceBuffer = CharBuffer.wrap(inputStr.toCharArray());
        ByteBuffer resultByteBuffer = eucKRCharset.encode(sourceBuffer);
        byte[] resultBytes =  resultByteBuffer.array();
        // EUC-KR 의 String 을 생성할 때, 두번째 인자값으로 인코딩 정보를 넣어준다.
        //return new String(resultBytes);
        return new String(resultBytes, eucKRCharset);
        // 만약 인코딩 정보를 넣지 않는다면 에러 스트링이(�, 0xfffd) 이 출력될 것이다. 
    }

    public static String encodeUtf8(String inputStr) throws UnsupportedEncodingException{
        
        Charset utf8Charset = Charset.forName("UTF-8");
        CharBuffer sourceBuffer = CharBuffer.wrap(inputStr.toCharArray());
        ByteBuffer resultByteBuffer = utf8Charset.encode(sourceBuffer);
        byte[] resultBytes =  resultByteBuffer.array();
        // EUC-KR 의 String 을 생성할 때, 두번째 인자값으로 인코딩 정보를 넣어준다.
        return new String(resultBytes, utf8Charset);
        // 만약 인코딩 정보를 넣지 않는다면 에러 스트링이(�, 0xfffd) 이 출력될 것이다.
         
    }
    
    public static void pringBytes(String input ){
        //System.out.println("########### printByte START");
        for(byte b : input.getBytes()) {
            //System.out.println(b);
        }
        //System.out.println("########### printByte   END");
    }
    

    /**
     * @return the definition
     */
    public String[] getDefinition() {
        return definition;
    }

    /**
     * @param definition the definition to set
     */
    public void setDefinition(String[] definition) {
        this.definition = definition;
    }

}
