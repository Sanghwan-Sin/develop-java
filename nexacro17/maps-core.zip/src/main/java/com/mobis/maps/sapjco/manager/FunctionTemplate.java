package com.mobis.maps.sapjco.manager;

import com.mobis.maps.cmmn.exception.MapsRuntimeException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.JCoListMetaData;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FunctionTemplate.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 5. 8.     DT045877     	최초 생성
 * </pre>
 */
public class FunctionTemplate {
    
    final JCoDestination destination;
    final JCoFunctionTemplate jCoFunctionTemplate;

    /**
     * use SapManagerBuilder
     * @param jCoFunctionTemplate
     */
    FunctionTemplate(JCoDestination destination, JCoFunctionTemplate jCoFunctionTemplate) {
        this.destination = destination;
        this.jCoFunctionTemplate = jCoFunctionTemplate;
    }

    /**
     * get function
     * @return
     */
    public Function getFunction() {
        JCoFunction jCoFunction = jCoFunctionTemplate.getFunction();
        if (jCoFunction == null) {
            throw new MapsRuntimeException("function `"+jCoFunctionTemplate.getName()+"` not found");
        }
        return new Function(destination, jCoFunction);
    }
    
    public FunctionResult getFunctionResult() {
        JCoFunction jCoFunction = jCoFunctionTemplate.getFunction();
        if (jCoFunction == null) {
            throw new MapsRuntimeException("function `"+jCoFunctionTemplate.getName()+"` not found");
        }
        return new FunctionResult(jCoFunction, destination);
    }

    public JCoListMetaData getImportParameterList() {
         return jCoFunctionTemplate.getImportParameterList();
    }
    
    public JCoListMetaData getChangingParameterList() {
        return jCoFunctionTemplate.getChangingParameterList();
    }
    
    public JCoListMetaData getExportParameterList() {
        return jCoFunctionTemplate.getExportParameterList();
    }
    
    public JCoListMetaData getTableParameterList() {
        return jCoFunctionTemplate.getTableParameterList();
    }
    
    /**
     * execute all functions with threads
     * @param nThreads
     * @param list
     * @param forEach
     * @return
     */
    //
   // public <T, R> List<R> executeAllThreads(int nThreads, List<T> list, ThrowableBiFunction<Function, T, R> forEach) {
    //    return Utils.executeAllThreads(nThreads, list, e -> forEach.apply(getFunction(), e));
  //  }

    /**
     * execute all functions with threads
     * <b>WARNING : </b>this method does not shutdown to ExecutorService instance
     * @param executorService
     * @param list
     * @param forEach
     * @return
     */
   // public <T, R> List<R> executeAllThreads(ExecutorService executorService, List<T> list, ThrowableBiFunction<Function, T, R> forEach) {
    //    return Utils.executeAllThreads(executorService, list, e -> forEach.apply(getFunction(), e));
   // }
}