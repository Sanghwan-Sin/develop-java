package com.mobis.maps.cmmn.constants;

import java.util.Locale;

/**
 * <pre>
 * MAPS상수
 * </pre>
 *
 * @ClassName   : MapsConstants.java
 * @Description : MAPS에 대한 상수를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 28.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsConstants {

    /** 세션키(로그인정보) */
    public static final String SSS_LOGIN_INFO = "loginInfo";
    /** 세션키(조직정보) */
    public static final String SSS_ORGNZT_INFO = "orgnztInfo";
    /** 세션키(계정잠김로그인정보) */
    public static final String SSS_LOCK_LOGIN_INFO = "lockLoginInfo";
    /** 세션키(초기화비빌번호사용자정보) */
    public static final String SSS_INIT_PWD_USER_INFO = "initPwdUserInfo";
    /** 세션키(권한리스트) */
    public static final String SSS_AUTHOR_LIST = "authorList";
    /** 세션키(iMobis사용자ID) */
    public static final String SSS_IMOBIS_USERID = "iMobisUserId";
    /** 세션키(iMobis로케일코드) */
    public static final String SSS_IMOBIS_LOCALE_CD = "iMobisLocaleCd";
    
    
    
    /** 디폴트로케일(영어) */
    public static final Locale DFLT_LOCALE = new Locale("en", "US");
    /** 파라미터키(언어코드) */
    public static final String PARAM_KEY_LANGUAGE_CODE = "ABLE_LANGUAGE_SELECTION_PARAM";

    /** ROOT메뉴ID(=M0000000000) */
    public static final String LEVEL0_MENU_ID = "M0000000000";

    /** 메세지유형(S:성공) */
    public static final String MESSAGE_TYPE_SUCCESS = "S";
    /** 메세지유형(E:실패) */
    public static final String MESSAGE_TYPE_ERROR = "E";
    
    /** 암호최대오류건수[5회] */
    public static final String DEFAULT_PASSWORD_MAX_ERROR_COUNT = "5";

    /** 여부(Y : Yes) */
    public static final String YN_YES = "Y";
    /** 여부(Y : No) */
    public static final String YN_NO = "N";
    
    /** 변경구분(N : 기본) */
    public static final String CRUD_NORMAL = "N";
    /** 변경구분(C : 신규) */
    public static final String CRUD_CREATE = "C";
    /** 변경구분(U : 수정) */
    public static final String CRUD_UPDATE = "U";
    /** 변경구분(D : 삭제) */
    public static final String CRUD_DELETE = "D";
    
    /** 시스템구분코드(M : nMGN) */
    public static final String SYS_SE_CD_NMGN = "M";
    /** 시스템구분코드(S : SRS) */
    public static final String SYS_SE_CD_SRS = "S";
    /** 시스템구분코드(D : DCS) */
    public static final String SYS_SE_CD_DCS = "D";
    /** 시스템구분코드(P : PDA) */
    public static final String SYS_SE_CD_PDA = "P";
    /** 시스템구분코드(I : IAM) */
    public static final String SYS_SE_CD_IAM = "I";
    /** 시스템구분코드(H : HDS) */
    public static final String SYS_SE_CD_HDS = "H";
    /** 시스템구분코드(T : DDS) */
    public static final String SYS_SE_CD_DDS = "T";
    /** 시스템구분코드(R : WF) */
    public static final String SYS_SE_CD_WF = "R";

    /** 조직구분코드(M : 모비스본사) */
    public static final String ORGNZT_SE_CD_MOBIS = "M";
    /** 조직구분코드(C : 모비스법인) */
    public static final String ORGNZT_SE_CD_CORPORATION = "C";
    /** 조직구분코드(C : 일반대리점) */
    public static final String ORGNZT_SE_CD_GENERAL_DISTRIBUTORS = "G";
    /** 조직구분코드(N : 국내외협력업체) */
    public static final String ORGNZT_SE_CD_VENDOR = "N";
    /** 조직구분코드(D: 직배대리점) */
    public static final String ORGNZT_SE_CD_DIRECT_DISTRIBUTORS = "D";
    /** 조직구분코드(E : 직배딜러) */
    public static final String ORGNZT_SE_CD_DIRECT_DEALER = "E";
    /** 조직구분코드(P : PDA) */
    public static final String ORGNZT_SE_CD_PDA = "P";

    /** 모비스법인(1000 : 모비스본사) */
    public static final String BSN_ORGNZT_CD_MOBIS = "1000";
    
    /** 행구분(N : 기본) */
    public static final String ROW_SE_NORMAL = "N";
    /** 행구분(C : 신규) */
    public static final String ROW_SE_CREATE = "I";
    /** 행구분(U : 수정) */
    public static final String ROW_SE_UPDATE = "U";
    /** 행구분(D : 삭제) */
    public static final String ROW_SE_DELETE = "D";
}
