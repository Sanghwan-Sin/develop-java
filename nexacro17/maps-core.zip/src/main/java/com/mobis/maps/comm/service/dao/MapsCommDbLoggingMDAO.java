package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommDbLoggingEventPropVO;
import com.mobis.maps.comm.vo.MapsCommDbLoggingEventVO;

/**
 * <pre>
 * DB Logging 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsCommDbLoggingMDAO.java
 * @Description : DB Logging에 대한 데이터를 처리.
 * @author DT048058
 * @since 2019. 12. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 30.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsCommDbLoggingMDAO")
public interface MapsCommDbLoggingMDAO {

    /**
     * DB Loggin Event 페이징 리스트 조회
     *
     * @param loggingEventVO
     * @return
     * @throws Exception
     */
    public List<MapsCommDbLoggingEventVO> selectDbLoggingEventPgList(MapsCommDbLoggingEventVO dbLoggingEventVO) throws Exception;

    /**
     * DB Loggin Event Property 리스트 조회
     *
     * @param loggingEventVO
     * @return
     * @throws Exception
     */
    public List<MapsCommDbLoggingEventPropVO> selectDbLoggingEventPropertyList(MapsCommDbLoggingEventVO dbLoggingEventVO) throws Exception;
    
}
