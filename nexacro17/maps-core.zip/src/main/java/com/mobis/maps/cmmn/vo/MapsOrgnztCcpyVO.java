package com.mobis.maps.cmmn.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 * MAPS 협력업체 조직정보 항목
 * </pre>
 *
 * @ClassName   : MapsOrgnztCcpyVO.java
 * @Description : MAPS 협력업체 조직정보에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 4.     DT048058     	최초 생성
 * </pre>
 */

public class MapsOrgnztCcpyVO  implements Serializable {
    
    
    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = -9209401672193475475L;
    /** SAP System */
    private String sysid;
    /** 클라이언트  */
    private String mandt;
    /** 회사 코드 */
    private String bukrs;
    /** 공급업체 또는 채권자의 계정 번호 */
    private String lifnr;
    /** 회사 코드 또는 회사 이름  */
    private String butxt;
    /** 이름 1 */
    private String name1;
    /** 이름 3 */
    private String name3;
    /** 대표 이름 */
    private String repres;
    /** 업태 */
    private String indtyp;
    /** 종목 */
    private String gestyp;
    /** 기업분류 */
    private String groupD;
    /** 세금 번호 1 */
    private String stcd1;
    /** 세금 번호 2 */
    private String stcd2;
    /** 국가키 */
    private String country;
    /** 우편번호 */
    private String postCode1;
    /** 지역(시/도, 도, 군/구) */
    private String region;
    /** 도시 */
    private String city1;
    /** 번지 */
    private String houseNum1;
    /** 상세 주소 */
    private String street;
    /** 도시 */
    private String city1En;
    /** 상세 주소 */
    private String streetEn;
    /** 업체 유형 - 부품  */
    private String vndTypeG;
    /** 업체 유형 - 도장 */
    private String vndTypeK;
    /** 업체 유형 - 포장 */
    private String vndTypeP;
    /** 업체 유형 - 용품 */
    private String vndTypeA;
    /** 업체 유형 - AM */
    private String vndTypeM;
    /** SOURCE 코드(CD-MM-40010) */
    private String zsrcCd;
    /** SOURCE 구분(CD-MM-40020) */
    private String prodType;
    /** 삭제일  */
    private String delDate;
    /** 등록일시 */
    private Date registDt;
    /**
     * @return the sysid
     */
    public String getSysid() {
        return sysid;
    }
    /**
     * @param sysid the sysid to set
     */
    public void setSysid(String sysid) {
        this.sysid = sysid;
    }
    /**
     * @return the mandt
     */
    public String getMandt() {
        return mandt;
    }
    /**
     * @param mandt the mandt to set
     */
    public void setMandt(String mandt) {
        this.mandt = mandt;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the butxt
     */
    public String getButxt() {
        return butxt;
    }
    /**
     * @param butxt the butxt to set
     */
    public void setButxt(String butxt) {
        this.butxt = butxt;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the name3
     */
    public String getName3() {
        return name3;
    }
    /**
     * @param name3 the name3 to set
     */
    public void setName3(String name3) {
        this.name3 = name3;
    }
    /**
     * @return the repres
     */
    public String getRepres() {
        return repres;
    }
    /**
     * @param repres the repres to set
     */
    public void setRepres(String repres) {
        this.repres = repres;
    }
    /**
     * @return the indtyp
     */
    public String getIndtyp() {
        return indtyp;
    }
    /**
     * @param indtyp the indtyp to set
     */
    public void setIndtyp(String indtyp) {
        this.indtyp = indtyp;
    }
    /**
     * @return the gestyp
     */
    public String getGestyp() {
        return gestyp;
    }
    /**
     * @param gestyp the gestyp to set
     */
    public void setGestyp(String gestyp) {
        this.gestyp = gestyp;
    }
    /**
     * @return the groupD
     */
    public String getGroupD() {
        return groupD;
    }
    /**
     * @param groupD the groupD to set
     */
    public void setGroupD(String groupD) {
        this.groupD = groupD;
    }
    /**
     * @return the stcd1
     */
    public String getStcd1() {
        return stcd1;
    }
    /**
     * @param stcd1 the stcd1 to set
     */
    public void setStcd1(String stcd1) {
        this.stcd1 = stcd1;
    }
    /**
     * @return the stcd2
     */
    public String getStcd2() {
        return stcd2;
    }
    /**
     * @param stcd2 the stcd2 to set
     */
    public void setStcd2(String stcd2) {
        this.stcd2 = stcd2;
    }
    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }
    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }
    /**
     * @return the postCode1
     */
    public String getPostCode1() {
        return postCode1;
    }
    /**
     * @param postCode1 the postCode1 to set
     */
    public void setPostCode1(String postCode1) {
        this.postCode1 = postCode1;
    }
    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }
    /**
     * @param region the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }
    /**
     * @return the city1
     */
    public String getCity1() {
        return city1;
    }
    /**
     * @param city1 the city1 to set
     */
    public void setCity1(String city1) {
        this.city1 = city1;
    }
    /**
     * @return the houseNum1
     */
    public String getHouseNum1() {
        return houseNum1;
    }
    /**
     * @param houseNum1 the houseNum1 to set
     */
    public void setHouseNum1(String houseNum1) {
        this.houseNum1 = houseNum1;
    }
    /**
     * @return the street
     */
    public String getStreet() {
        return street;
    }
    /**
     * @param street the street to set
     */
    public void setStreet(String street) {
        this.street = street;
    }
    /**
     * @return the city1En
     */
    public String getCity1En() {
        return city1En;
    }
    /**
     * @param city1En the city1En to set
     */
    public void setCity1En(String city1En) {
        this.city1En = city1En;
    }
    /**
     * @return the streetEn
     */
    public String getStreetEn() {
        return streetEn;
    }
    /**
     * @param streetEn the streetEn to set
     */
    public void setStreetEn(String streetEn) {
        this.streetEn = streetEn;
    }
    /**
     * @return the vndTypeG
     */
    public String getVndTypeG() {
        return vndTypeG;
    }
    /**
     * @param vndTypeG the vndTypeG to set
     */
    public void setVndTypeG(String vndTypeG) {
        this.vndTypeG = vndTypeG;
    }
    /**
     * @return the vndTypeK
     */
    public String getVndTypeK() {
        return vndTypeK;
    }
    /**
     * @param vndTypeK the vndTypeK to set
     */
    public void setVndTypeK(String vndTypeK) {
        this.vndTypeK = vndTypeK;
    }
    /**
     * @return the vndTypeP
     */
    public String getVndTypeP() {
        return vndTypeP;
    }
    /**
     * @param vndTypeP the vndTypeP to set
     */
    public void setVndTypeP(String vndTypeP) {
        this.vndTypeP = vndTypeP;
    }
    /**
     * @return the vndTypeA
     */
    public String getVndTypeA() {
        return vndTypeA;
    }
    /**
     * @param vndTypeA the vndTypeA to set
     */
    public void setVndTypeA(String vndTypeA) {
        this.vndTypeA = vndTypeA;
    }
    /**
     * @return the vndTypeM
     */
    public String getVndTypeM() {
        return vndTypeM;
    }
    /**
     * @param vndTypeM the vndTypeM to set
     */
    public void setVndTypeM(String vndTypeM) {
        this.vndTypeM = vndTypeM;
    }
    /**
     * @return the zsrcCd
     */
    public String getZsrcCd() {
        return zsrcCd;
    }
    /**
     * @param zsrcCd the zsrcCd to set
     */
    public void setZsrcCd(String zsrcCd) {
        this.zsrcCd = zsrcCd;
    }
    /**
     * @return the prodType
     */
    public String getProdType() {
        return prodType;
    }
    /**
     * @param prodType the prodType to set
     */
    public void setProdType(String prodType) {
        this.prodType = prodType;
    }
    /**
     * @return the delDate
     */
    public String getDelDate() {
        return delDate;
    }
    /**
     * @param delDate the delDate to set
     */
    public void setDelDate(String delDate) {
        this.delDate = delDate;
    }
    /**
     * @return the registDt
     */
    public Date getRegistDt() {
        return registDt;
    }
    /**
     * @param registDt the registDt to set
     */
    public void setRegistDt(Date registDt) {
        this.registDt = registDt;
    }
}
