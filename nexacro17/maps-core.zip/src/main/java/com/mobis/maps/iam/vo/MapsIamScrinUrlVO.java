package com.mobis.maps.iam.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsIamScrinUrlVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 2. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 28.     DT048058     	최초 생성
 * </pre>
 */
public class MapsIamScrinUrlVO extends MapsIamCommVO {
    
    /** 화면URL ID */
    private String scrinUrlId;
    /** 화면ID */
    private String scrinId;
    /** 화면URL구분코드 */
    private String scrinUrlSeCd;
    /** 화면URL */
    private String scrinUrl;
    
    /**
     * @return the scrinUrlId
     */
    public String getScrinUrlId() {
        return scrinUrlId;
    }
    /**
     * @param scrinUrlId the scrinUrlId to set
     */
    public void setScrinUrlId(String scrinUrlId) {
        this.scrinUrlId = scrinUrlId;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the scrinUrlSeCd
     */
    public String getScrinUrlSeCd() {
        return scrinUrlSeCd;
    }
    /**
     * @param scrinUrlSeCd the scrinUrlSeCd to set
     */
    public void setScrinUrlSeCd(String scrinUrlSeCd) {
        this.scrinUrlSeCd = scrinUrlSeCd;
    }
    /**
     * @return the scrinUrl
     */
    public String getScrinUrl() {
        return scrinUrl;
    }
    /**
     * @param scrinUrl the scrinUrl to set
     */
    public void setScrinUrl(String scrinUrl) {
        this.scrinUrl = scrinUrl;
    }
}
