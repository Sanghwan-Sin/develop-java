package com.mobis.maps.cmmn.vo;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class MessageVO {
	/** 메세지코드 */
	private String msgCd;
    /** 메세지명 */
	private String msgNm;
    /** 메세지구분 */
	private String msgSe;
    
    /**
     * toString 메소드를 대치한다.
     */
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
	
	/**
	 * @return the msgCd
	 */
	public String getMsgCd() {
		return msgCd;
	}
	/**
	 * @param msgCd the msgCd to set
	 */
	public void setMsgCd(String msgCd) {
		this.msgCd = msgCd;
	}
	/**
	 * @return the msgNm
	 */
	public String getMsgNm() {
		return msgNm;
	}
	/**
	 * @param msgNm the msgNm to set
	 */
	public void setMsgNm(String msgNm) {
		this.msgNm = msgNm;
	}
	/**
     * @return the msgSe
     */
    public String getMsgSe() {
        return msgSe;
    }
    /**
     * @param msgSe the msgSe to set
     */
    public void setMsgSe(String msgSe) {
        this.msgSe = msgSe;
    }
	
}
