package com.mobis.maps.comm.service.dao;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommScrinConectInfoVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;

/**
 * <pre>
 * 화면접속정보 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsCommScrinConectInfoMDAO.java
 * @Description : 화면접속정보에 대한 데이터 처리를 정의한다.
 * @author DT048058
 * @since 2020. 1. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 30.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsCommScrinConectInfoMDAO")
public interface MapsCommScrinConectInfoMDAO {

    /**
     * 화면정보 조회
     *
     * @param commScrinConectInfoVO
     * @return
     * @throws Exception
     */
    public MapsIamScreenVO selectScrinInfo(MapsCommScrinConectInfoVO commScrinConectInfoVO) throws Exception;
    
    /**
     * 화면접속정보 등록
     *
     * @param commScrinConectInfoVO
     * @throws Exception
     */
    public void insertScrinConectInfo(MapsCommScrinConectInfoVO commScrinConectInfoVO) throws Exception;
}
