package com.mobis.maps.comm.vo;

import java.util.List;

/**
 * <pre>
 * RFC정보 항목
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcInfoVO.java
 * @Description : RFC정보 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 23.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsCommSapRfcInfoVO extends PgBascVO {
    /* 조회조건 */
    /** SAP 시스템 ID */
    private String sysId;
    /** SAP 언어코드 */
    private String sapLangCd;
    /* RFC정보 */
    /** RFC기본정보 */
    private List<MapsCommSapRfcBassInfoVO> sapRfcBassInfos;
    /** RFC입출력정보 */
    private List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos;
    /** RFC구조체기본정보 */
    private List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos;
    /** RFC구조체필드정보 */
    private List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos;
    
    /**
     * @return the sysId
     */
    public String getSysId() {
        return sysId;
    }
    /**
     * @param sysId the sysId to set
     */
    public void setSysId(String sysId) {
        this.sysId = sysId;
    }
    /**
     * @return the sapLangCd
     */
    public String getSapLangCd() {
        return sapLangCd;
    }
    /**
     * @param sapLangCd the sapLangCd to set
     */
    public void setSapLangCd(String sapLangCd) {
        this.sapLangCd = sapLangCd;
    }
    /**
     * @return the sapRfcBassInfos
     */
    public List<MapsCommSapRfcBassInfoVO> getSapRfcBassInfos() {
        return sapRfcBassInfos;
    }
    /**
     * @param sapRfcBassInfos the sapRfcBassInfos to set
     */
    public void setSapRfcBassInfos(List<MapsCommSapRfcBassInfoVO> sapRfcBassInfos) {
        this.sapRfcBassInfos = sapRfcBassInfos;
    }
    /**
     * @return the sapRfcIpttInfos
     */
    public List<MapsCommSapRfcIpttInfoVO> getSapRfcIpttInfos() {
        return sapRfcIpttInfos;
    }
    /**
     * @param sapRfcIpttInfos the sapRfcIpttInfos to set
     */
    public void setSapRfcIpttInfos(List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos) {
        this.sapRfcIpttInfos = sapRfcIpttInfos;
    }
    /**
     * @return the sapRfcStrctrInfos
     */
    public List<MapsCommSapRfcStrctrMstVO> getSapRfcStrctrInfos() {
        return sapRfcStrctrInfos;
    }
    /**
     * @param sapRfcStrctrInfos the sapRfcStrctrInfos to set
     */
    public void setSapRfcStrctrInfos(List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos) {
        this.sapRfcStrctrInfos = sapRfcStrctrInfos;
    }
    /**
     * @return the sapRfcStrctrFieldInfos
     */
    public List<MapsCommSapRfcStrctrFieldVO> getSapRfcStrctrFieldInfos() {
        return sapRfcStrctrFieldInfos;
    }
    /**
     * @param sapRfcStrctrFieldInfos the sapRfcStrctrFieldInfos to set
     */
    public void setSapRfcStrctrFieldInfos(List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos) {
        this.sapRfcStrctrFieldInfos = sapRfcStrctrFieldInfos;
    }

}
