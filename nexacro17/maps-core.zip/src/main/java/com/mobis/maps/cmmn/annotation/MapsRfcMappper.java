package com.mobis.maps.cmmn.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsRfcMappper.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 10. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 11.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface MapsRfcMappper {
    /** Structure, Table Name[복수인경우"|"로 구분해서 입력 (예)P|IF_DATA|ET_DATA] */
    String targetName() default "P";
    /** Parameter 타겟구분명["|"로 구분해서 입력] */
    String paramTrgtNm() default "";
    /** 입출력구분[I:Import,E:Export,I|E:Import&Export] */
    String ipttSe() default "";
    /** 항목 KEY */
    String fieldKey() default "";
    /** 초기값 */
    String defaultVal() default "";
}
