package com.mobis.maps.cmmn.secure;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mobis.maps.cmmn.util.PropertiesUtil;
import SCSL.SLDsFile;

/**
 * <pre>
 * DRM 암/복호화
 * </pre>
 *
 * @ClassName   : DocPsrvUtil.java
 * @Description : DRM 암/복호화
 * @author Sin Sanghwan
 * @since 2019. 8. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 6.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Component
public class DocPsrvUtil {

    private static Logger logger = LoggerFactory.getLogger(DocPsrvUtil.class);
    
    public final static String ENC_NM = "_enc";
    public final static String DEC_NM = "_dec";

    /**
     * 암호화
     *
     * @param srcFile
     * @param dstFile
     * @return
     */
    private static int encryptScDs(String srcFile, String dstFile) {
        if (logger.isDebugEnabled()) {
            logger.debug("→ encryptScDs.start[dstFile=" + dstFile + ",srcFile=" + srcFile + "]");
        }
        int result = 0;

        String prop = PropertiesUtil.getValue("DS_SCDS_PROP");
        String keyFile = PropertiesUtil.getValue("DS_SCDS_KEY");
        if (logger.isDebugEnabled()) {
            logger.debug("→ encryptScDs.SLDsEncFileDAC[PROP=" + prop + ",,KEY=" + keyFile + "]");
        }

//        SLDsFile sFile = new SLDsFile();
//
//        sFile.SettingPathForProperty(prop);
//        sFile.SLDsInitDAC();
//        sFile.SLDsAddUserDAC("SECURITYDOMAIN", "111001100", 0, 0, 0);
//
//        result = sFile.SLDsEncFileDACV2(keyFile, "SECURITYDOMAIN", srcFile, dstFile, 1);
//        if (logger.isDebugEnabled()) {
//            logger.debug("→ encryptScDs.SLDsEncFileDAC[result=" + result + "]");
//        }

        return result;
    }

    /**
     * 복호화
     *
     * @param srcFile
     * @param dstFile
     * @return
     */
    private static int decryptScDs(String srcFile, String dstFile) {
        if (logger.isDebugEnabled()) {
            logger.debug("→ encryptScDs.start[dstFile=" + dstFile + ",[srcFile=" + srcFile + "]");
        }
        int result = 0;

        String prop = PropertiesUtil.getValue("DS_SCDS_PROP");
        String keyFile = PropertiesUtil.getValue("DS_SCDS_KEY");
        if (logger.isDebugEnabled()) {
            logger.debug("→ encryptScDs.SLDsEncFileDAC[PROP=" + prop + ",,KEY=" + keyFile + "]");
        }
        SLDsFile sFile = new SLDsFile();
        if( StringUtils.isBlank(prop) || StringUtils.isBlank(keyFile) ){
            return -120;
        }
        
        
        sFile.SettingPathForProperty(prop);
        result = sFile.CreateDecryptFile(
                                         keyFile
                                       , "0000001"
                                       ,  srcFile
                                       ,  dstFile
                                          );
         
        if (logger.isDebugEnabled()) {
            logger.debug("→ encryptScDs.CreateDecryptFile[result=" + result + "]");
        }
        return result;
    }

    /**
     * 암호화
     * 1. 복호화된 원본 파일 서버에 존재
     * 2. 원본파일 암호화해서 새로운 파일 생성
     * 3. 암호화된 파일 리턴
     *
     * @param srcFile
     * @return
     */
    public static File encryptScDsFile(File srcFile) {
        File result = null;
        if (srcFile != null) {
            String srcFileName = srcFile.getName();
            String srcFileAbPath = StringUtils.replace(srcFile.getAbsolutePath(), srcFileName, "");
            String srcFileExt = FilenameUtils.getExtension(srcFileName);
            if (!srcFileExt.equals("")) {
                srcFileName = StringUtils.replace(srcFileName, "." + srcFileExt, "");
                srcFileExt = "." + srcFileExt;
            }
            String srcFilePath = srcFileAbPath + srcFileName + srcFileExt;
            String dstFilePath = srcFileAbPath + srcFileName + ENC_NM + srcFileExt;
            if (logger.isDebugEnabled()) {
                logger.debug("→ encryptScDsFile(DRM 암호화)[원본파일=" + srcFilePath + ",암호파일=" + dstFilePath + "]");
            }
            int r = encryptScDs(srcFilePath, dstFilePath);
            if (logger.isDebugEnabled()) {
                logger.debug("→ encryptScDsFile(DRM 암호화)[결과=" + r + "]");
            }
            if (r == 0) { // 정상
                result = new File(dstFilePath);
            } else { // 오류
                result = srcFile;
            }
            logger.debug("[DRM 암호화] 결과값 : " + r);
        }
        return result;
    }

    /**
     * 복호화
     * 1. 이미 업로드된 암호화된 원본 파일 존재
     * 2. 원본파일 복호화해서 새로운 파일 생성
     * 3. 복호화된 파일 리턴
     *
     * @param srcFile
     * @return
     */
    public static File decryptScDsFile(File srcFile) {
        File result = null;
        if (srcFile != null) {
            String srcFileName = srcFile.getName();
            String srcFileAbPath = StringUtils.replace(srcFile.getAbsolutePath(), srcFileName, "");
            String srcFileExt = FilenameUtils.getExtension(srcFileName);
            if (!srcFileExt.equals("")) {
                srcFileName = StringUtils.replace(srcFileName, "." + srcFileExt, "");
                srcFileExt = "." + srcFileExt;
            }
            
            String srcFilePath = srcFileAbPath + srcFileName + srcFileExt;
            String dstFilePath = srcFileAbPath + srcFileName + DEC_NM + srcFileExt;
            if (logger.isDebugEnabled()) {
                logger.debug("→ decryptScDsFile(DRM 복호화)[원본파일=" + srcFilePath + ",복호파일=" + dstFilePath + "]");
            }
            int r = decryptScDs(srcFilePath, dstFilePath);
            if (logger.isDebugEnabled()) {
                logger.debug("→ decryptScDsFile(DRM 복호화)[결과=" + r + "]");
            }
            if (r == 0 || r == -36) { // 정상
                result = new File(dstFilePath);
            } else { // 오류
                result = srcFile;
            }
        }
        return result;
    }

    /**
     * 복호화
     * 1. 이미 업로드된 암호화된 원본 파일 존재
     * 2. 원본파일 복호화해서 새로운 파일 생성
     * 3. 복호화된 파일 원본파일에 덮어 쓰기
     * 4. 복호화된 파일 삭제
     * 5. 처리 결과값 리턴
     *
     * @param srcFile
     * @return
     * @throws IOException 
     */
    public static int decryptScDs(File srcFile) throws IOException {
        int result = 0;
        if (srcFile != null) {
            String srcFileName = srcFile.getName();
            String srcFileAbPath = StringUtils.replace(srcFile.getAbsolutePath(), srcFileName, "");
            String srcFileExt = FilenameUtils.getExtension(srcFileName);
            if (!srcFileExt.equals("")) {
                srcFileName = StringUtils.replace(srcFileName, "." + srcFileExt, "");
                srcFileExt = "." + srcFileExt;
            }
            String srcFilePath = srcFileAbPath + srcFileName + srcFileExt;
            String dstFilePath = srcFileAbPath + srcFileName + DEC_NM + srcFileExt;
            if (logger.isDebugEnabled()) {
                logger.debug("→ decryptScDs(DRM 복호화)[원본파일=" + srcFilePath + ",복호화파일=" + dstFilePath + ",결과값=" + result + "]");
            }
            result = decryptScDs(srcFilePath, dstFilePath);
            if (logger.isDebugEnabled()) {
                logger.debug("→ decryptScDs(DRM 복호화)[결과값=" + result + "]");
            }
            if (result == 0) { // 정상
                File destFile = new File(dstFilePath);
                if (destFile.exists()) {
                    FileUtils.copyFile(destFile, srcFile);
                    // 복사 완료시 복호화된 파일 삭제
                    if (destFile.exists()) {
                        destFile.delete();
                    }
                }
            }
        }
        return result;
    }

}
