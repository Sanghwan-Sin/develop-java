package com.mobis.maps.comm.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <pre>
 * Excel파일 Utility
 * </pre>
 *
 * @ClassName   : MapsCommExcelUtil.java
 * @Description : Excel파일에 대한 Utility를 정의.
 * @author DT048058
 * @since 2020. 9. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 9.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommExcelUtil {

    private final static Logger LOGGER = LoggerFactory.getLogger(MapsCommExcelUtil.class);

    /**
     * Workbook 생성
     *
     * @param file
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static XSSFWorkbook createWorkbook(File file) throws FileNotFoundException, IOException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("→ createWorkbook.file[path=" + file.getPath() + "]");
        }
        
        XSSFWorkbook workBook = new XSSFWorkbook(new FileInputStream(file));

        return workBook;
    }

    /**
     * Workbook(XLS) 생성
     *
     * @param file
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static HSSFWorkbook createWorkbookXls(File file) throws FileNotFoundException, IOException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("→ createWorkbookXls.file[path=" + file.getPath() + "]");
        }
        
        HSSFWorkbook workBook = new HSSFWorkbook(new FileInputStream(file));

        return workBook;
    }
}
