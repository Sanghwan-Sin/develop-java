package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 사용자 화면기능 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinFnctVO.java
 * @Description : 사용자 화면기능에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 23.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserScrinFnctVO extends MapsIamFnctVO {
    /** 사용자순번ID */
    private String userSeqId;
    /* 데이터항목 */
    /** 팝업화면ID */
    private String popupScrinId;
    /** 팝업화면명 */
    private String popupScrinNm;
    /** 팝업화면ID */
    private String popupScrinCd;

    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    /**
     * @return the popupScrinId
     */
    public String getPopupScrinId() {
        return popupScrinId;
    }
    /**
     * @param popupScrinId the popupScrinId to set
     */
    public void setPopupScrinId(String popupScrinId) {
        this.popupScrinId = popupScrinId;
    }
    /**
     * @return the popupScrinNm
     */
    public String getPopupScrinNm() {
        return popupScrinNm;
    }
    /**
     * @param popupScrinNm the popupScrinNm to set
     */
    public void setPopupScrinNm(String popupScrinNm) {
        this.popupScrinNm = popupScrinNm;
    }
    /**
     * @return the popupScrinCd
     */
    public String getPopupScrinCd() {
        return popupScrinCd;
    }
    /**
     * @param popupScrinCd the popupScrinCd to set
     */
    public void setPopupScrinCd(String popupScrinCd) {
        this.popupScrinCd = popupScrinCd;
    }

}
