package com.mobis.maps.comm.vo;

import org.hibernate.validator.constraints.NotBlank;

/**
 * <pre>
 * RFC기본정보 항목
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcBassInfoVO.java
 * @Description : RFC기본정보 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 23.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsCommSapRfcBassInfoVO extends PgBascVO {
    /** System ID */
    @NotBlank(message="EC00000001|SYS_ID")
    private String sysId;
    /** RFC아이디 */
    @NotBlank(message="EC00000001|RFC_ID")
    private String rfcId;
    /** RFC명 */
    @NotBlank(message="EC00000001|RFC_NM")
    private String rfcNm;
    /** 인터페이스ID */
    private String intrfcId;
    /** 담당자ID */
    private String chargerId;
    /** 입력데이터 */
    private String inputData;
    
    /**
     * @return the sysId
     */
    public String getSysId() {
        return sysId;
    }
    /**
     * @param sysId the sysId to set
     */
    public void setSysId(String sysId) {
        this.sysId = sysId;
    }
    /**
     * @return the rfcId
     */
    public String getRfcId() {
        return rfcId;
    }
    /**
     * @param rfcId the rfcId to set
     */
    public void setRfcId(String rfcId) {
        this.rfcId = rfcId;
    }
    /**
     * @return the rfcNm
     */
    public String getRfcNm() {
        return rfcNm;
    }
    /**
     * @param rfcNm the rfcNm to set
     */
    public void setRfcNm(String rfcNm) {
        this.rfcNm = rfcNm;
    }
    /**
     * @return the intrfcId
     */
    public String getIntrfcId() {
        return intrfcId;
    }
    /**
     * @param intrfcId the intrfcId to set
     */
    public void setIntrfcId(String intrfcId) {
        this.intrfcId = intrfcId;
    }
    /**
     * @return the chargerId
     */
    public String getChargerId() {
        return chargerId;
    }
    /**
     * @param chargerId the chargerId to set
     */
    public void setChargerId(String chargerId) {
        this.chargerId = chargerId;
    }
    /**
     * @return the inputData
     */
    public String getInputData() {
        return inputData;
    }
    /**
     * @param inputData the inputData to set
     */
    public void setInputData(String inputData) {
        this.inputData = inputData;
    }
}
