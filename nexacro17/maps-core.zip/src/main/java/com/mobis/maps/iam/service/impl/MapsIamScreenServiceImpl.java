package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamScreenService;
import com.mobis.maps.iam.service.MapsIamWordDicaryService;
import com.mobis.maps.iam.service.dao.MapsIamCompnMDAO;
import com.mobis.maps.iam.service.dao.MapsIamFnctMDAO;
import com.mobis.maps.iam.service.dao.MapsIamScreenMDAO;
import com.mobis.maps.iam.vo.MapsIamFnctVO;
import com.mobis.maps.iam.vo.MapsIamScreenCompnVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;
import com.mobis.maps.iam.vo.MapsIamScrinUrlVO;
import com.mobis.maps.iam.vo.MapsIamWordDicaryVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 화면관리 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamScreenServiceImpl.java
 * @Description : 화면관리 서비스를 구현 정의.
 * @author DT048657
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     DT048657     	최초 생성
 * </pre>
 */
@Service("mapsIamScreenService")
public class MapsIamScreenServiceImpl extends HService implements MapsIamScreenService {

    @Resource(name = "mapsIamWordDicaryService")
    private MapsIamWordDicaryService mapsIamWordDicaryService;
    
    @Resource(name="mapsIamScreenMDAO")
    private MapsIamScreenMDAO mapsIamScreenMDAO;
    
    @Resource(name="mapsIamCompnMDAO")
    private MapsIamCompnMDAO mapsIamCompnMDAO;
    
    @Resource(name="mapsIamFnctMDAO")
    private MapsIamFnctMDAO mapsIamFnctMDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#selectScreenPgList(com.mobis.maps.iam.vo.MapsIamScreenVO)
     */
    @Override
    public List<MapsIamScreenVO> selectScreenPgList(MapsIamScreenVO iamScreenVO) throws Exception {
        
        List<MapsIamScreenVO> screenInfos = mapsIamScreenMDAO.selectScreenPgList(iamScreenVO);
        
        return screenInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#selectScrinInfo(com.mobis.maps.iam.vo.MapsIamScreenVO)
     */
    @Override
    public MapsIamScreenVO selectScrinInfo(MapsIamScreenVO iamScreenVO) throws Exception {

        MapsIamScreenVO scrinInfo = mapsIamScreenMDAO.selectScreenInfo(iamScreenVO);
        
        return scrinInfo;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#multiScreenInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiScreenInfo(List<MapsIamScreenVO> screenInfos, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;

        for (MapsIamScreenVO commScreen : screenInfos) {

            int rowType = commScreen.getRowType();

            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            commScreen.setRegistId(loginInfo.getUserSeqId());
            commScreen.setUpdtId(loginInfo.getUserSeqId());

            switch (rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    mapsIamScreenMDAO.insertScreenInfo(commScreen);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    mapsIamScreenMDAO.updateScreenInfo(commScreen);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    mapsIamScreenMDAO.updateDeleteScreenInfo(commScreen);
                    // mapsIamScreenMDAO.deleteScreenInfo(commScreen);
                    break;
                default:
                    continue;

            }
            procCnt++;
        }

        return procCnt;
    }
    
    
    @Override
    public List<MapsIamScreenVO> selectScreenPgPopList(MapsIamScreenVO iamScreenVO) throws Exception {
        
        if (StringUtils.isBlank(iamScreenVO.getDfltLangCd())) {
            iamScreenVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        }
        
        List<MapsIamScreenVO> msgInfos = mapsIamScreenMDAO.selectScreenPgPopList(iamScreenVO);
        
        return msgInfos;
    }

    @Override
    public List<MapsIamScreenCompnVO> selectScreenCompnPgList(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception {
       
        List<MapsIamScreenCompnVO> compnInfos = mapsIamCompnMDAO.selectScreenCompnPgList(iamScreenCompnVO);
        
        return compnInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#selectScreenCompnList(com.mobis.maps.iam.vo.MapsIamScreenCompnVO)
     */
    @Override
    public List<MapsIamScreenCompnVO> selectScreenCompnList(MapsIamScreenCompnVO iamScreenCompnVO) throws Exception {
       
        List<MapsIamScreenCompnVO> compnInfos = mapsIamCompnMDAO.selectScreenCompnList(iamScreenCompnVO);
        
        return compnInfos;
    }

    @Override
    public MapsIamWordDicaryVO selectScreenCompnWdDic(MapsIamScreenCompnVO iamScreenCompnVO, LoginInfoVO loginInfo) throws Exception {
        
        MapsIamWordDicaryVO iamWdDicVO = new MapsIamWordDicaryVO();
        iamWdDicVO.setWordId(iamScreenCompnVO.getWordId());
        if (StringUtils.isNotBlank(iamScreenCompnVO.getLangCd())) {
            iamWdDicVO.setLangCd(iamScreenCompnVO.getLangCd());
        } else {
            iamWdDicVO.setLangCd(loginInfo.getLangCd());
        }
        
        MapsIamWordDicaryVO rsltIamWdDicVO = mapsIamWordDicaryService.selectWdDicInfoByLangWordId(iamWdDicVO);
        
        return rsltIamWdDicVO;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#multiScreenCompnInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiScreenCompnInfo(List<MapsIamScreenCompnVO> screenCompnInfos, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        for (MapsIamScreenCompnVO iamScreenCompn: screenCompnInfos) {
            
            int rowType = iamScreenCompn.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }
            
            if (StringUtils.isEmpty(iamScreenCompn.getWordId())) {
                throw new MapsBizException(messageSource, "EC00000011", new String[]{"Component Info"}, loginInfo.getUserLcale(), null);
            }

            iamScreenCompn.setRegistId(loginInfo.getUserSeqId());
            iamScreenCompn.setUpdtId(loginInfo.getUserSeqId());
                        
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    mapsIamCompnMDAO.insertScreenCompnInfo(iamScreenCompn);
                    break;
                case DataSet.ROW_TYPE_UPDATED :         
                    mapsIamCompnMDAO.updateScreenCompnInfo(iamScreenCompn);                        
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    mapsIamCompnMDAO.deleteScreenCompnInfo(iamScreenCompn);
                    break;
                default :
                    continue;
            }
            procCnt++;
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#selectScreenFnctPgList(com.mobis.maps.iam.vo.MapsIamFnctVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamFnctVO> selectScreenFnctPgList(MapsIamFnctVO iamFnctVO, LoginInfoVO loginInfo) throws Exception {

        iamFnctVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        iamFnctVO.setLangCd(loginInfo.getLangCd());
        
        List<MapsIamFnctVO> fnctInfos = mapsIamFnctMDAO.selectScreenFnctPgList(iamFnctVO);
        
        return fnctInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#selectScreenFnctList(com.mobis.maps.iam.vo.MapsIamFnctVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamFnctVO> selectScreenFnctList(MapsIamFnctVO iamFnctVO, LoginInfoVO loginInfo) throws Exception {

        iamFnctVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        iamFnctVO.setLangCd(loginInfo.getLangCd());
        
        List<MapsIamFnctVO> fnctInfos = mapsIamFnctMDAO.selectScreenFnctList(iamFnctVO);
        
        return fnctInfos;
    }


    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#multiScreenFnctInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiScreenFnctInfo(List<MapsIamFnctVO> fnctInfos, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        for (MapsIamFnctVO iamFnctCompn: fnctInfos) {
            
            int rowType = iamFnctCompn.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            iamFnctCompn.setRegistId(loginInfo.getUserSeqId());
            iamFnctCompn.setUpdtId(loginInfo.getUserSeqId());
            
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    mapsIamFnctMDAO.insertScreenFnctInfo(iamFnctCompn);
                    break;
                case DataSet.ROW_TYPE_UPDATED :         
                    mapsIamFnctMDAO.updateScreenFnctInfo(iamFnctCompn);                        
                    break;
                case DataSet.ROW_TYPE_DELETED :        
                    mapsIamFnctMDAO.deleteScreenFnctInfo(iamFnctCompn);
                    break;
                default :
                    continue;
                    
            }
            procCnt++;
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#selectScrinUrlList(com.mobis.maps.iam.vo.MapsIamScrinUrlVO)
     */
    @Override
    public List<MapsIamScrinUrlVO> selectScrinUrlList(MapsIamScrinUrlVO iamScrinUrlVO) throws Exception {
        
        List<MapsIamScrinUrlVO> scrinUrls = mapsIamScreenMDAO.selectScrinUrlList(iamScrinUrlVO);
        
        return scrinUrls;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamScreenService#multiScrinUrlInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiScrinUrlInfo(List<MapsIamScrinUrlVO> scrinUrls, LoginInfoVO loginInfo) throws Exception {
        int procCnt = 0;

        for (MapsIamScrinUrlVO iamScrinUrlVO : scrinUrls) {

            int rowType = iamScrinUrlVO.getRowType();

            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            iamScrinUrlVO.setRegistId(loginInfo.getUserSeqId());
            iamScrinUrlVO.setUpdtId(loginInfo.getUserSeqId());

            MapsIamScrinUrlVO oldIamScrinUrlVO = null;
            switch (rowType) {
                case DataSet.ROW_TYPE_INSERTED:
                    oldIamScrinUrlVO = mapsIamScreenMDAO.selectScrinUrlByUk(iamScrinUrlVO);
                    if (oldIamScrinUrlVO != null) {
                        throw new MapsBizException(messageSource, "ECI0000041", loginInfo.getUserLcale(), null);   //이미 등록된 화면URL입니다.
                    }
                    mapsIamScreenMDAO.insertScrinUrl(iamScrinUrlVO);
                    break;
                case DataSet.ROW_TYPE_UPDATED:
                    oldIamScrinUrlVO = mapsIamScreenMDAO.selectScrinUrl(iamScrinUrlVO);
                    if (oldIamScrinUrlVO == null) {
                        throw new MapsBizException(messageSource, "ECI0000042", loginInfo.getUserLcale(), null);   //등록된 화면URL이 없습니다.
                    }
                    mapsIamScreenMDAO.updateScrinUrl(iamScrinUrlVO);
                    break;
                case DataSet.ROW_TYPE_DELETED:
                    oldIamScrinUrlVO = mapsIamScreenMDAO.selectScrinUrl(iamScrinUrlVO);
                    if (oldIamScrinUrlVO == null) {
                        throw new MapsBizException(messageSource, "ECI0000042", loginInfo.getUserLcale(), null);   //등록된 화면URL이 없습니다.
                    }
                    mapsIamScreenMDAO.deleteScrinUrl(iamScrinUrlVO);
                    break;
                default:
                    continue;

            }
            procCnt++;
        }

        return procCnt;
    }

}
