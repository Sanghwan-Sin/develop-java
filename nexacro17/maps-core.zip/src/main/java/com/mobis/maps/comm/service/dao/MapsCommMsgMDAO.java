package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommMsgVO;

/**
 * <pre>
 * 메세지 관리 데이터처리
 * </pre>
 *
 * @ClassName   : MapsCommMsgMDAO.java
 * @Description : 메세지 관리 데이터처리를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 26.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Mapper("mapsCommMsgMDAO")
public interface MapsCommMsgMDAO {

    /**
     * 메세지 리스트 조회
     *
     * @param commMsgSearchVO
     * @return
     * @throws Exception
     */
    public List<MapsCommMsgVO> selectMsgPgList(MapsCommMsgVO commMsgVO) throws Exception;

    /**
     * 메세지 조회
     *
     * @param commMsgVO
     * @return
     * @throws Exception
     */
    public MapsCommMsgVO selectMsgInfo(MapsCommMsgVO commMsgVO) throws Exception;
    
    /**
     * 참조언어에 대한 메세지 조회
     *
     * @param commMsgVO
     * @return
     * @throws Exception
     */
    public MapsCommMsgVO selectMsgInfoByRefrnLang(MapsCommMsgVO commMsgVO) throws Exception;

    /**
     * 다음 메세지코드 조회
     *
     * @param commMsgVO
     * @return
     * @throws Exception
     */
    public String selectNextMsgCd(MapsCommMsgVO commMsgVO) throws Exception;
    
    /**
     * 메세지 저장
     *
     * @param commMsgVO
     * @throws Exception
     */
    public void insertMsgInfo(MapsCommMsgVO commMsgVO) throws Exception;
    
    /**
     * 메세지 수정
     *
     * @param commMsgVO
     * @return
     * @throws Exception
     */
    public int updateMsgInfo(MapsCommMsgVO commMsgVO) throws Exception;
    
    /**
     * 메세지 삭제
     *
     * @param commMsgVO
     * @return
     * @throws Exception
     */
    public int deleteMsgInfo(MapsCommMsgVO commMsgVO) throws Exception;
}
