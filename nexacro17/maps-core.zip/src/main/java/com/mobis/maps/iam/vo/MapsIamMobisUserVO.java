package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 모비스사용자 항목
 * </pre>
 *
 * @ClassName   : MapsIamMobisUserVO.java
 * @Description : 모비스사용자에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 4. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 13.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamMobisUserVO extends MapsIamMobisOrgnztVO {
    /** 사용자ID */
    private String userId;
    /** 사용자명 */
    private String userNm;
    /** 직위명 */
    private String jwNmHome;
    /** 직책명 */
    private String dutyNmHome;
    /** 사용자 본부명 */
    private String userDivNm;
    /** 사용자 실명 */
    private String userSilNm;
    /** 부서명 */
    private String deptNm;
    /** 사용자Email */
    private String userEmail;
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userNm
     */
    public String getUserNm() {
        return userNm;
    }
    /**
     * @param userNm the userNm to set
     */
    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }
    /**
     * @return the jwNmHome
     */
    public String getJwNmHome() {
        return jwNmHome;
    }
    /**
     * @param jwNmHome the jwNmHome to set
     */
    public void setJwNmHome(String jwNmHome) {
        this.jwNmHome = jwNmHome;
    }
    /**
     * @return the dutyNmHome
     */
    public String getDutyNmHome() {
        return dutyNmHome;
    }
    /**
     * @param dutyNmHome the dutyNmHome to set
     */
    public void setDutyNmHome(String dutyNmHome) {
        this.dutyNmHome = dutyNmHome;
    }
    /**
     * @return the userDivNm
     */
    public String getUserDivNm() {
        return userDivNm;
    }
    /**
     * @param userDivNm the userDivNm to set
     */
    public void setUserDivNm(String userDivNm) {
        this.userDivNm = userDivNm;
    }
    /**
     * @return the userSilNm
     */
    public String getUserSilNm() {
        return userSilNm;
    }
    /**
     * @param userSilNm the userSilNm to set
     */
    public void setUserSilNm(String userSilNm) {
        this.userSilNm = userSilNm;
    }
    /**
     * @return the deptNm
     */
    public String getDeptNm() {
        return deptNm;
    }
    /**
     * @param deptNm the deptNm to set
     */
    public void setDeptNm(String deptNm) {
        this.deptNm = deptNm;
    }
    /**
     * @return the userEmail
     */
    public String getUserEmail() {
        return userEmail;
    }
    /**
     * @param userEmail the userEmail to set
     */
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}
