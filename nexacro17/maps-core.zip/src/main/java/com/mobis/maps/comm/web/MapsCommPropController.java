package com.mobis.maps.comm.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.util.ValidatorUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommPropService;
import com.mobis.maps.comm.vo.MapsCommPropVO;

/**
 * <pre>
 * 프로퍼티 관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommPropController.java
 * @Description : 프로퍼티 관리에 대한 컨트롤러 정의.
 * @author DT048058
 * @since 2019. 12. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 18.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommPropController extends HController {
    
    @Resource
    private Validator validator;
    
    @Resource(name = "mapsCommPropService")
    private MapsCommPropService mapsCommPropService;
    
    /**
     * 프로퍼티 페이징리스트 조회
     *
     * @param commPropVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectPropPgList.do")
    public NexacroResult selectPropPgList(
            @ParamDataSet(name="dsInput") MapsCommPropVO commPropVO
            , NexacroResult result) throws Exception {
        
        List<MapsCommPropVO> propInfos = mapsCommPropService.selectPropPgList(commPropVO);
        
        result.addDataSet("dsOutput", propInfos);
        
        return result;
    }

    /**
     * 프로퍼티 저장
     *
     * @param propInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/multiPropInfo.do")
    public NexacroResult multiPropInfo(
            @ParamDataSet(name="dsInput") List<MapsCommPropVO> propInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        ValidatorUtil.validate(propInfos, validator);

        int procCnt = mapsCommPropService.multiPropInfo(propInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 프로퍼티 액셀다운로드
     *
     * @param commPropVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectPropListExcelDown.do")
    public NexacroResult selectPropListExcelDown(
            @ParamDataSet(name="dsInput") MapsCommPropVO commPropVO
            , NexacroResult result) throws Exception {

        List<MapsCommPropVO> propInfos = mapsCommPropService.selectPropPgList(commPropVO);

        result.addDataSet("dsOutput", propInfos);

        return result;
    }
    
    /**
     * 프로퍼티 업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectPropListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectPropListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<MapsCommPropVO> propInfos = new ArrayList<MapsCommPropVO>();

        List<String[]> rowList = ExcelUtil.importExcelToList(request, 2, 9, 0, "N");
        
        if (rowList != null && !rowList.isEmpty()) {

            for (String[] arrCol : rowList) {

                MapsCommPropVO commPropVO = new MapsCommPropVO();
                
                commPropVO.setPropSys(arrCol[2]);
                commPropVO.setPropKey(arrCol[4]);
                commPropVO.setPropVal(arrCol[5]);

                propInfos.add(commPropVO);
            }
        }

        result.addDataSet("dsOutput", propInfos);

        return result;
    }
    
    /**
     * 프로퍼티 복호화
     *
     * @param commPropVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectPropDecrypt.do")
    public NexacroResult selectPropDecrypt(
            @ParamDataSet(name="dsInput") MapsCommPropVO commPropVO
            , NexacroResult result) throws Exception {

        String decptVal = PropertiesUtil.getDecrypt(commPropVO.getPropVal());
        commPropVO.setPropVal(decptVal);

        result.addDataSet("dsOutput", commPropVO);

        return result;
    }
    
    /**
     * 프로퍼티 암호화
     *
     * @param commPropVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectPropEncrypt.do")
    public NexacroResult selectPropEncrypt(
            @ParamDataSet(name="dsInput") MapsCommPropVO commPropVO
            , NexacroResult result) throws Exception {

        String encptVal = PropertiesUtil.getEncrypt(commPropVO.getPropVal());
        commPropVO.setPropVal(encptVal);

        result.addDataSet("dsOutput", commPropVO);

        return result;
    }
}
