package com.mobis.maps.iam.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.comm.constants.MapsCommEmailTmplat;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommCodeService;
import com.mobis.maps.comm.service.MapsCommEmailService;
import com.mobis.maps.comm.vo.EmailSndngVO;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamAcntReqstInfoService;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.service.MapsIamUserBassInfoService;
import com.mobis.maps.iam.service.MapsIamUserService;
import com.mobis.maps.iam.service.dao.MapsIamAcntReqstInfoMDAO;
import com.mobis.maps.iam.util.MapsIamUtil;
import com.mobis.maps.iam.util.MapsIamValidatorUtil;
import com.mobis.maps.iam.vo.MapsIamAcntReqstAuthorVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstLangVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstPermIpVO;
import com.mobis.maps.iam.vo.MapsIamAcntReqstVO;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;

/**
 * <pre>
 * 계정신청 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstInfoServiceImpl.java
 * @Description : 계정신청에 대한 서비스를 구현.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsIamAcntReqstInfoService")
public class MapsIamAcntReqstInfoServiceImpl extends HService implements MapsIamAcntReqstInfoService {
    
    @Resource(name = "mapsCommCodeService")
    private MapsCommCodeService mapsCommCodeService;
    
    @Resource(name = "mapsCommEmailService")
    private MapsCommEmailService mapsCommEmailService;

    @Resource(name = "mapsIamMobisUserService")
    MapsIamMobisUserService mapsIamMobisUserService;
    
    @Resource(name = "mapsIamUserBassInfoService")
    private MapsIamUserBassInfoService mapsIamUserBassInfoService;
    
    @Resource(name="mapsIamUserService")
    private MapsIamUserService mapsIamUserService;
    
    @Resource(name="mapsIamAcntReqstInfoMDAO")
    private MapsIamAcntReqstInfoMDAO mapsIamAcntReqstInfoMDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#selectAcntReqstInfo(com.mobis.maps.iam.vo.MapsIamAcntReqstVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsIamAcntReqstVO selectAcntReqstInfo(MapsIamAcntReqstVO iamAcntReqstVO
            , LoginInfoVO loginInfo) throws Exception {

        /* 계정신청정보 조회 */
        MapsIamAcntReqstInfoVO iamAcntReqstInfoVO = new MapsIamAcntReqstInfoVO();
        iamAcntReqstInfoVO.setAcntReqstNo(iamAcntReqstVO.getAcntReqstNo());
        iamAcntReqstInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamAcntReqstInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        MapsIamUtil.addOrgnztSeCd(iamAcntReqstInfoVO.getSysSeCd(), iamAcntReqstInfoVO, loginInfo);
        MapsIamUtil.addOrgnztCd(iamAcntReqstInfoVO, loginInfo, mapsIamMobisUserService);
        MapsIamUtil.addAcntTyCd(iamAcntReqstInfoVO, loginInfo);
        iamAcntReqstInfoVO = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfo(iamAcntReqstInfoVO);
        //계정신청정보가 존재하지 않습니다.
        if (iamAcntReqstInfoVO == null) {
            throw new MapsBizException(messageSource, "ECI0000032", loginInfo.getUserLcale(), null);
        }
        /* 계정신청언어조회 */
        MapsIamAcntReqstLangVO iamAcntReqstLangVO = new MapsIamAcntReqstLangVO();
        iamAcntReqstLangVO.setAcntReqstNo(iamAcntReqstVO.getAcntReqstNo());
        List<MapsIamAcntReqstLangVO> acntReqstLangs = mapsIamAcntReqstInfoMDAO.selectAcntReqstLangList(iamAcntReqstLangVO);
        /* 계정신청허용IP조회 */
        MapsIamAcntReqstPermIpVO iamAcntReqstPermIpVO = new MapsIamAcntReqstPermIpVO();
        iamAcntReqstPermIpVO.setAcntReqstNo(iamAcntReqstVO.getAcntReqstNo());
        List<MapsIamAcntReqstPermIpVO> acntReqstPermIps = mapsIamAcntReqstInfoMDAO.selectAcntReqstPermIpList(iamAcntReqstPermIpVO);
        /* 계정신청권한조회 */
        MapsIamAcntReqstAuthorVO iamAcntReqstAuthorVO = new MapsIamAcntReqstAuthorVO();
        iamAcntReqstAuthorVO.setAcntReqstNo(iamAcntReqstVO.getAcntReqstNo());
        List<MapsIamAcntReqstAuthorVO> acntReqstAuthors = mapsIamAcntReqstInfoMDAO.selectAcntReqstAuthorList(iamAcntReqstAuthorVO);
        
        iamAcntReqstVO.setIamAcntReqstInfo(iamAcntReqstInfoVO);
        iamAcntReqstVO.setAcntReqstLangs(acntReqstLangs);
        iamAcntReqstVO.setAcntReqstPermIps(acntReqstPermIps);
        iamAcntReqstVO.setAcntReqstAuthors(acntReqstAuthors);
        
        return iamAcntReqstVO;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#selectAuthorMstList(com.mobis.maps.iam.vo.MapsIamAuthorVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamAuthorVO> selectAuthorMstList(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception {

        //로그인계정정보 설정
        MapsIamUtil.setLoginInfo(iamAuthorVO, loginInfo);
        
        List<MapsIamAuthorVO> lstAuthorMst = mapsIamAcntReqstInfoMDAO.selectAuthorMstList(iamAuthorVO);
        
        return lstAuthorMst;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#selectAcntExst(com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO)
     */
    @Override
    public MapsIamUserVO selectAcntExst(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO) throws Exception {
        
        return mapsIamAcntReqstInfoMDAO.selectAcntExst(iamAcntReqstInfoVO);
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#insertAcntReqst(com.mobis.maps.iam.vo.MapsIamAcntReqstVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int insertAcntReqst(MapsIamAcntReqstVO iamAcntReqstVO, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        
        MapsIamAcntReqstInfoVO iamAcntReqstInfoVO = iamAcntReqstVO.getIamAcntReqstInfo();
        iamAcntReqstInfoVO.setReqstSttusCd(REQST_STTUS_CD_WRITING);
        iamAcntReqstInfoVO.setRegistId(loginInfo.getUserSeqId());
        iamAcntReqstInfoVO.setUpdtId(loginInfo.getUserSeqId());

        // 계정신청nMGN조직정보 체크
        MapsOrgnztDistVO orgnztDistVO = MapsIamValidatorUtil.validateAcntReqstDistOrgnzt(iamAcntReqstInfoVO, loginInfo.getUserLcale());
        // 관리자 이메일 정보 조회
        List<MapsIamUserVO> mngrUserEmails = mapsIamUserService.selectMngrEmailList(iamAcntReqstInfoVO, orgnztDistVO, false);
        if (mngrUserEmails.isEmpty()) {
            iamAcntReqstInfoVO.setMngrId(MapsIamConstants.SYSTEM_USER_SEQ_ID);
        } else {
            iamAcntReqstInfoVO.setMngrId(mngrUserEmails.get(0).getUserSeqId());
        }
        
        MapsIamAcntReqstInfoVO srchIamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfo(iamAcntReqstInfoVO);
        if (srchIamAcntReqstInfo == null) {
            /* 정합성체크 */
            // 사용자ID 자동채번인 경우 사용자ID 체크
            selectIsAutoUserId(iamAcntReqstInfoVO, loginInfo.getUserLcale());
            // 신규사용자인경우 이메일 체크
            if (StringUtils.equals(iamAcntReqstInfoVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
                selectHasUserBassEmail(iamAcntReqstInfoVO, loginInfo.getUserLcale());
            }
            // 계정등록여부 체크(시스템구분코드+사용자ID)
            selectHasAcntInfo(iamAcntReqstInfoVO, loginInfo.getUserLcale());
            // 계정신청정보 체크
            selectHasAcntReqstInfo(iamAcntReqstInfoVO, loginInfo.getUserLcale());

            /* 계정신청정보 등록 */
            mapsIamAcntReqstInfoMDAO.insertAcntReqstInfo(iamAcntReqstInfoVO);
            procCnt = 1;
        } else {
            /* 정합성체크 */
            if (!StringUtils.equals(REQST_STTUS_CD_WRITING, srchIamAcntReqstInfo.getReqstSttusCd())) {
                // 계정신청정보가 이미 신청중입니다.
                throw new MapsBizException(messageSource, "ECI0000025", loginInfo.getUserLcale(), null);
            }
            /* 계정신청정보 변경 */
            procCnt = mapsIamAcntReqstInfoMDAO.updateAcntReqstInfo(iamAcntReqstInfoVO);
        }

        // 계정신청변경이력 등록
        insertAcntReqstSttusChghst(srchIamAcntReqstInfo, iamAcntReqstInfoVO, loginInfo);
        // 계정신청서브정보 등록
        insertAcntReqstSubInfos(iamAcntReqstVO, loginInfo);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#insertReqstAcnt(com.mobis.maps.iam.vo.MapsIamAcntReqstVO, javax.servlet.http.HttpServletRequest, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int insertReqstAcnt(MapsIamAcntReqstVO iamAcntReqstVO, HttpServletRequest request, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        
        MapsIamAcntReqstInfoVO iamAcntReqstInfoVO = iamAcntReqstVO.getIamAcntReqstInfo();
        iamAcntReqstInfoVO.setReqstSttusCd(REQST_STTUS_CD_REQUSETING);
        iamAcntReqstInfoVO.setRegistId(loginInfo.getUserSeqId());
        iamAcntReqstInfoVO.setUpdtId(loginInfo.getUserSeqId());

        // 계정신청nMGN조직정보 체크
        MapsOrgnztDistVO orgnztDistVO = MapsIamValidatorUtil.validateAcntReqstDistOrgnzt(iamAcntReqstInfoVO, loginInfo.getUserLcale());
        // 관리자 이메일 정보 조회
        List<MapsIamUserVO> mngrEmails = mapsIamUserService.selectMngrEmailList(iamAcntReqstInfoVO, orgnztDistVO, false);
        if (mngrEmails.isEmpty()) {
            iamAcntReqstInfoVO.setMngrId(MapsIamConstants.SYSTEM_USER_SEQ_ID);
        } else {
            iamAcntReqstInfoVO.setMngrId(mngrEmails.get(0).getUserSeqId());
        }

        MapsIamAcntReqstInfoVO srchIamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfo(iamAcntReqstInfoVO);
        if (srchIamAcntReqstInfo == null) {
            /* 정합성체크 */
            // 사용자ID 자동채번인 경우 사용자ID 체크
            selectIsAutoUserId(iamAcntReqstInfoVO, loginInfo.getUserLcale());
            // 신규사용자인경우 이메일 체크
            if (StringUtils.equals(iamAcntReqstInfoVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
                selectHasUserBassEmail(iamAcntReqstInfoVO, loginInfo.getUserLcale());
            }
            // 계정등록여부 체크(시스템구분코드+사용자ID)
            selectHasAcntInfo(iamAcntReqstInfoVO, loginInfo.getUserLcale());
            // 계정신청정보 체크
            selectHasAcntReqstInfo(iamAcntReqstInfoVO, loginInfo.getUserLcale());
            
            /* 계정신청정보 등록 */
            mapsIamAcntReqstInfoMDAO.insertAcntReqstInfo(iamAcntReqstInfoVO);
            
            procCnt = 1;
        } else {
            /* 정합성체크 */
            if (REQST_STTUS_CD_WRITING.compareTo(srchIamAcntReqstInfo.getReqstSttusCd()) > 0) {
                // 계정신청정보가 이미 신청중입니다.
                throw new MapsBizException(messageSource, "ECI0000025", loginInfo.getUserLcale(), null);
            }
            
            /* 계정신청정보 변경 */
            procCnt = mapsIamAcntReqstInfoMDAO.updateAcntReqstInfo(iamAcntReqstInfoVO);
        }
        
        // 계정신청변경이력 등록
        insertAcntReqstSttusChghst(srchIamAcntReqstInfo, iamAcntReqstInfoVO, loginInfo);
        // 계정신청서브정보 등록
        insertAcntReqstSubInfos(iamAcntReqstVO, loginInfo);
        
        /* 메일발송 */
        insertSendMailReqstAcnt(iamAcntReqstInfoVO, mngrEmails, loginInfo.getLangCd());
        
        return procCnt;
    }
    
    /**
     * 사용자ID 자동채번 체크
     *
     * @param iamAcntReqstInfoVO
     * @param locale
     * @throws Exception
     */
    private void selectIsAutoUserId(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, Locale locale) throws Exception {
        /* 초기데이터 확인 */
        if (StringUtils.equalsIgnoreCase(iamAcntReqstInfoVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
            iamAcntReqstInfoVO.setUserBassId(MapsIamConstants.USER_BASS_ID_NEW);
        }
        if (StringUtils.equalsIgnoreCase(iamAcntReqstInfoVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
            iamAcntReqstInfoVO.setUserId(MapsIamConstants.USER_ID_NEW);
        }

        /* 사용자ID 정합성 체크 */
        // 사용자ID 자동채번 여부 취득
        boolean isAutoUserId = MapsIamValidatorUtil.isAutoCountUserId(iamAcntReqstInfoVO.getOrgnztSeCd());
        if (isAutoUserId && !StringUtils.equals(iamAcntReqstInfoVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
            // 사용자 ID가 자동 생성 대상인 경우 사용자 ID를 "NEW"로 입력해야합니다.
            throw new MapsBizException(messageSource, "ECI0000076", locale, null);
            //iamUserVO.setUserId(MapsIamConstants.USER_ID_NEW);
        }
    }
    
    /**
     * 사용자기본Email 체크
     *
     * @param iamAcntReqstInfoVO
     * @throws Exception
     */
    private void selectHasUserBassEmail(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, Locale locale) throws Exception {
        
        MapsIamAcntReqstInfoVO iamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectHasUserBassEmail(iamAcntReqstInfoVO);
        
        if (iamAcntReqstInfo != null) {
            
            if (!StringUtils.equals(iamAcntReqstInfoVO.getUserNm(), iamAcntReqstInfo.getUserNm())) {
                //사용자명과 이메일을 확인해 주세요.
                throw new MapsBizException(messageSource, "ECI0000057",  null);
            }

            iamAcntReqstInfoVO.setUserBassId(iamAcntReqstInfo.getUserBassId());
            iamAcntReqstInfoVO.setUserBassOrgnztSeCd(iamAcntReqstInfo.getOrgnztSeCd());
            iamAcntReqstInfoVO.setUserBassBsnOrgnztCd(iamAcntReqstInfo.getBsnOrgnztCd());
            iamAcntReqstInfoVO.setUserBassOrgnztCd(iamAcntReqstInfo.getOrgnztCd());
            iamAcntReqstInfoVO.setMoblphonNo(iamAcntReqstInfo.getMoblphonNo());
            iamAcntReqstInfoVO.setOffmTelno(iamAcntReqstInfo.getOffmTelno());
            iamAcntReqstInfoVO.setFaxTelno(iamAcntReqstInfo.getFaxTelno());
        }
        String userSeqId = mapsIamAcntReqstInfoMDAO.selectUserSeqIdByOrgnztEmail(iamAcntReqstInfoVO);
        //userSeqId = mapsIamAcntReqstInfoMDAO.selectUserSeqIdByEmail(iamAcntReqstInfoVO);
        if (StringUtils.isNotBlank(userSeqId)) {
            //Email로 등록된 계정정보가 있습니다.
            throw new MapsBizException(messageSource, "ECI0000070", locale, null);
        }
    }
    
    /**
     * 계정정보 체크
     *
     * @param iamAcntReqstInfoVO
     * @param locale
     * @throws Exception
     */
    private void selectHasAcntInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, Locale locale) throws Exception {
        
        MapsIamUserVO iamUserInfo = mapsIamAcntReqstInfoMDAO.selectAcntExst(iamAcntReqstInfoVO);
        if (iamUserInfo != null) {
            // 이미 사용중인 사용자ID입니다.
            throw new MapsBizException(messageSource, "EC00000065", locale, null);
        }
    }
    
    /**
     * 계정신청상태코드 체크
     *
     * @param iamAcntReqstInfoVO
     * @param locale
     * @throws Exception
     */
    private void selectHasAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, Locale locale) throws Exception {
        
        // 자동생성인 경우 미체크.
        if (StringUtils.equals(iamAcntReqstInfoVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
            return;
        }
        // 시스템별 사용자ID 체크
        MapsIamAcntReqstInfoVO iamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectHasAcntReqstInfo(iamAcntReqstInfoVO);
        if (iamAcntReqstInfo != null) {
            if (StringUtils.equals(iamAcntReqstInfo.getReqstSttusCd(), REQST_STTUS_CD_WRITING)) {
                // 작성중인 계정신청정보가 있습니다.
                throw new MapsBizException(messageSource, "ECI0000027", locale, null);
            }
            if (StringUtils.equals(iamAcntReqstInfo.getReqstSttusCd(), REQST_STTUS_CD_REQUSETING)) {
                // 신청중인 계정신청정보가 있습니다
                throw new MapsBizException(messageSource, "ECI0000028", locale, null);
            }
            if (StringUtils.equals(iamAcntReqstInfo.getReqstSttusCd(), REQST_STTUS_CD_PUBLICATION)) {
                // 계정신청정보가 이미 발행되었습니다
                throw new MapsBizException(messageSource, "ECI0000029", locale, null);
            }
        }
        //조직별 이메일 체크
        iamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfoByOrgnztEmail(iamAcntReqstInfoVO);
        if (iamAcntReqstInfo != null) {
            if (StringUtils.equals(iamAcntReqstInfo.getReqstSttusCd(), REQST_STTUS_CD_WRITING)) {
                // 작성중인 계정신청정보가 있습니다.
                throw new MapsBizException(messageSource, "ECI0000027", locale, null);
            }
            if (StringUtils.equals(iamAcntReqstInfo.getReqstSttusCd(), REQST_STTUS_CD_REQUSETING)) {
                // 신청중인 계정신청정보가 있습니다
                throw new MapsBizException(messageSource, "ECI0000028", locale, null);
            }
            if (StringUtils.equals(iamAcntReqstInfo.getReqstSttusCd(), REQST_STTUS_CD_PUBLICATION)) {
                // 계정신청정보가 이미 발행되었습니다
                throw new MapsBizException(messageSource, "ECI0000029", locale, null);
            }
        }
        
        MapsIamValidatorUtil.validateAcntReqstDistOrgnzt(iamAcntReqstInfoVO, locale);
    }

    /**
     * 계정신청상태변경이력 등록
     *
     * @param orginIamAcntReqstInfoVO
     * @param iamAcntReqstInfoVO
     * @param loginInfo
     * @throws Exception
     */
    private void insertAcntReqstSttusChghst(MapsIamAcntReqstInfoVO orginIamAcntReqstInfoVO, MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, LoginInfoVO loginInfo) throws Exception {
        
        if (orginIamAcntReqstInfoVO != null) {
            if (StringUtils.equals(orginIamAcntReqstInfoVO.getReqstSttusCd(), iamAcntReqstInfoVO.getReqstSttusCd())) {
                return;
            }
            if (StringUtils.equals(orginIamAcntReqstInfoVO.getApprvSttusCd(), iamAcntReqstInfoVO.getApprvSttusCd())) {
                return;
            }
        }
        
        iamAcntReqstInfoVO.setChangeId(loginInfo.getUserSeqId());
        
        mapsIamAcntReqstInfoMDAO.insertAcntReqstSttusChghst(iamAcntReqstInfoVO);
    }
    
    /**
     * 계정신청 서브정보 등록
     *
     * @param iamAcntReqstVO
     * @param loginInfo
     * @throws Exception
     */
    private void insertAcntReqstSubInfos(MapsIamAcntReqstVO iamAcntReqstVO, LoginInfoVO loginInfo) throws Exception {

        /* 계정신청정보 */
        MapsIamAcntReqstInfoVO iamAcntReqstInfoVO = iamAcntReqstVO.getIamAcntReqstInfo();
        String acntReqstNo = iamAcntReqstInfoVO.getAcntReqstNo();
        
        /* 계정신청언어등록 */
        MapsIamAcntReqstLangVO iamAcntReqstLangVO = new MapsIamAcntReqstLangVO();
        iamAcntReqstLangVO.setAcntReqstNo(acntReqstNo);
        mapsIamAcntReqstInfoMDAO.deleteAllAcntReqstLang(iamAcntReqstLangVO);
        
        for (MapsIamAcntReqstLangVO iamAcntReqstLang: iamAcntReqstVO.getAcntReqstLangs()) {
            
            iamAcntReqstLang.setAcntReqstNo(acntReqstNo);
            iamAcntReqstLang.setRegistId(loginInfo.getUserSeqId());
            
            mapsIamAcntReqstInfoMDAO.insertAcntReqstLang(iamAcntReqstLang);
        }
        
        /* 계정신청허용IP등록 */
        MapsIamAcntReqstPermIpVO iamAcntReqstPermIpVO = new MapsIamAcntReqstPermIpVO();
        iamAcntReqstPermIpVO.setAcntReqstNo(acntReqstNo);
        mapsIamAcntReqstInfoMDAO.deleteAllAcntReqstPermIp(iamAcntReqstPermIpVO);
        
        if (iamAcntReqstVO.getAcntReqstPermIps() != null) {
            for (MapsIamAcntReqstPermIpVO iamAcntReqstPermIp: iamAcntReqstVO.getAcntReqstPermIps()) {
                
                iamAcntReqstPermIp.setAcntReqstNo(acntReqstNo);
                iamAcntReqstPermIp.setRegistId(loginInfo.getUserSeqId());
                
                mapsIamAcntReqstInfoMDAO.insertAcntReqstPermIp(iamAcntReqstPermIp);
            }
        }
        
        /* 계정신청권한등록 */
        MapsIamAcntReqstAuthorVO iamAcntReqstAuthorVO = new MapsIamAcntReqstAuthorVO();
        iamAcntReqstAuthorVO.setAcntReqstNo(acntReqstNo);
        mapsIamAcntReqstInfoMDAO.deleteAllAcntReqstAuthor(iamAcntReqstAuthorVO);

        if (iamAcntReqstVO.getAcntReqstAuthors() != null) {
            for (MapsIamAcntReqstAuthorVO iamAcntReqstAuthors: iamAcntReqstVO.getAcntReqstAuthors()) {
                
                iamAcntReqstAuthors.setAcntReqstNo(acntReqstNo);
                iamAcntReqstAuthors.setRegistId(loginInfo.getUserSeqId());
                
                mapsIamAcntReqstInfoMDAO.insertAcntReqstAuthor(iamAcntReqstAuthors);
            }
        }
        
    }

    /**
     * 계정신청 이메일 발송
     *
     * @param iamAcntReqstInfoVO
     * @param mngrEmails
     * @param langCd
     * @throws Exception
     */
    private void insertSendMailReqstAcnt(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, List<MapsIamUserVO> mngrEmails, String langCd) throws Exception {
        /* 신청자 메일전송 */
        Locale locale = MapsIamUtil.getLocale(langCd);
        MapsCommEmailTmplat emailReqstAcnt = MapsCommEmailTmplat.IAM003;
        // 이메일 내용 초기화 및 설정
        Map<String, Object> mEmailData = new HashMap<String, Object>();
        mEmailData.put("sysSeNm", emailReqstAcnt.getSysSeNm(mapsCommCodeService, iamAcntReqstInfoVO.getSysSeCd(), langCd));
        mEmailData.put("idxUrl", PropertiesUtil.getMapsUrl(iamAcntReqstInfoVO.getSysSeCd()));
        mEmailData.put("userNm", iamAcntReqstInfoVO.getUserNm());
        mEmailData.put("acntReqstNo", iamAcntReqstInfoVO.getAcntReqstNo());
        mEmailData.put("email", iamAcntReqstInfoVO.getEmail());
        // 이메일제목
        String emailSj = emailReqstAcnt.getSj(messageSource, iamAcntReqstInfoVO, locale);
        // 이메일 내용
        String emailCn = emailReqstAcnt.getCn(mEmailData, locale);
        // 이메일전송정보 설정
        EmailSndngVO emailSndngVO = new EmailSndngVO();
        emailSndngVO.setSndngProgrm(this.getClass().getName());
        emailSndngVO.setSndngEmail(MapsIamUtil.getHelpEmail());
        emailSndngVO.setRecptnEmail(iamAcntReqstInfoVO.getEmail()); // MAIL TO
        emailSndngVO.setEmailSj(emailSj);
        emailSndngVO.setEmailBdt(emailCn);
        emailSndngVO.setHtmlYn("Y"); // HTML 여부
        emailSndngVO.setRegistId(iamAcntReqstInfoVO.getRegistId()); // 등록자
        // 이메일전송정보 등록
        mapsCommEmailService.insertEmail(emailSndngVO);

        /* 관리자 메일전송 */
        if (mngrEmails == null || mngrEmails.isEmpty()) {
            return;
        }
        MapsCommEmailTmplat emailReqstAcntMngr = MapsCommEmailTmplat.IAM004;
        // 이메일제목
        emailSj = emailReqstAcntMngr.getSj(messageSource, iamAcntReqstInfoVO, locale);
        // 이메일 내용
        emailCn = emailReqstAcntMngr.getCn(mEmailData, locale);
        // 이메일전송정보 설정
        EmailSndngVO emailSndngMngrVO = new EmailSndngVO();
        emailSndngMngrVO.setSndngProgrm(this.getClass().getName());
        emailSndngMngrVO.setSndngEmail(iamAcntReqstInfoVO.getEmail());
        emailSndngMngrVO.setRecptnEmail(MapsIamUtil.getMngrEmailTo(mngrEmails));    // MAIL TO
        emailSndngMngrVO.setEmailSj(emailSj);
        emailSndngMngrVO.setEmailBdt(emailCn);
        emailSndngMngrVO.setHtmlYn("Y"); // HTML 여부
        emailSndngMngrVO.setRegistId(iamAcntReqstInfoVO.getRegistId()); // 등록자
        // 이메일전송정보 등록
        mapsCommEmailService.insertEmail(emailSndngMngrVO);
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#deleteAcntReqstInfo(com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int deleteAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;

        MapsIamAcntReqstInfoVO srchIamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfo(iamAcntReqstInfoVO);
        
        //삭제할 계정신청 정보가 없습니다.
        if (srchIamAcntReqstInfo == null) {
            throw new MapsBizException(messageSource, "ECI0000030", loginInfo.getUserLcale(), null);
        }
        //계정신청상태가 신청중이 아닙니다.
        if (!REQST_STTUS_CD_REQUSETING.equals(srchIamAcntReqstInfo.getReqstSttusCd())) {
            throw new MapsBizException(messageSource, "ECI0000031", loginInfo.getUserLcale(), null);
        }
        
        iamAcntReqstInfoVO.setUpdtId(loginInfo.getUserSeqId());
        
        procCnt = mapsIamAcntReqstInfoMDAO.deleteAcntReqstInfo(iamAcntReqstInfoVO);
        
        // 계정신청변경이력 등록
        insertAcntReqstSttusChghst(srchIamAcntReqstInfo, iamAcntReqstInfoVO, loginInfo);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#updateApprvSaveAcntReqst(com.mobis.maps.iam.vo.MapsIamAcntReqstVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateApprvSaveAcntReqst(MapsIamAcntReqstVO iamAcntReqstVO, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        
        MapsIamAcntReqstInfoVO iamAcntReqstInfoVO = iamAcntReqstVO.getIamAcntReqstInfo();
        iamAcntReqstInfoVO.setRegistId(loginInfo.getUserSeqId());
        iamAcntReqstInfoVO.setUpdtId(loginInfo.getUserSeqId());
        
        MapsIamAcntReqstInfoVO srchIamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfo(iamAcntReqstInfoVO);

        //계정신청정보가 존재하지 않습니다.
        if (srchIamAcntReqstInfo == null) {
            throw new MapsBizException(messageSource, "ECI0000032", loginInfo.getUserLcale(), null);
        }
        
        //계정신청정보가 신청중이 아닙니다.
        if (!REQST_STTUS_CD_REQUSETING.equals(srchIamAcntReqstInfo.getReqstSttusCd())) {
            throw new MapsBizException(messageSource, "ECI0000033", loginInfo.getUserLcale(), null);
        }
        
        procCnt = mapsIamAcntReqstInfoMDAO.updateAcntReqstInfo(iamAcntReqstInfoVO);

        // 계정신청변경이력 등록
        insertAcntReqstSttusChghst(srchIamAcntReqstInfo, iamAcntReqstInfoVO, loginInfo);
        
        insertAcntReqstSubInfos(iamAcntReqstVO, loginInfo);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#updateAcntReqstApprv(com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateAcntReqstApprv(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        
        /* 계정신청 승인 정합성체크 */
        MapsIamAcntReqstInfoVO srchIamAcntReqstInfo = updateValidateAcntReqstApprv(iamAcntReqstInfoVO, loginInfo);
        
        /* 계정신청정보 취득 */
        String orgnztSeCd = iamAcntReqstInfoVO.getOrgnztSeCd();

        /* 사용자ID 자동채번 */
        // 사용자ID 자동채번 여부 취득
        boolean isAutoUserId = MapsIamValidatorUtil.isAutoCountUserId(orgnztSeCd);
        if (isAutoUserId && StringUtils.equals(srchIamAcntReqstInfo.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
            // 자동채번 사용자ID 생성
            String newUserBassId = mapsIamUserBassInfoService.insertUserIdSeq(iamAcntReqstInfoVO, loginInfo);
            iamAcntReqstInfoVO.setUserBassId(newUserBassId);
            if (StringUtils.equals(iamAcntReqstInfoVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
                iamAcntReqstInfoVO.setUserId(newUserBassId);
                isAutoUserId = false;
            }
        }
        // 사용자ID 자동채번인 경우
        if (StringUtils.equals(iamAcntReqstInfoVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
            if (isAutoUserId) {
                // 자동채번 사용자ID 생성
                String newUserId = mapsIamUserBassInfoService.insertUserIdSeq(iamAcntReqstInfoVO, loginInfo);
                iamAcntReqstInfoVO.setUserId(newUserId);
            } else if (!StringUtils.equals(srchIamAcntReqstInfo.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) { 
                // 사용자기본ID가 사용자ID로 등록이 안된 경우 사용자기본ID를 사용
                String newUserSeqId = mapsIamAcntReqstInfoMDAO.selectUserSeqIdByUserBassId(iamAcntReqstInfoVO);
                if (StringUtils.isBlank(newUserSeqId)) {
                    iamAcntReqstInfoVO.setUserId(iamAcntReqstInfoVO.getUserBassId());
                }
            }
        } else {
            if (StringUtils.equals(iamAcntReqstInfoVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
                iamAcntReqstInfoVO.setUserBassId(iamAcntReqstInfoVO.getUserId());
            }
        }
        
        // 계정신청승인 정보 설정
        iamAcntReqstInfoVO.setApprvSttusCd(APPRV_STTUS_CD_APPROVAL);
        iamAcntReqstInfoVO.setReqstSttusCd(REQST_STTUS_CD_PUBLICATION);
        iamAcntReqstInfoVO.setChangeSeCd(MapsConstants.CRUD_CREATE);
        iamAcntReqstInfoVO.setChangeId(loginInfo.getUserSeqId());
        iamAcntReqstInfoVO.setApprvId(loginInfo.getUserSeqId());
        iamAcntReqstInfoVO.setRegistId(loginInfo.getUserSeqId());
        iamAcntReqstInfoVO.setUpdtId(loginInfo.getUserSeqId());
        // 초기 암호 설정
        iamAcntReqstInfoVO.setPwdChageSeCd(MapsIamConstants.PWD_CHAGE_SE_CD_NEW);
        iamAcntReqstInfoVO.setUserPwd(mapsIamUserService.selectGetPropInitlUserPwd(iamAcntReqstInfoVO.getUserId() , srchIamAcntReqstInfo.getSysSeCd() ));
        iamAcntReqstInfoVO.setBfePwd(iamAcntReqstInfoVO.getUserPwd());
        // 암호만료일자 정보 설정
        iamAcntReqstInfoVO.setPwdChageCyclDayCnt(mapsIamUserService.selectGetPropPwdChageCyclDayCnt());

        /* 사용자기본정보 등록 */
        // 계정신청 사용자기본정보 등록
        if (StringUtils.equals(srchIamAcntReqstInfo.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
            
            // 계정신청 사용자기본정보 등록
            mapsIamAcntReqstInfoMDAO.insertAcntReqstUserBassInfo(iamAcntReqstInfoVO);
            // 계정신청 사용자기본정보 변경이력 등록
            mapsIamAcntReqstInfoMDAO.insertAcntReqstUserBassChghst(iamAcntReqstInfoVO);
        }
        
        /* 사용자 등록 */
        // 계정신청 사용자 등록
        mapsIamAcntReqstInfoMDAO.insertAcntReqstUser(iamAcntReqstInfoVO);
        // 계정신청 사용자변경이력 등록
        mapsIamAcntReqstInfoMDAO.insertAcntReqstUserChghst(iamAcntReqstInfoVO);
        // 계정신청 사용자암호이력 등록
        mapsIamAcntReqstInfoMDAO.insertAcntReqstUserPwdChghst(iamAcntReqstInfoVO);
        
        /* 사용자 기타정보등록 */
        // 계정신청 사용자언어 등록
        MapsIamAcntReqstLangVO iamAcntReqstLangVO = new MapsIamAcntReqstLangVO();
        iamAcntReqstLangVO.setAcntReqstNo(iamAcntReqstInfoVO.getAcntReqstNo());
        iamAcntReqstLangVO.setUserSeqId(iamAcntReqstInfoVO.getUserSeqId());
        iamAcntReqstLangVO.setRegistId(loginInfo.getUserSeqId());
        iamAcntReqstLangVO.setUpdtId(loginInfo.getUserSeqId());
        mapsIamAcntReqstInfoMDAO.insertAcntReqstUserLang(iamAcntReqstLangVO);
        // 계정신청 사용자허용IP 등록
        MapsIamAcntReqstPermIpVO iamAcntReqstPermIpVO = new MapsIamAcntReqstPermIpVO();
        iamAcntReqstPermIpVO.setAcntReqstNo(iamAcntReqstInfoVO.getAcntReqstNo());
        iamAcntReqstPermIpVO.setUserSeqId(iamAcntReqstInfoVO.getUserSeqId());
        iamAcntReqstPermIpVO.setRegistId(loginInfo.getUserSeqId());
        iamAcntReqstPermIpVO.setUpdtId(loginInfo.getUserSeqId());
        mapsIamAcntReqstInfoMDAO.insertAcntReqstUserPermIp(iamAcntReqstPermIpVO);
        // 계정신청 사용자권한 등록
        MapsIamAcntReqstAuthorVO iamAcntReqstAuthorVO = new MapsIamAcntReqstAuthorVO();
        iamAcntReqstAuthorVO.setAcntReqstNo(iamAcntReqstInfoVO.getAcntReqstNo());
        iamAcntReqstAuthorVO.setUserSeqId(iamAcntReqstInfoVO.getUserSeqId());
        iamAcntReqstAuthorVO.setRegistId(loginInfo.getUserSeqId());
        iamAcntReqstAuthorVO.setUpdtId(loginInfo.getUserSeqId());
        mapsIamAcntReqstInfoMDAO.insertAcntReqstUserAuthor(iamAcntReqstAuthorVO);
        
        /* 계정신청승인 등록 */
        // 자동채번 사용자ID를 승인내용에 추가 적용.
        if (StringUtils.equals(srchIamAcntReqstInfo.getUserId(), MapsIamConstants.USER_ID_NEW)) {
            iamAcntReqstInfoVO.appendApprvCn("[Created User ID : " + iamAcntReqstInfoVO.getUserId() + "]");
        }
        procCnt = mapsIamAcntReqstInfoMDAO.updateAcntReqstApprv(iamAcntReqstInfoVO);
        if (procCnt != 1) {
            // 계정신청승인이 처리되지 않았습니다.
            throw new MapsBizException(messageSource, "ECI0000035", loginInfo.getUserLcale(), null);
        }
        // 계정신청변경이력 등록
        insertAcntReqstSttusChghst(srchIamAcntReqstInfo, iamAcntReqstInfoVO, loginInfo);

        /* 계정신청승인 이메일 발송 */
        MapsCommEmailTmplat emailAcntAppv = MapsCommEmailTmplat.IAM005;
        // 이메일제목
        String emailSj = emailAcntAppv.getSj(messageSource, iamAcntReqstInfoVO, loginInfo.getUserLcale());
        // 이메일 내용
        Map<String, Object> mEmailData = new HashMap<String, Object>();
        mEmailData.put("idxUrl", PropertiesUtil.getMapsUrl(iamAcntReqstInfoVO.getSysSeCd()));
        mEmailData.put("sysSeCd", iamAcntReqstInfoVO.getSysSeCd());
        mEmailData.put("sysSeNm", emailAcntAppv.getSysSeNm(mapsCommCodeService, iamAcntReqstInfoVO.getSysSeCd(), loginInfo.getLangCd()));
        mEmailData.put("userId", iamAcntReqstInfoVO.getUserId());
        mEmailData.put("userNm", iamAcntReqstInfoVO.getUserNm());
        mEmailData.put("userPwd", iamAcntReqstInfoVO.getUserPwd());
        mEmailData.put("acntReqstNo", iamAcntReqstInfoVO.getAcntReqstNo());
        mEmailData.put("initPwdChageDayCnt", iamAcntReqstInfoVO.getPwdChageCyclDayCnt());
        String emailCn = emailAcntAppv.getCn(mEmailData, loginInfo.getUserLcale());
        // 이메일전송정보 설정
        EmailSndngVO emailSndngVO = new EmailSndngVO();
        emailSndngVO.setSndngProgrm(this.getClass().getName());
        emailSndngVO.setSndngEmail(MapsIamUtil.getHelpEmail());
        emailSndngVO.setRecptnEmail(iamAcntReqstInfoVO.getEmail()); // MAIL TO
        emailSndngVO.setEmailSj(emailSj);
        emailSndngVO.setEmailBdt(emailCn);
        emailSndngVO.setHtmlYn("Y"); // HTML 여부
        emailSndngVO.setRegistId(iamAcntReqstInfoVO.getRegistId()); // 등록자
        // 이메일전송정보 등록
        mapsCommEmailService.insertEmail(emailSndngVO);

        return procCnt;
    }

    /**
     * 계정신청 승인 정합성 체크
     *
     * @param iamAcntReqstInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    private MapsIamAcntReqstInfoVO updateValidateAcntReqstApprv(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, LoginInfoVO loginInfo) throws Exception {

        MapsIamAcntReqstInfoVO srchIamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfo(iamAcntReqstInfoVO);
        if (srchIamAcntReqstInfo == null) {
            //승인할 계정신청 정보가 없습니다.
            throw new MapsBizException(messageSource, "ECI0000034", loginInfo.getUserLcale(), null);
        }
        if (!REQST_STTUS_CD_REQUSETING.equals(srchIamAcntReqstInfo.getReqstSttusCd())) {
            //계정신청상태가 신청중이 아닙니다.
            throw new MapsBizException(messageSource, "ECI0000031", loginInfo.getUserLcale(), null);
        }
        
        // 신규사용자인경우 이메일 체크
        if (StringUtils.equals(srchIamAcntReqstInfo.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
            
            selectHasUserBassEmail(srchIamAcntReqstInfo, loginInfo.getUserLcale());
            
            if (!StringUtils.equals(srchIamAcntReqstInfo.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
                iamAcntReqstInfoVO.setUserBassId(srchIamAcntReqstInfo.getUserBassId());
                iamAcntReqstInfoVO.setUserBassOrgnztSeCd(srchIamAcntReqstInfo.getUserBassOrgnztSeCd());
                iamAcntReqstInfoVO.setUserBassBsnOrgnztCd(srchIamAcntReqstInfo.getUserBassBsnOrgnztCd());
                iamAcntReqstInfoVO.setUserBassOrgnztCd(srchIamAcntReqstInfo.getUserBassOrgnztCd());
                iamAcntReqstInfoVO.setMoblphonNo(srchIamAcntReqstInfo.getMoblphonNo());
                iamAcntReqstInfoVO.setOffmTelno(srchIamAcntReqstInfo.getOffmTelno());
                iamAcntReqstInfoVO.setFaxTelno(srchIamAcntReqstInfo.getFaxTelno());
            }
        }
        iamAcntReqstInfoVO.setOriginUserBassId(srchIamAcntReqstInfo.getUserBassId());
        
        return srchIamAcntReqstInfo;
    }
    
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#updateAcntReqstReturn(com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateAcntReqstReturn(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , LoginInfoVO loginInfo) throws Exception {
        
        MapsIamAcntReqstInfoVO srchIamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfo(iamAcntReqstInfoVO);
        /* 조회정보 체크 */
        if (srchIamAcntReqstInfo == null) {
            // 반려할 계정신청 정보가 없습니다.
            throw new MapsBizException(messageSource, "ECI0000036", loginInfo.getUserLcale(), null);
        }
        
        if (!REQST_STTUS_CD_REQUSETING.equals(srchIamAcntReqstInfo.getReqstSttusCd())) {
            // 계정신청상태가 신청중이 아닙니다.
            throw new MapsBizException(messageSource, "ECI0000031", loginInfo.getUserLcale(), null);
        }
        /* 등록정보 체크 */
        if (StringUtils.isBlank(iamAcntReqstInfoVO.getApprvCn())) {
            // 승인내용은 필수 입력 항목입니다.
            throw new MapsBizException(messageSource, "ECI0000037", loginInfo.getUserLcale(), null);
        }
        
        int procCnt = 0;

        // 계정신청반려 정보 설정
        iamAcntReqstInfoVO.setApprvSttusCd(APPRV_STTUS_CD_RETURN);
        iamAcntReqstInfoVO.setReqstSttusCd(REQST_STTUS_CD_RETURN);
        iamAcntReqstInfoVO.setApprvId(loginInfo.getUserSeqId());
        iamAcntReqstInfoVO.setUpdtId(loginInfo.getUserSeqId());
        // 계정신청반려 등록
        procCnt = mapsIamAcntReqstInfoMDAO.updateAcntReqstApprv(iamAcntReqstInfoVO);
        if (procCnt != 1) {
            // 계정신청반려가 처리되지 않았습니다.
            throw new MapsBizException(messageSource, "ECI0000038", loginInfo.getUserLcale(), null);
        }
        // 계정신청변경이력 등록
        insertAcntReqstSttusChghst(srchIamAcntReqstInfo, iamAcntReqstInfoVO, loginInfo);
        
        /* 계정신청반려 이메일 발송 */
        MapsCommEmailTmplat emailAcntRtn = MapsCommEmailTmplat.IAM006;
        // 이메일제목
        String emailSj = emailAcntRtn.getSj(messageSource, iamAcntReqstInfoVO, loginInfo.getUserLcale());
        // 이메일 내용
        Map<String, Object> mEmailData = new HashMap<String, Object>();
        mEmailData.put("idxUrl", PropertiesUtil.getMapsUrl(iamAcntReqstInfoVO.getSysSeCd()));
        mEmailData.put("sysSeCd", iamAcntReqstInfoVO.getSysSeCd());
        mEmailData.put("sysSeNm", emailAcntRtn.getSysSeNm(mapsCommCodeService, iamAcntReqstInfoVO.getSysSeCd(), loginInfo.getLangCd()));
        mEmailData.put("userNm", iamAcntReqstInfoVO.getUserNm());
        mEmailData.put("acntReqstNo", iamAcntReqstInfoVO.getAcntReqstNo());
        mEmailData.put("email", iamAcntReqstInfoVO.getEmail());
        String emailCn = emailAcntRtn.getCn(mEmailData, loginInfo.getUserLcale());
        // 이메일전송정보 설정
        EmailSndngVO emailSndngVO = new EmailSndngVO();
        emailSndngVO.setSndngProgrm(this.getClass().getName());
        emailSndngVO.setSndngEmail(MapsIamUtil.getHelpEmail());
        emailSndngVO.setRecptnEmail(iamAcntReqstInfoVO.getEmail()); // MAIL TO
        emailSndngVO.setEmailSj(emailSj);
        emailSndngVO.setEmailBdt(emailCn);
        emailSndngVO.setHtmlYn("Y"); // HTML 여부
        emailSndngVO.setRegistId(iamAcntReqstInfoVO.getRegistId()); // 등록자
        // 이메일전송정보 등록
        mapsCommEmailService.insertEmail(emailSndngVO);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#selectNlognAcntReqstInfo(com.mobis.maps.iam.vo.MapsIamAcntReqstVO, java.lang.String)
     */
    @Override
    public MapsIamAcntReqstVO selectNlognAcntReqstInfo(MapsIamAcntReqstVO iamAcntReqstVO, String langCd) throws Exception {
        
        String acntReqstNo = iamAcntReqstVO.getAcntReqstNo();
        String email = iamAcntReqstVO.getEmail();
        Locale loginLocale = MapsIamUtil.getLocale(langCd);
        /* 조회정보 체크 */
        if (StringUtils.isBlank(acntReqstNo)) {
            MapsIamValidatorUtil.getMessageRequired("WI000000104", loginLocale);
        }
        if (StringUtils.isBlank(email)) {
            MapsIamValidatorUtil.getMessageRequired("W0000002762", loginLocale);
        }

        /* 계정신청정보 조회 */
        MapsIamAcntReqstInfoVO iamAcntReqstInfoVO = new MapsIamAcntReqstInfoVO();
        iamAcntReqstInfoVO.setAcntReqstNo(acntReqstNo);
        iamAcntReqstInfoVO.setEmail(email);
        iamAcntReqstInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamAcntReqstInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        iamAcntReqstInfoVO = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfo(iamAcntReqstInfoVO);
        if (iamAcntReqstInfoVO == null) {
            throw new MapsBizException(messageSource, "EC00000047", loginLocale, null);
        }
        
        /* 계정신청언어조회 */
        MapsIamAcntReqstLangVO iamAcntReqstLangVO = new MapsIamAcntReqstLangVO();
        iamAcntReqstLangVO.setAcntReqstNo(acntReqstNo);
        List<MapsIamAcntReqstLangVO> acntReqstLangs = mapsIamAcntReqstInfoMDAO.selectAcntReqstLangList(iamAcntReqstLangVO);
        
        /* 계정신청허용IP조회 */
        MapsIamAcntReqstPermIpVO iamAcntReqstPermIpVO = new MapsIamAcntReqstPermIpVO();
        iamAcntReqstPermIpVO.setAcntReqstNo(acntReqstNo);
        List<MapsIamAcntReqstPermIpVO> acntReqstPermIps = mapsIamAcntReqstInfoMDAO.selectAcntReqstPermIpList(iamAcntReqstPermIpVO);
        
        /* 계정신청권한조회 */
        MapsIamAcntReqstAuthorVO iamAcntReqstAuthorVO = new MapsIamAcntReqstAuthorVO();
        iamAcntReqstAuthorVO.setAcntReqstNo(acntReqstNo);
        List<MapsIamAcntReqstAuthorVO> acntReqstAuthors = mapsIamAcntReqstInfoMDAO.selectAcntReqstAuthorList(iamAcntReqstAuthorVO);
        
        iamAcntReqstVO.setIamAcntReqstInfo(iamAcntReqstInfoVO);
        iamAcntReqstVO.setAcntReqstLangs(acntReqstLangs);
        iamAcntReqstVO.setAcntReqstPermIps(acntReqstPermIps);
        iamAcntReqstVO.setAcntReqstAuthors(acntReqstAuthors);
        
        return iamAcntReqstVO;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#selectNlognAuthorMstList(com.mobis.maps.iam.vo.MapsIamAuthorVO)
     */
    @Override
    public List<MapsIamAuthorVO> selectNlognAuthorMstList(MapsIamAuthorVO iamAuthorVO) throws Exception {

        List<MapsIamAuthorVO> lstAuthorMst = mapsIamAcntReqstInfoMDAO.selectNlognAuthorMstList(iamAuthorVO);
        
        return lstAuthorMst;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#selectUserBassInfoByEmail(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO)
     */
    @Override
    public MapsIamUserBassInfoVO selectUserBassInfoByEmail(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception {

        iamUserBassInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserBassInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        MapsIamUserBassInfoVO iamUserBassInfo = mapsIamAcntReqstInfoMDAO.selectUserBassInfoByEmail(iamUserBassInfoVO);
        
        return iamUserBassInfo;
    }


    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#insertNlognReqstAcnt(com.mobis.maps.iam.vo.MapsIamAcntReqstVO, java.lang.String)
     */
    @Override
    public int insertNlognReqstAcnt(MapsIamAcntReqstVO iamAcntReqstVO, String langCd) throws Exception {

        // 계정신청정보 설정
        MapsIamAcntReqstInfoVO iamAcntReqstInfoVO = iamAcntReqstVO.getIamAcntReqstInfo();
        iamAcntReqstInfoVO.setReqstSttusCd(REQST_STTUS_CD_REQUSETING);

        /* 정합성체크 */
        Locale loginLocale = MapsIamUtil.getLocale(langCd);
        // 사용자ID 자동채번인 경우 사용자ID 체크
        selectIsAutoUserId(iamAcntReqstInfoVO, loginLocale);
        // 신규사용자인경우 이메일 체크
        if (StringUtils.equals(iamAcntReqstInfoVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
            selectHasUserBassEmail(iamAcntReqstInfoVO, loginLocale);
        }
        // 계정등록여부 체크(시스템구분코드+사용자ID)
        selectHasAcntInfo(iamAcntReqstInfoVO, loginLocale);
        // 계정신청정보 체크
        selectHasAcntReqstInfo(iamAcntReqstInfoVO, loginLocale);
        // 계정신청nMGN조직정보 체크
        MapsOrgnztDistVO orgnztDistVO = MapsIamValidatorUtil.validateAcntReqstDistOrgnzt(iamAcntReqstInfoVO, loginLocale);
        // 개인정보 수집 및 이용에 동의하셔야합니다. 
        if (!StringUtils.equals(iamAcntReqstInfoVO.getIndvdlinfoColctUseAgreYn(), MapsConstants.YN_YES)) {
            throw new MapsBizException(messageSource, "ECI0000091", loginLocale, null);
        }

        /* 초기값 설정 */
        // 관리자메일정보 조회 및 관리자 설정
        List<MapsIamUserVO> mngrEmails = mapsIamUserService.selectMngrEmailList(iamAcntReqstInfoVO, orgnztDistVO, false);
        if (mngrEmails.isEmpty()) {
            iamAcntReqstInfoVO.setMngrId(MapsIamConstants.SYSTEM_USER_SEQ_ID);
        } else {
            iamAcntReqstInfoVO.setMngrId(mngrEmails.get(0).getUserSeqId());
        }
        // 로그인정보 초기 설정
        LoginInfoVO loginInfo = new LoginInfoVO();
        loginInfo.setUserSeqId(iamAcntReqstInfoVO.getMngrId());

        // 사용자기본조직정보 설정
        if (StringUtils.equals(iamAcntReqstInfoVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
            iamAcntReqstInfoVO.setUserBassOrgnztSeCd(iamAcntReqstInfoVO.getOrgnztSeCd());
            iamAcntReqstInfoVO.setUserBassBsnOrgnztCd(iamAcntReqstInfoVO.getBsnOrgnztCd());
            iamAcntReqstInfoVO.setUserBassOrgnztCd(iamAcntReqstInfoVO.getOrgnztCd());
            iamAcntReqstInfoVO.setUserBassDealerCd(iamAcntReqstInfoVO.getDealerCd());
            if (!iamAcntReqstInfoVO.getUserBassOrgnztSeCd().matches("G|N|D|E")) {
                // 사용할 수 없는 사용자기본ID입니다.
                throw new MapsBizException(messageSource, "ECI0000092", loginLocale, null);
            }
        }
        if (StringUtils.equals(iamAcntReqstInfoVO.getUserId(), MapsIamConstants.USER_ID_NEW)) {
            if (!iamAcntReqstInfoVO.getOrgnztSeCd().matches("G|N|D|E")) {
                // 사용할 수 없는 사용자ID입니다.
                throw new MapsBizException(messageSource, "ECI0000093", loginLocale, null);
            }
        }
        // 타임존(=한국표준시)
        iamAcntReqstInfoVO.setTzoneCd("TZ0309");
        // 희망일시(=당일)
        iamAcntReqstInfoVO.setUseHopeDe(Calendar.getInstance().getTime());
        // 사용자언어
        Locale localeUserLang = MapsIamUtil.getDfltUserLangCd(iamAcntReqstInfoVO.getSysSeCd());
        List<MapsIamAcntReqstLangVO> acntReqstLangs = new ArrayList<MapsIamAcntReqstLangVO>();
        MapsIamAcntReqstLangVO iamAcntReqstLangVO = new MapsIamAcntReqstLangVO();
        iamAcntReqstLangVO.setLangCd(localeUserLang.toString());
        acntReqstLangs.add(iamAcntReqstLangVO);
        iamAcntReqstVO.setAcntReqstLangs(acntReqstLangs);
        iamAcntReqstInfoVO.setPermIpUseYn(MapsConstants.YN_NO);
        // 처리사용자ID설정
        iamAcntReqstInfoVO.setRegistId(loginInfo.getUserSeqId());
        iamAcntReqstInfoVO.setUpdtId(loginInfo.getUserSeqId());
        
        /* 계정신청정보 등록 */
        mapsIamAcntReqstInfoMDAO.insertAcntReqstInfo(iamAcntReqstInfoVO);
        // 계정신청변경이력 등록
        insertAcntReqstSttusChghst(null, iamAcntReqstInfoVO, loginInfo);
        // 계정신청 서브정보 등록
        insertAcntReqstSubInfos(iamAcntReqstVO, loginInfo);
        
        /* 메일발송 */
        insertSendMailReqstAcnt(iamAcntReqstInfoVO, mngrEmails, langCd);
        
        return 1;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstInfoService#deleteNlognAcntReqstInfo(com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO, java.lang.String)
     */
    @Override
    public int deleteNlognAcntReqstInfo(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, String langCd) throws Exception {
        
        int procCnt = 0;
        Locale loginLocale = MapsIamUtil.getLocale(langCd);

        MapsIamAcntReqstInfoVO srchIamAcntReqstInfo = mapsIamAcntReqstInfoMDAO.selectAcntReqstInfo(iamAcntReqstInfoVO);
        if (srchIamAcntReqstInfo == null) {
            // 삭제할 계정신청 정보가 없습니다.
            throw new MapsBizException(messageSource, "ECI0000038", loginLocale, null);
        }
        
        if (!REQST_STTUS_CD_REQUSETING.equals(srchIamAcntReqstInfo.getReqstSttusCd())) {
            // 계정신청상태가 신청중이 아닙니다.
            throw new MapsBizException(messageSource, "ECI0000030", loginLocale, null);
        }
        
        iamAcntReqstInfoVO.setUpdtId(MapsIamConstants.SYSTEM_USER_SEQ_ID);
        
        procCnt = mapsIamAcntReqstInfoMDAO.deleteAcntReqstInfo(iamAcntReqstInfoVO);
        
        return procCnt;
    }
}
