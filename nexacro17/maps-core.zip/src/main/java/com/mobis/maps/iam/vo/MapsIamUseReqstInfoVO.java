package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * 계정사용 신청 항목
 * </pre>
 *
 * @ClassName   : MapsIamUseReqstInfoVO.java
 * @Description : 계정사용 신청 항목을 정의
 * @author DT048657
 * @since 2020. 1. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 29.     DT048657     	최초 생성
 * </pre>
 */
public class MapsIamUseReqstInfoVO extends MapsIamCommVO {
    
    /** 사용신청ID */
    private String useReqstId;
    /** 사용자ID */
    private String userSeqId;
    /** 로그인ID */
    private String userId;
    /** 사용자명 */
    private String userNm;
    /** 선호언어 */
    private String preferLangCd;
    /** 사무실전화번호 */
    private String offmTelno;
    /** 휴대전화번호 */
    private String moblphonNo;
    /** 팩스번호 */
    private String fxnum;
    /** 이메일주소 */
    private String emailAdres;
    /** 계정잠금여부 */
    private String acntLockYn;
    /** 계정잠금사유 */
    private String acntCptalPrvonsh;
    /** 암호오류횟수 */
    private String pwdErrorCo;
    /** 사용여부 */
    private String useYn;      
    /** 허용IP사용여부 */
    private String permIpUseYn;
    
    
    /** 승인CD */
    private String confmCd;
    /** 신청사유 */
    private String reqstPrvonsh;
    /** 반려사유 */
    private String returnPrvonsh;
    /** 사유 */
    private String prvonsh;    
    /** 사용신청일 */
    private Date useRqstdt;
    /** 시스템구분CD */
    private String sysSeCd;   
    /** SAP고객식별자 */
    private String sapUserId;
    /** 계정유형코드 */
    private String acntTyCd;
    /** 영업조직(법인코드) */
    private String corpCd;
    /** 영업조직(법인코드)-SAP */
    private String vkorg;
    /** 유통경로 */
    private String vtweg;
    /** 고객번호 */
    private String kunnr;
    /** AS-IS고객코드 */
    private String zsacutm;
    /** 고객유형 */
    private String kvgr2;
    /** 고객세부유형 */
    private String kvgr3;
    /** CustomerType */
    private String kvgr4;
    /** 고객코드 */
    private String zkunnr;
    /** 딜러코드 */
    private String zdealer;
    /** 대표대리점코드 */
    private String zkunn2;
    /** 대표딜러코드 */
    private String zdeale2;   
    /** 영업조직이름 */
    private String zvknam;
    /** 대리점상호 */
    private String zkunam;
    /** 딜러상호 */
    private String zdlrnam;
    /** 대표대리점상호 */
    private String zku2nam;
    /** 대표딜러상호 */
    private String zdlr2nam;
    /** 신청FROM일 */
    private String useFromDate;
    /** 신청TO일 */
    private String useToDate;
    
    
    /**
     * @return the useReqstId
     */
    public String getUseReqstId() {
        return useReqstId;
    }
    /**
     * @param useReqstId the useReqstId to set
     */
    public void setUseReqstId(String useReqstId) {
        this.useReqstId = useReqstId;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userNm
     */
    public String getUserNm() {
        return userNm;
    }
    /**
     * @param userNm the userNm to set
     */
    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }
    /**
     * @return the preferLangCd
     */
    public String getPreferLangCd() {
        return preferLangCd;
    }
    /**
     * @param preferLangCd the preferLangCd to set
     */
    public void setPreferLangCd(String preferLangCd) {
        this.preferLangCd = preferLangCd;
    }
    /**
     * @return the offmTelno
     */
    public String getOffmTelno() {
        return offmTelno;
    }
    /**
     * @param offmTelno the offmTelno to set
     */
    public void setOffmTelno(String offmTelno) {
        this.offmTelno = offmTelno;
    }
    /**
     * @return the moblphonNo
     */
    public String getMoblphonNo() {
        return moblphonNo;
    }
    /**
     * @param moblphonNo the moblphonNo to set
     */
    public void setMoblphonNo(String moblphonNo) {
        this.moblphonNo = moblphonNo;
    }
    /**
     * @return the fxnum
     */
    public String getFxnum() {
        return fxnum;
    }
    /**
     * @param fxnum the fxnum to set
     */
    public void setFxnum(String fxnum) {
        this.fxnum = fxnum;
    }
    /**
     * @return the emailAdres
     */
    public String getEmailAdres() {
        return emailAdres;
    }
    /**
     * @param emailAdres the emailAdres to set
     */
    public void setEmailAdres(String emailAdres) {
        this.emailAdres = emailAdres;
    }
    /**
     * @return the acntLockYn
     */
    public String getAcntLockYn() {
        return acntLockYn;
    }
    /**
     * @param acntLockYn the acntLockYn to set
     */
    public void setAcntLockYn(String acntLockYn) {
        this.acntLockYn = acntLockYn;
    }
    /**
     * @return the acntCptalPrvonsh
     */
    public String getAcntCptalPrvonsh() {
        return acntCptalPrvonsh;
    }
    /**
     * @param acntCptalPrvonsh the acntCptalPrvonsh to set
     */
    public void setAcntCptalPrvonsh(String acntCptalPrvonsh) {
        this.acntCptalPrvonsh = acntCptalPrvonsh;
    }
    /**
     * @return the pwdErrorCo
     */
    public String getPwdErrorCo() {
        return pwdErrorCo;
    }
    /**
     * @param pwdErrorCo the pwdErrorCo to set
     */
    public void setPwdErrorCo(String pwdErrorCo) {
        this.pwdErrorCo = pwdErrorCo;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * @return the permIpUseYn
     */
    public String getPermIpUseYn() {
        return permIpUseYn;
    }
    /**
     * @param permIpUseYn the permIpUseYn to set
     */
    public void setPermIpUseYn(String permIpUseYn) {
        this.permIpUseYn = permIpUseYn;
    }
    /**
     * @return the confmCd
     */
    public String getConfmCd() {
        return confmCd;
    }
    /**
     * @param confmCd the confmCd to set
     */
    public void setConfmCd(String confmCd) {
        this.confmCd = confmCd;
    }
    /**
     * @return the reqstPrvonsh
     */
    public String getReqstPrvonsh() {
        return reqstPrvonsh;
    }
    /**
     * @param reqstPrvonsh the reqstPrvonsh to set
     */
    public void setReqstPrvonsh(String reqstPrvonsh) {
        this.reqstPrvonsh = reqstPrvonsh;
    }
    /**
     * @return the returnPrvonsh
     */
    public String getReturnPrvonsh() {
        return returnPrvonsh;
    }
    /**
     * @param returnPrvonsh the returnPrvonsh to set
     */
    public void setReturnPrvonsh(String returnPrvonsh) {
        this.returnPrvonsh = returnPrvonsh;
    }
    /**
     * @return the prvonsh
     */
    public String getPrvonsh() {
        return prvonsh;
    }
    /**
     * @param prvonsh the prvonsh to set
     */
    public void setPrvonsh(String prvonsh) {
        this.prvonsh = prvonsh;
    }
    /**
     * @return the useRqstdt
     */
    public Date getUseRqstdt() {
        return useRqstdt;
    }
    /**
     * @param useRqstdt the useRqstdt to set
     */
    public void setUseRqstdt(Date useRqstdt) {
        this.useRqstdt = useRqstdt;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the sapUserId
     */
    public String getSapUserId() {
        return sapUserId;
    }
    /**
     * @param sapUserId the sapUserId to set
     */
    public void setSapUserId(String sapUserId) {
        this.sapUserId = sapUserId;
    }
    /**
     * @return the acntTyCd
     */
    public String getAcntTyCd() {
        return acntTyCd;
    }
    /**
     * @param acntTyCd the acntTyCd to set
     */
    public void setAcntTyCd(String acntTyCd) {
        this.acntTyCd = acntTyCd;
    }
    /**
     * @return the corpCd
     */
    public String getCorpCd() {
        return corpCd;
    }
    /**
     * @param corpCd the corpCd to set
     */
    public void setCorpCd(String corpCd) {
        this.corpCd = corpCd;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the kvgr2
     */
    public String getKvgr2() {
        return kvgr2;
    }
    /**
     * @param kvgr2 the kvgr2 to set
     */
    public void setKvgr2(String kvgr2) {
        this.kvgr2 = kvgr2;
    }
    /**
     * @return the kvgr3
     */
    public String getKvgr3() {
        return kvgr3;
    }
    /**
     * @param kvgr3 the kvgr3 to set
     */
    public void setKvgr3(String kvgr3) {
        this.kvgr3 = kvgr3;
    }
    /**
     * @return the kvgr4
     */
    public String getKvgr4() {
        return kvgr4;
    }
    /**
     * @param kvgr4 the kvgr4 to set
     */
    public void setKvgr4(String kvgr4) {
        this.kvgr4 = kvgr4;
    }
    /**
     * @return the zkunnr
     */
    public String getZkunnr() {
        return zkunnr;
    }
    /**
     * @param zkunnr the zkunnr to set
     */
    public void setZkunnr(String zkunnr) {
        this.zkunnr = zkunnr;
    }
    /**
     * @return the zdealer
     */
    public String getZdealer() {
        return zdealer;
    }
    /**
     * @param zdealer the zdealer to set
     */
    public void setZdealer(String zdealer) {
        this.zdealer = zdealer;
    }
    /**
     * @return the zkunn2
     */
    public String getZkunn2() {
        return zkunn2;
    }
    /**
     * @param zkunn2 the zkunn2 to set
     */
    public void setZkunn2(String zkunn2) {
        this.zkunn2 = zkunn2;
    }
    /**
     * @return the zdeale2
     */
    public String getZdeale2() {
        return zdeale2;
    }
    /**
     * @param zdeale2 the zdeale2 to set
     */
    public void setZdeale2(String zdeale2) {
        this.zdeale2 = zdeale2;
    }
    /**
     * @return the zvknam
     */
    public String getZvknam() {
        return zvknam;
    }
    /**
     * @param zvknam the zvknam to set
     */
    public void setZvknam(String zvknam) {
        this.zvknam = zvknam;
    }
    /**
     * @return the zkunam
     */
    public String getZkunam() {
        return zkunam;
    }
    /**
     * @param zkunam the zkunam to set
     */
    public void setZkunam(String zkunam) {
        this.zkunam = zkunam;
    }
    /**
     * @return the zdlrnam
     */
    public String getZdlrnam() {
        return zdlrnam;
    }
    /**
     * @param zdlrnam the zdlrnam to set
     */
    public void setZdlrnam(String zdlrnam) {
        this.zdlrnam = zdlrnam;
    }
    /**
     * @return the zku2nam
     */
    public String getZku2nam() {
        return zku2nam;
    }
    /**
     * @param zku2nam the zku2nam to set
     */
    public void setZku2nam(String zku2nam) {
        this.zku2nam = zku2nam;
    }
    /**
     * @return the zdlr2nam
     */
    public String getZdlr2nam() {
        return zdlr2nam;
    }
    /**
     * @param zdlr2nam the zdlr2nam to set
     */
    public void setZdlr2nam(String zdlr2nam) {
        this.zdlr2nam = zdlr2nam;
    }
    /**
     * @return the useFromDate
     */
    public String getUseFromDate() {
        return useFromDate;
    }
    /**
     * @param useFromDate the useFromDate to set
     */
    public void setUseFromDate(String useFromDate) {
        this.useFromDate = useFromDate;
    }
    /**
     * @return the useToDate
     */
    public String getUseToDate() {
        return useToDate;
    }
    /**
     * @param useToDate the useToDate to set
     */
    public void setUseToDate(String useToDate) {
        this.useToDate = useToDate;
    }
   
           
}
