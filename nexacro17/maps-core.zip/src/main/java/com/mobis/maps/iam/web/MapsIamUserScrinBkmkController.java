package com.mobis.maps.iam.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamUserScrinBkmkService;
import com.mobis.maps.iam.vo.MapsIamUserScrinBkmkVO;

/**
 * <pre>
 * 사용자 화면 즐겨찾기 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinBkmkController.java
 * @Description : 사용자 화면 즐겨찾기에 대한 컨트롤러를 정의.
 * @author DT048058
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamUserScrinBkmkController extends HController {
    
    @Resource(name = "mapsIamUserScrinBkmkService")
    private MapsIamUserScrinBkmkService mapsIamUserScrinBkmkService;
    
    /**
     * 사용자 화면 즐겨찾기 리스트 조회
     *
     * @param iamUserScrinBkmkVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectUserScrinBkmkList.do")
    public NexacroResult selectUserScrinBkmkList(
            @ParamDataSet(name="dsInput") MapsIamUserScrinBkmkVO iamUserScrinBkmkVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsIamUserScrinBkmkVO> userScrinBkmks = mapsIamUserScrinBkmkService.selectUserScrinBkmkList(iamUserScrinBkmkVO, loginInfo);
                
        result.addDataSet("dsOutput", userScrinBkmks);        
        
        return result;
    }

    /**
     * 사용자 화면 즐겨찾기 등록
     *
     * @param iamUserScrinBkmkVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/insertUserScrinBkmk.do")
    public NexacroResult insertUserScrinBkmk(
            @ParamDataSet(name="dsInput") MapsIamUserScrinBkmkVO iamUserScrinBkmkVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamUserScrinBkmkService.insertUserScrinBkmk(iamUserScrinBkmkVO, loginInfo);
                
        result.addVariable("procCnt", procCnt);    
        
        return result;
    }

    /**
     * 사용자 화면 즐겨찾기 삭제
     *
     * @param iamUserScrinBkmkVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/deleteUserScrinBkmk.do")
    public NexacroResult deleteUserScrinBkmk(
            @ParamDataSet(name="dsInput") MapsIamUserScrinBkmkVO iamUserScrinBkmkVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int procCnt = mapsIamUserScrinBkmkService.deleteUserScrinBkmk(iamUserScrinBkmkVO, loginInfo);
                
        result.addVariable("procCnt", procCnt);    
        
        return result;
    }
}
