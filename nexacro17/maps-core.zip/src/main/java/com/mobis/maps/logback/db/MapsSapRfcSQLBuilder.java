package com.mobis.maps.logback.db;

import com.mobis.maps.logback.db.names.MapsSapRfcColumnName;
import com.mobis.maps.logback.db.names.MapsSapRfcTableName;

import ch.qos.logback.classic.db.names.DBNameResolver;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSapRfcSQLBuilder.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 7.     DT048058     	최초 생성
 * </pre>
 */

public class MapsSapRfcSQLBuilder {

    
    static String buildInsertPropertiesSQL(DBNameResolver dbNameResolver) {
        StringBuilder sqlBuilder = new StringBuilder("INSERT INTO COMNDB.");
        sqlBuilder.append(dbNameResolver.getTableName(MapsSapRfcTableName.T_RFC_EXECUT_LOG_DATA)).append(" (");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.EVENT_ID)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.RFC_IPTT_SE)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.RFC_FIELD)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.RFC_DATA_TY)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.RFC_DATA)).append(") ");
        sqlBuilder.append("VALUES (?, ?, ?, ?, ?)");
        return sqlBuilder.toString();
    }

    static String buildInsertExceptionSQL(DBNameResolver dbNameResolver) {
        StringBuilder sqlBuilder = new StringBuilder("INSERT INTO COMNDB.");
        sqlBuilder.append(dbNameResolver.getTableName(MapsSapRfcTableName.T_RFC_EXECUT_LOG_EXCP)).append(" (");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.EVENT_ID)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.I)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.TRACE_LINE)).append(") ");
        sqlBuilder.append("VALUES (?, ?, ?)");
        return sqlBuilder.toString();
    }

    static String buildInsertSQL(DBNameResolver dbNameResolver) {
        StringBuilder sqlBuilder = new StringBuilder("INSERT INTO COMNDB.");
        sqlBuilder.append(dbNameResolver.getTableName(MapsSapRfcTableName.T_RFC_EXECUT_LOG)).append(" (");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.SYS_ID)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.RFC_ID)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.RFC_SERVER)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.RFC_CLIENT)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.RFC_LANG)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.SCRIN_ID)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.USER_ID)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.LGI_IP_ADRES)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.THREAD_NM)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.LOG_LEVEL)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.LOG_IPTT)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.LOG_MSG)).append(", ");
        sqlBuilder.append(dbNameResolver.getColumnName(MapsSapRfcColumnName.LOG_DT)).append(") ");
        sqlBuilder.append("VALUES (?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        return sqlBuilder.toString();
    }
}
