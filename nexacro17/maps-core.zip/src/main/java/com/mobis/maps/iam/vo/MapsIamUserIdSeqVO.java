package com.mobis.maps.iam.vo;

import java.util.Date;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsIamUserIdSeqVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 8. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 11.     oh.dongwon     	최초 생성
 * </pre>
 */

public class MapsIamUserIdSeqVO {
    /** 조직구분코드 */
    private String orgnztSeCd;
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 조직코드 */
    private String orgnztCd;
    /** 딜러코드 */
    private String dealerCd;
    /** 사용자ID순번 */
    private int userIdSn;
    /** 사용자ID순번16진수 */
    private String userIdSnHex;
    /** 사용자ID */
    private String userId;
    /** 생성자ID */
    private String registId;
    /** 생성일시 */
    private Date registDt;
    /** 수정자ID */
    private String updtId;
    /** 수정일시 */
    private Date updtDt;

    /**
     * @return the orgnztSeCd
     */
    public String getOrgnztSeCd() {
        return orgnztSeCd;
    }
    /**
     * @param orgnztSeCd the orgnztSeCd to set
     */
    public void setOrgnztSeCd(String orgnztSeCd) {
        this.orgnztSeCd = orgnztSeCd;
    }
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the orgnztCd
     */
    public String getOrgnztCd() {
        return orgnztCd;
    }
    /**
     * @param orgnztCd the orgnztCd to set
     */
    public void setOrgnztCd(String orgnztCd) {
        this.orgnztCd = orgnztCd;
    }
    /**
     * @return the dealerCd
     */
    public String getDealerCd() {
        return dealerCd;
    }
    /**
     * @param dealerCd the dealerCd to set
     */
    public void setDealerCd(String dealerCd) {
        this.dealerCd = dealerCd;
    }
    /**
     * @return the userIdSn
     */
    public int getUserIdSn() {
        return userIdSn;
    }
    /**
     * @param userIdSn the userIdSn to set
     */
    public void setUserIdSn(int userIdSn) {
        this.userIdSn = userIdSn;
    }
    /**
     * @return the userIdSnHex
     */
    public String getUserIdSnHex() {
        return userIdSnHex;
    }
    /**
     * @param userIdSnHex the userIdSnHex to set
     */
    public void setUserIdSnHex(String userIdSnHex) {
        this.userIdSnHex = userIdSnHex;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }
    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }
    /**
     * @return the registDt
     */
    public Date getRegistDt() {
        return registDt;
    }
    /**
     * @param registDt the registDt to set
     */
    public void setRegistDt(Date registDt) {
        this.registDt = registDt;
    }
    /**
     * @return the updtId
     */
    public String getUpdtId() {
        return updtId;
    }
    /**
     * @param updtId the updtId to set
     */
    public void setUpdtId(String updtId) {
        this.updtId = updtId;
    }
    /**
     * @return the updtDt
     */
    public Date getUpdtDt() {
        return updtDt;
    }
    /**
     * @param updtDt the updtDt to set
     */
    public void setUpdtDt(Date updtDt) {
        this.updtDt = updtDt;
    }
    
}
