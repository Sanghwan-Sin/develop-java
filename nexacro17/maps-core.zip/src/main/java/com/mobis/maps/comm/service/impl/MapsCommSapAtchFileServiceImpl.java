package com.mobis.maps.comm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.MapsSapRfcInfo;
import com.mobis.maps.comm.service.MapsCommSapAtchFileService;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileChkVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileCntVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * SAP 첨부파일 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommSapAtchFileServiceImpl.java
 * @Description : SAP 첨부파일에 대한 서비스를 구현.
 * @author DT048058
 * @since 2020. 3. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 3.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsCommSapAtchFileService")
public class MapsCommSapAtchFileServiceImpl extends HService implements MapsCommSapAtchFileService {
    
    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#selectSapAtchFileList(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileVO> selectSapAtchFileList(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileList::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_LIST;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_LIST, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<MapsCommSapAtchFileVO> lstFile = MapsRfcMappperUtil.getExportTableValues(funcRslt, FIELD_TARGET_IT_ATTACH, MapsCommSapAtchFileVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileList::end");
        }
        
        return lstFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#selectSapAtchFileDetail(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileVO selectSapAtchFileDetail(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFile::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_CONTENT;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_CONTENT, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileVO esFile = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFile::end");
        }
        
        return esFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#selectSapAtchFileCnt(com.mobis.maps.comm.vo.MapsCommSapAtchFileInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileInfoVO selectSapAtchFileCnt(MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileCnt::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_COUNT;
        commSapAtchFileInfoVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileInfoVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_COUNT, commSapAtchFileInfoVO);
        
        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileInfoVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileInfoVO esCount = MapsRfcMappperUtil.getExportStructure(funcRslt, FIELD_TARGET_ES_ATTACH_COUNT, MapsCommSapAtchFileInfoVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileCnt::end");
        }

        return esCount;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#selectSapAtchFileCntList(com.mobis.maps.comm.vo.MapsCommSapAtchFileCntVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileCntVO> selectSapAtchFileCntList(MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , List<MapsCommSapAtchFileCntVO> refNos
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileCntList::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_ITEM_SUM;
        commSapAtchFileCntVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileCntVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, commSapAtchFileCntVO);
        
        for (MapsCommSapAtchFileCntVO refNoVO : refNos) {
            MapsRfcMappperUtil.appendImportStructureTableRow(func, FIELD_TARGET_I_REF_NO_T, refNoVO);
        }
        

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileCntVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<MapsCommSapAtchFileCntVO> lstSapFileCnt = MapsRfcMappperUtil.getExportTableValues(funcRslt, FIELD_TARGET_IT_ATTACH_SUM, MapsCommSapAtchFileCntVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileCntList::end");
        }
        
        return lstSapFileCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#selectSapAtchFileSumryCnt(com.mobis.maps.comm.vo.MapsCommSapAtchFileCntVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileCntVO> selectSapAtchFileSumryCnt(MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , List<MapsCommSapAtchFileCntVO> refNos
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileSumryCnt::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_ITEM_SUM2;
        commSapAtchFileCntVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileCntVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, commSapAtchFileCntVO);
        for (MapsCommSapAtchFileCntVO refNoVO : refNos) {
            MapsRfcMappperUtil.appendImportStructureTableRow(func, FIELD_TARGET_I_REF_NO_T, refNoVO);
        }

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileCntVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<MapsCommSapAtchFileCntVO> lstSapFileSumryCnt = MapsRfcMappperUtil.getExportTableValues(funcRslt,  FIELD_TARGET_IT_ATTACH_SUM, MapsCommSapAtchFileCntVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileSumryCnt::end");
        }
        
        return lstSapFileSumryCnt;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#selectSapAtchFileRegistInfo(com.mobis.maps.comm.vo.MapsCommSapAtchFileInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, MapsCommSapAtchFileInfoVO> selectSapAtchFileRegistInfo(MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileInfo::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_CREATE_INFO;
        commSapAtchFileInfoVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileInfoVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_INFO, commSapAtchFileInfoVO);
        
        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileInfoVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        Map<String, MapsCommSapAtchFileInfoVO> rtnEs = new HashMap<String, MapsCommSapAtchFileInfoVO>();
        
        MapsCommSapAtchFileInfoVO esConfig = MapsRfcMappperUtil.getExportStructure(funcRslt, FIELD_TARGET_ES_CONFIG, MapsCommSapAtchFileInfoVO.class);
        rtnEs.put(MAP_KEY_ES_CONFIG, esConfig);
        MapsCommSapAtchFileInfoVO esMaster = MapsRfcMappperUtil.getExportStructure(funcRslt, FIELD_TARGET_ES_MASTER, MapsCommSapAtchFileInfoVO.class);
        rtnEs.put(MAP_KEY_ES_MASTER, esMaster);
        MapsCommSapAtchFileInfoVO esCreate = MapsRfcMappperUtil.getExportStructure(funcRslt, FIELD_TARGET_ES_CREATE, MapsCommSapAtchFileInfoVO.class);
        rtnEs.put(MAP_KEY_ES_CREATE, esCreate);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileInfo::end");
        }
        
        return rtnEs;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#selectSapAtchFileChk(com.mobis.maps.comm.vo.MapsCommSapAtchFileChkVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileChkVO selectSapAtchFileChk(MapsCommSapAtchFileChkVO commSapAtchFileChkVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileChk::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_CONTENT;
        commSapAtchFileChkVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileChkVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, commSapAtchFileChkVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileChkVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileChkVO esFileChk = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileChkVO.class);
        
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSapAtchFileChk::end");
        }
        return esFileChk;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#insertSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileVO insertSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ insertSapAtchFile::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_CREATE;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_CREATE, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        // RFC 호출 애러처리
        if (StringUtils.equals(commSapAtchFileVO.getMsgType(), MapsConstants.MESSAGE_TYPE_ERROR)) {
            throw new MapsBizException(commSapAtchFileVO.getMsg());
        }
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileVO esFile = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileVO.class);
        
        if (logger.isDebugEnabled()) {
            logger.debug("→ insertSapAtchFile::end");
        }
        return esFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#updateSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileVO updateSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ updateSapAtchFile::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_UPDATE;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_UPDATE, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        // RFC 호출 애러처리
        if (StringUtils.equals(commSapAtchFileVO.getMsgType(), MapsConstants.MESSAGE_TYPE_ERROR)) {
            throw new MapsBizException(commSapAtchFileVO.getMsg());
        }
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileVO esFile = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileVO.class);
        
        if (logger.isDebugEnabled()) {
            logger.debug("→ updateSapAtchFile::end");
        }
        return esFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#deleteSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsCommSapAtchFileVO deleteSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ updateSapAtchFile::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_DELETE;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_DELETE, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        // RFC 호출 애러처리
        if (StringUtils.equals(commSapAtchFileVO.getMsgType(), MapsConstants.MESSAGE_TYPE_ERROR)) {
            throw new MapsBizException(commSapAtchFileVO.getMsg());
        }
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        MapsCommSapAtchFileVO esFile = MapsRfcMappperUtil.getExportStructure(funcRslt,  FIELD_TARGET_ES_ATTACH, MapsCommSapAtchFileVO.class);
        
        if (logger.isDebugEnabled()) {
            logger.debug("→ updateSapAtchFile::end");
        }
        return esFile;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommSapAtchFileService#deleteAllSapAtchFile(com.mobis.maps.comm.vo.MapsCommSapAtchFileVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommSapAtchFileVO> deleteAllSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ deleteAllSapAtchFile::start");
        }
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_CHNNL_R_FILE_DELETE_ALL;
        commSapAtchFileVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, commSapAtchFileVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, PARAM_TARGET_FILE_ALL_DELETE, commSapAtchFileVO);

        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, commSapAtchFileVO);
        // RFC 호출 애러처리
        if (StringUtils.equals(commSapAtchFileVO.getMsgType(), MapsConstants.MESSAGE_TYPE_ERROR)) {
            throw new MapsBizException(commSapAtchFileVO.getMsg());
        }
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<MapsCommSapAtchFileVO> esFiles = MapsRfcMappperUtil.getExportTableValues(funcRslt,  FIELD_TARGET_IT_ATTACH, MapsCommSapAtchFileVO.class);
        
        if (logger.isDebugEnabled()) {
            logger.debug("→ deleteAllSapAtchFile::end");
        }
        return esFiles;
    }

}
