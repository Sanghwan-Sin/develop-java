package com.mobis.maps.comm.vo;


/**
 * <pre>
 * 메뉴관리 항목
 * </pre>
 *
 * @ClassName   : MapsCommMenuVO.java
 * @Description : 메뉴관리 항목을 정의
 * @author DT048657
 * @since 2020. 01. 07.
 * @version 1.0MapsCommMenuVO
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 01. 07.     DT048657     	최초 생성
 * </pre>
 */
public class MapsCommMenuVO extends PgBascVO {
    /** 부모메뉴ID */
    private String parntsMenuId;    
    /** 메뉴ID */
    private String menuId;
    /** 메뉴명 */
    private String menuNm;
    /** 메뉴순서 */
    private String menuLevel;
    /** 메뉴유형코드(M:메뉴,S:화면,P:팝업화면,U:URL) */
    private String menuTyCd;
    /** 메뉴유형코드(M:메인,P:팝업) */
    private String menuOpenTy;
    /** 메뉴파라메터 */
    private String menuArgs;
    /** 메뉴설명 */
    private String menuDc;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 화면ID */
    private String scrinId;
    /** 화면별칭ID */
    private String scrinAliasId;
    /** 화면명 */
    private String scrinNm;
    /** 화면코드 */
    private String scrinCd;
    /** 화면URL */
    private String scrinUrl;
    /** 화면설명 */
    private String scrinDc;
    /** DRM화면여부 */
    private String drmScrinYn;
    /** DRM파일여부 */
    private String drmFileYn;
    /** 개인정보사용여부 */
    private String indvdlinfoUseYn;
    /** 팝업여부 */
    private String popupYn;
    /** 화면표시여부 */
    private String indictYn;
    /* 인증관리 */
    /** 인증여부 */
    private String authorYn;
    /**
     * @return the parntsMenuId
     */
    public String getParntsMenuId() {
        return parntsMenuId;
    }
    /**
     * @param parntsMenuId the parntsMenuId to set
     */
    public void setParntsMenuId(String parntsMenuId) {
        this.parntsMenuId = parntsMenuId;
    }
    /**
     * @return the menuId
     */
    public String getMenuId() {
        return menuId;
    }
    /**
     * @param menuId the menuId to set
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
    /**
     * @return the menuNm
     */
    public String getMenuNm() {
        return menuNm;
    }
    /**
     * @param menuNm the menuNm to set
     */
    public void setMenuNm(String menuNm) {
        this.menuNm = menuNm;
    }
    /**
     * @return the menuLevel
     */
    public String getMenuLevel() {
        return menuLevel;
    }
    /**
     * @param menuLevel the menuLevel to set
     */
    public void setMenuLevel(String menuLevel) {
        this.menuLevel = menuLevel;
    }
    /**
     * @return the menuTyCd
     */
    public String getMenuTyCd() {
        return menuTyCd;
    }
    /**
     * @param menuTyCd the menuTyCd to set
     */
    public void setMenuTyCd(String menuTyCd) {
        this.menuTyCd = menuTyCd;
    }
    /**
     * @return the menuOpenTy
     */
    public String getMenuOpenTy() {
        return menuOpenTy;
    }
    /**
     * @param menuOpenTy the menuOpenTy to set
     */
    public void setMenuOpenTy(String menuOpenTy) {
        this.menuOpenTy = menuOpenTy;
    }
    /**
     * @return the menuArgs
     */
    public String getMenuArgs() {
        return menuArgs;
    }
    /**
     * @param menuArgs the menuArgs to set
     */
    public void setMenuArgs(String menuArgs) {
        this.menuArgs = menuArgs;
    }
    /**
     * @return the menuDc
     */
    public String getMenuDc() {
        return menuDc;
    }
    /**
     * @param menuDc the menuDc to set
     */
    public void setMenuDc(String menuDc) {
        this.menuDc = menuDc;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the scrinAliasId
     */
    public String getScrinAliasId() {
        return scrinAliasId;
    }
    /**
     * @param scrinAliasId the scrinAliasId to set
     */
    public void setScrinAliasId(String scrinAliasId) {
        this.scrinAliasId = scrinAliasId;
    }
    /**
     * @return the scrinNm
     */
    public String getScrinNm() {
        return scrinNm;
    }
    /**
     * @param scrinNm the scrinNm to set
     */
    public void setScrinNm(String scrinNm) {
        this.scrinNm = scrinNm;
    }
    /**
     * @return the scrinCd
     */
    public String getScrinCd() {
        return scrinCd;
    }
    /**
     * @param scrinCd the scrinCd to set
     */
    public void setScrinCd(String scrinCd) {
        this.scrinCd = scrinCd;
    }
    /**
     * @return the scrinUrl
     */
    public String getScrinUrl() {
        return scrinUrl;
    }
    /**
     * @param scrinUrl the scrinUrl to set
     */
    public void setScrinUrl(String scrinUrl) {
        this.scrinUrl = scrinUrl;
    }
    /**
     * @return the scrinDc
     */
    public String getScrinDc() {
        return scrinDc;
    }
    /**
     * @param scrinDc the scrinDc to set
     */
    public void setScrinDc(String scrinDc) {
        this.scrinDc = scrinDc;
    }
    /**
     * @return the drmScrinYn
     */
    public String getDrmScrinYn() {
        return drmScrinYn;
    }
    /**
     * @param drmScrinYn the drmScrinYn to set
     */
    public void setDrmScrinYn(String drmScrinYn) {
        this.drmScrinYn = drmScrinYn;
    }
    /**
     * @return the drmFileYn
     */
    public String getDrmFileYn() {
        return drmFileYn;
    }
    /**
     * @param drmFileYn the drmFileYn to set
     */
    public void setDrmFileYn(String drmFileYn) {
        this.drmFileYn = drmFileYn;
    }
    /**
     * @return the indvdlinfoUseYn
     */
    public String getIndvdlinfoUseYn() {
        return indvdlinfoUseYn;
    }
    /**
     * @param indvdlinfoUseYn the indvdlinfoUseYn to set
     */
    public void setIndvdlinfoUseYn(String indvdlinfoUseYn) {
        this.indvdlinfoUseYn = indvdlinfoUseYn;
    }
    /**
     * @return the popupYn
     */
    public String getPopupYn() {
        return popupYn;
    }
    /**
     * @param popupYn the popupYn to set
     */
    public void setPopupYn(String popupYn) {
        this.popupYn = popupYn;
    }
    /**
     * @return the indictYn
     */
    public String getIndictYn() {
        return indictYn;
    }
    /**
     * @param indictYn the indictYn to set
     */
    public void setIndictYn(String indictYn) {
        this.indictYn = indictYn;
    }
    /**
     * @return the authorYn
     */
    public String getAuthorYn() {
        return authorYn;
    }
    /**
     * @param authorYn the authorYn to set
     */
    public void setAuthorYn(String authorYn) {
        this.authorYn = authorYn;
    }
}
