package com.mobis.maps.comm.constants;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.mobis.maps.cmmn.exception.MapsBizException;

/**
 * <pre>
 * SAP 데이터 타입
 * </pre>
 *
 * @ClassName   : MapsCommSapDataType.java
 * @Description : SAP 데이터 타입을 정의.
 * @author Sin Sanghwan
 * @since 2019. 10. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 14.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public enum JCoMetaDataType {

      CHAR(String.class, RfcDataTy.String)
    , STRING(String.class, RfcDataTy.String)
    , INT(Integer.class, RfcDataTy.Integer)
    , INT1(Integer.class, RfcDataTy.Integer)
    , INT2(Integer.class, RfcDataTy.Integer)
    , FLOAT(Float.class, RfcDataTy.Float)
    , NUM(BigDecimal.class, RfcDataTy.Number)
    , BCD(BigDecimal.class, RfcDataTy.Number)
    , DATE(Date.class, RfcDataTy.Date)
    , TIME(Date.class, RfcDataTy.Datetime)
    
    , CLNT(String.class, RfcDataTy.String)
    , CUKY(String.class, RfcDataTy.String)
    , LANG(String.class, RfcDataTy.String)
    , NUMC(String.class, RfcDataTy.String)
    , UNIT(String.class, RfcDataTy.String)
    , INT4(Integer.class, RfcDataTy.Integer)
    , INT8(Integer.class, RfcDataTy.Integer)
    , FLTP(Float.class, RfcDataTy.Float)
    , QUAN(BigDecimal.class, RfcDataTy.Number)
    , DEC(BigDecimal.class, RfcDataTy.Number)
    , DF16_DEC(BigDecimal.class, RfcDataTy.Number)
    , DF16_RAW(BigDecimal.class, RfcDataTy.Number)
    , DF16_SCL(BigDecimal.class, RfcDataTy.Number)
    , DF34_DEC(BigDecimal.class, RfcDataTy.Number)
    , DF34_RAW(BigDecimal.class, RfcDataTy.Number)
    , DF34_SCL(BigDecimal.class, RfcDataTy.Number)
    , CURR(BigDecimal.class, RfcDataTy.Currency)
    , XSTRING(byte.class, RfcDataTy.Binary)
    ;
    
    // 멤버 선언
    private Class<?> c;
    private RfcDataTy rfcDataTy;
    
    /**
     * SAP 데이터 타입 생성
     *
     * @param c
     * @param rfcDataTy
     */
    private JCoMetaDataType(Class<?> c, RfcDataTy rfcDataTy) {
        this.c = c;
        this.rfcDataTy = rfcDataTy;
    }
    
    /**
     * SAP 데이터 타입 취득
     *
     * @param type
     * @return
     * @throws MapsBizException 
     */
    public static JCoMetaDataType get(String type, String classNm) throws MapsBizException {
        
        JCoMetaDataType rtnSapDataType = null;
        
        for (JCoMetaDataType sapDataType: values()) {
            if (StringUtils.equals(sapDataType.name(), type)) {
                rtnSapDataType =  sapDataType;
                break;
            }
        }
        if (rtnSapDataType == null) {
            throw new MapsBizException("데이터 타입(=" + type + ")은 채널시스템에 미정의된 데이터 타입입니다.");
        }
        
        if (StringUtils.equals(rtnSapDataType.getClass().getName(), classNm)) {
            return rtnSapDataType;
        }

        if (StringUtils.equals(String.class.getName(), classNm)) {
            rtnSapDataType = JCoMetaDataType.STRING;
        } else if (StringUtils.equals(BigDecimal.class.getName(), classNm)) {
            rtnSapDataType = JCoMetaDataType.BCD;
        } else if (StringUtils.equals(Float.class.getName(), classNm)) {
            rtnSapDataType = JCoMetaDataType.FLOAT;
        } else if (StringUtils.equals(Date.class.getName(), classNm)) {
            rtnSapDataType = JCoMetaDataType.DATE;
        }
        
        return rtnSapDataType;
    }

    /**
     * @return the c
     */
    public Class<?> getC() {
        return c;
    }

    /**
     * @return the rfcDataTy
     */
    public RfcDataTy getRfcDataTy() {
        return rfcDataTy;
    }
    
}