package com.mobis.maps.iam.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.iam.vo.MapsIamUserScrinStatsVO;

/**
 * <pre>
 * 사용자 화면 통계 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinStatsMDAO.java
 * @Description : 사용자 화면 통계에 대한 데이터 처리를 정의.
 * @author DT048058
 * @since 2020. 5. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 7.     DT048058     	최초 생성
 * </pre>
 */
@Mapper("mapsIamUserScrinStatsMDAO")
public interface MapsIamUserScrinStatsMDAO {

    /**
     * 사용자 화면 접속 통계 메인 리스트 조회
     *
     * @param iamUserScrinStatsVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinStatsVO> selectUserScrinStatsMainList(MapsIamUserScrinStatsVO iamUserScrinStatsVO) throws Exception;

    /**
     * 사용자 화면 접속 통계 상세 리스트 조회
     *
     * @param iamUserScrinStatsVO
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinStatsVO> selectUserScrinStatsDetailList(MapsIamUserScrinStatsVO iamUserScrinStatsVO) throws Exception;
    
}
