package com.mobis.maps.logback.db.names;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSapRfcTableName.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 7.     DT048058     	최초 생성
 * </pre>
 */

public enum MapsSapRfcTableName {
    T_RFC_EXECUT_LOG, T_RFC_EXECUT_LOG_DATA, T_RFC_EXECUT_LOG_EXCP;
}
