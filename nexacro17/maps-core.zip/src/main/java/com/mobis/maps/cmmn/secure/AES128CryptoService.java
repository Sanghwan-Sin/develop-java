package com.mobis.maps.cmmn.secure;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

/**
 * <pre>
 * AES-128 암호화 제공 서비스
 *
 * 키 : 128bits (16bytes)
 * IV (initialization vector) : 128bits (16bytes)
 * 블록 : 128bits (16bytes)
 * 알고리즘 : AES
 * 블록 운영모드 : CBC
 * 패딩 : PKCS5Padding
 *
 * 1. JCE SUNProvider를 사용한다.
 * 2. 사용전 반드시 JCE Unlimited Strength Jurisdiction Policy Files 가 설치되어야한다.
 *  - 미설치시 java.security.InvalidKeyException: Illegal key size 발생
 *  ex) JRE7 - Java/jre7/lib/security 폴더 local_policy.jar, US_export_policy.jar 파일(덮어쓰기)
 * 3. byte[], String(base64), String(Hex) 3가지 타입을 지원한다.
 * </pre>
 *
 * @ClassName   : AES128CryptoService.java
 * @Description : AES-128 암호화 제공 서비스
 * @author ADM기술팀
 * @since 2016. 6. 29.
 * @version 1.0
* @see <a href="http://docs.oracle.com/javase/7/docs/technotes/guides/security/SunProviders.html">http://docs.oracle.com/javase/7/docs/technotes/guides/security/SunProviders.html</a>
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2016. 6. 29.     JUNG YEON HO     	최초 생성
 * </pre>
 */
public class AES128CryptoService {
    // private String cipherTransformation = "AES/CBC/PKCS5Padding"; // default
    private String cipherTransformation = "AES/CBC/PKCS5Padding"; // default
    // private String cipherTransformation = "AES/CBC/NoPadding"; // No padding
    // options

    private final static String ALGORITHM = "AES";

    private final static int BUFFER_SIZE = 1024;

    // 키 사이즈 검사용
    private final static int KEY_SIZE = 16; // 16bytes = 128bits
    private final static int IV_SIZE = 8; // 8bytes = 64bits

    /**
     * byte[] 메시지 암호화 후 byte[] 출력
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param msg
     *            : byte[]
     * @return 암호화된 byte[]
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public byte[] encrypt(byte[] key, byte[] iv, byte[] msg) throws NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        if (key.length != KEY_SIZE) {
            throw new InvalidKeyException("Illegal key size : The size of key must be 16bytes(128bits)");
        }

        Cipher cipher = Cipher.getInstance(cipherTransformation);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        SecretKeySpec keySpec = new SecretKeySpec(key, ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

        byte[] encrypted = cipher.doFinal(msg);

        return encrypted;
    }

    /**
     * String 메시지 암호화 후 Base64 인코딩 출력
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param msg
     *            : String
     * @return 암호화 후 Base64 인코딩 String
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public String encrypt(byte[] key, byte[] iv, String msg) throws NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        byte[] encrypted = this.encrypt(key, iv, msg.getBytes());
        return Base64.encodeBase64String(encrypted).trim();
    }

    /**
     * File 암호화 - srcFile을 읽어 destFile 로 암호화
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param srcFile
     *            : 원본파일
     * @param destFile
     *            : 암호화된 파일
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IOException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public void encrypt(byte[] key, byte[] iv, File srcFile, File destFile)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
            InvalidAlgorithmParameterException, IOException, IllegalBlockSizeException, BadPaddingException {
        if (key.length != KEY_SIZE) {
            throw new InvalidKeyException("Illegal key size : The size of key must be 16bytes(128bits)");
        }

        Cipher cipher = Cipher.getInstance(cipherTransformation);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        SecretKeySpec keySpec = new SecretKeySpec(key, ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

        FileInputStream fis = new FileInputStream(srcFile);
        FileOutputStream fos = new FileOutputStream(destFile);

        byte[] in = new byte[BUFFER_SIZE];
        int read;
        while ((read = fis.read(in)) != -1) {
            byte[] output = cipher.update(in, 0, read);
            if (output != null) {
                fos.write(output);
            }
        }

        byte[] output = cipher.doFinal();
        if (output != null) {
            fos.write(output);
        }
        fis.close();
        fos.flush();
        fos.close();
    }

    /**
     * File 암호화 - srcPath 경로의 파일을 읽어 destPath 경로의 파일로 암호화
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param srcPath
     *            : 원본 파일 경로
     * @param destPath
     *            : 암호화된 파일 경로
     * @throws InvalidKeyException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     * @throws IOException
     */
    public void encrypt(byte[] key, byte[] iv, String srcPath, String destPath)
            throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {
        encrypt(key, iv, new File(srcPath), new File(destPath));
    }

    /**
     * Hex String 메시지 암호화 후 Hex 인코딩 출력
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param msg
     *            : String
     * @return 암호화 후 Hex 인코딩 String
     * @throws InvalidKeyException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public String encryptToHexString(byte[] key, byte[] iv, String msg)
            throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        byte[] encrypted = this.encrypt(key, iv, msg.getBytes());
        return Hex.encodeHexString(encrypted);
    }

    /**
     * byte[] 메시지 복호화
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param msg
     *            : byte[]
     * @return 복호화된 byte[]
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public byte[] decrypt(byte[] key, byte[] iv, byte[] msg) throws NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        if (key.length != KEY_SIZE) {
            throw new InvalidKeyException("Illegal key size : The size of key must be 16bytes(128bits)");
        }

        Cipher cipher = Cipher.getInstance(cipherTransformation);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        SecretKeySpec keySpec = new SecretKeySpec(key, ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);

        byte[] encrypted = cipher.doFinal(msg);

        return encrypted;
    }

    /**
     * Base64 인코딩 String 메시지 복호화
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param msg
     *            : String(base64)
     * @return 복호화된 String
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public String decrypt(byte[] key, byte[] iv, String msg) throws NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        byte[] decodeMsg = Base64.decodeBase64(msg);
        String decrypted = new String(this.decrypt(key, iv, decodeMsg));
        return decrypted;
    }

    /**
     * File 복호화 - srcFile을 읽어 destFile 로 복호화
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param srcFile
     *            : 암호화된 파일
     * @param destFile
     *            : 복호화된 파일
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IOException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public void decrypt(byte[] key, byte[] iv, File srcFile, File destFile)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
            InvalidAlgorithmParameterException, IOException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(cipherTransformation);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        SecretKeySpec keySpec = new SecretKeySpec(key, ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);

        FileInputStream fis = new FileInputStream(srcFile);
        FileOutputStream fos = new FileOutputStream(destFile);

        byte[] in = new byte[BUFFER_SIZE];
        int read;
        while ((read = fis.read(in)) != -1) {
            byte[] output = cipher.update(in, 0, read);
            if (output != null) {
                fos.write(output);
            }
        }

        byte[] output = cipher.doFinal();
        if (output != null) {
            fos.write(output);
        }
        fis.close();
        fos.flush();
        fos.close();
    }

    /**
     * File 복호화 - srcPath 경로의 파일을 읽어 destPath 경로의 파일로 복호화
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param srcPath
     *            : 암호화된 파일 경로
     * @param destPath
     *            : 복호화된 파일 경로
     * @throws InvalidKeyException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     * @throws IOException
     */
    public void decrypt(byte[] key, byte[] iv, String srcPath, String destPath)
            throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {
        decrypt(key, iv, new File(srcPath), new File(destPath));
    }

    /**
     * Hex 인코딩 String 메시지 복호화
     *
     * @param key
     *            : 128bits (16bytes)
     * @param iv
     *            : 64bits (8bytes)
     * @param msg
     *            : String(hex)
     * @return 복호화된 String
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     * @throws DecoderException
     */
    public String decryptHexString(byte[] key, byte[] iv, String msg)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, DecoderException {
        byte[] decodeMsg = Hex.decodeHex(msg.toCharArray());
        String decrypted = new String(this.decrypt(key, iv, decodeMsg));
        return decrypted;
    }

    /**
     * AES128 랜덤 키 생성
     *
     * @return byte[] - 16bytes
     * @throws NoSuchAlgorithmException
     */
    public byte[] generateRandomKey() throws NoSuchAlgorithmException {
        KeyGenerator keygen = KeyGenerator.getInstance(ALGORITHM);
        keygen.init(new SecureRandom());
        keygen.init(KEY_SIZE * 4); // 128bits
        SecretKey secKey = keygen.generateKey();
        return secKey.getEncoded();
    }

    /**
     * IV 생성
     * 
     * @return byte[] - 16bytes
     */
    public byte[] generateRandomIV() {
        SecureRandom secRand = new SecureRandom();
        byte[] iv = new byte[IV_SIZE];
        secRand.nextBytes(iv);
        return iv;
    }

    /**
     * 암호화 설정 변경
     * algorithm/mode/padding
     * default - AES/CBC/PKCS5Padding
     * 
     * @param cipherTrnasformation
     */
    public void setCipherTransformation(String cipherTrnasformation) {
        this.cipherTransformation = cipherTrnasformation;
    }

}
