package com.mobis.maps.cmmn.interceptor;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.ui.adaptor.nexacro.servlet.NexacroContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsMultiScrinLoginException;
import com.mobis.maps.cmmn.exception.MapsSessionException;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.util.WebUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommLoginService;
import com.mobis.maps.iam.vo.MapsIamLoginHistVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * Maps세션 Interceptor
 * </pre>
 *
 * @ClassName   : MapsSessionInterceptor.java
 * @Description : Maps 세션 관련 Interceptor를 정의.
 * @author DT048058
 * @since 2020. 7. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 20.     DT048058     	최초 생성
 * </pre>
 */
public class MapsSessionInterceptor extends HandlerInterceptorAdapter {
    
    protected Logger logger = LoggerFactory.getLogger(MapsSessionInterceptor.class);

    /** message source */
    @Resource(name = "messageSource")
    private MessageSource messageSource;
    
    
    @Resource(name = "mapsCommLoginService")
    private MapsCommLoginService mapsCommLoginService;
    
    /*
     * @로그인 체크 후 로그인 정보가 없으면 오류
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 로그인 정보 획득
        LoginInfoVO loginInfo = (LoginInfoVO) request.getSession().getAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (logger.isDebugEnabled()) {
            logger.debug("preHandle::url["+request.getRequestURI()+"],url["+request.getRequestURL().toString()+"]");
        }
        // 세션에 로그인 정보가 존재 하지 않으면 예외처리한다.
        if (loginInfo == null) {
            throw new MapsSessionException(messageSource, "EC00000043");
        }
        
        // 중복 로그인 처리 START
        // 프로퍼티에서 읽어옴(==> 공통에 넣지 말고 각시스템에 넣을것 ==> 시스템 마다 틀림 PDA는 하면 안됨)
        String dubLoginYn = PropertiesUtil.getDbValue("DUP_LOGIN_CHECK_YN");
        
        String userId = loginInfo.getUserId();
        String duploginIds = PropertiesUtil.getDbValue("DUP_LOGIN_IDS");
        // 중복로그인 허용 리스트에 존재하면 중복로그인 체크 안함.
        
        boolean iaMatchDupLoginList = WebUtil.isMatchArryString(userId, duploginIds);
        if (logger.isDebugEnabled()) {
            logger.debug("******************************::userId["+userId+"]");
            logger.debug("******************************::duploginIds["+duploginIds+"]");
            logger.debug("******************************::iaMatchDupLoginList["+iaMatchDupLoginList+"]");
        }
        
        if( StringUtils.equals(dubLoginYn, "Y")  &&  iaMatchDupLoginList ){
            dubLoginYn = "N";
        }
        
        if(StringUtils.equals(dubLoginYn , "Y")){
            String userSedId = loginInfo.getUserSeqId();
            Date loginDt = loginInfo.getLoginDt();
            MapsIamLoginHistVO iamLoginHistVO = new MapsIamLoginHistVO();
            iamLoginHistVO.setLoginSeqId(userSedId);
            iamLoginHistVO.setLoginDt(loginDt);
            // 현 logindt보다 이후에 로그인한 사람아 있으면 로그 아웃 처리
            MapsIamLoginHistVO iamLoginHistVORtn = mapsCommLoginService.selectLoginExpired(iamLoginHistVO);
            String maxLoginDt = iamLoginHistVORtn.getMaxLoginDt();
            // 나보다 후에 로그인한놈이 있을경우
            if( StringUtils.isNotBlank(maxLoginDt)){
                java.text.SimpleDateFormat formatter=new java.text.SimpleDateFormat("yyyyMMddHHmmss"); 
                String curLoginDt =  formatter.format(loginDt) ;
                if (Long.valueOf(maxLoginDt) > Long.valueOf(curLoginDt)) {
                    logger.info("***************************************************************************************************************************");
                    logger.info("***************************************************************************************************************************");
                    logger.info("강제로 접속 끊기 Exception ..............로그인DTM : " + curLoginDt + ", 가장최근 로그인DTM : " + maxLoginDt);
                    logger.info("강제로 접속 끊기 Exception ..............로그아웃처리!!!!");
                    logger.info("***************************************************************************************************************************");
                    // You are logged in again with your current account. You are logged out.
                    throw new MapsSessionException(messageSource, "ECM0000008", loginInfo.getUserLcale(), null);
                }
            }
        }
        // 중복 로그인 END
        
        /* 멀티화면사용 확인 */
        NexacroContext nexacontext = null;
        Object context = RequestContextHolder.getRequestAttributes().getAttribute("NexacroCachedData", 0);
        if (context instanceof NexacroContext) {
            nexacontext = (NexacroContext)context;
        }
        if (nexacontext != null){
            DataSet data = nexacontext.getPlatformData().getDataSet("gdsTranParam");
            if (data != null) {
                String userSeqId = data.getString(0, "tokenNo");
                //logger.info("→ preHandle::gdsTranParam[userSeqId=" + userSeqId + ",loginInfo[userSeqId=" + loginInfo.getUserSeqId() + "]");
                if (StringUtils.isNotBlank(userSeqId) && !StringUtils.equals(loginInfo.getUserSeqId(), userSeqId)) {
                    //동일 웹브라우저에 다른 사용자로 로그인 되었습니다. 로그 아웃 처리합니다.
                    throw new MapsMultiScrinLoginException(messageSource, "EC00000066", loginInfo.getUserLcale(), null);
                }
            }
        }
        return true;
    }
}
