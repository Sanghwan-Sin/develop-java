package com.mobis.maps.cmmn.exception;

import java.util.Locale;

import able.com.exception.BizException;

import org.springframework.context.MessageSource;

/**
 * <pre>
 * 템플릿 다운로드 중 발생하는 예외
 * </pre>
 *
 * @ClassName   : MapsTmplatDwnlException.java
 * @Description : 템플릿 다운로드 중 발생하는 예외
 * @author Sin Sanghwan
 * @since 2019. 9. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 10.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class MapsTmplatDwnlException extends BizException {

    private static final long serialVersionUID = -712482115806425826L;

    public MapsTmplatDwnlException() {
        super();
    }

    public MapsTmplatDwnlException(MessageSource messageSource, String messageKey, Exception wrappedException) {
        super(messageSource, messageKey, wrappedException);
    }

    public MapsTmplatDwnlException(MessageSource messageSource, String messageKey, Locale locale,
            Exception wrappedException) {
        super(messageSource, messageKey, locale, wrappedException);
    }

    public MapsTmplatDwnlException(MessageSource messageSource, String messageKey, Object[] messageParameters,
            Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, wrappedException);
    }

    public MapsTmplatDwnlException(MessageSource messageSource, String messageKey, Object[] messageParameters,
            Locale locale, Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, locale, wrappedException);
    }

    public MapsTmplatDwnlException(MessageSource messageSource, String messageKey, Object[] messageParameters,
            String defaultMessage, Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, wrappedException);
    }

    public MapsTmplatDwnlException(MessageSource messageSource, String messageKey, Object[] messageParameters,
            String defaultMessage, Locale locale, Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, locale, wrappedException);
    }

    public MapsTmplatDwnlException(MessageSource messageSource, String messageKey) {
        super(messageSource, messageKey);
    }

    public MapsTmplatDwnlException(String defaultMessage, Exception wrappedException) {
        super(defaultMessage, wrappedException);
    }

    public MapsTmplatDwnlException(String defaultMessage, Object[] messageParameters, Exception wrappedException) {
        super(defaultMessage, messageParameters, wrappedException);
    }

    public MapsTmplatDwnlException(String defaultMessage) {
        super(defaultMessage);
    }

}