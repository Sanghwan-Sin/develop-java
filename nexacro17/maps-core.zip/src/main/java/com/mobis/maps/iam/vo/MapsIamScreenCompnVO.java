package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 화면 콤포넌트 항목
 * </pre>
 *
 * @ClassName   : MapsCommScreenCompnVO.java
 * @Description : 화면 콤포넌트 항목 정의
 * @author DT048657
 * @since 2019. 9. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 6.     DT048657     	최초 생성
 * </pre>
 */
public class MapsIamScreenCompnVO extends MapsIamCommVO {
    /** 화면콤포넌트ID */
    private String scrinCompnId;
    /** 화면ID */
    private String scrinId;
    /** 콤포넌트ID */
    private String compnId;
    /** 용어ID */
    private String wordId;
    /** 단축용어사용코드 */
    private String abbrevWordUseCd;
    /** 원본용어 */
    private String orginlWord;
    /** 약어1 */
    private String abbrevWord1;
    /** 약어2 */
    private String abbrevWord2;
    /** 약어3 */
    private String abbrevWord3;
    /** 약어4 */
    private String abbrevWord4;
    /** 약어5 */
    private String abbrevWord5;
    /** 사용여부 */
    private String useYn;
    /**
     * @return the scrinCompnId
     */
    public String getScrinCompnId() {
        return scrinCompnId;
    }
    /**
     * @param scrinCompnId the scrinCompnId to set
     */
    public void setScrinCompnId(String scrinCompnId) {
        this.scrinCompnId = scrinCompnId;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the compnId
     */
    public String getCompnId() {
        return compnId;
    }
    /**
     * @param compnId the compnId to set
     */
    public void setCompnId(String compnId) {
        this.compnId = compnId;
    }
    /**
     * @return the wordId
     */
    public String getWordId() {
        return wordId;
    }
    /**
     * @param wordId the wordId to set
     */
    public void setWordId(String wordId) {
        this.wordId = wordId;
    }
    /**
     * @return the abbrevWordUseCd
     */
    public String getAbbrevWordUseCd() {
        return abbrevWordUseCd;
    }
    /**
     * @param abbrevWordUseCd the abbrevWordUseCd to set
     */
    public void setAbbrevWordUseCd(String abbrevWordUseCd) {
        this.abbrevWordUseCd = abbrevWordUseCd;
    }
    /**
     * @return the orginlWord
     */
    public String getOrginlWord() {
        return orginlWord;
    }
    /**
     * @param orginlWord the orginlWord to set
     */
    public void setOrginlWord(String orginlWord) {
        this.orginlWord = orginlWord;
    }
    /**
     * @return the abbrevWord1
     */
    public String getAbbrevWord1() {
        return abbrevWord1;
    }
    /**
     * @param abbrevWord1 the abbrevWord1 to set
     */
    public void setAbbrevWord1(String abbrevWord1) {
        this.abbrevWord1 = abbrevWord1;
    }
    /**
     * @return the abbrevWord2
     */
    public String getAbbrevWord2() {
        return abbrevWord2;
    }
    /**
     * @param abbrevWord2 the abbrevWord2 to set
     */
    public void setAbbrevWord2(String abbrevWord2) {
        this.abbrevWord2 = abbrevWord2;
    }
    /**
     * @return the abbrevWord3
     */
    public String getAbbrevWord3() {
        return abbrevWord3;
    }
    /**
     * @param abbrevWord3 the abbrevWord3 to set
     */
    public void setAbbrevWord3(String abbrevWord3) {
        this.abbrevWord3 = abbrevWord3;
    }
    /**
     * @return the abbrevWord4
     */
    public String getAbbrevWord4() {
        return abbrevWord4;
    }
    /**
     * @param abbrevWord4 the abbrevWord4 to set
     */
    public void setAbbrevWord4(String abbrevWord4) {
        this.abbrevWord4 = abbrevWord4;
    }
    /**
     * @return the abbrevWord5
     */
    public String getAbbrevWord5() {
        return abbrevWord5;
    }
    /**
     * @param abbrevWord5 the abbrevWord5 to set
     */
    public void setAbbrevWord5(String abbrevWord5) {
        this.abbrevWord5 = abbrevWord5;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

}
