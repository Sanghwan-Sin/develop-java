package com.mobis.maps.comm.service;

import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.vo.MapsCommFileExtVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileCntVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;

/**
 * <pre>
 * 공통 파일 관리 인터페이스
 * </pre>
 *
 * @ClassName   : MapsCommFileService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 8.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsCommFileService {

    public static final String PARAM_TARGET_FILE_INFO = "INFO";
    public static final String PARAM_TARGET_FILE_COUNT = "COUNT";
    public static final String PARAM_TARGET_FILE_SUM = "SUM";
    public static final String PARAM_TARGET_FILE_LIST = "LIST";
    public static final String PARAM_TARGET_FILE_CONTENT = "CONTENT";
    public static final String PARAM_TARGET_FILE_CREATE = "CREATE";
    public static final String PARAM_TARGET_FILE_UPDATE = "UPDATE";
    public static final String PARAM_TARGET_FILE_DELETE = "DELETE";
    public static final String PARAM_TARGET_FILE_ALL_DELETE = "ALL_DELETE";
    
    public static final String FIELD_TARGET_I_REF_NO_T = "I_REF_NO_T";
    public static final String FIELD_TARGET_ES_CREATE = "ES_CREATE";
    public static final String FIELD_TARGET_ES_CONFIG = "ES_CONFIG";
    public static final String FIELD_TARGET_ES_MASTER = "ES_MASTER";
    public static final String FIELD_TARGET_ES_ATTACH_COUNT = "ES_ATTACH_COUNT";
    public static final String FIELD_TARGET_ES_ATTACH = "ES_ATTACH";
    public static final String FIELD_TARGET_IT_ATTACH_SUM = "IT_ATTACH_SUM";
    public static final String FIELD_TARGET_IT_ATTACH = "IT_ATTACH";
    
    
    public static final String MAP_KEY_ES_CONFIG = "esConfig";
    public static final String MAP_KEY_ES_MASTER = "esMaster";
    public static final String MAP_KEY_ES_CREATE = "esCreate";
    
    
    /**
     * 업로드 허용 파일 확장자 리스트 조회
     *
     * @param atchFileVO
     * @return
     * @throws Exception
     */
    public List<MapsCommFileExtVO> selectAtchFileExtInfo(MapsCommFileExtVO atchFile) throws Exception;
    
    /**
     * 첨부파일리스트 조회
     *
     * @param atchFileVO
     * @return
     * @throws Exception
     */
    public List<MapsAtchFileVO> selectAtchFileList(MapsAtchFileVO atchFileVO) throws Exception;
    
    /**
     * 첨부파일 등록
     *
     * @param atchSe
     * @param atchId
     * @param atchFiles
     * @return
     * @throws Exception
     */
    public int multiAtchFile(String atchSe, String atchId, List<MapsAtchFileVO> atchFiles) throws Exception;

    /**
     * 첨부파일 등록
     *
     * @param atchFileSe
     * @param atchFileBaseInfo
     * @param atchFiles
     * @return
     * @throws Exception
     */
    public int multiAtchFile(AtchFileSe atchFileSe, Object atchFileBaseInfo, List<MapsAtchFileVO> atchFiles) throws Exception;


    /**
     * 첨부파일 삭제
     *
     * @param atchFileVO
     * @return
     * @throws Exception
     */
    public int deleteAtchFile(MapsAtchFileVO atchFileVO) throws Exception;

    /**
     * 첨부파일 삭제(전체)
     *
     * @param atchFileVO
     * @return
     * @throws Exception
     */
    public int deleteAtchFileAll(MapsAtchFileVO atchFileVO) throws Exception;
    
    /**
     * 첨부파일 Upload
     * request로부터 파일객체를 추출하여 저장하고 저장정보를 FileVO 객체로 반환한다.
     *
     * @param request
     * @param atchSe
     * @return
     * @throws Exception
     */
    public List<MapsAtchFileVO> selectAtchFileUpload(HttpServletRequest request, String atchSe) throws Exception;

    /**
     * 첨부파일 Download
     *
     * @param atchFileVO
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    public void selectAtchFileDownload(MapsAtchFileVO atchFileVO, HttpServletRequest request, HttpServletResponse response) throws Exception;

    /**
     * 첨부파일 Image Viewer
     *
     * @param atchFileVO
     * @param request
     * @param response
     * @throws Exception
     */
    public void selectAtchFileImageViewer(MapsAtchFileVO atchFileVO, HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    /**
     * 파일 업로드
     *
     * @param request
     * @return
     * @throws Exception
     */
    public File selectFileUpload(HttpServletRequest request) throws Exception;

    /**
     * Template 파일 Download
     *
     * @param tmplatId
     * @param request
     * @param response
     * @throws Exception
     */
    public void selectTmplatFileDownload(String tmplatId, HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    /**
     * Classpatch내 Template 액셀파일 Download
     *
     * @param tmplatId
     * @param request
     * @param response
     * @throws Exception
     */
    public void selectExcelTmplatFileDownload(String tmplatId, HttpServletRequest request, HttpServletResponse response) throws Exception;
    

    /**
     * 화면명 조회
     *
     * @param scrinId
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsIamScreenVO selectScrinNm(String scrinId, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 메뉴얼 파일 다운로드
     *
     * @param scrinId
     * @param dwnlMode
     * @param loginInfo
     * @param request
     * @param response
     * @throws Exception
     */
    public void selectMnlFileDownload(String scrinId, String dwnlMode, LoginInfoVO loginInfo, HttpServletRequest request, HttpServletResponse response) throws Exception; 

    /**
     * SAP 첨부파일 리스트 조회
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileVO> selectSapAtchFileList(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 상세 조회
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileVO selectSapAtchFileDetail(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 건수 조회
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileInfoVO selectSapAtchFileCnt(MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 건수 리스트 조회
     *
     * @param commSapAtchFileCntVO
     * @param refNos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileCntVO> selectSapAtchFileCntList(MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , List<MapsCommSapAtchFileCntVO> refNos
            , LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 Summary건수 조회
     *
     * @param commSapAtchFileCntVO
     * @param refNos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileCntVO> selectSapAtchFileSumryCnt(MapsCommSapAtchFileCntVO commSapAtchFileCntVO
            , List<MapsCommSapAtchFileCntVO> refNos
            , LoginInfoVO loginInfo) throws Exception;

    /**
     * SAP 첨부파일 등록정보 조회
     *
     * @param commSapAtchFileInfoVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public Map<String, MapsCommSapAtchFileInfoVO> selectSapAtchFileRegistInfo(MapsCommSapAtchFileInfoVO commSapAtchFileInfoVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 복수 등록
     *
     * @param commSapAtchFileVO
     * @param sapAtchFiles
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileVO> multiSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO
            , List<MapsCommSapAtchFileVO> sapAtchFiles
            , LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 등록
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileVO insertSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 수정
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileVO updateSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 삭제
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsCommSapAtchFileVO deleteSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * SAP 첨부파일 삭제(전체)
     *
     * @param atchFileVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileVO> deleteAllSapAtchFile(MapsCommSapAtchFileVO commSapAtchFileVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 삭제(RowSe="D" 선택)
     *
     * @param sapAtchFiles
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileVO> deleteSelectdSapAtchFile(List<MapsCommSapAtchFileVO> sapAtchFiles, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부파일 Upload
     * request로부터 파일객체를 추출하여 저장하고 저장정보를 FileVO 객체로 반환한다.
     *
     * @param request
     * @param sysSeCd
     * @param sysId
     * @param fscode
     * @param refNo
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileVO> selectSapAtchFileUpload(HttpServletRequest request
            , String sysSeCd
            , String sysId
            , String fscode
            , String refNo
            , String sameFileNmWithRefNo
            , LoginInfoVO loginInfo) throws Exception;
    
    /**
     * SAP 첨부화일다운로드
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @param request
     * @param response
     * @throws Exception
     */
    public void selectSapAtchFileDownload(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception;
    
    /**
     * SAP 이미지화일뷰어
     *
     * @param commSapAtchFileVO
     * @param loginInfo
     * @param request
     * @param response
     * @throws Exception
     */
    public void selectSapImageFileViewer(MapsCommSapAtchFileVO commSapAtchFileVO
            , LoginInfoVO loginInfo
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception;
    
    /**
     * selectFileDownload
     *
     * @param file
     * @param fileNm
     * @param request
     * @param response
     * @param isViewer
     * @throws Exception
     */
    public void selectFileDownload(File file
                                  , String fileNm
                                  , HttpServletRequest request
                                  , HttpServletResponse response
                                  , boolean isViewer) throws Exception;
    
    /**
     * selectFileDownload
     *
     * @param is
     * @param fileNm
     * @param fileSize
     * @param request
     * @param response
     * @param isViewer
     * @throws Exception
     */
    public void selectFileDownload(InputStream is
                                 , String fileNm
                                 , int fileSize
                                 , HttpServletRequest request
                                 , HttpServletResponse response
                                 , boolean isViewer) throws Exception;
    
    


    /**
     * SAP 첨부파일 Upload - 복수 refNo : POST시 'name' 의 값으로 refNo를 보내야 함
     * request로부터 파일객체를 추출하여 저장하고 저장정보를 FileVO 객체로 반환한다.
     *
     * @param request
     * @param sysSeCd
     * @param sysId
     * @param fscode
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommSapAtchFileVO> selectSapAtchFileUploadMulti(HttpServletRequest request
            , String sysSeCd
            , String sysId
            , String fscode
            , String sameFileNmWithRefNo
            , LoginInfoVO loginInfo) throws Exception;

}
