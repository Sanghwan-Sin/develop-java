package com.mobis.maps.cmmn.vo;

import java.util.Date;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SapCodeVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 9.     DT048058        최초 생성
 * </pre>
 */

public class SapCodeVO extends CodeVO {
    /** 문자필드, 길이 70 */
    private String usr01;
    /** 문자필드, 길이 70 */
    private String usr02;
    /** 문자필드, 길이 70 */
    private String usr03;
    /** 문자필드, 길이 70 */
    private String usr04;
    /** 문자필드, 길이 70 */
    private String usr05;
    /** 문자필드, 길이 70 */
    private String usr06;
    /** 문자필드, 길이 70 */
    private String usr07;
    /** 문자필드, 길이 70 */
    private String usr08;
    /** 문자필드, 길이 70 */
    private String usr09;
    /** 문자필드, 길이 70 */
    private String usr10;
    /** 숫자문자필드, 길이 10 */
    private String usr11;
    /** 숫자문자필드, 길이 10 */
    private String usr12;
    /** 사용자 필드(20자) */
    private String usr13;
    /** 사용자 필드(20자) */
    private String usr14;
    /** 텍스트 (40 문자) */
    private String usr15;
    /** 텍스트 (40 문자) */
    private String usr16;
    /** 작업 영역 길이 128 */
    private String usr17;
    /** 작업 영역 길이 128 */
    private String usr18;
    /** 사용자 정의 필드: 리포트 지시자 */
    private String usr19;
    /** 사용자 정의 필드: 리포트 지시자 */
    private String usr20;
    /** 사용자 정의 필드: 리포트 지시자 */
    private String usr21;
    /** 사용자 정의 필드: 리포트 지시자 */
    private String usr22;
    /** 일자에 대한 사용자 필드 */
    private Date usr23;
    /** 일자에 대한 사용자 필드 */
    private Date usr24;
    /** 일자에 대한 사용자 필드 */
    private Date usr25;
    /** 일자에 대한 사용자 필드 */
    private Date usr26;
    /** Time User Field */
    private String usr27;
    /** Time User Field */
    private String usr28;
    /** Time User Field */
    private String usr29;
    /** Time User Field */
    private String usr30;
    /** 사용자 필드(1자) */
    private String usr31;
    /** 사용자 필드(1자) */
    private String usr32;
    /** 사용자 필드(1자) */
    private String usr33;
    /** 사용자 필드(1자) */
    private String usr34;
    /** 사용자 필드(1자) */
    private String usr35;
    /** 사용자필드(4자리) */
    private String usr36;
    /** 사용자필드(4자리) */
    private String usr37;
    /** 사용자필드(4자리) */
    private String usr38;
    /** 사용자필드(4자리) */
    private String usr39;
    /**
     * @return the usr01
     */
    public String getUsr01() {
        return usr01;
    }
    /**
     * @param usr01 the usr01 to set
     */
    public void setUsr01(String usr01) {
        this.usr01 = usr01;
    }
    /**
     * @return the usr02
     */
    public String getUsr02() {
        return usr02;
    }
    /**
     * @param usr02 the usr02 to set
     */
    public void setUsr02(String usr02) {
        this.usr02 = usr02;
    }
    /**
     * @return the usr03
     */
    public String getUsr03() {
        return usr03;
    }
    /**
     * @param usr03 the usr03 to set
     */
    public void setUsr03(String usr03) {
        this.usr03 = usr03;
    }
    /**
     * @return the usr04
     */
    public String getUsr04() {
        return usr04;
    }
    /**
     * @param usr04 the usr04 to set
     */
    public void setUsr04(String usr04) {
        this.usr04 = usr04;
    }
    /**
     * @return the usr05
     */
    public String getUsr05() {
        return usr05;
    }
    /**
     * @param usr05 the usr05 to set
     */
    public void setUsr05(String usr05) {
        this.usr05 = usr05;
    }
    /**
     * @return the usr06
     */
    public String getUsr06() {
        return usr06;
    }
    /**
     * @param usr06 the usr06 to set
     */
    public void setUsr06(String usr06) {
        this.usr06 = usr06;
    }
    /**
     * @return the usr07
     */
    public String getUsr07() {
        return usr07;
    }
    /**
     * @param usr07 the usr07 to set
     */
    public void setUsr07(String usr07) {
        this.usr07 = usr07;
    }
    /**
     * @return the usr08
     */
    public String getUsr08() {
        return usr08;
    }
    /**
     * @param usr08 the usr08 to set
     */
    public void setUsr08(String usr08) {
        this.usr08 = usr08;
    }
    /**
     * @return the usr09
     */
    public String getUsr09() {
        return usr09;
    }
    /**
     * @param usr09 the usr09 to set
     */
    public void setUsr09(String usr09) {
        this.usr09 = usr09;
    }
    /**
     * @return the usr10
     */
    public String getUsr10() {
        return usr10;
    }
    /**
     * @param usr10 the usr10 to set
     */
    public void setUsr10(String usr10) {
        this.usr10 = usr10;
    }
    /**
     * @return the usr11
     */
    public String getUsr11() {
        return usr11;
    }
    /**
     * @param usr11 the usr11 to set
     */
    public void setUsr11(String usr11) {
        this.usr11 = usr11;
    }
    /**
     * @return the usr12
     */
    public String getUsr12() {
        return usr12;
    }
    /**
     * @param usr12 the usr12 to set
     */
    public void setUsr12(String usr12) {
        this.usr12 = usr12;
    }
    /**
     * @return the usr13
     */
    public String getUsr13() {
        return usr13;
    }
    /**
     * @param usr13 the usr13 to set
     */
    public void setUsr13(String usr13) {
        this.usr13 = usr13;
    }
    /**
     * @return the usr14
     */
    public String getUsr14() {
        return usr14;
    }
    /**
     * @param usr14 the usr14 to set
     */
    public void setUsr14(String usr14) {
        this.usr14 = usr14;
    }
    /**
     * @return the usr15
     */
    public String getUsr15() {
        return usr15;
    }
    /**
     * @param usr15 the usr15 to set
     */
    public void setUsr15(String usr15) {
        this.usr15 = usr15;
    }
    /**
     * @return the usr16
     */
    public String getUsr16() {
        return usr16;
    }
    /**
     * @param usr16 the usr16 to set
     */
    public void setUsr16(String usr16) {
        this.usr16 = usr16;
    }
    /**
     * @return the usr17
     */
    public String getUsr17() {
        return usr17;
    }
    /**
     * @param usr17 the usr17 to set
     */
    public void setUsr17(String usr17) {
        this.usr17 = usr17;
    }
    /**
     * @return the usr18
     */
    public String getUsr18() {
        return usr18;
    }
    /**
     * @param usr18 the usr18 to set
     */
    public void setUsr18(String usr18) {
        this.usr18 = usr18;
    }
    /**
     * @return the usr19
     */
    public String getUsr19() {
        return usr19;
    }
    /**
     * @param usr19 the usr19 to set
     */
    public void setUsr19(String usr19) {
        this.usr19 = usr19;
    }
    /**
     * @return the usr20
     */
    public String getUsr20() {
        return usr20;
    }
    /**
     * @param usr20 the usr20 to set
     */
    public void setUsr20(String usr20) {
        this.usr20 = usr20;
    }
    /**
     * @return the usr21
     */
    public String getUsr21() {
        return usr21;
    }
    /**
     * @param usr21 the usr21 to set
     */
    public void setUsr21(String usr21) {
        this.usr21 = usr21;
    }
    /**
     * @return the usr22
     */
    public String getUsr22() {
        return usr22;
    }
    /**
     * @param usr22 the usr22 to set
     */
    public void setUsr22(String usr22) {
        this.usr22 = usr22;
    }
    /**
     * @return the usr23
     */
    public Date getUsr23() {
        return usr23;
    }
    /**
     * @param usr23 the usr23 to set
     */
    public void setUsr23(Date usr23) {
        this.usr23 = usr23;
    }
    /**
     * @return the usr24
     */
    public Date getUsr24() {
        return usr24;
    }
    /**
     * @param usr24 the usr24 to set
     */
    public void setUsr24(Date usr24) {
        this.usr24 = usr24;
    }
    /**
     * @return the usr25
     */
    public Date getUsr25() {
        return usr25;
    }
    /**
     * @param usr25 the usr25 to set
     */
    public void setUsr25(Date usr25) {
        this.usr25 = usr25;
    }
    /**
     * @return the usr26
     */
    public Date getUsr26() {
        return usr26;
    }
    /**
     * @param usr26 the usr26 to set
     */
    public void setUsr26(Date usr26) {
        this.usr26 = usr26;
    }
    /**
     * @return the usr27
     */
    public String getUsr27() {
        return usr27;
    }
    /**
     * @param usr27 the usr27 to set
     */
    public void setUsr27(String usr27) {
        this.usr27 = usr27;
    }
    /**
     * @return the usr28
     */
    public String getUsr28() {
        return usr28;
    }
    /**
     * @param usr28 the usr28 to set
     */
    public void setUsr28(String usr28) {
        this.usr28 = usr28;
    }
    /**
     * @return the usr29
     */
    public String getUsr29() {
        return usr29;
    }
    /**
     * @param usr29 the usr29 to set
     */
    public void setUsr29(String usr29) {
        this.usr29 = usr29;
    }
    /**
     * @return the usr30
     */
    public String getUsr30() {
        return usr30;
    }
    /**
     * @param usr30 the usr30 to set
     */
    public void setUsr30(String usr30) {
        this.usr30 = usr30;
    }
    /**
     * @return the usr31
     */
    public String getUsr31() {
        return usr31;
    }
    /**
     * @param usr31 the usr31 to set
     */
    public void setUsr31(String usr31) {
        this.usr31 = usr31;
    }
    /**
     * @return the usr32
     */
    public String getUsr32() {
        return usr32;
    }
    /**
     * @param usr32 the usr32 to set
     */
    public void setUsr32(String usr32) {
        this.usr32 = usr32;
    }
    /**
     * @return the usr33
     */
    public String getUsr33() {
        return usr33;
    }
    /**
     * @param usr33 the usr33 to set
     */
    public void setUsr33(String usr33) {
        this.usr33 = usr33;
    }
    /**
     * @return the usr34
     */
    public String getUsr34() {
        return usr34;
    }
    /**
     * @param usr34 the usr34 to set
     */
    public void setUsr34(String usr34) {
        this.usr34 = usr34;
    }
    /**
     * @return the usr35
     */
    public String getUsr35() {
        return usr35;
    }
    /**
     * @param usr35 the usr35 to set
     */
    public void setUsr35(String usr35) {
        this.usr35 = usr35;
    }
    /**
     * @return the usr36
     */
    public String getUsr36() {
        return usr36;
    }
    /**
     * @param usr36 the usr36 to set
     */
    public void setUsr36(String usr36) {
        this.usr36 = usr36;
    }
    /**
     * @return the usr37
     */
    public String getUsr37() {
        return usr37;
    }
    /**
     * @param usr37 the usr37 to set
     */
    public void setUsr37(String usr37) {
        this.usr37 = usr37;
    }
    /**
     * @return the usr38
     */
    public String getUsr38() {
        return usr38;
    }
    /**
     * @param usr38 the usr38 to set
     */
    public void setUsr38(String usr38) {
        this.usr38 = usr38;
    }
    /**
     * @return the usr39
     */
    public String getUsr39() {
        return usr39;
    }
    /**
     * @param usr39 the usr39 to set
     */
    public void setUsr39(String usr39) {
        this.usr39 = usr39;
    }
}
