package com.mobis.maps.cmmn.vo;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <pre>
 * MAPS PDA 조직정보 항목
 * </pre>
 *
 * @ClassName   : MapsOrgnztPdaVO.java
 * @Description : MAPS PDA 조직정보에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 6. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 8.     DT048058     	최초 생성
 * </pre>
 */

public class MapsOrgnztPdaVO   implements Serializable {
    
    
    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = -7359884682020646803L;
    /** ABAP System Field: Name of SAP System */
    private String sysid;
    /** 클라이언트  */
    private String mandt;
    /** 회사코드  */
    private String compCode;
    /** 비즈니스 파트너 GUID */
    private String prrGuid;
    /** 프로세서 */
    private String prrId;
    /** 거래처내역  */
    private String prrTxt;
    /** 창고 번호/복합 창고 */
    private String lgnum;
    /** 서비스 시작일  */
    private String srvStartDate;
    /** 서비스 종료일  */
    private String zzsrvEndDate;
    /** 처리자 그룹 */
    private String prrGr;
    /** 처리자 그룹 이름 */
    private String prrGrTxt;
    /** 처리자 그룹 담당자  */
    private String teamResp;
    /** 팀 리더 */
    private String teamlead;
    /** 팀 리더 이름 */
    private String teamleadTxt;
    /** 비즈니스 파트너에 지정된 사용자  */
    private String username;
    /** 프로세서 유형 */
    private String prrType;
    /** 처리자 유형 내역 */
    private String prrTypeTxt;
    /** 처리자의 리포팅 그룹 */
    private String prrRepg;
    /** 처리자의 리포팅 그룹 내역 */
    private String prrRepgTxt;
    /** 처리자의 작업 범주 */
    private String workcat;
    /** 처리자의 작업 범주 내역 */
    private String workcatTxt;
    /** 십진수 형식 */
    private String zzprrDcpfm;
    /** 일자 포맷 */
    private String zzprrDatfm;
    /** 시간 형식(12시간/24시간 지정) */
    private String zzprrTimefm;
    /** 국가키 */
    private String country;
    /** 등록일시 */
    private Date registDt;
    
    /** 로그인 ID */
    private String zzpdaLoginId;
    
    public String getToString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.DEFAULT_STYLE);
    }
    
    /**
     * @return the zzpdaLoginId
     */
    public String getZzpdaLoginId() {
        return zzpdaLoginId;
    }
    /**
     * @param zzpdaLoginId the zzpdaLoginId to set
     */
    public void setZzpdaLoginId(String zzpdaLoginId) {
        this.zzpdaLoginId = zzpdaLoginId;
    }
    /**
     * @return the sysid
     */
    public String getSysid() {
        return sysid;
    }
    /**
     * @param sysid the sysid to set
     */
    public void setSysid(String sysid) {
        this.sysid = sysid;
    }
    /**
     * @return the mandt
     */
    public String getMandt() {
        return mandt;
    }
    /**
     * @param mandt the mandt to set
     */
    public void setMandt(String mandt) {
        this.mandt = mandt;
    }
    /**
     * @return the compCode
     */
    public String getCompCode() {
        return compCode;
    }
    /**
     * @param compCode the compCode to set
     */
    public void setCompCode(String compCode) {
        this.compCode = compCode;
    }
    /**
     * @return the prrGuid
     */
    public String getPrrGuid() {
        return prrGuid;
    }
    /**
     * @param prrGuid the prrGuid to set
     */
    public void setPrrGuid(String prrGuid) {
        this.prrGuid = prrGuid;
    }
    /**
     * @return the prrId
     */
    public String getPrrId() {
        return prrId;
    }
    /**
     * @param prrId the prrId to set
     */
    public void setPrrId(String prrId) {
        this.prrId = prrId;
    }
    /**
     * @return the prrTxt
     */
    public String getPrrTxt() {
        return prrTxt;
    }
    /**
     * @param prrTxt the prrTxt to set
     */
    public void setPrrTxt(String prrTxt) {
        this.prrTxt = prrTxt;
    }
    /**
     * @return the lgnum
     */
    public String getLgnum() {
        return lgnum;
    }
    /**
     * @param lgnum the lgnum to set
     */
    public void setLgnum(String lgnum) {
        this.lgnum = lgnum;
    }
    /**
     * @return the srvStartDate
     */
    public String getSrvStartDate() {
        return srvStartDate;
    }
    /**
     * @param srvStartDate the srvStartDate to set
     */
    public void setSrvStartDate(String srvStartDate) {
        this.srvStartDate = srvStartDate;
    }
    /**
     * @return the zzsrvEndDate
     */
    public String getZzsrvEndDate() {
        return zzsrvEndDate;
    }
    /**
     * @param zzsrvEndDate the zzsrvEndDate to set
     */
    public void setZzsrvEndDate(String zzsrvEndDate) {
        this.zzsrvEndDate = zzsrvEndDate;
    }
    /**
     * @return the prrGr
     */
    public String getPrrGr() {
        return prrGr;
    }
    /**
     * @param prrGr the prrGr to set
     */
    public void setPrrGr(String prrGr) {
        this.prrGr = prrGr;
    }
    /**
     * @return the prrGrTxt
     */
    public String getPrrGrTxt() {
        return prrGrTxt;
    }
    /**
     * @param prrGrTxt the prrGrTxt to set
     */
    public void setPrrGrTxt(String prrGrTxt) {
        this.prrGrTxt = prrGrTxt;
    }
    /**
     * @return the teamResp
     */
    public String getTeamResp() {
        return teamResp;
    }
    /**
     * @param teamResp the teamResp to set
     */
    public void setTeamResp(String teamResp) {
        this.teamResp = teamResp;
    }
    /**
     * @return the teamlead
     */
    public String getTeamlead() {
        return teamlead;
    }
    /**
     * @param teamlead the teamlead to set
     */
    public void setTeamlead(String teamlead) {
        this.teamlead = teamlead;
    }
    /**
     * @return the teamleadTxt
     */
    public String getTeamleadTxt() {
        return teamleadTxt;
    }
    /**
     * @param teamleadTxt the teamleadTxt to set
     */
    public void setTeamleadTxt(String teamleadTxt) {
        this.teamleadTxt = teamleadTxt;
    }
    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }
    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }
    /**
     * @return the prrType
     */
    public String getPrrType() {
        return prrType;
    }
    /**
     * @param prrType the prrType to set
     */
    public void setPrrType(String prrType) {
        this.prrType = prrType;
    }
    /**
     * @return the prrTypeTxt
     */
    public String getPrrTypeTxt() {
        return prrTypeTxt;
    }
    /**
     * @param prrTypeTxt the prrTypeTxt to set
     */
    public void setPrrTypeTxt(String prrTypeTxt) {
        this.prrTypeTxt = prrTypeTxt;
    }
    /**
     * @return the prrRepg
     */
    public String getPrrRepg() {
        return prrRepg;
    }
    /**
     * @param prrRepg the prrRepg to set
     */
    public void setPrrRepg(String prrRepg) {
        this.prrRepg = prrRepg;
    }
    /**
     * @return the prrRepgTxt
     */
    public String getPrrRepgTxt() {
        return prrRepgTxt;
    }
    /**
     * @param prrRepgTxt the prrRepgTxt to set
     */
    public void setPrrRepgTxt(String prrRepgTxt) {
        this.prrRepgTxt = prrRepgTxt;
    }
    /**
     * @return the workcat
     */
    public String getWorkcat() {
        return workcat;
    }
    /**
     * @param workcat the workcat to set
     */
    public void setWorkcat(String workcat) {
        this.workcat = workcat;
    }
    /**
     * @return the workcatTxt
     */
    public String getWorkcatTxt() {
        return workcatTxt;
    }
    /**
     * @param workcatTxt the workcatTxt to set
     */
    public void setWorkcatTxt(String workcatTxt) {
        this.workcatTxt = workcatTxt;
    }
    /**
     * @return the zzprrDcpfm
     */
    public String getZzprrDcpfm() {
        return zzprrDcpfm;
    }
    /**
     * @param zzprrDcpfm the zzprrDcpfm to set
     */
    public void setZzprrDcpfm(String zzprrDcpfm) {
        this.zzprrDcpfm = zzprrDcpfm;
    }
    /**
     * @return the zzprrDatfm
     */
    public String getZzprrDatfm() {
        return zzprrDatfm;
    }
    /**
     * @param zzprrDatfm the zzprrDatfm to set
     */
    public void setZzprrDatfm(String zzprrDatfm) {
        this.zzprrDatfm = zzprrDatfm;
    }
    /**
     * @return the zzprrTimefm
     */
    public String getZzprrTimefm() {
        return zzprrTimefm;
    }
    /**
     * @param zzprrTimefm the zzprrTimefm to set
     */
    public void setZzprrTimefm(String zzprrTimefm) {
        this.zzprrTimefm = zzprrTimefm;
    }
    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }
    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }
    /**
     * @return the registDt
     */
    public Date getRegistDt() {
        return registDt;
    }
    /**
     * @param registDt the registDt to set
     */
    public void setRegistDt(Date registDt) {
        this.registDt = registDt;
    }
}
