package com.mobis.maps.cmmn.exception;

import java.util.Locale;

import org.springframework.context.MessageSource;

/**
 * <pre>
 * 다중화면로그인 예외처리
 * </pre>
 *
 * @ClassName   : MapsMultiScrinLoginException.java
 * @Description : 다중화면로그인에 대한 예외처리.
 * @author DT048058
 * @since 2020. 3. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 24.     DT048058     	최초 생성
 * </pre>
 */

public class MapsMultiScrinLoginException extends MapsBizException {

    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = -4331213163640024009L;

    public MapsMultiScrinLoginException() {
        super();
    }

    public MapsMultiScrinLoginException(MessageSource messageSource
            , String messageKey
            , Exception wrappedException) {
        super(messageSource, messageKey, wrappedException);
    }

    public MapsMultiScrinLoginException(MessageSource messageSource
            , String messageKey
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, locale, wrappedException);
    }

    public MapsMultiScrinLoginException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, wrappedException);
    }

    public MapsMultiScrinLoginException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, locale, wrappedException);
    }

    public MapsMultiScrinLoginException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , String defaultMessage
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, wrappedException);
    }

    public MapsMultiScrinLoginException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , String defaultMessage
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, locale, wrappedException);
    }

    public MapsMultiScrinLoginException(MessageSource messageSource
            , String messageKey) {
        super(messageSource, messageKey);
    }

    public MapsMultiScrinLoginException(String defaultMessage
            , Exception wrappedException) {
        super(defaultMessage, wrappedException);
    }

    public MapsMultiScrinLoginException(String defaultMessage
            , Object[] messageParameters
            , Exception wrappedException) {
        super(defaultMessage, messageParameters, wrappedException);
    }

    public MapsMultiScrinLoginException(String defaultMessage) {
        super(defaultMessage);
    }
}
