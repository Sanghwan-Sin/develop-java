package com.mobis.maps.comm.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsLoggingEventProp.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 30.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommDbLoggingEventPropVO {

    private int eventId;
    private String mappedKey;
    private String mappedValue;
    
    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }
    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    /**
     * @return the mappedKey
     */
    public String getMappedKey() {
        return mappedKey;
    }
    /**
     * @param mappedKey the mappedKey to set
     */
    public void setMappedKey(String mappedKey) {
        this.mappedKey = mappedKey;
    }
    /**
     * @return the mappedValue
     */
    public String getMappedValue() {
        return mappedValue;
    }
    /**
     * @param mappedValue the mappedValue to set
     */
    public void setMappedValue(String mappedValue) {
        this.mappedValue = mappedValue;
    }
}
