package com.mobis.maps.comm.vo;

/**
 * <pre>
 * 다국어 항목
 * </pre>
 *
 * @ClassName   : MapsCommLanguageVO.java
 * @Description : 화면에 대한 펑션 정의
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
public class MapsCommScrinFnctVO {
    /** userSeqId */
    private String userSeqId;
    /** 화면ID */
    private String scrinId;
    /** Func ID */
    private String fnctId;
    /** Funct Secton */
    private String fnctSeCd;
    /** Funct Nm */
    private String fnctNm;
    /** Func Url */
    private String fnctUrl;
    /** 콤포넌트ID */
    private String compnId;
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the fnctId
     */
    public String getFnctId() {
        return fnctId;
    }
    /**
     * @param fnctId the fnctId to set
     */
    public void setFnctId(String fnctId) {
        this.fnctId = fnctId;
    }
    /**
     * @return the fnctSeCd
     */
    public String getFnctSeCd() {
        return fnctSeCd;
    }
    /**
     * @param fnctSeCd the fnctSeCd to set
     */
    public void setFnctSeCd(String fnctSeCd) {
        this.fnctSeCd = fnctSeCd;
    }
    /**
     * @return the fnctNm
     */
    public String getFnctNm() {
        return fnctNm;
    }
    /**
     * @param fnctNm the fnctNm to set
     */
    public void setFnctNm(String fnctNm) {
        this.fnctNm = fnctNm;
    }
    /**
     * @return the fnctUrl
     */
    public String getFnctUrl() {
        return fnctUrl;
    }
    /**
     * @param fnctUrl the fnctUrl to set
     */
    public void setFnctUrl(String fnctUrl) {
        this.fnctUrl = fnctUrl;
    }
    /**
     * @return the compnId
     */
    public String getCompnId() {
        return compnId;
    }
    /**
     * @param compnId the compnId to set
     */
    public void setCompnId(String compnId) {
        this.compnId = compnId;
    }
}
