package com.mobis.maps.cmmn.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * <pre>
 * 로그인 정보 항목
 * </pre>
 *
 * @ClassName   : LoginInfoVO.java
 * @Description : 로그인 정보에 대한 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 28.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class LoginInfoVO implements Serializable {
    /**
     * Statements
     * (long)serialVersionUID
     */
    private static final long serialVersionUID = -1837186421036575037L;
    /* 로그인정보 */
    /** 세션ID */
    private String sessionId;
    /** 최종로그인일시 */
    private Date loginDt;
    /** 최종로그인IP주소 */
    private String loginIpAdres;
    /** 디폴트언어코드 */
    private String dfltLangCd;
    /** 언어코드 */
    private String langCd;
    /** 사용자언어 */
    private Locale userLcale;
    /** 사용자TimeZone */
    private TimeZone userTz;
    /* 사용자 */
    /** 사용자순번ID */
    private String userSeqId;
    /** 관리자ID */
    private String mngrId;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 사용자ID */
    private String userId;
    /** 사용자기본ID */
    private String userBassId;
    /** 사용자명 */
    private String userNm;
    /** 조직구분코드 */
    private String userBassOrgnztSeCd;
    /** 영업조직코드 */
    private String userBassBsnOrgnztCd;
    /** 조직코드 */
    private String userBassOrgnztCd;
    /** 딜러코드 */
    private String userBassDealerCd;
    /** 이메일주소 */
    private String email;
    /** 휴대전화번호 */
    private String moblphonNo;
    /** 사무실전화번호 */
    private String offmTelno;
    /** 팩스전화번호 */
    private String faxTelno;
    /** 사용자암호 */
    private String userPwd;
    /** 구사용자ID */
    private String asisUserId;
    /** 조직구분코드 */
    private String orgnztSeCd;
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 영업조직명 */
    private String bsnOrgnztNm;
    /** 조직코드 */
    private String orgnztCd;
    /** 조직명 */
    private String orgnztNm;
    /** 딜러코드 */
    private String dealerCd;
    /** 딜러명 */
    private String dealerNm;
    /** 계정유형코드 */
    private String acntTyCd;
    /** 계정잠금여부 */
    private String acntLockYn;
    /** 계정잠금사유코드 */
    private String acntLockResnCd;
    /** 타임존코드 */
    private String tzoneCd;
    /** 허용IP사용여부 */
    private String permIpUseYn;
    /** 사용시작일 */
    private Date useBgnde;
    /** 사용종료일 */
    private Date useEndde;
    /** 개인정보수집이용동의여부 */
    private String indvdlinfoColctUseAgreYn;
    /** 개인정보수집이용동의일시 */
    private Date indvdlinfoColctUseAgreDt;
    /** 암호만료일시 */
    private Date pwdEndDt;
    /** 암호오류횟수 */
    private int pwdErrorCo;
    /** 암호초기화여부 */
    private String pwdInitlYn;
    /** 암호변경일시 */
    private Date pwdChangeDt;
    /** 최종로그인일시 */
    private Date lastLoginDt;
    /** 최종로그인IP주소 */
    private String lastLoginIpAdres;
    /** 사용여부 */
    private String useYn;
    /** 삭제여부 */
    private String delYn;
    /* TimeZone */
    /** RFC PC시스템ID */
    private String tzId;
    /** RFC PC시스템ID */
    private int tzRawOffset;
    /* RFC */
    /** RFC PC시스템ID */
    private String rfcPcSysId;
    /** RFC PC클라이언트 */
    private String rfcPcClient;
    /** RFC PW시스템ID */
    private String rfcPwSysId;
    /** RFC PW클라이언트 */
    private String rfcPwClient;
    /** RFC서버언어 */
    private String rfcServerLang;
    /** RFC시간대 */
    private String rfcTzone;
    /** RFC언어 */
    private String rfcLang;
    /** SCREEN 구분코드(NULL : 디폴트 URL , 1:HTML5 버전 , 2:마이플랫폼 Big버전 */
    private String scrinUrlSeCd;
    /* 기타 */
    /** PWD_CHK_YN DB암호화로 패스워드는 서버에서 체크 1: 비번동일 0 : 실패**/
    private String pwdChkYn;
    /** 대표대리점여부 */
    private boolean repZkunnr;
    /** 중복 로그인여부 ==> 현재로그인되어 있으면 preLoginFlag에 "LOGIN"이 셋팅됨.*/
    private String preLoginFlag;
    
    
    /**
     * @return the preLoginFlag
     */
    public String getPreLoginFlag() {
        return preLoginFlag;
    }
    /**
     * @param preLoginFlag the preLoginFlag to set
     */
    public void setPreLoginFlag(String preLoginFlag) {
        this.preLoginFlag = preLoginFlag;
    }
    /**
     * @return the pwdChkYn
     */
    public String getPwdChkYn() {
        return pwdChkYn;
    }
    /**
     * @param pwdChkYn the pwdChkYn to set
     */
    public void setPwdChkYn(String pwdChkYn) {
        this.pwdChkYn = pwdChkYn;
    }
    /**
     * @return the scrinUrlSeCd
     */
    public String getScrinUrlSeCd() {
        return scrinUrlSeCd;
    }
    /**
     * @param scrinUrlSeCd the scrinUrlSeCd to set
     */
    public void setScrinUrlSeCd(String scrinUrlSeCd) {
        this.scrinUrlSeCd = scrinUrlSeCd;
    }
    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }
    /**
     * @param sessionId the sessionId to set
     */
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
    /**
     * @return the loginDt
     */
    public Date getLoginDt() {
        return loginDt;
    }
    /**
     * @param loginDt the loginDt to set
     */
    public void setLoginDt(Date loginDt) {
        this.loginDt = loginDt;
    }
    /**
     * @return the loginIpAdres
     */
    public String getLoginIpAdres() {
        return loginIpAdres;
    }
    /**
     * @param loginIpAdres the loginIpAdres to set
     */
    public void setLoginIpAdres(String loginIpAdres) {
        this.loginIpAdres = loginIpAdres;
    }
    /**
     * @return the dfltLangCd
     */
    public String getDfltLangCd() {
        return dfltLangCd;
    }
    /**
     * @param dfltLangCd the dfltLangCd to set
     */
    public void setDfltLangCd(String dfltLangCd) {
        this.dfltLangCd = dfltLangCd;
    }
    /**
     * @return the langCd
     */
    public String getLangCd() {
        return langCd;
    }
    /**
     * @param langCd the langCd to set
     */
    public void setLangCd(String langCd) {
        this.langCd = langCd;
    }
    /**
     * @return the userLcale
     */
    public Locale getUserLcale() {
        return userLcale;
    }
    /**
     * @param userLcale the userLcale to set
     */
    public void setUserLcale(Locale userLcale) {
        this.userLcale = userLcale;
    }
    /**
     * @return the userTz
     */
    public TimeZone getUserTz() {
        return userTz;
    }
    /**
     * @param userTz the userTz to set
     */
    public void setUserTz(TimeZone userTz) {
        this.userTz = userTz;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
    /**
     * @return the mngrId
     */
    public String getMngrId() {
        return mngrId;
    }
    /**
     * @param mngrId the mngrId to set
     */
    public void setMngrId(String mngrId) {
        this.mngrId = mngrId;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userBassId
     */
    public String getUserBassId() {
        return userBassId;
    }
    /**
     * @param userBassId the userBassId to set
     */
    public void setUserBassId(String userBassId) {
        this.userBassId = userBassId;
    }
    /**
     * @return the userNm
     */
    public String getUserNm() {
        return userNm;
    }
    /**
     * @param userNm the userNm to set
     */
    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }
    /**
     * @return the userBassOrgnztSeCd
     */
    public String getUserBassOrgnztSeCd() {
        return userBassOrgnztSeCd;
    }
    /**
     * @param userBassOrgnztSeCd the userBassOrgnztSeCd to set
     */
    public void setUserBassOrgnztSeCd(String userBassOrgnztSeCd) {
        this.userBassOrgnztSeCd = userBassOrgnztSeCd;
    }
    /**
     * @return the userBassBsnOrgnztCd
     */
    public String getUserBassBsnOrgnztCd() {
        return userBassBsnOrgnztCd;
    }
    /**
     * @param userBassBsnOrgnztCd the userBassBsnOrgnztCd to set
     */
    public void setUserBassBsnOrgnztCd(String userBassBsnOrgnztCd) {
        this.userBassBsnOrgnztCd = userBassBsnOrgnztCd;
    }
    /**
     * @return the userBassOrgnztCd
     */
    public String getUserBassOrgnztCd() {
        return userBassOrgnztCd;
    }
    /**
     * @param userBassOrgnztCd the userBassOrgnztCd to set
     */
    public void setUserBassOrgnztCd(String userBassOrgnztCd) {
        this.userBassOrgnztCd = userBassOrgnztCd;
    }
    /**
     * @return the userBassDealerCd
     */
    public String getUserBassDealerCd() {
        return userBassDealerCd;
    }
    /**
     * @param userBassDealerCd the userBassDealerCd to set
     */
    public void setUserBassDealerCd(String userBassDealerCd) {
        this.userBassDealerCd = userBassDealerCd;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the moblphonNo
     */
    public String getMoblphonNo() {
        return moblphonNo;
    }
    /**
     * @param moblphonNo the moblphonNo to set
     */
    public void setMoblphonNo(String moblphonNo) {
        this.moblphonNo = moblphonNo;
    }
    /**
     * @return the offmTelno
     */
    public String getOffmTelno() {
        return offmTelno;
    }
    /**
     * @param offmTelno the offmTelno to set
     */
    public void setOffmTelno(String offmTelno) {
        this.offmTelno = offmTelno;
    }
    /**
     * @return the faxTelno
     */
    public String getFaxTelno() {
        return faxTelno;
    }
    /**
     * @param faxTelno the faxTelno to set
     */
    public void setFaxTelno(String faxTelno) {
        this.faxTelno = faxTelno;
    }
    /**
     * @return the userPwd
     */
    public String getUserPwd() {
        return userPwd;
    }
    /**
     * @param userPwd the userPwd to set
     */
    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }
    /**
     * @return the asisUserId
     */
    public String getAsisUserId() {
        return asisUserId;
    }
    /**
     * @param asisUserId the asisUserId to set
     */
    public void setAsisUserId(String asisUserId) {
        this.asisUserId = asisUserId;
    }
    /**
     * @return the orgnztSeCd
     */
    public String getOrgnztSeCd() {
        return orgnztSeCd;
    }
    /**
     * @param orgnztSeCd the orgnztSeCd to set
     */
    public void setOrgnztSeCd(String orgnztSeCd) {
        this.orgnztSeCd = orgnztSeCd;
    }
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the bsnOrgnztNm
     */
    public String getBsnOrgnztNm() {
        return bsnOrgnztNm;
    }
    /**
     * @param bsnOrgnztNm the bsnOrgnztNm to set
     */
    public void setBsnOrgnztNm(String bsnOrgnztNm) {
        this.bsnOrgnztNm = bsnOrgnztNm;
    }
    /**
     * @return the orgnztCd
     */
    public String getOrgnztCd() {
        return orgnztCd;
    }
    /**
     * @param orgnztCd the orgnztCd to set
     */
    public void setOrgnztCd(String orgnztCd) {
        this.orgnztCd = orgnztCd;
    }
    /**
     * @return the orgnztNm
     */
    public String getOrgnztNm() {
        return orgnztNm;
    }
    /**
     * @param orgnztNm the orgnztNm to set
     */
    public void setOrgnztNm(String orgnztNm) {
        this.orgnztNm = orgnztNm;
    }
    /**
     * @return the dealerCd
     */
    public String getDealerCd() {
        return dealerCd;
    }
    /**
     * @param dealerCd the dealerCd to set
     */
    public void setDealerCd(String dealerCd) {
        this.dealerCd = dealerCd;
    }
    /**
     * @return the dealerNm
     */
    public String getDealerNm() {
        return dealerNm;
    }
    /**
     * @param dealerNm the dealerNm to set
     */
    public void setDealerNm(String dealerNm) {
        this.dealerNm = dealerNm;
    }
    /**
     * @return the acntTyCd
     */
    public String getAcntTyCd() {
        return acntTyCd;
    }
    /**
     * @param acntTyCd the acntTyCd to set
     */
    public void setAcntTyCd(String acntTyCd) {
        this.acntTyCd = acntTyCd;
    }
    /**
     * @return the acntLockYn
     */
    public String getAcntLockYn() {
        return acntLockYn;
    }
    /**
     * @param acntLockYn the acntLockYn to set
     */
    public void setAcntLockYn(String acntLockYn) {
        this.acntLockYn = acntLockYn;
    }
    /**
     * @return the acntLockResnCd
     */
    public String getAcntLockResnCd() {
        return acntLockResnCd;
    }
    /**
     * @param acntLockResnCd the acntLockResnCd to set
     */
    public void setAcntLockResnCd(String acntLockResnCd) {
        this.acntLockResnCd = acntLockResnCd;
    }
    /**
     * @return the tzoneCd
     */
    public String getTzoneCd() {
        return tzoneCd;
    }
    /**
     * @param tzoneCd the tzoneCd to set
     */
    public void setTzoneCd(String tzoneCd) {
        this.tzoneCd = tzoneCd;
    }
    /**
     * @return the permIpUseYn
     */
    public String getPermIpUseYn() {
        return permIpUseYn;
    }
    /**
     * @param permIpUseYn the permIpUseYn to set
     */
    public void setPermIpUseYn(String permIpUseYn) {
        this.permIpUseYn = permIpUseYn;
    }
    /**
     * @return the useBgnde
     */
    public Date getUseBgnde() {
        return useBgnde;
    }
    /**
     * @param useBgnde the useBgnde to set
     */
    public void setUseBgnde(Date useBgnde) {
        this.useBgnde = useBgnde;
    }
    /**
     * @return the useEndde
     */
    public Date getUseEndde() {
        return useEndde;
    }
    /**
     * @param useEndde the useEndde to set
     */
    public void setUseEndde(Date useEndde) {
        this.useEndde = useEndde;
    }
    /**
     * @return the indvdlinfoColctUseAgreYn
     */
    public String getIndvdlinfoColctUseAgreYn() {
        return indvdlinfoColctUseAgreYn;
    }
    /**
     * @param indvdlinfoColctUseAgreYn the indvdlinfoColctUseAgreYn to set
     */
    public void setIndvdlinfoColctUseAgreYn(String indvdlinfoColctUseAgreYn) {
        this.indvdlinfoColctUseAgreYn = indvdlinfoColctUseAgreYn;
    }
    /**
     * @return the indvdlinfoColctUseAgreDt
     */
    public Date getIndvdlinfoColctUseAgreDt() {
        return indvdlinfoColctUseAgreDt;
    }
    /**
     * @param indvdlinfoColctUseAgreDt the indvdlinfoColctUseAgreDt to set
     */
    public void setIndvdlinfoColctUseAgreDt(Date indvdlinfoColctUseAgreDt) {
        this.indvdlinfoColctUseAgreDt = indvdlinfoColctUseAgreDt;
    }
    /**
     * @return the pwdEndDt
     */
    public Date getPwdEndDt() {
        return pwdEndDt;
    }
    /**
     * @param pwdEndDt the pwdEndDt to set
     */
    public void setPwdEndDt(Date pwdEndDt) {
        this.pwdEndDt = pwdEndDt;
    }
    /**
     * @return the pwdErrorCo
     */
    public int getPwdErrorCo() {
        return pwdErrorCo;
    }
    /**
     * @param pwdErrorCo the pwdErrorCo to set
     */
    public void setPwdErrorCo(int pwdErrorCo) {
        this.pwdErrorCo = pwdErrorCo;
    }
    /**
     * @return the pwdInitlYn
     */
    public String getPwdInitlYn() {
        return pwdInitlYn;
    }
    /**
     * @param pwdInitlYn the pwdInitlYn to set
     */
    public void setPwdInitlYn(String pwdInitlYn) {
        this.pwdInitlYn = pwdInitlYn;
    }
    /**
     * @return the pwdChangeDt
     */
    public Date getPwdChangeDt() {
        return pwdChangeDt;
    }
    /**
     * @param pwdChangeDt the pwdChangeDt to set
     */
    public void setPwdChangeDt(Date pwdChangeDt) {
        this.pwdChangeDt = pwdChangeDt;
    }
    /**
     * @return the lastLoginDt
     */
    public Date getLastLoginDt() {
        return lastLoginDt;
    }
    /**
     * @param lastLoginDt the lastLoginDt to set
     */
    public void setLastLoginDt(Date lastLoginDt) {
        this.lastLoginDt = lastLoginDt;
    }
    /**
     * @return the lastLoginIpAdres
     */
    public String getLastLoginIpAdres() {
        return lastLoginIpAdres;
    }
    /**
     * @param lastLoginIpAdres the lastLoginIpAdres to set
     */
    public void setLastLoginIpAdres(String lastLoginIpAdres) {
        this.lastLoginIpAdres = lastLoginIpAdres;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }
    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    /**
     * @return the tzId
     */
    public String getTzId() {
        return tzId;
    }
    /**
     * @param tzId the tzId to set
     */
    public void setTzId(String tzId) {
        this.tzId = tzId;
    }
    /**
     * @return the tzRawOffset
     */
    public int getTzRawOffset() {
        return tzRawOffset;
    }
    /**
     * @param tzRawOffset the tzRawOffset to set
     */
    public void setTzRawOffset(int tzRawOffset) {
        this.tzRawOffset = tzRawOffset;
    }
    /**
     * @return the rfcPcSysId
     */
    public String getRfcPcSysId() {
        return rfcPcSysId;
    }
    /**
     * @param rfcPcSysId the rfcPcSysId to set
     */
    public void setRfcPcSysId(String rfcPcSysId) {
        this.rfcPcSysId = rfcPcSysId;
    }
    /**
     * @return the rfcPcClient
     */
    public String getRfcPcClient() {
        return rfcPcClient;
    }
    /**
     * @param rfcPcClient the rfcPcClient to set
     */
    public void setRfcPcClient(String rfcPcClient) {
        this.rfcPcClient = rfcPcClient;
    }
    /**
     * @return the rfcPwSysId
     */
    public String getRfcPwSysId() {
        return rfcPwSysId;
    }
    /**
     * @param rfcPwSysId the rfcPwSysId to set
     */
    public void setRfcPwSysId(String rfcPwSysId) {
        this.rfcPwSysId = rfcPwSysId;
    }
    /**
     * @return the rfcPwClient
     */
    public String getRfcPwClient() {
        return rfcPwClient;
    }
    /**
     * @param rfcPwClient the rfcPwClient to set
     */
    public void setRfcPwClient(String rfcPwClient) {
        this.rfcPwClient = rfcPwClient;
    }
    /**
     * @return the rfcServerLang
     */
    public String getRfcServerLang() {
        return rfcServerLang;
    }
    /**
     * @param rfcServerLang the rfcServerLang to set
     */
    public void setRfcServerLang(String rfcServerLang) {
        this.rfcServerLang = rfcServerLang;
    }
    /**
     * @return the rfcTzone
     */
    public String getRfcTzone() {
        return rfcTzone;
    }
    /**
     * @param rfcTzone the rfcTzone to set
     */
    public void setRfcTzone(String rfcTzone) {
        this.rfcTzone = rfcTzone;
    }
    /**
     * @return the rfcLang
     */
    public String getRfcLang() {
        return rfcLang;
    }
    /**
     * @param rfcLang the rfcLang to set
     */
    public void setRfcLang(String rfcLang) {
        this.rfcLang = rfcLang;
    }
    /**
     * @return the repZkunnr
     */
    public boolean isRepZkunnr() {
        return repZkunnr;
    }
    /**
     * @param repZkunnr the repZkunnr to set
     */
    public void setRepZkunnr(boolean repZkunnr) {
        this.repZkunnr = repZkunnr;
    }
    
}
