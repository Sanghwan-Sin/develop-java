package com.mobis.maps.comm.vo;

import java.util.Date;
import java.util.List;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommSapDestInfoVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 23.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommSapDestInfoVO {
    /** Destination ID */
    private String destId;
    /** Destination Name */
    private String destNm;
    /** Last Activity Timestamp */
    private Date lastActvtyDt;
    /** Last Activity Timestamp */
    private String lastActvtyDate;
    /** Max Used Count */
    private int maxUsedCnt;
    /** Origin destination ID */
    private String orginDestId;
    /** Peak Limit */
    private int pkLmt;
    /** Pool Capacity */
    private int poolCpcty;
    /** Pooled Connection Count */
    private int pooledConectCnt;
    /** Used Connection Count */
    private int usedConectCnt;
    /** Waiting Thread Count */
    private int waitThreadCnt;
    /** Vaid */
    private boolean valid;
    /** Connection Infomation List */
    private List<MapsCommSapDestConectInfoVO> destConectInfos;
    
    /**
     * @return the destId
     */
    public String getDestId() {
        return destId;
    }
    /**
     * @param destId the destId to set
     */
    public void setDestId(String destId) {
        this.destId = destId;
    }
    /**
     * @return the destNm
     */
    public String getDestNm() {
        return destNm;
    }
    /**
     * @param destNm the destNm to set
     */
    public void setDestNm(String destNm) {
        this.destNm = destNm;
    }
    /**
     * @return the lastActvtyDt
     */
    public Date getLastActvtyDt() {
        return lastActvtyDt;
    }
    /**
     * @param lastActvtyDt the lastActvtyDt to set
     */
    public void setLastActvtyDt(Date lastActvtyDt) {
        this.lastActvtyDt = lastActvtyDt;
    }
    /**
     * @return the maxUsedCnt
     */
    public int getMaxUsedCnt() {
        return maxUsedCnt;
    }
    /**
     * @param maxUsedCnt the maxUsedCnt to set
     */
    public void setMaxUsedCnt(int maxUsedCnt) {
        this.maxUsedCnt = maxUsedCnt;
    }
    /**
     * @return the orginDestId
     */
    public String getOrginDestId() {
        return orginDestId;
    }
    /**
     * @param orginDestId the orginDestId to set
     */
    public void setOrginDestId(String orginDestId) {
        this.orginDestId = orginDestId;
    }
    /**
     * @return the pkLmt
     */
    public int getPkLmt() {
        return pkLmt;
    }
    /**
     * @param pkLmt the pkLmt to set
     */
    public void setPkLmt(int pkLmt) {
        this.pkLmt = pkLmt;
    }
    /**
     * @return the poolCpcty
     */
    public int getPoolCpcty() {
        return poolCpcty;
    }
    /**
     * @param poolCpcty the poolCpcty to set
     */
    public void setPoolCpcty(int poolCpcty) {
        this.poolCpcty = poolCpcty;
    }
    /**
     * @return the pooledConectCnt
     */
    public int getPooledConectCnt() {
        return pooledConectCnt;
    }
    /**
     * @param pooledConectCnt the pooledConectCnt to set
     */
    public void setPooledConectCnt(int pooledConectCnt) {
        this.pooledConectCnt = pooledConectCnt;
    }
    /**
     * @return the usedConectCnt
     */
    public int getUsedConectCnt() {
        return usedConectCnt;
    }
    /**
     * @param usedConectCnt the usedConectCnt to set
     */
    public void setUsedConectCnt(int usedConectCnt) {
        this.usedConectCnt = usedConectCnt;
    }
    /**
     * @return the waitThreadCnt
     */
    public int getWaitThreadCnt() {
        return waitThreadCnt;
    }
    /**
     * @param waitThreadCnt the waitThreadCnt to set
     */
    public void setWaitThreadCnt(int waitThreadCnt) {
        this.waitThreadCnt = waitThreadCnt;
    }
    /**
     * @return the valid
     */
    public boolean isValid() {
        return valid;
    }
    /**
     * @param valid the valid to set
     */
    public void setValid(boolean valid) {
        this.valid = valid;
    }
    /**
     * @return the destConectInfos
     */
    public List<MapsCommSapDestConectInfoVO> getDestConectInfos() {
        return destConectInfos;
    }
    /**
     * @param destConectInfos the destConectInfos to set
     */
    public void setDestConectInfos(List<MapsCommSapDestConectInfoVO> destConectInfos) {
        this.destConectInfos = destConectInfos;
    }
    /**
     * @return the lastActvtyDate
     */
    public String getLastActvtyDate() {
        return lastActvtyDate;
    }
    /**
     * @param lastActvtyDate the lastActvtyDate to set
     */
    public void setLastActvtyDate(String lastActvtyDate) {
        this.lastActvtyDate = lastActvtyDate;
    }
}
