package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.service.MapsIamUserScrinStatsService;
import com.mobis.maps.iam.service.dao.MapsIamUserScrinStatsMDAO;
import com.mobis.maps.iam.util.MapsIamUtil;
import com.mobis.maps.iam.vo.MapsIamUserScrinStatsVO;

/**
 * <pre>
 * 사용자 화면 통계 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinStatsServiceImpl.java
 * @Description : 사용자 화면 통계에 대한 서비스 구현.
 * @author DT048058
 * @since 2020. 5. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 7.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsIamUserScrinStatsService")
public class MapsIamUserScrinStatsServiceImpl extends HService implements MapsIamUserScrinStatsService {

    @Resource(name = "mapsIamMobisUserService")
    MapsIamMobisUserService mapsIamMobisUserService;
    
    @Resource(name="mapsIamUserScrinStatsMDAO")
    private MapsIamUserScrinStatsMDAO mapsIamUserScrinStatsMDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserScrinStatsService#selectUserScrinStatsMainList(com.mobis.maps.iam.vo.MapsIamUserScrinStatsVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserScrinStatsVO> selectUserScrinStatsMainList(MapsIamUserScrinStatsVO iamUserScrinStatsVO
            , LoginInfoVO loginInfo) throws Exception {
        
        if (!StringUtils.equals(MapsIamConstants.ORGNZT_SE_CD_MOBIS, loginInfo.getOrgnztSeCd())) {
            iamUserScrinStatsVO.setBsnOrgnztCd(loginInfo.getBsnOrgnztCd());
        }
        MapsIamUtil.addOrgnztSeCd(iamUserScrinStatsVO.getSysSeCd(), iamUserScrinStatsVO, loginInfo);
        MapsIamUtil.addOrgnztCd(iamUserScrinStatsVO, loginInfo, mapsIamMobisUserService);
        
        iamUserScrinStatsVO.setLangCd(loginInfo.getLangCd());
        if (StringUtils.isBlank(iamUserScrinStatsVO.getDfltLangCd())) {
            iamUserScrinStatsVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        }

        List<MapsIamUserScrinStatsVO> lstMain = mapsIamUserScrinStatsMDAO.selectUserScrinStatsMainList(iamUserScrinStatsVO);
        
        return lstMain;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserScrinStatsService#selectUserScrinStatsDetailList(com.mobis.maps.iam.vo.MapsIamUserScrinStatsVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserScrinStatsVO> selectUserScrinStatsDetailList(MapsIamUserScrinStatsVO iamUserScrinStatsVO
            , LoginInfoVO loginInfo) throws Exception {
        
        if (!StringUtils.equals(MapsIamConstants.ORGNZT_SE_CD_MOBIS, loginInfo.getOrgnztSeCd())) {
            iamUserScrinStatsVO.setBsnOrgnztCd(loginInfo.getBsnOrgnztCd());
        }
        MapsIamUtil.addOrgnztSeCd(iamUserScrinStatsVO.getSysSeCd(), iamUserScrinStatsVO, loginInfo);
        MapsIamUtil.addOrgnztCd(iamUserScrinStatsVO, loginInfo, mapsIamMobisUserService);

        iamUserScrinStatsVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserScrinStatsVO.setRfcPcClient(RfcSapSys.PC.getClient());

        List<MapsIamUserScrinStatsVO> lstDetail = mapsIamUserScrinStatsMDAO.selectUserScrinStatsDetailList(iamUserScrinStatsVO);
        
        return lstDetail;
    }

}
