package com.mobis.maps.comm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommSapLoginVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 11.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommSapLoginVO extends MapsCommSapRfcIfCommVO {
    /* 로그인 파라매터 */
    /** 사용자ID */
    @MapsRfcMappper( targetName="P|ES_UNAME_INFO", ipttSe="I|E", fieldKey="I_UNAME|BNAME" )
    private String userId;
    /* 로그인 정보 */
    /** 언어코드 */
    private String langCd;
    /** 아이디 저장 여부 */
    private String saveIdYn;
    /* 로그인 정보 */
    /** 로그인한 url */
    private String requestUrl;
    
    /** 품의내부번호 */
    private String cnSulInnerNo;
    /** 결재항목코드 */
    private String sancItemCd;
    
    
    
    
    /**
     * @return the cnSulInnerNo
     */
    public String getCnSulInnerNo() {
        return cnSulInnerNo;
    }
    /**
     * @param cnSulInnerNo the cnSulInnerNo to set
     */
    public void setCnSulInnerNo(String cnSulInnerNo) {
        this.cnSulInnerNo = cnSulInnerNo;
    }
    /**
     * @return the sancItemCd
     */
    public String getSancItemCd() {
        return sancItemCd;
    }
    /**
     * @param sancItemCd the sancItemCd to set
     */
    public void setSancItemCd(String sancItemCd) {
        this.sancItemCd = sancItemCd;
    }
    /** 사용자명 */
    @MapsRfcMappper( targetName="ES_UNAME_INFO", ipttSe="E", fieldKey="NAME_TEXT" )
    private String userNm;
    /** 이메일 */
    @MapsRfcMappper( targetName="ES_UNAME_INFO", ipttSe="E", fieldKey="SMTP_ADDR" )
    private String email;
    /* 호면캡쳐방지용 로그인 정보 */
    /** 화면코드 */
    private String scrinCd;
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the langCd
     */
    public String getLangCd() {
        return langCd;
    }
    /**
     * @param langCd the langCd to set
     */
    public void setLangCd(String langCd) {
        this.langCd = langCd;
    }
    /**
     * @return the saveIdYn
     */
    public String getSaveIdYn() {
        return saveIdYn;
    }
    /**
     * @param saveIdYn the saveIdYn to set
     */
    public void setSaveIdYn(String saveIdYn) {
        this.saveIdYn = saveIdYn;
    }
    /**
     * @return the requestUrl
     */
    public String getRequestUrl() {
        return requestUrl;
    }
    /**
     * @param requestUrl the requestUrl to set
     */
    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }
    /**
     * @return the userNm
     */
    public String getUserNm() {
        return userNm;
    }
    /**
     * @param userNm the userNm to set
     */
    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the scrinCd
     */
    public String getScrinCd() {
        return scrinCd;
    }
    /**
     * @param scrinCd the scrinCd to set
     */
    public void setScrinCd(String scrinCd) {
        this.scrinCd = scrinCd;
    }
    
}
