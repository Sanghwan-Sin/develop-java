package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 메뉴관리 항목
 * </pre>
 *
 * @ClassName   : MapsCommMenuVO.java
 * @Description : 메뉴관리 항목을 정의
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
public class MapsIamAuthorMenuVO extends MapsIamMenuVO {
    /* 조회조건 */
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 복사권한ID */
    private String authorId;
    /* 인증관리 */
    /** 인증여부 */
    private String authorYn;

    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the authorId
     */
    public String getAuthorId() {
        return authorId;
    }
    /**
     * @param authorId the authorId to set
     */
    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }
    /**
     * @return the authorYn
     */
    public String getAuthorYn() {
        return authorYn;
    }
    /**
     * @param authorYn the authorYn to set
     */
    public void setAuthorYn(String authorYn) {
        this.authorYn = authorYn;
    }
}
