package com.mobis.maps.comm.service;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;
import com.mobis.maps.sapjco.manager.Destination;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * RFC호출 서비스
 * </pre>
 *
 * @ClassName   : MapsCmmnSapService.java
 * @Description : RFC호출에 대한 서비스를 정의.
 * @author Sin Sanghwan
 * @since 2019. 7. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 29.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsCommSapService {
    
    /**
     * Destination
     *
     * @param local
     * @return
     */
    public Destination selectDestination(Locale local) throws Exception;
    
    /**
     * Destination
     *
     * @param local
     * @param rfcSapSys
     * @return
     * @throws Exception
     */
    public Destination selectDestination(Locale local, RfcSapSys rfcSapSys) throws Exception;
    
    /**
     * Destination
     *
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public Destination selectDestination(LoginInfoVO loginInfo) throws Exception;
    
    /**
     * Destination
     *
     * @param loginInfo
     * @param rfcSapSys
     * @return
     * @throws Exception
     */
    public Destination selectDestination(LoginInfoVO loginInfo, RfcSapSys rfcSapSys) throws Exception;

    /**
     * Function
     *
     * @param loginInfo
     * @param rfcId
     * @return
     * @throws Exception
     */
    public Function selectFunction(LoginInfoVO loginInfo, String rfcId) throws Exception;
    
    
    /**
     * Statements
     *
     * @param loginInfo
     * @param rfcId
     * @param debugYn
     * @return
     * @throws Exception
     */
    public Function selectFunction(LoginInfoVO loginInfo, String rfcId, boolean debugYn) throws Exception;
    
    /**
     * selectFunction
     *
     * @param ffcSapSys
     * @param loginInfo
     * @param rfcId
     * @return
     * @throws Exception
     */
    public Function selectFunction(LoginInfoVO loginInfo, String rfcId, RfcSapSys ffcSapSys) throws Exception;
    
    
    /**
     * Statements
     *
     * @param loginInfo
     * @param rfcId
     * @param ffcSapSys
     * @param debugYn
     * @return
     * @throws Exception
     */
    public Function selectFunction(LoginInfoVO loginInfo, String rfcId, RfcSapSys ffcSapSys, boolean debugYn) throws Exception;
    

    /**
     * RFC호출 공통정보 설정
     *
     * @param loginInfo
     * @param function
     * @param commSapRfcIfCommVO
     * @throws Exception
     */
    public void selectSetRfcIfComm(LoginInfoVO loginInfo, Function function, MapsCommSapRfcIfCommVO commSapRfcIfCommVO) throws Exception;

    /**
     * RFC호출
     *
     * @param loginInfo
     * @param function
     * @return
     * @throws Exception
     */
    public FunctionResult selectExecute(LoginInfoVO loginInfo, Function function) throws Exception;
    
    /**
     * RFC호출
     *
     * @param loginInfo
     * @param function
     * @param isLog
     * @return
     * @throws Exception
     */
    public FunctionResult selectExecute(LoginInfoVO loginInfo, Function function, boolean isLog) throws Exception;
    
    /**
     * RFC호출 결과 설정
     *
     * @param funcResult
     * @param commSapRfcIfCommVO
     * @return
     * @throws Exception
     */
    public void selectSetRfcResult(FunctionResult funcResult, MapsCommSapRfcIfCommVO commSapRfcIfCommVO) throws Exception;

    /**
     * RFC호출 페이징Export Table 취득(VO)
     *
     * @param result
     * @param commSapRfcIfCommVO
     * @param rfcField
     * @param exportClass
     * @return
     * @throws Exception
     */
    public <T> List<T> selectGetExportTablePgVO(FunctionResult result, MapsCommSapRfcIfCommVO commSapRfcIfCommVO, String rfcField, Class<? extends T> exportClass) throws Exception;

    /**
     * RFC호출 페이징Export Table 취득(VO)
     *
     * @param result
     * @param commSapRfcIfCommVO
     * @param rfcField
     * @param mapngInfo
     * @param exportClass
     * @return
     * @throws Exception
     */
    public <T> List<T> selectGetExportTablePgVO(FunctionResult result, MapsCommSapRfcIfCommVO commSapRfcIfCommVO, String rfcField, Map<String, String> mapngInfo, Class<? extends T> exportClass) throws Exception;

    /**
     * RFC호출 페이징Export Table 취득(Map)
     *
     * @param result
     * @param commSapRfcIfCommVO
     * @param rfcField
     * @param mapngInfo
     * @return
     * @throws Exception
     */
    public List<Map<String, Object>> selectGetExportTablePgMap(FunctionResult result, MapsCommSapRfcIfCommVO commSapRfcIfCommVO, String rfcField, Map<String, String> mapngInfo) throws Exception;
    
    /**
     * Statements
     *
     * @param loginInfo
     * @param rfcId
     * @param imprtBean
     * @return
     * @throws Exception
     */
    public <T> List<T> selectRfcList(LoginInfoVO loginInfo, String rfcId, Object imprtBean) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param rfcId
     * @param imprtBean
     * @param exportClass
     * @return
     * @throws Exception
     */
    public <T> List<T> selectRfcList(LoginInfoVO loginInfo, String rfcId, Object imprtBean, Class<? extends T> exportClass) throws Exception;
}
