package com.mobis.maps.cmmn.exception;

import java.util.Locale;

import org.springframework.context.MessageSource;

/**
 * <pre>
 * 로그인 예외처리
 * </pre>
 *
 * @ClassName   : MapsLoginException.java
 * @Description : 로그인에 대한 예외처리.
 * @author DT048058
 * @since 2020. 3. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 24.     DT048058     	최초 생성
 * </pre>
 */

public class MapsLoginException extends MapsBizException {

    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = 6727936032055294333L;

    private int code;
    
    public MapsLoginException() {
        super();
    }

    public MapsLoginException(MessageSource messageSource
            , String messageKey
            , Exception wrappedException) {
        super(messageSource, messageKey, wrappedException);
    }

    public MapsLoginException(MessageSource messageSource
            , String messageKey
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, locale, wrappedException);
    }

    public MapsLoginException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, wrappedException);
    }

    public MapsLoginException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, locale, wrappedException);
    }

    public MapsLoginException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , String defaultMessage
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, wrappedException);
    }

    public MapsLoginException(MessageSource messageSource
            , String messageKey
            , Object[] messageParameters
            , String defaultMessage
            , Locale locale
            , Exception wrappedException) {
        super(messageSource, messageKey, messageParameters, defaultMessage, locale, wrappedException);
    }

    public MapsLoginException(MessageSource messageSource
            , String messageKey) {
        super(messageSource, messageKey);
    }

    public MapsLoginException(String defaultMessage
            , Exception wrappedException) {
        super(defaultMessage, wrappedException);
    }

    public MapsLoginException(String defaultMessage
            , Object[] messageParameters
            , Exception wrappedException) {
        super(defaultMessage, messageParameters, wrappedException);
    }

    public MapsLoginException(String defaultMessage) {
        super(defaultMessage);
    }

    /**
     * @return the code
     */
    public int getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(int code) {
        this.code = code;
    }
}
