package com.mobis.maps.iam.constants;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsIamConstants.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 3. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 11.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamConstants {

    public static final String SYSTEM_USER_SEQ_ID = "U0000000001";
    public static final String HELP_EMAIL = "maps-channel-help@mobis.co.kr";

    /** 영업조직코드(1000 : 모비스본사) */
    public static final String BSN_ORGNZT_CD_MOBIS = "1000";

    /** 사용기본ID(신규) */
    public final static String USER_BASS_ID_NEW = "NEW";
    /** 계정ID(신규) */
    public final static String USER_ID_NEW = "NEW";
    
    /** DB프로퍼티키(LOGIN_INITIAL_PW : 초기사용자암호) */
    public static final String DBPROP_KEY_INITL_USER_PWD = "LOGIN_INITIAL_PW";
    /** DB프로퍼티키(LOGIN_PW_CHNG_CYCL : 암호변경주기일수) */
    public static final String DBPROP_KEY_PWD_CHAGE_CYCL_DAY_CNT = "LOGIN_PW_CHNG_CYCL";
    /** DB프로퍼티키(LOGIN_PW_ERR_CNT : 암호실패최대건수) */
    public static final String DBPROP_KEY_PWD_ERROR_MAX_CO = "LOGIN_PW_ERR_CNT";
    /** 
     * DB PROPERTY[USER_ID_SEQ:사용자ID자동생성 조직구분코드 표현식]
     * ※ 조직구분코드를 "|" 구분자로 정의 
     */
    public static final String DBPROP_KEY_USER_ID_SEQ = "USER_ID_SEQ";
    
    /** 초기비빌번호 prefix */
    public static final String INITIAL_PW_PREFIX = "a#";
    
    /**PDA  초기비빌번호 */
    public static final String INITIAL_PW_PDA = "MAPS2020";

    /** 용어약어사용코드(00 : 오리지널) */
    public static final String ABBREV_WORD_USE_CD_ORIGINAL = "00";
    /** 용어약어사용코드(01 : 약어1) */
    public static final String ABBREV_WORD_USE_CD_01 = "01";
    /** 용어약어사용코드(02 : 약어2) */
    public static final String ABBREV_WORD_USE_CD_02 = "02";
    /** 용어약어사용코드(03 : 약어3) */
    public static final String ABBREV_WORD_USE_CD_03 = "03";
    /** 용어약어사용코드(04 : 약어4) */
    public static final String ABBREV_WORD_USE_CD_04 = "04";
    /** 용어약어사용코드(05 : 약어5) */
    public static final String ABBREV_WORD_USE_CD_05 = "05";
    
    /** 계정유형코드(S : IT운영자) */
    public static final String ACCOUNT_TYPE_CD_SYSTEM = "S";
    /** 계정유형코드(M : 마스터사용자) */
    public static final String ACCOUNT_TYPE_CD_MASTER = "M";
    /** 계정유형코드(N : 일반사용자) */
    public static final String ACCOUNT_TYPE_CD_NOMAL = "N";
    
    /** 메뉴유형코드(M : 메뉴) */
    public static final String MENU_TYPE_CD_MENU = "M";
    /** 메뉴유형코드(S : 화면) */
    public static final String MENU_TYPE_CD_SCREEN = "S";
    /** 메뉴유형코드(U : URL) */
    public static final String MENU_TYPE_CD_URL = "U";

    /** 조직구분코드(M : 모비스본사) */
    public static final String ORGNZT_SE_CD_MOBIS = "M";
    /** 조직구분코드(C : 모비스법인) */
    public static final String ORGNZT_SE_CD_CORPORATION = "C";
    /** 조직구분코드(G : 일반대리점) */
    public static final String ORGNZT_SE_CD_GENERAL_DISTRIBUTOR = "G";
    /** 조직구분코드(D : 직배대리점) */
    public static final String ORGNZT_SE_CD_DIRECT_DISTRIBUTOR = "D";
    /** 조직구분코드(E : 직배딜러) */
    public static final String ORGNZT_SE_CD_DIRECT_DEALER = "E";
    /** 조직구분코드(N : 국내외협력업체) */
    public static final String ORGNZT_SE_CD_VENDOR = "N";
    /** 조직구분코드(P : PDA) */
    public static final String ORGNZT_SE_CD_PDA = "P";

    /** nMGN고객그룹(13 : [HQ]수출_모비스) */
    public static final String NMGN_KDGRP_XPORT_MOBIS = "13";
    /** nMGN고객그룹(14 : [HQ]수출_대리점) */
    public static final String NMGN_KDGRP_XPORT_DIST = "14";
    /** nMGN고객그룹(15 : [HQ]수출_로컬대리점) */
    public static final String NMGN_KDGRP_XPORT_LOCAL = "15";

    /** 초기화암호변경일수 (1일) */
    public static final int INIT_PWD_CHAGE_DAY_CNT = 1;
    /** 암호변경주기일수 (90일) */
    public static final int PWD_CHAGE_CYCL_DAY_CNT = 90;
    
    /** 암호변경구분코드 (00 : 신규) */
    public static final String PWD_CHAGE_SE_CD_NEW = "00";
    /** 암호변경구분코드 (01 : 암호초기화) */
    public static final String PWD_CHAGE_SE_CD_INIT = "01";
    /** 암호변경구분코드 (02 : 사용자) */
    public static final String PWD_CHAGE_SE_CD_USER = "02";
    /** 암호변경구분코드 (03 : 암호만료) */
    public static final String PWD_CHAGE_SE_CD_END = "03";
    /** 암호변경구분코드 (04 : 암호변경횟수초과) */
    public static final String PWD_CHAGE_SE_CD_ERROR = "04";
    /** 암호변경구분코드 (05 : 관리자암호초기화) */
    public static final String PWD_CHAGE_SE_CD_MANAGER_INIT = "05";
    /** 암호변경구분코드 (06 : 계정잠김해제) */
    public static final String PWD_CHAGE_SE_CD_UNLOCK = "06";
    /** 암호변경구분코드 (07 : 비밀번호찾기) */
    public static final String PWD_CHAGE_SE_CD_FIND = "07";

    /** 계정잠김구분코드[100:비밀번호오류횟수초과] */
    public static final String ACNT_LOCK_RESN_CD_PASSWORD_OVER_COUNT = "100";
    /** 계정잠김구분코드[101:비밀번호만료] */
    public static final String ACNT_LOCK_RESN_CD_END_PASSWORD = "101";
    /** 계정잠김구분코드[200:장기미사용자] */
    public static final String ACNT_LOCK_RESN_CD_NOT_USED_LONG = "200";
    /** 계정잠김구분코드[300:퇴사] */
    public static final String ACNT_LOCK_RESN_RETIREMENT = "300";
    /** 계정잠김구분코드[999:기타] */
    public static final String ACNT_LOCK_RESN_CD_ETC = "999";

    /** 계정상태코드[9:사용중] */
    public static final String ACNT_STTUS_CD_USING = "1";
    /** 계정상태코드[2:미사용기간] */
    public static final String ACNT_STTUS_CD_UNUSED_PERIOD = "2";
    /** 계정상태코드[3:암호만료] */
    public static final String ACNT_STTUS_CD_END_PASSWORD = "3";
    /** 계정상태코드[4:계정잠김] */
    public static final String ACNT_STTUS_CD_LOCK = "4";
    /** 계정상태코드[5:사용종료] */
    public static final String ACNT_STTUS_CD_END_USED= "5";
    /** 계정상태코드[6:미사용] */
    public static final String ACNT_STTUS_CD_UNUSED = "6";
    /** 계정상태코드[7:삭제] */
    public static final String ACNT_STTUS_CD_DELETED = "7";
    /** 계정상태코드[9:퇴사] */
    public static final String ACNT_STTUS_CD_RETIREMENT = "9";
}
