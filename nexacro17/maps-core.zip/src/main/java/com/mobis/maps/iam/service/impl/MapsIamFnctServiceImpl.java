package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamFnctService;
import com.mobis.maps.iam.service.dao.MapsIamFnctMDAO;
import com.mobis.maps.iam.util.MapsIamValidatorUtil;
import com.mobis.maps.iam.vo.MapsIamFnctEstnUrlVO;
import com.mobis.maps.iam.vo.MapsIamFnctVO;
import com.mobis.maps.iam.vo.MapsIamScreenVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * Function관리 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamFnctServiceImpl.java
 * @Description : Function관리 서비스를 구현 정의.
 * @author DT048657
 * @since 2019. 9. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 16.     DT048657     	최초 생성
 * </pre>
 */
@Service("mapsIamFnctService")
public class MapsIamFnctServiceImpl extends HService implements MapsIamFnctService {
    
    @Resource(name="mapsIamFnctMDAO")
    private MapsIamFnctMDAO mapsIamFnctMDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamFnctService#selectFnctPgList(com.mobis.maps.iam.vo.MapsIamFnctVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamFnctVO> selectFnctPgList(MapsIamFnctVO iamFnctVO, LoginInfoVO loginInfo) throws Exception {

        iamFnctVO.setDfltLangCd(MapsConstants.DFLT_LOCALE.toString());
        iamFnctVO.setLangCd(loginInfo.getLangCd());
        
        List<MapsIamFnctVO> FnctInfos = mapsIamFnctMDAO.selectFnctPgList(iamFnctVO);
        
        return FnctInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamFnctService#multiFnctInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiFnctInfo(List<MapsIamFnctVO> fnctInfos, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        for (MapsIamFnctVO iamFnctVO: fnctInfos) {
            
            int rowType = iamFnctVO.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            // 시스템은 필수 항목입니다.
            MapsIamValidatorUtil.validateRequired(iamFnctVO.getSysSeCd(), "W0000000070", loginInfo.getUserLcale());
            // 기능구분은 필수 항목입니다.
            MapsIamValidatorUtil.validateRequired(iamFnctVO.getFnctSeCd(), "WI000000059", loginInfo.getUserLcale());
            // 기능명은 필수 항목입니다.
            MapsIamValidatorUtil.validateRequired(iamFnctVO.getFnctNm(), "W0000000100", loginInfo.getUserLcale());
            // 기능URL은 필수 항목입니다.
            MapsIamValidatorUtil.validateRequired(iamFnctVO.getFnctUrl(), "W0000000101", loginInfo.getUserLcale());
            // 컴포넌트ID는 필수 항목입니다.
            MapsIamValidatorUtil.validateRequired(iamFnctVO.getCompnId(), "W0000000097", loginInfo.getUserLcale());
            // 사용여부는 필수 항목입니다.
            MapsIamValidatorUtil.validateRequired(iamFnctVO.getUseYn(), "W0000000041", loginInfo.getUserLcale());

            iamFnctVO.setRegistId(loginInfo.getUserSeqId());
            iamFnctVO.setUpdtId(loginInfo.getUserSeqId());
            
            MapsIamFnctVO resultIamFnct = null;
            MapsIamScreenVO iamPopupScrin = null;
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    if (FNCT_SE_CD_POPUP.equals(iamFnctVO.getFnctSeCd())) {
                        iamPopupScrin = mapsIamFnctMDAO.selectScrinInfo(iamFnctVO);
                        if (iamPopupScrin == null) {
                            throw new MapsBizException(messageSource, "EC00000011", new String[]{"Screen ID"}, null);
                        }
                        
                        if (!StringUtils.equals(iamPopupScrin.getScrinUrl(), iamFnctVO.getFnctUrl())) {
                            iamFnctVO.setFnctUrl(iamPopupScrin.getScrinUrl());
                        }
                        
                        resultIamFnct = mapsIamFnctMDAO.selectFnctInfoByScrinId(iamFnctVO);
                    } else {
                        resultIamFnct = mapsIamFnctMDAO.selectFnctInfoByFnctUrl(iamFnctVO);
                    }
                    if (resultIamFnct != null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Function Info"}, null);
                    }
                    mapsIamFnctMDAO.insertFnctInfo(iamFnctVO);
                    break;
                case DataSet.ROW_TYPE_UPDATED :
                    resultIamFnct = mapsIamFnctMDAO.selectFnctInfo(iamFnctVO);
                    if (resultIamFnct == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Function Info"}, null);
                    }
                    if (FNCT_SE_CD_POPUP.equals(iamFnctVO.getFnctSeCd())) {
                        iamPopupScrin = mapsIamFnctMDAO.selectScrinInfo(iamFnctVO);
                        if (iamPopupScrin == null) {
                            throw new MapsBizException(messageSource, "EC00000011", new String[]{"Screen ID"}, null);
                        }
                        
                        if (!StringUtils.equals(iamPopupScrin.getScrinUrl(), iamFnctVO.getFnctUrl())) {
                            iamFnctVO.setFnctUrl(iamPopupScrin.getScrinUrl());
                        }
                        if (mapsIamFnctMDAO.selectFnctInfoByScrinId(iamFnctVO) != null) {
                            throw new MapsBizException(messageSource, "EC00000011", new String[]{"Function Info"}, null);
                        }
                    } else {
                        if (!StringUtils.equals(resultIamFnct.getFnctUrl(), iamFnctVO.getFnctUrl())) {
                            if (mapsIamFnctMDAO.selectFnctInfoByFnctUrl(iamFnctVO) != null) {
                                throw new MapsBizException(messageSource, "EC00000011", new String[]{"Function Info"}, null);
                            }
                        }
                    }
                    mapsIamFnctMDAO.updateFnctInfo(iamFnctVO);                        
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    resultIamFnct = mapsIamFnctMDAO.selectFnctInfo(iamFnctVO);
                    if (resultIamFnct == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Function Info"}, null);
                    }
                    mapsIamFnctMDAO.deleteFnctInfo(iamFnctVO);
                    break;
                default :
                    continue;
                    
            }
            procCnt++;
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamFnctService#multiScreenFnctInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiScreenFnctInfo(List<MapsIamFnctVO> fnctInfos, LoginInfoVO loginInfo) throws Exception {
        int procCnt = 0;

        for (MapsIamFnctVO iamScrinFnctVO : fnctInfos) {

            int rowType = iamScrinFnctVO.getRowType();

            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            iamScrinFnctVO.setRegistId(loginInfo.getUserSeqId());
            iamScrinFnctVO.setUpdtId(loginInfo.getUserSeqId());

            MapsIamFnctVO resultIamFnct = null;
            switch (rowType) {
                case DataSet.ROW_TYPE_INSERTED:
                    mapsIamFnctMDAO.insertFnctInfo(iamScrinFnctVO);
                    break;
                case DataSet.ROW_TYPE_UPDATED:
                    mapsIamFnctMDAO.updateFnctInfo(iamScrinFnctVO);
                    break;
                case DataSet.ROW_TYPE_DELETED:
                    resultIamFnct = mapsIamFnctMDAO.selectFnctInfo(iamScrinFnctVO);
                    if (resultIamFnct == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[] { "Screen Function Info" }, null);
                    }
                    mapsIamFnctMDAO.deleteFnctInfo(iamScrinFnctVO);
                    break;
                default:
                    continue;

            }
            procCnt++;
        }
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamFnctService#selectFnctEstnUrlList(com.mobis.maps.iam.vo.MapsIamFnctEstnUrlVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamFnctEstnUrlVO> selectFnctEstnUrlList(MapsIamFnctEstnUrlVO iamFnctEstnUrlVO
            , LoginInfoVO loginInfo) throws Exception {
        
        List<MapsIamFnctEstnUrlVO> fnctEstnUrls = mapsIamFnctMDAO.selectFnctEstnUrlList(iamFnctEstnUrlVO);
        
        return fnctEstnUrls;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamFnctService#multiFnctEstnUrl(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiFnctEstnUrl(List<MapsIamFnctEstnUrlVO> fnctEstnUrls, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        for (MapsIamFnctEstnUrlVO iamFnctEstnUrlVO: fnctEstnUrls) {
            
            int rowType = iamFnctEstnUrlVO.getRowType();
            
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            iamFnctEstnUrlVO.setRegistId(loginInfo.getUserSeqId());
            
            MapsIamFnctEstnUrlVO resultIamFnctEstnUrl = null;
            switch(rowType) {
                case DataSet.ROW_TYPE_INSERTED :
                    resultIamFnctEstnUrl = mapsIamFnctMDAO.selectFnctEstnUrl(iamFnctEstnUrlVO);
                    if (resultIamFnctEstnUrl != null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Function URL Info"}, null);
                    }
                    mapsIamFnctMDAO.insertFnctEstnUrl(iamFnctEstnUrlVO);
                    break;
                case DataSet.ROW_TYPE_DELETED :
                    resultIamFnctEstnUrl = mapsIamFnctMDAO.selectFnctEstnUrl(iamFnctEstnUrlVO);
                    if (resultIamFnctEstnUrl == null) {
                        throw new MapsBizException(messageSource, "EC00000011", new String[]{"Function URL Info"}, null);
                    }
                    mapsIamFnctMDAO.deleteFnctEstnUrl(iamFnctEstnUrlVO);
                    break;
                default :
                    continue;
                    
            }
            procCnt++;
        }
        
        return procCnt;
    }

}
