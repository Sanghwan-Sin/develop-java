package com.mobis.maps.comm.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.SapCodeVO;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.comm.service.MapsCommCodeService;
import com.mobis.maps.comm.vo.MapsCommCodeGroupVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;

/**
 * <pre>
 * 공통코드 관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommCodeController.java
 * @Description : 공통코드 관리에 대한 컨트롤러 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 27.   Sin Sanghwan     최초 생성
 * </pre>
 */
@Controller
public class MapsCommCodeController extends HController {

    @Resource(name = "mapsCommCodeService")
    private MapsCommCodeService mapsCommCodeService;
    
    /**
     * 공통코드 전체리스트 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectCommCodeAllPgList.do")
    public NexacroResult selectCommCodeAllPgList(
            @ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommCodeVO> commCodes = mapsCommCodeService.selectCommCodeAllPgList(commCodeVO, loginInfo);
        
        result.addDataSet("dsOutput", commCodes);
        
        return result;
    }
    
    /**
     * 공통코드그룹 리스트 조회
     *
     * @param commCodeGroupVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectCommCodeGroupPgList.do")
    public NexacroResult selectCommCodeGroupPgList(
            @ParamDataSet(name="dsInput") MapsCommCodeGroupVO commCodeGroupVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommCodeGroupVO> commCodeGroups = mapsCommCodeService.selectCommCodeGroupPgList(commCodeGroupVO, loginInfo);
        
        result.addDataSet("dsOutput", commCodeGroups);
        
        return result;
    }
    
    /**
     * 공통코드그룹 조회
     *
     * @param commCodeGroupVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectCommCodeGroup.do")
    public NexacroResult selectCommCodeGroup(
            @ParamDataSet(name="dsInput") MapsCommCodeGroupVO commCodeGroupVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        MapsCommCodeGroupVO commCodeGroup = mapsCommCodeService.selectCommCodeGroup(commCodeGroupVO, loginInfo);
        
        result.addDataSet("dsOutput", commCodeGroup);
        
        return result;
    }

    /**
     * 공통코드그룹 등록
     *
     * @param msgInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/insertCommCodeGroup.do")
    public NexacroResult insertCommCodeGroup(
            @ParamDataSet(name="dsInput") MapsCommCodeGroupVO commCodeGroupVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsCommCodeService.insertCommCodeGroup(commCodeGroupVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 공통코드그룹 수정
     *
     * @param commCodeGroupVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/updateCommCodeGroup.do")
    public NexacroResult updateCommCodeGroup(
            @ParamDataSet(name="dsInput") MapsCommCodeGroupVO commCodeGroupVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsCommCodeService.updateCommCodeGroup(commCodeGroupVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * 공통코드그룹 삭제
     *
     * @param commCodeGroupVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/deleteCommCodeGroup.do")
    public NexacroResult deleteCommCodeGroup(
            @ParamDataSet(name="dsInput") MapsCommCodeGroupVO commCodeGroupVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsCommCodeService.deleteCommCodeGroup(commCodeGroupVO, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 공통코드 리스트 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/selectCommCodePgList.do")
    public NexacroResult selectCommCodePgList(
            @ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsCommCodeVO> commCodes = mapsCommCodeService.selectCommCodePgList(commCodeVO, loginInfo);
        
        result.addDataSet("dsOutput", commCodes);
        
        return result;
    }

    /**
     * 공통코드 저장
     *
     * @param msgInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/multiCommCode.do")
    public NexacroResult multiCommCode(
            @ParamDataSet(name="dsInput") List<MapsCommCodeVO> commCodes
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsCommCodeService.multiCommCode(commCodes, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * 코드 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/code/selectCodeList.do")
    public NexacroResult selectCodeList(
            HttpServletRequest request,
            @ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {
        
        String jsessionID = request.getRequestedSessionId();
        logger.info("***************************************************************");
        logger.info("BEFORE selectCodeList : " + jsessionID);
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        jsessionID = request.getRequestedSessionId();
        logger.info("AFTER  selectCodeList : " + jsessionID);
        logger.info("***************************************************************");
        
        
        List<CodeVO> codes = mapsCommCodeService.selectCodeList(commCodeVO, loginInfo);
        
        result.addDataSet("dsOutput", codes);
        
        return result;
    }

    /**
     * 하위 코드 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/code/selectLwprtCodeList.do")
    public NexacroResult selectLwprtCodeList(
            HttpServletRequest request,
            @ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {
        
        String jsessionID = request.getRequestedSessionId();
        logger.info("***************************************************************");
        logger.info("BEFORE selectLwprtCodeList : " + jsessionID);
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        jsessionID = request.getRequestedSessionId();
        logger.info("AFTER  selectLwprtCodeList : " + jsessionID);
        logger.info("***************************************************************");
        
        List<CodeVO> codes = mapsCommCodeService.selectLwprtCodeList(commCodeVO, loginInfo);
        
        result.addDataSet("dsOutput", codes);
        
        return result;
    }

    /**
     * 코드명 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/code/selectCodeNm.do")
    public NexacroResult selectCodeNm(
            HttpServletRequest request,
            @ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {
        
        String jsessionID = request.getRequestedSessionId();
        logger.info("***************************************************************");
        logger.info("BEFORE selectCodeNm : " + jsessionID);
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        jsessionID = request.getRequestedSessionId();
        logger.info("AFTER  selectCodeNm : " + jsessionID);
        logger.info("***************************************************************");
        
        CodeVO code = mapsCommCodeService.selectCodeNm(commCodeVO, loginInfo);
        
        result.addDataSet("dsOutput", code);
        
        return result;
    }
    
    /**
     * SAP코드 리스트 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/code/selectSapCodeList.do")
    public NexacroResult selectSapCodeList(
            HttpServletRequest request,
            @ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {
        
        String jsessionID = request.getRequestedSessionId();
        
        logger.info("***************************************************************");
        logger.info("BEFORE selectSapCodeList : " + jsessionID);
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        jsessionID = request.getRequestedSessionId();
        logger.info("AFTER  selectSapCodeList : " + jsessionID);
        logger.info("***************************************************************");
        
        
        List<SapCodeVO> codes = mapsCommCodeService.selectSapCodeList(commCodeVO, loginInfo);
        
        result.addDataSet("dsOutput", codes);
        
        return result;
    }
    
    /**
     * SAP코드명 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/code/selectSapCodeNm.do")
    public NexacroResult selecSapCodeNm(
            HttpServletRequest request,
            @ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {
        
        String jsessionID = request.getRequestedSessionId();
        logger.info("***************************************************************");
        logger.info("BEFORE selecSapCodeNm : " + jsessionID);
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        jsessionID = request.getRequestedSessionId();
        logger.info("AFTER  selecSapCodeNm : " + jsessionID);
        logger.info("***************************************************************");
        
        SapCodeVO code = mapsCommCodeService.selectSapCodeNm(commCodeVO, loginInfo);
        
        result.addDataSet("dsOutput", code);
        
        return result;
    }
    
    /**
     * Domain코드 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/code/selectDomnCodeList.do")
    public NexacroResult selectDomnCodeList(
            HttpServletRequest request,
            @ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {
        
        String jsessionID = request.getRequestedSessionId();
        logger.info("***************************************************************");
        logger.info("BEFORE selectDomnCodeList : " + jsessionID);
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        jsessionID = request.getRequestedSessionId();
        logger.info("AFTER  selectDomnCodeList : " + jsessionID);
        logger.info("***************************************************************");
        
        List<CodeVO> codes = mapsCommCodeService.selectDomnCodeList(commCodeVO, loginInfo);
        
        result.addDataSet("dsOutput", codes);
        
        return result;
    }

    /**
     * Domain코드명 조회
     *
     * @param commCodeVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/code/selectDomnCodeNm.do")
    public NexacroResult selectDomnCodeNm(
            HttpServletRequest request,
            @ParamDataSet(name="dsInput") MapsCommCodeVO commCodeVO
            , NexacroResult result) throws Exception {
        
        String jsessionID = request.getRequestedSessionId();
        logger.info("***************************************************************");
        logger.info("BEFORE selectDomnCodeNm : " + jsessionID);
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        jsessionID = request.getRequestedSessionId();
        logger.info("AFTER  selectDomnCodeNm : " + jsessionID);
        logger.info("***************************************************************");
        
        CodeVO code = mapsCommCodeService.selectDomnCodeNm(commCodeVO, loginInfo);
        
        result.addDataSet("dsOutput", code);
        
        return result;
    }

    /**
     * RFC 정보 화면초기화 정보
     *
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/code/selectSapRfcInit.do")
    public NexacroResult selectSapRfcInit(NexacroResult result) throws Exception {

        result.addDataSet("dsOutputSysId", RfcSapSys.getCodeList());
        
        return result;
    }
}
