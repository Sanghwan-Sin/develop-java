package com.mobis.maps.comm.vo;

/**
 * <pre>
 * 다국어 항목
 * </pre>
 *
 * @ClassName   : MapsCommLanguageVO.java
 * @Description : 다국어 항목을 정의
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
public class MapsCommLanguageVO {

    /** 디폴트언어코드 */
    private String dfltLangCd;
    /** 언어코드 */
    private String langCd;
    /** 화면ID */
    private String scrinId;
    /** 콤포넌트ID */
    private String compnId;
    /** 콤포넌트 명 */
    private String compnNm;
    /** 용어ID */
    private String wordId;
    /** 단축용어사용코드 */
    private String abbrevWordUseCd;
    /** 디폴트원본용어 */
    private String dfltOrginlWord;
    /** 디폴트단축용어1 */
    private String dfltAbbrevWord1;
    /** 디폴트단축용어2 */
    private String dfltAbbrevWord2;
    /** 디폴트단축용어3 */
    private String dfltAbbrevWord3;
    /** 디폴트단축용어4 */
    private String dfltAbbrevWord4;
    /** 디폴트단축용어5 */
    private String dfltAbbrevWord5;
    /** 원본용어 */
    private String orginlWord;
    /** 단축용어1 */
    private String abbrevWord1;
    /** 단축용어2 */
    private String abbrevWord2;
    /** 단축용어3 */
    private String abbrevWord3;
    /** 단축용어4 */
    private String abbrevWord4;
    /** 단축용어5 */
    private String abbrevWord5;
    /**
     * @return the dfltLangCd
     */
    public String getDfltLangCd() {
        return dfltLangCd;
    }
    /**
     * @param dfltLangCd the dfltLangCd to set
     */
    public void setDfltLangCd(String dfltLangCd) {
        this.dfltLangCd = dfltLangCd;
    }
    /**
     * @return the langCd
     */
    public String getLangCd() {
        return langCd;
    }
    /**
     * @param langCd the langCd to set
     */
    public void setLangCd(String langCd) {
        this.langCd = langCd;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the compnId
     */
    public String getCompnId() {
        return compnId;
    }
    /**
     * @param compnId the compnId to set
     */
    public void setCompnId(String compnId) {
        this.compnId = compnId;
    }
    /**
     * @return the compnNm
     */
    public String getCompnNm() {
        return compnNm;
    }
    /**
     * @param compnNm the compnNm to set
     */
    public void setCompnNm(String compnNm) {
        this.compnNm = compnNm;
    }
    /**
     * @return the wordId
     */
    public String getWordId() {
        return wordId;
    }
    /**
     * @param wordId the wordId to set
     */
    public void setWordId(String wordId) {
        this.wordId = wordId;
    }
    /**
     * @return the abbrevWordUseCd
     */
    public String getAbbrevWordUseCd() {
        return abbrevWordUseCd;
    }
    /**
     * @param abbrevWordUseCd the abbrevWordUseCd to set
     */
    public void setAbbrevWordUseCd(String abbrevWordUseCd) {
        this.abbrevWordUseCd = abbrevWordUseCd;
    }
    /**
     * @return the dfltOrginlWord
     */
    public String getDfltOrginlWord() {
        return dfltOrginlWord;
    }
    /**
     * @param dfltOrginlWord the dfltOrginlWord to set
     */
    public void setDfltOrginlWord(String dfltOrginlWord) {
        this.dfltOrginlWord = dfltOrginlWord;
    }
    /**
     * @return the dfltAbbrevWord1
     */
    public String getDfltAbbrevWord1() {
        return dfltAbbrevWord1;
    }
    /**
     * @param dfltAbbrevWord1 the dfltAbbrevWord1 to set
     */
    public void setDfltAbbrevWord1(String dfltAbbrevWord1) {
        this.dfltAbbrevWord1 = dfltAbbrevWord1;
    }
    /**
     * @return the dfltAbbrevWord2
     */
    public String getDfltAbbrevWord2() {
        return dfltAbbrevWord2;
    }
    /**
     * @param dfltAbbrevWord2 the dfltAbbrevWord2 to set
     */
    public void setDfltAbbrevWord2(String dfltAbbrevWord2) {
        this.dfltAbbrevWord2 = dfltAbbrevWord2;
    }
    /**
     * @return the dfltAbbrevWord3
     */
    public String getDfltAbbrevWord3() {
        return dfltAbbrevWord3;
    }
    /**
     * @param dfltAbbrevWord3 the dfltAbbrevWord3 to set
     */
    public void setDfltAbbrevWord3(String dfltAbbrevWord3) {
        this.dfltAbbrevWord3 = dfltAbbrevWord3;
    }
    /**
     * @return the dfltAbbrevWord4
     */
    public String getDfltAbbrevWord4() {
        return dfltAbbrevWord4;
    }
    /**
     * @param dfltAbbrevWord4 the dfltAbbrevWord4 to set
     */
    public void setDfltAbbrevWord4(String dfltAbbrevWord4) {
        this.dfltAbbrevWord4 = dfltAbbrevWord4;
    }
    /**
     * @return the dfltAbbrevWord5
     */
    public String getDfltAbbrevWord5() {
        return dfltAbbrevWord5;
    }
    /**
     * @param dfltAbbrevWord5 the dfltAbbrevWord5 to set
     */
    public void setDfltAbbrevWord5(String dfltAbbrevWord5) {
        this.dfltAbbrevWord5 = dfltAbbrevWord5;
    }
    /**
     * @return the orginlWord
     */
    public String getOrginlWord() {
        return orginlWord;
    }
    /**
     * @param orginlWord the orginlWord to set
     */
    public void setOrginlWord(String orginlWord) {
        this.orginlWord = orginlWord;
    }
    /**
     * @return the abbrevWord1
     */
    public String getAbbrevWord1() {
        return abbrevWord1;
    }
    /**
     * @param abbrevWord1 the abbrevWord1 to set
     */
    public void setAbbrevWord1(String abbrevWord1) {
        this.abbrevWord1 = abbrevWord1;
    }
    /**
     * @return the abbrevWord2
     */
    public String getAbbrevWord2() {
        return abbrevWord2;
    }
    /**
     * @param abbrevWord2 the abbrevWord2 to set
     */
    public void setAbbrevWord2(String abbrevWord2) {
        this.abbrevWord2 = abbrevWord2;
    }
    /**
     * @return the abbrevWord3
     */
    public String getAbbrevWord3() {
        return abbrevWord3;
    }
    /**
     * @param abbrevWord3 the abbrevWord3 to set
     */
    public void setAbbrevWord3(String abbrevWord3) {
        this.abbrevWord3 = abbrevWord3;
    }
    /**
     * @return the abbrevWord4
     */
    public String getAbbrevWord4() {
        return abbrevWord4;
    }
    /**
     * @param abbrevWord4 the abbrevWord4 to set
     */
    public void setAbbrevWord4(String abbrevWord4) {
        this.abbrevWord4 = abbrevWord4;
    }
    /**
     * @return the abbrevWord5
     */
    public String getAbbrevWord5() {
        return abbrevWord5;
    }
    /**
     * @param abbrevWord5 the abbrevWord5 to set
     */
    public void setAbbrevWord5(String abbrevWord5) {
        this.abbrevWord5 = abbrevWord5;
    }
    
}
