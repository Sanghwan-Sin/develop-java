package com.mobis.maps.iam.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamAuthorExcelUpldVO;
import com.mobis.maps.iam.vo.MapsIamAuthorMenuScnFnctVO;
import com.mobis.maps.iam.vo.MapsIamAuthorMenuVO;
import com.mobis.maps.iam.vo.MapsIamAuthorSetupVO;
import com.mobis.maps.iam.vo.MapsIamAuthorUserVO;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsIamAuthorService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 최은삼
 * @since 2019. 12. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 13.     최은삼     	최초 생성
 * </pre>
 */

public interface MapsIamAuthorService {

    /** 권한여부(0 : 권한없음) */
    public static final String AUTHOR_FlAG_NO = "0";
    /** 권한여부(0 : 권한있음) */
    public static final String AUTHOR_FlAG_YES = "1";

    /** 권한설정구분코드(M : 메뉴) */
    public static final String AUTHOR_SETUP_SE_CD_MENU = "M";
    /** 권한설정구분코드(S : 화면) */
    public static final String AUTHOR_SETUP_SE_CD_SCREEN = "S";
    /** 권한설정구분코드(F : 기능) */
    public static final String AUTHOR_SETUP_SE_CD_FUNCTION = "F";
    /** 권한설정구분코드(U : 사용자) */
    public static final String AUTHOR_SETUP_SE_CD_USER = "U";
    
    /**
     * 권한 리스트 조회
     *
     * @param iamAuthorVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectAuthorList(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 권한 페이징리스트 조회
     *
     * @param iamAuthorVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectAuthorPgList(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 권한 조회
     *
     * @param iamAuthorVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public MapsIamAuthorVO selectAuthorInfo(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 권한 저장
     *
     * @param authorInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiAuthorInfo(List<MapsIamAuthorVO> authorInfos, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 권한정보 파일업로드 저장
     * Statements
     *
     * @param request
     * @param response
     * @param iamAuthorExcelUpldVO
     * @param loginInfo
     * @throws Exception
     */
    public void multiAuthorInfoFiileUpload(HttpServletRequest request, HttpServletResponse response, MapsIamAuthorExcelUpldVO iamAuthorExcelUpldVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 권한 변경이력 페이징리스트 조회
     *
     * @param iamAuthorVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorVO> selectAuthorChghstPgList(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 권한별 메뉴 리스트 조회
     *
     * @param imAuthorMenuVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorMenuVO> selectAuthorMenuScrinList(MapsIamAuthorMenuVO imAuthorMenuVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 권한별 메뉴 저장
     *
     * @param iamAuthorMenuInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiAuthorMenuInfo(List<MapsIamAuthorMenuVO> iamAuthorMenuInfos, LoginInfoVO loginInfo) throws Exception;

    /**
     * 권한별 메뉴 화면 기능 리스트 조회
     *
     * @param iamAuthorVO
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorMenuScnFnctVO> selectAuthorScrinFnctList(MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO) throws Exception;

    /**
     * 권한별 화면기능 저장
     *
     * @param iamAuthorScrinFnctInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiAuthorScrinFnctInfo(List<MapsIamAuthorMenuScnFnctVO> iamAuthorScrinFnctInfos, LoginInfoVO loginInfo) throws Exception;

    /**
     * 권한설정 변경이력 페이징리스트 조회
     *
     * @param iamAuthorSetupVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorSetupVO> selectAuthorSetupChghstPgList(MapsIamAuthorSetupVO iamAuthorSetupVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 권한별 사용자 리스트 조회
     *
     * @param iamAuthorUserVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamAuthorUserVO> selectAuthorUserPgList(MapsIamAuthorUserVO iamAuthorUserVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 권한별 사용자 저장
     *
     * @param iamAuthorUserInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiAuthorUserInfo(List<MapsIamAuthorUserVO> iamAuthorUserInfos, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 권한 가져오기
     *
     * @param iamAuthorVO
     * @param loginInfo
     * @throws Exception
     */
    public int insertImportAuthorInfo(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception;

}
