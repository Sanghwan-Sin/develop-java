package com.mobis.maps.sapjco.manager;

import java.util.List;

import com.mobis.maps.cmmn.exception.MapsRuntimeException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.ext.Environment;
import com.sap.conn.jco.monitor.JCoConnectionData;
import com.sap.conn.jco.monitor.JCoDestinationMonitor;

/**
 * @Classname Destination
 * @Description Destination, Monitoring, Function, FuntionTemaplate 제공
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * 
 * @Modification Information
 * since            author      description
 * =============    ========    ==================================================
 * 2019. 05. 18.    DT045877    최초 생성
 */
public class Destination {
    
    private JCoDestination jcoDestination;

    /**
     * Constructor
     *
     * @param destinationProvider
     * @param dest
     * @throws JCoException
     */
    public Destination(String dest) throws JCoException {
        jcoDestination = JCoDestinationManager.getDestination(dest);
    }

    /**
     * Constructor
     *
     * @param destinationProvider
     * @param dest
     * @throws JCoException
     */
    public Destination(DestinationProvider destinationProvider, String dest) throws JCoException {
        Environment.registerDestinationDataProvider(destinationProvider);
        jcoDestination = JCoDestinationManager.getDestination(dest);
    }
    
    /**
     * Destinatin 정보 반환
     *
     * @return
     */
    public JCoDestinationMonitor getMonitor() {
        return jcoDestination.getMonitor();
    }
    
    /**
     * Connection 상태 반환
     *
     * @return
     */
    public List<? extends JCoConnectionData> getConnectionInfo() {
        return jcoDestination.getMonitor().getConnectionsData();
    }
    
    /**
     * Funcion 객체 반환
     * @param rfcName
     * @return 
     * @throws JCoException
     */
    public Function getFunction(String rfcName) throws JCoException {
        JCoFunction jcoFunction = jcoDestination.getRepository().getFunction(rfcName);
        if (jcoFunction == null) {
            throw new MapsRuntimeException("Function '" + rfcName + "' not found");
        }
        return new Function(jcoDestination, jcoFunction);
    }
    
    /**
     * FunctionTemplate 객체 반환
     * @param rfcName
     * @return
     * @throws JCoException
     */
    public FunctionTemplate getFunctionTemplate(String rfcName) throws JCoException {
        JCoFunctionTemplate jcoFunctionTemplate = jcoDestination.getRepository().getFunctionTemplate(rfcName);
        if (jcoFunctionTemplate == null) {
            throw new MapsRuntimeException("FunctionTemplate '" + rfcName + "' not found");
        }
        return new FunctionTemplate(jcoDestination, jcoFunctionTemplate);
    }
    
    /**
     * Statements
     *
     * @return
     * @throws Exception
     */
    public String getClient() throws Exception {
        return jcoDestination.getClient();
    }
}