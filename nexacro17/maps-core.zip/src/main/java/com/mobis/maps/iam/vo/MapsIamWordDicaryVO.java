package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 용어사전 항목
 * </pre>
 *
 * @ClassName   : MapsCommWordDicaryVO.java
 * @Description : 용어사전 항목을 정의
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
public class MapsIamWordDicaryVO extends MapsIamCommVO {
    
    /* 조회조건 */
    /** 키워드타입 */
    private String kwrdTy;
    /** 키워드 */
    private String kwrd;  
    /* 데이터항목 */
    /** 사전ID */
    private String dicaryId;
    /** 용어ID */
    private String wordId;    
    /** 원본용어 */
    private String orginlWord;
    /** 단축용어1 */
    private String abbrevWord1;
    /** 단축용어2 */
    private String abbrevWord2;
    /** 단축용어3 */
    private String abbrevWord3;
    /** 단축용어4 */
    private String abbrevWord4;
    /** 단축용어5 */
    private String abbrevWord5;
    /** 용어설명 */
    private String wordDc;
    /** 사용여부 */
    private String useYn;
    /** 참조언어코드 */
    private String refrnDicaryId; 
    /** 참조언어코드 */
    private String refrnLangCd;    
    /** 참조원본용어 */
    private String refrnOrginlWord;
    /** 참조단축용어1 */
    private String refrnAbbrevWord1;
    /** 참조단축용어2 */
    private String refrnAbbrevWord2;
    /** 참조단축용어3 */
    private String refrnAbbrevWord3;
    /** 참조단축용어4 */
    private String refrnAbbrevWord4;
    /** 참조단축용어5 */
    private String refrnAbbrevWord5;    
    /** 참조용어설명 */
    private String refrnWordDc;
    /** 참조사용여부 */
    private String refrnUseYn;
    
    /**
     * @return the kwrdTy
     */
    public String getKwrdTy() {
        return kwrdTy;
    }
    /**
     * @param kwrdTy the kwrdTy to set
     */
    public void setKwrdTy(String kwrdTy) {
        this.kwrdTy = kwrdTy;
    }
    /**
     * @return the kwrd
     */
    public String getKwrd() {
        return kwrd;
    }
    /**
     * @param kwrd the kwrd to set
     */
    public void setKwrd(String kwrd) {
        this.kwrd = kwrd;
    }
    /**
     * @return the dicaryId
     */
    public String getDicaryId() {
        return dicaryId;
    }
    /**
     * @param dicaryId the dicaryId to set
     */
    public void setDicaryId(String dicaryId) {
        this.dicaryId = dicaryId;
    }
    /**
     * @return the wordId
     */
    public String getWordId() {
        return wordId;
    }
    /**
     * @param wordId the wordId to set
     */
    public void setWordId(String wordId) {
        this.wordId = wordId;
    }
    /**
     * @return the orginlWord
     */
    public String getOrginlWord() {
        return orginlWord;
    }
    /**
     * @param orginlWord the orginlWord to set
     */
    public void setOrginlWord(String orginlWord) {
        this.orginlWord = orginlWord;
    }
    /**
     * @return the abbrevWord1
     */
    public String getAbbrevWord1() {
        return abbrevWord1;
    }
    /**
     * @param abbrevWord1 the abbrevWord1 to set
     */
    public void setAbbrevWord1(String abbrevWord1) {
        this.abbrevWord1 = abbrevWord1;
    }
    /**
     * @return the abbrevWord2
     */
    public String getAbbrevWord2() {
        return abbrevWord2;
    }
    /**
     * @param abbrevWord2 the abbrevWord2 to set
     */
    public void setAbbrevWord2(String abbrevWord2) {
        this.abbrevWord2 = abbrevWord2;
    }
    /**
     * @return the abbrevWord3
     */
    public String getAbbrevWord3() {
        return abbrevWord3;
    }
    /**
     * @param abbrevWord3 the abbrevWord3 to set
     */
    public void setAbbrevWord3(String abbrevWord3) {
        this.abbrevWord3 = abbrevWord3;
    }
    /**
     * @return the abbrevWord4
     */
    public String getAbbrevWord4() {
        return abbrevWord4;
    }
    /**
     * @param abbrevWord4 the abbrevWord4 to set
     */
    public void setAbbrevWord4(String abbrevWord4) {
        this.abbrevWord4 = abbrevWord4;
    }
    /**
     * @return the abbrevWord5
     */
    public String getAbbrevWord5() {
        return abbrevWord5;
    }
    /**
     * @param abbrevWord5 the abbrevWord5 to set
     */
    public void setAbbrevWord5(String abbrevWord5) {
        this.abbrevWord5 = abbrevWord5;
    }
    /**
     * @return the wordDc
     */
    public String getWordDc() {
        return wordDc;
    }
    /**
     * @param wordDc the wordDc to set
     */
    public void setWordDc(String wordDc) {
        this.wordDc = wordDc;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    /**
     * @return the refrnDicaryId
     */
    public String getRefrnDicaryId() {
        return refrnDicaryId;
    }
    /**
     * @param refrnDicaryId the refrnDicaryId to set
     */
    public void setRefrnDicaryId(String refrnDicaryId) {
        this.refrnDicaryId = refrnDicaryId;
    }
    /**
     * @return the refrnLangCd
     */
    public String getRefrnLangCd() {
        return refrnLangCd;
    }
    /**
     * @param refrnLangCd the refrnLangCd to set
     */
    public void setRefrnLangCd(String refrnLangCd) {
        this.refrnLangCd = refrnLangCd;
    }
    /**
     * @return the refrnOrginlWord
     */
    public String getRefrnOrginlWord() {
        return refrnOrginlWord;
    }
    /**
     * @param refrnOrginlWord the refrnOrginlWord to set
     */
    public void setRefrnOrginlWord(String refrnOrginlWord) {
        this.refrnOrginlWord = refrnOrginlWord;
    }
    /**
     * @return the refrnAbbrevWord1
     */
    public String getRefrnAbbrevWord1() {
        return refrnAbbrevWord1;
    }
    /**
     * @param refrnAbbrevWord1 the refrnAbbrevWord1 to set
     */
    public void setRefrnAbbrevWord1(String refrnAbbrevWord1) {
        this.refrnAbbrevWord1 = refrnAbbrevWord1;
    }
    /**
     * @return the refrnAbbrevWord2
     */
    public String getRefrnAbbrevWord2() {
        return refrnAbbrevWord2;
    }
    /**
     * @param refrnAbbrevWord2 the refrnAbbrevWord2 to set
     */
    public void setRefrnAbbrevWord2(String refrnAbbrevWord2) {
        this.refrnAbbrevWord2 = refrnAbbrevWord2;
    }
    /**
     * @return the refrnAbbrevWord3
     */
    public String getRefrnAbbrevWord3() {
        return refrnAbbrevWord3;
    }
    /**
     * @param refrnAbbrevWord3 the refrnAbbrevWord3 to set
     */
    public void setRefrnAbbrevWord3(String refrnAbbrevWord3) {
        this.refrnAbbrevWord3 = refrnAbbrevWord3;
    }
    /**
     * @return the refrnAbbrevWord4
     */
    public String getRefrnAbbrevWord4() {
        return refrnAbbrevWord4;
    }
    /**
     * @param refrnAbbrevWord4 the refrnAbbrevWord4 to set
     */
    public void setRefrnAbbrevWord4(String refrnAbbrevWord4) {
        this.refrnAbbrevWord4 = refrnAbbrevWord4;
    }
    /**
     * @return the refrnAbbrevWord5
     */
    public String getRefrnAbbrevWord5() {
        return refrnAbbrevWord5;
    }
    /**
     * @param refrnAbbrevWord5 the refrnAbbrevWord5 to set
     */
    public void setRefrnAbbrevWord5(String refrnAbbrevWord5) {
        this.refrnAbbrevWord5 = refrnAbbrevWord5;
    }
    /**
     * @return the refrnWordDc
     */
    public String getRefrnWordDc() {
        return refrnWordDc;
    }
    /**
     * @param refrnWordDc the refrnWordDc to set
     */
    public void setRefrnWordDc(String refrnWordDc) {
        this.refrnWordDc = refrnWordDc;
    }
    /**
     * @return the refrnUseYn
     */
    public String getRefrnUseYn() {
        return refrnUseYn;
    }
    /**
     * @param refrnUseYn the refrnUseYn to set
     */
    public void setRefrnUseYn(String refrnUseYn) {
        this.refrnUseYn = refrnUseYn;
    }
    
}
