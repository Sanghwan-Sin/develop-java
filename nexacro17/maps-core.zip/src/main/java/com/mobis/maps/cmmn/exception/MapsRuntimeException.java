package com.mobis.maps.cmmn.exception;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsRuntimeException.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 3. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 4.     oh.dongwon     	최초 생성
 * </pre>
 */

public class MapsRuntimeException extends RuntimeException {

    /**
     * Statements
     * (long)serialVersionUID 
     */
    private static final long serialVersionUID = 1L;

   
    /**
     * Statements
     *
     * @param message
     */
    public MapsRuntimeException(String message) {
        super(message);
    }

    /**
     * Statements
     *
     * @param cause
     */
    public MapsRuntimeException(Throwable cause) {
        super(cause);
    }

    /**
     * Statements
     *
     * @param message
     * @param cause
     */
    public MapsRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Statements
     *
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public MapsRuntimeException(String message, Throwable cause, boolean enableSuppression,boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}
