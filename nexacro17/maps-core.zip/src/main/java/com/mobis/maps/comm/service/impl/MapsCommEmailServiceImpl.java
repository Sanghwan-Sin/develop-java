package com.mobis.maps.comm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.exception.BizException;
import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommEmailService;
import com.mobis.maps.comm.service.dao.MapsCommEmailMDAO;
import com.mobis.maps.comm.vo.EmailSndngVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommEmailServiceImpl.java
 * @Description : 이메일등록(전송)
 * @author hong.minho
 * @since 2020. 4. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 13.     hong.minho     	최초 생성
 * </pre>
 */

@Service("mapsCommEmailService")
public class MapsCommEmailServiceImpl extends HService implements MapsCommEmailService {
    
    @Resource(name="mapsCommEmailMDAO")
    MapsCommEmailMDAO dao;

    
    /*
     * @see com.mobis.maps.comm.service.MapsCommEmailService#multiSendEmail(com.mobis.maps.comm.vo.EmailSndngVO, java.util.List)
     */
    @Override
    public void multiSendEmail(EmailSndngVO emailVo, List<MapsAtchFileVO> fileVos) throws BizException, Exception {
        
        if (emailVo == null) {
            throw new MapsBizException(this.messageSource, "EC00000001", new String[]{"Parameter"}, MapsConstants.DFLT_LOCALE, null);
        }
        
        if (fileVos != null && fileVos.size() > 0) {
            emailVo.setAtchYn("Y");
        }
        
        
        // *** insert Email
        this.insertEmail(emailVo);
        
        if (emailVo.getEmailSn() == 0) {
            // 채번실패
            throw new MapsBizException(this.messageSource, "IC00000011", MapsConstants.DFLT_LOCALE, null); // Processing failed.
        }
        
        
        if (fileVos == null || fileVos.size() <= 0) { // 첨부파일 없으면 종료
            return;
        }
        
        
        // *** 첨부파일 처리 (n건)
        for(MapsAtchFileVO fileVo : fileVos) {
            if (fileVo == null) continue;
            
            if (StringUtils.isBlank(fileVo.getAtchSe())) {
                if (logger.isDebugEnabled()) {
                    logger.debug(MessageUtil.getMessage("EC00000001", new String[]{"Attach File[atchSe]"}, MapsConstants.DFLT_LOCALE));
                }
                
                continue;
            }
            
            if (StringUtils.isBlank(fileVo.getAtchId())) {
                if (logger.isDebugEnabled()) {
                    logger.debug(MessageUtil.getMessage("EC00000001", new String[]{"Attach File[atchId]"}, MapsConstants.DFLT_LOCALE));
                }
                
                continue;
            }
            
            // 첨부대상
            emailVo.setAtchSe(fileVo.getAtchSe());
            emailVo.setAtchId(fileVo.getAtchId());
            emailVo.setFileNo(fileVo.getFileNo());
            
            // 첨부등록
            dao.insertAttach(emailVo);
        }
        
    }


    
    /*
     * @see com.mobis.maps.comm.service.MapsCommEmailService#insertEmail(com.mobis.maps.comm.vo.EmailSndngVO)
     */
    @Override
    public int insertEmail(EmailSndngVO vo) throws BizException, Exception {
        if (vo == null) {
            throw new MapsBizException(this.messageSource, "EC00000001", new String[]{"Parameter"}, MapsConstants.DFLT_LOCALE, null);
        }
        
        if (StringUtils.isBlank(vo.getSndngProgrm())) {
            throw new MapsBizException(this.messageSource, "EC00000001", new String[]{"Parameter[sndngProgrm]"}, MapsConstants.DFLT_LOCALE, null);
        }
        if (StringUtils.isBlank(vo.getSndngEmail())) {
            throw new MapsBizException(this.messageSource, "EC00000001", new String[]{"Parameter[sndngEmail]"}, MapsConstants.DFLT_LOCALE, null);
        }
        if (StringUtils.isBlank(vo.getRecptnEmail())) {
            throw new MapsBizException(this.messageSource, "EC00000001", new String[]{"Parameter[recptnEmail]"}, MapsConstants.DFLT_LOCALE, null);
        }
        if (StringUtils.isBlank(vo.getEmailSj())) {
            throw new MapsBizException(this.messageSource, "EC00000001", new String[]{"Parameter[emailSj]"}, MapsConstants.DFLT_LOCALE, null);
        }
        if (StringUtils.isBlank(vo.getEmailBdt())) {
            throw new MapsBizException(this.messageSource, "EC00000001", new String[]{"Parameter[emailBdt]"}, MapsConstants.DFLT_LOCALE, null);
        }
        if (StringUtils.isBlank(vo.getRegistId())) {
            throw new MapsBizException(this.messageSource, "EC00000001", new String[]{"Parameter[registId]"}, MapsConstants.DFLT_LOCALE, null);
        }
        
        
        dao.insertEmail(vo);
        
        if (logger.isDebugEnabled()) {logger.debug("##### emailSn : " + vo.getEmailSn());}
        
        return vo.getEmailSn();
    }

}
