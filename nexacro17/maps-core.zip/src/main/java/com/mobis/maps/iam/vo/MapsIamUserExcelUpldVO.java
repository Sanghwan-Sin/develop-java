package com.mobis.maps.iam.vo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 사용자 액셀업로드 항목
 * </pre>
 *
 * @ClassName   : MapsIamUserExcelUpldVO.java
 * @Description : 사용자 액셀업로드에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 9. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 9.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUserExcelUpldVO extends MapsIamExcelUpldCommVO {
    
    /** 사용자 리스트 */
    private List<MapsIamUserVO> users;
    /** 계정ID 매핑행 */
    private Map<String, Integer> mapngRowUserSeqId;
    /** 사용자별 사용자언어 매핑 */
    private Map<String, MapsIamUserLangVO> mapngLangs;
    /** 이메일 매핑행 */
    private Map<String, Integer> mapngRowEmail;
    /** 사용자권한 리스트 */
    private List<MapsIamUserAuthorVO> userAuthors;
    /** 사용자별 권한 매핑행 */
    private Map<String, List<Integer>> mapngRowUserAuthors;
    /** 권한ID 매핑 */
    private Map<String, MapsIamAuthorVO> mapngAuthorId;
    
    public MapsIamUserExcelUpldVO() {
        
        this.users = new ArrayList<MapsIamUserVO>();
        this.mapngRowUserSeqId = new HashMap<String, Integer>();
        this.mapngLangs = new HashMap<String, MapsIamUserLangVO>();
        
        this.mapngRowEmail = new HashMap<String, Integer>();
        
        this.userAuthors = new ArrayList<MapsIamUserAuthorVO>();
        this.mapngRowUserAuthors = new HashMap<String, List<Integer>>();
        this.mapngAuthorId = new HashMap<String, MapsIamAuthorVO>();
    }
    
    public void setMapngRowUserSeqId(String userSeqId, int row) {
        mapngRowUserSeqId.put(userSeqId, new Integer(row));
    }
    
    public Integer getMapngRowUserSeqId(String userSeqId) {
        
        return mapngRowUserSeqId.get(userSeqId);
    }
    
    public void setMapngRowEmail(String email, int row) {
        mapngRowEmail.put(email, new Integer(row));
    }
    
    public Integer getMapngRowEmail(String email) {
        
        return mapngRowEmail.get(email);
    }
    
    public void setMapngAuthorId(String authorId, MapsIamAuthorVO iamAuthorVO) {
        mapngAuthorId.put(authorId, iamAuthorVO);
    }
    
    public MapsIamAuthorVO getMapngAuthorId(String authorId) {
        
        return mapngAuthorId.get(authorId);
    }
    
    public MapsIamUserLangVO getUserLang(String userSeqId) {
        
        return mapngLangs.get(userSeqId);
    }
    
    public void putUserLang(String userSeqId, String langCd) {
        
        MapsIamUserLangVO iamUserLangVO = new MapsIamUserLangVO();
        iamUserLangVO.setRowType(DataSet.ROW_TYPE_INSERTED);
        iamUserLangVO.setUserSeqId(userSeqId);
        iamUserLangVO.setLangCd(langCd);
        iamUserLangVO.setReprsntYn(MapsConstants.YN_YES);
        
        mapngLangs.put(userSeqId, iamUserLangVO);
    }
    
    public List<Integer> getMapngRowUserAuthor(String userSeqId) {
        
        return mapngRowUserAuthors.get(userSeqId);
    }
    
    public void addMapngRowUserAuthor(String userSeqId, int row) {
        
        List<Integer> authors = getMapngRowUserAuthor(userSeqId);
        
        if (authors == null) {
            authors = new ArrayList<Integer>();
        }
        authors.add(new Integer(row));
        
        mapngRowUserAuthors.put(userSeqId, authors);
    }

    /**
     * @return the users
     */
    public List<MapsIamUserVO> getUsers() {
        return users;
    }
    /**
     * @param users the users to set
     */
    public void setUsers(List<MapsIamUserVO> users) {
        this.users = users;
    }
    /**
     * @return the mapngRowUserSeqId
     */
    public Map<String, Integer> getMapngRowUserSeqId() {
        return mapngRowUserSeqId;
    }
    /**
     * @param mapngRowUserSeqId the mapngRowUserSeqId to set
     */
    public void setMapngRowUserSeqId(Map<String, Integer> mapngRowUserSeqId) {
        this.mapngRowUserSeqId = mapngRowUserSeqId;
    }
    /**
     * @return the mapngLangs
     */
    public Map<String, MapsIamUserLangVO> getMapngLangs() {
        return mapngLangs;
    }
    /**
     * @param mapngLangs the mapngLangs to set
     */
    public void setMapngLangs(Map<String, MapsIamUserLangVO> mapngLangs) {
        this.mapngLangs = mapngLangs;
    }
    /**
     * @return the mapngRowEmail
     */
    public Map<String, Integer> getMapngRowEmail() {
        return mapngRowEmail;
    }
    /**
     * @param mapngRowEmail the mapngRowEmail to set
     */
    public void setMapngRowEmail(Map<String, Integer> mapngRowEmail) {
        this.mapngRowEmail = mapngRowEmail;
    }
    /**
     * @return the userAuthors
     */
    public List<MapsIamUserAuthorVO> getUserAuthors() {
        return userAuthors;
    }
    /**
     * @param userAuthors the userAuthors to set
     */
    public void setUserAuthors(List<MapsIamUserAuthorVO> userAuthors) {
        this.userAuthors = userAuthors;
    }
    /**
     * @return the mapngRowUserAuthors
     */
    public Map<String, List<Integer>> getMapngRowUserAuthors() {
        return mapngRowUserAuthors;
    }
    /**
     * @param mapngRowUserAuthors the mapngRowUserAuthors to set
     */
    public void setMapngRowUserAuthors(Map<String, List<Integer>> mapngRowUserAuthors) {
        this.mapngRowUserAuthors = mapngRowUserAuthors;
    }
    /**
     * @return the mapngAuthorId
     */
    public Map<String, MapsIamAuthorVO> getMapngAuthorId() {
        return mapngAuthorId;
    }
    /**
     * @param mapngAuthorId the mapngAuthorId to set
     */
    public void setMapngAuthorId(Map<String, MapsIamAuthorVO> mapngAuthorId) {
        this.mapngAuthorId = mapngAuthorId;
    }

}
