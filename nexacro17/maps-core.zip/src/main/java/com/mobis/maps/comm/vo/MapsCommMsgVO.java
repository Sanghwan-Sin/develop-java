package com.mobis.maps.comm.vo;

/**
 * <pre>
 * 메세지 관리 항목
 * </pre>
 *
 * @ClassName   : MapsCommMsgVO.java
 * @Description : 메세지 관리 항목을 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 26.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsCommMsgVO extends PgBascVO {
    /** 메세지시스템 */
    private String msgSys;
    /** 메세지코드 */
    private String msgCd;
    /** 메세지언어 */
    private String msgLang;
    /** 메세지명 */
    private String msgNm;
    /** 메세지구분 */
    private String msgSe;
    /** 참조 메세지언어 */
    private String refrnMsgLang;
    /** 참조 메세지명 */
    private String refrnMsgNm;
    /**
     * @return the msgSys
     */
    public String getMsgSys() {
        return msgSys;
    }
    /**
     * @param msgSys the msgSys to set
     */
    public void setMsgSys(String msgSys) {
        this.msgSys = msgSys;
    }
    /**
     * @return the msgCd
     */
    public String getMsgCd() {
        return msgCd;
    }
    /**
     * @param msgCd the msgCd to set
     */
    public void setMsgCd(String msgCd) {
        this.msgCd = msgCd;
    }
    /**
     * @return the msgLang
     */
    public String getMsgLang() {
        return msgLang;
    }
    /**
     * @param msgLang the msgLang to set
     */
    public void setMsgLang(String msgLang) {
        this.msgLang = msgLang;
    }
    /**
     * @return the msgNm
     */
    public String getMsgNm() {
        return msgNm;
    }
    /**
     * @param msgNm the msgNm to set
     */
    public void setMsgNm(String msgNm) {
        this.msgNm = msgNm;
    }
    /**
     * @return the msgSe
     */
    public String getMsgSe() {
        return msgSe;
    }
    /**
     * @param msgSe the msgSe to set
     */
    public void setMsgSe(String msgSe) {
        this.msgSe = msgSe;
    }
    /**
     * @return the refrnMsgLang
     */
    public String getRefrnMsgLang() {
        return refrnMsgLang;
    }
    /**
     * @param refrnMsgLang the refrnMsgLang to set
     */
    public void setRefrnMsgLang(String refrnMsgLang) {
        this.refrnMsgLang = refrnMsgLang;
    }
    /**
     * @return the refrnMsgNm
     */
    public String getRefrnMsgNm() {
        return refrnMsgNm;
    }
    /**
     * @param refrnMsgNm the refrnMsgNm to set
     */
    public void setRefrnMsgNm(String refrnMsgNm) {
        this.refrnMsgNm = refrnMsgNm;
    }
}
