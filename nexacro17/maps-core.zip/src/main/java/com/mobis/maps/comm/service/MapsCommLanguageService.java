package com.mobis.maps.comm.service;

import java.util.List;
import java.util.Locale;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommLanguageVO;
import com.mobis.maps.comm.vo.MapsCommScrinFnctVO;

/**
 * <pre>
 * 다국어 관리 서비스
 * </pre>
 *
 * @ClassName   : MapsCommLanguageService.java
 * @Description : 다국어 관리 서비스를 정의.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
public interface MapsCommLanguageService {
    
    /**
     * 다국어 리스트 조회
     *
     * @param commLangVO
     * @return
     * @throws Exception
     */
    public List<MapsCommLanguageVO> selectLangList(MapsCommLanguageVO commLangVO) throws Exception;
    
    /**
     * 화면에 대한 function list조회
     *
     * @param commScrinFnctVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsCommScrinFnctVO> selectScrinFuncList(MapsCommScrinFnctVO commScrinFnctVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 용어명 조회
     * Statements
     *
     * @param wordId
     * @param abbrevWordUseCd
     * @param locale
     * @return
     * @throws Exception
     */
    public String selectWord(String wordId, String abbrevWordUseCd, Locale locale) throws Exception;
}
