package com.mobis.maps.cmmn.secure;

import java.security.InvalidKeyException;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;

import able.com.util.crypto.AES256CryptoService;

/**
 * <pre>
 * 암호화 복호화
 * </pre>
 *
 * @ClassName   : Secure.java
 * @Description : 암호화 복호화
 * @author oh.dongwon
 * @since 2018. 5. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2018. 5. 18.     oh.dongwon     	최초 생성
 * </pre>
 */
public class Secure {

	private String key;
	private String iv;

    public Secure() {}
    
	public Secure(String key) {
		this.key = key;
	}
	public Secure(String key, String iv) {
		this.key = key;
		this.iv = iv;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @param iv the iv to set
	 */
	public void setIv(String iv) {
		this.iv = iv;
	}

	/**
     * AES256 암호화
     *
     * @param value 암호화 대상 값
     * @return
     * @throws Exception
     */
    public String encryptAES256(String value) throws Exception {
        String encrypted = null;
        String iv = "";
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(key.length() != 32) {
        	throw new InvalidKeyException("the length of the value is 32 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            if(StringUtils.isEmpty(this.iv)) {
            	iv = StringUtils.substring(key, 0, 16);
            }else{
            	iv = this.iv;
            }
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = encodeHexKeyAES256(key);
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 암호화 - Base64 String 결과 반환
            encrypted = aes256CryptoService.encrypt(keyB, ivB, value);
        }
        return encrypted;
    }

	/**
     * AES256 암호화
     *
     * @param key 키
     * @param value 암호화 대상 값
     * @return
     * @throws Exception
     */
    public String encryptAES256(String key, String value) throws Exception {
        String encrypted = null;
        String iv = "";
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(key.length() != 32) {
        	throw new InvalidKeyException("the length of the value is 32 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            if(StringUtils.isEmpty(this.iv)) {
            	iv = StringUtils.substring(key, 0, 16);
            }else{
            	iv = this.iv;
            }
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = encodeHexKeyAES256(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 암호화 - Base64 String 결과 반환
            encrypted = aes256CryptoService.encrypt(keyB, ivB, value);
        }
        return encrypted;
    }

	/**
     * AES256 암호화
     *
     * @param key 키
     * @param value 암호화 대상 값
     * @param iv 초기 백터값
     * @return
     * @throws Exception
     */
    public String encryptAES256(String key, String value, String iv) throws Exception {
        String encrypted = null;
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(StringUtils.isEmpty(iv)) {
        	throw new InvalidKeyException("iv is empty");
        }else if(key.length() != 32) {
        	throw new InvalidKeyException("the length of the value is 32 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = encodeHexKeyAES256(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 암호화 - Base64 String 결과 반환
            encrypted = aes256CryptoService.encrypt(keyB, ivB, value);
        }
        return encrypted;
    }

    /**
     * AES256 복호화
     *
     * @param key 키
     * @param value 복호화 대상 값
     * @return
     * @throws Exception
     */
    public String decryptAES256(String value) throws Exception {
        String decrypted = null;
        String iv = "";
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(key.length() != 32) {
        	throw new InvalidKeyException("the length of the value is 32 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            if(StringUtils.isEmpty(this.iv)) {
            	iv = StringUtils.substring(key, 0, 16);
            }else{
            	iv = this.iv;
            }
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = encodeHexKeyAES256(key);
            //byte[] ivB = iv.getBytes();
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 복호화
            decrypted = aes256CryptoService.decrypt(keyB, ivB, value);
        }
        return decrypted;
    }

    /**
     * AES256 복호화
     *
     * @param key 키
     * @param value 복호화 대상 값
     * @return
     * @throws Exception
     */
    public String decryptAES256(String key, String value) throws Exception {
        String decrypted = null;
        String iv = "";
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(key.length() != 32) {
        	throw new InvalidKeyException("the length of the value is 32 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            if(StringUtils.isEmpty(this.iv)) {
            	iv = StringUtils.substring(key, 0, 16);
            }else{
            	iv = this.iv;
            }
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = encodeHexKeyAES256(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 복호화
            decrypted = aes256CryptoService.decrypt(keyB, ivB, value);
        }
        return decrypted;
    }

    /**
     * AES256 복호화
     *
     * @param key 키
     * @param value 복호화 대상 값
     * @return
     * @throws Exception
     */
    public String decryptAES256(String key, String value, String iv) throws Exception {
        String decrypted = null;
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(StringUtils.isEmpty(iv)) {
        	throw new InvalidKeyException("iv is empty");
        }else if(key.length() != 32) {
        	throw new InvalidKeyException("the length of the value is 32 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            AES256CryptoService aes256CryptoService = new AES256CryptoService();
            byte[] keyB = encodeHexKeyAES256(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 복호화
            decrypted = aes256CryptoService.decrypt(keyB, ivB, value);
        }
        return decrypted;
    }

    /**
     * AES128 암호화
     *
     * @param value 암호화 대상 값
     * @return
     * @throws Exception
     */
    public String encryptAES128(String value) throws Exception {
        String encrypted = null;
        String iv = "";
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(key.length() != 16) {
        	throw new InvalidKeyException("the length of the value is 16 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            if(StringUtils.isEmpty(this.iv)) {
            	iv = StringUtils.substring(key, 0, 16);
            }else{
            	iv = this.iv;
            }
        	AES128CryptoService aes128CryptoService = new AES128CryptoService();
            byte[] keyB = encodeHexKeyAES128(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 암호화 - Base64 String 결과 반환
            encrypted = aes128CryptoService.encrypt(keyB, ivB, value);
        }
        return encrypted;
    }

    /**
     * AES128 암호화
     *
     * @param key 키
     * @param value 암호화 대상 값
     * @return
     * @throws Exception
     */
    public String encryptAES128(String key, String value) throws Exception {
        String encrypted = null;
        String iv = "";
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(key.length() != 16) {
        	throw new InvalidKeyException("the length of the value is 16 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            if(StringUtils.isEmpty(this.iv)) {
            	iv = StringUtils.substring(key, 0, 16);
            }else{
            	iv = this.iv;
            }
        	AES128CryptoService aes128CryptoService = new AES128CryptoService();
            byte[] keyB = encodeHexKeyAES256(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 암호화 - Base64 String 결과 반환
            encrypted = aes128CryptoService.encrypt(keyB, ivB, value);
        }
        return encrypted;
    }

	/**
     * AES256 암호화
     *
     * @param key 키
     * @param value 암호화 대상 값
     * @param iv 초기 백터값
     * @return
     * @throws Exception
     */
    public String encryptAES128(String key, String value, String iv) throws Exception {
        String encrypted = null;
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(StringUtils.isEmpty(iv)) {
        	throw new InvalidKeyException("iv is empty");
        }else if(key.length() != 16) {
        	throw new InvalidKeyException("the length of the value is 32 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            AES128CryptoService aes128CryptoService = new AES128CryptoService();
            byte[] keyB = encodeHexKeyAES128(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 암호화 - Base64 String 결과 반환
            encrypted = aes128CryptoService.encrypt(keyB, ivB, value);
        }
        return encrypted;
    }

    /**
     * AES256 복호화
     *
     * @param value 복호화 대상 값
     * @return
     * @throws Exception
     */
    public String decryptAES128(String value) throws Exception {
        String decrypted = null;
        String iv = "";
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(key.length() != 16) {
        	throw new InvalidKeyException("the length of the value is 16 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            if(StringUtils.isEmpty(this.iv)) {
            	iv = StringUtils.substring(key, 0, 16);
            }else{
            	iv = this.iv;
            }
        	AES128CryptoService aes128CryptoService = new AES128CryptoService();
            byte[] keyB = encodeHexKeyAES128(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 복호화
            decrypted = aes128CryptoService.decrypt(keyB, ivB, value);
        }
        return decrypted;
    }

    /**
     * AES256 복호화
     *
     * @param key 키
     * @param value 복호화 대상 값
     * @return
     * @throws Exception
     */
    public String decryptAES128(String key, String value) throws Exception {
        String decrypted = null;
        String iv = "";
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(key.length() != 16) {
        	throw new InvalidKeyException("the length of the value is 16 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            if(StringUtils.isEmpty(this.iv)) {
            	iv = StringUtils.substring(key, 0, 16);
            }else{
            	iv = this.iv;
            }
        	AES128CryptoService aes128CryptoService = new AES128CryptoService();
            byte[] keyB = encodeHexKeyAES128(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 복호화
            decrypted = aes128CryptoService.decrypt(keyB, ivB, value);
        }
        return decrypted;
    }

    /**
     * AES256 복호화
     *
     * @param key 키
     * @param value 복호화 대상 값
     * @return
     * @throws Exception
     */
    public String decryptAES128(String key, String value, String iv) throws Exception {
        String decrypted = null;
        if(StringUtils.isEmpty(key)){
        	throw new InvalidKeyException("key is empty");
        }else if(StringUtils.isEmpty(iv)) {
        	throw new InvalidKeyException("iv is empty");
        }else if(key.length() != 16) {
        	throw new InvalidKeyException("the length of the value is 32 characters.");
        }else if(StringUtils.isEmpty(value)) {
        	throw new InvalidKeyException("value is empty");
        } else {
            AES128CryptoService aes128CryptoService = new AES128CryptoService();
            byte[] keyB = encodeHexKeyAES128(key);
            byte[] ivB = iv.getBytes();
/*
            byte[] keyB = key.getBytes();
            byte[] ivB = iv.getBytes();
            // Hex String -> byte[] 변환
            byte[] keyB = Hex.decodeHex(key.toCharArray());
            byte[] ivB = Hex.decodeHex(iv.toCharArray());
*/
            // 복호화
            decrypted = aes128CryptoService.decrypt(keyB, ivB, value);
        }
        return decrypted;
    }

    private byte[] encodeHexKeyAES256(String key){
    	String encodeHexKey = "";
    	encodeHexKey = new String(Hex.encodeHex(key.getBytes()));
    	if(encodeHexKey != null){
    		encodeHexKey = StringUtils.substring(encodeHexKey, 0, 32);
    	}
    	return encodeHexKey.getBytes();
    }

    private byte[] encodeHexKeyAES128(String key){
    	String encodeHexKey = "";
    	encodeHexKey = new String(Hex.encodeHex(key.getBytes()));
    	if(encodeHexKey != null){
    		encodeHexKey = StringUtils.substring(encodeHexKey, 0, 16);
    	}
    	return encodeHexKey.getBytes();
    }
}
