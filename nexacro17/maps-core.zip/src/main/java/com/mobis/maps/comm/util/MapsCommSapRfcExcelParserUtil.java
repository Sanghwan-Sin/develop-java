package com.mobis.maps.comm.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mobis.maps.comm.vo.MapsCommSapRfcBassInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIpttInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrFieldVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrMstVO;

/**
 * <pre>
 * 액셀 업로드 RFC정보 파싱
 * </pre>
 *
 * @ClassName   : MapsCommSapRfcExcelParserUtil.java
 * @Description : 업로드된 액셀 파일에 대한 RFC정보 파싱.
 * @author Sin Sanghwan
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class MapsCommSapRfcExcelParserUtil {
    
    private final static Logger LOGGER = LoggerFactory.getLogger(MapsCommSapRfcExcelParserUtil.class);
    
    private static final String SHEET_NAME_RFC_INFO = "RFC_INFO";
    
    private static final String SHEET_NAME_STRUCTURE = "STRUCTURE";
    
    private static final String DATA_TY_LIST = "L";
    
    private static final int RFC_IPTT_START_ROW = 3;
    
    private static final int RFC_IPTT_END_COL = 11;
    
    private static final int RFC_STRCTR_START_ROW = 1;
    
    private static final int RFC_STRCTR_END_COL = 8;
    
    /**
     * RFC정보 설정
     *
     * @param sysId
     * @param file
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static MapsCommSapRfcInfoVO setRfcInfo(String sysId, File file) throws FileNotFoundException, IOException {
        
        List<MapsCommSapRfcBassInfoVO> sapRfcBassInfos = new ArrayList<MapsCommSapRfcBassInfoVO>();
        
        List<MapsCommSapRfcIpttInfoVO> sapRfcIpttInfos = new ArrayList<MapsCommSapRfcIpttInfoVO>();

        List<MapsCommSapRfcStrctrMstVO> sapRfcStrctrInfos = new ArrayList<MapsCommSapRfcStrctrMstVO>();

        List<MapsCommSapRfcStrctrFieldVO> sapRfcStrctrFieldInfos = new ArrayList<MapsCommSapRfcStrctrFieldVO>();
        
        int rownum = 0;
        
        XSSFWorkbook workbook = MapsCommExcelUtil.createWorkbook(file);
        
        XSSFSheet sheetRfcInfo = workbook.getSheet(SHEET_NAME_RFC_INFO);
        
        sapRfcBassInfos.add(getRfcMst(sysId, sheetRfcInfo));
        rownum = RFC_IPTT_START_ROW;
        while (true) {
            
            XSSFRow xssfRow = sheetRfcInfo.getRow(rownum);
            if (xssfRow == null) {
                break;
            }

            // RFC입출력정보 생성
            MapsCommSapRfcIpttInfoVO sapRfcStrctrInfo = getRfcRfcIpttInfo(sapRfcBassInfos.get(0), xssfRow);
            if (sapRfcStrctrInfo == null) {
                break;
            }
            sapRfcIpttInfos.add(sapRfcStrctrInfo);
            
            if (StringUtils.equals(sapRfcStrctrInfo.getDataTy(), DATA_TY_LIST)) {
                // 구조체마스터 정보 생성
                MapsCommSapRfcStrctrMstVO sapRfcStrctrMst = getRfcStrctrMst(xssfRow);
                sapRfcStrctrInfos.add(sapRfcStrctrMst);
                // RFC입출력정보에 구조체명 설정
                sapRfcStrctrInfo.setStrctrNm(sapRfcStrctrMst.getStrctrNm());
            }
            rownum++;
        }
        
        XSSFSheet sheetStrctr = workbook.getSheet(SHEET_NAME_STRUCTURE);
        rownum = RFC_STRCTR_START_ROW;
        while (true) {
            
            XSSFRow xssfRow = sheetStrctr.getRow(rownum);
            if (xssfRow == null) {
                break;
            }

            // 구조체필드 정보 생성
            MapsCommSapRfcStrctrFieldVO sapRfcStrctrFieldInfo = getRfcStrctrField(xssfRow);
            if (sapRfcStrctrFieldInfo == null) {
                break;
            }
            sapRfcStrctrFieldInfos.add(sapRfcStrctrFieldInfo);
            rownum++;
        }
        
        MapsCommSapRfcInfoVO commSapRfcInfoVO = new MapsCommSapRfcInfoVO();
        commSapRfcInfoVO.setSapRfcBassInfos(sapRfcBassInfos);
        commSapRfcInfoVO.setSapRfcIpttInfos(sapRfcIpttInfos);
        commSapRfcInfoVO.setSapRfcStrctrInfos(sapRfcStrctrInfos);
        commSapRfcInfoVO.setSapRfcStrctrFieldInfos(sapRfcStrctrFieldInfos);
        
        return commSapRfcInfoVO;
    }
    
    /**
     * RFC 마스터 정보 취득
     *
     * @param sysId
     * @param sheet
     * @return
     */
    public static MapsCommSapRfcBassInfoVO getRfcMst(String sysId, XSSFSheet sheet) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("→ getRfcMst.sheet[SheetName=" + sheet.getSheetName() + "]");
        }

        XSSFRow row0 = sheet.getRow(0);
        XSSFCell cellRfcId = row0.getCell(2);
        XSSFCell cellItrfcId = row0.getCell(8);
        XSSFRow row1 = sheet.getRow(1);
        XSSFCell cellRfcNm = row1.getCell(2);
        XSSFCell cellChargerId = row1.getCell(8);
        
        MapsCommSapRfcBassInfoVO sapRfcMst = new MapsCommSapRfcBassInfoVO();
        sapRfcMst.setSysId(sysId);
        sapRfcMst.setRfcId(cellRfcId.getStringCellValue());
        sapRfcMst.setRfcNm(cellRfcNm.getStringCellValue());
        sapRfcMst.setChargerId(cellChargerId.getStringCellValue());
        sapRfcMst.setIntrfcId(cellItrfcId.getStringCellValue());
        
        return sapRfcMst;
    }
    
    /**
     * RFC 입출력정보 취득
     *
     * @param sapRfcBassInfoVO
     * @param xssfRow
     * @return
     */
    public static MapsCommSapRfcIpttInfoVO getRfcRfcIpttInfo(MapsCommSapRfcBassInfoVO sapRfcBassInfoVO, XSSFRow xssfRow) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("→ getRfcStrctrInfo::start.sapRfcBassInfoVO["+sapRfcBassInfoVO.getRfcId()+"]xssfRow[xssfRow=" + xssfRow.getRowNum() + "]");
        }
        
        MapsCommSapRfcIpttInfoVO sapRfcStrctrInfo = null;
        
        sapRfcStrctrInfo = setXSFCell(sapRfcBassInfoVO, xssfRow, sapRfcStrctrInfo);
        
        return sapRfcStrctrInfo;
    }

    /**
     * Statements
     *
     * @param sapRfcBassInfoVO
     * @param xssfRow
     * @param sapRfcStrctrInfo
     * @return
     */
    private static MapsCommSapRfcIpttInfoVO setXSFCell(MapsCommSapRfcBassInfoVO sapRfcBassInfoVO, XSSFRow xssfRow, MapsCommSapRfcIpttInfoVO sapRfcStrctrInfoIn) {
        MapsCommSapRfcIpttInfoVO sapRfcStrctrInfo = sapRfcStrctrInfoIn;
        for (int c = 0; c < RFC_IPTT_END_COL; c++) {
            
            XSSFCell xssfCell = xssfRow.getCell(c);
            if (c > 0) {
                setXSFCell2(sapRfcStrctrInfo, c, xssfCell);
            } else {
                if (xssfCell == null || StringUtils.isBlank(xssfCell.getStringCellValue())) {
                    break;
                } else {
                    sapRfcStrctrInfo = new MapsCommSapRfcIpttInfoVO();
                    sapRfcStrctrInfo.setSysId(sapRfcBassInfoVO.getSysId());
                    sapRfcStrctrInfo.setRfcId(sapRfcBassInfoVO.getRfcId());
                    sapRfcStrctrInfo.setUseYn("Y");
                    sapRfcStrctrInfo.setDelYn("N");
                }
            }
        }
        return sapRfcStrctrInfo;
    }

    /**
     * Statements
     *
     * @param sapRfcStrctrInfo
     * @param c
     * @param xssfCell
     */
    private static void setXSFCell2(MapsCommSapRfcIpttInfoVO sapRfcStrctrInfo, int c, XSSFCell xssfCell) {
        switch (c) {
            case 1 :    //RFC_IN_OUT
                sapRfcStrctrInfo.setRfcIpttSe(xssfCell.getStringCellValue());
                break;
            case 2 :    //RFC_FIELD
                sapRfcStrctrInfo.setRfcField(xssfCell.getStringCellValue());
                break;
            case 3 :    //ITEM_ID
                sapRfcStrctrInfo.setIemId(xssfCell.getStringCellValue());
                break;
            case 4 :    //WORD_ID
                sapRfcStrctrInfo.setWordId(xssfCell.getStringCellValue());
                break;
            case 5 :    //RFC_FIELD_NAME
                sapRfcStrctrInfo.setRfcFieldNm(xssfCell.getStringCellValue());
                break;
            case 7 :    //DATA_TYPE 
                sapRfcStrctrInfo.setDataTy(xssfCell.getStringCellValue());
                break;
            case 8 :    //STRUCTURE 
                sapRfcStrctrInfo.setStrctrId(xssfCell.getStringCellValue());
                break;
            case 10 :   //DESCRIPTION
                sapRfcStrctrInfo.setRfcFieldDc(xssfCell.getStringCellValue());
                break;
            default :
                break;
        }
    }
    
    /**
     * 구조체 마스터 정보 취득
     *
     * @param xssfRow
     * @return
     */
    public static MapsCommSapRfcStrctrMstVO getRfcStrctrMst(XSSFRow xssfRow) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("→ getRfcStrctrMst::start.xssfRow[xssfRow=" + xssfRow.getRowNum() + "]");
        }
        
        MapsCommSapRfcStrctrMstVO sapRfcStrctrMst = null;
        
        for (int c = 0; c < RFC_IPTT_END_COL; c++) {
            
            XSSFCell xssfCell = xssfRow.getCell(c);
            if (c > 0) {
                switch (c) {
                    case 8 :    //STRUCTURE 
                        sapRfcStrctrMst.setStrctrId(xssfCell.getStringCellValue());
                        break;
                    case 9 :   //STRUCTURE_NAME
                        sapRfcStrctrMst.setStrctrNm(xssfCell.getStringCellValue());
                        break;
                    default :
                        break;
                }
            } else {
                if (xssfCell == null || StringUtils.isBlank(xssfCell.getStringCellValue())) {
                    break;
                } else {
                    sapRfcStrctrMst = new MapsCommSapRfcStrctrMstVO();
                }
            }
        }
        
        return sapRfcStrctrMst;
    }
    
    /**
     * 구조체 항목 정보 취득
     *
     * @param xssfRow
     * @return
     */
    public static MapsCommSapRfcStrctrFieldVO getRfcStrctrField(XSSFRow xssfRow) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("→ getRfcStrctrField::start.xssfRow[xssfRow=" + xssfRow.getRowNum() + "]");
        }
        
        MapsCommSapRfcStrctrFieldVO sapRfcStrctrField = null;
        
        sapRfcStrctrField = checkXssfCell(xssfRow, sapRfcStrctrField);
        
        return sapRfcStrctrField;
    }

    /**
     * Statements
     *
     * @param xssfRow
     * @param sapRfcStrctrField
     * @return
     */
    private static MapsCommSapRfcStrctrFieldVO checkXssfCell(XSSFRow xssfRow, MapsCommSapRfcStrctrFieldVO sapRfcStrctrFieldIn) {
        
        MapsCommSapRfcStrctrFieldVO sapRfcStrctrField = sapRfcStrctrFieldIn;
        for (int c = 0; c < RFC_STRCTR_END_COL; c++) {
            
            XSSFCell xssfCell = xssfRow.getCell(c);
            if (c > 0) {
                checkXssfCell2(sapRfcStrctrField, c, xssfCell);
            } else {
                if (StringUtils.isBlank(xssfCell.getStringCellValue())) {
                    break;
                } else {
                    sapRfcStrctrField = new MapsCommSapRfcStrctrFieldVO();
                    sapRfcStrctrField.setStrctrId(xssfCell.getStringCellValue());
                    sapRfcStrctrField.setUseYn("Y");
                    sapRfcStrctrField.setDelYn("N");
                }
            }
        }
        return sapRfcStrctrField;
    }

    /**
     * Statements
     *
     * @param sapRfcStrctrField
     * @param c
     * @param xssfCell
     */
    private static void checkXssfCell2(MapsCommSapRfcStrctrFieldVO sapRfcStrctrField, int c, XSSFCell xssfCell) {
        switch (c) {
            case 1 :   //RFC_FIELD
                sapRfcStrctrField.setRfcField(xssfCell.getStringCellValue());
                break;
            case 2 :   //ITEM_ID
                sapRfcStrctrField.setIemId(xssfCell.getStringCellValue());
                break;
            case 3 :   //WORD_ID
                sapRfcStrctrField.setWordId(xssfCell.getStringCellValue());
                break;
            case 4 :   //RFC_FIELD_NAME
                sapRfcStrctrField.setRfcFieldNm(xssfCell.getStringCellValue());
                break;
            case 6 :   //DATA_TYPE
                sapRfcStrctrField.setDataTy(xssfCell.getStringCellValue());
                break;
            case 7 :   //DESCRIPTION
                sapRfcStrctrField.setRfcFieldDc(xssfCell.getStringCellValue());
                break;
            default :
                break;
        }
    }
}
