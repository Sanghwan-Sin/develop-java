package com.mobis.maps.cmmn.util;

import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import able.com.ui.adaptor.nexacro.servlet.NexacroContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;

import com.nexacro17.xapi.data.DataSet;
import com.nexacro17.xapi.data.PlatformData;
import com.nexacro17.xapi.data.Variable;
import com.nexacro17.xapi.tx.HttpPlatformResponse;
import com.nexacro17.xapi.tx.PlatformException;
import com.nexacro17.xapi.tx.PlatformType;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : NexacroUtil.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 29.     DT048058     	최초 생성
 * </pre>
 */

public class NexacroUtil {

    protected static Logger logger = LoggerFactory.getLogger(NexacroUtil.class);

    /**
     * getGdsTranParam DataSet 취득
     *
     * @return
     */
    public static DataSet getGdsTranParam() {
        
        DataSet ds = null;
        Object context = RequestContextHolder.getRequestAttributes().getAttribute("NexacroCachedData", 0);
        NexacroContext nexacontext = null;
        if (context instanceof NexacroContext) {
            nexacontext = (NexacroContext)context;
        }

        if (nexacontext != null){
//            int c = nexacontext.getPlatformData().getDataSetCount();
//            for (int i = 0; i < c; i++) {
//                ds = nexacontext.getPlatformData().getDataSet(i);
//                
//                logger.debug("DataSet[" + i + "][name=" + ds.getName()+"]");
//            }
            ds = nexacontext.getPlatformData().getDataSet("gdsTranParam");
        }
        return ds;
    }
    
    /**
     * getGdsTranParam Local Datetime 취득
     *
     * @return
     */
    public static Date getGdsLocalDt() {

        DataSet dsParam = getGdsTranParam();
        if (dsParam == null) {
            return null;
        }
        
        return dsParam.getDateTime(0, "localDt");
    }
    
    /**
     * getGdsScrinId 화면ID 취득
     *
     * @return
     */
    public static String getGdsScrinId() {

        DataSet dsParam = getGdsTranParam();
        if (dsParam == null) {
            return null;
        }
        
        return dsParam.getString(0, "scrinId");
    }
    
    
    /**
     * Error메세지 전송
     *
     * @param response
     * @param code
     * @param msg
     * @throws PlatformException
     */
    public static void sendDataErrorMsg(
            HttpServletResponse response
            , String code
            , String msg) throws PlatformException {

        PlatformData platformData = new PlatformData();
        platformData.addVariable(Variable.createVariable("ErrorCode", code));
        platformData.addVariable(Variable.createVariable("ErrorMsg", msg));
        
        HttpPlatformResponse res = new HttpPlatformResponse(response, PlatformType.CONTENT_TYPE_XML, "UTF-8");
        res.setData(platformData);
        res.sendData();
    }
}
