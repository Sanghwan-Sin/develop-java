package com.mobis.maps.iam.util;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO;
import com.mobis.maps.iam.vo.MapsIamCommVO;
import com.mobis.maps.iam.vo.MapsIamMobisOrgnztVO;
import com.mobis.maps.iam.vo.MapsIamUserVO;

/**
 * <pre>
 * IAM시스템 유틸리티
 * </pre>
 *
 * @ClassName   : MapsIamUtil.java
 * @Description : IAM시스템에 대한 유틸리티.
 * @author DT048058
 * @since 2020. 6. 15.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 15.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamUtil {
    
    /**
     * 로그인정보설정
     *
     * @param iamCommVO
     * @param loginInfoVO
     */
    public static void setLoginInfo(MapsIamCommVO iamCommVO, LoginInfoVO loginInfoVO) {

        iamCommVO.setAcntSysSeCd(loginInfoVO.getSysSeCd());
        iamCommVO.setAcntBsnOrgnztCd(loginInfoVO.getBsnOrgnztCd());
        iamCommVO.setAcntOrgnztSeCd(loginInfoVO.getOrgnztSeCd());
        iamCommVO.setAcntOrgnztCd(loginInfoVO.getOrgnztCd());
        iamCommVO.setAcntDealerCd(loginInfoVO.getDealerCd());
        iamCommVO.setAcntAcntTyCd(loginInfoVO.getAcntTyCd());
        
        iamCommVO.setDfltLangCd(loginInfoVO.getDfltLangCd());
    }

    public static void addUserBassOrgnztSeCd(MapsIamCommVO iamCommVO, LoginInfoVO loginInfoVO) {
        
        String acntTyCd = loginInfoVO.getAcntTyCd();
        String mapsSysSeCd = iamCommVO.getMapsSysSeCd();

        if (MapsConstants.SYS_SE_CD_IAM.equals(mapsSysSeCd)) {
            return;
        }
        
        if (MapsIamConstants.ACCOUNT_TYPE_CD_SYSTEM.equals(acntTyCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_MOBIS);
        }
        if (!MapsIamConstants.ACCOUNT_TYPE_CD_NOMAL.equals(acntTyCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_CORPORATION);
        }
        
        if (MapsConstants.SYS_SE_CD_NMGN.equals(mapsSysSeCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_GENERAL_DISTRIBUTORS);
        } else if (MapsConstants.SYS_SE_CD_SRS.equals(mapsSysSeCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_VENDOR);
        } else if (MapsConstants.SYS_SE_CD_DCS.equals(mapsSysSeCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_DIRECT_DISTRIBUTORS);
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_DIRECT_DEALER);
        } else if (MapsConstants.SYS_SE_CD_PDA.equals(mapsSysSeCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_PDA);
        } else {
            if (MapsIamConstants.ACCOUNT_TYPE_CD_SYSTEM.equals(acntTyCd)) {
                iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_MOBIS);
            }
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_CORPORATION);
        }
    }
    
    /**
     * 로그인 계정정보에 대한 조직구분코드 추가
     *
     * @param iamCommVO
     * @param loginInfoVO
     */
    public static void addOrgnztSeCd(String sysSeCd, MapsIamCommVO iamCommVO, LoginInfoVO loginInfoVO) {

        String loginAcntTyCd = loginInfoVO.getAcntTyCd();
        String loginSysSeCd= sysSeCd;
        String mapsSysSeCd = iamCommVO.getMapsSysSeCd();

        if (StringUtils.isBlank(loginSysSeCd)) {
            if (MapsConstants.SYS_SE_CD_IAM.equals(mapsSysSeCd)) {
                return;
            }
            loginSysSeCd = loginInfoVO.getSysSeCd();
        }

        if (MapsIamConstants.ACCOUNT_TYPE_CD_SYSTEM.equals(loginAcntTyCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_MOBIS);
        }
        if (!MapsIamConstants.ACCOUNT_TYPE_CD_NOMAL.equals(loginAcntTyCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_CORPORATION);
        }
        
        if (MapsConstants.SYS_SE_CD_NMGN.equals(loginSysSeCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_GENERAL_DISTRIBUTORS);
        } else if (MapsConstants.SYS_SE_CD_SRS.equals(loginSysSeCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_VENDOR);
        } else if (MapsConstants.SYS_SE_CD_DCS.equals(loginSysSeCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_DIRECT_DISTRIBUTORS);
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_DIRECT_DEALER);
        } else if (MapsConstants.SYS_SE_CD_PDA.equals(loginSysSeCd)) {
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_PDA);
        } else {
            if (MapsIamConstants.ACCOUNT_TYPE_CD_SYSTEM.equals(loginAcntTyCd)) {
                iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_MOBIS);
            }
            iamCommVO.addOrgnztSeCd(MapsConstants.ORGNZT_SE_CD_CORPORATION);
        }
    }
    
    /**
     * 로그인 계정정보에 대한 조직코드 추가
     *
     * @param iamCommVO
     * @param loginInfoVO
     * @throws Exception 
     */
    public static void addOrgnztCd(MapsIamCommVO iamCommVO, LoginInfoVO loginInfoVO, MapsIamMobisUserService mapsIamMobisUserService) throws Exception {
        
        String loginSysSeCd = loginInfoVO.getSysSeCd();
        String loginOrgnztSeCd = loginInfoVO.getOrgnztSeCd();
        String loginBsnOrgnztCd = loginInfoVO.getBsnOrgnztCd();
        String loginOrgnztCd = loginInfoVO.getOrgnztCd();
        String loginAcntTyCd = loginInfoVO.getAcntTyCd();
        // IT운영자
        if (MapsIamConstants.ACCOUNT_TYPE_CD_SYSTEM.equals(loginAcntTyCd)) {
            return;
        }
        // nMGN시스템인경우
        if (MapsConstants.SYS_SE_CD_NMGN.equals(loginSysSeCd)) {
            
            List<MapsOrgnztDistVO> orgnztDists = null;
            // 마스터사용자
            if (MapsIamConstants.ACCOUNT_TYPE_CD_MASTER.equals(loginAcntTyCd)) {
                // 사용자기본정보 조직구분이 모비스본사 이면 관리대상대리점 정보를 취득후 설정
                if (MapsConstants.ORGNZT_SE_CD_MOBIS.equals(loginOrgnztSeCd)) {
                    orgnztDists = mapsIamMobisUserService.selectDistKdGrpList(loginInfoVO);
                
                }
            }
            // 대표대리점
            if (loginInfoVO.isRepZkunnr()) {
                MapsIamMobisOrgnztVO iamMobisOrgnztVO = new MapsIamMobisOrgnztVO();
                iamMobisOrgnztVO.setBsnOrgnztCd(loginBsnOrgnztCd);
                iamMobisOrgnztVO.setOrgnztCd(loginOrgnztCd);
                orgnztDists = mapsIamMobisUserService.selectOrgnztDistInfoList(loginInfoVO);
            }
            if (orgnztDists != null) {
                for (MapsOrgnztDistVO orgnztDistVO: orgnztDists) {
                    iamCommVO.addBsnOrgnztCd(orgnztDistVO.getVkorg());
                    iamCommVO.addOrgnztCd(orgnztDistVO.getKunnr());
                }
            }
        }
        if (MapsIamValidatorUtil.isMobisCpr(loginInfoVO.getOrgnztSeCd())) {
            return;
        }
        if (StringUtils.isNotBlank(loginInfoVO.getOrgnztCd())) {
            if (ArrayUtils.isEmpty(iamCommVO.getOrgnztCds())) {
                iamCommVO.addOrgnztCd(loginInfoVO.getOrgnztCd());
            }
        }
    }

    
    /**
     * 로그인 계정정보에 대한 계정유형코드 추가
     *
     * @param iamCommVO
     * @param loginInfoVO
     */
    public static void addAcntTyCd(MapsIamCommVO iamCommVO, LoginInfoVO loginInfoVO) {
        
        String acntTyCd = loginInfoVO.getAcntTyCd();
        if (MapsIamConstants.ACCOUNT_TYPE_CD_SYSTEM.equals(acntTyCd)) {
            return;
        }
        if (StringUtils.isNotBlank(loginInfoVO.getOrgnztCd())) {
            if (!MapsIamConstants.ACCOUNT_TYPE_CD_NOMAL.equals(acntTyCd)) {
                iamCommVO.addOrgnztCd(loginInfoVO.getOrgnztCd());
            }
            iamCommVO.addOrgnztCd(loginInfoVO.getOrgnztCd());
        }
    }
    
    /**
     * 로케일 취득
     *
     * @param langCd
     * @return
     */
    public static Locale getLocale(String langCd) {
        
        Locale locale = MapsConstants.DFLT_LOCALE;
        
        if (StringUtils.isNotBlank(langCd)) {
            String[] localeInfo = StringUtils.split(langCd, "_");
            if (localeInfo.length == 2) {
                locale = new Locale(localeInfo[0], localeInfo[1]);
            }
        }
        
        return locale;
    }
    
    /**
     * 디폴트사용자언어 취득
     *
     * @param sysSeCd
     * @return
     */
    public static Locale getDfltUserLangCd(String sysSeCd) {
        
        Locale langLocale = MapsConstants.DFLT_LOCALE;
        
        if (sysSeCd.matches("S|I|P|H|T")) {
            langLocale = new Locale("ko", "KR");
        }
        
        return langLocale;
    }
    
    public static void setAcntSttusCd(MapsIamUserVO iamUserVO) {
        
        String acntSttusCd = null;
        
        String acntLockYn = iamUserVO.getAcntLockYn();
        String acntLockResnCd = iamUserVO.getAcntLockResnCd();
        Date useBgnde = iamUserVO.getUseBgnde();
        Date useEndde = iamUserVO.getUseEndde();
        Date pwdEndDt = iamUserVO.getPwdEndDt();
        String useYn = iamUserVO.getUseYn();
        String delYn = iamUserVO.getDelYn();
        Calendar toDay = Calendar.getInstance();
        if (StringUtils.equals(acntLockResnCd, MapsIamConstants.ACNT_LOCK_RESN_RETIREMENT)
                && StringUtils.equals(acntLockYn, MapsConstants.YN_YES)) {
            acntSttusCd = MapsIamConstants.ACNT_STTUS_CD_RETIREMENT;
        } else if (StringUtils.equals(delYn, MapsConstants.YN_YES)) {
            acntSttusCd = MapsIamConstants.ACNT_STTUS_CD_DELETED;
        } else if (StringUtils.equals(useYn, MapsConstants.YN_NO)) {
            acntSttusCd = MapsIamConstants.ACNT_STTUS_CD_UNUSED;
        } else if (toDay.getTime().compareTo(useEndde) >= 0) {
            acntSttusCd = MapsIamConstants.ACNT_STTUS_CD_END_USED;
        } else if (StringUtils.equals(acntLockYn, MapsConstants.YN_YES)) {
            acntSttusCd = MapsIamConstants.ACNT_STTUS_CD_LOCK;
        } else if (pwdEndDt.compareTo(toDay.getTime()) >= 0) {
            acntSttusCd = MapsIamConstants.ACNT_STTUS_CD_END_PASSWORD;
        } else if (useBgnde.compareTo(toDay.getTime()) >= 0) {
            acntSttusCd = MapsIamConstants.ACNT_STTUS_CD_UNUSED_PERIOD;
        } else {
            acntSttusCd = MapsIamConstants.ACNT_STTUS_CD_USING;
        }
        iamUserVO.setAcntSttusCd(acntSttusCd);
    }
    
    public static String getHelpEmail() throws Exception {
        
        String helpEmail = PropertiesUtil.getValue("IAM_HELP_EMAIL");
        if (StringUtils.isNotBlank(helpEmail)) {
            return helpEmail;
        }
        
        return MapsIamConstants.HELP_EMAIL;
    }

    public static String getEmail(MapsIamUserVO iamUserVO) throws Exception {
        StringBuilder sbEmail = new StringBuilder();
        sbEmail.append("\"");
        sbEmail.append(iamUserVO.getUserNm());
        sbEmail.append("\"");
        sbEmail.append("<");
        sbEmail.append(iamUserVO.getEmail());
        sbEmail.append(">");
        return sbEmail.toString();
    }
    
    public static String getMngrEmailFrom(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, List<MapsIamUserVO> users) throws Exception {
        
        for (MapsIamUserVO iamUserVO: users) {
            if (!StringUtils.equals(iamAcntReqstInfoVO.getMngrId(), iamUserVO.getUserSeqId())) {
                continue;
            }
            return getEmail(iamUserVO);
        }
        return MapsIamConstants.HELP_EMAIL;
    }

    public static String getMngrEmailCc(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO, List<MapsIamUserVO> users) throws Exception {
        
        StringBuilder sbEmail = new StringBuilder();
        for (MapsIamUserVO iamUserVO: users) {
            if (!StringUtils.equals(iamAcntReqstInfoVO.getMngrId(), iamUserVO.getUserSeqId())) {
                continue;
            }
            if (sbEmail.length() > 0) {
                sbEmail.append(",");
            }
            sbEmail.append(getEmail(iamUserVO));
        }
        
        return sbEmail.toString();
    }

    public static String getMngrEmailTo(List<MapsIamUserVO> users) throws Exception {
        
        StringBuilder sbEmail = new StringBuilder();
        
        if (users != null & !users.isEmpty()) {
            
            for (MapsIamUserVO iamUserVO: users) {
                if (sbEmail.length() > 0) {
                    sbEmail.append(",");
                }
                sbEmail.append(getEmail(iamUserVO));
            }
        }
//        else {
//            //TODO 삭제
//            MapsIamUserVO iamUserVO = new MapsIamUserVO();
//            iamUserVO.setUserNm("관리자");
//            iamUserVO.setEmail("DT048058@mobis.co.kr");
//            sbEmail.append(getEmail(iamUserVO));
//        }
        
        return sbEmail.toString();
    }
}
