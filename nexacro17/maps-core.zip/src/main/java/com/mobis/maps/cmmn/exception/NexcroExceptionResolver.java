package com.mobis.maps.cmmn.exception;

import java.nio.file.AccessDeniedException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.exception.BizException;
import able.com.ui.adaptor.nexacro.AuthorityException;
import able.com.ui.adaptor.nexacro.NexacroException;
import able.com.ui.adaptor.nexacro.resolve.NexcroMappingExceptionResolver;
import able.com.ui.adaptor.nexacro.util.HttpUtil;
import able.com.ui.adaptor.nexacro.util.NexacroUtil;
import able.com.ui.adaptor.nexacro.view.NexacroModelAndView;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataAccessException;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.ModelAndView;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.util.ValidatorUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;

/**
 * <pre>
 * 넥사크로 예외처리
 * </pre>
 *
 * @ClassName   : NexcroExceptionResolver.java
 * @Description : 넥사크로에 대한 예외처리를 정의한다.
 * @author Sin Sanghwan
 * @since 2019. 9. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 10.     Sin Sanghwan       최초 생성
 * </pre>
 */

public class NexcroExceptionResolver extends NexcroMappingExceptionResolver {

    protected Logger logger = LoggerFactory.getLogger(NexcroExceptionResolver.class);

    /**
     * 메세지코드(시스템애러="EC00000000")
     */
    protected static final String SYSTEM_ERROR_CODE = "EC00000000";
    /**
     * Htttp Request Header정보(ACCEPT="accept")
     */
    protected static final String HEADER_ACCEPT = "accept";
    /**
     * CHARSET(UTF-8)
     */
    protected static final String CHARSET_UTF_8 = "UTF-8";
    /**
     * Context Type(text/json)
     */
    protected static final String CONTEXT_TYPE_TEXT_JSON = "text/json";
    /**
     * Context Type(application/json)
     */
    protected static final String CONTEXT_TYPE_APPLICATION_JSON = "application/json";
    /**
     * 예외결과키(Code)
     */
    protected static final String RESULT_KEY_CODE = "code";
    /**
     * 예외결과키(메세지코드)
     */
    protected static final String RESULT_KEY_MESSAGE_CODE = "msgCd";
    /**
     * 예외결과키(메세지)
     */
    protected static final String RESULT_KEY_MESSAGE = "msg";
    /**
     * 예외리턴키(Code)
     */
    protected static final String RETURN_KEY_CODE = "errorcode";
    /**
     * 예외리턴키(메세지)
     */
    protected static final String RETURN_KEY_MESSAGE = "errormsg";
    /**
     * 예외리턴AJAX키(Code)
     */
    protected static final String RETURN_AJAX_KEY_CODE = "resultCode";
    /**
     * 예외리턴AJAX키(메세지)
     */
    protected static final String RETURN_AJAX_KEY_MESSAGE = "resultMsg";
    
    /** message source */
    @Resource(name = "messageSource")
    private MessageSource messageSource;

    @Override
    public ModelAndView doResolveException(
              HttpServletRequest request
            , HttpServletResponse response
            , Object handler
            , Exception ex) {

        ModelAndView rtnMv = null;
        String contentType = request.getHeader(HttpUtil.HEADER_CONTENT_TYPE);
        String accept = request.getHeader(HEADER_ACCEPT);
        NexacroModelAndView mvNexacro = new NexacroModelAndView(getView());
        boolean isContentJsonType = false;//(code == -40);
        Map<String, Object> result = resolveException(ex, request);
        int code = 0;
        if (result.get(RESULT_KEY_CODE) != null) {
            code = Integer.parseInt(result.get(RESULT_KEY_CODE).toString());
            switch (code) {
                case -40 :  //다른곳에서 로그인 한 경우
                case -41 :  //세션만료
                case -42 :
                case -60 :  //url 접근 권한이 없는 경우
                case -70 :  //TimeOut이 발생한경
                case -71 :  //지원히지 않는 브라우저인경우
                case -81 :  //파일다운로드 에러
                    isContentJsonType = true;
                    response.reset();
                    response.setCharacterEncoding(CHARSET_UTF_8);
                    response.setContentType(CONTEXT_TYPE_TEXT_JSON);
                    break;
                default :
                    isContentJsonType = false;
            }
            mvNexacro.setErrorCode(code);
        }
        String rsltMsg = null;
        if (result.get(RESULT_KEY_MESSAGE) != null) {
            rsltMsg = (String) result.get(RESULT_KEY_MESSAGE);
            mvNexacro.setErrorMsg(rsltMsg);
        }

        boolean isNexacroRequest = NexacroUtil.isNexacroRequest(request);
        StringBuilder sbTrace = new StringBuilder();
        if (isNexacroRequest) {
            if (StringUtils.startsWith(contentType, MediaType.TEXT_XML_VALUE.toLowerCase())) {
                // json데이터 요청인경우
                if (StringUtils.indexOf(accept, CONTEXT_TYPE_APPLICATION_JSON) != -1) {
                    
                    rtnMv = getMvJsonAjax(result);
                    sbTrace.append("001::JsonAjax");
                } else {

                    if (isContentJsonType) {
                        if (code == -40) { // 다른곳에서 로그인 한 경우
                            response.setStatus(333);
                        } else if (code == -41) { // 세션만료
                            response.setStatus(665);
                        } else if (code == -42) {
                            response.setStatus(334);
                        } else if (code == -60) { // url 접근 권한이 없는 경우
                            rtnMv = getMvAuthError(result);
                            sbTrace.append("010::AuthError");
                        } else if (code == -70) { // TimeOut이 발생한경우
                            rtnMv = getMvTimeOutError(result);
                            sbTrace.append("011::TimeOutError");
                        } else if (code == -71) { // 지원히지 않는 브라우저인경우
                            rtnMv = getMvError(result);
                            sbTrace.append("012::Error");
                        } else if (code == -81) { // 파일다운로드 에러
                            rtnMv = getMvError(result);
                            sbTrace.append("013::Error");
                        }
                    }
                    if (rtnMv == null) {
                        rtnMv = mvNexacro;
                        sbTrace.append("014::Nexacro");
                    }
                }
            } else if (StringUtils.startsWith(contentType, MediaType.MULTIPART_FORM_DATA_VALUE)) {
                rtnMv = mvNexacro;
                sbTrace.append("020::Nexacro");
//                // 엑셀 업로드 오류시에 대응
//                if (ex instanceof ExcelBindingException) {
//                } else if (ex instanceof MultipartException) {
//                } else {
//                    rtnMv = mvNexacro;//getMvAlertError(result);
//                    sbTrace.append("022::Error");
//                }
            } else {
                if (isContentJsonType) {
                    // 다른곳에서 로그인 한 경우
                    if (code == -40) {
                        response.setStatus(333);
                    } else if (code == -41) {
                        response.setStatus(665);
                    } else if (code == -42) {
                        response.setStatus(334);
                    } else if (code == -60) {
                        rtnMv = getMvAuthError(result);
                        sbTrace.append("030::AuthError");
                    } else if (code == -70) { // TimeOut이 발생한경우
                        rtnMv = getMvTimeOutError(result);
                        sbTrace.append("031::TimeOutError");
                    } else if (code == -71) { // 지원히지 않는 브라우저인경우
                        rtnMv = getMvError(result);
                        sbTrace.append("032::Error");
                    } else if (code == -81) { // 파일다운로드 에러
                        rtnMv = getMvError(result);
                        sbTrace.append("033::Error");
                    }
                } else if (contentType == null
                        || ex instanceof MapsFileDwnlException
                        || ex instanceof MapsTmplatDwnlException) {
                    // 다운로드 오류시에 대응
                    rtnMv = getMvAlertError(result);
                    sbTrace.append("034::Nexacro");
                }
    
                if (rtnMv == null) {
                    rtnMv = mvNexacro;
                    sbTrace.append("035::Nexacro");
                }
            }
        } else if (StringUtils.startsWith(contentType, MediaType.APPLICATION_JSON_UTF8_VALUE)
                || StringUtils.startsWith(contentType, MediaType.APPLICATION_JSON_VALUE)) {

            response.reset();
            response.setCharacterEncoding(CHARSET_UTF_8);
            response.setContentType(CONTEXT_TYPE_APPLICATION_JSON);
            
            rtnMv = getMvJsonError(result);
            sbTrace.append("100::JsonError");

        } else if (StringUtils.indexOf(contentType, "application/x-www-form-urlencoded; charset=UTF-8") != -1
                || request.getRequestURI().indexOf("ajax") != -1) {
            rtnMv = getMvJsonAjax(result);
            sbTrace.append("200::JsonAjax");
        } else if (StringUtils.startsWith(contentType, MediaType.MULTIPART_FORM_DATA_VALUE)) {
            // 엑셀 업로드 오류시에 대응
            if (ex instanceof ExcelBindingException) {
                rtnMv = mvNexacro;
                sbTrace.append("310::Nexacro");
            } else if (ex instanceof MultipartException) {
                rtnMv = mvNexacro;
                sbTrace.append("320::Nexacro");
            } else {
                rtnMv = getMvError(result);
                sbTrace.append("330::Error");
            }
        } else {
            if (code == -71 || code == -20 || code == -81) {
                response.reset();
                response.setCharacterEncoding(CHARSET_UTF_8);
                response.setContentType(CONTEXT_TYPE_TEXT_JSON);

                rtnMv = getMvError(result);
                sbTrace.append("900::Error");

            } else {
                
                ModelAndView vmLoginUsrView = getMvLoginUsrView(result);
                
                Enumeration<String> e = request.getParameterNames();
                while (e.hasMoreElements()) {
                    String key = e.nextElement();
                    vmLoginUsrView.addObject(key, request.getParameter(key));
                }
                rtnMv = vmLoginUsrView;
                sbTrace.append("910::LoginUsrView");
            }

            if (rtnMv == null) {
                rtnMv = mvNexacro;
                sbTrace.append("920::Nexacro");
            }

        }

        sbTrace.insert(0, "→ doResolveException::");
        sbTrace.append("::[contentType="+contentType+",characterEncoding"+response.getCharacterEncoding()+",accept="+accept+",isNexacroRequest="+isNexacroRequest+"]");
        if (logger.isDebugEnabled()) {
            logger.debug(sbTrace.toString());
        }
        return rtnMv;
    }
    
    private ModelAndView getMvAlertError(Map<String, Object> result) {

        ModelAndView mv = new ModelAndView("cmmn/errorAlert");
        mv.addObject(RETURN_KEY_CODE, result.get(RESULT_KEY_CODE));
        mv.addObject(RETURN_KEY_MESSAGE, result.get(RESULT_KEY_MESSAGE));
        
        return mv;
    }
    
    private ModelAndView getMvError(Map<String, Object> result) {

        ModelAndView mv = new ModelAndView("cmmn/defaultError");
        mv.addObject(RETURN_KEY_CODE, result.get(RESULT_KEY_CODE));
        mv.addObject(RETURN_KEY_MESSAGE, result.get(RESULT_KEY_MESSAGE));
        
        return mv;
    }
    
    private ModelAndView getMvTimeOutError(Map<String, Object> result) {

        ModelAndView mv = new ModelAndView("cmmn/timeOutError");
        
        return mv;
    }
    
    private ModelAndView getMvAuthError(Map<String, Object> result) {

        ModelAndView mv = new ModelAndView("cmmn/authError");
        mv.addObject(RETURN_KEY_CODE, result.get(RESULT_KEY_CODE));
        mv.addObject(RETURN_KEY_MESSAGE, result.get(RESULT_KEY_MESSAGE));
        
        return mv;
    }
    
    private ModelAndView getMvLoginUsrView(Map<String, Object> result) {

        ModelAndView mv = new ModelAndView("cmmn/loginError");
        mv.addObject(RETURN_KEY_CODE, result.get(RESULT_KEY_CODE));
        mv.addObject(RETURN_KEY_MESSAGE, result.get(RESULT_KEY_MESSAGE));
        
        return mv;
    }
    
    private ModelAndView getMvJsonError(Map<String, Object> result) {

        ModelAndView mv = new ModelAndView("jsonView");
        mv.addObject(RETURN_KEY_CODE, result.get(RESULT_KEY_CODE));
        mv.addObject(RETURN_KEY_MESSAGE, result.get(RESULT_KEY_MESSAGE));
        
        return mv;
    }
    
//    private ModelAndView getMvJson(Map<String, Object> result) {
//
//        ModelAndView mv = new ModelAndView("jsonView");
//        mv.addObject(result);
//        
//        return mv;
//    }
    
    private ModelAndView getMvJsonAjax(Map<String, Object> result) {

        ModelAndView mv = new ModelAndView("jsonView");
        mv.addObject(RETURN_AJAX_KEY_CODE, result.get(RESULT_KEY_CODE));
        mv.addObject(RETURN_AJAX_KEY_MESSAGE, result.get(RESULT_KEY_MESSAGE));
        mv.addObject(result);
        
        return mv;
    }

    private Map<String, Object> resolveException(Exception ex, HttpServletRequest request) {

        /*
         * -1  기본 넥사에러
         * -10 화면 Alert 메시지 출력
         * -11 JSP Alert메세지 출력
         * -20 화면 하단 메시지 출력
         * -30 로그아웃
         */
        Map<String, Object> mapRslt = new HashMap<>();
        int code = 0;
        String msgCd = "";
        Object[] args = null;
        String msg = "";
        String msgEx = "";
        Locale locale = Locale.getDefault();

        LoginInfoVO loginInfo = (LoginInfoVO) request.getSession().getAttribute(MapsConstants.SSS_LOGIN_INFO);
        if (loginInfo != null) {
            locale = loginInfo.getUserLcale();
        } else if (StringUtils.isNotBlank(request.getParameter(MapsConstants.PARAM_KEY_LANGUAGE_CODE))) {
            String[] arrLocaleInfo = StringUtils.split(request.getParameter(MapsConstants.PARAM_KEY_LANGUAGE_CODE), "_");
            locale = new Locale(arrLocaleInfo[0], arrLocaleInfo[1]);
        }
        
        //
        if (ex instanceof MapsLoginException) {
            logger.error("{}", "Resolver MapsLoginException.................");
            logger.error( ExceptionUtils.getStackTrace(ex) );

            MapsLoginException e = (MapsLoginException) ex;
            code = -10;
            msg = e.getMessage();
        } else if (ex instanceof MapsSessionException) {
            logger.error("{}", "Resolver MapsSessionException.................");
            logger.error( ExceptionUtils.getStackTrace(ex) );

            MapsSessionException e = (MapsSessionException) ex;
            code = -30;
            msgCd = e.getMessageKey();
        } else if (ex instanceof MapsMultiScrinLoginException) {
            logger.error("{}", "Resolver MapsMultiScrinLoginException.................");
            logger.error( ExceptionUtils.getStackTrace(ex) );

            MapsMultiScrinLoginException e = (MapsMultiScrinLoginException) ex;
            code = -31;
            msgCd = e.getMessageKey();
        } else if (ex instanceof MapsScrinAuthenticException) {
            logger.error("{}", "Resolver MapsScrinAuthenticException.................");

            code = -10;
            msg = ex.getMessage();
        } else if (ex instanceof MapsAuthenticException) {
            logger.error("{}", "Resolver MapsAuthenticException.................");

            code = -10;
            msg = ex.getMessage();
        } else if (ex instanceof MapsBizException) {
            logger.error("{}", "Resolver MapsBizException.................");
            logger.error( ExceptionUtils.getStackTrace(ex) );

            MapsBizException e = (MapsBizException) ex;
            code = -10;
            msg = e.getMessage();
        } else if (ex instanceof BizException) {
            logger.error("{}", "Resolver BizException.................");
            logger.error( ExceptionUtils.getStackTrace(ex) );

            BizException e = (BizException) ex;
            code = -10;
            msg = e.getMessage();
        } else if (ex instanceof NexacroException) {
            logger.error("{}", "Resolver NexacroException.................");
            logger.error( ExceptionUtils.getStackTrace(ex) );

            NexacroException e = (NexacroException) ex;
            code = e.getErrorCode();
            msgCd = SYSTEM_ERROR_CODE;
        } else if (ex instanceof ValidatorException) {
            logger.error("{}", "Resolver ValidatorException.................");

            code = -10;
            ValidatorException e = (ValidatorException) ex;
            if (e.isMultiDisp()) {
                msg = ValidatorUtil.getErrorMessages(e, messageSource, locale);
            } else {
                msg = ValidatorUtil.getErrorMessage(e, messageSource, locale);
            }
        } else if (ex instanceof DataAccessException) {
            logger.error("{}", "Resolver DataAccessException.................");
            logger.error( ExceptionUtils.getStackTrace(ex) );
            
            code = -20;
            msgCd = SYSTEM_ERROR_CODE;
        } else if (ex instanceof AccessDeniedException) {
            logger.error("{}", "Resolver AccessDeniedException.................");
            logger.error( ExceptionUtils.getStackTrace(ex) );
            logger.error("{}", ex.getMessage());
            
            code = -20;
        } else if (ex instanceof AuthorityException) {
            logger.error("{}", "Resolver AuthorityException.................");

            code = -10;
            msg = ex.getMessage();
        } else if (ex instanceof Exception) {
            logger.error("{}", "Resolver Exception.................");
            logger.error( ExceptionUtils.getStackTrace(ex) );
            logger.error("{}", ex);
            
            code = -20;
            msgCd = SYSTEM_ERROR_CODE;
            msgEx = ex.getMessage();
        }
        
        if (!StringUtils.isEmpty(msgCd)) {
            try {
                msg = messageSource.getMessage(msgCd, args, locale);
                if (StringUtils.isNotBlank(msgEx)) {
                    msg += "|" + msgEx;
                }
            } catch (Exception ee) {
                logger.error("{}", "NexcroExceptionResolver message exception[code=" + code + ",msgCd=" + msgCd + ",locale=" + locale.toString() + "]");
            }
        }
        logger.error("error={}", "[code=" + code + ",msgCd=" + msgCd + ",locale=" + locale.toString() + ",msg=" + msg + "]");
        mapRslt.put(RESULT_KEY_CODE, code);
        mapRslt.put(RESULT_KEY_MESSAGE_CODE, msgCd);
        mapRslt.put(RESULT_KEY_MESSAGE, msg);
        
        return mapRslt;
    }
}
