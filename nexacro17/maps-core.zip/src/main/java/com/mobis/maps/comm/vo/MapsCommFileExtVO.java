package com.mobis.maps.comm.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommFileExtVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 10. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 10. 21.     oh.dongwon     	최초 생성
 * </pre>
 */

public class MapsCommFileExtVO {
    /** SAP시스템ID */ 
    private String sysId;
    /** SAP시스템 client  */ 
    private String mandt;
    
    /** 파일 확장자 그룹 'CA-CHNNL-002' , 'CA-CHNNL-003' */
    private String code;
    /** 파일 확장자 */
    private String ext;
    
    
    
    /**
     * @return the sysId
     */
    public String getSysId() {
        return sysId;
    }
    /**
     * @param sysId the sysId to set
     */
    public void setSysId(String sysId) {
        this.sysId = sysId;
    }
    /**
     * @return the mandt
     */
    public String getMandt() {
        return mandt;
    }
    /**
     * @param mandt the mandt to set
     */
    public void setMandt(String mandt) {
        this.mandt = mandt;
    }
    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
    /**
     * @return the ext
     */
    public String getExt() {
        return ext;
    }
    /**
     * @param ext the ext to set
     */
    public void setExt(String ext) {
        this.ext = ext;
    }
    
    
}
