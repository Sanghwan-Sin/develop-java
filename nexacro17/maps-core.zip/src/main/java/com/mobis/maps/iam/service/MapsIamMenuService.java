package com.mobis.maps.iam.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamMenuScreenVO;
import com.mobis.maps.iam.vo.MapsIamMenuVO;

/**
 * <pre>
 * 메뉴 관리 서비스
 * </pre>
 *
 * @ClassName   : MapsIamMenuService.java
 * @Description : 메뉴 관리 서비스를 정의.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
public interface MapsIamMenuService {
    
    /**
     * 메뉴 리스트 조회
     *
     * @param iamMenuVO
     * @return
     * @throws Exception
     */
    public List<MapsIamMenuVO> selectMenuList(MapsIamMenuVO iamMenuVO) throws Exception;

    /**
     * 메뉴 화면 리스트 조회
     *
     * @param iamMenuVO
     * @return
     * @throws Exception
     */
    public List<MapsIamMenuScreenVO> selectMenuScreenList(MapsIamMenuVO iamMenuVO) throws Exception;

    
    /**
     * 메뉴 등록
     *
     * @param menuInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiMenuInfo(List<MapsIamMenuVO> menuInfos, LoginInfoVO loginInfo) throws Exception;
    
    
    /**
     * 메뉴 화면 등록
     *
     * @param menuScreenInfos
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public int multiMenuScreenInfo(List<MapsIamMenuScreenVO> menuScreenInfos, LoginInfoVO loginInfo) throws Exception;

    

}
