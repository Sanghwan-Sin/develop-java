package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.ValidatorUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.service.MapsIamUserBassInfoService;
import com.mobis.maps.iam.service.dao.MapsIamUserBassInfoMDAO;
import com.mobis.maps.iam.util.MapsIamUtil;
import com.mobis.maps.iam.util.MapsIamValidatorUtil;
import com.mobis.maps.iam.vo.MapsIamUserBassInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserIdSeqVO;
import com.mobis.maps.iam.vo.MapsIamUserOrgnztVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 사용자기본정보 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamUserBassInfoServiceImpl.java
 * @Description : 사용자기본정보에 대한 서비스를 구현.
 * @author DT048058
 * @since 2020. 3. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 17.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsIamUserBassInfoService")
public class MapsIamUserBassInfoServiceImpl extends HService implements MapsIamUserBassInfoService {

    @Resource(name = "mapsIamMobisUserService")
    MapsIamMobisUserService mapsIamMobisUserService;
    
    @Resource(name = "mapsIamUserBassInfoMDAO")
    private MapsIamUserBassInfoMDAO mapsIamUserBassInfoMDAO;
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#selectUserBassInfoPgList(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserBassInfoVO> selectUserBassInfoPgList(MapsIamUserBassInfoVO iamUserBassInfoVO
            , LoginInfoVO loginInfo) throws Exception {

        iamUserBassInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserBassInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        if (StringUtils.isBlank(iamUserBassInfoVO.getOrgnztSeCd())) {
            MapsIamUtil.addUserBassOrgnztSeCd(iamUserBassInfoVO, loginInfo);
        }
        if (StringUtils.isBlank(iamUserBassInfoVO.getOrgnztCd())) {
            MapsIamUtil.addOrgnztCd(iamUserBassInfoVO, loginInfo, mapsIamMobisUserService);
        }
        
        List<MapsIamUserBassInfoVO> lstUserBassInfo = mapsIamUserBassInfoMDAO.selectUserBassInfoPgList(iamUserBassInfoVO);
        
        return lstUserBassInfo;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#selectPopupUserBassInfoPgList(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserBassInfoVO> selectPopupUserBassInfoPgList(MapsIamUserBassInfoVO iamUserBassInfoVO
            , LoginInfoVO loginInfo) throws Exception {

        iamUserBassInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserBassInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        List<MapsIamUserBassInfoVO> lstUserBassInfo = mapsIamUserBassInfoMDAO.selectPopupUserBassInfoPgList(iamUserBassInfoVO);
        
        return lstUserBassInfo;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#selectUserBassInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsIamUserBassInfoVO selectUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO
            , LoginInfoVO loginInfo) throws Exception {

        iamUserBassInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserBassInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        MapsIamUserBassInfoVO iamUserBassInfo = mapsIamUserBassInfoMDAO.selectUserBassInfo(iamUserBassInfoVO);
        
        return iamUserBassInfo;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#multiUserBassInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiUserBassInfo(List<MapsIamUserBassInfoVO> userBassInfos, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        for (MapsIamUserBassInfoVO iamUserBassInfoVO : userBassInfos) {

            int rowType = iamUserBassInfoVO.getRowType();
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }
            
            switch (rowType) {
                case DataSet.ROW_TYPE_INSERTED:
                    // 사용자ID 자동채번 여부 취득
                    boolean isAutoUserId = MapsIamValidatorUtil.isAutoCountUserId(iamUserBassInfoVO.getOrgnztSeCd());
                    // 사용자 기본정보 등록정합성 체크
                    insertValidateUserBassInfo(iamUserBassInfoVO, isAutoUserId, loginInfo);

                    // 계정ID 자동 채번
                    if (isAutoUserId) {
                        String newUserBassId = insertUserIdSeq(iamUserBassInfoVO, loginInfo);
                        iamUserBassInfoVO.setUserBassId(newUserBassId);
                    }
                    
                    insertUserBassInfo(iamUserBassInfoVO, loginInfo);
                    break;
                case DataSet.ROW_TYPE_UPDATED:
                    
                    updateUserBassInfo(iamUserBassInfoVO, loginInfo);
                    break;
                case DataSet.ROW_TYPE_DELETED:
                    deleteUserBassInfo(iamUserBassInfoVO, loginInfo);
                    break;
            }
            procCnt++;
        }
        return procCnt;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#insertValidateUserBassInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, boolean, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public void insertValidateUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO
            , boolean isAutoUserId
            , LoginInfoVO loginInfo) throws Exception {
        
        //해당 서비스에 대한 권한이 없습니다.
        MapsIamValidatorUtil.validateOperatorUser(loginInfo);

        // 사용자기본ID은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserBassInfoVO.getUserBassId(), "WI000000019", loginInfo.getUserLcale());
        if (StringUtils.equalsIgnoreCase(iamUserBassInfoVO.getUserBassId(), MapsIamConstants.USER_BASS_ID_NEW)) {
            if (MapsIamValidatorUtil.isMobisOrgnzt(iamUserBassInfoVO.getOrgnztSeCd())) {
                // 사원번호로 사용자기본ID를 입력하세요.
                throw new MapsBizException(messageSource, "ECI0000079", loginInfo.getUserLcale(), null);
            }
            if (!iamUserBassInfoVO.getOrgnztSeCd().matches("G|N|D|E")) {
                // 사용할 수 없는 사용자기본ID입니다.
                throw new MapsBizException(messageSource, "ECI0000092", loginInfo.getUserLcale(), null);
            }
            iamUserBassInfoVO.setUserBassId(MapsIamConstants.USER_BASS_ID_NEW);
        } else {
            if (isAutoUserId) {
                // 사용자기본ID가 자동 생성 대상인 경우 사용자기본ID를 "NEW"로 입력해야합니다.
                throw new MapsBizException(messageSource, "ECI0000078", loginInfo.getUserLcale(), null);
            }
        }
        
        // 이메일은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserBassInfoVO.getEmail(), "W0000003560", loginInfo.getUserLcale());
        // 유효하지 않은 이메일 주소입니다.
        if (!ValidatorUtil.isEmail(iamUserBassInfoVO.getEmail())) {
            throw new MapsBizException(messageSource, "EC00000013", new String[]{iamUserBassInfoVO.getEmail()}, loginInfo.getUserLcale(), null);
            //throw new MapsBizException(MapsIamValidatorUtil.getMessageByWordId("EC00000013", W0000003560", loginInfo.getUserLcale()));    
        }
        
        // 사용자명은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserBassInfoVO.getUserNm(), "W0000003562", loginInfo.getUserLcale());
        
        // 조직정보 정합성 체크.
        MapsIamValidatorUtil.validateOrgnztInfo(iamUserBassInfoVO, loginInfo);
        
        // 사용자등록정보 체크.
        MapsIamUserBassInfoVO rsltUserBassInfo = selectHasUserBassInfo(iamUserBassInfoVO);
        if (rsltUserBassInfo != null && StringUtils.isNotBlank(rsltUserBassInfo.getUserBassId())) {
            throw new MapsBizException(messageSource, "ECI0000043", loginInfo.getUserLcale(), null);    // 사용자기본정보는 이미 등록되어 있습니다.
        }
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#updateValidateUserBassInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public void updateValidateUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO
            , LoginInfoVO loginInfo) throws Exception {

        //해당 서비스에 대한 권한이 없습니다.
        MapsIamValidatorUtil.validateOperatorUser(loginInfo);
        
        // 사용자기본정보 조회
        MapsIamUserBassInfoVO rsltUserBassInfo = selectUserBassInfo(iamUserBassInfoVO, loginInfo);
        if (rsltUserBassInfo == null) {
            //등록된 사용자기본정보가 없습니다.
            throw new MapsBizException(messageSource, "ECI0000044", loginInfo.getUserLcale(), null);
        }

        // 이메일은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserBassInfoVO.getEmail(), "W0000003560", loginInfo.getUserLcale());
        // 유효하지 않은 이메일 주소입니다.
        if (!ValidatorUtil.isEmail(iamUserBassInfoVO.getEmail())) {
            throw new MapsBizException(messageSource, "EC00000013", new String[]{iamUserBassInfoVO.getEmail()}, loginInfo.getUserLcale(), null);
        }
        
        // 사용자명은 필수 항목입니다.
        MapsIamValidatorUtil.validateRequired(iamUserBassInfoVO.getUserNm(), "W0000003562", loginInfo.getUserLcale());
        
        // 조직정보 정합성 체크
        MapsIamValidatorUtil.validateOrgnztInfo(iamUserBassInfoVO, loginInfo);
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#deleteValidateUserBassInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsIamUserBassInfoVO deleteValidateUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO
            , LoginInfoVO loginInfo) throws Exception {

        //해당 서비스에 대한 권한이 없습니다.
        MapsIamValidatorUtil.validateOperatorUser(loginInfo);
        
        // 사용자기본정보 조회
        MapsIamUserBassInfoVO rsltUserBassInfo = selectUserBassInfo(iamUserBassInfoVO, loginInfo);
        if (rsltUserBassInfo == null) {
            //등록된 사용자기본정보가 없습니다.
            throw new MapsBizException(messageSource, "ECI0000044", loginInfo.getUserLcale(), null);
        }
        
        return rsltUserBassInfo;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#selectHasUserBassInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO)
     */
    @Override
    public MapsIamUserBassInfoVO selectHasUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO) throws Exception {
        
        return mapsIamUserBassInfoMDAO.selectHasUserBassInfo(iamUserBassInfoVO);
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#insertUserIdSeq(com.mobis.maps.iam.vo.MapsIamUserOrgnztVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public String insertUserIdSeq(MapsIamUserOrgnztVO iamUserOrgnztVO, LoginInfoVO loginInfo) throws Exception {
        
        MapsIamUserIdSeqVO mapsIamUserIdSeqVO = new MapsIamUserIdSeqVO();
        mapsIamUserIdSeqVO.setOrgnztSeCd(iamUserOrgnztVO.getOrgnztSeCd());
        mapsIamUserIdSeqVO.setBsnOrgnztCd(iamUserOrgnztVO.getBsnOrgnztCd());
        mapsIamUserIdSeqVO.setOrgnztCd(iamUserOrgnztVO.getOrgnztCd());
        mapsIamUserIdSeqVO.setDealerCd(iamUserOrgnztVO.getDealerCd());
        mapsIamUserIdSeqVO.setRegistId(loginInfo.getUserSeqId());
        mapsIamUserIdSeqVO.setUpdtId(loginInfo.getUserSeqId());
        
        mapsIamUserBassInfoMDAO.insertUserIdSeq(mapsIamUserIdSeqVO);
     
        return mapsIamUserIdSeqVO.getUserId();
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#insertUserBassInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int insertUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception {
        
        /* 사용자기본정보 등록 */
        //사용자기본정보 등록
        iamUserBassInfoVO.setRegistId(loginInfo.getUserSeqId());
        iamUserBassInfoVO.setUpdtId(loginInfo.getUserSeqId());
        mapsIamUserBassInfoMDAO.insertUserBassInfo(iamUserBassInfoVO);

        //사용자기본정보 변경이력 등록
        insertUserBassChghst(MapsConstants.CRUD_CREATE, iamUserBassInfoVO, loginInfo);
            
        return 1;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#updateUserBassInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;

        updateValidateUserBassInfo(iamUserBassInfoVO, loginInfo);
        
        iamUserBassInfoVO.setRegistId(loginInfo.getUserSeqId());
        iamUserBassInfoVO.setUpdtId(loginInfo.getUserSeqId());
        procCnt = mapsIamUserBassInfoMDAO.updateUserBassInfo(iamUserBassInfoVO);
        if (procCnt != 1) {
            //수정된 사용자기본정보가 없습니다.
            throw new MapsBizException(messageSource, "ECI0000045", loginInfo.getUserLcale(), null);
        }

        //사용자기본정보 변경이력 등록
        insertUserBassChghst(MapsConstants.CRUD_UPDATE, iamUserBassInfoVO, loginInfo);
        
        return 1;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#updateLoginUserBassInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int updateLoginUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO
            , LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        /* 사용자기본정보 정합성 체크 */
        // 본인이 아닙니다.
        if (!StringUtils.equals(loginInfo.getUserBassId(), iamUserBassInfoVO.getUserBassId())) {
            throw new MapsBizException(messageSource, "ECI0000052", loginInfo.getUserLcale(), null);
        }
        // 사용자기본정보 조회
        MapsIamUserBassInfoVO rsltUserBassInfo = selectUserBassInfo(iamUserBassInfoVO, loginInfo);
        if (rsltUserBassInfo == null) {
            //등록된 사용자기본정보가 없습니다.
            throw new MapsBizException(messageSource, "ECI0000044", loginInfo.getUserLcale(), null);
        }
        /* 사용자기본정보 수정 항목 설정 */
        String[] colNms = new String[]{
            "moblphonNo", "offmTelno", "faxTelno"
        };
        for (String colNm: colNms) {
            String sOrigin = BeanUtils.getProperty(rsltUserBassInfo, colNm);
            String sTarget = BeanUtils.getProperty(iamUserBassInfoVO, colNm);
            if (!StringUtils.equals(sOrigin, sTarget)) {
                BeanUtils.setProperty(rsltUserBassInfo, colNm, sTarget);
                iamUserBassInfoVO.setRowType(DataSet.ROW_TYPE_UPDATED);
            }
        }
        // 수정된 사용자기본정보가 없습니다.
        if (iamUserBassInfoVO.getRowType() != DataSet.ROW_TYPE_UPDATED) {
            throw new MapsBizException(messageSource, "ECI0000045", loginInfo.getUserLcale(), null);
        }
        rsltUserBassInfo.setUpdtId(loginInfo.getUserSeqId());
        
        /* 사용자기본정보 수정 */
        procCnt = mapsIamUserBassInfoMDAO.updateUserBassInfo(rsltUserBassInfo);
        if (procCnt != 1) {
            //수정된 사용자기본정보가 없습니다.
            throw new MapsBizException(messageSource, "ECI0000045", loginInfo.getUserLcale(), null);
        }

        //사용자기본정보 변경이력 등록
        insertUserBassChghst(MapsConstants.CRUD_UPDATE, rsltUserBassInfo, loginInfo);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#deleteUserBassInfo(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int deleteUserBassInfo(MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception {
        
        int procCnt = 0;
        
        MapsIamUserBassInfoVO rsltUserBassInfo = deleteValidateUserBassInfo(iamUserBassInfoVO, loginInfo);
        
        procCnt = mapsIamUserBassInfoMDAO.updateDeleteUserBassInfo(iamUserBassInfoVO);
        //procCnt = mapsIamUserBassInfoMDAO.deleteUserBassInfo(iamUserBassInfoVO);
        if (procCnt != 1) {
            //삭제된 사용자기본정보가 없습니다.
            throw new MapsBizException(messageSource, "ECI0000046", loginInfo.getUserLcale(), null);
        }

        //사용자기본정보 변경이력 등록
        insertUserBassChghst(MapsConstants.CRUD_DELETE, rsltUserBassInfo, loginInfo);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#selectUserBassChghstPgList(com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamUserBassInfoVO> selectUserBassChghstPgList(MapsIamUserBassInfoVO iamUserBassInfoVO,
            LoginInfoVO loginInfo) throws Exception {

        iamUserBassInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamUserBassInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        List<MapsIamUserBassInfoVO> lstUserBassChghst = mapsIamUserBassInfoMDAO.selectUserBassChghstPgList(iamUserBassInfoVO);
        
        return lstUserBassChghst;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamUserBassInfoService#insertUserBassChghst(java.lang.String, com.mobis.maps.iam.vo.MapsIamUserBassInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public void insertUserBassChghst(String changeSeCd, MapsIamUserBassInfoVO iamUserBassInfoVO, LoginInfoVO loginInfo) throws Exception {
        
        iamUserBassInfoVO.setChangeSeCd(changeSeCd);
        iamUserBassInfoVO.setChangeId(loginInfo.getUserSeqId());
        mapsIamUserBassInfoMDAO.insertUserBassChghst(iamUserBassInfoVO);
    }

}
