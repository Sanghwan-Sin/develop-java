package com.mobis.maps.comm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommMailSendingLogService;
import com.mobis.maps.comm.service.dao.MapsCommMailSendingLogMDAO;
import com.mobis.maps.comm.vo.MapsCommMailSendingLogVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommMailSendingLogServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 1.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 1.     jiyongdo     	최초 생성
 * </pre>
 */
@Service("mapsCommMailSendingLogService")
public class MapsCommMailSendingLogServiceImpl extends HService implements MapsCommMailSendingLogService{
    
    @Resource(name="mapsCommMailSendingLogMDAO")
    private MapsCommMailSendingLogMDAO mapsCommMailSendingLogMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommMailSendingLogService#selectMailLoggingList(com.mobis.maps.comm.vo.MapsCommMailSendingLogVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommMailSendingLogVO> selectMailLoggingList(MapsCommMailSendingLogVO loggingVO, LoginInfoVO loginInfo) throws Exception {
        
        List<MapsCommMailSendingLogVO> lstMailLog = mapsCommMailSendingLogMDAO.selectMailLoggingList(loggingVO);
        return lstMailLog;
    }
}
