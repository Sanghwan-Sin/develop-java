package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.service.dao.MapsIamMobisUserMDAO;
import com.mobis.maps.iam.vo.MapsIamMobisOrgnztVO;
import com.mobis.maps.iam.vo.MapsIamMobisUserVO;
import com.mobis.maps.iam.vo.MapsIamUserOrgnztVO;

/**
 * <pre>
 * 모비스사용자 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamMobisUserServiceImpl.java
 * @Description : 모비스사용자에 대한 서비스를 구현.
 * @author DT048058
 * @since 2020. 4. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 17.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsIamMobisUserService")
public class MapsIamMobisUserServiceImpl extends HService implements MapsIamMobisUserService {

    @Resource(name = "mapsIamMobisUserMDAO")
    private MapsIamMobisUserMDAO mapsIamMobisUserDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamMobisUserService#selectMobisOrgnztTreeList(com.mobis.maps.iam.vo.MapsIamMobisOrgnztVO)
     */
    @Override
    public List<MapsIamMobisOrgnztVO> selectMobisOrgnztTreeList(MapsIamMobisOrgnztVO iamMobisOrgnztVO) throws Exception {

        List<MapsIamMobisOrgnztVO> lstMobisOrgnzt = mapsIamMobisUserDAO.selectMobisOrgnztTreeList(iamMobisOrgnztVO);
        
        return lstMobisOrgnzt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamMobisUserService#selectMobisUserPgList(com.mobis.maps.iam.vo.MapsIamMobisUserVO)
     */
    @Override
    public List<MapsIamMobisUserVO> selectMobisUserPgList(MapsIamMobisUserVO iamMobisUserVO) throws Exception {

        List<MapsIamMobisUserVO> lstMobisUser = mapsIamMobisUserDAO.selectMobisUserPgList(iamMobisUserVO);
        
        return lstMobisUser;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamMobisUserService#selectMobisUserTreeList(com.mobis.maps.iam.vo.MapsIamMobisUserVO)
     */
    @Override
    public List<MapsIamMobisUserVO> selectMobisUserTreeList(MapsIamMobisUserVO iamMobisUserVO) throws Exception {

        List<MapsIamMobisUserVO> lstMobisUser = mapsIamMobisUserDAO.selectMobisUserTreeList(iamMobisUserVO);
        
        return lstMobisUser;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamMobisUserService#selectOrgnztDistInfoList(com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsOrgnztDistVO> selectOrgnztDistInfoList(LoginInfoVO loginInfoVO) throws Exception {

        List<MapsOrgnztDistVO> lstMobisOrgnzt = mapsIamMobisUserDAO.selectOrgnztDistInfoList(loginInfoVO);
        
        return lstMobisOrgnzt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamMobisUserService#selectDistKdGrpList(com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsOrgnztDistVO> selectDistKdGrpList(LoginInfoVO loginInfoVO) throws Exception {
        
        List<MapsOrgnztDistVO> lstDistOrgnzt = mapsIamMobisUserDAO.selectDistKdGrpList(loginInfoVO);
        
        return lstDistOrgnzt;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamMobisUserService#selectDistOrgnztInfo(com.mobis.maps.iam.vo.MapsIamUserOrgnztVO)
     */
    @Override
    public MapsOrgnztDistVO selectDistOrgnztInfo(MapsIamUserOrgnztVO iamUserOrgnztVO) throws Exception {
        
        MapsOrgnztDistVO orgnztDistVO = mapsIamMobisUserDAO.selectDistOrgnztInfo(iamUserOrgnztVO);
        
        return orgnztDistVO;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamMobisUserService#selectCboSjWordNm(java.lang.String, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsOrgnztDistVO selectCboSjWordNm(String cboSjTy, LoginInfoVO loginInfoVO) throws Exception {

        MapsCommCodeVO commCodeVO = new MapsCommCodeVO();
        commCodeVO.setCboSjTy(cboSjTy);
        commCodeVO.setLangCd(loginInfoVO.getLangCd());
        
        MapsOrgnztDistVO cboSjOrgnzt = mapsIamMobisUserDAO.selectCboSjWordNm(commCodeVO);
        
        return cboSjOrgnzt;
    }

}
