package com.mobis.maps.sapjco.manager;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.mobis.maps.sapjco.common.function.ThrowableBiConsumer;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FunctionResult.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 5. 8.     DT045877     	최초 생성
 * </pre>
 */
public class FunctionResult {

    final JCoDestination destination;
    final JCoFunction function;

    /**
     * @param jCoFunction
     * @see SapFunctionFunction
     */
    FunctionResult(JCoFunction function, JCoDestination destination) {
        this.destination = destination;
        this.function = function;
    }

    public String getMessageServerInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append(destination.getMessageServerHost());
        sb.append(":");
        sb.append(destination.getMessageServerService());
        sb.append("|");
        sb.append(destination.getR3Name());
        sb.append("|");
        sb.append(destination.getClient());
        sb.append("|");
        sb.append(destination.getLanguage());
        return sb.toString();
    }

    public String getMessageServerHost() {
        StringBuilder sb = new StringBuilder();
//        sb.append("ApplicationServerHost=" + destination.getApplicationServerHost());
//        sb.append(",GatewayHost=" + destination.getGatewayHost());
//        sb.append(",MessageServerHost=" + destination.getMessageServerHost());
//        sb.append(",TPHost=" + destination.getTPHost());
        sb.append(destination.getMessageServerHost());
        sb.append(":");
        sb.append(destination.getMessageServerService());
        return sb.toString();
    }
    
    public String getR3Name() {
        return destination.getR3Name();
    }
    
    public String getClient() {
        return destination.getClient();
    }
    
    public String getLanguage() {
        return destination.getLanguage();
    }
    
    /**
     * get Function Name
     *
     * @return
     */
    public String getName() {
        return function.getName();
    }

    /**
     * get export parameters
     * @return
     */
    public JCoParameterList getExportParameterList() {
        return function.getExportParameterList();
    }

    /**
     * get table parameters
     * @return
     */
    public JCoParameterList getTableParameterList() {
        return function.getTableParameterList();
    }
    
    /**
     * get structure that will imported
     *
     * @param structureName
     * @return
     */
    public JCoStructure getExportStructure(String structureName) {
        return getExportParameterList().getStructure(structureName);
    }
    
    /**
     * get result table count
     * @return
     */
    public int getTableCount() {
        return function.getTableParameterList().getFieldCount();
    }
    
    /**
     * get table by index
     * @param index
     * @return
     */
    public JCoTable getJCoTable(int index) {
        return function.getTableParameterList().getTable(index);
    }
    
    /**
     * get table by name
     * @param name
     * @return
     */
    public JCoTable getJCoTable(String name) {
        return function.getTableParameterList().getTable(name);
    }
    
    /**
     * get map list table
     * @param index
     * @return
     */
    public List<Map<String, Object>> getTable(int index) {
        return Util.toMapList(function.getTableParameterList().getTable(index));
    }
    
    /**
     * get map list table
     * @param name
     * @return
     */
    public List<Map<String, Object>> getTable(String name) {
        return Util.toMapList(function.getTableParameterList().getTable(name));
    }
    
    /**
     * get custom class table
     * @param index
     * @param createRow
     * @param bindField
     * @return
     */
    public <R> List<R> getTable(int index, Supplier<R> createRow, ThrowableBiConsumer<R, JCoField> bindField) {
        return Util.toClass(function.getTableParameterList().getTable(index), createRow, bindField);
    }
    
    /**
     * get custom class table
     * @param name
     * @param createRow
     * @param bindField
     * @return
     */
    public <R> List<R> getTable(String name, Supplier<R> createRow, ThrowableBiConsumer<R, JCoField> bindField) {
        return Util.toClass(function.getTableParameterList().getTable(name), createRow, bindField);
    }
    
    /**
     * get all tables
     * @return
     */
    public List<List<Map<String, Object>>> getAllTables() {
        return IntStream.range(0, getTableCount()).mapToObj(e -> getTable(e)).collect(Collectors.toList());
    }
}