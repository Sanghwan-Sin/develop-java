package com.mobis.maps.cmmn.excel;

import java.util.List;
/**
 * <pre>
 * Excel 에 한 행(Row)의 데이터를 담을 클래스
 * </pre>
 *
 * @ClassName   : Row.java
 * @Description : Excel 에 한 행(Row)의 데이터를 담을 클래스
 * @author oh.dongwon
 * @since 2018. 5. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2018. 5. 18.     oh.dongwon     	최초 생성
 * </pre>
 */
public class Row {

	private final List<String> values;

	public Row(List<String> values) {
		this.values = values;
	}

	public String getValue(int cellIndex) {
		return values.get(cellIndex);
	}

	public Integer getIntegerValue(int cellIndex) {
		return Integer.parseInt(getValue(cellIndex));
	}

	public Long getLongValue(int cellIndex) {
		return Long.parseLong(getValue(cellIndex));
	}

	public Float getFloatValue(int cellIndex) {
		return Float.parseFloat(getValue(cellIndex));
	}

	public Boolean getBooleanValue(int cellIndex) {
		return Boolean.valueOf(getValue(cellIndex));
	}

}
