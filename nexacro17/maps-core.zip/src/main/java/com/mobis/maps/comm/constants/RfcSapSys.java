package com.mobis.maps.comm.constants;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.vo.CodeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : RfcSystem.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2019. 12. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 23.     DT048058     	최초 생성
 * </pre>
 */

public enum RfcSapSys {
    
      PC("S/4HANA", "sapcode.pc.sys.id", "sapcode.pc.sys.client", "domncode.pc.sys.id", "domncode.pc.sys.client")    // S/4HANA 서버
    , PW("eWM", "sapcode.pw.sys.id", "sapcode.pw.sys.client", "domncode.pw.sys.id", "domncode.pw.sys.client")        // eWM 서버
    , PS("SPP", "sapcode.ps.sys.id", "sapcode.ps.sys.client", "domncode.ps.sys.id", "domncode.ps.sys.client")        // SPP 서버
    ;

    private String serverNm;
    private String propKeySysId;
    private String propKeyClient;
    private String porpKeyDomainSysId;
    private String porpKeyDomainClient;
    private RfcSapSys(String serverNm, String propKeySysId, String propKeyClient, String porpKeyDomainSysId, String porpKeyDomainClient) {
        this.serverNm = serverNm;
        this.propKeySysId = propKeySysId;
        this.propKeyClient = propKeyClient;
        this.porpKeyDomainSysId = porpKeyDomainSysId;
        this.porpKeyDomainClient = porpKeyDomainClient;
    }
    
    public static RfcSapSys get(String name) {

        for (RfcSapSys rfcSapSys: values()) {
            if (StringUtils.equals(name, rfcSapSys.name()) || StringUtils.startsWith(name, rfcSapSys.name())) {
                return rfcSapSys;
            }
        }
        return null;
    }
    
    public String getSysId() {
        return PropertiesUtil.getString(getPropKeySysId());
    }
    
    public String getClient() {
        return PropertiesUtil.getString(getPropKeyClient());
    }
    
    public String getDomainSysId() {
        return PropertiesUtil.getString(getPorpKeyDomainSysId());
    }
    
    public String getDomainClient() {
        return PropertiesUtil.getString(getPorpKeyDomainClient());
    }
    
    public static List<CodeVO> getCodeList() {
        
        List<CodeVO> codes = new ArrayList<CodeVO>();
        for (RfcSapSys rfcSapSys: values()) {
            CodeVO code = new CodeVO();
            code.setCode(rfcSapSys.name());
            code.setCodeNm(rfcSapSys.getServerNm());
            
            codes.add(code);
        }
        
        return codes;
    }
    
    public static List<CodeVO> getRfcCodeList() {
        
        List<CodeVO> codes = new ArrayList<CodeVO>();
        for (RfcSapSys rfcSapSys: values()) {
            CodeVO code = new CodeVO();
            code.setCode(rfcSapSys.getSysId());
            code.setCodeNm(rfcSapSys.getServerNm());
            
            codes.add(code);
        }
        
        return codes;
    }

    /**
     * @return the serverNm
     */
    public String getServerNm() {
        return serverNm;
    }

    /**
     * @return the propKeySysId
     */
    public String getPropKeySysId() {
        return propKeySysId;
    }

    /**
     * @return the propKeyClient
     */
    public String getPropKeyClient() {
        return propKeyClient;
    }

    /**
     * @return the porpKeyDomainSysId
     */
    public String getPorpKeyDomainSysId() {
        return porpKeyDomainSysId;
    }

    /**
     * @return the porpKeyDomainClient
     */
    public String getPorpKeyDomainClient() {
        return porpKeyDomainClient;
    }
    
}
