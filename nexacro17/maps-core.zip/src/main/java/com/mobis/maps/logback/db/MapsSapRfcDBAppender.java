package com.mobis.maps.logback.db;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ArrayUtils;

import com.mobis.maps.logback.db.names.MapsSapRfcDBNameResolver;

import ch.qos.logback.classic.db.names.DBNameResolver;
import ch.qos.logback.classic.spi.CallerData;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.StackTraceElementProxy;
import ch.qos.logback.classic.spi.ThrowableProxyUtil;
import ch.qos.logback.core.CoreConstants;
import ch.qos.logback.core.db.DBAppenderBase;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSapRfcDBAppender.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 1. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 7.     DT048058     	최초 생성
 * </pre>
 */

public class MapsSapRfcDBAppender extends DBAppenderBase<ILoggingEvent> {
    
    protected String insertPropertiesSQL;
    protected String insertExceptionSQL;
    protected String insertSQL;
    protected static final Method GET_GENERATED_KEYS_METHOD;

    private DBNameResolver dbNameResolver;


    static final int INDEX_SYS_ID = 1;          // 시스템ID
    static final int INDEX_RFC_ID = 2;          // RFC ID
    static final int INDEX_RFC_SERVER = 3;      // RFC서버
    static final int INDEX_RFC_CLIENT = 4;      // CLIENT
    static final int INDEX_RFC_LANG = 5;        // 언어
    static final int INDEX_SCRIN_ID = 6;        // 화면ID
    static final int INDEX_USER_ID = 7;         // 사용자ID
    static final int INDEX_LGI_IP_ADRES = 8;    // 로그인IP주소
    static final int INDEX_THREAD_NM = 9;       // 스레드명
    static final int INDEX_LOG_LEVEL = 10;      // 로그레벨
    static final int INDEX_LOG_IPTT = 11;       // 로그입출력
    static final int INDEX_LOG_MSG = 12;        // 로그메세지
    static final int INDEX_LOG_DT = 13;         // 로그일시
    static final int INDEX_EVENT_ID= 14;        // 로그순번
    
    static final StackTraceElement EMPTY_CALLER_DATA = CallerData.naInstance();

    static {
        // PreparedStatement.getGeneratedKeys() method was added in JDK 1.4
        Method getGeneratedKeysMethod;
        try {
            // the
            getGeneratedKeysMethod = PreparedStatement.class.getMethod("getGeneratedKeys", (Class[]) null);
        } catch (Exception ex) {
            getGeneratedKeysMethod = null;
        }
        GET_GENERATED_KEYS_METHOD = getGeneratedKeysMethod;
    }

    public void setDbNameResolver(DBNameResolver dbNameResolver) {
        this.dbNameResolver = dbNameResolver;
    }

    @Override
    public void start() {
        if (dbNameResolver == null) {
            dbNameResolver = new MapsSapRfcDBNameResolver();
        }
        //System.out.println("→ MapsSapRfcDBAppender::start.start");
        insertExceptionSQL = MapsSapRfcSQLBuilder.buildInsertExceptionSQL(dbNameResolver);
        //System.out.println("→ MapsSapRfcDBAppender::start["+insertExceptionSQL+"]");
        insertPropertiesSQL = MapsSapRfcSQLBuilder.buildInsertPropertiesSQL(dbNameResolver);
        //System.out.println("→ MapsSapRfcDBAppender::start["+insertPropertiesSQL+"]");
        insertSQL = MapsSapRfcSQLBuilder.buildInsertSQL(dbNameResolver);
        //System.out.println("→ MapsSapRfcDBAppender::start["+insertSQL+"]");
        super.start();
        //System.out.println("→ MapsSapRfcDBAppender::start.end");
    }

    @Override
    protected void subAppend(ILoggingEvent event
            , Connection connection
            , PreparedStatement insertStatement) throws Throwable {

        //System.out.println("→ MapsSapRfcDBAppender::subAppend.start");
        Object[] argArray = event.getArgumentArray();
        if (ArrayUtils.isEmpty(argArray) || argArray.length != 9) {
            return;
        }
        bindLoggingEventWithInsertStatement(insertStatement, event);
        bindLoggingEventArgumentsWithPreparedStatement(insertStatement, argArray);

        // This is expensive... should we do it every time?
        bindCallerDataWithPreparedStatement(insertStatement, event.getCallerData());
        try {
            int updateCount = insertStatement.executeUpdate();
            //System.out.println("→ MapsSapRfcDBAppender::subAppend::insertStatement.end[updateCount="+updateCount+"]");
            if (updateCount != 1) {
                addWarn("Failed to insert loggingEvent");
            }
        } catch (Exception e) {
            //System.out.println("→ MapsSapRfcDBAppender::subAppend::error[message="+e.getMessage()+"]");
            e.printStackTrace();
            throw e;
        }
        //System.out.println("→ MapsSapRfcDBAppender::subAppend.end");
    }

    protected void secondarySubAppend(ILoggingEvent event, Connection connection, long eventId) throws Throwable {
        //System.out.println("→ MapsSapRfcDBAppender::secondarySubAppend.start[eventId="+eventId+"]");
        Map<String, String> mergedMap = mergePropertyMaps(event);
        insertProperties(mergedMap, connection, eventId);

        if (event.getThrowableProxy() != null) {
            insertThrowable(event.getThrowableProxy(), connection, eventId);
        }
        //System.out.println("→ MapsSapRfcDBAppender::secondarySubAppend.end");
    }

    void bindLoggingEventWithInsertStatement(PreparedStatement stmt, ILoggingEvent event) throws SQLException {
        //System.out.println("→ MapsSapRfcDBAppender::bindLoggingEventWithInsertStatement.start");
        stmt.setString(INDEX_LOG_MSG, event.getFormattedMessage());
        stmt.setString(INDEX_LOG_LEVEL, event.getLevel().toString());
        stmt.setString(INDEX_THREAD_NM, event.getThreadName());
        stmt.setTimestamp(INDEX_LOG_DT, new Timestamp(event.getTimeStamp()));
        //System.out.println("→ MapsSapRfcDBAppender::bindLoggingEventWithInsertStatement.end");
    }
    
    void bindLoggingEventArgumentsWithPreparedStatement(PreparedStatement stmt, Object[] argArray) throws SQLException {
        //System.out.println("→ MapsSapRfcDBAppender::bindLoggingEventArgumentsWithPreparedStatement.start");
        int arrayLen = argArray != null ? argArray.length : 0;

        for (int i = 0; i < arrayLen && i < 9; i++) {
            int idx = -1;
            String val = asStringTruncatedTo254(argArray[i]);
            switch (i) {
                case 0 :
                    idx = INDEX_SYS_ID;
                    break;
                case 1 :
                    idx = INDEX_RFC_ID;
                    break;
                case 2 :
                    idx = INDEX_LOG_IPTT;
                    break;
                case 3 :
                    idx = INDEX_RFC_SERVER;
                    break;
                case 4 :
                    idx = INDEX_RFC_CLIENT;
                    break;
                case 5 :
                    idx = INDEX_RFC_LANG;
                    break;
                case 6 :
                    idx = INDEX_SCRIN_ID;
                    break;
                case 7 :
                    idx = INDEX_USER_ID;
                    break;
                case 8 :
                    idx = INDEX_LGI_IP_ADRES;
                    break;
                default :
                    continue;
            }
            //System.out.println("→ MapsSapRfcDBAppender::bindLoggingEventArgumentsWithPreparedStatement["+idx+"]["+val+"]");
            stmt.setString(idx, val);
        }
        //System.out.println("→ MapsSapRfcDBAppender::bindLoggingEventArgumentsWithPreparedStatement.end");
    }

    String asStringTruncatedTo254(Object o) {
        String s = null;
        if (o != null) {
            s = o.toString();
        }

        if (s == null) {
            return null;
        }
        if (s.length() <= 254) {
            return s;
        } else {
            return s.substring(0, 254);
        }
    }

    void bindCallerDataWithPreparedStatement(PreparedStatement stmt
            , StackTraceElement[] callerDataArray) throws SQLException {
        //System.out.println("→ MapsSapRfcDBAppender::bindCallerDataWithPreparedStatement.start");

        StackTraceElement caller = extractFirstCaller(callerDataArray);
        //System.out.println("→ MapsSapRfcDBAppender::bindCallerDataWithPreparedStatement["+caller.getClassName()+"]");

//        stmt.setString(CALLER_FILENAME_INDEX, caller.getFileName());
//        stmt.setString(CALLER_CLASS_INDEX, caller.getClassName());
//        stmt.setString(CALLER_METHOD_INDEX, caller.getMethodName());
//        stmt.setString(CALLER_LINE_INDEX, Integer.toString(caller.getLineNumber()));
        //System.out.println("→ MapsSapRfcDBAppender::bindCallerDataWithPreparedStatement.end");
    }

    private StackTraceElement extractFirstCaller(StackTraceElement[] callerDataArray) {
        //System.out.println("→ MapsSapRfcDBAppender::extractFirstCaller.start");
        StackTraceElement caller = EMPTY_CALLER_DATA;
        if (hasAtLeastOneNonNullElement(callerDataArray)) {
            caller = callerDataArray[0];
        }
        //System.out.println("→ MapsSapRfcDBAppender::extractFirstCaller.end");
        return caller;
    }

    private boolean hasAtLeastOneNonNullElement(StackTraceElement[] callerDataArray) {
        return callerDataArray != null && callerDataArray.length > 0 && callerDataArray[0] != null;
    }

    Map<String, String> mergePropertyMaps(ILoggingEvent event) {
        Map<String, String> mergedMap = new HashMap<String, String>();
        // we add the context properties first, then the event properties, since
        // we consider that event-specific properties should have priority over
        // context-wide properties.
        Map<String, String> loggerContextMap = event.getLoggerContextVO().getPropertyMap();
        Map<String, String> mdcMap = event.getMDCPropertyMap();
        if (loggerContextMap != null) {
            mergedMap.putAll(loggerContextMap);
        }
        if (mdcMap != null) {
            mergedMap.putAll(mdcMap);
        }

        return mergedMap;
    }

    @Override
    protected Method getGeneratedKeysMethod() {
        return GET_GENERATED_KEYS_METHOD;
    }

    @Override
    protected String getInsertSQL() {
        return insertSQL;
    }

    protected void insertProperties(Map<String, String> mergedMap
            , Connection connection
            , long eventId) throws SQLException {
        //System.out.println("→ MapsSapRfcDBAppender::insertProperties.start[eventId="+eventId+"]");
        Set<String> propertiesKeys = mergedMap.keySet();
        if (propertiesKeys.size() > 0) {
            PreparedStatement insertPropertiesStatement = null;
            try {
                insertPropertiesStatement = connection.prepareStatement(insertPropertiesSQL);

                for (String key : propertiesKeys) {
                    //System.out.println("→ MapsSapRfcDBAppender::insertProperties.propertiesKeys[key="+key+"]");
                    String[] keys = StringUtils.split(key, "|");
                    String value = mergedMap.get(key);
                    //System.out.println("→ MapsSapRfcDBAppender::insertProperties.keys[0="+keys[0]+",0="+keys[1]+",0="+keys[2]+"]");

                    insertPropertiesStatement.setLong(1, eventId);
                    insertPropertiesStatement.setString(2, keys[0]);
                    insertPropertiesStatement.setString(3, keys[1]);
                    insertPropertiesStatement.setString(4, keys[2]);
                    insertPropertiesStatement.setString(5, value);
                    //System.out.println("→ MapsSapRfcDBAppender::insertProperties[key="+key+",insertPropertiesStatement="+insertPropertiesStatement+"]");

                    if (cnxSupportsBatchUpdates) {
                        insertPropertiesStatement.addBatch();
                    } else {
                        insertPropertiesStatement.execute();
                    }
                }

                if (cnxSupportsBatchUpdates) {
                    insertPropertiesStatement.executeBatch();
                }
            } catch (Exception e) {
                //System.out.println("→ MapsSapRfcDBAppender::insertProperties.error[message="+e.getMessage()+"]");
                e.printStackTrace();
                throw e;
            } finally {
                ch.qos.logback.core.db.DBHelper.closeStatement(insertPropertiesStatement);
            }
        }
        //System.out.println("→ MapsSapRfcDBAppender::insertProperties.end");
    }

    /**
     * Add an exception statement either as a batch or execute immediately if
     * batch updates are not supported.
     */
    void updateExceptionStatement(PreparedStatement exceptionStatement
            , String txt
            , short i
            , long eventId) throws SQLException {
        //System.out.println("→ MapsSapRfcDBAppender::updateExceptionStatement.start[eventId="+eventId+"]");
        exceptionStatement.setLong(1, eventId);
        exceptionStatement.setShort(2, i);
        exceptionStatement.setString(3, txt);
        if (cnxSupportsBatchUpdates) {
            exceptionStatement.addBatch();
        } else {
            exceptionStatement.execute();
        }
        //System.out.println("→ MapsSapRfcDBAppender::updateExceptionStatement.end[eventId="+eventId+"]");
    }

    short buildExceptionStatement(IThrowableProxy tp
            , short baseIndex
            , PreparedStatement insertExceptionStatement
            , long eventId) throws SQLException {
        //System.out.println("→ MapsSapRfcDBAppender::buildExceptionStatement.start[baseIndex="+baseIndex+",eventId="+eventId+"]");
        StringBuilder buf = new StringBuilder();
        ThrowableProxyUtil.subjoinFirstLine(buf, tp);
        updateExceptionStatement(insertExceptionStatement, buf.toString(), baseIndex++, eventId);

        int commonFrames = tp.getCommonFrames();
        StackTraceElementProxy[] stepArray = tp.getStackTraceElementProxyArray();
        for (int i = 0; i < stepArray.length - commonFrames; i++) {
            StringBuilder sb = new StringBuilder();
            sb.append(CoreConstants.TAB);
            ThrowableProxyUtil.subjoinSTEP(sb, stepArray[i]);
            updateExceptionStatement(insertExceptionStatement, sb.toString(), baseIndex++, eventId);
        }

        if (commonFrames > 0) {
            StringBuilder sb = new StringBuilder();
            sb.append(CoreConstants.TAB).append("... ").append(commonFrames).append(" common frames omitted");
            updateExceptionStatement(insertExceptionStatement, sb.toString(), baseIndex++, eventId);
        }
        //System.out.println("→ MapsSapRfcDBAppender::buildExceptionStatement.end[baseIndex="+baseIndex+",eventId="+eventId+"]");
        return baseIndex;
    }

    protected void insertThrowable(IThrowableProxy tp
            , Connection connection
            , long eventId) throws SQLException {
        //System.out.println("→ MapsSapRfcDBAppender::insertThrowable.start[eventId="+eventId+"]");
        PreparedStatement exceptionStatement = null;
        try {
            exceptionStatement = connection.prepareStatement(insertExceptionSQL);

            short baseIndex = 0;
            while (tp != null) {
                baseIndex = buildExceptionStatement(tp, baseIndex, exceptionStatement, eventId);
                tp = tp.getCause();
            }

            if (cnxSupportsBatchUpdates) {
                exceptionStatement.executeBatch();
            }
        } catch (Exception e) {
            //System.out.println("→ MapsSapRfcDBAppender::insertThrowable.error[eventId="+eventId+"]");
            e.printStackTrace();
            throw e;
        } finally {
            ch.qos.logback.core.db.DBHelper.closeStatement(exceptionStatement);
        }
        //System.out.println("→ MapsSapRfcDBAppender::insertThrowable.end[eventId="+eventId+"]");
    }
}
