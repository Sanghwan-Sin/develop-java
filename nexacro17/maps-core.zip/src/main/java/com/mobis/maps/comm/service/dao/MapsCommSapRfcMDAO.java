package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommSapRfcBassInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcIpttInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrFieldVO;
import com.mobis.maps.comm.vo.MapsCommSapRfcStrctrMstVO;

/**
 * <pre>
 * RFC 관리 데이터처리
 * </pre>
 *
 * @ClassName : MapsCommSapRfcMDAO.java
 * @Description : RFC 관리 데이터처리를 정의.
 * @author Sin Sanghwan
 * @since 2019. 8. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 26.     Sin Sanghwan     	최초 생성
 *               </pre>
 */
@Mapper("mapsCommSapRfcMDAO")
public interface MapsCommSapRfcMDAO {

    /**
     * RFC 정보 리스트를 조회한다
     *
     * @param commSapRfcInfoVO 
     * @return
     * @throws Exception
     */
    public List<MapsCommSapRfcBassInfoVO> selectSapRfcBassInfoPgList(MapsCommSapRfcInfoVO commSapRfcInfoVO) throws Exception;

    /**
     * RFC 정보를 조회한다
     *
     * @param commSapRfcBassInfoVO 
     * @return
     * @throws Exception
     */
    public MapsCommSapRfcBassInfoVO selectSapRfcBassInfo(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO) throws Exception;
    
    /**
     * RFC 정보 등록
     *
     * @param commSapRfcBassInfoVO 
     * @throws Exception
     */
    public void insertSapRfcBassInfo(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO) throws Exception;

    /**
     * RFC 정보 수정
     *
     * @param commSapRfcBassInfoVO 
     * @return
     * @throws Exception
     */
    public int updateSapRfcBassInfo(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO) throws Exception;

    /**
     * RFC 정보 삭제
     *
     * @param commSapRfcBassInfoVO 
     * @throws Exception
     */
     public int deleteSapRfcBassInfo(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO) throws Exception;

    /**
     * RFC ID에 해당하는 RFC 입출력정보 리스트를 조회한다
     *
     * @param commSapRfcIpttInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsCommSapRfcIpttInfoVO> selectSapRfcIpttInfoByRfcIdList(MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO) throws Exception;

    /**
     * RFC 입출력정보를 조회한다
     *
     * @param commSapRfcIpttInfoVO
     * @return
     * @throws Exception
     */
    public MapsCommSapRfcIpttInfoVO selectSapRfcIpttInfo(MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO) throws Exception;

    /**
     * RFC 입출력정보 등록
     *
     * @param commSapRfcIpttInfoVO
     * @throws Exception
     */
    public void insertSapRfcIpttInfo(MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO) throws Exception;

    /**
     * RFC 입출력정보 수정
     *
     * @param commSapRfcIpttInfoVO
     * @throws Exception
     */
    public int updateSapRfcIpttInfo(MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO) throws Exception;

    /**
     * RFC 입출력정보 삭제
     *
     * @param commSapRfcIpttInfoVO
     * @throws Exception
     */
    public int deleteSapRfcIpttInfo(MapsCommSapRfcIpttInfoVO commSapRfcIpttInfoVO) throws Exception;

    /**
     * RFC 입출력정보 삭제(전체)
     *
     * @param commSapRfcIpttInfoVO
     * @throws Exception
     */    public int deleteSapRfcIpttInfoAll(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO) throws Exception;

    /**
     * RFC아이디에 해당하는 RFC 구조체리스트를 조회한다
     *
     * @param commSapRfcIpttInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsCommSapRfcStrctrMstVO> selectSapRfcStrctrMstByRfcIdList(MapsCommSapRfcBassInfoVO commSapRfcBassInfoVO) throws Exception;

    /**
     * RFC 구조체마스터를 조회한다
     *
     * @param commSapRfcIpttInfoVO
     * @return
     * @throws Exception
     */
    public MapsCommSapRfcStrctrMstVO selectSapRfcStrctrMst(MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO) throws Exception;

    /**
     * RFC 구조체 등록
     *
     * @param commSapRfcStrctrMstVO
     * @throws Exception
     */
    public void insertSapRfcStrctrMst(MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO) throws Exception;

    /**
     * RFC 구조체 수정
     *
     * @param commSapRfcStrctrMstVO
     * @throws Exception
     */
    public int updateSapRfcStrctrMst(MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO) throws Exception;

    /**
     * RFC 구조체 삭제
     *
     * @param commSapRfcStrctrMstVO
     * @throws Exception
     */
    public int deleteSapRfcStrctrMst(MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO) throws Exception;

    /**
     * RFC아이디에 해당하는 RFC 구조체필드 리스트를 조회한다
     *
     * @param commSapRfcStrctrFieldVO
     * @return
     * @throws Exception
     */
    public List<MapsCommSapRfcStrctrFieldVO> selectSapRfcStrctrFieldByRfcIdList(MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO) throws Exception;

    /**
     * RFC 구조체필드 리스트를 조회한다
     *
     * @param commSapRfcIpttInfoVO
     * @return
     * @throws Exception
     */
    public List<MapsCommSapRfcStrctrFieldVO> selectSapRfcStrctrFieldList(MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO) throws Exception;
    
    /**
     * RFC 구조체필드를 조회한다
     *
     * @param commSapRfcStrctrFieldVO
     * @return
     * @throws Exception
     */
    public MapsCommSapRfcStrctrFieldVO selectSapRfcStrctrField(MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO) throws Exception;

    /**
     * RFC 구조체항목 등록
     *
     * @param commSapRfcStrctrFieldVO
     * @throws Exception
     */
    public void insertSapRfcStrctrField(MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO) throws Exception;

    /**
     * RFC 구조체항목 수정
     *
     * @param commSapRfcStrctrFieldVO
     * @throws Exception
     */
    public int updateSapRfcStrctrField(MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO) throws Exception;

    /**
     * RFC 구조체항목 삭제
     *
     * @param commSapRfcStrctrFieldVO
     * @throws Exception
     */
    public int deleteSapRfcStrctrField(MapsCommSapRfcStrctrFieldVO commSapRfcStrctrFieldVO) throws Exception;

    /**
     * RFC 구조체항목 삭제(전체)
     *
     * @param commSapRfcStrctrMstVO
     * @throws Exception
     */
    public int deleteSapRfcStrctrFieldAll(MapsCommSapRfcStrctrMstVO commSapRfcStrctrMstVO) throws Exception;
    
}