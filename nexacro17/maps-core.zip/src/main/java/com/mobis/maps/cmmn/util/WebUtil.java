package com.mobis.maps.cmmn.util;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Enumeration;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.ui.Model;

import com.mobis.maps.cmmn.spring.SpringApplicationContext;

/**
 * <pre>
 * Web유틸리티
 * </pre>
 *
 * @ClassName   : WebUtil.java
 * @Description : Web에 대한 유틸리티를 정의.
 * @author DT048058
 * @since 2020. 1. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 23.     DT048058     	최초 생성
 * </pre>
 */
public class WebUtil {

    protected static Logger logger = LoggerFactory.getLogger(WebUtil.class);
    /** 서버Profile(로컬) */
    public static final String SERVER_PROFILE_LOCAL = "LOCAL";
    /** 서버Profile(개발) */
    public static final String SERVER_PROFILE_DEVELOPE = "DEV";
    /** 서버Profile(품질) */
    public static final String SERVER_PROFILE_QUALITY = "QAS";
    /** 서버Profile(운영) */
    public static final String SERVER_PROFILE_PRODUCTION = "PRD";
    /** IP헤더(클라이언트IP취득용) */
    public static final String[] IP_HEADERS = {
          "X-Forwarded-For"
        , "Proxy-Client-IP"
        , "WL-Proxy-Client-IP"
        , "HTTP_CLIENT_IP"
        , "HTTP_X_FORWARDED_FOR"
        , "X-Real-IP"
        , "X-RealIP"
        , "REMOTE_ADDR"
    };

    /**
     *
     * 세션조회 및 Parameter 전달
     *
     * @param request
     * @return
     * @throws Exception
     */
    public static void getAuthByParameter(Model model, HttpServletRequest request) throws Exception {

        // Cookie를 읽어서 Cookie 배열로 반환
        Cookie[] cookies = request.getCookies();
        String browserScnCd = "html5";

        // 입력받은 쿠키명으로 비교해서 쿠키값을 얻어낸다.
        for (Cookie cookie : cookies) {

            if ("G_BROWSER_SCN_CD".equals(cookie.getName())) {
                browserScnCd = cookie.getValue();
                break;
            }
        }

        model.addAttribute("browserScnCd", browserScnCd);

        Enumeration<String> e = request.getParameterNames();
        while (e.hasMoreElements()) {
            String key = e.nextElement();
            String val = request.getParameter(key);
//            if (logger.isDebugEnabled()) {
//                logger.debug("start[{} : {}]", key, val);
//            }
            request.setAttribute(key, val);
//            if (logger.isDebugEnabled()) {
//                logger.debug("end[{} : {}]", key, request.getAttribute(key));
//            }
        }
    }

    /**
     * 인터넷 익스 플로러 체크
     *
     * @param request
     * @return
     */
    public static boolean checkMsie(HttpServletRequest request) {
        String header = request.getHeader("User-Agent");
        boolean result = false;
        // MSIE IE<=10, Trident = IE11
        if (header.indexOf("MSIE") > -1 || header.indexOf("Trident") > -1) {
            result = true;
        }
        return result;
    }
    
    /**
     * Index Url 취득
     *
     * @param request
     * @return
     */
    public static String getIndexUrl(HttpServletRequest request) {
        
        StringBuffer url = request.getRequestURL();
        String servletPath = request.getServletPath();
        int endIdx = url.indexOf(servletPath);

        StringBuilder sbUrl = new StringBuilder();
        sbUrl.append(url.substring(0, endIdx));
        
        return sbUrl.toString();
    }
    
    /**
     * User-Agent 취득
     *
     * @param request
     * @return
     */
    public static String getUserAgent(HttpServletRequest request) {

        return  StringUtils.defaultString(request.getHeader("User-Agent"));
    }

    /**
     * 브라우저명 취득
     *
     * @param request
     * @return
     */
    public static String getBrowserName(HttpServletRequest request) {
        
        String brwsrNm = "";
        
        String userAgent = StringUtil.upperCase(getUserAgent(request));
        if (userAgent.indexOf("NEXACROPLATFORM") > -1) {
            brwsrNm = "nexacro";
        } else if (userAgent.indexOf("MIPLATFORM") > -1) {
            brwsrNm = "mi";
        } else if (userAgent.indexOf("TRIDENT") > -1 || userAgent.indexOf("MSIE") > -1) {
            brwsrNm = "ie";
        } else if (userAgent.indexOf("EDGE") > -1) {
            brwsrNm = "edge";
        } else if (userAgent.indexOf("CHROME") > -1) {
            brwsrNm = "chrome";
        } else if (userAgent.indexOf("SAFARI") > -1) {
            brwsrNm = "safari";
        } else if (userAgent.indexOf("FIREFOX") > -1) {
            brwsrNm = "firefox";
        } else if (userAgent.indexOf("OPERA") > -1) {
            brwsrNm = "opera";
        } else {
            brwsrNm = "unknown";
        }
        return brwsrNm;
    }

    /**
     * 서버Profile 취득
     *
     * @return
     */
    public static String getServerProfile() {
        Environment env = SpringApplicationContext.getEnvironment();
        String[] profiles = env.getActiveProfiles();
        String serverProfl = "";
        for (String profile: profiles) {
            if (StringUtils.isNotBlank(profile)) {
                if ("prd".equals(profile)) {
                    serverProfl = SERVER_PROFILE_PRODUCTION;
                } else if ("qas".equals(profile)) {
                    serverProfl = SERVER_PROFILE_QUALITY;
                } else if ("dev".equals(profile)) {
                    serverProfl = SERVER_PROFILE_DEVELOPE;
                } else if ("local".equals(profile)) {
                    serverProfl = SERVER_PROFILE_LOCAL;
                    break;
                } else {
                    serverProfl = profile;
                }
            } else {
                serverProfl = SERVER_PROFILE_LOCAL;
                break;
            }
        }
        return serverProfl;
    }
    
    /**
     * 서버Profile 취득
     *
     * @param request
     * @return
     */
    public static String getServerProfile(HttpServletRequest request) {

        return getServerProfile(request.getServerName());
    }
    
    public static String getServerProfile(String serverNm) {
        
        String serverProfl = "";
        if (StringUtils.indexOf(serverNm, "localhost") > -1 || StringUtils.indexOf(serverNm, "127.0.0.1") > -1) {
            serverProfl = WebUtil.SERVER_PROFILE_LOCAL;
        } else if (StringUtils.indexOf(serverNm, "-qa.") > 0) {
            serverProfl = WebUtil.SERVER_PROFILE_QUALITY;
        } else if (StringUtils.indexOf(serverNm, "-dev.") > 0) {
            serverProfl = WebUtil.SERVER_PROFILE_DEVELOPE;
        } else {
            serverProfl = WebUtil.SERVER_PROFILE_PRODUCTION;
        }
        
        return serverProfl;
    }

    
    /**
     * Statements
     *
     * @param searchStr ex> "CONTEST"
     * @param delimStr  ex> "TESTUSER,SRSCONTEST"
     * searchStr : "CONTEST"     , delimStr  "TESTUSER,SRSCONTEST"  == > RETURN false
     * searchStr : "SRSCONTEST"  , delimStr  "TESTUSER,SRSCONTEST"  == > RETURN true 
     * 
     * @return 
     */
    public static boolean isMatchArryString(String searchStrIn, String delimStr ){
        // input str이나 조회값이 없으면
        String searchStr = StringUtils.upperCase(searchStrIn);
        if(StringUtils.isEmpty( searchStr ) || StringUtils.isEmpty( delimStr ) ){
            return false;
        }
        String [] spilitVal = StringUtils.split(delimStr, ",");
        for(int i = 0 ; i < spilitVal.length ; i++ ){
            String exStr = spilitVal[i];
            if( StringUtils.equals( searchStr , exStr  ) ){
                return true;
            }
        }
        return false;
    }
    
    /**
     * 사용자IP 취득
     *
     * @param request
     * @return
     */
    public static String getUserIpAdres(HttpServletRequest request) {

        String clientIp = null;
        
        for (String ipHeader: IP_HEADERS) {
            clientIp = request.getHeader(ipHeader);
            if (StringUtils.isBlank(clientIp)) {
                continue;
            }
            if ("unknown".equalsIgnoreCase(clientIp)) {
                continue;
            }
            if (StringUtils.contains(clientIp, ",")) {
                String[] clientIps = StringUtils.split(clientIp, ",");
                clientIp = clientIps[0];
            }
            return clientIp;
        }
        
        clientIp = request.getRemoteAddr();
        if ("0:0:0:0:0:0:0:1".equalsIgnoreCase(clientIp)) {
            InetAddress inetAddress = null;
            try {
                inetAddress = InetAddress.getLocalHost();
                clientIp = inetAddress.getHostAddress();
            } catch (UnknownHostException e) {}
        }
        
        return clientIp;
    }
    
    public static String getHeaderJsessionId(HttpServletRequest request) {
        return request.getHeader("JSESSIONID");
    }
}
