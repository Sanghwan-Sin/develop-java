package com.mobis.maps.cmmn.exception;

import org.springframework.validation.BindingResult;

/**
 * <pre>
 * Validation 예외처리
 * </pre>
 *
 * @ClassName   : ValidatorException.java
 * @Description : Validation에 대한 예외처리를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 10.     Sin Sanghwan     	최초 생성
 * </pre>
 */
public class ValidatorException extends Exception {

    /** (long)serialVersionUID */
    private static final long serialVersionUID = 3967397406565710989L;
    
    private BindingResult bindingResult;

    private boolean multiDisp;
    
    private String[] filters;

    public ValidatorException(BindingResult bindingResult) {
        super();
        this.bindingResult = bindingResult;
        this.multiDisp = false;
    }

    public ValidatorException(BindingResult bindingResult, boolean multiDisp) {
        super();
        this.bindingResult = bindingResult;
        this.multiDisp = multiDisp;
    }

    public ValidatorException(BindingResult bindingResult, boolean multiDisp, String[] filters) {
        this(bindingResult, multiDisp);
        this.filters = filters;
    }

    public ValidatorException(String defaultMessage) {
        super(defaultMessage);
    }

    /**
     * @return the bindingResult
     */
    public BindingResult getBindingResult() {
        return bindingResult;
    }
    /**
     * @return the multiDisp
     */
    public boolean isMultiDisp() {
        return multiDisp;
    }
    /**
     * @return the filters
     */
    public String[] getFilters() {
        return filters;
    }
}
