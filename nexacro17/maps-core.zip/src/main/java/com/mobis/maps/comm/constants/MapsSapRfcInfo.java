package com.mobis.maps.comm.constants;

/**
 * <pre>
 * RFC호출정보
 * </pre>
 *
 * @ClassName   : MapsSapRfcInfo.java
 * @Description : RFC호출 기본정보를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 19.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public enum MapsSapRfcInfo {
    
      ZPCA_CHNNL_R_FILE_CREATE_INFO("ZPCA_CHNNL_R_FILE_CREATE_INFO")
    , ZPCA_CHNNL_R_FILE_ITEM_SUM("ZPCA_CHNNL_R_FILE_ITEM_SUM")
    , ZPCA_CHNNL_R_FILE_ITEM_SUM2("ZPCA_CHNNL_R_FILE_ITEM_SUM2")
    , ZPCA_CHNNL_R_FILE_CONTENT("ZPCA_CHNNL_R_FILE_CONTENT")
    , ZPCA_CHNNL_R_FILE_COUNT("ZPCA_CHNNL_R_FILE_COUNT")
    , ZPCA_CHNNL_R_FILE_LIST("ZPCA_CHNNL_R_FILE_LIST")
    , ZPCA_CHNNL_R_FILE_CREATE("ZPCA_CHNNL_R_FILE_CREATE")
    , ZPCA_CHNNL_R_FILE_CHECK("ZPCA_CHNNL_R_FILE_CHECK")
    , ZPCA_CHNNL_R_FILE_UPDATE("ZPCA_CHNNL_R_FILE_UPDATE")
    , ZPCA_CHNNL_R_FILE_DELETE("ZPCA_CHNNL_R_FILE_DELETE")
    , ZPCA_CHNNL_R_FILE_DELETE_ALL("ZPCA_CHNNL_R_FILE_DELETE_ALL")
    , ZPCA_OZ_PRT_RFC_PARAM_ENCRYPT("ZPCA_OZ_PRT_RFC_PARAM_ENCRYPT")
    ;
    /** 인터페이스ID */
    private String ifCode;
    
    private MapsSapRfcInfo(String ifCode) {
        this.ifCode = ifCode;
    }

    /**
     * @return the ifCode
     */
    public String getIfCode() {
        return ifCode;
    }
}
