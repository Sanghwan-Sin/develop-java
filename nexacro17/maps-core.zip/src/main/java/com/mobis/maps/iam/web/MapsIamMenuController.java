package com.mobis.maps.iam.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.service.MapsIamMenuService;
import com.mobis.maps.iam.vo.MapsIamMenuScreenVO;
import com.mobis.maps.iam.vo.MapsIamMenuVO;

/**
 * <pre>
 * 메뉴 관리 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsIamMenuController.java
 * @Description : 메뉴 관리에 대한 컨트롤러 정의.
 * @author DT048657
 * @since 2019. 9. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 5.     DT048657     	최초 생성
 * </pre>
 */
@Controller
public class MapsIamMenuController extends HController {

    @Resource(name = "mapsIamMenuService")
    private MapsIamMenuService mapsIamMenuService;
    
    /**
     * 메뉴 조회
     *
     * @param iamMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectMenuList.do")
    public NexacroResult selectMenuList(
            @ParamDataSet(name="dsInput") MapsIamMenuVO iamMenuVO
            , NexacroResult result) throws Exception {
        
        List<MapsIamMenuVO> MenuInfos = mapsIamMenuService.selectMenuList(iamMenuVO);
        
        result.addDataSet("dsOutput", MenuInfos);
        
        return result;
    }
    
    /**
     * 메뉴 화면 조회
     *
     * @param iamMsgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectMenuScreenList.do")
    public NexacroResult selectMenuScreenList(
            @ParamDataSet(name="dsInput") MapsIamMenuVO iamMenuVO
            , NexacroResult result) throws Exception {
        
        List<MapsIamMenuScreenVO> MenuScreenInfos = mapsIamMenuService.selectMenuScreenList(iamMenuVO);
        
        result.addDataSet("dsOutput", MenuScreenInfos);
        
        return result;
    }
    
    
    /**
     * 메뉴 저장
     *
     * @param MenuInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiMenuInfo.do")
    public NexacroResult multiMenuInfo(
            @ParamDataSet(name="dsInput") List<MapsIamMenuVO> menuInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamMenuService.multiMenuInfo(menuInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 메뉴 화면 저장
     *
     * @param MenuScreenInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/multiMenuScreenInfo.do")
    public NexacroResult multiMenuScreenInfo(
            @ParamDataSet(name="dsInput") List<MapsIamMenuScreenVO> menuScreenInfos
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        int procCnt = mapsIamMenuService.multiMenuScreenInfo(menuScreenInfos, loginInfo);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    
    
    /**
     * 메뉴 액셀다운로드
     *
     * @param iamMenuVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectMenuListExcelDown.do")
    public NexacroResult selectMenuListExcelDown(
            @ParamDataSet(name="dsInput") MapsIamMenuVO iamMenuVO
            , NexacroResult result) throws Exception {

        List<MapsIamMenuVO> MenuInfos = mapsIamMenuService.selectMenuList(iamMenuVO);

        result.addDataSet("dsOutput", MenuInfos);

        return result;
    }
        
    /**
     * 메뉴 엑셀업로드
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/iam/selectMenuListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectMenuListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<MapsIamMenuVO> MenuInfos = new ArrayList<MapsIamMenuVO>();

        List<String[]> rowList = ExcelUtil.importExcelToList(request, 2, 13, 0, "N");
        
        if (rowList != null && !rowList.isEmpty()) {

            for (String[] arrCol : rowList) {

                MapsIamMenuVO iamMenuVO = new MapsIamMenuVO();
                /*
                iamMenuVO.setWordId(arrCol[2]);
                iamMenuVO.setLangCd(arrCol[3]);
                iamMenuVO.setOrginlWord(arrCol[4]);
                iamMenuVO.setAbbrevWord(arrCol[5]);
                iamMenuVO.setWordDc(arrCol[6]);
                iamMenuVO.setUseYn(arrCol[7]);
                iamMenuVO.setRefrnLangCd(arrCol[8]);
                iamMenuVO.setRefrnOrginlWord(arrCol[9]);
                iamMenuVO.setRefrnAbbrevWord(arrCol[10]);
                iamMenuVO.setRefrnWordDc(arrCol[11]);
                iamMenuVO.setRefrnUseYn(arrCol[12]);
                */
                MenuInfos.add(iamMenuVO);
            }
        }

        result.addDataSet("dsOutput", MenuInfos);

        return result;
    }

    
     
}
