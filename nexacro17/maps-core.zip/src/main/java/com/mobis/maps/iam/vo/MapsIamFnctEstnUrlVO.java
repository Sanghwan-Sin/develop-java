package com.mobis.maps.iam.vo;

import java.util.Date;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * 기능확장URL 항목
 * </pre>
 *
 * @ClassName   : MapsIamFnctEstnUrlVO.java
 * @Description : 기능확장URL에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 7. 15.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 15.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamFnctEstnUrlVO extends PgBascVO {
    /** 기능ID */
    private String fnctId;
    /** 기능URL */
    private String fnctUrl;
    /** 기능설명 */
    private String fnctDc;
    /** 생성자ID */
    private String registId;
    /** 생성일자 */
    private Date registDt;
    
    /**
     * @return the fnctId
     */
    public String getFnctId() {
        return fnctId;
    }
    /**
     * @param fnctId the fnctId to set
     */
    public void setFnctId(String fnctId) {
        this.fnctId = fnctId;
    }
    /**
     * @return the fnctUrl
     */
    public String getFnctUrl() {
        return fnctUrl;
    }
    /**
     * @param fnctUrl the fnctUrl to set
     */
    public void setFnctUrl(String fnctUrl) {
        this.fnctUrl = fnctUrl;
    }
    /**
     * @return the fnctDc
     */
    public String getFnctDc() {
        return fnctDc;
    }
    /**
     * @param fnctDc the fnctDc to set
     */
    public void setFnctDc(String fnctDc) {
        this.fnctDc = fnctDc;
    }
    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }
    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }
    /**
     * @return the registDt
     */
    public Date getRegistDt() {
        return registDt;
    }
    /**
     * @param registDt the registDt to set
     */
    public void setRegistDt(Date registDt) {
        this.registDt = registDt;
    }
}
