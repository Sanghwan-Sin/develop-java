package com.mobis.maps.comm.vo;

import java.util.Date;

/**
 * <pre>
 * 화면접속정보 항목
 * </pre>
 *
 * @ClassName   : MapsCommScrinConectInfoVO.java
 * @Description : 화면접속정보에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 1. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 30.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommScrinConectInfoVO {
    /** 접속일시 */
    private Date conectDt;
    /** 시스템구분코드 */
    private String sysSeCd;
    /** 사용자ID */
    private String userId;
    /** 메뉴ID */
    private String menuId;
    /** 화면ID */
    private String scrinId;
    /** 서버명 */
    private String serverNm;
    /** 서버프로필 */
    private String serverProfl;
    /** USER-AGENT */
    private String userAgent;
    /** 브라우저명 */
    private String brwsrNm;
    /** 접속자ID */
    private String conectId;
    /** 접속ID주소 */
    private String conectIpAdres;
    /**
     * @return the conectDt
     */
    public Date getConectDt() {
        return conectDt;
    }
    /**
     * @param conectDt the conectDt to set
     */
    public void setConectDt(Date conectDt) {
        this.conectDt = conectDt;
    }
    /**
     * @return the sysSeCd
     */
    public String getSysSeCd() {
        return sysSeCd;
    }
    /**
     * @param sysSeCd the sysSeCd to set
     */
    public void setSysSeCd(String sysSeCd) {
        this.sysSeCd = sysSeCd;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the menuId
     */
    public String getMenuId() {
        return menuId;
    }
    /**
     * @param menuId the menuId to set
     */
    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
    /**
     * @return the scrinId
     */
    public String getScrinId() {
        return scrinId;
    }
    /**
     * @param scrinId the scrinId to set
     */
    public void setScrinId(String scrinId) {
        this.scrinId = scrinId;
    }
    /**
     * @return the serverNm
     */
    public String getServerNm() {
        return serverNm;
    }
    /**
     * @param serverNm the serverNm to set
     */
    public void setServerNm(String serverNm) {
        this.serverNm = serverNm;
    }
    /**
     * @return the serverProfl
     */
    public String getServerProfl() {
        return serverProfl;
    }
    /**
     * @param serverProfl the serverProfl to set
     */
    public void setServerProfl(String serverProfl) {
        this.serverProfl = serverProfl;
    }
    /**
     * @return the userAgent
     */
    public String getUserAgent() {
        return userAgent;
    }
    /**
     * @param userAgent the userAgent to set
     */
    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }
    /**
     * @return the brwsrNm
     */
    public String getBrwsrNm() {
        return brwsrNm;
    }
    /**
     * @param brwsrNm the brwsrNm to set
     */
    public void setBrwsrNm(String brwsrNm) {
        this.brwsrNm = brwsrNm;
    }
    /**
     * @return the conectId
     */
    public String getConectId() {
        return conectId;
    }
    /**
     * @param conectId the conectId to set
     */
    public void setConectId(String conectId) {
        this.conectId = conectId;
    }
    /**
     * @return the conectIpAdres
     */
    public String getConectIpAdres() {
        return conectIpAdres;
    }
    /**
     * @param conectIpAdres the conectIpAdres to set
     */
    public void setConectIpAdres(String conectIpAdres) {
        this.conectIpAdres = conectIpAdres;
    }
}
