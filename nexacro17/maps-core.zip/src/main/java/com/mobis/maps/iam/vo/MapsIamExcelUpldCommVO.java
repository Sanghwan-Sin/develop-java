package com.mobis.maps.iam.vo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 * IAM 액셀업로드공통 항목
 * </pre>
 *
 * @ClassName   : MapsIamExcelUpldVO.java
 * @Description : IAM 액셀업로드 공통에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 9. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 10.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamExcelUpldCommVO {

    /** 권한리스트 */
    private File excelFile;
    /** 애러코드 */
    private int errorCode;
    /** 애러메세지 */
    private String errorMsg;
    /** 애러 */
    private List<String> errors;
    
    public MapsIamExcelUpldCommVO() {
        this.errors = new ArrayList<String>();
    }
    
    public void addError(String error) {
        errors.add(error);
    }

    public boolean hasError() {
        return !errors.isEmpty();
    }

    public String toErrorString() {
        
        StringBuilder sbErrMsg = new StringBuilder();

        for (String errMsg: errors) {
            if (sbErrMsg.length() > 0) {
                sbErrMsg.append("\n\r");
            }
            sbErrMsg.append(errMsg);
        }
        
        return sbErrMsg.toString();
    }
    

    /**
     * @return the excelFile
     */
    public File getExcelFile() {
        return excelFile;
    }
    /**
     * @param excelFile the excelFile to set
     */
    public void setExcelFile(File excelFile) {
        this.excelFile = excelFile;
    }
    /**
     * @return the errorCode
     */
    public int getErrorCode() {
        return errorCode;
    }
    /**
     * @param errorCode the errorCode to set
     */
    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }
    /**
     * @return the errorMsg
     */
    public String getErrorMsg() {
        return errorMsg;
    }
    /**
     * @param errorMsg the errorMsg to set
     */
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
    /**
     * @return the errors
     */
    public List<String> getErrors() {
        return errors;
    }
    /**
     * @param errors the errors to set
     */
    public void setErrors(List<String> errors) {
        this.errors = errors;
    }

}
