package com.mobis.maps.cmmn.interceptor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.secure.WebSecurityUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsWebSecurityInterceptor.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048058
 * @since 2020. 7. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 22.     DT048058     	최초 생성
 * </pre>
 */
public class MapsWebSecurityInterceptor extends HandlerInterceptorAdapter {
    
    protected Logger logger = LoggerFactory.getLogger(MapsWebSecurityInterceptor.class);
    
    /*
     * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response
            , Object handler) throws Exception {

        debugPreHandleStart(request, response);

        Map<String, String[]> params = request.getParameterMap();
        
        for (String key : params.keySet()) {
            String[] values = params.get(key);
            if (values == null) {
                continue;
            }
            for (int i = 0; i < values.length; i++) {

                validateSecurityResult(WebSecurityUtil.checkDownloadParams(values[i]));
            }
        }
        
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
        if (multipartResolver.isMultipart(request)) {
            
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            
            Iterator<String> iter = multipartRequest.getFileNames();
            while (iter.hasNext()) {
                String uploadFileName = iter.next();
                List<MultipartFile> files = multipartRequest.getFiles(uploadFileName);
                for (MultipartFile file : files) {
                    
                    String fileName = file.getOriginalFilename();
                    /* */
                    validateSecurityResult(WebSecurityUtil.uploadFileExtCheck(fileName, "uploadExt"));
                    /* */
                    validateSecurityResult(WebSecurityUtil.uploadFileExtCheck(fileName, "uploadDetour"));
                }
            }
        }
        
        return super.preHandle(request, response, handler);
    }
    
    private void debugPreHandleStart(HttpServletRequest request, HttpServletResponse response) {
        if (!logger.isDebugEnabled()) {
            return;
        }
        logger.debug("━━━━━━━━━━━━━━━   MapsWebSecurityInterceptor preHandle     ━━━━━━━━━━━━━━━━");
        logger.debug("");
        logger.debug(" ================= request Paramter ===============");
        Map<String, String[]> params = request.getParameterMap();
        String[] values = null;
        for (String key : params.keySet()) {
            values = params.get(key);
            if (values != null) {
                for (int i = 0; i < values.length; i++) {
                    logger.debug(key + "[" + i + "] :  " + values[i]);
                }
            }
        }
    }
    
    private void debugAfterCompletionStart(HttpServletRequest request, HttpServletResponse response) {
        if (!logger.isDebugEnabled()) {
            return;
        }
        logger.debug("━━━━━━━━━━━━━━━   MapsWebSecurityInterceptor afterCompletion ━━━━━━━━━━━━━━━");
    }

    private void validateSecurityResult(HashMap<String, String> securityResult) throws Exception {
        if ("true".equals(securityResult.get("result"))) {
            throw new Exception("Web Security Violation " + (String) securityResult.get("securitySort") + ", Violation Char:: ' " + (String) securityResult.get("violationChar") + "'");
        }
    }

    /*
     * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#postHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, org.springframework.web.servlet.ModelAndView)
     */
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response
            , Object handler, ModelAndView modelAndView) throws Exception {
        super.postHandle(request, response, handler, modelAndView);
    }

    /*
     * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#afterCompletion(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, java.lang.Exception)
     */
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response
            , Object handler, Exception ex) throws Exception {

        debugAfterCompletionStart(request, response);
    
        super.afterCompletion(request, response, handler, ex);
    }
}
