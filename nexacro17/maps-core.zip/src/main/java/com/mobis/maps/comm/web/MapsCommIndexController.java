package com.mobis.maps.comm.web;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import able.com.exception.BizException;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mobis.maps.cmmn.secure.SecureUtils;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.comm.service.MapsCommIndexService;
import com.mobis.maps.comm.vo.MapsCommIndexVO;

/**
 * <pre>
 * 초기화면로드 컨트롤러
 * </pre>
 *
 * @ClassName   : MapsCommIndexController.java
 * @Description : 초기화면로드 컨트롤러를 정의.
 * @author DT048058
 * @since 2019. 12. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 4.     DT048058     	최초 생성
 * </pre>
 */
@Controller
public class MapsCommIndexController extends HController {

    @Resource(name = "mapsCommIndexService")
    private MapsCommIndexService mapsCommIndexService;

    @RequestMapping(value = "/index.do")
    public String index(  Model model ) throws Exception {
        String indexTarget = PropertiesUtil.getDbValue("INDEX_TARGET");
        if (StringUtils.isBlank(indexTarget)) {
            indexTarget = "main";
        }
        // SSL 적용대상인 경우 urlProtocol 에 https가 리턴된다.
        // SSL 페이지로 redirection 용임.
        String urlProtocol = PropertiesUtil.getDbValue("URL_PROTOCOL");
        if (StringUtils.isBlank(urlProtocol)) {
            urlProtocol = "http";
        }
        
        model.addAttribute("URL_PROTOCOL" ,urlProtocol );
        
        return indexTarget;
    }
    
    @RequestMapping(value = "/selectWorkflow.do" )
    public String selectWorkflow(HttpServletRequest request
            , HttpServletResponse response , Model model) throws Exception {
        
        String exStr = "";
        try{
            mapsCommIndexService.selecSapSdilInfo(request, response);
        }catch(BizException ex){
            exStr = ex.getMessage();
        }
        logger.debug("→ index::start[exStr=" + exStr + "]");
        model.addAttribute("ERR_MSG" ,exStr );
        
        return "mainSapSid";
    }
    
    
    /**
     * imobis 에서 sso진행
     *
     * @param userId
     * @param randomNum
     * @param request
     * @param response
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/selectMapsChnnlSso.do" )
    public String selectMapsChnnlSso( @RequestParam("USERID") String userIdIn, @RequestParam("RandomNum") String randomNum,
                                      HttpServletRequest request
                                    , HttpServletResponse response 
                                    , Model model) throws Exception {
        
        
        if( logger.isDebugEnabled() ){
            logger.debug("→ index::start[USERID=" + userIdIn + "]");
            logger.debug("→ index::start[randomNum=" + randomNum + "]");
        }
        String decodeVal = "";
        
        String userId = selectUnescapeVal(userIdIn);
        if( logger.isDebugEnabled() ){
            logger.debug("→ ******************  AFTER UNESCAPE ]");
            logger.debug("→ index::start[USERID=" + userId + "]");
            logger.debug("→ index::start[randomNum=" + randomNum + "]");
        }
        
        
        
        HttpSession session = request.getSession(true);
        
        if(StringUtils.isNotBlank(decodeVal)){
            userId = decodeVal;
        }
        
        // 초기화
        session.setAttribute("IMOBIS_SESSION_USERID", "");
        String exStr = "";
        Map<String, String> rtnMap = new HashMap<String,String>();
        try{
            rtnMap = mapsCommIndexService.selectSsoCheckMap(userId, randomNum);
        }catch(BizException ex){
            exStr = ex.getMessage();
        }
        // sso 체크 성공
        // imobis 세션인증 성공했다는 로직 임.
        
        String errMsg = rtnMap.get("RTNERRMSG");
        String outUsrId = rtnMap.get("OUTUSRID");
        String rtnValue = rtnMap.get("RTNVALUE");
        if( logger.isDebugEnabled() ){
            logger.debug("→ index::start[errMsg=" + errMsg + "]");
            logger.debug("→ index::start[outUsrId=" + outUsrId + "]");
            logger.debug("→ index::start[rtnValue=" + rtnValue + "]");
        }
        if( StringUtils.isBlank(errMsg) && StringUtils.isBlank(exStr) ){
            /* 세션초기화 */
            session.setAttribute("IMOBIS_SESSION_USERID", outUsrId);
        }
        if( StringUtils.isNotBlank(exStr)){
            model.addAttribute("ERR_MSG" ,exStr );
        }
        
        if( StringUtils.isNotBlank(errMsg)){
            model.addAttribute("ERR_MSG" ,errMsg );
        }
        
        return "chnnlSso";
    }

    /**
     * Statements
     *
     * @param userIdIn
     * @return
     */
    private String selectUnescapeVal(String userIdIn) {
        String[] searchList      = new String[]{"&#39;" , "&quot;" , "&#58;",  "&#59;", "&#40;", "&#41;", "&lt;", "&gt;", "&#123;" , "&#125;" , "&#35;" , "&#36;" , "&#37;" , "&amp;" , "&#63;" , "&#33;" , "&#64;" , "&#42;" , "&#124;"  };
        String[] replacementList = new String[]{"'"     , "\""     , ":"     , ";"    , "("    , ")"    , "<"   ,  ">"  , "{"      , "}"      , "#"     , "$"     , "%"     , "&"     , "?"     , "!"     , "@"     , "*"     , ":"       };
        String userId = StringUtils.replaceEach(userIdIn, searchList, replacementList);
        return userId;
    }
    
    /**
     * imobis 에서 sso진행
     *
     * @param userId
     * @param randomNum
     * @param request
     * @param response
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/selectSsoFromPortal.do" )
    public String selectSsoFromPortal( @RequestParam("ssoEncData") String ssoEncData ,
                                      HttpServletRequest request
                                    , HttpServletResponse response 
                                    , Model model) throws Exception {
        
        HttpSession session = request.getSession(true);
        // 초기화
        session.setAttribute("IMOBIS_SESSION_USERID", "");
        session.setAttribute("IMOBIS_SESSION_LOCALECD", "");
        String exStr = "";
        HashMap<String,String> rtnMap = new HashMap<String,String>();
        try{
            rtnMap = mapsCommIndexService.selectSsoFromPortalCheck(ssoEncData);
            //exStr = "";//mapsCommIndexService.selectSsoCheck(userId, randomNum);
        }catch(BizException ex){
            exStr = ex.getMessage();
        }
        
        String usrId = rtnMap.get("IMOBIS_SESSION_USERID");
        String localecd = rtnMap.get("IMOBIS_SESSION_LOCALECD");
        // sso 체크 성공
        // imobis 세션인증 성공했다는 로직 임.
        
        
        if(StringUtils.isBlank(exStr)){
            /* 세션초기화 */
            session.setAttribute("IMOBIS_SESSION_USERID", usrId);
            session.setAttribute("IMOBIS_SESSION_LOCALECD", localecd);
        }
        
        String ssoUserId = (String)session.getAttribute("IMOBIS_SESSION_USERID");
        String ssoLocalecd = (String)session.getAttribute("IMOBIS_SESSION_LOCALECD");
        if( logger.isDebugEnabled() ){
            logger.debug("→ index::start[ssoUserId=" + ssoUserId + "]");
            logger.debug("→ index::start[ssoLocalecd=" + ssoLocalecd + "]");
            logger.debug("→ index::start[exStr=" + exStr + "]");
        }
        model.addAttribute("ERR_MSG" ,exStr );
        return "chnnlSso";
    }
    
    
    @RequestMapping(value = "/selectWorkflowTest.do")
    public String selectWorkflowTest(HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        return "mainSapSidTest";
    }
    
    @RequestMapping(value = "/selectSsoFromPortalTest.do")
    public String selectSsoFromPortalTest(HttpServletRequest request
            , HttpServletResponse response) throws Exception {
        return "mainSsoTest";
    }
    
    @RequestMapping(value = "/comm/selectWorkflowSancVal.do")
    @ResponseBody
    public String selectWorkflowSancVal(MapsCommIndexVO inVo ) throws Exception {
        return mapsCommIndexService.selectWorkflowSancVal(inVo).getSsoEncData();
    }
}
