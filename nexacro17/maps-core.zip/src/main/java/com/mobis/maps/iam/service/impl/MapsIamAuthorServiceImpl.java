package com.mobis.maps.iam.service.impl;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.service.HService;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.FileUploadUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamAuthorService;
import com.mobis.maps.iam.service.dao.MapsIamAuthorMDAO;
import com.mobis.maps.iam.util.MapsIamAuthorExcelUpldUtil;
import com.mobis.maps.iam.util.MapsIamValidatorUtil;
import com.mobis.maps.iam.vo.MapsIamAuthorExcelUpldVO;
import com.mobis.maps.iam.vo.MapsIamAuthorMenuScnFnctVO;
import com.mobis.maps.iam.vo.MapsIamAuthorMenuVO;
import com.mobis.maps.iam.vo.MapsIamAuthorSetupVO;
import com.mobis.maps.iam.vo.MapsIamAuthorUserVO;
import com.mobis.maps.iam.vo.MapsIamAuthorVO;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * 권한관리 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamAuthorServiceImpl.java
 * @Description : 권한관리에 대한 서비스를 구현.
 * @author 최은삼
 * @since 2019. 12. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 13.     최은삼     	최초 생성
 * </pre>
 */

@Service("mapsIamAuthorService")
public class MapsIamAuthorServiceImpl extends HService implements MapsIamAuthorService {

    @Resource(name = "mapsCommFileService")
    private MapsCommFileService mapsCommFileService;
    
    @Resource(name = "mapsIamAuthorMDAO")
    private MapsIamAuthorMDAO mapsIamAuthorMDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#selectAuthorList(com.mobis.maps.iam.vo.MapsIamAuthorVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamAuthorVO> selectAuthorList(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception {

        iamAuthorVO.setAcntOrgnztSeCd(loginInfo.getOrgnztSeCd());
        iamAuthorVO.setAcntOrgnztCd(loginInfo.getOrgnztCd());
        iamAuthorVO.setAcntDealerCd(loginInfo.getDealerCd());
        iamAuthorVO.setAcntAcntTyCd(loginInfo.getAcntTyCd());
        
        List<MapsIamAuthorVO> authorInfos = mapsIamAuthorMDAO.selectAuthorList(iamAuthorVO);

        return authorInfos;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#selectAuthorPgList(com.mobis.maps.iam.vo.MapsIamAuthorVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamAuthorVO> selectAuthorPgList(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception {
        
        iamAuthorVO.setAcntOrgnztSeCd(loginInfo.getOrgnztSeCd());
        iamAuthorVO.setAcntOrgnztCd(loginInfo.getOrgnztCd());
        iamAuthorVO.setAcntDealerCd(loginInfo.getDealerCd());
        iamAuthorVO.setAcntAcntTyCd(loginInfo.getAcntTyCd());

        List<MapsIamAuthorVO> authorInfos = mapsIamAuthorMDAO.selectAuthorPgList(iamAuthorVO);

        return authorInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#selectAuthorInfo(com.mobis.maps.iam.vo.MapsIamAuthorVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public MapsIamAuthorVO selectAuthorInfo(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception {

        MapsIamAuthorVO ismAuthorVO = mapsIamAuthorMDAO.selectAuthorInfo(iamAuthorVO);
        
        return ismAuthorVO;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#multiAuthorInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiAuthorInfo(List<MapsIamAuthorVO> authorInfos, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;

        for (MapsIamAuthorVO iamAuthor : authorInfos) {

            int rowType = iamAuthor.getRowType();
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            procCnt += mulitAuthorInfoRow(iamAuthor, loginInfo);
        }

        return procCnt;
    }

    /**
     * 권한정보 저장
     *
     * @param iamAuthorVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    private int mulitAuthorInfoRow(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception {

        int rowType = iamAuthorVO.getRowType();

        iamAuthorVO.setRegistId(loginInfo.getUserSeqId());
        iamAuthorVO.setUpdtId(loginInfo.getUserSeqId());

        MapsIamAuthorVO rsltAuthorInfo = null;
        switch (rowType) {
            case DataSet.ROW_TYPE_INSERTED:
                /* 권한 등록 */
                // 권한 등록
                mapsIamAuthorMDAO.insertAuthorInfo(iamAuthorVO);
                // 권한 등록 이력 등록
                iamAuthorVO.setChangeSeCd(MapsConstants.CRUD_CREATE);
                iamAuthorVO.setChangeId(loginInfo.getUserSeqId());
                mapsIamAuthorMDAO.insertAuthorChghst(iamAuthorVO);

                break;
            case DataSet.ROW_TYPE_UPDATED:
                /* 권한 수정 정보 조회 */
                rsltAuthorInfo = mapsIamAuthorMDAO.selectAuthorInfo(iamAuthorVO);
                if (rsltAuthorInfo == null) {
                    throw new MapsBizException(messageSource, "EC00000011", new String[] { "Author Info" }, null);
                }
                /* 권한 삭제 */
                // 권한 삭제
                mapsIamAuthorMDAO.updateAuthorInfo(iamAuthorVO);
                // 권한 수정 이력 등록
                iamAuthorVO.setChangeSeCd(MapsConstants.CRUD_UPDATE);
                iamAuthorVO.setChangeId(loginInfo.getUserSeqId());
                mapsIamAuthorMDAO.insertAuthorChghst(iamAuthorVO);

                break;
            case DataSet.ROW_TYPE_DELETED:
                /* 권한 삭제 정보 조회 */
                rsltAuthorInfo = mapsIamAuthorMDAO.selectAuthorInfo(iamAuthorVO);
                if (rsltAuthorInfo == null) {
                    throw new MapsBizException(messageSource, "EC00000011", new String[] { "Author Info" }, null);
                }
                /* 권한별 메뉴,화면,화면기능 삭제 */
                deleteAuthorSubInfo(iamAuthorVO.getAuthorId(), loginInfo);
                // 권한 삭제
                mapsIamAuthorMDAO.deleteAuthorInfo(iamAuthorVO);
                // 권한 삭제 이력 등록
                rsltAuthorInfo.setChangeSeCd(MapsConstants.CRUD_DELETE);
                rsltAuthorInfo.setChangeId(loginInfo.getUserSeqId());
                mapsIamAuthorMDAO.insertAuthorChghst(rsltAuthorInfo);

                break;
            default:
                return 0;

        }
        return 1;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#multiAuthorInfoFiileUpload(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, com.mobis.maps.iam.vo.MapsIamAuthorExcelUpldVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    public void multiAuthorInfoFiileUpload(HttpServletRequest request, HttpServletResponse response, MapsIamAuthorExcelUpldVO iamAuthorExcelUpldVO, LoginInfoVO loginInfo) throws Exception {
        
        //해당 서비스에 대한 권한이 없습니다.
        MapsIamValidatorUtil.validateNotSystemUser(loginInfo);

        /* Excel업로드파일 취득 */
        File fAuthorExcel = mapsCommFileService.selectFileUpload(request);
        iamAuthorExcelUpldVO.setExcelFile(fAuthorExcel);
        //logger.debug("→ selectSapRfcInfoFileUpload.fUp[path=" + fUp.getPath() + "]");

        /* Excel업로드파일 파싱 */
        try {
            MapsIamAuthorExcelUpldUtil.pasing(iamAuthorExcelUpldVO, loginInfo);
        } finally {
            FileUploadUtil.removeFile(fAuthorExcel);
        }
        if (iamAuthorExcelUpldVO.hasError()) {
            return;
        }

        /* 권한관리정보 저장 */
        for (MapsIamAuthorVO iamAuthorVO : iamAuthorExcelUpldVO.getAuthors()) {

            int rowType = iamAuthorVO.getRowType();
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            String authorId = iamAuthorVO.getAuthorId();
            List<MapsIamAuthorMenuVO> lstAuthorMenu = iamAuthorExcelUpldVO.getAuthorMenu(authorId);
            List<MapsIamAuthorUserVO> lstAuthorUser = iamAuthorExcelUpldVO.getAuthorUser(authorId);
            //logger.debug("→ multiAuthorInfoFiileUpload.iamAuthorVO[authorId=" + authorId + ",lstAuthorMenu="+lstAuthorMenu.size()+",lstAuthorUser="+lstAuthorUser.size()+"]");
            try {
                mulitAuthorInfoRow(iamAuthorVO, loginInfo);
            } catch (MapsBizException e) {
                iamAuthorVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                iamAuthorVO.setMsg(e.getMessage());
                iamAuthorExcelUpldVO.addError(e.getMessage());
                return;
            }

            //권한설정이력정보 설정
            MapsIamAuthorSetupVO iamAuthorSetupVO = new MapsIamAuthorSetupVO();
            iamAuthorSetupVO.setChangeId(loginInfo.getUserSeqId());
            // 신규 권한ID 취득
            String newAuthorId = iamAuthorVO.getAuthorId();

            //권한별 메뉴,화면,화면기능 등록
            for (MapsIamAuthorMenuVO iamAuthorMenuVO: lstAuthorMenu) {
                if (rowType == DataSet.ROW_TYPE_INSERTED) {
                    iamAuthorMenuVO.setAuthorId(newAuthorId);
                    iamAuthorMenuVO.setAuthorYn(AUTHOR_FlAG_YES);
                }
                //권한별 메뉴 저장
                iamAuthorMenuVO.setMsgTy(null);
                try {
                    multiAuthorMenuInfoRow(iamAuthorMenuVO, iamAuthorSetupVO, loginInfo);
                    iamAuthorMenuVO.setMsgTy(MapsConstants.MESSAGE_TYPE_SUCCESS);
                } catch (MapsBizException e) {
                    iamAuthorMenuVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                    iamAuthorMenuVO.setMsg(e.getMessage());
                    iamAuthorExcelUpldVO.addError(e.getMessage());
                    return;
                }
            }

            //권한별 사용자 등록
            iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_USER);
            for (MapsIamAuthorUserVO iamAuthorUserVO: lstAuthorUser) {
                if (rowType == DataSet.ROW_TYPE_INSERTED) {
                    iamAuthorUserVO.setAuthorId(newAuthorId);
                }
                //권한별 사용자 저장
                iamAuthorUserVO.setMsgTy(null);
                try {
                    multiAuthorUserInfoRow(iamAuthorUserVO, iamAuthorSetupVO, loginInfo);
                    iamAuthorUserVO.setMsgTy(MapsConstants.MESSAGE_TYPE_SUCCESS);
                } catch (MapsBizException e) {
                    iamAuthorUserVO.setMsgTy(MapsConstants.MESSAGE_TYPE_ERROR);
                    iamAuthorUserVO.setMsg(e.getMessage());
                    iamAuthorExcelUpldVO.addError(e.getMessage());
                    return;
                }
            }
        }

    }
    
    /**
     * Summary 권한정보 삭제 
     *
     * @param authorId
     * @throws Exception
     */
    private void deleteAuthorSubInfo(String authorId, LoginInfoVO loginInfo) throws Exception {
        //권한설정이력정보 설정
        MapsIamAuthorSetupVO iamAuthorSetupVO = new MapsIamAuthorSetupVO();
        iamAuthorSetupVO.setAuthorId(authorId);
        iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_DELETE);
        iamAuthorSetupVO.setChangeId(loginInfo.getUserSeqId());

        /* 권한별 메뉴 삭제 */
        //권한별 메뉴,화면 삭제 정보 설정
        MapsIamAuthorMenuVO iamAuthorMenu = new MapsIamAuthorMenuVO();
        iamAuthorMenu.setAuthorId(authorId);
        // 권한별 메뉴 이력 등록
        iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_MENU);
        mapsIamAuthorMDAO.insertAllAuthorSetupChghst(iamAuthorSetupVO);
        // 권한별 메뉴 삭제
        mapsIamAuthorMDAO.deleteAllAuthorMenu(iamAuthorMenu);

        /* 권한별 화면 삭제 */
        // 권한별 화면 이력 등록
        iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_SCREEN);
        mapsIamAuthorMDAO.insertAllAuthorSetupChghst(iamAuthorSetupVO);
        // 권한별 화면 삭제
        mapsIamAuthorMDAO.deleteAllAuthorScrin(iamAuthorMenu);

        /* 권한별 화면기능 삭제 */
        //권한별 화면기능 삭제 정보 설정
        MapsIamAuthorMenuScnFnctVO iamAuthorScrinFnct = new MapsIamAuthorMenuScnFnctVO();
        iamAuthorScrinFnct.setAuthorId(authorId);
        // 권한별 화면기능 이력 등록
        iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_FUNCTION);
        mapsIamAuthorMDAO.insertAllAuthorSetupChghst(iamAuthorSetupVO);
        // 권한별 화면기능 삭제
        mapsIamAuthorMDAO.deleteAllAuthorScrinFnct(iamAuthorScrinFnct);

        /* 권한별 사용자 삭제 */
        MapsIamAuthorUserVO iamAuthorUserVO = new MapsIamAuthorUserVO();
        iamAuthorUserVO.setAuthorId(authorId);
        // 권한별 사용자 이력 등록
        iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_USER);
        mapsIamAuthorMDAO.insertAllAuthorSetupChghst(iamAuthorSetupVO);
        // 권한별 사용자 삭제
        mapsIamAuthorMDAO.deleteAllAuthorUser(iamAuthorUserVO);
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#selectAuthorChghstPgList(com.mobis.maps.iam.vo.MapsIamAuthorVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamAuthorVO> selectAuthorChghstPgList(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception {
        
        List<MapsIamAuthorVO> lstAuthorChghst = mapsIamAuthorMDAO.selectAuthorChghstPgList(iamAuthorVO);
        
        return lstAuthorChghst;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#selectAuthorMenuScrinList(com.mobis.maps.iam.vo.MapsIamAuthorMenuVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamAuthorMenuVO> selectAuthorMenuScrinList(MapsIamAuthorMenuVO imAuthorMenuVO, LoginInfoVO loginInfo) throws Exception {
        
        imAuthorMenuVO.setDfltLangCd(loginInfo.getDfltLangCd());
        imAuthorMenuVO.setLangCd(loginInfo.getLangCd());
        
        List<MapsIamAuthorMenuVO> authorMenuInfos = mapsIamAuthorMDAO.selectAuthorMenuScrinList(imAuthorMenuVO);
        
        return authorMenuInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#multiAuthorMenuInfo(com.mobis.maps.iam.vo.MapsIamAuthorMenuVO, java.util.List)
     */
    @Override
    public int multiAuthorMenuInfo(List<MapsIamAuthorMenuVO> iamAuthorMenuInfos, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;
        //권한설정이력정보 설정
        MapsIamAuthorSetupVO iamAuthorSetupVO = new MapsIamAuthorSetupVO();
        iamAuthorSetupVO.setChangeId(loginInfo.getUserSeqId());
        for (MapsIamAuthorMenuVO iamAuthorMenu : iamAuthorMenuInfos) {

            int rowType = iamAuthorMenu.getRowType();
            if (rowType != DataSet.ROW_TYPE_UPDATED) {
                continue;
            }
            
            multiAuthorMenuInfoRow(iamAuthorMenu, iamAuthorSetupVO, loginInfo);
            
            procCnt++;
        }

        return procCnt;
    }
    
    private int multiAuthorMenuInfoRow(MapsIamAuthorMenuVO iamAuthorMenuVO, MapsIamAuthorSetupVO iamAuthorSetupVO, LoginInfoVO loginInfo) throws Exception {

        int delCnt = 0;
        
        iamAuthorMenuVO.setRegistId(loginInfo.getUserSeqId());
        iamAuthorMenuVO.setUpdtId(loginInfo.getUserSeqId());

        iamAuthorSetupVO.setAuthorId(iamAuthorMenuVO.getAuthorId());
        iamAuthorSetupVO.setAuthorSetupTrgetId(iamAuthorMenuVO.getMenuId());
        iamAuthorSetupVO.setChangeId(loginInfo.getUserSeqId());

        if (StringUtils.equals(iamAuthorMenuVO.getMenuTyCd(), MapsIamConstants.MENU_TYPE_CD_MENU)) {

            iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_MENU);
            // 권한별 메뉴 삭제
            delCnt = mapsIamAuthorMDAO.deleteAuthorMenu(iamAuthorMenuVO);
            // 권한별 메뉴 등록
            if (StringUtils.equals(iamAuthorMenuVO.getAuthorYn(), AUTHOR_FlAG_YES)) {
                mapsIamAuthorMDAO.insertAuthorMenu(iamAuthorMenuVO);

                // 권한별 메뉴 등록이력 등록
                iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_CREATE);
                mapsIamAuthorMDAO.insertAuthorSetupChghst(iamAuthorSetupVO);
            } else {
                // 권한별 메뉴 삭제이력 등록
                if (delCnt > 0) {
                    iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_DELETE);
                    mapsIamAuthorMDAO.insertAuthorSetupChghst(iamAuthorSetupVO);
                }
            }
        } else if (StringUtils.equals(iamAuthorMenuVO.getMenuTyCd(), MapsIamConstants.MENU_TYPE_CD_SCREEN)) {

            // 권한별 화면 삭제
            delCnt = mapsIamAuthorMDAO.deleteAuthorScrin(iamAuthorMenuVO);
            if (StringUtils.equals(iamAuthorMenuVO.getAuthorYn(), AUTHOR_FlAG_YES)) {
                /* 권한별 화면 등록 */
                // 권한별 화면 등록
                mapsIamAuthorMDAO.insertAuthorScrin(iamAuthorMenuVO);
                // 권한별 화면 등록이력 등록
                iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_SCREEN);
                iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_CREATE);
                mapsIamAuthorMDAO.insertAuthorSetupChghst(iamAuthorSetupVO);
                
                /* 권한별 화면기능 등록 */
                // 권한별 화면기능 전체 등록
                MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO = new MapsIamAuthorMenuScnFnctVO();
                iamAuthorMenuScnFnctVO.setAuthorId(iamAuthorMenuVO.getAuthorId());
                iamAuthorMenuScnFnctVO.setScrinId(iamAuthorMenuVO.getScrinId());
                iamAuthorMenuScnFnctVO.setRegistId(loginInfo.getUserSeqId());
                mapsIamAuthorMDAO.insertAllAuthorScrinFnct(iamAuthorMenuScnFnctVO);
                // 권한별 화면기능 전체 등록 이력 등록
                iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_FUNCTION);
                iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_CREATE);
                iamAuthorSetupVO.setScrinId(iamAuthorMenuVO.getScrinId());
                mapsIamAuthorMDAO.insertAllAuthorSetupChghst(iamAuthorSetupVO);
            } else {
                if (delCnt > 0) {
                    /* 권한별 화면기능 삭제 */
                    // 권한별 화면기능 전체 삭제 이력 등록
                    iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_FUNCTION);
                    iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_DELETE);
                    iamAuthorSetupVO.setScrinId(iamAuthorMenuVO.getScrinId());
                    mapsIamAuthorMDAO.insertAllAuthorSetupChghst(iamAuthorSetupVO);
                    // 권한별 화면기능 전체 삭제
                    MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO = new MapsIamAuthorMenuScnFnctVO();
                    iamAuthorMenuScnFnctVO.setAuthorId(iamAuthorMenuVO.getAuthorId());
                    iamAuthorMenuScnFnctVO.setScrinId(iamAuthorMenuVO.getScrinId());
                    mapsIamAuthorMDAO.deleteAllAuthorScrinFnctByScrinId(iamAuthorMenuScnFnctVO);
                    
                    /* 권한별 화면기능 삭제 */
                    // 권한별 화면기능 이력 삭제 등록
                    iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_SCREEN);
                    iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_DELETE);
                    mapsIamAuthorMDAO.insertAuthorSetupChghst(iamAuthorSetupVO);
                }
            }
        }
        
        return 1;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#selectAuthorScrinFnctList(com.mobis.maps.iam.vo.MapsIamAuthorMenuScnFnctVO)
     */
    @Override
    public List<MapsIamAuthorMenuScnFnctVO> selectAuthorScrinFnctList(MapsIamAuthorMenuScnFnctVO iamAuthorMenuScnFnctVO) throws Exception {

        List<MapsIamAuthorMenuScnFnctVO> authorMenuScnFnctVO = mapsIamAuthorMDAO.selectAuthorScrinFnctList(iamAuthorMenuScnFnctVO);

        return authorMenuScnFnctVO;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#multiAuthorScrinFnctInfo(java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiAuthorScrinFnctInfo(List<MapsIamAuthorMenuScnFnctVO> iamAuthorScrinFnctInfos, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;

        for (MapsIamAuthorMenuScnFnctVO iamAuthorScrinFnct : iamAuthorScrinFnctInfos) {

            int rowType = iamAuthorScrinFnct.getRowType();
            if (rowType != DataSet.ROW_TYPE_UPDATED) {
                continue;
            }

            iamAuthorScrinFnct.setRegistId(loginInfo.getUserSeqId());
            iamAuthorScrinFnct.setUpdtId(loginInfo.getUserSeqId());

            mapsIamAuthorMDAO.deleteAuthorScrinFnct(iamAuthorScrinFnct);

            if (StringUtils.equals(iamAuthorScrinFnct.getAuthorYn(), AUTHOR_FlAG_YES)) {
                mapsIamAuthorMDAO.insertAuthorScrinFnct(iamAuthorScrinFnct);
            }
            
            procCnt++;
        }

        return procCnt;
    }
    
    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#selectAuthorSetupChghstPgList(com.mobis.maps.iam.vo.MapsIamAuthorSetupVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamAuthorSetupVO> selectAuthorSetupChghstPgList(MapsIamAuthorSetupVO iamAuthorSetupVO, LoginInfoVO loginInfo) throws Exception {
        
        List<MapsIamAuthorSetupVO> lstAuthorSetupChghst = mapsIamAuthorMDAO.selectAuthorSetupChghstPgList(iamAuthorSetupVO);
        
        return lstAuthorSetupChghst;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#selectAuthorUserPgList(com.mobis.maps.iam.vo.MapsIamAuthorUserVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamAuthorUserVO> selectAuthorUserPgList(MapsIamAuthorUserVO iamAuthorUserVO, LoginInfoVO loginInfo) throws Exception {

        List<MapsIamAuthorUserVO> authorUserInfos = mapsIamAuthorMDAO.selectAuthorUserPgList(iamAuthorUserVO);

        return authorUserInfos;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#multiAuthorUserInfo(com.mobis.maps.iam.vo.MapsIamAuthorUserVO, java.util.List)
     */
    @Override
    public int multiAuthorUserInfo(List<MapsIamAuthorUserVO> iamAuthorUserInfos, LoginInfoVO loginInfo) throws Exception {

        int procCnt = 0;

        //권한설정이력정보 설정
        MapsIamAuthorSetupVO iamAuthorSetupVO = new MapsIamAuthorSetupVO();
        iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_USER);
        iamAuthorSetupVO.setChangeId(loginInfo.getUserSeqId());
        for (MapsIamAuthorUserVO iamAuthorUser : iamAuthorUserInfos) {

            int rowType = iamAuthorUser.getRowType();
            if (rowType == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }

            multiAuthorUserInfoRow(iamAuthorUser, iamAuthorSetupVO, loginInfo);
            
            procCnt++;
        }

        return procCnt;
    }

    /**
     * Statements
     *
     * @param iamAuthorUserVO
     * @param iamAuthorSetupVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    private int multiAuthorUserInfoRow(MapsIamAuthorUserVO iamAuthorUserVO, MapsIamAuthorSetupVO iamAuthorSetupVO, LoginInfoVO loginInfo) throws Exception {

        int rowType = iamAuthorUserVO.getRowType();
        
        iamAuthorUserVO.setRegistId(loginInfo.getUserSeqId());
        iamAuthorUserVO.setUpdtId(loginInfo.getUserSeqId());

        iamAuthorSetupVO.setAuthorId(iamAuthorUserVO.getAuthorId());
        iamAuthorSetupVO.setAuthorSetupTrgetId(iamAuthorUserVO.getUserSeqId());
        iamAuthorSetupVO.setChangeId(loginInfo.getUserSeqId());

        MapsIamAuthorUserVO dplctAuthorUserVO = mapsIamAuthorMDAO.selectAuthorUserByUserSeqId(iamAuthorUserVO);
        switch (rowType) {
            case DataSet.ROW_TYPE_INSERTED :

                if (dplctAuthorUserVO != null) {
                    //이미 사용자권한에 등록된 계정입니다.
                    throw new MapsBizException(messageSource, "ECI0000039", loginInfo.getUserLcale(), null);
                }
                
                mapsIamAuthorMDAO.insertAuthorUser(iamAuthorUserVO);

                iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_CREATE);
                break;
            case DataSet.ROW_TYPE_UPDATED :
                
                if (dplctAuthorUserVO == null) {
                    //사용자권한에 등록된 계정이 없습니다.
                    throw new MapsBizException(messageSource, "ECI0000040", loginInfo.getUserLcale(), null);
                }
                
                if (!StringUtils.equals(dplctAuthorUserVO.getUserAuthorId(), iamAuthorUserVO.getUserAuthorId())) {
                    //이미 사용자권한에 등록된 계정입니다.
                    throw new MapsBizException(messageSource, "ECI0000039", loginInfo.getUserLcale(), null);
                }
                
                mapsIamAuthorMDAO.updateAuthorUser(iamAuthorUserVO);

                iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_UPDATE);
                break;
            case DataSet.ROW_TYPE_DELETED :
                
                if (dplctAuthorUserVO == null) {
                    //사용자권한에 등록된 계정이 없습니다.
                    throw new MapsBizException(messageSource, "ECI0000040", loginInfo.getUserLcale(), null);
                }

                mapsIamAuthorMDAO.deleteAuthorUser(iamAuthorUserVO);

                iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_DELETE);
                break;

        }

        mapsIamAuthorMDAO.insertAuthorSetupChghst(iamAuthorSetupVO);
        
        return 1;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAuthorService#insertImportAuthorInfo(com.mobis.maps.iam.vo.MapsIamAuthorVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int insertImportAuthorInfo(MapsIamAuthorVO iamAuthorVO, LoginInfoVO loginInfo) throws Exception {
        /* 권한 타겟 정보 조회 */
        MapsIamAuthorVO authorVO = mapsIamAuthorMDAO.selectAuthorInfo(iamAuthorVO);
        if (authorVO == null) {
            throw new MapsBizException(messageSource, "EC00000011", new String[] { "Target Author Info" }, null);
        }
        /* 권한 원본 정보 조회 */
        MapsIamAuthorVO importAuthorVO = new MapsIamAuthorVO();
        importAuthorVO.setAuthorId(iamAuthorVO.getImportAuthorId());
        importAuthorVO = mapsIamAuthorMDAO.selectAuthorInfo(iamAuthorVO);
        if (importAuthorVO == null) {
            throw new MapsBizException(messageSource, "EC00000011", new String[] { "Original Author Info" }, null);
        }

        iamAuthorVO.setRegistId(loginInfo.getUserSeqId());
        iamAuthorVO.setUpdtId(loginInfo.getUserSeqId());
        
        /* 권한별 메뉴,화면,화면기능 삭제후 등록 */
        if (StringUtils.isNotBlank(iamAuthorVO.getImportAuthorId())) {
            // 권한별 메뉴,화면,화면기능 삭제
            deleteAuthorSubInfo(iamAuthorVO.getAuthorId(), loginInfo);
            // 권한별 메뉴,화면,화면기능 등록
            insertImportAuthorInfo(iamAuthorVO);
        }
        
        return 1;
    }
    
    /**
     * 권한정보 가져오기
     *
     * @param iamAuthorVO
     * @throws Exception
     */
    private void insertImportAuthorInfo(MapsIamAuthorVO iamAuthorVO) throws Exception {
        //권한설정이력정보 설정
        MapsIamAuthorSetupVO iamAuthorSetupVO = new MapsIamAuthorSetupVO();
        iamAuthorSetupVO.setAuthorId(iamAuthorVO.getImportAuthorId());
        iamAuthorSetupVO.setChangeSeCd(MapsConstants.CRUD_CREATE);
        iamAuthorSetupVO.setChangeId(iamAuthorVO.getUpdtId());
        //권한별 메뉴,화면 삭제 정보 설정
        // 권한별 메뉴 등록
        mapsIamAuthorMDAO.insertImportAuthorMenu(iamAuthorVO);
        // 권한별 메뉴 이력 등록
        iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_MENU);
        mapsIamAuthorMDAO.insertAllAuthorSetupChghst(iamAuthorSetupVO);
        // 권한별 화면 등록
        mapsIamAuthorMDAO.insertImportAuthorScrin(iamAuthorVO);
        // 권한별 화면 이력 등록
        iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_SCREEN);
        mapsIamAuthorMDAO.insertAllAuthorSetupChghst(iamAuthorSetupVO);
        // 권한별 화면기능 등록
        mapsIamAuthorMDAO.insertImportAuthorScrinFnct(iamAuthorVO);
        // 권한별 화면기능 등록
        iamAuthorSetupVO.setAuthorSetupSeCd(AUTHOR_SETUP_SE_CD_FUNCTION);
        mapsIamAuthorMDAO.insertAllAuthorSetupChghst(iamAuthorSetupVO);
    }

}
