package com.mobis.maps.comm.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;
import able.com.util.fmt.DateUtil;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommDbLoggingService;
import com.mobis.maps.comm.service.dao.MapsCommDbLoggingMDAO;
import com.mobis.maps.comm.vo.MapsCommDbLoggingEventPropVO;
import com.mobis.maps.comm.vo.MapsCommDbLoggingEventVO;

/**
 * <pre>
 * DB Logging 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsCommDbLoggingServiceImpl.java
 * @Description : DB Logging에 대한 서비스를 구현.
 * @author DT048058
 * @since 2019. 12. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 30.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsCommDbLoggingService")
public class MapsCommDbLoggingServiceImpl extends HService implements MapsCommDbLoggingService {

    @Resource(name="mapsCommDbLoggingMDAO")
    private MapsCommDbLoggingMDAO mapsCommDbLoggingMDAO;

    /*
     * @see com.mobis.maps.comm.service.MapsCommDbLoggingService#selectLoggingEventPgList(com.mobis.maps.comm.vo.MapsCommDbLoggingEventVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommDbLoggingEventVO> selectDbLoggingEventPgList(MapsCommDbLoggingEventVO dbLoggingEventVO
            , LoginInfoVO loginInfo) throws Exception {

        String strtDt = dbLoggingEventVO.getStrtDt();
        String endDt = dbLoggingEventVO.getEndDt();

        if (StringUtils.isNotBlank(strtDt)) {
            Date dStrt = DateUtil.stringToDate(strtDt, "yyyyMMddHHmmss");
            dbLoggingEventVO.setStrtTs(dStrt.getTime());
        }
        if (StringUtils.isNotBlank(endDt)) {
            Date dEnd = DateUtil.stringToDate(endDt, "yyyyMMddHHmmss");
            dbLoggingEventVO.setEndTs(dEnd.getTime());
        }
        
        List<MapsCommDbLoggingEventVO> lstDbLoggingEvent = mapsCommDbLoggingMDAO.selectDbLoggingEventPgList(dbLoggingEventVO);
        
        return lstDbLoggingEvent;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommDbLoggingService#selectLoggingEventPropertyList(com.mobis.maps.comm.vo.MapsCommDbLoggingEventVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsCommDbLoggingEventPropVO> selectDbLoggingEventPropList(MapsCommDbLoggingEventVO dbLoggingEventVO
            , LoginInfoVO loginInfo) throws Exception {
        
        List<MapsCommDbLoggingEventPropVO> lstDbLoggingEventProp = mapsCommDbLoggingMDAO.selectDbLoggingEventPropertyList(dbLoggingEventVO);
        
        return lstDbLoggingEventProp;
    }

}
