package com.mobis.maps.comm.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommOzReportService;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.comm.vo.MapsCommOzReportVO;
import com.mobis.maps.comm.constants.MapsSapRfcInfo;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.util.PropertiesUtil;
/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsCommOzReportServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author oh.dongwon
 * @since 2020. 4. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 27.     oh.dongwon     	최초 생성
 * </pre>
 */
@Service("mapsCommOzReportService")
public class MapsCommOzReportServiceImpl  extends HService implements MapsCommOzReportService {
    
    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.comm.service.MapsCommOzReportService#selectCommMapsOzReport(com.mobis.maps.cmmn.vo.LoginInfoVO, java.util.List)
     */
    @Override
    public MapsCommOzReportVO selectCommMapsOzReport(LoginInfoVO loginInfo, List<MapsCommOzReportVO> mapsCommOzReportList) throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_OZ_PRT_RFC_PARAM_ENCRYPT;
        
        MapsCommOzReportVO paramVo = mapsCommOzReportList.get(0);
        
        Function func = null;
        
        // ERP/EWM 유무로 판단.
        String iErpYn = paramVo.getiErpYn();
        if(StringUtils.equals(iErpYn, "Y")){
            func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name() , RfcSapSys.PC  );
        }else{
            func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name() , RfcSapSys.PW );
        }
        
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVo);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVo);
        
        // Table 호출
        for(MapsCommOzReportVO vo : mapsCommOzReportList) {
            MapsRfcMappperUtil.appendImportStructureTableRow(func, "I_RFC_PARAM_T", vo);
        }
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);    //func.execute();
        
        
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVo);
        MapsRfcMappperUtil.setExportParamList(funcRslt, paramVo, loginInfo.getUserLcale());
        String ozUrl = PropertiesUtil.getDbValue("OZ_URL");
        paramVo.setSystemOzUrl(ozUrl);
        return paramVo;
    }

    /*
     * @see com.mobis.maps.comm.service.MapsCommOzReportService#selectCommMapsOzReportMulti(com.mobis.maps.cmmn.vo.LoginInfoVO, java.util.List)
     */
    @Override
    public MapsCommOzReportVO selectCommMapsOzReportMulti(LoginInfoVO loginInfo, List<MapsCommOzReportVO> mapsCommOzReportVOList) throws Exception {
        int size = mapsCommOzReportVOList.size();
        String previosSeqNo = "";
        List<MapsCommOzReportVO> mapsCommOzReportVOInput = new ArrayList<MapsCommOzReportVO>();
        MapsCommOzReportVO rtnParam = new MapsCommOzReportVO();
        String reportName = "";
        String eOzSeqno = "";
        StringBuffer formDataSb = new StringBuffer();
        for(int  i =  0 ; i < size ; i++ ){
            MapsCommOzReportVO ozParam = mapsCommOzReportVOList.get(i);
            if(StringUtils.equals(previosSeqNo, "")){
                previosSeqNo = ozParam.getOzSeqNo();
                mapsCommOzReportVOInput =  new ArrayList<MapsCommOzReportVO>();
            } 
            
            if( !StringUtils.equals(previosSeqNo, ozParam.getOzSeqNo())  ){
                rtnParam = this.selectCommMapsOzReport(loginInfo , mapsCommOzReportVOInput);
                reportName = rtnParam.getReportName();
                eOzSeqno = rtnParam.geteOzSeqno();
                logger.debug( "reportName : " + rtnParam.getReportName() );
                logger.debug( "eOzSeqno  : " + rtnParam.geteOzSeqno() );
                formDataSb.append("<input type='text' name='reportName' value='" + reportName + "' />\n" );
                formDataSb.append("<input type='text' name='ozSeqno' value='" + eOzSeqno + "' />\n" );
                mapsCommOzReportVOInput =  new ArrayList<MapsCommOzReportVO>();
            }
            
            mapsCommOzReportVOInput.add(ozParam);
            
            previosSeqNo = ozParam.getOzSeqNo();
            
            if( i == (size -1)  ){
                rtnParam = this.selectCommMapsOzReport(loginInfo , mapsCommOzReportVOInput);
                reportName = rtnParam.getReportName();
                eOzSeqno = rtnParam.geteOzSeqno();
                logger.debug( "reportName : " + rtnParam.getReportName() );
                logger.debug( "eOzSeqno  : " + rtnParam.geteOzSeqno() );
                formDataSb.append("<input type='text' name='reportName' value='" + reportName + "' />\n" );
                formDataSb.append("<input type='text' name='ozSeqno' value='" + eOzSeqno + "' />\n" );
                mapsCommOzReportVOInput =  new ArrayList<MapsCommOzReportVO>();
            }
            
            
        }
        MapsCommOzReportVO rtnVo = new MapsCommOzReportVO();
        
        String formData = formDataSb.toString();
        String ozUrl = PropertiesUtil.getDbValue("OZ_URL_MULTI");
        rtnVo.setFormData(formData);
        rtnVo.setSystemOzUrl(ozUrl);
        return rtnVo;
    }

}
