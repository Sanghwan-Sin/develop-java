package com.mobis.maps.iam.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.constants.RfcSapSys;
import com.mobis.maps.iam.constants.MapsIamConstants;
import com.mobis.maps.iam.service.MapsIamAcntReqstSttusService;
import com.mobis.maps.iam.service.MapsIamMobisUserService;
import com.mobis.maps.iam.service.dao.MapsIamAcntReqstSttusMDAO;
import com.mobis.maps.iam.util.MapsIamUtil;
import com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO;

/**
 * <pre>
 * 계정신청현황 서비스 구현
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstSttusServiceImpl.java
 * @Description : 계정신청현황에 대한 서비스를 구현.
 * @author DT048058
 * @since 2020. 3. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 30.     DT048058     	최초 생성
 * </pre>
 */
@Service("mapsIamAcntReqstSttusService")
public class MapsIamAcntReqstSttusServiceImpl extends HService implements MapsIamAcntReqstSttusService {

    @Resource(name = "mapsIamMobisUserService")
    MapsIamMobisUserService mapsIamMobisUserService;

    @Resource(name="mapsIamAcntReqstSttusMDAO")
    private MapsIamAcntReqstSttusMDAO mapsIamAcntReqstSttusMDAO;

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstSttusService#selectAcntReqstSttusPgList(com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamAcntReqstInfoVO> selectAcntReqstSttusPgList(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , LoginInfoVO loginInfo) throws Exception {
        
        if (StringUtils.isBlank(iamAcntReqstInfoVO.getOrgnztSeCd())) {
            MapsIamUtil.addOrgnztSeCd(iamAcntReqstInfoVO.getSysSeCd(), iamAcntReqstInfoVO, loginInfo);
        }
        if (StringUtils.isBlank(iamAcntReqstInfoVO.getOrgnztCd())) {
            MapsIamUtil.addOrgnztCd(iamAcntReqstInfoVO, loginInfo, mapsIamMobisUserService);
        }
        if (StringUtils.isBlank(iamAcntReqstInfoVO.getAcntTyCd())) {
            MapsIamUtil.addAcntTyCd(iamAcntReqstInfoVO, loginInfo);
        }

        iamAcntReqstInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamAcntReqstInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        List<MapsIamAcntReqstInfoVO> lstAcntReqstSttus =  mapsIamAcntReqstSttusMDAO.selectAcntReqstSttusPgList(iamAcntReqstInfoVO);
        
        return lstAcntReqstSttus;
    }

    /*
     * @see com.mobis.maps.iam.service.MapsIamAcntReqstSttusService#selectAcntReqstSttusMasterPgList(com.mobis.maps.iam.vo.MapsIamAcntReqstInfoVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsIamAcntReqstInfoVO> selectAcntReqstSttusMasterPgList(MapsIamAcntReqstInfoVO iamAcntReqstInfoVO
            , LoginInfoVO loginInfo) throws Exception {

        iamAcntReqstInfoVO.setSysSeCd(loginInfo.getSysSeCd());
        if (StringUtils.isBlank(iamAcntReqstInfoVO.getOrgnztSeCd())) {
            MapsIamUtil.addOrgnztSeCd(iamAcntReqstInfoVO.getSysSeCd(), iamAcntReqstInfoVO, loginInfo);
        }
        iamAcntReqstInfoVO.setBsnOrgnztCd(loginInfo.getBsnOrgnztCd());
        if (StringUtils.isBlank(iamAcntReqstInfoVO.getOrgnztCd())) {
            MapsIamUtil.addOrgnztCd(iamAcntReqstInfoVO, loginInfo, mapsIamMobisUserService);
        }
        if (StringUtils.equals(loginInfo.getOrgnztSeCd(), MapsConstants.ORGNZT_SE_CD_DIRECT_DEALER)) {
            iamAcntReqstInfoVO.setDealerCd(loginInfo.getDealerCd());
        }
        iamAcntReqstInfoVO.setAcntTyCd(MapsIamConstants.ACCOUNT_TYPE_CD_NOMAL);

        iamAcntReqstInfoVO.setRfcPcSysId(RfcSapSys.PC.getSysId());
        iamAcntReqstInfoVO.setRfcPcClient(RfcSapSys.PC.getClient());
        
        List<MapsIamAcntReqstInfoVO> lstAcntReqstSttus =  mapsIamAcntReqstSttusMDAO.selectAcntReqstSttusPgList(iamAcntReqstInfoVO);
        
        return lstAcntReqstSttus;
    }

}
