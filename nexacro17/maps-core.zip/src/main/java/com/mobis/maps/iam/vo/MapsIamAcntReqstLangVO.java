package com.mobis.maps.iam.vo;

/**
 * <pre>
 * 계정신청언어 항목
 * </pre>
 *
 * @ClassName   : MapsIamAcntReqstLangVO.java
 * @Description : 계정신청언어에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     DT048058     	최초 생성
 * </pre>
 */

public class MapsIamAcntReqstLangVO extends MapsIamCommVO {
    /** 계정신청번호 */
    private String acntReqstNo;
    /** 국가언어코드 */
    private String langCd;
    /* 등록정보 */
    /** 사용자언어순번 */
    private int userLangSeq;
    /** 사용자순번ID */
    private String userSeqId;
    /**
     * @return the acntReqstNo
     */
    public String getAcntReqstNo() {
        return acntReqstNo;
    }
    /**
     * @param acntReqstNo the acntReqstNo to set
     */
    public void setAcntReqstNo(String acntReqstNo) {
        this.acntReqstNo = acntReqstNo;
    }
    /**
     * @return the langCd
     */
    public String getLangCd() {
        return langCd;
    }
    /**
     * @param langCd the langCd to set
     */
    public void setLangCd(String langCd) {
        this.langCd = langCd;
    }
    /**
     * @return the userLangSeq
     */
    public int getUserLangSeq() {
        return userLangSeq;
    }
    /**
     * @param userLangSeq the userLangSeq to set
     */
    public void setUserLangSeq(int userLangSeq) {
        this.userLangSeq = userLangSeq;
    }
    /**
     * @return the userSeqId
     */
    public String getUserSeqId() {
        return userSeqId;
    }
    /**
     * @param userSeqId the userSeqId to set
     */
    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }
}
