package com.mobis.maps.sapjco.manager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;

import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoTable;
import com.mobis.maps.sapjco.common.Converter;
import com.mobis.maps.sapjco.common.function.ThrowableBiConsumer;
import com.mobis.maps.sapjco.common.function.ThrowableConsumer;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : Util.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT045877
 * @since 2019. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 5. 8.     DT045877     	최초 생성
 * </pre>
 */
public class Util {
    /**
     * Statements
     */
    private Util() {
    }
    
    /**
     * JCoTable to List[Map[String, Object]]
     * @param table
     * jCo table
     * @return
     */
    public static List<Map<String, Object>> toMapList(JCoTable table) {
        List<Map<String, Object>> rv = new ArrayList<>();
    
        while (!table.isEmpty()) {
            Map<String, Object> map = new LinkedHashMap<>();
            Converter.toStream(table).forEach(field -> map.put(field.getName(), field.getValue()));
            rv.add(map);
            if (table.isLastRow()) {
                break;
            }
            table.nextRow();
        }        
        return rv;
    }
    
    /**
     * JCoTable to custom class
     * @param table
     * jCo table
     * @param createRow
     * create custom class row
     * @param bindField
     * bind field in custom class row
     * @return
     */
    public static <R> List<R> toClass(JCoTable table, Supplier<R> createRow, ThrowableBiConsumer<R, JCoField> bindField) {
        List<R> rv = new ArrayList<>();
        
        while (!table.isEmpty()) {
            R r = createRow.get();
            Converter.toStream(table).forEach(ThrowableConsumer.<JCoField>runtime(field -> bindField.accept(r, field)));
            rv.add(r);
            if (table.isLastRow()) {
                break;
            }
            table.nextRow();
        }
        return rv;
    }
    
    /**
     * if [object value] is [java.util.Date] then [to string by format] else [object value]
     * @param value
     * @param format
     * @return
     */
    public static Object filterDate(Object value, String format) {
        if (value != null && "java.util.Date".equals(value.getClass().getName())) {
            return new SimpleDateFormat(format , Locale.KOREA).format((Date)value );
        }
        return value;
    }
}