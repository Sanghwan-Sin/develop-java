package com.mobis.maps.comm.vo;

/**
 * <pre>
 * 공통조직 항목
 * </pre>
 *
 * @ClassName   : MapsCommOrgnztVO.java
 * @Description : 공통조직에 대한 항목을 정의.
 * @author DT048058
 * @since 2020. 3. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 18.     DT048058     	최초 생성
 * </pre>
 */

public class MapsCommOrgnztVO extends PgBascVO {
    /** 조직구분코드 */
    private String orgnztSeCd;
    /** 영업조직코드 */
    private String bsnOrgnztCd;
    /** 조직코드 */
    private String orgnztCd;
    /** 조직명 */
    private String orgnztNm;
    /** 딜러코드 */
    private String dealerCd;
    /** 딜러명 */
    private String dealerNm;
    /** 조직국가코드 */
    private String orgnztCycd;
    /** 조직우편번호 */
    private String orgnztZip;
    /** 조직주소 */
    private String orgnztAdres;
    /** 조직상태 */
    private String orgnztSttus;
    /* 일반/직배대리점 및 딜러관련 정보 */
    /** 수출/내수구분 */
    private String expDmstcSe;
    /** 대리점코드 */
    private String distCd;
    /** 대표대리점코드 */
    private String repDistCd;
    /** 대표조직명 */
    private String repDistNm;
    /** 대표대리점여부 */
    private String repDistYn;
    /** 대표딜러코드 */
    private String repDealerCd;
    /** 대표딜러명 */
    private String repDealerNm;
    /** 대표딜러여부 */
    private String repDealerYn;
    /**
     * @return the orgnztSeCd
     */
    public String getOrgnztSeCd() {
        return orgnztSeCd;
    }
    /**
     * @param orgnztSeCd the orgnztSeCd to set
     */
    public void setOrgnztSeCd(String orgnztSeCd) {
        this.orgnztSeCd = orgnztSeCd;
    }
    /**
     * @return the bsnOrgnztCd
     */
    public String getBsnOrgnztCd() {
        return bsnOrgnztCd;
    }
    /**
     * @param bsnOrgnztCd the bsnOrgnztCd to set
     */
    public void setBsnOrgnztCd(String bsnOrgnztCd) {
        this.bsnOrgnztCd = bsnOrgnztCd;
    }
    /**
     * @return the orgnztCd
     */
    public String getOrgnztCd() {
        return orgnztCd;
    }
    /**
     * @param orgnztCd the orgnztCd to set
     */
    public void setOrgnztCd(String orgnztCd) {
        this.orgnztCd = orgnztCd;
    }
    /**
     * @return the orgnztNm
     */
    public String getOrgnztNm() {
        return orgnztNm;
    }
    /**
     * @param orgnztNm the orgnztNm to set
     */
    public void setOrgnztNm(String orgnztNm) {
        this.orgnztNm = orgnztNm;
    }
    /**
     * @return the dealerCd
     */
    public String getDealerCd() {
        return dealerCd;
    }
    /**
     * @param dealerCd the dealerCd to set
     */
    public void setDealerCd(String dealerCd) {
        this.dealerCd = dealerCd;
    }
    /**
     * @return the dealerNm
     */
    public String getDealerNm() {
        return dealerNm;
    }
    /**
     * @param dealerNm the dealerNm to set
     */
    public void setDealerNm(String dealerNm) {
        this.dealerNm = dealerNm;
    }
    /**
     * @return the orgnztCycd
     */
    public String getOrgnztCycd() {
        return orgnztCycd;
    }
    /**
     * @param orgnztCycd the orgnztCycd to set
     */
    public void setOrgnztCycd(String orgnztCycd) {
        this.orgnztCycd = orgnztCycd;
    }
    /**
     * @return the orgnztZip
     */
    public String getOrgnztZip() {
        return orgnztZip;
    }
    /**
     * @param orgnztZip the orgnztZip to set
     */
    public void setOrgnztZip(String orgnztZip) {
        this.orgnztZip = orgnztZip;
    }
    /**
     * @return the orgnztAdres
     */
    public String getOrgnztAdres() {
        return orgnztAdres;
    }
    /**
     * @param orgnztAdres the orgnztAdres to set
     */
    public void setOrgnztAdres(String orgnztAdres) {
        this.orgnztAdres = orgnztAdres;
    }
    /**
     * @return the expDmstcSe
     */
    public String getExpDmstcSe() {
        return expDmstcSe;
    }
    /**
     * @param expDmstcSe the expDmstcSe to set
     */
    public void setExpDmstcSe(String expDmstcSe) {
        this.expDmstcSe = expDmstcSe;
    }
    /**
     * @return the distCd
     */
    public String getDistCd() {
        return distCd;
    }
    /**
     * @param distCd the distCd to set
     */
    public void setDistCd(String distCd) {
        this.distCd = distCd;
    }
    /**
     * @return the repDistCd
     */
    public String getRepDistCd() {
        return repDistCd;
    }
    /**
     * @param repDistCd the repDistCd to set
     */
    public void setRepDistCd(String repDistCd) {
        this.repDistCd = repDistCd;
    }
    /**
     * @return the repDistNm
     */
    public String getRepDistNm() {
        return repDistNm;
    }
    /**
     * @param repDistNm the repDistNm to set
     */
    public void setRepDistNm(String repDistNm) {
        this.repDistNm = repDistNm;
    }
    /**
     * @return the repDistYn
     */
    public String getRepDistYn() {
        return repDistYn;
    }
    /**
     * @param repDistYn the repDistYn to set
     */
    public void setRepDistYn(String repDistYn) {
        this.repDistYn = repDistYn;
    }
    /**
     * @return the orgnztSttus
     */
    public String getOrgnztSttus() {
        return orgnztSttus;
    }
    /**
     * @param orgnztSttus the orgnztSttus to set
     */
    public void setOrgnztSttus(String orgnztSttus) {
        this.orgnztSttus = orgnztSttus;
    }
    /**
     * @return the repDealerCd
     */
    public String getRepDealerCd() {
        return repDealerCd;
    }
    /**
     * @param repDealerCd the repDealerCd to set
     */
    public void setRepDealerCd(String repDealerCd) {
        this.repDealerCd = repDealerCd;
    }
    /**
     * @return the repDealerNm
     */
    public String getRepDealerNm() {
        return repDealerNm;
    }
    /**
     * @param repDealerNm the repDealerNm to set
     */
    public void setRepDealerNm(String repDealerNm) {
        this.repDealerNm = repDealerNm;
    }
    /**
     * @return the repDealerYn
     */
    public String getRepDealerYn() {
        return repDealerYn;
    }
    /**
     * @param repDealerYn the repDealerYn to set
     */
    public void setRepDealerYn(String repDealerYn) {
        this.repDealerYn = repDealerYn;
    }
}
