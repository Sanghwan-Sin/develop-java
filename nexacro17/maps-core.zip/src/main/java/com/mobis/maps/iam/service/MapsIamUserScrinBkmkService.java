package com.mobis.maps.iam.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.iam.vo.MapsIamUserScrinBkmkVO;

/**
 * <pre>
 * 사용자 화면 즐겨찾기 서비스
 * </pre>
 *
 * @ClassName   : MapsIamUserScrinBkmkService.java
 * @Description : 사용자 화면 즐겨찾기에 대한 서비스를 정의.
 * @author DT048058
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     DT048058     	최초 생성
 * </pre>
 */

public interface MapsIamUserScrinBkmkService {

    /**
     * 사용자 화면 즐겨찾기 리스트 조회
     *
     * @param iamUserScrinBkmkVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsIamUserScrinBkmkVO> selectUserScrinBkmkList(MapsIamUserScrinBkmkVO iamUserScrinBkmkVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자 화면 즐겨찾기 등록
     *
     * @param iamUserScrinBkmkVO
     * @param loginInfo
     * @throws Exception
     */
    public int insertUserScrinBkmk(MapsIamUserScrinBkmkVO iamUserScrinBkmkVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 사용자 화면 즐겨찾기 삭제
     *
     * @param iamUserScrinBkmkVO
     * @param loginInfo
     * @throws Exception
     */
    public int deleteUserScrinBkmk(MapsIamUserScrinBkmkVO iamUserScrinBkmkVO, LoginInfoVO loginInfo) throws Exception;
    
}
