package com.mobis.maps.comm.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.comm.vo.MapsCommDbTblColVO;

/**
 * <pre>
 * 테이블컬럼정보 데이터 처리
 * </pre>
 *
 * @ClassName   : MapsCommDbTblColMDAO.java
 * @Description : 테이블컬럼정보에 대한 데이터 처리를 정의.
 * @author Sin Sanghwan
 * @since 2019. 9. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 25.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Mapper("mapsCommDbTblColMDAO")
public interface MapsCommDbTblColMDAO {
    
    /**
     * 테이블컬럼정보 리스트 조회
     *
     * @param commDbTblColVO
     * @return
     * @throws Exception
     */
    public List<MapsCommDbTblColVO> selectDbTblColList(MapsCommDbTblColVO commDbTblColVO) throws Exception;

}
