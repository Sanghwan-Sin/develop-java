package com.mobis.maps.nmgn.qm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.qm.service.QualityNonconfirmityService;
import com.mobis.maps.nmgn.qm.vo.FormatDataVO;
import com.mobis.maps.nmgn.qm.vo.QualityNonconfirmityDetVO;
import com.mobis.maps.nmgn.qm.vo.QualityNonconfirmityVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityNonconfirmityServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 14.     jiyongdo     	최초 생성
 * </pre>
 */
@Service("qualityNonconfirmityService")
public class QualityNonconfirmityServiceImpl extends HService implements QualityNonconfirmityService{
    
    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityNonconfirmityService#selectQualityNonconfirmityList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.QualityNonconfirmityVO)
     */
    @Override
    public Map<String, Object> selectQualityNonconfirmityList(LoginInfoVO loginInfo, QualityNonconfirmityVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_S_NCR_LIST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<QualityNonconfirmityVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", paramVO, QualityNonconfirmityVO.class);
        //List<OdrUnprocessedItmLstVO> totLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_SUMMARY", paramVO, OdrUnprocessedItmLstVO.class);
        QualityNonconfirmityVO totLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", QualityNonconfirmityVO.class);
        
        retMap.put("head", totLst);
        retMap.put("body", odrLst);      
        
        return retMap;  
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityNonconfirmityService#selectQualityNonconfirmityDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.QualityNonconfirmityDetVO)
     */
    @Override
    public Map<String, Object> selectQualityNonconfirmityDetail(LoginInfoVO loginInfo, QualityNonconfirmityDetVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_S_NCR_DATA;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        QualityNonconfirmityDetVO dataVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_DATA", QualityNonconfirmityDetVO.class);
        QualityNonconfirmityDetVO esRtnVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", QualityNonconfirmityDetVO.class);
        
        List<QualityNonconfirmityDetVO> lotLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LOT", paramVO, QualityNonconfirmityDetVO.class);
        List<QualityNonconfirmityDetVO> txtLst1 = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_ZREQDESCE", paramVO, QualityNonconfirmityDetVO.class);
        List<QualityNonconfirmityDetVO> txtLst2 = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_ZGOODDESCE", paramVO, QualityNonconfirmityDetVO.class);
        List<QualityNonconfirmityDetVO> txtLst3 = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_ZBADDESCE", paramVO, QualityNonconfirmityDetVO.class);
        
        retMap.put("esRtn"  , esRtnVo);
        retMap.put("data"   , dataVo);   
        retMap.put("lotLst" , lotLst);   
        retMap.put("txtLst1", txtLst1);   
        retMap.put("txtLst2", txtLst2);   
        retMap.put("txtLst3", txtLst3);   
        
        return retMap; 
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityNonconfirmityService#selectFormatData(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.FormatDataVO)
     */
    @Override
    public FormatDataVO selectFormatData(LoginInfoVO loginInfo, FormatDataVO paramVo) throws Exception {
        // RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_CHNNL_S_FORMAT_DATA;
        
        paramVo.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVo);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVo);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);    //func.execute();
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVo);
        FormatDataVO resultVo = new FormatDataVO();
        MapsRfcMappperUtil.setExportParamList(funcRslt, resultVo, loginInfo.getUserLcale());
        
       // String strFscode = StringUtils.trim(funcRslt.getExportParameterList().getValue("E_FSCODE").toString());
       // String strRefNo = StringUtils.trim(funcRslt.getExportParameterList().getValue("E_REF_NO").toString());
       // String strFileSeqno = StringUtils.trim(funcRslt.getExportParameterList().getValue("E_FILE_SEQNO").toString());
        resultVo.setMsgType(paramVo.getMsgType());
        resultVo.setMsg(paramVo.getMsg());
        logger.info("양식 다운로드 관련  공통 기능 호출 strFscode ["+resultVo.geteFscode()+"]  strRefNo ["+resultVo.geteRefNo()+"] strFileSeqno [ "+resultVo.geteFileSeqno()+"]");
        
        return resultVo;
    }
}
