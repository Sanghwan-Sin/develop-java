package com.mobis.maps.nmgn.cc.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsOrderSummaryVO.java
 * @Description : - Order Processing Summary
 *                - Order Status Summary
 *                - Order Unprocessed List
 *                 
 * @author hong.minho
 * @since 2020. 9. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 10.     hong.minho     	최초 생성
 * </pre>
 */

public class MapsOrderSummaryVO extends MapsCommSapRfcIfCommVO {
    /** Dist. Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    
    /** [nMGN] Order Process Total */
    //-----[ES_TOTAL] START-----
    /** Client */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="MANDT" )
    private String mandt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZORDCNT" )
    private BigDecimal zordcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZBOCNT" )
    private BigDecimal zbocnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZALOCNT" )
    private BigDecimal zalocnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICCNT_ON" )
    private BigDecimal zpiccntOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACCNT_ON" )
    private BigDecimal zpaccntOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACCNT" )
    private BigDecimal zpaccnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZLOADCNT" )
    private BigDecimal zloadcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZINVCNT" )
    private BigDecimal zinvcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZSHPCNT" )
    private BigDecimal zshpcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZUNPROCNT" )
    private BigDecimal zunprocnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZORDQTY" )
    private String zordqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZBOQTY" )
    private String zboqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZALOQTY" )
    private String zaloqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICQTY_ON" )
    private String zpicqtyOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACQTY_ON" )
    private String zpacqtyOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACQTY" )
    private String zpacqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZLOADQTY" )
    private String zloadqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZINVQTY" )
    private String zinvqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZSHPQTY" )
    private String zshpqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZORDAMT" )
    private String zordamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZBOAMT" )
    private String zboamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZALOAMT" )
    private String zaloamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICAMT_ON" )
    private String zpicamtOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACAMT_ON" )
    private String zpacamtOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACAMT" )
    private String zpacamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZLOADAMT" )
    private String zloadamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZINVAMT" )
    private String zinvamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZSHPAMT" )
    private String zshpamt;
    //-----[ES_TOTAL] END-----
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the mandt
     */
    public String getMandt() {
        return mandt;
    }
    /**
     * @param mandt the mandt to set
     */
    public void setMandt(String mandt) {
        this.mandt = mandt;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the zordcnt
     */
    public BigDecimal getZordcnt() {
        return zordcnt;
    }
    /**
     * @param zordcnt the zordcnt to set
     */
    public void setZordcnt(BigDecimal zordcnt) {
        this.zordcnt = zordcnt;
    }
    /**
     * @return the zbocnt
     */
    public BigDecimal getZbocnt() {
        return zbocnt;
    }
    /**
     * @param zbocnt the zbocnt to set
     */
    public void setZbocnt(BigDecimal zbocnt) {
        this.zbocnt = zbocnt;
    }
    /**
     * @return the zalocnt
     */
    public BigDecimal getZalocnt() {
        return zalocnt;
    }
    /**
     * @param zalocnt the zalocnt to set
     */
    public void setZalocnt(BigDecimal zalocnt) {
        this.zalocnt = zalocnt;
    }
    /**
     * @return the zpiccntOn
     */
    public BigDecimal getZpiccntOn() {
        return zpiccntOn;
    }
    /**
     * @param zpiccntOn the zpiccntOn to set
     */
    public void setZpiccntOn(BigDecimal zpiccntOn) {
        this.zpiccntOn = zpiccntOn;
    }
    /**
     * @return the zpaccntOn
     */
    public BigDecimal getZpaccntOn() {
        return zpaccntOn;
    }
    /**
     * @param zpaccntOn the zpaccntOn to set
     */
    public void setZpaccntOn(BigDecimal zpaccntOn) {
        this.zpaccntOn = zpaccntOn;
    }
    /**
     * @return the zpaccnt
     */
    public BigDecimal getZpaccnt() {
        return zpaccnt;
    }
    /**
     * @param zpaccnt the zpaccnt to set
     */
    public void setZpaccnt(BigDecimal zpaccnt) {
        this.zpaccnt = zpaccnt;
    }
    /**
     * @return the zloadcnt
     */
    public BigDecimal getZloadcnt() {
        return zloadcnt;
    }
    /**
     * @param zloadcnt the zloadcnt to set
     */
    public void setZloadcnt(BigDecimal zloadcnt) {
        this.zloadcnt = zloadcnt;
    }
    /**
     * @return the zinvcnt
     */
    public BigDecimal getZinvcnt() {
        return zinvcnt;
    }
    /**
     * @param zinvcnt the zinvcnt to set
     */
    public void setZinvcnt(BigDecimal zinvcnt) {
        this.zinvcnt = zinvcnt;
    }
    /**
     * @return the zshpcnt
     */
    public BigDecimal getZshpcnt() {
        return zshpcnt;
    }
    /**
     * @param zshpcnt the zshpcnt to set
     */
    public void setZshpcnt(BigDecimal zshpcnt) {
        this.zshpcnt = zshpcnt;
    }
    /**
     * @return the zunprocnt
     */
    public BigDecimal getZunprocnt() {
        return zunprocnt;
    }
    /**
     * @param zunprocnt the zunprocnt to set
     */
    public void setZunprocnt(BigDecimal zunprocnt) {
        this.zunprocnt = zunprocnt;
    }
    /**
     * @return the zordqty
     */
    public String getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(String zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zaloqty
     */
    public String getZaloqty() {
        return zaloqty;
    }
    /**
     * @param zaloqty the zaloqty to set
     */
    public void setZaloqty(String zaloqty) {
        this.zaloqty = zaloqty;
    }
    /**
     * @return the zpicqtyOn
     */
    public String getZpicqtyOn() {
        return zpicqtyOn;
    }
    /**
     * @param zpicqtyOn the zpicqtyOn to set
     */
    public void setZpicqtyOn(String zpicqtyOn) {
        this.zpicqtyOn = zpicqtyOn;
    }
    /**
     * @return the zpacqtyOn
     */
    public String getZpacqtyOn() {
        return zpacqtyOn;
    }
    /**
     * @param zpacqtyOn the zpacqtyOn to set
     */
    public void setZpacqtyOn(String zpacqtyOn) {
        this.zpacqtyOn = zpacqtyOn;
    }
    /**
     * @return the zpacqty
     */
    public String getZpacqty() {
        return zpacqty;
    }
    /**
     * @param zpacqty the zpacqty to set
     */
    public void setZpacqty(String zpacqty) {
        this.zpacqty = zpacqty;
    }
    /**
     * @return the zloadqty
     */
    public String getZloadqty() {
        return zloadqty;
    }
    /**
     * @param zloadqty the zloadqty to set
     */
    public void setZloadqty(String zloadqty) {
        this.zloadqty = zloadqty;
    }
    /**
     * @return the zinvqty
     */
    public String getZinvqty() {
        return zinvqty;
    }
    /**
     * @param zinvqty the zinvqty to set
     */
    public void setZinvqty(String zinvqty) {
        this.zinvqty = zinvqty;
    }
    /**
     * @return the zshpqty
     */
    public String getZshpqty() {
        return zshpqty;
    }
    /**
     * @param zshpqty the zshpqty to set
     */
    public void setZshpqty(String zshpqty) {
        this.zshpqty = zshpqty;
    }
    /**
     * @return the zordamt
     */
    public String getZordamt() {
        return zordamt;
    }
    /**
     * @param zordamt the zordamt to set
     */
    public void setZordamt(String zordamt) {
        this.zordamt = zordamt;
    }
    /**
     * @return the zboamt
     */
    public String getZboamt() {
        return zboamt;
    }
    /**
     * @param zboamt the zboamt to set
     */
    public void setZboamt(String zboamt) {
        this.zboamt = zboamt;
    }
    /**
     * @return the zaloamt
     */
    public String getZaloamt() {
        return zaloamt;
    }
    /**
     * @param zaloamt the zaloamt to set
     */
    public void setZaloamt(String zaloamt) {
        this.zaloamt = zaloamt;
    }
    /**
     * @return the zpicamtOn
     */
    public String getZpicamtOn() {
        return zpicamtOn;
    }
    /**
     * @param zpicamtOn the zpicamtOn to set
     */
    public void setZpicamtOn(String zpicamtOn) {
        this.zpicamtOn = zpicamtOn;
    }
    /**
     * @return the zpacamtOn
     */
    public String getZpacamtOn() {
        return zpacamtOn;
    }
    /**
     * @param zpacamtOn the zpacamtOn to set
     */
    public void setZpacamtOn(String zpacamtOn) {
        this.zpacamtOn = zpacamtOn;
    }
    /**
     * @return the zpacamt
     */
    public String getZpacamt() {
        return zpacamt;
    }
    /**
     * @param zpacamt the zpacamt to set
     */
    public void setZpacamt(String zpacamt) {
        this.zpacamt = zpacamt;
    }
    /**
     * @return the zloadamt
     */
    public String getZloadamt() {
        return zloadamt;
    }
    /**
     * @param zloadamt the zloadamt to set
     */
    public void setZloadamt(String zloadamt) {
        this.zloadamt = zloadamt;
    }
    /**
     * @return the zinvamt
     */
    public String getZinvamt() {
        return zinvamt;
    }
    /**
     * @param zinvamt the zinvamt to set
     */
    public void setZinvamt(String zinvamt) {
        this.zinvamt = zinvamt;
    }
    /**
     * @return the zshpamt
     */
    public String getZshpamt() {
        return zshpamt;
    }
    /**
     * @param zshpamt the zshpamt to set
     */
    public void setZshpamt(String zshpamt) {
        this.zshpamt = zshpamt;
    }
    
}
