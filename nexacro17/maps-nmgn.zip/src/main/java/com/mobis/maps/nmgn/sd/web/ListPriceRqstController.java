package com.mobis.maps.nmgn.sd.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.nmgn.cc.vo.NewsLetterVO;
import com.mobis.maps.nmgn.sd.service.ListPriceRqstService;
import com.mobis.maps.nmgn.sd.vo.ListPriceRqstVO;
import com.mobis.maps.nmgn.sd.vo.PartInfoVO;
import com.mobis.maps.nmgn.sd.vo.PriceRqstDetailVO;
import com.mobis.maps.nmgn.sd.vo.RqstNoVO;
import com.mobis.maps.nmgn.sd.vo.ZsacutmVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmpListPriceRqstController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 9. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 26.     Jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class ListPriceRqstController extends HController {

    @Resource(name = "mapsSmpListPriceRqstService")
    private ListPriceRqstService mapsSmpListPriceRqstService;
    
    @RequestMapping(value = "/sd/selectPriceRequestList.do")
    public NexacroResult selectPriceRequestList(@ParamDataSet(name="dsInput") ListPriceRqstVO paramVO
                                              , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ListPriceRqstVO> lstSbook = mapsSmpListPriceRqstService.selectPriceRequestList(paramVO, loginInfo);
        
        for(ListPriceRqstVO vo : lstSbook) {
            // status
            if ("R".equals(vo.getStatus())) { // 요청중
                vo.setStatusImg("theme://images/ico_status_req.png");
            } else if ("A".equals(vo.getStatus())) { // 문의결과 회신완료
                vo.setStatusImg("theme://images/ico_status_ok.png");
            } else if ("E".equals(vo.getStatus())) { // 공급 불가 품목
                vo.setStatusImg("theme://images/ico_status_error.png");
            } else if ("D".equals(vo.getStatus())) { // 공급 불가 품목
                vo.setStatusImg("theme://images/ic_no.png");
            } else { // 신규
                vo.setStatusImg("theme://images/ico_new.png");
            }
            vo.setChkRsltCd("S");
        }

        result.addDataSet("dsOutput", lstSbook);
        result.addDataSet("dsOutput2", paramVO);

        return result;
    }
    
    @RequestMapping(value = "/sd/selectPriceRequestListExcelDown.do")
    public NexacroResult selectPriceRequestListExcelDown(@ParamDataSet(name="dsInput") ListPriceRqstVO sbookVO
                                                       , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        sbookVO.setExcelDwnlYn("Y");
        
        List<ListPriceRqstVO> lstSbook = mapsSmpListPriceRqstService.selectPriceRequestList(sbookVO, loginInfo);

        
        for(ListPriceRqstVO vo : lstSbook) {
            vo.setStatusImg(vo.getStatus());
            vo.setXlsYn("Y");
        }        
        
        result.addDataSet("dsOutput", lstSbook);

        return result;
    }    
    
    @RequestMapping(value = "/sd/selectPriceRequestListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectPriceRequestListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<ListPriceRqstVO> lstSbook = new ArrayList<ListPriceRqstVO>();
        List<String[]> rowList = ExcelUtil.importExcelToList(request, 1, 5, 0, "N");
        
        if (rowList != null && !rowList.isEmpty()) {

            for (String[] arrCol : rowList) {

                ListPriceRqstVO smplSbook = new ListPriceRqstVO();
                
                smplSbook.setReqty(arrCol[0]);
                smplSbook.setMatnr(arrCol[1]);
                smplSbook.setMatnrRef(arrCol[2]);
                smplSbook.setReqReason(arrCol[3]);
                lstSbook.add(smplSbook);
            }
        }

        result.addDataSet("dsOutput", lstSbook);

        return result;
    }    
    
    @RequestMapping(value = "/sd/selectZsacutm.do")
    public NexacroResult selectZsacutm(@ParamDataSet(name="dsInput") ZsacutmVO paramVO
                                     , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ZsacutmVO> lstSbook = mapsSmpListPriceRqstService.selectZsacutm(paramVO, loginInfo);

        result.addDataSet("dsOutput", lstSbook);

        return result;
    }    
    
    @RequestMapping(value = "/sd/selectMaktx.do")
    public NexacroResult selectMaktx(@ParamDataSet(name="dsInput") PartInfoVO paramVO
                                   , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PartInfoVO> lstSbook = mapsSmpListPriceRqstService.selectMaktx(paramVO, loginInfo);

        result.addDataSet("dsOutput", lstSbook);

        return result;
    }    
    
    @RequestMapping(value = "/sd/selectReqNo.do")
    public NexacroResult selectReqNo(@ParamDataSet(name="dsInput") RqstNoVO paramVO
                                   , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<RqstNoVO> lstSbook = mapsSmpListPriceRqstService.selectReqNo(paramVO, loginInfo);

        result.addDataSet("dsOutput", lstSbook);

        return result;
    }        
    
    @RequestMapping(value = "/sd/multiListPriceRequest.do")
    public NexacroResult multiListPriceRequest(@ParamDataSet(name="dsInput") ListPriceRqstVO paramVO
                                            , @ParamDataSet(name="dsInput2") List<ListPriceRqstVO> paramList
                                            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = mapsSmpListPriceRqstService.multiListPriceRequest(paramVO, paramList, loginInfo);
        
        @SuppressWarnings("unchecked")
        List<ListPriceRqstVO> retList = (List<ListPriceRqstVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", paramVO);
        result.addDataSet("dsOutput2", retList);        

        return result;
    }
    
    @RequestMapping(value = "/sd/selectPriceRequestDetailList.do")
    public NexacroResult selectPriceRequestDetailList(@ParamDataSet(name="dsInput") PriceRqstDetailVO paramVO
                                                    , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PriceRqstDetailVO> lstSbook = mapsSmpListPriceRqstService.selectPriceRequestDetailList(paramVO, loginInfo);

        result.addDataSet("dsOutput", lstSbook);
        result.addDataSet("dsOutput2", paramVO);

        return result;
    }    
    
    @RequestMapping(value = "/sd/multiPriceRequestDetail.do")
    public NexacroResult multiPriceRequestDetail(@ParamDataSet(name="dsInput") PriceRqstDetailVO paramVO
                                              , @ParamDataSet(name="dsInput2") List<PriceRqstDetailVO> paramList
                                              , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = mapsSmpListPriceRqstService.multiPriceRequestDetail(paramVO, paramList, loginInfo);

        @SuppressWarnings("unchecked")
        List<PriceRqstDetailVO> retList = (List<PriceRqstDetailVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", paramVO);
        result.addDataSet("dsOutput2", retList);        

        return result;
    }   
    
    /**
     * multiSapAtchFile
     *
     * @param NewsLetterVO
     * @param atchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/multiSapAtchFile.do")
    public NexacroResult multiSapAtchFile(@ParamDataSet(name="dsInput") NewsLetterVO atchFileVO
                              , @ParamDataSet(name="dsInputAtchFile") List<MapsAtchFileVO> atchFiles
                              , NexacroResult result) throws Exception {
        
        int procCnt = mapsSmpListPriceRqstService.multiAtchFile(atchFileVO, atchFiles);

        result.addVariable("procCnt", procCnt);

        return result;
    } 
    
    /**
     * selectMaktxMulti
     *
     * @param NewsLetterVO
     * @param 
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/sd/selectMaktxMulti.do")
    public NexacroResult selectMaktxMulti(@ParamDataSet(name="dsInput") PartInfoVO paramVO
                                         ,@ParamDataSet(name="dsInput2") List<ListPriceRqstVO> paramList
                                        , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ListPriceRqstVO> chkVo = mapsSmpListPriceRqstService.selectMaktxMulti(paramVO, paramList, loginInfo);

        result.addDataSet("dsOutput", chkVo);

        return result;
    }      
}
