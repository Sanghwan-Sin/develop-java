package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.nmgn.cc.vo.DpomManualVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistributorPartsOperationManualService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 10. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

public interface DistributorPartsOperationManualService {

    /**
     * DPOM 조회
     *
     * @param loginInfo
     * @param paramVO
     * @return
     * @throws Exception
     */
    List<DpomManualVO> selectDpomList(LoginInfoVO loginInfo, DpomManualVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     * @throws Exception
     */
    DpomManualVO selectDpomEditList(LoginInfoVO loginInfo, DpomManualVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVOList
     * @return
     */
    int multiSaveDpomList(List<DpomManualVO> paramVOList) throws Exception;

    /**
     * Statements
     *
     * @param paramVOList
     * @return
     */
    int deleteDpom(DpomManualVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVOList
     * @return
     */
    int updateDpom(DpomManualVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVOList
     * @return
     */
    DpomManualVO insertDpom(DpomManualVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param atchFileVO
     * @param atchFiles
     * @return
     */
    int multiAtchFile(DpomManualVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception;

}
