package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.PaymentDueOrderListService;
import com.mobis.maps.nmgn.sd.vo.PaymentDueOrderVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PaymentDueOrderListController.java
 * @Description : Payment Due Order List
 * @author jiyongdo
 * @since 2020. 4. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 17.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class PaymentDueOrderListController extends HController{

    @Resource(name = "paymentDueOrderListService")
    private PaymentDueOrderListService paymentDueOrderListService;
    
    /**
     * selectPaymentDueOrderList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPaymentDueOrderList.do")
    public NexacroResult selectPaymentDueOrderList(@ParamDataSet(name="dsInput") PaymentDueOrderVO paramVO
                                                    , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = paymentDueOrderListService.selectPaymentDueOrderList(loginInfo, paramVO);
        
        @SuppressWarnings("unchecked")
        List<PaymentDueOrderVO> retList = (List<PaymentDueOrderVO>)retMap.get("body");
        PaymentDueOrderVO retVo = (PaymentDueOrderVO)retMap.get("head");
        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", retVo);
        result.addDataSet("dsReturn", paramVO);   

        return result;
    }    
    
    /**
     * selectPaymentDueOrderListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPaymentDueOrderListExcelDown.do")
    public NexacroResult selectPaymentDueOrderListExcelDown(@ParamDataSet(name="dsInput") PaymentDueOrderVO paramVO
                                                          , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);     
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(5000);
        
        Map<String, Object> retMap = paymentDueOrderListService.selectPaymentDueOrderList(loginInfo, paramVO);
        
        @SuppressWarnings("unchecked")
        List<PaymentDueOrderVO> retList = (List<PaymentDueOrderVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList);

        return result;
    }      
}
