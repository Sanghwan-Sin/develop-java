package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderSalesSummaryVO.java
 * @Description : ZPSD_NMGN_R_ORDERNSALES_CF
 * @author 이수지
 * @since 2020. 4. 08.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 08.      이수지     	       최초 생성
 * </pre>
 */

public class OrderSalesSummaryVO extends MapsCommSapRfcIfCommVO {
    
    private String distCd;
    private String subDistCd;
    private String zkunam;
    
    /** Year */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_GJAHR" )
    private String iGjahr;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** L - Region */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZLREGIO" )
    private String iZlregio;
    /** M - Region */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZMREGIO" )
    private String iZmregio;
    /** Dist Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** Main Dist. Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZKUNZ1" )
    private String iZkunz1;
    /** Company */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSALCD" )
    private String iZsalcd;
    /** Ship Typr */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSHPTP" )
    private String iZshptp;
    /** S - Region */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSREGIO" )
    private String iZsregio;
    /** Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZTYPE" )
    private String iZtype;       
    
    
    /** -----[ET_LIST_D] START----- */
    
    /** Fiscal Year */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="GJAHR" )
    private BigDecimal gjahr;
    /** Fiscal period */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="MONTH" )
    private BigDecimal month;
    /** Month short text */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="KTX" )
    private String ktx;
    /** Incoming Orders Quantity */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ORDQTY" )
    private BigDecimal ordqty;
    /** Sales Volume Quantity */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="SALQTY" )
    private BigDecimal salqty;
    /** Currency Key */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /** Long Text */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="LTEXT" )
    private String ltext;
    /** Base Unit of Measure for BOM */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="BASME" )
    private String basme;
    /** Order */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ORDAMT" )
    private String ordamt;
    private BigDecimal ordamt1;
    private BigDecimal ordamt2;
    private BigDecimal ordamt3;
    private BigDecimal ordamt4;
    /** Sales */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="SALAMT" )
    private String salamt;
    private BigDecimal salamt1;
    private BigDecimal salamt2;
    private BigDecimal salamt3;
    private BigDecimal salamt4;
    
    /** -----[ES_LIST_H] START----- */
    
    /** Dist. Code */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name 1 */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** Customer group 1 */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /** Description */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="BEZEI" )
    private String bezei;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZSHPTP" )
    private String zshptp;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZSHPTP_TEXT" )
    private String zshptpText;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZSALCD" )
    private String zsalcd;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZSALCD_TEXT" )
    private String zsalcdText;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZLREGIO" )
    private String zlregio;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZLREGIO_TEXT" )
    private String zlregioText;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZMREGIO" )
    private String zmregio;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZMREGIO_TEXT" )
    private String zmregioText;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZSREGIO" )
    private String zsregio;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZSREGIO_TEXT" )
    private String zsregioText;
    
    /** -----[ES_LIST_H] END----- */
    private String type;
    private String year;
    
    /** -----[ET_LIST_D] END----- */     
    
    /**
     * @return the iGjahr
     */
    public String getiGjahr() {
        return iGjahr;
    }
    /**
     * @param iGjahr the iGjahr to set
     */
    public void setiGjahr(String iGjahr) {
        this.iGjahr = iGjahr;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iZlregio
     */
    public String getiZlregio() {
        return iZlregio;
    }
    /**
     * @param iZlregio the iZlregio to set
     */
    public void setiZlregio(String iZlregio) {
        this.iZlregio = iZlregio;
    }
    /**
     * @return the iZmregio
     */
    public String getiZmregio() {
        return iZmregio;
    }
    /**
     * @param iZmregio the iZmregio to set
     */
    public void setiZmregio(String iZmregio) {
        this.iZmregio = iZmregio;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZsalcd
     */
    public String getiZsalcd() {
        return iZsalcd;
    }
    /**
     * @param iZsalcd the iZsalcd to set
     */
    public void setiZsalcd(String iZsalcd) {
        this.iZsalcd = iZsalcd;
    }
    /**
     * @return the iZshptp
     */
    public String getiZshptp() {
        return iZshptp;
    }
    /**
     * @param iZshptp the iZshptp to set
     */
    public void setiZshptp(String iZshptp) {
        this.iZshptp = iZshptp;
    }
    /**
     * @return the iZsregio
     */
    public String getiZsregio() {
        return iZsregio;
    }
    /**
     * @param iZsregio the iZsregio to set
     */
    public void setiZsregio(String iZsregio) {
        this.iZsregio = iZsregio;
    }
    /**
     * @return the iZtype
     */
    public String getiZtype() {
        return iZtype;
    }
    /**
     * @param iZtype the iZtype to set
     */
    public void setiZtype(String iZtype) {
        this.iZtype = iZtype;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the zshptp
     */
    public String getZshptp() {
        return zshptp;
    }
    /**
     * @param zshptp the zshptp to set
     */
    public void setZshptp(String zshptp) {
        this.zshptp = zshptp;
    }
    /**
     * @return the zsalcd
     */
    public String getZsalcd() {
        return zsalcd;
    }
    /**
     * @param zsalcd the zsalcd to set
     */
    public void setZsalcd(String zsalcd) {
        this.zsalcd = zsalcd;
    }
    /**
     * @return the zlregio
     */
    public String getZlregio() {
        return zlregio;
    }
    /**
     * @param zlregio the zlregio to set
     */
    public void setZlregio(String zlregio) {
        this.zlregio = zlregio;
    }
    /**
     * @return the zmregio
     */
    public String getZmregio() {
        return zmregio;
    }
    /**
     * @param zmregio the zmregio to set
     */
    public void setZmregio(String zmregio) {
        this.zmregio = zmregio;
    }
    /**
     * @return the zsregio
     */
    public String getZsregio() {
        return zsregio;
    }
    /**
     * @param zsregio the zsregio to set
     */
    public void setZsregio(String zsregio) {
        this.zsregio = zsregio;
    }
    /**
     * @return the gjahr
     */
    public BigDecimal getGjahr() {
        return gjahr;
    }
    /**
     * @param gjahr the gjahr to set
     */
    public void setGjahr(BigDecimal gjahr) {
        this.gjahr = gjahr;
    }
    /**
     * @return the month
     */
    public BigDecimal getMonth() {
        return month;
    }
    /**
     * @param month the month to set
     */
    public void setMonth(BigDecimal month) {
        this.month = month;
    }
    /**
     * @return the ktx
     */
    public String getKtx() {
        return ktx;
    }
    /**
     * @param ktx the ktx to set
     */
    public void setKtx(String ktx) {
        this.ktx = ktx;
    }
    /**
     * @return the ordqty
     */
    public BigDecimal getOrdqty() {
        return ordqty;
    }
    /**
     * @param ordqty the ordqty to set
     */
    public void setOrdqty(BigDecimal ordqty) {
        this.ordqty = ordqty;
    }
    /**
     * @return the salqty
     */
    public BigDecimal getSalqty() {
        return salqty;
    }
    /**
     * @param salqty the salqty to set
     */
    public void setSalqty(BigDecimal salqty) {
        this.salqty = salqty;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the ltext
     */
    public String getLtext() {
        return ltext;
    }
    /**
     * @param ltext the ltext to set
     */
    public void setLtext(String ltext) {
        this.ltext = ltext;
    }
    /**
     * @return the basme
     */
    public String getBasme() {
        return basme;
    }
    /**
     * @param basme the basme to set
     */
    public void setBasme(String basme) {
        this.basme = basme;
    }
    /**
     * @return the ordamt
     */
    public String getOrdamt() {
        return ordamt;
    }
    /**
     * @param ordamt the ordamt to set
     */
    public void setOrdamt(String ordamt) {
        this.ordamt = ordamt;
    }
    /**
     * @return the ordamt1
     */
    public BigDecimal getOrdamt1() {
        return ordamt1;
    }
    /**
     * @param ordamt1 the ordamt1 to set
     */
    public void setOrdamt1(BigDecimal ordamt1) {
        this.ordamt1 = ordamt1;
    }
    /**
     * @return the ordamt2
     */
    public BigDecimal getOrdamt2() {
        return ordamt2;
    }
    /**
     * @param ordamt2 the ordamt2 to set
     */
    public void setOrdamt2(BigDecimal ordamt2) {
        this.ordamt2 = ordamt2;
    }
    /**
     * @return the ordamt3
     */
    public BigDecimal getOrdamt3() {
        return ordamt3;
    }
    /**
     * @param ordamt3 the ordamt3 to set
     */
    public void setOrdamt3(BigDecimal ordamt3) {
        this.ordamt3 = ordamt3;
    }
    /**
     * @return the ordamt4
     */
    public BigDecimal getOrdamt4() {
        return ordamt4;
    }
    /**
     * @param ordamt4 the ordamt4 to set
     */
    public void setOrdamt4(BigDecimal ordamt4) {
        this.ordamt4 = ordamt4;
    }
    /**
     * @return the salamt
     */
    public String getSalamt() {
        return salamt;
    }
    /**
     * @param salamt the salamt to set
     */
    public void setSalamt(String salamt) {
        this.salamt = salamt;
    }
    /**
     * @return the salamt1
     */
    public BigDecimal getSalamt1() {
        return salamt1;
    }
    /**
     * @param salamt1 the salamt1 to set
     */
    public void setSalamt1(BigDecimal salamt1) {
        this.salamt1 = salamt1;
    }
    /**
     * @return the salamt2
     */
    public BigDecimal getSalamt2() {
        return salamt2;
    }
    /**
     * @param salamt2 the salamt2 to set
     */
    public void setSalamt2(BigDecimal salamt2) {
        this.salamt2 = salamt2;
    }
    /**
     * @return the salamt3
     */
    public BigDecimal getSalamt3() {
        return salamt3;
    }
    /**
     * @param salamt3 the salamt3 to set
     */
    public void setSalamt3(BigDecimal salamt3) {
        this.salamt3 = salamt3;
    }
    /**
     * @return the salamt4
     */
    public BigDecimal getSalamt4() {
        return salamt4;
    }
    /**
     * @param salamt4 the salamt4 to set
     */
    public void setSalamt4(BigDecimal salamt4) {
        this.salamt4 = salamt4;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the year
     */
    public String getYear() {
        return year;
    }
    /**
     * @param year the year to set
     */
    public void setYear(String year) {
        this.year = year;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the bezei
     */
    public String getBezei() {
        return bezei;
    }
    /**
     * @param bezei the bezei to set
     */
    public void setBezei(String bezei) {
        this.bezei = bezei;
    }
    /**
     * @return the zshptpText
     */
    public String getZshptpText() {
        return zshptpText;
    }
    /**
     * @param zshptpText the zshptpText to set
     */
    public void setZshptpText(String zshptpText) {
        this.zshptpText = zshptpText;
    }
    /**
     * @return the zsalcdText
     */
    public String getZsalcdText() {
        return zsalcdText;
    }
    /**
     * @param zsalcdText the zsalcdText to set
     */
    public void setZsalcdText(String zsalcdText) {
        this.zsalcdText = zsalcdText;
    }
    /**
     * @return the zlregioText
     */
    public String getZlregioText() {
        return zlregioText;
    }
    /**
     * @param zlregioText the zlregioText to set
     */
    public void setZlregioText(String zlregioText) {
        this.zlregioText = zlregioText;
    }
    /**
     * @return the zmregioText
     */
    public String getZmregioText() {
        return zmregioText;
    }
    /**
     * @param zmregioText the zmregioText to set
     */
    public void setZmregioText(String zmregioText) {
        this.zmregioText = zmregioText;
    }
    /**
     * @return the zsregioText
     */
    public String getZsregioText() {
        return zsregioText;
    }
    /**
     * @param zsregioText the zsregioText to set
     */
    public void setZsregioText(String zsregioText) {
        this.zsregioText = zsregioText;
    }
    /**
     * @return the iZkunz1
     */
    public String getiZkunz1() {
        return iZkunz1;
    }
    /**
     * @param iZkunz1 the iZkunz1 to set
     */
    public void setiZkunz1(String iZkunz1) {
        this.iZkunz1 = iZkunz1;
    }
    /**
     * @return the distCd
     */
    public String getDistCd() {
        return distCd;
    }
    /**
     * @param distCd the distCd to set
     */
    public void setDistCd(String distCd) {
        this.distCd = distCd;
    }
    /**
     * @return the subDistCd
     */
    public String getSubDistCd() {
        return subDistCd;
    }
    /**
     * @param subDistCd the subDistCd to set
     */
    public void setSubDistCd(String subDistCd) {
        this.subDistCd = subDistCd;
    }
    /**
     * @return the zkunam
     */
    public String getZkunam() {
        return zkunam;
    }
    /**
     * @param zkunam the zkunam to set
     */
    public void setZkunam(String zkunam) {
        this.zkunam = zkunam;
    }

}
