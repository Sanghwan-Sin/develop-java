package com.mobis.maps.nmgn.qm.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityNonconfirmityVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 14.     jiyongdo     	최초 생성
 * </pre>
 */

public class QualityNonconfirmityVO extends MapsCommSapRfcIfCommVO{

    /** 회사 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_BUKRS" )
    private String iBukrs;
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** 계열-해외 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZECMP" )
    private String iZecmp;
    /** 부적합번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZNCRNO" )
    private String iZncrno;    
    /** 기존고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;    
    /** 전송일자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSENDDATEF" )
    private Date iZsenddatef;
    /** 전송일자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSENDDATET" )
    private Date iZsenddatet;
    /** 부적합유형코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZTYPECODE" )
    private String iZtypecode;
    /** SeqNo */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="SEQNO" )
    private Integer seqno;
    /** 회사 코드 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** 회사 코드 또는 회사 이름 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="BUTXT" )
    private String butxt;
    /** 부적합번호 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZNCRNO" )
    private String zncrno;
    /** 기존고객코드 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** 이름 1 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** 자재내역 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** 개선대책서 발생코드 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZOCCODE" )
    private String zoccode;
    /** 부적합유형코드 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZTYPECODE" )
    private String ztypecode;
    /** 성 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZCRNAME" )
    private String zcrname;
    /** 생성일자(local) */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /** 성 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSENDEMP" )
    private String zsendemp;
    /** 전송일자 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSENDDATE" )
    private Date zsenddate;
    /** 성 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZDELEMP" )
    private String zdelemp;
    /** 삭제일자 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZDELDATE" )
    private Date zdeldate;
    /** 삭제사유 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZDELDESC" )
    private String zdeldesc;
    /** 설명 내역 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSTATUS" )
    private String zstatus;
    /** 클레임의뢰코드 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZCREQCODE" )
    private String zcreqcode;
    /** 처리지침-국내 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZRESECODE" )
    private String zresecode;
    /** 포장Lot From */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPSLOTF" )
    private String zpslotf;
    /** 포장Lot To */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPSLOTT" )
    private String zpslott;
    /** 포장사 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPSLIFNR" )
    private String zpslifnr;
    /** 이름 1 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPSLIFNR_NAME" )
    private String zpslifnrName;
    /** 제조사 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPDLIFNR" )
    private String zpdlifnr;
    /** 이름 1 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPDLIFNR_NAME" )
    private String zpdlifnrName;
    /** 설명 내역 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZECMP" )
    private String zecmp;
    /** 의뢰방법(현지언어) */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZREQDESCE" )
    private String zreqdesce;
    /** 정품설명(현지언어) */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZGOODDESCE" )
    private String zgooddesce;
    /** 부적합품설명(현지언어) */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZBADDESCE" )
    private String zbaddesce;
    /** 전량회수대상 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZALLYN" )
    private String zallyn;    
    /**
     * @return the iBukrs
     */
    public String getiBukrs() {
        return iBukrs;
    }
    /**
     * @param iBukrs the iBukrs to set
     */
    public void setiBukrs(String iBukrs) {
        this.iBukrs = iBukrs;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iZecmp
     */
    public String getiZecmp() {
        return iZecmp;
    }
    /**
     * @param iZecmp the iZecmp to set
     */
    public void setiZecmp(String iZecmp) {
        this.iZecmp = iZecmp;
    }
    /**
     * @return the iZncrno
     */
    public String getiZncrno() {
        return iZncrno;
    }
    /**
     * @param iZncrno the iZncrno to set
     */
    public void setiZncrno(String iZncrno) {
        this.iZncrno = iZncrno;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the iZsenddatef
     */
    public Date getiZsenddatef() {
        return iZsenddatef;
    }
    /**
     * @param iZsenddatef the iZsenddatef to set
     */
    public void setiZsenddatef(Date iZsenddatef) {
        this.iZsenddatef = iZsenddatef;
    }
    /**
     * @return the iZsenddatet
     */
    public Date getiZsenddatet() {
        return iZsenddatet;
    }
    /**
     * @param iZsenddatet the iZsenddatet to set
     */
    public void setiZsenddatet(Date iZsenddatet) {
        this.iZsenddatet = iZsenddatet;
    }
    /**
     * @return the iZtypecode
     */
    public String getiZtypecode() {
        return iZtypecode;
    }
    /**
     * @param iZtypecode the iZtypecode to set
     */
    public void setiZtypecode(String iZtypecode) {
        this.iZtypecode = iZtypecode;
    }
    /**
     * @return the seqno
     */
    public Integer getSeqno() {
        return seqno;
    }
    /**
     * @param seqno the seqno to set
     */
    public void setSeqno(Integer seqno) {
        this.seqno = seqno;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the butxt
     */
    public String getButxt() {
        return butxt;
    }
    /**
     * @param butxt the butxt to set
     */
    public void setButxt(String butxt) {
        this.butxt = butxt;
    }
    /**
     * @return the zncrno
     */
    public String getZncrno() {
        return zncrno;
    }
    /**
     * @param zncrno the zncrno to set
     */
    public void setZncrno(String zncrno) {
        this.zncrno = zncrno;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zoccode
     */
    public String getZoccode() {
        return zoccode;
    }
    /**
     * @param zoccode the zoccode to set
     */
    public void setZoccode(String zoccode) {
        this.zoccode = zoccode;
    }
    /**
     * @return the ztypecode
     */
    public String getZtypecode() {
        return ztypecode;
    }
    /**
     * @param ztypecode the ztypecode to set
     */
    public void setZtypecode(String ztypecode) {
        this.ztypecode = ztypecode;
    }
    /**
     * @return the zcrname
     */
    public String getZcrname() {
        return zcrname;
    }
    /**
     * @param zcrname the zcrname to set
     */
    public void setZcrname(String zcrname) {
        this.zcrname = zcrname;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zsendemp
     */
    public String getZsendemp() {
        return zsendemp;
    }
    /**
     * @param zsendemp the zsendemp to set
     */
    public void setZsendemp(String zsendemp) {
        this.zsendemp = zsendemp;
    }
    /**
     * @return the zsenddate
     */
    public Date getZsenddate() {
        return zsenddate;
    }
    /**
     * @param zsenddate the zsenddate to set
     */
    public void setZsenddate(Date zsenddate) {
        this.zsenddate = zsenddate;
    }
    /**
     * @return the zdelemp
     */
    public String getZdelemp() {
        return zdelemp;
    }
    /**
     * @param zdelemp the zdelemp to set
     */
    public void setZdelemp(String zdelemp) {
        this.zdelemp = zdelemp;
    }
    /**
     * @return the zdeldate
     */
    public Date getZdeldate() {
        return zdeldate;
    }
    /**
     * @param zdeldate the zdeldate to set
     */
    public void setZdeldate(Date zdeldate) {
        this.zdeldate = zdeldate;
    }
    /**
     * @return the zdeldesc
     */
    public String getZdeldesc() {
        return zdeldesc;
    }
    /**
     * @param zdeldesc the zdeldesc to set
     */
    public void setZdeldesc(String zdeldesc) {
        this.zdeldesc = zdeldesc;
    }
    /**
     * @return the zstatus
     */
    public String getZstatus() {
        return zstatus;
    }
    /**
     * @param zstatus the zstatus to set
     */
    public void setZstatus(String zstatus) {
        this.zstatus = zstatus;
    }
    /**
     * @return the zcreqcode
     */
    public String getZcreqcode() {
        return zcreqcode;
    }
    /**
     * @param zcreqcode the zcreqcode to set
     */
    public void setZcreqcode(String zcreqcode) {
        this.zcreqcode = zcreqcode;
    }
    /**
     * @return the zresecode
     */
    public String getZresecode() {
        return zresecode;
    }
    /**
     * @param zresecode the zresecode to set
     */
    public void setZresecode(String zresecode) {
        this.zresecode = zresecode;
    }
    /**
     * @return the zpslotf
     */
    public String getZpslotf() {
        return zpslotf;
    }
    /**
     * @param zpslotf the zpslotf to set
     */
    public void setZpslotf(String zpslotf) {
        this.zpslotf = zpslotf;
    }
    /**
     * @return the zpslott
     */
    public String getZpslott() {
        return zpslott;
    }
    /**
     * @param zpslott the zpslott to set
     */
    public void setZpslott(String zpslott) {
        this.zpslott = zpslott;
    }
    /**
     * @return the zpslifnr
     */
    public String getZpslifnr() {
        return zpslifnr;
    }
    /**
     * @param zpslifnr the zpslifnr to set
     */
    public void setZpslifnr(String zpslifnr) {
        this.zpslifnr = zpslifnr;
    }
    /**
     * @return the zpslifnrName
     */
    public String getZpslifnrName() {
        return zpslifnrName;
    }
    /**
     * @param zpslifnrName the zpslifnrName to set
     */
    public void setZpslifnrName(String zpslifnrName) {
        this.zpslifnrName = zpslifnrName;
    }
    /**
     * @return the zpdlifnr
     */
    public String getZpdlifnr() {
        return zpdlifnr;
    }
    /**
     * @param zpdlifnr the zpdlifnr to set
     */
    public void setZpdlifnr(String zpdlifnr) {
        this.zpdlifnr = zpdlifnr;
    }
    /**
     * @return the zpdlifnrName
     */
    public String getZpdlifnrName() {
        return zpdlifnrName;
    }
    /**
     * @param zpdlifnrName the zpdlifnrName to set
     */
    public void setZpdlifnrName(String zpdlifnrName) {
        this.zpdlifnrName = zpdlifnrName;
    }
    /**
     * @return the zecmp
     */
    public String getZecmp() {
        return zecmp;
    }
    /**
     * @param zecmp the zecmp to set
     */
    public void setZecmp(String zecmp) {
        this.zecmp = zecmp;
    }
    /**
     * @return the zreqdesce
     */
    public String getZreqdesce() {
        return zreqdesce;
    }
    /**
     * @param zreqdesce the zreqdesce to set
     */
    public void setZreqdesce(String zreqdesce) {
        this.zreqdesce = zreqdesce;
    }
    /**
     * @return the zgooddesce
     */
    public String getZgooddesce() {
        return zgooddesce;
    }
    /**
     * @param zgooddesce the zgooddesce to set
     */
    public void setZgooddesce(String zgooddesce) {
        this.zgooddesce = zgooddesce;
    }
    /**
     * @return the zbaddesce
     */
    public String getZbaddesce() {
        return zbaddesce;
    }
    /**
     * @param zbaddesce the zbaddesce to set
     */
    public void setZbaddesce(String zbaddesce) {
        this.zbaddesce = zbaddesce;
    }
    /**
     * @return the zallyn
     */
    public String getZallyn() {
        return zallyn;
    }
    /**
     * @param zallyn the zallyn to set
     */
    public void setZallyn(String zallyn) {
        this.zallyn = zallyn;
    }
}
