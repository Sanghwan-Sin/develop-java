package com.mobis.maps.nmgn.ex.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ex.service.InvoiceNoListService;
import com.mobis.maps.nmgn.ex.vo.InvoiceDetailVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceDownloadVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceExcelDownloadVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFtaCoPartsVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFtaCoVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceHeaderVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceNoListVO;
import com.mobis.maps.nmgn.ex.vo.InvoicePackingVO;
import com.mobis.maps.nmgn.ex.vo.InvoicePopVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceNoListServiceImpl.java
 * @Description : Invoice List, Header, Detail
 * @author jiyongdo
 * @since 2020. 2. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 3.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("invoiceNoListService")
public class InvoiceNoListServiceImpl extends HService implements InvoiceNoListService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceNoListService#selectInvoiceNoList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderListVO)
     */
    @Override
    public Map<String, Object> selectInvoiceNoList(LoginInfoVO loginInfo, InvoiceNoListVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_GET_INVOICE_LIST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅            
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        //paramVO.setVkorg("1040");
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        InvoiceNoListVO rtnLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", InvoiceNoListVO.class);        
        List<InvoiceNoListVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, InvoiceNoListVO.class);
        
        retMap.put("head", rtnLst);
        retMap.put("body", odrLst);
        
        return retMap;   
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceNoListService#selectInvoiceDetailList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ex.vo.InvoiceDetailVO)
     */
    @Override
    public Map<String, Object> selectInvoiceDetailList(LoginInfoVO loginInfo, InvoiceDetailVO paramVO)
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_GET_INVOICE_DETAIL;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅            
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        //paramVO.setVkorg("1040");
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        InvoiceDetailVO rtnLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", InvoiceDetailVO.class);        
        List<InvoiceDetailVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, InvoiceDetailVO.class);
        
        retMap.put("head", rtnLst);
        retMap.put("body", odrLst);
        
        return retMap;   
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceNoListService#selectInvoicePackingListExcelDown(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ex.vo.InvoicePackingVO)
     */
    @Override
    public List<InvoicePackingVO> selectInvoicePackingListExcelDown(LoginInfoVO loginInfo, InvoicePackingVO paramVO)
            throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_DOWN_INV_DET_PACKING;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅            
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        //paramVO.setVkorg("1040");
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */    
        List<InvoicePackingVO> lstVo = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, InvoicePackingVO.class);
        
        return lstVo;   
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceNoListService#selectInvoiceDownloadListExcelDown(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ex.vo.InvoiceDownloadVO)
     */
    @Override
    public List<InvoiceDownloadVO> selectInvoiceDownloadListExcelDown(LoginInfoVO loginInfo, InvoiceDownloadVO paramVO)
            throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_DOWN_INV_DET_DOWNLOAD;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅            
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        //paramVO.setVkorg("1040");
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */    
        List<InvoiceDownloadVO> lstVo = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, InvoiceDownloadVO.class);
        
        return lstVo;   
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceNoListService#selectInvoiceNoPopupList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ex.vo.InvoicePopVO)
     */
    @Override
    public List<InvoicePopVO> selectInvoiceNoPopupList(LoginInfoVO loginInfo, InvoicePopVO paramVO) throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_INVOICE_POP_UP;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅            
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */     
        List<InvoicePopVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, InvoicePopVO.class);
        
        return odrLst;   
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceNoListService#selectInvoiceHeaderList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ex.vo.InvoiceHeaderVO)
     */
    @Override
    public Map<String, Object> selectInvoiceHeaderList(LoginInfoVO loginInfo, InvoiceHeaderVO paramVO)
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_GET_INVOICE_HEADER;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅            
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        //paramVO.setVkorg("1040");
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        MapsRfcMappperUtil.setExportParamList(funcRslt, paramVO, loginInfo.getUserLcale());
        /* RFC 호출 조회정보 추출 */
        InvoiceHeaderVO rtnLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", InvoiceHeaderVO.class);        
        List<InvoiceHeaderVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, InvoiceHeaderVO.class);
        
        retMap.put("head", rtnLst);
        retMap.put("body", odrLst);
        
        return retMap;   
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceNoListService#selectInvoiceFtaCoListExcelDown(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ex.vo.InvoiceFtaCoVO)
     */
    @Override
    public List<InvoiceFtaCoVO> selectInvoiceFtaCoListExcelDown(LoginInfoVO loginInfo, InvoiceFtaCoVO paramVO)
            throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_DOWN_INV_HEADER_EU_CO;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅            
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        //paramVO.setVkorg("1040");
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */    
        List<InvoiceFtaCoVO> lstVo = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, InvoiceFtaCoVO.class);
        
        return lstVo;  
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceNoListService#selectInvoiceFtaCoPartsListExcelDown(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ex.vo.InvoiceFtaCoPartsVO)
     */
    @Override
    public List<InvoiceFtaCoPartsVO> selectInvoiceFtaCoPartsListExcelDown(LoginInfoVO loginInfo,
            InvoiceFtaCoPartsVO paramVO) throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_DOWN_INV_HEAD_CO_PART;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅            
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        //paramVO.setVkorg("1040");
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */    
        List<InvoiceFtaCoPartsVO> lstVo = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, InvoiceFtaCoPartsVO.class);
        
        return lstVo;  
    }
    
    @Override
    public List<InvoiceExcelDownloadVO> selectInvoiceExcelDown(LoginInfoVO loginInfo,
           List<InvoiceExcelDownloadVO> paramList) throws Exception {
        List<InvoiceExcelDownloadVO> outputVoList = new ArrayList<>(); //결과리스트
        FunctionResult funcRslt = null;
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_INVOICE_FILE_DOWNLOAD;
        
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
     
        Iterator<InvoiceExcelDownloadVO> itr = paramList.iterator();
        
        while( itr.hasNext() )
        {
            
            InvoiceExcelDownloadVO tmpUploadInputVo=itr.next();
                
            // 파라미터(TABLES) 추출, 적재
            tmpUploadInputVo.setIfCode(sapRfcInfo.getIfCode());
           
            /* RFC 파라미터(Import) 셋팅 */
            // 공통파라미터(Import) 셋팅
            mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, tmpUploadInputVo);
            // 파라미터(Import) 셋팅
            MapsRfcMappperUtil.setImportParamList(func, tmpUploadInputVo);
          
            MapsRfcMappperUtil.appendImportTableRow(func, "IT_INVOICE", tmpUploadInputVo);
            
            // RFC 호출 실행
            funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func, true);
            // RFC 호출 공통결과 정보 추출
            mapsCmmnSapService.selectSetRfcResult(funcRslt, tmpUploadInputVo);
            
            // 개별데이타 저장
            outputVoList=MapsRfcMappperUtil.getExportTableResultValues(funcRslt, "ET_LIST", InvoiceExcelDownloadVO.class);
            //outputVoList=MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", tmpUploadInputVo, ImptPriceItemUploadOutputVO.class);

        }
   
        return outputVoList;
    }
}
