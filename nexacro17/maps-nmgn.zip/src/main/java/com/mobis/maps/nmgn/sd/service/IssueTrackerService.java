package com.mobis.maps.nmgn.sd.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.IssueTrackerAddInputVO;
import com.mobis.maps.nmgn.sd.vo.IssueTrackerVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : Issue Tracker Service.java
 * @Description : Issue Tracker(VOC Request) List 및 상세 조회, Issue Tracker Request Save 및 Update
 * @author ChoKyungHo
 * @since 2020. 03. 02.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 02.   ChoKyungHo     	                    최초 생성
 * </pre>
 */

public interface IssueTrackerService {

    /**
     * Issue Tracker(VOC Request) List 조회
     *
     * @param loginInfo
     * @param IssueTrackerVO
     * @return
     */
    List<IssueTrackerVO> selectIssueTrackerList(LoginInfoVO loginInfo, IssueTrackerVO paramVO) throws Exception;
    
    /**
     * Issue Tracker(VOC Request) Detail 조회
     *
     * @param loginInfo
     * @param IssueTrackerVO
     * @return
     */
    Map<String, Object> selectIssueTrackerDetail(LoginInfoVO loginInfo, IssueTrackerAddInputVO paramVO) throws Exception;

    /**
     * Issue Tracker(VOC Request) 저장
     *
     * @param loginInfo
     * @param paramVO
     * @param paramComments
     * @param paramReply
     * @return
     */
    Map<String, Object> multiSaveIssueTrackerRequest(LoginInfoVO loginInfo, IssueTrackerAddInputVO paramVO,
            List<IssueTrackerAddInputVO> paramComments) throws Exception;

    /**
     * Issue Tracker(VOC Request) 업데이트. 업데이트인 경우에는 ticket번호에 해당하는 reply만 업데이트 함
     *
     * @param loginInfo
     * @param paramVO
     * @param paramReply
     * @return
     */
    Map<String, Object> updateIssueTrackerRequest(LoginInfoVO loginInfo, IssueTrackerAddInputVO paramVO,
            List<IssueTrackerAddInputVO> paramReply) throws Exception;

}
