package com.mobis.maps.nmgn.cc.vo;

import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;
/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SearchInfoVO.java
 * @Description : 구매 공통 팝업 조회
 * @author DT060152
 * @since 2020.02.05.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020.02.05.     DT060152        최초 생성
 * </pre>
 */

public class SearchInfoVO extends MapsCommSapRfcIfCommVO{
    
    /** 회사 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_BUKRS" )
    private String iBukrs;
    /** 이름 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_NAME" )
    private String iName;
    /** P=플랜트, V=사급업체, S=제품업체, C=국가코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CODE" )
    private String iCode;
        
    /** 단일 문자 표시 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_EXCEPTION" )
    private String eException;   
    
    /** [MM] SRS 플랜트, 사급업체 조회 Struc. */
    private List<?> etData;
    /** 코드 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="CODE" )
    private String code;
    /** 이름 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="NAME" )
    private String name;
    
    /**
     * @return the iBukrs
     */
    public String getiBukrs() {
        return iBukrs;
    }
    /**
     * @param iBukrs the iBukrs to set
     */
    public void setiBukrs(String iBukrs) {
        this.iBukrs = iBukrs;
    }
    /**
     * @return the iName
     */
    public String getiName() {
        return iName;
    }
    /**
     * @param iName the iName to set
     */
    public void setiName(String iName) {
        this.iName = iName;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the eException
     */
    public String geteException() {
        return eException;
    }
    /**
     * @param eException the eException to set
     */
    public void seteException(String eException) {
        this.eException = eException;
    }
    /**
     * @return the etData
     */
    public List<?> getEtData() {
        return etData;
    }
    /**
     * @param etData the etData to set
     */
    public void setEtData(List<?> etData) {
        this.etData = etData;
    }
    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the iCode
     */
    public String getiCode() {
        return iCode;
    }
    /**
     * @param iCode the iCode to set
     */
    public void setiCode(String iCode) {
        this.iCode = iCode;
    }
    
}
