package com.mobis.maps.nmgn.qm.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.qm.service.ClaimMultiService;
import com.mobis.maps.nmgn.qm.vo.ClaimMultiCheckVO;
import com.mobis.maps.nmgn.qm.vo.ClaimMultiSaveVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimMultiController.java
 * @Description : Multi Claim 처리
 * @author hong.minho
 * @since 2020. 10. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 10. 20.     hong.minho     	최초 생성
 * </pre>
 */

@Controller
public class ClaimMultiController extends HController {
    
    /*
     * 
     */
    @Resource(name = "claimMultiService")
    ClaimMultiService service;
    


    /**
     * Multi Claim - Claim Check
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/qm/multiCheckClaim.do")
    public NexacroResult multiCheckClaim(@ParamDataSet(name = "dsInput") ClaimMultiCheckVO params,
            @ParamDataSet(name = "dsOutput") List<ClaimMultiCheckVO> paramLst, NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ClaimMultiCheckVO> lst = service.multiCheckClaim(params, paramLst, loginInfo);
        
        result.addDataSet("dsOutput", lst);
        result.addDataSet("dsReturn", params);   

        return result;
    }    
    
    
    /**
     * Multi Claim - Claim Save / Send
     *
     * @param params
     * @param paramLst
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/qm/multiSaveClaim.do")
    public NexacroResult multiSaveClaim(@ParamDataSet(name = "dsInput") ClaimMultiSaveVO params,
            @ParamDataSet(name = "dsOutput") List<ClaimMultiSaveVO> paramLst, NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<ClaimMultiSaveVO> lst = service.multiSaveClaim(params, paramLst, loginInfo);
        
        
        result.addDataSet("dsOutput", lst);
        result.addDataSet("dsReturn", params);   
        
        return result;
    }
}
