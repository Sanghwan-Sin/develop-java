package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceAdjFileDwnVO.java
 * @Description : ZPSD_MGN_R_LIST_PRICE_ADJ_FILE
 * @author 이수지
 * @since 2020. 01. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 01. 28.     이수지     	       최초 생성
 * </pre>
 */

public class ListPriceAdjFileDwnVO extends MapsCommSapRfcIfCommVO {
    
    /** -----[IS_DATES] START----- */
    
    /** ABAP: ID: I/E (포함/제외된 값) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="SIGN" )
    private String sign;
    /** ABAP: 선택옵션 (EQ/BT/CP/...) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="OPTION" )
    private String option;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="LOW" )
    private String low;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="HIGH" )
    private String high;
    
    /** -----[IS_DATES] END----- */
    
    /** 단일 문자 표시 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** H/K 구분 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;    
    /**  */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_UKURS_TXT" )
    private String eUkursTxt;
    
    /** -----[T_RESULT] START----- */
    
    /** 고객코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** 이름 1 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** H/K 구분 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** 코드설명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD_DESC" )
    private String zhkcdDesc;
    /** Received Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZRVC_DATE" )
    private Date zrvcDate;
    /** 가격 리스트 유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PLTYP" )
    private String pltyp;
    /** 코드설명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PTEXT" )
    private String ptext;
    /** SD document currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** 파일내역 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_NAME" )
    private String zfileName;
    /** 파일내역 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_REAL_NAME" )
    private String zfileRealName;
    /** 파일경로 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_PATH" )
    private String zfilePath;
    /** 파일사이즈 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_SIZE" )
    private String zfileSize;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_TYPE" )
    private String zfileType;
    /** Create Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /** Create User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCRNAME" )
    private String zcrname;
    /** Change Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDLDATE" )
    private Date zudldate;
    /** Change User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDNAME" )
    private String zudname;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_SEQNO" )
    private String zfileSeqno;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="REF_NO" )
    private String refNo;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;    
    
    /** -----[T_RESULT] END----- */        
    
    /**
     * @param sign the sign to set
     */
    public void setSign(String sign) {
        this.sign = sign;
    }
    /**
     * @return the sign
     */
    public String getSign() {
        return sign;
    }
    /**
     * @return the option
     */
    public String getOption() {
        return option;
    }
    /**
     * @param option the option to set
     */
    public void setOption(String option) {
        this.option = option;
    }
    /**
     * @return the low
     */
    public String getLow() {
        return low;
    }
    /**
     * @param low the low to set
     */
    public void setLow(String low) {
        this.low = low;
    }
    /**
     * @return the high
     */
    public String getHigh() {
        return high;
    }
    /**
     * @param high the high to set
     */
    public void setHigh(String high) {
        this.high = high;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zhkcdDesc
     */
    public String getZhkcdDesc() {
        return zhkcdDesc;
    }
    /**
     * @param zhkcdDesc the zhkcdDesc to set
     */
    public void setZhkcdDesc(String zhkcdDesc) {
        this.zhkcdDesc = zhkcdDesc;
    }
    /**
     * @return the zrvcDate
     */
    public Date getZrvcDate() {
        return zrvcDate;
    }
    /**
     * @param zrvcDate the zrvcDate to set
     */
    public void setZrvcDate(Date zrvcDate) {
        this.zrvcDate = zrvcDate;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the ptext
     */
    public String getPtext() {
        return ptext;
    }
    /**
     * @param ptext the ptext to set
     */
    public void setPtext(String ptext) {
        this.ptext = ptext;
    }
    /**
     * @return the zfileName
     */
    public String getZfileName() {
        return zfileName;
    }
    /**
     * @param zfileName the zfileName to set
     */
    public void setZfileName(String zfileName) {
        this.zfileName = zfileName;
    }
    /**
     * @return the zfileRealName
     */
    public String getZfileRealName() {
        return zfileRealName;
    }
    /**
     * @param zfileRealName the zfileRealName to set
     */
    public void setZfileRealName(String zfileRealName) {
        this.zfileRealName = zfileRealName;
    }
    /**
     * @return the zfilePath
     */
    public String getZfilePath() {
        return zfilePath;
    }
    /**
     * @param zfilePath the zfilePath to set
     */
    public void setZfilePath(String zfilePath) {
        this.zfilePath = zfilePath;
    }
    /**
     * @return the zfileSize
     */
    public String getZfileSize() {
        return zfileSize;
    }
    /**
     * @param zfileSize the zfileSize to set
     */
    public void setZfileSize(String zfileSize) {
        this.zfileSize = zfileSize;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zcrname
     */
    public String getZcrname() {
        return zcrname;
    }
    /**
     * @param zcrname the zcrname to set
     */
    public void setZcrname(String zcrname) {
        this.zcrname = zcrname;
    }
    /**
     * @return the zudldate
     */
    public Date getZudldate() {
        return zudldate;
    }
    /**
     * @param zudldate the zudldate to set
     */
    public void setZudldate(Date zudldate) {
        this.zudldate = zudldate;
    }
    /**
     * @return the zudname
     */
    public String getZudname() {
        return zudname;
    }
    /**
     * @param zudname the zudname to set
     */
    public void setZudname(String zudname) {
        this.zudname = zudname;
    }
    /**
     * @return the eUkursTxt
     */
    public String geteUkursTxt() {
        return eUkursTxt;
    }
    /**
     * @param eUkursTxt the eUkursTxt to set
     */
    public void seteUkursTxt(String eUkursTxt) {
        this.eUkursTxt = eUkursTxt;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the zfileType
     */
    public String getZfileType() {
        return zfileType;
    }
    /**
     * @param zfileType the zfileType to set
     */
    public void setZfileType(String zfileType) {
        this.zfileType = zfileType;
    }
    /**
     * @return the zfileSeqno
     */
    public String getZfileSeqno() {
        return zfileSeqno;
    }
    /**
     * @param zfileSeqno the zfileSeqno to set
     */
    public void setZfileSeqno(String zfileSeqno) {
        this.zfileSeqno = zfileSeqno;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
}
