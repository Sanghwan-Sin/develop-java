package com.mobis.maps.nmgn.ti.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.service.PartMasterService;
import com.mobis.maps.nmgn.ti.vo.PartMasterDetailVO;
import com.mobis.maps.nmgn.ti.vo.PartMasterVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartMasterController.java
 * @Description : Part Master
 * @author 이수지
 * @since 2020. 5. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 21.     이수지              	최초 생성
 * </pre>
 */

@Controller
public class PartMasterController extends HController{

    @Resource(name = "partMasterService")
    private PartMasterService partMasterService;
    
    /**
     * selectPartMaster
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectPartMasterList.do")
    public NexacroResult selectPartMasterList(@ParamDataSet(name="dsInput") PartMasterVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PartMasterVO> list = partMasterService.selectPartMasterList(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }    
    
    /**
     * selectPartRegionList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectPartRegionList.do")
    public NexacroResult selectPartRegionList(@ParamDataSet(name="dsInput") PartMasterVO params
                                      , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PartMasterVO> list = partMasterService.selectRegionList(loginInfo, params);
        
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectPartModelList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectPartModelList.do")
    public NexacroResult selectPartModelList(@ParamDataSet(name="dsInput") PartMasterVO params
                                      , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PartMasterVO> list = partMasterService.selectModelList(loginInfo, params);
        
        result.addDataSet("dsOutput", list);
        
        return result;
    }   
    
    /**
     * selectPartMasterExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectPartMasterExcelDown.do")
    public NexacroResult selectPartMasterExcelDown(@ParamDataSet(name="dsInput") PartMasterVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<PartMasterVO> list = partMasterService.selectPartMasterList(loginInfo, params);

        result.addDataSet("dsOutput", list);
        
        return result;
    }    
 
    /**
     * selectPartMasterDetailList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectPartMasterDetailList.do")
    public NexacroResult selectPartMasterDetailList(@ParamDataSet(name="dsInput") PartMasterDetailVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        Map<String, Object> retMap = partMasterService.selectPartMasterDetailList(loginInfo, params);
        @SuppressWarnings("unchecked")
        List<PartMasterDetailVO> retList = (List<PartMasterDetailVO>)retMap.get("body");
        PartMasterDetailVO retVo = (PartMasterDetailVO)retMap.get("head");
        PartMasterDetailVO rtnVo = (PartMasterDetailVO)retMap.get("head1");
        
        result.addDataSet("dsOutput", retVo);
        result.addDataSet("dsOutput2", retList);
        result.addDataSet("dsOutput3", rtnVo);
        
        return result;
    }
    
    /**
     * selectPartMasterDetailListExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectPartMasterDetailListExcelDown.do")
    public NexacroResult selectPartMasterDetailListExcelDown(@ParamDataSet(name="dsInput") PartMasterDetailVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        Map<String, Object> retMap = partMasterService.selectPartMasterDetailListExcelDown(loginInfo, params);
        @SuppressWarnings("unchecked")
        List<PartMasterDetailVO> retList = (List<PartMasterDetailVO>)retMap.get("head");
        
        result.addDataSet("dsOutput", retList);
        
        return result;
    }
}
