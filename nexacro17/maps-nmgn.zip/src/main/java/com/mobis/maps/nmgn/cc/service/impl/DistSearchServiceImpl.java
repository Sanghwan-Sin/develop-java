package com.mobis.maps.nmgn.cc.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.nmgn.cc.service.DistSearchService;
import com.mobis.maps.nmgn.cc.service.dao.DistSearchMDAO;
import com.mobis.maps.nmgn.cc.vo.DistSearchVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistSearchServiceImpl.java
 * @Description : 대리점 검색
 * @author hong.minho
 * @since 2020. 3. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 13.     hong.minho     	최초 생성
 * </pre>
 */

@Service("distSearchService")
public class DistSearchServiceImpl extends HService implements DistSearchService {

    @Resource(name = "distSearchMDAO")
    DistSearchMDAO dao;
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.DistSearchService#selectDistSearch(com.mobis.maps.nmgn.cc.vo.DistSearchVO)
     */
    @Override
    public List<DistSearchVO> selectDistSearch(DistSearchVO params) throws MapsBizException, Exception {
        return dao.selectDistSearch(params);
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistSearchService#selectDistInfo(com.mobis.maps.nmgn.cc.vo.DistSearchVO)
     */
    @Override
    public DistSearchVO selectDistInfo(DistSearchVO params, MapsOrgnztDistVO orgVo) throws MapsBizException, Exception {
        
        if (params == null) {
            throw new MapsBizException(messageSource, "EC00000000");
        }
        
        if (StringUtils.isBlank(params.getVkorg())) {
            params.setVkorg(orgVo != null ? orgVo.getVkorg() : "1000");
        }
        
        return dao.selectDistInfo(params);
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistSearchService#selectSubDistLst(com.mobis.maps.nmgn.cc.vo.DistSearchVO, com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.cmmn.vo.MapsOrgnztDistVO)
     */
    @Override
    public List<DistSearchVO> selectSubDistLst(DistSearchVO params, LoginInfoVO loginInfo, MapsOrgnztDistVO orgVo) throws MapsBizException, Exception {
        if (params == null) {
            throw new MapsBizException(messageSource, "EC00000000");
        }
        
        LoginInfoVO loginInfo1 = loginInfo;
        MapsOrgnztDistVO orgVo1 = orgVo;
        
        if (loginInfo1 == null) {loginInfo1 = new LoginInfoVO();}
        if (orgVo1 == null) {orgVo1 = new MapsOrgnztDistVO();}
        
        String vkorg = params.getVkorg();
        if (StringUtils.isBlank(vkorg)) {vkorg = (StringUtils.isBlank(orgVo1.getVkorg()) ? loginInfo1.getBsnOrgnztCd() : orgVo1.getVkorg());}
        if (StringUtils.isBlank(vkorg)) {vkorg = "1000";}
        
        String vtweg = params.getVtweg();
        if (StringUtils.isBlank(vtweg)) {vtweg = (StringUtils.isBlank(orgVo1.getVtweg()) ? "E" : orgVo1.getVtweg());}
        
        // *** params
        params.setVkorg(vkorg);
        params.setVtweg(vtweg);
        params.setZsacutm(StringUtils.isBlank(params.getZsacutm()) ? orgVo1.getZsacutm() : params.getZsacutm()); // ZSACUTM
        
        
        return dao.selectSubDistLst(params);
    }

}
