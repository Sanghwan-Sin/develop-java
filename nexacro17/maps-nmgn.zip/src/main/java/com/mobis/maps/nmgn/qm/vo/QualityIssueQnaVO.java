package com.mobis.maps.nmgn.qm.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityIssueQnaVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 10. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 10. 28.     jiyongdo     	최초 생성
 * </pre>
 */

public class QualityIssueQnaVO extends MapsCommSapRfcIfCommVO{
    //-----[IS_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZTYPE" )
    private String ztype;
    /** Company Code */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="BUKRS" )
    private String bukrs;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZQISSUENO" )
    private String zqissueno;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="ZSEQ" )
    private BigDecimal zseq;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="ZQSTTXT" )
    private String zqsttxt;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="ZQSTDT" )
    private Date zqstdt;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="ZQSTID" )
    private String zqstid;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="ZQSTNAME" )
    private String zqstname;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZQSTMAIL" )
    private String zqstmail;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="FSCODE" )
    private String fscode;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="REF_NO" )
    private String refNo;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="FILE_NAME" )
    private String fileName;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="IS_DATA|ET_DATA", ipttSe="I|E", fieldKey="MSGNO" )
    private String msgno;
    //-----[IS_DATA] END-----
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_FSCODE" )
    private String eFscode;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NO" )
    private String eRefNo;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZSEQ" )
    private BigDecimal eZseq;
    //-----[ET_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="REF_NO_Q" )
    private String refNoQ;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="FILE_NAME_Q" )
    private String fileNameQ;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="FILE_SEQNO_Q" )
    private String fileSeqnoQ;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZANSTXT" )
    private String zanstxt;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZANSDT" )
    private Date zansdt;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZANSID" )
    private String zansid;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZANSNAME" )
    private String zansname;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="REF_NO_A" )
    private String refNoA;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="FILE_NAME_A" )
    private String fileNameA;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="FILE_SEQNO_A" )
    private String fileSeqnoA;
    //-----[ET_DATA] END-----
    /**
     * @return the ztype
     */
    public String getZtype() {
        return ztype;
    }
    /**
     * @param ztype the ztype to set
     */
    public void setZtype(String ztype) {
        this.ztype = ztype;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the zqissueno
     */
    public String getZqissueno() {
        return zqissueno;
    }
    /**
     * @param zqissueno the zqissueno to set
     */
    public void setZqissueno(String zqissueno) {
        this.zqissueno = zqissueno;
    }
    /**
     * @return the zseq
     */
    public BigDecimal getZseq() {
        return zseq;
    }
    /**
     * @param zseq the zseq to set
     */
    public void setZseq(BigDecimal zseq) {
        this.zseq = zseq;
    }
    /**
     * @return the zqsttxt
     */
    public String getZqsttxt() {
        return zqsttxt;
    }
    /**
     * @param zqsttxt the zqsttxt to set
     */
    public void setZqsttxt(String zqsttxt) {
        this.zqsttxt = zqsttxt;
    }
    /**
     * @return the zqstdt
     */
    public Date getZqstdt() {
        return zqstdt;
    }
    /**
     * @param zqstdt the zqstdt to set
     */
    public void setZqstdt(Date zqstdt) {
        this.zqstdt = zqstdt;
    }
    /**
     * @return the zqstid
     */
    public String getZqstid() {
        return zqstid;
    }
    /**
     * @param zqstid the zqstid to set
     */
    public void setZqstid(String zqstid) {
        this.zqstid = zqstid;
    }
    /**
     * @return the zqstname
     */
    public String getZqstname() {
        return zqstname;
    }
    /**
     * @param zqstname the zqstname to set
     */
    public void setZqstname(String zqstname) {
        this.zqstname = zqstname;
    }
    /**
     * @return the zqstmail
     */
    public String getZqstmail() {
        return zqstmail;
    }
    /**
     * @param zqstmail the zqstmail to set
     */
    public void setZqstmail(String zqstmail) {
        this.zqstmail = zqstmail;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }
    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public String getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(String msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the eFscode
     */
    public String geteFscode() {
        return eFscode;
    }
    /**
     * @param eFscode the eFscode to set
     */
    public void seteFscode(String eFscode) {
        this.eFscode = eFscode;
    }
    /**
     * @return the eRefNo
     */
    public String geteRefNo() {
        return eRefNo;
    }
    /**
     * @param eRefNo the eRefNo to set
     */
    public void seteRefNo(String eRefNo) {
        this.eRefNo = eRefNo;
    }
    /**
     * @return the eZseq
     */
    public BigDecimal geteZseq() {
        return eZseq;
    }
    /**
     * @param eZseq the eZseq to set
     */
    public void seteZseq(BigDecimal eZseq) {
        this.eZseq = eZseq;
    }
    /**
     * @return the refNoQ
     */
    public String getRefNoQ() {
        return refNoQ;
    }
    /**
     * @param refNoQ the refNoQ to set
     */
    public void setRefNoQ(String refNoQ) {
        this.refNoQ = refNoQ;
    }
    /**
     * @return the fileNameQ
     */
    public String getFileNameQ() {
        return fileNameQ;
    }
    /**
     * @param fileNameQ the fileNameQ to set
     */
    public void setFileNameQ(String fileNameQ) {
        this.fileNameQ = fileNameQ;
    }
    /**
     * @return the fileSeqnoQ
     */
    public String getFileSeqnoQ() {
        return fileSeqnoQ;
    }
    /**
     * @param fileSeqnoQ the fileSeqnoQ to set
     */
    public void setFileSeqnoQ(String fileSeqnoQ) {
        this.fileSeqnoQ = fileSeqnoQ;
    }
    /**
     * @return the zanstxt
     */
    public String getZanstxt() {
        return zanstxt;
    }
    /**
     * @param zanstxt the zanstxt to set
     */
    public void setZanstxt(String zanstxt) {
        this.zanstxt = zanstxt;
    }
    /**
     * @return the zansdt
     */
    public Date getZansdt() {
        return zansdt;
    }
    /**
     * @param zansdt the zansdt to set
     */
    public void setZansdt(Date zansdt) {
        this.zansdt = zansdt;
    }
    /**
     * @return the zansid
     */
    public String getZansid() {
        return zansid;
    }
    /**
     * @param zansid the zansid to set
     */
    public void setZansid(String zansid) {
        this.zansid = zansid;
    }
    /**
     * @return the zansname
     */
    public String getZansname() {
        return zansname;
    }
    /**
     * @param zansname the zansname to set
     */
    public void setZansname(String zansname) {
        this.zansname = zansname;
    }
    /**
     * @return the refNoA
     */
    public String getRefNoA() {
        return refNoA;
    }
    /**
     * @param refNoA the refNoA to set
     */
    public void setRefNoA(String refNoA) {
        this.refNoA = refNoA;
    }
    /**
     * @return the fileNameA
     */
    public String getFileNameA() {
        return fileNameA;
    }
    /**
     * @param fileNameA the fileNameA to set
     */
    public void setFileNameA(String fileNameA) {
        this.fileNameA = fileNameA;
    }
    /**
     * @return the fileSeqnoA
     */
    public String getFileSeqnoA() {
        return fileSeqnoA;
    }
    /**
     * @param fileSeqnoA the fileSeqnoA to set
     */
    public void setFileSeqnoA(String fileSeqnoA) {
        this.fileSeqnoA = fileSeqnoA;
    }
}
