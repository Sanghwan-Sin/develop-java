package com.mobis.maps.nmgn.cc.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.cc.service.SearchInfoService;
import com.mobis.maps.nmgn.cc.vo.SearchInfoVO;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoStructure;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SearchInfoService.java
 * @Description : 구매 공통 팝업 조회
 * @author DT060152
 * @since 2020. 01. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 01. 29.     DT060152      최초 생성
 * </pre>
 */

@Service("searchInfoService")
public class SearchInfoServiceImpl extends HService implements SearchInfoService {
    
    @Resource(name = "mapsCmmnSapService")  
    private MapsCommSapService mapsCmmnSapService;
    
    /***
     * 공통팝업 조회
     */
    @Override
    public Map<String, Object> selectSearchInfoList(LoginInfoVO loginInfo, SearchInfoVO paramVO)
            throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
      
        /*RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPMM_SRS_S_SEARCH_01;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        /*공통파라미터(Import) 셋팅*/
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        /*파라미터(Import) 셋팅 */
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /*RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        /*RFC 호출 공통결과 정보 추출*/
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        //SH 조회 결과 
        SearchInfoVO esReturn = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", SearchInfoVO.class);
        
        //결과 메시지 처리
        JCoStructure resReturn = funcRslt.getExportParameterList().getStructure("ES_RETURN");
        esReturn.setMsgType(resReturn.getString("MTYPE"));
        esReturn.setMsgId(resReturn.getString("MSGID"));
        esReturn.setMsgNo(resReturn.getString("MSGNO"));
        esReturn.setMsg(resReturn.getString("MESSAGE"));
        
        retMap.put("esReturn", esReturn);
        
        List<SearchInfoVO> etData  = MapsRfcMappperUtil.getExportTableValues(funcRslt, "ET_DATA", SearchInfoVO.class);
        
        retMap.put("etData", etData);

        return retMap;
    }       
}
