package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OdrProcessingListVO.java
 * @Description : ZPSD_NMGN_R_ORDER_SUMMARY
 * @author jiyongdo
 * @since 2020. 1. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 9.     jiyongdo     	최초 생성
 * </pre>
 */

public class OdrProcessingListVO extends MapsCommSapRfcIfCommVO{

    private int rnum;

    /** 단일 문자 표시 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CL_EXC" )
    private String iClExc;
    /** History Display */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_HISTORY" )
    private String iHistory;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** 고객세부유형 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR3" )
    private String iKvgr3;
    /** O : Ordered Date (디폴트), C : Confirmed Date, S : SRD (Shipping Required Date) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_OPT_DATE" )
    private String iOptDate;
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PARTNO" )
    private String iPartno;
    /** C:Create, U:Change, R:Display */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 영업 조직 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** 출하 유형 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VSART" )
    private String iVsart;
    /** 유통 경로 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    /** SD 문서 통화 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_WAERK" )
    private String iWaerk;
    /** Level */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCUGRD3" )
    private String iZcugrd3;
    /** ORDER HEAD PROCESS CODE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZOHPCD" )
    private String iZohpcd;
    /** Ordered Date */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_FR" )
    private Date iZorddtFr;
    /** Ordered Date */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_TO" )
    private Date iZorddtTo;
    /** 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_E" )
    private String iZordnoE;
    /** 고객 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_P" )
    private String iZordnoP;
    /** 오더유형 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDTYP" )
    private String iZordtyp;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    /** SHIP TYPE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSHPTP" )
    private String iZshptp;
    /* ORDER HEAD PROCESS CODE ( =' ') */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZOHPCD_EQ" )
    private String iZohpcdEq;

    /** [SD] Order Total Values summary SAP<->Channel */
    //-----[ES_SUMMARY] START-----
    /**  */
    @MapsRfcMappper( targetName="ES_SUMMARY", ipttSe="E", fieldKey="ZORDCNT_TV" )
    private BigDecimal zordcntTv;
    /**  */
    @MapsRfcMappper( targetName="ES_SUMMARY", ipttSe="E", fieldKey="ZORDCNT_TE" )
    private BigDecimal zordcntTe;
    /**  */
    @MapsRfcMappper( targetName="ES_SUMMARY", ipttSe="E", fieldKey="ZORDCNT_TG" )
    private BigDecimal zordcntTg;
    /**  */
    @MapsRfcMappper( targetName="ES_SUMMARY", ipttSe="E", fieldKey="ZORDCNT_TS_SM" )
    private BigDecimal zordcntTsSm;
    /**  */
    @MapsRfcMappper( targetName="ES_SUMMARY", ipttSe="E", fieldKey="ZORDCNT_TA_SM" )
    private BigDecimal zordcntTaSm;
    /**  */
    @MapsRfcMappper( targetName="ES_SUMMARY", ipttSe="E", fieldKey="ZORDCNT_TP_SM" )
    private BigDecimal zordcntTpSm;
    /**  */
    @MapsRfcMappper( targetName="ES_SUMMARY", ipttSe="E", fieldKey="ZORDCNT_TZ_SM" )
    private BigDecimal zordcntTzSm;
    /**  */
    @MapsRfcMappper( targetName="ES_SUMMARY", ipttSe="E", fieldKey="ZORDCNT_TM" )
    private BigDecimal zordcntTm;
    /**  */
    @MapsRfcMappper( targetName="ES_SUMMARY", ipttSe="E", fieldKey="ZORDCNT_TS" )
    private BigDecimal zordcntTs;
    //-----[ES_SUMMARY] END-----    
    /** [SD] Order Total Values SAP<->Channel */

    //-----[ES_TOTAL] START-----
    /** Item Ordered */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZORDCNT|ZORDCNT" )
    private BigDecimal zordcnt;
    /** Item Confirmed */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCFMCNT|ZCFMCNT" )
    private BigDecimal zcfmcnt;
    /** Item Cancelled */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCANCCNT|ZCANCCNT" )
    private BigDecimal zcanccnt;
    /** Item B/O */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZBOCNT|ZBOCNT" )
    private BigDecimal zbocnt;
    /** Item Allocated */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZALOCNT|ZALOCNT" )
    private BigDecimal zalocnt;
    /** Item On Pick */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPICCNT_ON|ZPICCNT_ON" )
    private BigDecimal zpiccntOn;
    /** Item On Pack */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPACCNT_ON|ZPACCNT_ON" )
    private BigDecimal zpaccntOn;
    /** Item Picked */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPICCNT|ZPICCNT" )
    private BigDecimal zpiccnt;
    /** Item Packed */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPACCNT|ZPACCNT" )
    private BigDecimal zpaccnt;
//    /** Item Transferred */
//    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZTRFCNT|ZTRFCNT" )
//    private BigDecimal ztrfcnt;
//    /** Item Loaded */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZLOADCNT|ZLOADCNT" )
    private BigDecimal zloadcnt;
    /** Item Invoiced */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZINVCNT|ZINVCNT" )
    private BigDecimal zinvcnt;
    /** Item Shipped */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZSHPCNT|ZSHPCNT" )
    private BigDecimal zshpcnt;
    /** Pieces Ordered */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZORDQTY|ZORDQTY" )
    private String zordqty;
    /** Pieces Confirmed */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCFMQTY|ZCFMQTY" )
    private String zcfmqty;
    /** 취소수량 */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCANCQTY|ZCANCQTY" )
    private String zcancqty;
    /** Processing B/O */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZBOQTY|ZBOQTY" )
    private String zboqty;
    /** Processing Alloc. */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZALOQTY|ZALOQTY" )
    private String zaloqty;
    /** On Pick Qty */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPICQTY_ON|ZPICQTY_ON" )
    private String zpicqtyOn;
    /** On Pack Qty */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPACQTY_ON|ZPACQTY_ON" )
    private String zpacqtyOn;
    /** Processing Picked */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPICQTY|ZPICQTY" )
    private String zpicqty;
    /** Processing Packed */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPACQTY|ZPACQTY" )
    private String zpacqty;
//    /** Transferred Qty */
//    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZTRFQTY|ZTRFQTY" )
//    private String ztrfqty;
//    /** Loaded Qty */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZLOADQTY|ZLOADQTY" )
    private String zloadqty;
    /** Processing Invoiced */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZINVQTY|ZINVQTY" )
    private String zinvqty;
    /** Processing Shipped */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZSHPQTY|ZSHPQTY" )
    private String zshpqty;
    /** Amount Ordered */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZORDAMT|ZORDAMT" )
    private String zordamt;
    /** Amount Confirmed */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCFMAMT|ZCFMAMT" )
    private String zcfmamt;
    /** Amount Cancelled */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCANCAMT|ZCANCAMT" )
    private String zcancamt;
    /** Amount B/O */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZBOAMT|ZBOAMT" )
    private String zboamt;
    /** Amount Allocated */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZALOAMT|ZALOAMT" )
    private String zaloamt;
    /** Amount Picked */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPICAMT_ON|ZPICAMT_ON" )
    private String zpicamtOn;
    /** Amount Packed */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPACAMT_ON|ZPACAMT_ON" )
    private String zpacamtOn;
    /** Amount Picked */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPICAMT|ZPICAMT" )
    private String zpicamt;
    /** Amount Packed */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPACAMT|ZPACAMT" )
    private String zpacamt;
//    /** Amount Transferred */
//    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZTRFAMT|ZTRFAMT" )
//    private String ztrfamt;
//    /** Amount Loaded */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZLOADAMT|ZLOADAMT" )
    private String zloadamt;
    /** Amount Invoiced */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZINVAMT|ZINVAMT" )
    private String zinvamt;
    /** Amount Shipped */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZSHPAMT|ZSHPAMT" )
    private String zshpamt;
    
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCURCNT|ZCURCNT" )
    private BigDecimal zcurcnt;
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCURQTY|ZCURQTY" )
    private String zcurqty;
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCURAMT|ZCURAMT" )
    private String zcuramt;
    /** Single-Character Flag */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="HISTORY" )
    private String history;
    
    //-----[ES_TOTAL] END-----
    /** [SD] Order Summary SAP<->Channel */

    //-----[T_RESULT] START-----
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** 고객 오더번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_P" )
    private String zordnoP;
    /** 오더번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /** SEQ번호(청구번호) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO" )
    private String zordno;
    /** 오더유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP" )
    private String zordtyp;
    /** ORDER HEAD PROCESS CODE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZOHPCD" )
    private String zohpcd;
    /** DATA COMMUNI */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCOMTY" )
    private String zcomty;
    /** ORDERED DATE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDDT" )
    private Date zorddt;
    /** ORDERED TIME */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTM" )
    private Date zordtm;
    /** OFFER DATE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZOFFDT" )
    private Date zoffdt;
    /** 플랜트 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WERKS" )
    private String werks;
    /** H/K */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /** ORDER DETAIL FLAG CODE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZODFCD" )
    private String zodfcd;
    /** CONFIRME DATE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCFMDT" )
    private Date zcfmdt;
    /** 최초 할당 시도일 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZALCTDT" )
    private Date zalctdt;
    /** CLOSED DATE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCLSDT" )
    private Date zclsdt;
    /** Level */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCUGRD3" )
    private String zcugrd3;
    /** 고객세부유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR3" )
    private String kvgr3;
    /** 출하 유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="VSART" )
    private String vsart;
    /** 정수 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZLTIME" )
    private Integer zltime;
    /** Rate */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILLRT" )
    private BigDecimal zfillrt;
    /** Rate */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSVCRT" )
    private BigDecimal zsvcrt;
    /** RECEIVED DATE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZRCVDT" )
    private Date zrcvdt;
    /** RECEIVED TIME */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZRCVTM" )
    private Date zrcvtm;
    /** 판매 단위 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="VRKME" )
    private String vrkme;
    /** SD 문서 통화 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    //-----[T_RESULT] END-----
    private BigDecimal zordTot1;
    private BigDecimal zordTot2;
    
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the iClExc
     */
    public String getiClExc() {
        return iClExc;
    }
    /**
     * @param iClExc the iClExc to set
     */
    public void setiClExc(String iClExc) {
        this.iClExc = iClExc;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iKvgr3
     */
    public String getiKvgr3() {
        return iKvgr3;
    }
    /**
     * @param iKvgr3 the iKvgr3 to set
     */
    public void setiKvgr3(String iKvgr3) {
        this.iKvgr3 = iKvgr3;
    }
    /**
     * @return the iOptDate
     */
    public String getiOptDate() {
        return iOptDate;
    }
    /**
     * @param iOptDate the iOptDate to set
     */
    public void setiOptDate(String iOptDate) {
        this.iOptDate = iOptDate;
    }
    /**
     * @return the iPartno
     */
    public String getiPartno() {
        return iPartno;
    }
    /**
     * @param iPartno the iPartno to set
     */
    public void setiPartno(String iPartno) {
        this.iPartno = iPartno;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVsart
     */
    public String getiVsart() {
        return iVsart;
    }
    /**
     * @param iVsart the iVsart to set
     */
    public void setiVsart(String iVsart) {
        this.iVsart = iVsart;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the iWaerk
     */
    public String getiWaerk() {
        return iWaerk;
    }
    /**
     * @param iWaerk the iWaerk to set
     */
    public void setiWaerk(String iWaerk) {
        this.iWaerk = iWaerk;
    }
    /**
     * @return the iZcugrd3
     */
    public String getiZcugrd3() {
        return iZcugrd3;
    }
    /**
     * @param iZcugrd3 the iZcugrd3 to set
     */
    public void setiZcugrd3(String iZcugrd3) {
        this.iZcugrd3 = iZcugrd3;
    }
    /**
     * @return the iZohpcd
     */
    public String getiZohpcd() {
        return iZohpcd;
    }
    /**
     * @param iZohpcd the iZohpcd to set
     */
    public void setiZohpcd(String iZohpcd) {
        this.iZohpcd = iZohpcd;
    }
    /**
     * @return the iZorddtFr
     */
    public Date getiZorddtFr() {
        return iZorddtFr;
    }
    /**
     * @param iZorddtFr the iZorddtFr to set
     */
    public void setiZorddtFr(Date iZorddtFr) {
        this.iZorddtFr = iZorddtFr;
    }
    /**
     * @return the iZorddtTo
     */
    public Date getiZorddtTo() {
        return iZorddtTo;
    }
    /**
     * @param iZorddtTo the iZorddtTo to set
     */
    public void setiZorddtTo(Date iZorddtTo) {
        this.iZorddtTo = iZorddtTo;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the iZordnoP
     */
    public String getiZordnoP() {
        return iZordnoP;
    }
    /**
     * @param iZordnoP the iZordnoP to set
     */
    public void setiZordnoP(String iZordnoP) {
        this.iZordnoP = iZordnoP;
    }
    /**
     * @return the iZordtyp
     */
    public String getiZordtyp() {
        return iZordtyp;
    }
    /**
     * @param iZordtyp the iZordtyp to set
     */
    public void setiZordtyp(String iZordtyp) {
        this.iZordtyp = iZordtyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZshptp
     */
    public String getiZshptp() {
        return iZshptp;
    }
    /**
     * @param iZshptp the iZshptp to set
     */
    public void setiZshptp(String iZshptp) {
        this.iZshptp = iZshptp;
    }
    /**
     * @return the zordcntTv
     */
    public BigDecimal getZordcntTv() {
        return zordcntTv;
    }
    /**
     * @param zordcntTv the zordcntTv to set
     */
    public void setZordcntTv(BigDecimal zordcntTv) {
        this.zordcntTv = zordcntTv;
    }
    /**
     * @return the zordcntTe
     */
    public BigDecimal getZordcntTe() {
        return zordcntTe;
    }
    /**
     * @param zordcntTe the zordcntTe to set
     */
    public void setZordcntTe(BigDecimal zordcntTe) {
        this.zordcntTe = zordcntTe;
    }
    /**
     * @return the zordcntTg
     */
    public BigDecimal getZordcntTg() {
        return zordcntTg;
    }
    /**
     * @param zordcntTg the zordcntTg to set
     */
    public void setZordcntTg(BigDecimal zordcntTg) {
        this.zordcntTg = zordcntTg;
    }
    /**
     * @return the zordcntTm
     */
    public BigDecimal getZordcntTm() {
        return zordcntTm;
    }
    /**
     * @param zordcntTm the zordcntTm to set
     */
    public void setZordcntTm(BigDecimal zordcntTm) {
        this.zordcntTm = zordcntTm;
    }
    /**
     * @return the zordcntTs
     */
    public BigDecimal getZordcntTs() {
        return zordcntTs;
    }
    /**
     * @param zordcntTs the zordcntTs to set
     */
    public void setZordcntTs(BigDecimal zordcntTs) {
        this.zordcntTs = zordcntTs;
    }
    /**
     * @return the zordcnt
     */
    public BigDecimal getZordcnt() {
        return zordcnt;
    }
    /**
     * @param zordcnt the zordcnt to set
     */
    public void setZordcnt(BigDecimal zordcnt) {
        this.zordcnt = zordcnt;
    }
    /**
     * @return the zcfmcnt
     */
    public BigDecimal getZcfmcnt() {
        return zcfmcnt;
    }
    /**
     * @param zcfmcnt the zcfmcnt to set
     */
    public void setZcfmcnt(BigDecimal zcfmcnt) {
        this.zcfmcnt = zcfmcnt;
    }
    /**
     * @return the zcanccnt
     */
    public BigDecimal getZcanccnt() {
        return zcanccnt;
    }
    /**
     * @param zcanccnt the zcanccnt to set
     */
    public void setZcanccnt(BigDecimal zcanccnt) {
        this.zcanccnt = zcanccnt;
    }
    /**
     * @return the zbocnt
     */
    public BigDecimal getZbocnt() {
        return zbocnt;
    }
    /**
     * @param zbocnt the zbocnt to set
     */
    public void setZbocnt(BigDecimal zbocnt) {
        this.zbocnt = zbocnt;
    }
    /**
     * @return the zalocnt
     */
    public BigDecimal getZalocnt() {
        return zalocnt;
    }
    /**
     * @param zalocnt the zalocnt to set
     */
    public void setZalocnt(BigDecimal zalocnt) {
        this.zalocnt = zalocnt;
    }
    /**
     * @return the zpiccntOn
     */
    public BigDecimal getZpiccntOn() {
        return zpiccntOn;
    }
    /**
     * @param zpiccntOn the zpiccntOn to set
     */
    public void setZpiccntOn(BigDecimal zpiccntOn) {
        this.zpiccntOn = zpiccntOn;
    }
    /**
     * @return the zpaccntOn
     */
    public BigDecimal getZpaccntOn() {
        return zpaccntOn;
    }
    /**
     * @param zpaccntOn the zpaccntOn to set
     */
    public void setZpaccntOn(BigDecimal zpaccntOn) {
        this.zpaccntOn = zpaccntOn;
    }
    /**
     * @return the zpiccnt
     */
    public BigDecimal getZpiccnt() {
        return zpiccnt;
    }
    /**
     * @param zpiccnt the zpiccnt to set
     */
    public void setZpiccnt(BigDecimal zpiccnt) {
        this.zpiccnt = zpiccnt;
    }
    /**
     * @return the zpaccnt
     */
    public BigDecimal getZpaccnt() {
        return zpaccnt;
    }
    /**
     * @param zpaccnt the zpaccnt to set
     */
    public void setZpaccnt(BigDecimal zpaccnt) {
        this.zpaccnt = zpaccnt;
    }
    /**
     * @return the zinvcnt
     */
    public BigDecimal getZinvcnt() {
        return zinvcnt;
    }
    /**
     * @param zinvcnt the zinvcnt to set
     */
    public void setZinvcnt(BigDecimal zinvcnt) {
        this.zinvcnt = zinvcnt;
    }
    /**
     * @return the zshpcnt
     */
    public BigDecimal getZshpcnt() {
        return zshpcnt;
    }
    /**
     * @param zshpcnt the zshpcnt to set
     */
    public void setZshpcnt(BigDecimal zshpcnt) {
        this.zshpcnt = zshpcnt;
    }
    /**
     * @return the zordqty
     */
    public String getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(String zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zcfmqty
     */
    public String getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(String zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the zcancqty
     */
    public String getZcancqty() {
        return zcancqty;
    }
    /**
     * @param zcancqty the zcancqty to set
     */
    public void setZcancqty(String zcancqty) {
        this.zcancqty = zcancqty;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zaloqty
     */
    public String getZaloqty() {
        return zaloqty;
    }
    /**
     * @param zaloqty the zaloqty to set
     */
    public void setZaloqty(String zaloqty) {
        this.zaloqty = zaloqty;
    }
    /**
     * @return the zpicqtyOn
     */
    public String getZpicqtyOn() {
        return zpicqtyOn;
    }
    /**
     * @param zpicqtyOn the zpicqtyOn to set
     */
    public void setZpicqtyOn(String zpicqtyOn) {
        this.zpicqtyOn = zpicqtyOn;
    }
    /**
     * @return the zpacqtyOn
     */
    public String getZpacqtyOn() {
        return zpacqtyOn;
    }
    /**
     * @param zpacqtyOn the zpacqtyOn to set
     */
    public void setZpacqtyOn(String zpacqtyOn) {
        this.zpacqtyOn = zpacqtyOn;
    }
    /**
     * @return the zpicqty
     */
    public String getZpicqty() {
        return zpicqty;
    }
    /**
     * @param zpicqty the zpicqty to set
     */
    public void setZpicqty(String zpicqty) {
        this.zpicqty = zpicqty;
    }
    /**
     * @return the zpacqty
     */
    public String getZpacqty() {
        return zpacqty;
    }
    /**
     * @param zpacqty the zpacqty to set
     */
    public void setZpacqty(String zpacqty) {
        this.zpacqty = zpacqty;
    }
    /**
     * @return the zinvqty
     */
    public String getZinvqty() {
        return zinvqty;
    }
    /**
     * @param zinvqty the zinvqty to set
     */
    public void setZinvqty(String zinvqty) {
        this.zinvqty = zinvqty;
    }
    /**
     * @return the zshpqty
     */
    public String getZshpqty() {
        return zshpqty;
    }
    /**
     * @param zshpqty the zshpqty to set
     */
    public void setZshpqty(String zshpqty) {
        this.zshpqty = zshpqty;
    }
    /**
     * @return the zordamt
     */
    public String getZordamt() {
        return zordamt;
    }
    /**
     * @param zordamt the zordamt to set
     */
    public void setZordamt(String zordamt) {
        this.zordamt = zordamt;
    }
    /**
     * @return the zcfmamt
     */
    public String getZcfmamt() {
        return zcfmamt;
    }
    /**
     * @param zcfmamt the zcfmamt to set
     */
    public void setZcfmamt(String zcfmamt) {
        this.zcfmamt = zcfmamt;
    }
    /**
     * @return the zcancamt
     */
    public String getZcancamt() {
        return zcancamt;
    }
    /**
     * @param zcancamt the zcancamt to set
     */
    public void setZcancamt(String zcancamt) {
        this.zcancamt = zcancamt;
    }
    /**
     * @return the zboamt
     */
    public String getZboamt() {
        return zboamt;
    }
    /**
     * @param zboamt the zboamt to set
     */
    public void setZboamt(String zboamt) {
        this.zboamt = zboamt;
    }
    /**
     * @return the zaloamt
     */
    public String getZaloamt() {
        return zaloamt;
    }
    /**
     * @param zaloamt the zaloamt to set
     */
    public void setZaloamt(String zaloamt) {
        this.zaloamt = zaloamt;
    }
    /**
     * @return the zpicamtOn
     */
    public String getZpicamtOn() {
        return zpicamtOn;
    }
    /**
     * @param zpicamtOn the zpicamtOn to set
     */
    public void setZpicamtOn(String zpicamtOn) {
        this.zpicamtOn = zpicamtOn;
    }
    /**
     * @return the zpacamtOn
     */
    public String getZpacamtOn() {
        return zpacamtOn;
    }
    /**
     * @param zpacamtOn the zpacamtOn to set
     */
    public void setZpacamtOn(String zpacamtOn) {
        this.zpacamtOn = zpacamtOn;
    }
    /**
     * @return the zpicamt
     */
    public String getZpicamt() {
        return zpicamt;
    }
    /**
     * @param zpicamt the zpicamt to set
     */
    public void setZpicamt(String zpicamt) {
        this.zpicamt = zpicamt;
    }
    /**
     * @return the zpacamt
     */
    public String getZpacamt() {
        return zpacamt;
    }
    /**
     * @param zpacamt the zpacamt to set
     */
    public void setZpacamt(String zpacamt) {
        this.zpacamt = zpacamt;
    }
    /**
     * @return the zinvamt
     */
    public String getZinvamt() {
        return zinvamt;
    }
    /**
     * @param zinvamt the zinvamt to set
     */
    public void setZinvamt(String zinvamt) {
        this.zinvamt = zinvamt;
    }
    /**
     * @return the zshpamt
     */
    public String getZshpamt() {
        return zshpamt;
    }
    /**
     * @param zshpamt the zshpamt to set
     */
    public void setZshpamt(String zshpamt) {
        this.zshpamt = zshpamt;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the zordnoP
     */
    public String getZordnoP() {
        return zordnoP;
    }
    /**
     * @param zordnoP the zordnoP to set
     */
    public void setZordnoP(String zordnoP) {
        this.zordnoP = zordnoP;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the zohpcd
     */
    public String getZohpcd() {
        return zohpcd;
    }
    /**
     * @param zohpcd the zohpcd to set
     */
    public void setZohpcd(String zohpcd) {
        this.zohpcd = zohpcd;
    }
    /**
     * @return the zcomty
     */
    public String getZcomty() {
        return zcomty;
    }
    /**
     * @param zcomty the zcomty to set
     */
    public void setZcomty(String zcomty) {
        this.zcomty = zcomty;
    }
    /**
     * @return the zorddt
     */
    public Date getZorddt() {
        return zorddt;
    }
    /**
     * @param zorddt the zorddt to set
     */
    public void setZorddt(Date zorddt) {
        this.zorddt = zorddt;
    }
    /**
     * @return the zordtm
     */
    public Date getZordtm() {
        return zordtm;
    }
    /**
     * @param zordtm the zordtm to set
     */
    public void setZordtm(Date zordtm) {
        this.zordtm = zordtm;
    }
    /**
     * @return the zoffdt
     */
    public Date getZoffdt() {
        return zoffdt;
    }
    /**
     * @param zoffdt the zoffdt to set
     */
    public void setZoffdt(Date zoffdt) {
        this.zoffdt = zoffdt;
    }
    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }
    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the zodfcd
     */
    public String getZodfcd() {
        return zodfcd;
    }
    /**
     * @param zodfcd the zodfcd to set
     */
    public void setZodfcd(String zodfcd) {
        this.zodfcd = zodfcd;
    }
    /**
     * @return the zcfmdt
     */
    public Date getZcfmdt() {
        return zcfmdt;
    }
    /**
     * @param zcfmdt the zcfmdt to set
     */
    public void setZcfmdt(Date zcfmdt) {
        this.zcfmdt = zcfmdt;
    }
    /**
     * @return the zalctdt
     */
    public Date getZalctdt() {
        return zalctdt;
    }
    /**
     * @param zalctdt the zalctdt to set
     */
    public void setZalctdt(Date zalctdt) {
        this.zalctdt = zalctdt;
    }
    /**
     * @return the zclsdt
     */
    public Date getZclsdt() {
        return zclsdt;
    }
    /**
     * @param zclsdt the zclsdt to set
     */
    public void setZclsdt(Date zclsdt) {
        this.zclsdt = zclsdt;
    }
    /**
     * @return the zcugrd3
     */
    public String getZcugrd3() {
        return zcugrd3;
    }
    /**
     * @param zcugrd3 the zcugrd3 to set
     */
    public void setZcugrd3(String zcugrd3) {
        this.zcugrd3 = zcugrd3;
    }
    /**
     * @return the kvgr3
     */
    public String getKvgr3() {
        return kvgr3;
    }
    /**
     * @param kvgr3 the kvgr3 to set
     */
    public void setKvgr3(String kvgr3) {
        this.kvgr3 = kvgr3;
    }
    /**
     * @return the vsart
     */
    public String getVsart() {
        return vsart;
    }
    /**
     * @param vsart the vsart to set
     */
    public void setVsart(String vsart) {
        this.vsart = vsart;
    }
    /**
     * @return the zltime
     */
    public Integer getZltime() {
        return zltime;
    }
    /**
     * @param zltime the zltime to set
     */
    public void setZltime(Integer zltime) {
        this.zltime = zltime;
    }
    /**
     * @return the zfillrt
     */
    public BigDecimal getZfillrt() {
        return zfillrt;
    }
    /**
     * @param zfillrt the zfillrt to set
     */
    public void setZfillrt(BigDecimal zfillrt) {
        this.zfillrt = zfillrt;
    }
    /**
     * @return the zsvcrt
     */
    public BigDecimal getZsvcrt() {
        return zsvcrt;
    }
    /**
     * @param zsvcrt the zsvcrt to set
     */
    public void setZsvcrt(BigDecimal zsvcrt) {
        this.zsvcrt = zsvcrt;
    }
    /**
     * @return the zrcvdt
     */
    public Date getZrcvdt() {
        return zrcvdt;
    }
    /**
     * @param zrcvdt the zrcvdt to set
     */
    public void setZrcvdt(Date zrcvdt) {
        this.zrcvdt = zrcvdt;
    }
    /**
     * @return the zrcvtm
     */
    public Date getZrcvtm() {
        return zrcvtm;
    }
    /**
     * @param zrcvtm the zrcvtm to set
     */
    public void setZrcvtm(Date zrcvtm) {
        this.zrcvtm = zrcvtm;
    }
    /**
     * @return the vrkme
     */
    public String getVrkme() {
        return vrkme;
    }
    /**
     * @param vrkme the vrkme to set
     */
    public void setVrkme(String vrkme) {
        this.vrkme = vrkme;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the zordTot1
     */
    public BigDecimal getZordTot1() {
        return zordTot1;
    }
    /**
     * @param zordTot1 the zordTot1 to set
     */
    public void setZordTot1(BigDecimal zordTot1) {
        this.zordTot1 = zordTot1;
    }
    /**
     * @return the zordTot2
     */
    public BigDecimal getZordTot2() {
        return zordTot2;
    }
    /**
     * @param zordTot2 the zordTot2 to set
     */
    public void setZordTot2(BigDecimal zordTot2) {
        this.zordTot2 = zordTot2;
    }
    /**
     * @return the zloadcnt
     */
    public BigDecimal getZloadcnt() {
        return zloadcnt;
    }
    /**
     * @param zloadcnt the zloadcnt to set
     */
    public void setZloadcnt(BigDecimal zloadcnt) {
        this.zloadcnt = zloadcnt;
    }
    /**
     * @return the zloadqty
     */
    public String getZloadqty() {
        return zloadqty;
    }
    /**
     * @param zloadqty the zloadqty to set
     */
    public void setZloadqty(String zloadqty) {
        this.zloadqty = zloadqty;
    }
    /**
     * @return the zloadamt
     */
    public String getZloadamt() {
        return zloadamt;
    }
    /**
     * @param zloadamt the zloadamt to set
     */
    public void setZloadamt(String zloadamt) {
        this.zloadamt = zloadamt;
    }
    /**
     * @return the zcurcnt
     */
    public BigDecimal getZcurcnt() {
        return zcurcnt;
    }
    /**
     * @param zcurcnt the zcurcnt to set
     */
    public void setZcurcnt(BigDecimal zcurcnt) {
        this.zcurcnt = zcurcnt;
    }
    /**
     * @return the zcurqty
     */
    public String getZcurqty() {
        return zcurqty;
    }
    /**
     * @param zcurqty the zcurqty to set
     */
    public void setZcurqty(String zcurqty) {
        this.zcurqty = zcurqty;
    }
    /**
     * @return the zcuramt
     */
    public String getZcuramt() {
        return zcuramt;
    }
    /**
     * @param zcuramt the zcuramt to set
     */
    public void setZcuramt(String zcuramt) {
        this.zcuramt = zcuramt;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the iHistory
     */
    public String getiHistory() {
        return iHistory;
    }
    /**
     * @param iHistory the iHistory to set
     */
    public void setiHistory(String iHistory) {
        this.iHistory = iHistory;
    }
    /**
     * @return the history
     */
    public String getHistory() {
        return history;
    }
    /**
     * @param history the history to set
     */
    public void setHistory(String history) {
        this.history = history;
    }
    /**
     * @return the iZohpcdEq
     */
    public String getiZohpcdEq() {
        return iZohpcdEq;
    }
    /**
     * @param iZohpcdEq the iZohpcdEq to set
     */
    public void setiZohpcdEq(String iZohpcdEq) {
        this.iZohpcdEq = iZohpcdEq;
    }
    /**
     * @return the zordcntTsSm
     */
    public BigDecimal getZordcntTsSm() {
        return zordcntTsSm;
    }
    /**
     * @param zordcntTsSm the zordcntTsSm to set
     */
    public void setZordcntTsSm(BigDecimal zordcntTsSm) {
        this.zordcntTsSm = zordcntTsSm;
    }
    /**
     * @return the zordcntTaSm
     */
    public BigDecimal getZordcntTaSm() {
        return zordcntTaSm;
    }
    /**
     * @param zordcntTaSm the zordcntTaSm to set
     */
    public void setZordcntTaSm(BigDecimal zordcntTaSm) {
        this.zordcntTaSm = zordcntTaSm;
    }
    /**
     * @return the zordcntTpSm
     */
    public BigDecimal getZordcntTpSm() {
        return zordcntTpSm;
    }
    /**
     * @param zordcntTpSm the zordcntTpSm to set
     */
    public void setZordcntTpSm(BigDecimal zordcntTpSm) {
        this.zordcntTpSm = zordcntTpSm;
    }
    /**
     * @return the zordcntTzSm
     */
    public BigDecimal getZordcntTzSm() {
        return zordcntTzSm;
    }
    /**
     * @param zordcntTzSm the zordcntTzSm to set
     */
    public void setZordcntTzSm(BigDecimal zordcntTzSm) {
        this.zordcntTzSm = zordcntTzSm;
    }
}
