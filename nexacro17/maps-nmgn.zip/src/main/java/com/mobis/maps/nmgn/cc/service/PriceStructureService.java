package com.mobis.maps.nmgn.cc.service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.vo.PriceStructureVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PriceStructureService.java
 * @Description : PriceStructureService
 * @author ha.jeongryeong
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     ha.jeongryeong         최초 생성
 * </pre>
 */

public interface PriceStructureService {

    /**
     * 조회 - Price Structure Detail
     *
     * @param paramVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public PriceStructureVO selectPriceStructure(PriceStructureVO paramVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * 저장 - Price Structure Detail
     *
     * @param paramVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    int multiPriceStructure(PriceStructureVO paramVO, LoginInfoVO loginInfo) throws Exception;
}
