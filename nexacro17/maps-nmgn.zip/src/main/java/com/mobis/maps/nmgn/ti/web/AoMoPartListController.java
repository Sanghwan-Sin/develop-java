package com.mobis.maps.nmgn.ti.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.service.AoMoPartListService;
import com.mobis.maps.nmgn.ti.vo.AoMoPartListVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AoMoPartListController.java
 * @Description : ZJTIR02090 AO/MO Part List
 * @author 이수지
 * @since 2020. 5. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 11.       이수지                최초 생성
 * </pre>
 */

@Controller
public class AoMoPartListController extends HController {

    @Resource(name = "aoMoPartListService")
    private AoMoPartListService aoMoPartListService;

    /**
     * selectAoMoPartList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectAoMoPartList.do")
    public NexacroResult selectAoMoPartList(@ParamDataSet(name="dsInput") AoMoPartListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<AoMoPartListVO> list = aoMoPartListService.selectAoMoPartList(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectAoMoPartListExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectAoMoPartListExcelDown.do")
    public NexacroResult selectAoMoPartListExcelDown(@ParamDataSet(name="dsInput") AoMoPartListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<AoMoPartListVO> list = aoMoPartListService.selectAoMoPartList(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectRegion
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectRegion.do")
    public NexacroResult selectRegion(@ParamDataSet(name="dsInput") AoMoPartListVO params
                                      , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<AoMoPartListVO> list = aoMoPartListService.selectRegion(loginInfo, params);
        
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectModel
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectModel.do")
    public NexacroResult selectModel(@ParamDataSet(name="dsInput") AoMoPartListVO params
                                      , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<AoMoPartListVO> list = aoMoPartListService.selectModel(loginInfo, params);
        
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectAoDetail
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectAoDetail.do")
    public NexacroResult selectAoDetail(@ParamDataSet(name="dsInput") AoMoPartListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<AoMoPartListVO> list = aoMoPartListService.selectAoDetail(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectAoDetailExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectAoDetailExcelDown.do")
    public NexacroResult selectAoDetailExcelDown(@ParamDataSet(name="dsInput") AoMoPartListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<AoMoPartListVO> list = aoMoPartListService.selectAoDetail(loginInfo, params);

        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectMoDetail
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectMoDetail.do")
    public NexacroResult selectMoDetail(@ParamDataSet(name="dsInput") AoMoPartListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);      
        
        List<AoMoPartListVO> list = aoMoPartListService.selectMoDetail(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectMoDetailExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectMoDetailExcelDown.do")
    public NexacroResult selectMoDetailExcelDown(@ParamDataSet(name="dsInput") AoMoPartListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<AoMoPartListVO> list = aoMoPartListService.selectMoDetail(loginInfo, params);

        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectAoMoParentList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectAoMoParentList.do")
    public NexacroResult selectAoMoParentList(@ParamDataSet(name="dsInput") AoMoPartListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<AoMoPartListVO> list = aoMoPartListService.selectAoMoParentList(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectAoMoParentListExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectAoMoParentListExcelDown.do")
    public NexacroResult selectAoMoParentListExcelDown(@ParamDataSet(name="dsInput") AoMoPartListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<AoMoPartListVO> list = aoMoPartListService.selectAoMoParentList(loginInfo, params);

        result.addDataSet("dsOutput", list);
        
        return result;
    }
}
