package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.nmgn.cc.vo.NewsLetterVO;
import com.mobis.maps.nmgn.cc.vo.TargetTreeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : NewsLetterMDAO.java
 * @Description : News Letter
 * @author 이수지
 * @since 2020. 03. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 31.    이수지               	최초 생성
 * </pre>
 */
@Mapper("newsLetterMDAO")
public interface NewsLetterMDAO {

    /**
     * News Letter 조회
     *
     * @param paramVO
     * @return
     */
    List<NewsLetterVO> selectNewsLetter(NewsLetterVO params) throws Exception;
    
    /**
     * News Letter 저장
     *
     * @param paramVO
     * @return
     */
    int insertNewsLetter(NewsLetterVO params) throws Exception;
    
    /**
     * News Letter 상세조회
     *
     * @param paramVO
     * @return
     */
    List<NewsLetterVO> selectNewsLetterDetail(NewsLetterVO params) throws Exception;
    
    /**
     * News Letter Read Count 업데이트
     */
    int updateNewsLetterReadCount(NewsLetterVO params) throws Exception;
    
    /**
     * News Letter 수정
     *
     * @param paramVO
     * @return
     */
    int updateNewsLetter(NewsLetterVO params) throws Exception;
    
    /**
     * News Letter 삭제
     *
     * @param paramVO
     * @return
     */
    int deleteNewsLetter(NewsLetterVO params) throws Exception;
    
    /**
     * 첨부파일 등록
     *
     * @param paramVOList
     * @return
     */
    public int multiAtchFile(AtchFileSe atchFileSe, Object atchFileBaseInfo, List<MapsAtchFileVO> atchFiles) throws Exception;

    /**
     * selectTargetTreeList
     *
     * @param params
     * @return
     */
    List<TargetTreeVO> selectTargetTreeList(TargetTreeVO params) throws Exception;

    /**
     * 메일전송 상태 업데이트
     *
     * @param params
     */
    void updateNewsLetteMail(NewsLetterVO params);    
}
