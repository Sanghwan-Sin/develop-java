package com.mobis.maps.nmgn.cc.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.nmgn.cc.service.DistributorPartsOperationManualService;
import com.mobis.maps.nmgn.cc.service.dao.DistributorPartsOperationManualMDAO;
import com.mobis.maps.nmgn.cc.vo.DpomManualVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistributorPartsOperationManualServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 10. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 22.     Jiyongdo     	최초 생성
 * </pre>
 */
@Service("distributorPartsOperationManualService")
public class DistributorPartsOperationManualServiceImpl extends HService implements DistributorPartsOperationManualService{

    @Resource(name = "distributorPartsOperationManualMDAO")
    DistributorPartsOperationManualMDAO distributorPartsOperationManualMDAO;
    
    @Resource(name="mapsCommFileService")
    private MapsCommFileService mapsCommFileService;    

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistributorPartsOperationManualService#selectDpomList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.DpomManualVO)
     */
    @Override
    public List<DpomManualVO> selectDpomList(LoginInfoVO loginInfo, DpomManualVO paramVO) throws Exception {
        List<DpomManualVO> retList = distributorPartsOperationManualMDAO.selectDpomList(paramVO);
        return retList;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistributorPartsOperationManualService#selectDpomEditList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.DpomManualVO)
     */
    @Override
    public DpomManualVO selectDpomEditList(LoginInfoVO loginInfo, DpomManualVO paramVO) throws Exception {
        DpomManualVO retslt = distributorPartsOperationManualMDAO.selectDpomEditList(paramVO);
        distributorPartsOperationManualMDAO.updateDpomRdCnt(paramVO);
        retslt.setRcnt(paramVO.getRcnt());        
        return retslt;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistributorPartsOperationManualService#saveDpomList(com.mobis.maps.nmgn.cc.vo.DpomManualVO)
     */
    @Override
    public int multiSaveDpomList(List<DpomManualVO> paramVOList) throws Exception {
        int nProcCnt = 0;
        
        for(DpomManualVO tmpVO : paramVOList) {
            if("Y".equals(tmpVO.getChkYn())){
                tmpVO.setUpdtId("SYSTEM");
                nProcCnt = distributorPartsOperationManualMDAO.deleteDpomList(tmpVO);
                distributorPartsOperationManualMDAO.deleteAtchFileAll(tmpVO);
            }
        }
        return nProcCnt;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistributorPartsOperationManualService#deleteDpom(com.mobis.maps.nmgn.cc.vo.DpomManualVO)
     */
    @Override
    public int deleteDpom(DpomManualVO paramVO) throws Exception {
        int nDelCnt = 0;
        nDelCnt = distributorPartsOperationManualMDAO.deleteDpom(paramVO);
        return nDelCnt;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistributorPartsOperationManualService#updateDpom(com.mobis.maps.nmgn.cc.vo.DpomManualVO)
     */
    @Override
    public int updateDpom(DpomManualVO paramVO) throws Exception {
        int nUpdCnt = 0;
        nUpdCnt = distributorPartsOperationManualMDAO.updateDpom(paramVO);
        return nUpdCnt;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistributorPartsOperationManualService#insertDpom(com.mobis.maps.nmgn.cc.vo.DpomManualVO)
     */
    @Override
    public DpomManualVO insertDpom(DpomManualVO paramVO) throws Exception {
        //List<DpomManualVO> retList = distributorPartsOperationManualMDAO.selectDpomList(paramVO);
        distributorPartsOperationManualMDAO.insertDpom(paramVO);
//        DpomManualVO retVo = distributorPartsOperationManualMDAO.insertDpom(paramVO);
        DpomManualVO retVo = new DpomManualVO();
        retVo.setDocNo(paramVO.getDocNo());
        return retVo;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistributorPartsOperationManualService#multiAtchFile(com.mobis.maps.nmgn.cc.vo.DpomManualVO, java.util.List)
     */
    @Override
    public int multiAtchFile(DpomManualVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception {
        int retCnt = 0;
        if (atchFiles != null && atchFiles.size()>0) {
            AtchFileSe atchFileGubn = AtchFileSe.get(atchFileVO.getAtchSe()); 
            retCnt = mapsCommFileService.multiAtchFile(atchFileGubn, atchFileVO, atchFiles);    
        }
        return retCnt;
    }
}
