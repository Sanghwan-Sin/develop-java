package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.CanvassListPubOrderVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CanvassListPubOrderService.java
 * @Description : ZJSDO30240_P Canvass List for Publication Order
 * @author 이수지
 * @since 2020. 2. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 20.       이수지      	                                 최초 생성
 * </pre>
 */

public interface CanvassListPubOrderService {

    /**
     * Canvass List for Publication Order
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<CanvassListPubOrderVO> selectCanvassListPubOrder (LoginInfoVO loginVo, CanvassListPubOrderVO params) throws Exception;
}
