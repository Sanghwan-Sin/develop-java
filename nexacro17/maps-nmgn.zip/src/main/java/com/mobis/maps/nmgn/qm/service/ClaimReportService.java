package com.mobis.maps.nmgn.qm.service;

import java.util.List;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.qm.vo.ClaimReportVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimReportService.java
 * @Description : Claim Report
 * @author hong.minho
 * @since 2020. 10. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 10. 12.     hong.minho     	최초 생성
 * </pre>
 */

public interface ClaimReportService {

    /**
     * Claim Report
     *
     * @param loginInfo
     * @param paramVO
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    List<ClaimReportVO> selectClaimReport(LoginInfoVO loginInfo, ClaimReportVO paramVO) throws MapsBizException, Exception;
    
}
