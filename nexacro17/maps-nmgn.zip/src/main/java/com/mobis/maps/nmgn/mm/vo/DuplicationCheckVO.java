package com.mobis.maps.nmgn.mm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DuplicationCheckVO.java
 * @Description : ZPMM_NMGN_R_DUPCHK_PI_REQ
 * @author 이수지
 * @since 2020. 3.6
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3.6          이수지     	       최초 생성
 * </pre>
 */

public class DuplicationCheckVO extends MapsCommSapRfcIfCommVO {
    
    /** 회사코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_BUKRS" )
    private String iBukrs;
    /** 부품코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** 사업장 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_WERKS" )
    private String iWerks;
    /** 내수/수출 구분 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZEDCD" )
    private String iZedcd;
    /** H/K 구분 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** 중복검토 여부 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_DUPCHK" )
    private String eDupchk;
    
    /**
     * @return the iBukrs
     */
    public String getiBukrs() {
        return iBukrs;
    }
    /**
     * @param iBukrs the iBukrs to set
     */
    public void setiBukrs(String iBukrs) {
        this.iBukrs = iBukrs;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iWerks
     */
    public String getiWerks() {
        return iWerks;
    }
    /**
     * @param iWerks the iWerks to set
     */
    public void setiWerks(String iWerks) {
        this.iWerks = iWerks;
    }
    /**
     * @return the iZedcd
     */
    public String getiZedcd() {
        return iZedcd;
    }
    /**
     * @param iZedcd the iZedcd to set
     */
    public void setiZedcd(String iZedcd) {
        this.iZedcd = iZedcd;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the eDupchk
     */
    public String geteDupchk() {
        return eDupchk;
    }
    /**
     * @param eDupchk the eDupchk to set
     */
    public void seteDupchk(String eDupchk) {
        this.eDupchk = eDupchk;
    }
}
