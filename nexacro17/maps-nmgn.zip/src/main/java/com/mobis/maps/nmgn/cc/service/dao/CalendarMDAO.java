package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.nmgn.cc.vo.CalendarHdyVO;
import com.mobis.maps.nmgn.cc.vo.CalendarVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarMDAO.java
 * @Description : Work Calendar
 * @author hong.minho
 * @since 2020. 5. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 21.     hong.minho     	최초 생성
 * </pre>
 */

@Mapper("calendarMDAO")
public interface CalendarMDAO {

    /**
     * 법인별 Calendar 조회
     *
     * @param params
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    List<CalendarVO> selectCalendar(CalendarVO params) throws Exception;
    
    
    /**
     * 법인별 기념일 조회
     *
     * @param params
     * @return
     * @throws Exception
     */
    List<CalendarHdyVO> selectAnniversary(CalendarVO params) throws Exception;


    /**
     * 월 Calendar 조회
     *
     * @param params
     * @return
     * @throws Exception
     */
    List<CalendarVO> selectCalendarMon(CalendarVO params) throws Exception;
}
