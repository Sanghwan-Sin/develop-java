package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.RfcOptionVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.HqHsCodeService;
import com.mobis.maps.nmgn.sd.vo.HqFtaAgreementVO;
import com.mobis.maps.nmgn.sd.vo.HqHsCodeVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : HqHsCodeServiceImpl.java
 * @Description : ZJSDR50030 HQ HS code by parts no
 * @author 이수지
 * @since 2020. 01. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 01. 17.      이수지      	        최초 생성
 * </pre>
 */

@Service("hqHsCodeService")
public class HqHsCodeServiceImpl extends HService implements HqHsCodeService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.sd.service.HqHsCodeService#selectHqHsCode(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.HqHsCodeVO, java.util.List)
     */
    @Override
    public List<HqHsCodeVO> selectHqHsCode(LoginInfoVO loginVo, HqHsCodeVO params,  List<RfcOptionVO> paramList)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_GTS_R_HSCODE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        MapsRfcMappperUtil.appendImportMultiOptions(func, "IR_MATNR", paramList);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<HqHsCodeVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "CT_DATA", params, HqHsCodeVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.HqHsCodeService#selectHqFtaAgreement(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.HqFtaAgreementVO)
     */
    @Override
    public List<HqFtaAgreementVO> selectHqFtaAgreement(LoginInfoVO loginVo, HqFtaAgreementVO params) throws Exception {
       
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_S_AGREEMENT2;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<HqFtaAgreementVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", params, HqFtaAgreementVO.class);
        
        return list;
    }

}
