package com.mobis.maps.nmgn.cc.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.nmgn.cc.service.MapsNoticeService;
import com.mobis.maps.nmgn.cc.service.dao.MapsNoticeMDAO;
import com.mobis.maps.nmgn.cc.vo.MapsNoticeAtchFileVO;
import com.mobis.maps.nmgn.cc.vo.MapsNoticeVO;



/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsNoticeServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

@Service("mapsNoticeService")
public class MapsNoticeServiceImpl extends HService implements MapsNoticeService{
    @Resource(name = "mapsNoticeMDAO")
    private MapsNoticeMDAO mapsNoticeMDAO;
    
    @Resource(name="mapsCommFileService")
    private MapsCommFileService mapsCommFileService;

    /*
     * @see com.mobis.maps.smpl.service.MapsNoticeService#selectNoticeList(com.mobis.maps.smpl.vo.MapsNoticeVO)
     */
    @Override
    public List<MapsNoticeVO> selectNoticeList(MapsNoticeVO inputVO) {
        List<MapsNoticeVO> mapsNoticeVO = mapsNoticeMDAO.selectNoticeList(inputVO);
        return mapsNoticeVO;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsNoticeService#selectNoticeNewList(com.mobis.maps.smpl.vo.MapsNoticeVO)
     */
    @Override
    public MapsNoticeVO selectNoticeNewList(MapsNoticeVO inputVO) throws Exception {  
        MapsNoticeVO mapsNoticeVO = mapsNoticeMDAO.selectNoticeNewList(inputVO);
        mapsNoticeMDAO.updateNoticeRdCnt(inputVO);
        mapsNoticeVO.setRdCnt(inputVO.getRdCnt());
        return mapsNoticeVO;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsNoticeService#multiNotice(com.mobis.maps.smpl.vo.MapsNoticeVO)
     */
    @Override
    public MapsNoticeVO multiNotice(MapsNoticeVO inputVO) throws Exception {
        
        MapsNoticeVO rtnVo = new MapsNoticeVO();
        if("S".equals(inputVO.getSaveType()))
        {
            MapsNoticeVO paramVo = mapsNoticeMDAO.selectContId(inputVO);
            if(!"".equals(paramVo.getBbscttId()) && !StringUtils.isEmpty(paramVo.getBbscttId()))
            {
                inputVO.setBbscttId(paramVo.getBbscttId());
            }
            else
            {
                inputVO.setBbscttId("0");
            }            
            mapsNoticeMDAO.insertNotice(inputVO);
            rtnVo.setAtchId(inputVO.getBbscttId());
        }       
        else if("U".equals(inputVO.getSaveType()))
        {            
            mapsNoticeMDAO.updateNotice(inputVO);
            rtnVo.setAtchId(inputVO.getBbscttId());
        }
        else if("D".equals(inputVO.getSaveType()))
        {            
            mapsNoticeMDAO.deleteNotice(inputVO);

            MapsAtchFileVO atchFileVO = new MapsAtchFileVO();            
            atchFileVO.setAtchSe(inputVO.getAtchSe());
            atchFileVO.setAtchId(inputVO.getBbscttId());
            
            mapsCommFileService.deleteAtchFileAll(atchFileVO);
        }
        return rtnVo;
    }
    
    @Override
    public int multiNoticeAtchFile(MapsNoticeAtchFileVO mapsNoticeAtchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception {

        AtchFileSe atchFileSe = AtchFileSe.get(mapsNoticeAtchFileVO.getAtchSe());
        
        int procCnt = mapsCommFileService.multiAtchFile(atchFileSe, mapsNoticeAtchFileVO, atchFiles);
        
        return procCnt;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.MapsNoticeService#selectMainNoticeList(com.mobis.maps.nmgn.cc.vo.MapsNoticeVO)
     */
    @Override
    public List<MapsNoticeVO> selectMainNoticeList(MapsNoticeVO inputVO) throws Exception {
        List<MapsNoticeVO> mapsNoticeVO = mapsNoticeMDAO.selectMainNoticeList(inputVO);
        return mapsNoticeVO;
    }
}
