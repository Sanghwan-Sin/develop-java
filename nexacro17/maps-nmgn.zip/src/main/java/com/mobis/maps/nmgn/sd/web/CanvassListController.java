package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.CanvassListService;
import com.mobis.maps.nmgn.sd.vo.CanvassListVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CanvassListController.java
 * @Description : ZJSDR30290 Canvass List
 * @author 이수지
 * @since 2020. 2. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 25.       이수지                최초 생성
 * </pre>
 */

@Controller
public class CanvassListController extends HController {

    @Resource(name = "canvassListService")
    private CanvassListService canvassListService;

    /**
     * selectCanvassList
     *
     * @param params
     * @param results
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectCanvassList.do")
    public NexacroResult selectCanvassList(@ParamDataSet(name="dsInput") CanvassListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<CanvassListVO> list = canvassListService.selectCanvassList(loginInfo, params);
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectCanvassListExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectCanvassListExcelDown.do")
    public NexacroResult selectCanvassListExcelDown(@ParamDataSet(name="dsInput") CanvassListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<CanvassListVO> list = canvassListService.selectCanvassList(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }

}
