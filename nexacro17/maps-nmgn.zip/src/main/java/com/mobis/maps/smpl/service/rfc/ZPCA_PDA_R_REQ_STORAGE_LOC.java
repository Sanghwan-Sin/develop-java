package com.mobis.maps.smpl.service.rfc;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ZPCA_PDA_R_REQ_STORAGE_LOC.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 17.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public enum ZPCA_PDA_R_REQ_STORAGE_LOC {
    
    impParam
    , impTbl
    , expParam
    , expTbl
    ;
    
    private ZPCA_PDA_R_REQ_STORAGE_LOC() {
    }
}
