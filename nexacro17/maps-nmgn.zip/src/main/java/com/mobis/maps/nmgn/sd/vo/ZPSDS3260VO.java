package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ZPSDS3260VO.java
 * @Description : METD : ETD Result
 * @author hong.minho
 * @since 2020. 7. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 20.     hong.minho     	최초 생성
 * </pre>
 */

public class ZPSDS3260VO extends MapsCommSapRfcIfCommVO {
    private String ordno;   /* [ordno,0~10      ] Order Number */
    private String ordln;   /* [ordln,10~14     ] Line Item Number */
    private String ordls;   /* [ordls,14~15     ] Line Item Number Suffix */
    private String ptno;    /* [ptno,15~33      ] 파트번호 */
    private String fbqty;   /* [fbqty,33~40     ] FIRST 백오더 수량 */
    private String lbqty;   /* [lbqty,40~47     ] LAST 백오더 수량 */
    private String prqty;   /* [prqty,47~54     ] 공정수량 */
    private String spqty;   /* [spqty,54~61     ] 선적수량 */
    private String prEtddt; /* [prEtddt,61~69   ] 재고할당 ETD일자 */
    private String prEtdqt; /* [prEtdqt,69~76   ] 재고할당 ETD수량 */
    private String prNoetd; /* [prNoetd,76~78   ] 재고할당 ETD 일자 미생성 사유 */
    private String boEtddt; /* [boEtddt,78~86   ] 백오더 ETD일자 */
    private String boEtdqt; /* [boEtdqt,86~93   ] 백오더 ETD수량 */
    private String boNoetd; /* [boNoetd,93~95   ] 백오더 ETD 일자 미생성 사유 */
    private String boProbm; /* [boProbm,95~97   ] ATO PROBLEM MANAGMENT 코드 */
    /**
     * @return the ordno
     */
    public String getOrdno() {
        return ordno;
    }
    /**
     * @param ordno the ordno to set
     */
    public void setOrdno(String ordno) {
        this.ordno = ordno;
    }
    /**
     * @return the ordln
     */
    public String getOrdln() {
        return ordln;
    }
    /**
     * @param ordln the ordln to set
     */
    public void setOrdln(String ordln) {
        this.ordln = ordln;
    }
    /**
     * @return the ordls
     */
    public String getOrdls() {
        return ordls;
    }
    /**
     * @param ordls the ordls to set
     */
    public void setOrdls(String ordls) {
        this.ordls = ordls;
    }
    /**
     * @return the ptno
     */
    public String getPtno() {
        return ptno;
    }
    /**
     * @param ptno the ptno to set
     */
    public void setPtno(String ptno) {
        this.ptno = ptno;
    }
    /**
     * @return the fbqty
     */
    public String getFbqty() {
        return fbqty;
    }
    /**
     * @param fbqty the fbqty to set
     */
    public void setFbqty(String fbqty) {
        this.fbqty = fbqty;
    }
    /**
     * @return the lbqty
     */
    public String getLbqty() {
        return lbqty;
    }
    /**
     * @param lbqty the lbqty to set
     */
    public void setLbqty(String lbqty) {
        this.lbqty = lbqty;
    }
    /**
     * @return the prqty
     */
    public String getPrqty() {
        return prqty;
    }
    /**
     * @param prqty the prqty to set
     */
    public void setPrqty(String prqty) {
        this.prqty = prqty;
    }
    /**
     * @return the spqty
     */
    public String getSpqty() {
        return spqty;
    }
    /**
     * @param spqty the spqty to set
     */
    public void setSpqty(String spqty) {
        this.spqty = spqty;
    }
    /**
     * @return the prEtddt
     */
    public String getPrEtddt() {
        return prEtddt;
    }
    /**
     * @param prEtddt the prEtddt to set
     */
    public void setPrEtddt(String prEtddt) {
        this.prEtddt = prEtddt;
    }
    /**
     * @return the prEtdqt
     */
    public String getPrEtdqt() {
        return prEtdqt;
    }
    /**
     * @param prEtdqt the prEtdqt to set
     */
    public void setPrEtdqt(String prEtdqt) {
        this.prEtdqt = prEtdqt;
    }
    /**
     * @return the prNoetd
     */
    public String getPrNoetd() {
        return prNoetd;
    }
    /**
     * @param prNoetd the prNoetd to set
     */
    public void setPrNoetd(String prNoetd) {
        this.prNoetd = prNoetd;
    }
    /**
     * @return the boEtddt
     */
    public String getBoEtddt() {
        return boEtddt;
    }
    /**
     * @param boEtddt the boEtddt to set
     */
    public void setBoEtddt(String boEtddt) {
        this.boEtddt = boEtddt;
    }
    /**
     * @return the boEtdqt
     */
    public String getBoEtdqt() {
        return boEtdqt;
    }
    /**
     * @param boEtdqt the boEtdqt to set
     */
    public void setBoEtdqt(String boEtdqt) {
        this.boEtdqt = boEtdqt;
    }
    /**
     * @return the boNoetd
     */
    public String getBoNoetd() {
        return boNoetd;
    }
    /**
     * @param boNoetd the boNoetd to set
     */
    public void setBoNoetd(String boNoetd) {
        this.boNoetd = boNoetd;
    }
    /**
     * @return the boProbm
     */
    public String getBoProbm() {
        return boProbm;
    }
    /**
     * @param boProbm the boProbm to set
     */
    public void setBoProbm(String boProbm) {
        this.boProbm = boProbm;
    }

}
