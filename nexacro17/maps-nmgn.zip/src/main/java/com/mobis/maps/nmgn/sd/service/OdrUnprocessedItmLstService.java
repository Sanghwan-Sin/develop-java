package com.mobis.maps.nmgn.sd.service;

import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.OdrUnprocessedItmLstVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OdrUnprocessedItmLstService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 6.     jiyongdo     	최초 생성
 * </pre>
 */

public interface OdrUnprocessedItmLstService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectOdrUnprocessedItmList(LoginInfoVO loginInfo, OdrUnprocessedItmLstVO paramVO) throws Exception;

}
