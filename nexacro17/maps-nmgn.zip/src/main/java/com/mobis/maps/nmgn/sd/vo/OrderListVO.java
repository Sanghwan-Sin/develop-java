package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderListVO.java
 * @Description : ZPSD_NMGN_R_ORDER_LIST
 * @author jiyongdo
 * @since 2019. 12. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 16.     jiyongdo     	최초 생성
 * </pre>
 */

public class OrderListVO extends MapsCommSapRfcIfCommVO{

    private int rnum;
    
    private String zkunam;
    
    // 입력
    @MapsRfcMappper(ipttSe="I", fieldKey="I_ZSACUTM")
    private String iZsacutm ;
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    @MapsRfcMappper(ipttSe="I", fieldKey="I_ZORDNO_P")
    private String iZordnoP ;
    @MapsRfcMappper(ipttSe="I", fieldKey="I_ZORDNO_E")  
    private String iZordnoE ;
    @MapsRfcMappper(ipttSe="I", fieldKey="I_ZORDDT_FR") 
    private Date iZorddtFr  ;
    @MapsRfcMappper(ipttSe="I", fieldKey="I_ZORDDT_TO") 
    private Date iZorddtTo  ;
    @MapsRfcMappper(ipttSe="I", fieldKey="I_ZOHPCD")    
    private String iZohpcd  ;
    @MapsRfcMappper(ipttSe="I", fieldKey="I_ZORDTYP")   
    private String iZordtyp ;
    @MapsRfcMappper(ipttSe="I", fieldKey="I_PARTNO")    
    private String iPartno  ;
    @MapsRfcMappper(ipttSe="I", fieldKey="I_CL_EXC")    
    private String iClExc   ;
    @MapsRfcMappper(ipttSe="I", fieldKey="I_TYPE")  
    private String type     ;
    @MapsRfcMappper( ipttSe="I", fieldKey="I_HISTORY" )
    private String iHistory ;
    
    /* ORDER HEAD PROCESS CODE ( =' ') */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZOHPCD_EQ" )
    private String iZohpcdEq;
    
    // 출력
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" ) 
    private String zsacutm  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_P" )    
    private String zordnoP  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )    
    private String zordnoE  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO" )  
    private String zordno   ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP" ) 
    private String zordtyp  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZOHPCD" )  
    private String zohpcd   ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCOMTY" )  
    private String zcomty   ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDDT" )  
    private Date zorddt   ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTM" )  
    private Date zordtm   ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZOFFDT" )  
    private Date zoffdt   ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDCNT" ) 
    private BigDecimal zordcnt  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCFMCNT" ) 
    private BigDecimal zcfmcnt  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDQTY" ) 
    private String zordqty  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCFMQTY" ) 
    private String zcfmqty  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDAMT" ) 
    private String zordamt  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCFMAMT" ) 
    private String zcfmamt  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZBOQTY" )  
    private String zboqty   ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZALOQTY" ) 
    private String zaloqty  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPICQTY" ) 
    private String zpicqty  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPACQTY" ) 
    private String zpacqty  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZINVQTY" ) 
    private String zinvqty  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSHPQTY" ) 
    private String zshpqty  ;
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="HISTORY" )
    private String history;
    
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZordnoP
     */
    public String getiZordnoP() {
        return iZordnoP;
    }
    /**
     * @param iZordnoP the iZordnoP to set
     */
    public void setiZordnoP(String iZordnoP) {
        this.iZordnoP = iZordnoP;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the iZorddtFr
     */
    public Date getiZorddtFr() {
        return iZorddtFr;
    }
    /**
     * @param iZorddtFr the iZorddtFr to set
     */
    public void setiZorddtFr(Date iZorddtFr) {
        this.iZorddtFr = iZorddtFr;
    }
    /**
     * @return the iZorddtTo
     */
    public Date getiZorddtTo() {
        return iZorddtTo;
    }
    /**
     * @param iZorddtTo the iZorddtTo to set
     */
    public void setiZorddtTo(Date iZorddtTo) {
        this.iZorddtTo = iZorddtTo;
    }
    /**
     * @return the iZohpcd
     */
    public String getiZohpcd() {
        return iZohpcd;
    }
    /**
     * @param iZohpcd the iZohpcd to set
     */
    public void setiZohpcd(String iZohpcd) {
        this.iZohpcd = iZohpcd;
    }
    /**
     * @return the iZordtyp
     */
    public String getiZordtyp() {
        return iZordtyp;
    }
    /**
     * @param iZordtyp the iZordtyp to set
     */
    public void setiZordtyp(String iZordtyp) {
        this.iZordtyp = iZordtyp;
    }
    /**
     * @return the iPartno
     */
    public String getiPartno() {
        return iPartno;
    }
    /**
     * @param iPartno the iPartno to set
     */
    public void setiPartno(String iPartno) {
        this.iPartno = iPartno;
    }
    /**
     * @return the iClExc
     */
    public String getiClExc() {
        return iClExc;
    }
    /**
     * @param iClExc the iClExc to set
     */
    public void setiClExc(String iClExc) {
        this.iClExc = iClExc;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the zordnoP
     */
    public String getZordnoP() {
        return zordnoP;
    }
    /**
     * @param zordnoP the zordnoP to set
     */
    public void setZordnoP(String zordnoP) {
        this.zordnoP = zordnoP;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the zohpcd
     */
    public String getZohpcd() {
        return zohpcd;
    }
    /**
     * @param zohpcd the zohpcd to set
     */
    public void setZohpcd(String zohpcd) {
        this.zohpcd = zohpcd;
    }
    /**
     * @return the zcomty
     */
    public String getZcomty() {
        return zcomty;
    }
    /**
     * @param zcomty the zcomty to set
     */
    public void setZcomty(String zcomty) {
        this.zcomty = zcomty;
    }
    /**
     * @return the zorddt
     */
    public Date getZorddt() {
        return zorddt;
    }
    /**
     * @param zorddt the zorddt to set
     */
    public void setZorddt(Date zorddt) {
        this.zorddt = zorddt;
    }
    /**
     * @return the zordtm
     */
    public Date getZordtm() {
        return zordtm;
    }
    /**
     * @param zordtm the zordtm to set
     */
    public void setZordtm(Date zordtm) {
        this.zordtm = zordtm;
    }
    /**
     * @return the zoffdt
     */
    public Date getZoffdt() {
        return zoffdt;
    }
    /**
     * @param zoffdt the zoffdt to set
     */
    public void setZoffdt(Date zoffdt) {
        this.zoffdt = zoffdt;
    }
    /**
     * @return the zordcnt
     */
    public BigDecimal getZordcnt() {
        return zordcnt;
    }
    /**
     * @param zordcnt the zordcnt to set
     */
    public void setZordcnt(BigDecimal zordcnt) {
        this.zordcnt = zordcnt;
    }
    /**
     * @return the zcfmcnt
     */
    public BigDecimal getZcfmcnt() {
        return zcfmcnt;
    }
    /**
     * @param zcfmcnt the zcfmcnt to set
     */
    public void setZcfmcnt(BigDecimal zcfmcnt) {
        this.zcfmcnt = zcfmcnt;
    }
    /**
     * @return the zordqty
     */
    public String getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(String zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zcfmqty
     */
    public String getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(String zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the zordamt
     */
    public String getZordamt() {
        return zordamt;
    }
    /**
     * @param zordamt the zordamt to set
     */
    public void setZordamt(String zordamt) {
        this.zordamt = zordamt;
    }
    /**
     * @return the zcfmamt
     */
    public String getZcfmamt() {
        return zcfmamt;
    }
    /**
     * @param zcfmamt the zcfmamt to set
     */
    public void setZcfmamt(String zcfmamt) {
        this.zcfmamt = zcfmamt;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zaloqty
     */
    public String getZaloqty() {
        return zaloqty;
    }
    /**
     * @param zaloqty the zaloqty to set
     */
    public void setZaloqty(String zaloqty) {
        this.zaloqty = zaloqty;
    }
    /**
     * @return the zpicqty
     */
    public String getZpicqty() {
        return zpicqty;
    }
    /**
     * @param zpicqty the zpicqty to set
     */
    public void setZpicqty(String zpicqty) {
        this.zpicqty = zpicqty;
    }
    /**
     * @return the zpacqty
     */
    public String getZpacqty() {
        return zpacqty;
    }
    /**
     * @param zpacqty the zpacqty to set
     */
    public void setZpacqty(String zpacqty) {
        this.zpacqty = zpacqty;
    }
    /**
     * @return the zinvqty
     */
    public String getZinvqty() {
        return zinvqty;
    }
    /**
     * @param zinvqty the zinvqty to set
     */
    public void setZinvqty(String zinvqty) {
        this.zinvqty = zinvqty;
    }
    /**
     * @return the zshpqty
     */
    public String getZshpqty() {
        return zshpqty;
    }
    /**
     * @param zshpqty the zshpqty to set
     */
    public void setZshpqty(String zshpqty) {
        this.zshpqty = zshpqty;
    }
    /**
     * @return the zkunam
     */
    public String getZkunam() {
        return zkunam;
    }
    /**
     * @param zkunam the zkunam to set
     */
    public void setZkunam(String zkunam) {
        this.zkunam = zkunam;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the iHistory
     */
    public String getiHistory() {
        return iHistory;
    }
    /**
     * @param iHistory the iHistory to set
     */
    public void setiHistory(String iHistory) {
        this.iHistory = iHistory;
    }
    /**
     * @return the history
     */
    public String getHistory() {
        return history;
    }
    /**
     * @param history the history to set
     */
    public void setHistory(String history) {
        this.history = history;
    }
    /**
     * @return the iZohpcdEq
     */
    public String getiZohpcdEq() {
        return iZohpcdEq;
    }
    /**
     * @param iZohpcdEq the iZohpcdEq to set
     */
    public void setiZohpcdEq(String iZohpcdEq) {
        this.iZohpcdEq = iZohpcdEq;
    }   
    
}
