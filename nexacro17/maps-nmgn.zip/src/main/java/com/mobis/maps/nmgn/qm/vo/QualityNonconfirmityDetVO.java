package com.mobis.maps.nmgn.qm.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityNonconfirmityDetVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 16.     jiyongdo     	최초 생성
 * </pre>
 */

public class QualityNonconfirmityDetVO extends MapsCommSapRfcIfCommVO{

    /** 부적합번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZNCRNO" )
    private String iZncrno;
    /** 기존고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** 회사 코드 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** 회사 코드 또는 회사 이름 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="BUTXT" )
    private String butxt;
    /** 부적합번호 */
    @MapsRfcMappper( targetName="ES_DATA|ET_LOT", ipttSe="E", fieldKey="ZNCRNO|ZNCRNO" )
    private String zncrno;
    /** 이름 1 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** 자재내역 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** 개선대책서 발생코드 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZOCCODE" )
    private String zoccode;
    /** 부적합유형코드 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZTYPECODE" )
    private String ztypecode;
    /** 성 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZSENDEMP" )
    private String zsendemp;
    /** 전송일자 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZSENDDATE" )
    private Date zsenddate;
    /** 설명 내역 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZSTATUS" )
    private String zstatus;
    /** 클레임의뢰코드 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZCREQCODE" )
    private String zcreqcode;
    /** 처리지침-국내 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRESECODE" )
    private String zresecode;
    /** 포장Lot From */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPSLOTF" )
    private String zpslotf;
    /** 포장Lot To */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPSLOTT" )
    private String zpslott;
    /** 포장사 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPSLIFNR" )
    private String zpslifnr;
    /** 이름 1 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPSLIFNR_NAME" )
    private String zpslifnrName;
    /** 제조사 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPDLIFNR" )
    private String zpdlifnr;
    /** 이름 1 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPDLIFNR_NAME" )
    private String zpdlifnrName;
    /** 설명 내역 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZECMP" )
    private String zecmp;
    /** 의뢰방법(현지언어) */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZREQDESCE" )
    private String zreqdesce;
    /** 정품설명(현지언어) */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZGOODDESCE" )
    private String zgooddesce;
    /** 부적합품설명(현지언어) */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZBADDESCE" )
    private String zbaddesce;
    /** 기존고객코드 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="LIFNR" )
    private String lifnr;    
    /** 전량회수대상 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZALLYN" )
    private String zallyn;        
    /** Seq. No. */
    @MapsRfcMappper( targetName="ET_LOT", ipttSe="E", fieldKey="SEQ" )
    private BigDecimal seq;
    /** 포장Lot */
    @MapsRfcMappper( targetName="ET_LOT", ipttSe="E", fieldKey="ZPSLOT" )
    private String zpslot;
    /** 텍스트 (길이 132) */
    @MapsRfcMappper( targetName="ET_ZBADDESCE|ET_ZGOODDESCE|ET_ZREQDESCE", ipttSe="E", fieldKey="LINE|LINE|LINE" )
    private String line;
    /** 이름 1 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="LIFNR_NAME" )
    private String lifnrName;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZATT_FSCODE" )
    private String zattFscode;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZATT_REF_NO" )
    private String zattRefNo;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZATT_FILE_NAME" )
    private String zattFileName;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZATT_FILE_SEQNO" )
    private String zattFileSeqno;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZGOOD_FSCODE" )
    private String zgoodFscode;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZGOOD_REF_NO" )
    private String zgoodRefNo;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZGOOD_FILE_NAME" )
    private String zgoodFileName;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZGOOD_FILE_SEQNO" )
    private String zgoodFileSeqno;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZBAD_FSCODE" )
    private String zbadFscode;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZBAD_REF_NO" )
    private String zbadRefNo;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZBAD_FILE_NAME" )
    private String zbadFileName;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZBAD_FILE_SEQNO" )
    private String zbadFileSeqno;    
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /**
     * @return the iZncrno
     */
    public String getiZncrno() {
        return iZncrno;
    }
    /**
     * @param iZncrno the iZncrno to set
     */
    public void setiZncrno(String iZncrno) {
        this.iZncrno = iZncrno;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the butxt
     */
    public String getButxt() {
        return butxt;
    }
    /**
     * @param butxt the butxt to set
     */
    public void setButxt(String butxt) {
        this.butxt = butxt;
    }
    /**
     * @return the zncrno
     */
    public String getZncrno() {
        return zncrno;
    }
    /**
     * @param zncrno the zncrno to set
     */
    public void setZncrno(String zncrno) {
        this.zncrno = zncrno;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zoccode
     */
    public String getZoccode() {
        return zoccode;
    }
    /**
     * @param zoccode the zoccode to set
     */
    public void setZoccode(String zoccode) {
        this.zoccode = zoccode;
    }
    /**
     * @return the ztypecode
     */
    public String getZtypecode() {
        return ztypecode;
    }
    /**
     * @param ztypecode the ztypecode to set
     */
    public void setZtypecode(String ztypecode) {
        this.ztypecode = ztypecode;
    }
    /**
     * @return the zsendemp
     */
    public String getZsendemp() {
        return zsendemp;
    }
    /**
     * @param zsendemp the zsendemp to set
     */
    public void setZsendemp(String zsendemp) {
        this.zsendemp = zsendemp;
    }
    /**
     * @return the zsenddate
     */
    public Date getZsenddate() {
        return zsenddate;
    }
    /**
     * @param zsenddate the zsenddate to set
     */
    public void setZsenddate(Date zsenddate) {
        this.zsenddate = zsenddate;
    }
    /**
     * @return the zstatus
     */
    public String getZstatus() {
        return zstatus;
    }
    /**
     * @param zstatus the zstatus to set
     */
    public void setZstatus(String zstatus) {
        this.zstatus = zstatus;
    }
    /**
     * @return the zcreqcode
     */
    public String getZcreqcode() {
        return zcreqcode;
    }
    /**
     * @param zcreqcode the zcreqcode to set
     */
    public void setZcreqcode(String zcreqcode) {
        this.zcreqcode = zcreqcode;
    }
    /**
     * @return the zresecode
     */
    public String getZresecode() {
        return zresecode;
    }
    /**
     * @param zresecode the zresecode to set
     */
    public void setZresecode(String zresecode) {
        this.zresecode = zresecode;
    }
    /**
     * @return the zpslotf
     */
    public String getZpslotf() {
        return zpslotf;
    }
    /**
     * @param zpslotf the zpslotf to set
     */
    public void setZpslotf(String zpslotf) {
        this.zpslotf = zpslotf;
    }
    /**
     * @return the zpslott
     */
    public String getZpslott() {
        return zpslott;
    }
    /**
     * @param zpslott the zpslott to set
     */
    public void setZpslott(String zpslott) {
        this.zpslott = zpslott;
    }
    /**
     * @return the zpslifnr
     */
    public String getZpslifnr() {
        return zpslifnr;
    }
    /**
     * @param zpslifnr the zpslifnr to set
     */
    public void setZpslifnr(String zpslifnr) {
        this.zpslifnr = zpslifnr;
    }
    /**
     * @return the zpslifnrName
     */
    public String getZpslifnrName() {
        return zpslifnrName;
    }
    /**
     * @param zpslifnrName the zpslifnrName to set
     */
    public void setZpslifnrName(String zpslifnrName) {
        this.zpslifnrName = zpslifnrName;
    }
    /**
     * @return the zpdlifnr
     */
    public String getZpdlifnr() {
        return zpdlifnr;
    }
    /**
     * @param zpdlifnr the zpdlifnr to set
     */
    public void setZpdlifnr(String zpdlifnr) {
        this.zpdlifnr = zpdlifnr;
    }
    /**
     * @return the zpdlifnrName
     */
    public String getZpdlifnrName() {
        return zpdlifnrName;
    }
    /**
     * @param zpdlifnrName the zpdlifnrName to set
     */
    public void setZpdlifnrName(String zpdlifnrName) {
        this.zpdlifnrName = zpdlifnrName;
    }
    /**
     * @return the zecmp
     */
    public String getZecmp() {
        return zecmp;
    }
    /**
     * @param zecmp the zecmp to set
     */
    public void setZecmp(String zecmp) {
        this.zecmp = zecmp;
    }
    /**
     * @return the zreqdesce
     */
    public String getZreqdesce() {
        return zreqdesce;
    }
    /**
     * @param zreqdesce the zreqdesce to set
     */
    public void setZreqdesce(String zreqdesce) {
        this.zreqdesce = zreqdesce;
    }
    /**
     * @return the zgooddesce
     */
    public String getZgooddesce() {
        return zgooddesce;
    }
    /**
     * @param zgooddesce the zgooddesce to set
     */
    public void setZgooddesce(String zgooddesce) {
        this.zgooddesce = zgooddesce;
    }
    /**
     * @return the zbaddesce
     */
    public String getZbaddesce() {
        return zbaddesce;
    }
    /**
     * @param zbaddesce the zbaddesce to set
     */
    public void setZbaddesce(String zbaddesce) {
        this.zbaddesce = zbaddesce;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the zallyn
     */
    public String getZallyn() {
        return zallyn;
    }
    /**
     * @param zallyn the zallyn to set
     */
    public void setZallyn(String zallyn) {
        this.zallyn = zallyn;
    }
    /**
     * @return the seq
     */
    public BigDecimal getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(BigDecimal seq) {
        this.seq = seq;
    }
    /**
     * @return the zpslot
     */
    public String getZpslot() {
        return zpslot;
    }
    /**
     * @param zpslot the zpslot to set
     */
    public void setZpslot(String zpslot) {
        this.zpslot = zpslot;
    }
    /**
     * @return the line
     */
    public String getLine() {
        return line;
    }
    /**
     * @param line the line to set
     */
    public void setLine(String line) {
        this.line = line;
    }
    /**
     * @return the lifnrName
     */
    public String getLifnrName() {
        return lifnrName;
    }
    /**
     * @param lifnrName the lifnrName to set
     */
    public void setLifnrName(String lifnrName) {
        this.lifnrName = lifnrName;
    }
    /**
     * @return the zattFscode
     */
    public String getZattFscode() {
        return zattFscode;
    }
    /**
     * @param zattFscode the zattFscode to set
     */
    public void setZattFscode(String zattFscode) {
        this.zattFscode = zattFscode;
    }
    /**
     * @return the zattRefNo
     */
    public String getZattRefNo() {
        return zattRefNo;
    }
    /**
     * @param zattRefNo the zattRefNo to set
     */
    public void setZattRefNo(String zattRefNo) {
        this.zattRefNo = zattRefNo;
    }
    /**
     * @return the zattFileName
     */
    public String getZattFileName() {
        return zattFileName;
    }
    /**
     * @param zattFileName the zattFileName to set
     */
    public void setZattFileName(String zattFileName) {
        this.zattFileName = zattFileName;
    }
    /**
     * @return the zattFileSeqno
     */
    public String getZattFileSeqno() {
        return zattFileSeqno;
    }
    /**
     * @param zattFileSeqno the zattFileSeqno to set
     */
    public void setZattFileSeqno(String zattFileSeqno) {
        this.zattFileSeqno = zattFileSeqno;
    }
    /**
     * @return the zgoodFscode
     */
    public String getZgoodFscode() {
        return zgoodFscode;
    }
    /**
     * @param zgoodFscode the zgoodFscode to set
     */
    public void setZgoodFscode(String zgoodFscode) {
        this.zgoodFscode = zgoodFscode;
    }
    /**
     * @return the zgoodRefNo
     */
    public String getZgoodRefNo() {
        return zgoodRefNo;
    }
    /**
     * @param zgoodRefNo the zgoodRefNo to set
     */
    public void setZgoodRefNo(String zgoodRefNo) {
        this.zgoodRefNo = zgoodRefNo;
    }
    /**
     * @return the zgoodFileName
     */
    public String getZgoodFileName() {
        return zgoodFileName;
    }
    /**
     * @param zgoodFileName the zgoodFileName to set
     */
    public void setZgoodFileName(String zgoodFileName) {
        this.zgoodFileName = zgoodFileName;
    }
    /**
     * @return the zgoodFileSeqno
     */
    public String getZgoodFileSeqno() {
        return zgoodFileSeqno;
    }
    /**
     * @param zgoodFileSeqno the zgoodFileSeqno to set
     */
    public void setZgoodFileSeqno(String zgoodFileSeqno) {
        this.zgoodFileSeqno = zgoodFileSeqno;
    }
    /**
     * @return the zbadFscode
     */
    public String getZbadFscode() {
        return zbadFscode;
    }
    /**
     * @param zbadFscode the zbadFscode to set
     */
    public void setZbadFscode(String zbadFscode) {
        this.zbadFscode = zbadFscode;
    }
    /**
     * @return the zbadRefNo
     */
    public String getZbadRefNo() {
        return zbadRefNo;
    }
    /**
     * @param zbadRefNo the zbadRefNo to set
     */
    public void setZbadRefNo(String zbadRefNo) {
        this.zbadRefNo = zbadRefNo;
    }
    /**
     * @return the zbadFileName
     */
    public String getZbadFileName() {
        return zbadFileName;
    }
    /**
     * @param zbadFileName the zbadFileName to set
     */
    public void setZbadFileName(String zbadFileName) {
        this.zbadFileName = zbadFileName;
    }
    /**
     * @return the zbadFileSeqno
     */
    public String getZbadFileSeqno() {
        return zbadFileSeqno;
    }
    /**
     * @param zbadFileSeqno the zbadFileSeqno to set
     */
    public void setZbadFileSeqno(String zbadFileSeqno) {
        this.zbadFileSeqno = zbadFileSeqno;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }    
}
