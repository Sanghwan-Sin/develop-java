package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.DistSearchVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistSearchMDAO.java
 * @Description : 대리점 검색
 * @author hong.minho
 * @since 2020. 3. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 13.     hong.minho         최초 생성
 * </pre>
 */

@Mapper("distSearchMDAO")
public interface DistSearchMDAO {

    
    /**
     * 대리점검색
     *
     * @param params
     * @return
     * @throws Exception
     */
    List<DistSearchVO> selectDistSearch(DistSearchVO params) throws Exception;
 
    
    /**
     * 대리점 정보 조회
     *
     * @param params
     * @return
     * @throws Exception
     */
    DistSearchVO selectDistInfo(DistSearchVO params) throws Exception;
    

    /**
     * 하위대리점 조회 (대표대리점의 경우)
     *
     * @param params
     * @return
     * @throws Exception
     */
    List<DistSearchVO> selectSubDistLst(DistSearchVO params) throws Exception;
}
