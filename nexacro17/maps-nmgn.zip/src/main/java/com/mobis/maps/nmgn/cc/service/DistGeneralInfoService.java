package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.nmgn.cc.vo.DistGeneralInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistGeneralInfoService.java
 * @Description : DistGeneralInfoService
 * @author ha.jeongryeong
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     ha.jeongryeong     	최초 생성
 * </pre>
 */

public interface DistGeneralInfoService {

    /**
     * 조회
     *
     * @param sampleMsgVO
     * @return
     * @throws Exception
     */
    public List<DistGeneralInfoVO> selectDistGeneralInfoList(DistGeneralInfoVO paramVO) throws Exception;
    
    
}
