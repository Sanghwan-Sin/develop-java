package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.OdrProcessingListService;
import com.mobis.maps.nmgn.sd.vo.OdrProcessingListVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OdrProcessingListController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 9.     jiyongdo     	최초 생성
 * </pre>
 */
@Controller
public class OdrProcessingListController extends HController{

    @Resource(name = "odrProcessingListService")
    private OdrProcessingListService odrProcessingListService;
    
    @RequestMapping(value = "/sd/selectOdrProcessingSumList.do")
    public NexacroResult selectOdrProcessingSumList(@ParamDataSet(name="dsInput") OdrProcessingListVO paramVO
                                                  , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = odrProcessingListService.selectOdrProcessingSumList(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        OdrProcessingListVO totList = (OdrProcessingListVO) retMap.get("head");
        @SuppressWarnings("unchecked")
        List<OdrProcessingListVO> retList = (List<OdrProcessingListVO>)retMap.get("body");
        //OdrProcessingListVO sumList = (OdrProcessingListVO) retMap.get("summ");  
        OdrProcessingListVO sumList = (OdrProcessingListVO) retMap.get("summ");
        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", totList);   
        result.addDataSet("dsOutput3", sumList);   
        result.addDataSet("dsOutput4", paramVO);   

        return result;
    }
    
    @RequestMapping(value = "/sd/selectOdrProcessingSumListExcelDown.do")
    public NexacroResult selectOdrProcessingSumListExcelDown(@ParamDataSet(name="dsInput") OdrProcessingListVO paramVO
                                                           , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        Map<String, Object> retMap = odrProcessingListService.selectOdrProcessingSumList(loginInfo, paramVO);  
        @SuppressWarnings("unchecked")
        List<OdrProcessingListVO> retList = (List<OdrProcessingListVO>)retMap.get("body");        
        result.addDataSet("dsOutput", retList);

        return result;
    }  
}
