package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DispRequestVO.java
 * @Description : ZPSD_NMGN_S_DISPREQ
 * @author 이수지
 * @since 2020. 8. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 26.     이수지             	최초 생성
 * </pre>
 */

public class DispRequestVO extends MapsCommSapRfcIfCommVO{

    /** 요청번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQ_NO" )
    private String iReqNo;
    /** 상태 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_STATUS" )
    private String iStatus;
    /** 인증/법규 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCERTI_CD" )
    private String iZcertiCd;
    /** 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
   
    /** -----[T_DATA] START----- */
    
    /** Client */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MANDT" )
    private String mandt;
    /** Company Code */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REQ_NO" )
    private String reqNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REQDT" )
    private Date reqdt;
    /** E-Mail Address */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="SMTP_ADDR" )
    private String smtpAddr;
    /** Material Number */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCERTI_CD" )
    private String zcertiCd;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCERTI_NAME" )
    private String zcertiName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDOC_CD" )
    private String zdocCd;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDOC_NAME" )
    private String zdocName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REQ_TYPE" )
    private String reqType;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REQ_TYPE_TXT" )
    private String reqTypeTxt;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REF_NO" )
    private String refNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDUE_DAT" )
    private Date zdueDat;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZREJ_TYPE" )
    private String zrejType;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZREJ_TYPE_TXT" )
    private String zrejTypeTxt;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZREJ_REASON" )
    private String zrejReason;
    /** Account Number of Vendor or Creditor */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LIFNR" )
    private String lifnr;
    /** Name 3 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="NAME3" )
    private String name3;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="STATUS" )
    private String status;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="STATUS_TXT" )
    private String statusTxt;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZREMARK" )
    private String zremark;
    
    /** -----[T_DATA] END----- */
    
    
    /**
     * @return the iReqNo
     */
    public String getiReqNo() {
        return iReqNo;
    }
    /**
     * @param iReqNo the iReqNo to set
     */
    public void setiReqNo(String iReqNo) {
        this.iReqNo = iReqNo;
    }
    /**
     * @return the iStatus
     */
    public String getiStatus() {
        return iStatus;
    }
    /**
     * @param iStatus the iStatus to set
     */
    public void setiStatus(String iStatus) {
        this.iStatus = iStatus;
    }
    /**
     * @return the iZcertiCd
     */
    public String getiZcertiCd() {
        return iZcertiCd;
    }
    /**
     * @param iZcertiCd the iZcertiCd to set
     */
    public void setiZcertiCd(String iZcertiCd) {
        this.iZcertiCd = iZcertiCd;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the mandt
     */
    public String getMandt() {
        return mandt;
    }
    /**
     * @param mandt the mandt to set
     */
    public void setMandt(String mandt) {
        this.mandt = mandt;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the reqNo
     */
    public String getReqNo() {
        return reqNo;
    }
    /**
     * @param reqNo the reqNo to set
     */
    public void setReqNo(String reqNo) {
        this.reqNo = reqNo;
    }
    /**
     * @return the reqdt
     */
    public Date getReqdt() {
        return reqdt;
    }
    /**
     * @param reqdt the reqdt to set
     */
    public void setReqdt(Date reqdt) {
        this.reqdt = reqdt;
    }
    /**
     * @return the smtpAddr
     */
    public String getSmtpAddr() {
        return smtpAddr;
    }
    /**
     * @param smtpAddr the smtpAddr to set
     */
    public void setSmtpAddr(String smtpAddr) {
        this.smtpAddr = smtpAddr;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the zcertiCd
     */
    public String getZcertiCd() {
        return zcertiCd;
    }
    /**
     * @param zcertiCd the zcertiCd to set
     */
    public void setZcertiCd(String zcertiCd) {
        this.zcertiCd = zcertiCd;
    }
    /**
     * @return the zcertiName
     */
    public String getZcertiName() {
        return zcertiName;
    }
    /**
     * @param zcertiName the zcertiName to set
     */
    public void setZcertiName(String zcertiName) {
        this.zcertiName = zcertiName;
    }
    /**
     * @return the zdocCd
     */
    public String getZdocCd() {
        return zdocCd;
    }
    /**
     * @param zdocCd the zdocCd to set
     */
    public void setZdocCd(String zdocCd) {
        this.zdocCd = zdocCd;
    }
    /**
     * @return the zdocName
     */
    public String getZdocName() {
        return zdocName;
    }
    /**
     * @param zdocName the zdocName to set
     */
    public void setZdocName(String zdocName) {
        this.zdocName = zdocName;
    }
    /**
     * @return the reqType
     */
    public String getReqType() {
        return reqType;
    }
    /**
     * @param reqType the reqType to set
     */
    public void setReqType(String reqType) {
        this.reqType = reqType;
    }
    /**
     * @return the reqTypeTxt
     */
    public String getReqTypeTxt() {
        return reqTypeTxt;
    }
    /**
     * @param reqTypeTxt the reqTypeTxt to set
     */
    public void setReqTypeTxt(String reqTypeTxt) {
        this.reqTypeTxt = reqTypeTxt;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the zdueDat
     */
    public Date getZdueDat() {
        return zdueDat;
    }
    /**
     * @param zdueDat the zdueDat to set
     */
    public void setZdueDat(Date zdueDat) {
        this.zdueDat = zdueDat;
    }
    /**
     * @return the zrejType
     */
    public String getZrejType() {
        return zrejType;
    }
    /**
     * @param zrejType the zrejType to set
     */
    public void setZrejType(String zrejType) {
        this.zrejType = zrejType;
    }
    /**
     * @return the zrejTypeTxt
     */
    public String getZrejTypeTxt() {
        return zrejTypeTxt;
    }
    /**
     * @param zrejTypeTxt the zrejTypeTxt to set
     */
    public void setZrejTypeTxt(String zrejTypeTxt) {
        this.zrejTypeTxt = zrejTypeTxt;
    }
    /**
     * @return the zrejReason
     */
    public String getZrejReason() {
        return zrejReason;
    }
    /**
     * @param zrejReason the zrejReason to set
     */
    public void setZrejReason(String zrejReason) {
        this.zrejReason = zrejReason;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the name3
     */
    public String getName3() {
        return name3;
    }
    /**
     * @param name3 the name3 to set
     */
    public void setName3(String name3) {
        this.name3 = name3;
    }
    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }
    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    /**
     * @return the statusTxt
     */
    public String getStatusTxt() {
        return statusTxt;
    }
    /**
     * @param statusTxt the statusTxt to set
     */
    public void setStatusTxt(String statusTxt) {
        this.statusTxt = statusTxt;
    }
    /**
     * @return the zremark
     */
    public String getZremark() {
        return zremark;
    }
    /**
     * @param zremark the zremark to set
     */
    public void setZremark(String zremark) {
        this.zremark = zremark;
    }
    
}
