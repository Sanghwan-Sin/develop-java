package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.PromotionListService;
import com.mobis.maps.nmgn.sd.vo.PromotionListVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionListServiceImpl.java
 * @Description : ZJSDR20120 Promotion List
 * @author 이수지
 * @since 2020. 3. 11
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 11       이수지      	        최초 생성
 * </pre>
 */

@Service("promotionListService")
public class PromotionListServiceImpl extends HService implements PromotionListService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.PromotionListService#selectPromotionList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.PromotionListVO)
     */
    @Override
    public List<PromotionListVO> selectPromotionList(LoginInfoVO loginVo, PromotionListVO params)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_S_PROMOTION_DETAIL;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<PromotionListVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, PromotionListVO.class);
        
        return list;
    }

}