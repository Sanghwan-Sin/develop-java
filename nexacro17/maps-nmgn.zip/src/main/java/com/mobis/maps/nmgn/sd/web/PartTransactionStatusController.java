package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.PartTransactionStatusService;
import com.mobis.maps.nmgn.sd.vo.PartTransactionStatusVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceController.java
 * @Description : ZJSDR20030 List Price
 * @author 이수지
 * @since 2020. 1. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 10.       이수지                최초 생성
 * </pre>
 */

@Controller
public class PartTransactionStatusController extends HController {

    @Resource(name = "partTransactionStatusService")
    private PartTransactionStatusService partTransactionStatusService;

    /**
     * selectPartTransactionStatus
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPartTransactionStatus.do")
    public NexacroResult selectPartTransactionStatus(@ParamDataSet(name="dsInput") PartTransactionStatusVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PartTransactionStatusVO> list = partTransactionStatusService.selectPartTransactionStatus(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectPartTransactionStatusExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPartTransactionStatusExcelDown.do")
    public NexacroResult selectPartTransactionStatusExcelDown(@ParamDataSet(name="dsInput") PartTransactionStatusVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<PartTransactionStatusVO> list = partTransactionStatusService.selectPartTransactionStatus(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
}
