package com.mobis.maps.nmgn.sd.vo;


import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MsdsManagementVO.java
 * @Description : ZPSD_NMGN_S_MSDS
 * @author 이수지
 * @since 2020. 07. 15.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *   2020. 07. 15.     이수지     	       최초 생성
 * </pre>
 */

public class MsdsManagementVO extends MapsCommSapRfcIfCommVO {
    
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_BUKRS" )
    private String ivBukrs;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_LIFNR" )
    private String ivLifnr;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_MATNR" )
    private String ivMatnr;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_ZDHCD" )
    private String ivZdhcd;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_ZDKCD" )
    private String ivZdkcd;

    /** -----[IT_SEND] START----- */
    
    /** Company Code */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** Account Number of Vendor or Creditor */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="LIFNR" )
    private String lifnr;
    /** Name 1 (surname for persons, else company name) */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="LITXT" )
    private String litxt;
    /** Material Number */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /**  */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="ZDHCD" )
    private String zdhcd;
    /**  */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="ZDKCD" )
    private String zdkcd;
    /**  */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;
    /**  */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="ZATTACH_DOC_E" )
    private String zattachDocE;
    /**  */
    @MapsRfcMappper( targetName="IT_SEND", ipttSe="E", fieldKey="ZATTACH_DATE_E" )
    private Date zattachDateE;
    
    /** -----[IT_SEND] END----- */
    
    
    /**
     * @return the ivBukrs
     */
    public String getIvBukrs() {
        return ivBukrs;
    }
    /**
     * @param ivBukrs the ivBukrs to set
     */
    public void setIvBukrs(String ivBukrs) {
        this.ivBukrs = ivBukrs;
    }
    /**
     * @return the ivLifnr
     */
    public String getIvLifnr() {
        return ivLifnr;
    }
    /**
     * @param ivLifnr the ivLifnr to set
     */
    public void setIvLifnr(String ivLifnr) {
        this.ivLifnr = ivLifnr;
    }
    /**
     * @return the ivMatnr
     */
    public String getIvMatnr() {
        return ivMatnr;
    }
    /**
     * @param ivMatnr the ivMatnr to set
     */
    public void setIvMatnr(String ivMatnr) {
        this.ivMatnr = ivMatnr;
    }
    /**
     * @return the ivZdhcd
     */
    public String getIvZdhcd() {
        return ivZdhcd;
    }
    /**
     * @param ivZdhcd the ivZdhcd to set
     */
    public void setIvZdhcd(String ivZdhcd) {
        this.ivZdhcd = ivZdhcd;
    }
    /**
     * @return the ivZdkcd
     */
    public String getIvZdkcd() {
        return ivZdkcd;
    }
    /**
     * @param ivZdkcd the ivZdkcd to set
     */
    public void setIvZdkcd(String ivZdkcd) {
        this.ivZdkcd = ivZdkcd;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the litxt
     */
    public String getLitxt() {
        return litxt;
    }
    /**
     * @param litxt the litxt to set
     */
    public void setLitxt(String litxt) {
        this.litxt = litxt;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zdhcd
     */
    public String getZdhcd() {
        return zdhcd;
    }
    /**
     * @param zdhcd the zdhcd to set
     */
    public void setZdhcd(String zdhcd) {
        this.zdhcd = zdhcd;
    }
    /**
     * @return the zdkcd
     */
    public String getZdkcd() {
        return zdkcd;
    }
    /**
     * @param zdkcd the zdkcd to set
     */
    public void setZdkcd(String zdkcd) {
        this.zdkcd = zdkcd;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the zattachDocE
     */
    public String getZattachDocE() {
        return zattachDocE;
    }
    /**
     * @param zattachDocE the zattachDocE to set
     */
    public void setZattachDocE(String zattachDocE) {
        this.zattachDocE = zattachDocE;
    }
    /**
     * @return the zattachDateE
     */
    public Date getZattachDateE() {
        return zattachDateE;
    }
    /**
     * @param zattachDateE the zattachDateE to set
     */
    public void setZattachDateE(Date zattachDateE) {
        this.zattachDateE = zattachDateE;
    }
    
}
