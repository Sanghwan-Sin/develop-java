package com.mobis.maps.nmgn.ex.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.service.PackingDetailService;
import com.mobis.maps.nmgn.ex.vo.PackingDetailVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingDetailController.java
 * @Description : ZJEXR00190 Packing Detail
 * @author 이수지
 * @since 2020. 2. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 10.       이수지                최초 생성
 * </pre>
 */

@Controller
public class PackingDetailController extends HController {

    @Resource(name = "packingDetailService")
    private PackingDetailService packingDetailService;

    /**
     * selectPackingDetail
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectPackingDetail.do")
    public NexacroResult selectPackingDetail(@ParamDataSet(name="dsInput") PackingDetailVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PackingDetailVO> list = packingDetailService.selectPackingDetail(loginInfo, params);

        if (list.size() > 0) {
            list.get(0).setInvoice(params.getiInvoice());
        } 
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectPackingDetailExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectPackingDetailExcelDown.do")
    public NexacroResult selectPackingDetailExcelDown(@ParamDataSet(name="dsInput") PackingDetailVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<PackingDetailVO> list = packingDetailService.selectPackingDetail(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
}
