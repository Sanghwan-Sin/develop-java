package com.mobis.maps.nmgn.mm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PacakageImproveReqDetailVO.java
 * @Description : ZPMM_NMGN_R_CREATE_PI_REQ / 포장개선의뢰 임시저장 및 요청 VO
 * @author ChoKyungHo
 * @since 2020. 03. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 17.    ChoKyungHo              최초 생성
 * </pre>
 */

public class PackageImproveRequestVO extends MapsCommSapRfcIfCommVO {
    
    /** -----[IS_DATA] START----- */
    /** 의뢰번호  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZSPCNO" )
    private String zspcno;
    /** 회사 코드 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="BUKRS" )
    private String bukrs;
    /** 플랜트 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="WERKS" )
    private String werks;
    /** Customer Number */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="KUNNR" )
    private String kunnr;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="MATNR" )
    private String matnr;
    /** H/K 구분 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZHKCD" )
    private String zhkcd;
    /** 내수/수출구분 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZEDCD" )
    private String zedcd;
    /** 부품/용품 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZPA_FLG" )
    private String zpaFlg;
    /** 포장LOT */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZPSLOT" )
    private String zpslot;
    /** 발생지역 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZAREA" )
    private String zarea;
    /** 발생처 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZOCC_GB" )
    private String zoccGb;
    /** 의뢰부서 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZDEPT" )
    private String zdept;
    /** 의뢰자 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZREQ_EMPNO" )
    private String zreqEmpno;
    /** 이메일 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZEMAIL" )
    private String zemail;
    /** 연락처 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZTELL" )
    private String ztell;
    /** 요청일 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZREQ_DATE" )
    private String zreqDate;
    /** 개선부서 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZIMP_DEPT" )
    private String zimpDept;
    /** 개선구분 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZIMPGB" )
    private String zimpgb;
    /** 예상발생유형 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZOCC_TYPE" )
    private String zoccType;
    /** 불량유형 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZUNFIT_TYPE" )
    private String zunfitType;
    /** 불량내용 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZUNF_TXT" )
    private String zunfTxt;
    /** 요청사항 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZREQ_TXT" )
    private String zreqTxt;
    /** File Server ID */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZFSCODE" )
    private String zfscode;
    /** 포장상태 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZSPC_FILE" )
    private String zspcFile;
    /** File ID */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZSPC_FILE_SEQNO" )
    private String zspcFileSeqno;
    /** Reference Number */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZSPC_FILE_REF_NO" )
    private String zspcFileRefNo;
    /** 불량부위 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZUNF_FILE" )
    private String zunfFile;
    /** File ID */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZUNF_FILE_SEQNO" )
    private String zunfFileSeqno;
    /** Reference Number */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZUNF_FILE_REF_NO" )
    private String zunfFileRefNo;
    /** 완료여부 */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="STYPE" )
    private String stype;
    
    /** 의뢰번호 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZSPCNO" )
    private String eZspcno;

    /** File Server ID */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_FSCODE" )
    private String eFscode;
    /** Reference Number(포장상태) */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NO1" )
    private String eRefNo1;
    /** Reference Number(불량부위) */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NO2" )
    private String eRefNo2;
    

    /**
     * @return the zspcno
     */
    public String getZspcno() {
        return zspcno;
    }

    /**
     * @param zspcno the zspcno to set
     */
    public void setZspcno(String zspcno) {
        this.zspcno = zspcno;
    }

    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }

    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }

    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }

    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }

    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }

    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }

    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }

    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }

    /**
     * @return the zedcd
     */
    public String getZedcd() {
        return zedcd;
    }

    /**
     * @param zedcd the zedcd to set
     */
    public void setZedcd(String zedcd) {
        this.zedcd = zedcd;
    }

    /**
     * @return the zpaFlg
     */
    public String getZpaFlg() {
        return zpaFlg;
    }

    /**
     * @param zpaFlg the zpaFlg to set
     */
    public void setZpaFlg(String zpaFlg) {
        this.zpaFlg = zpaFlg;
    }

    /**
     * @return the zpslot
     */
    public String getZpslot() {
        return zpslot;
    }

    /**
     * @param zpslot the zpslot to set
     */
    public void setZpslot(String zpslot) {
        this.zpslot = zpslot;
    }

    /**
     * @return the zarea
     */
    public String getZarea() {
        return zarea;
    }

    /**
     * @param zarea the zarea to set
     */
    public void setZarea(String zarea) {
        this.zarea = zarea;
    }

    /**
     * @return the zoccGb
     */
    public String getZoccGb() {
        return zoccGb;
    }

    /**
     * @param zoccGb the zoccGb to set
     */
    public void setZoccGb(String zoccGb) {
        this.zoccGb = zoccGb;
    }

    /**
     * @return the zdept
     */
    public String getZdept() {
        return zdept;
    }

    /**
     * @param zdept the zdept to set
     */
    public void setZdept(String zdept) {
        this.zdept = zdept;
    }

    /**
     * @return the zreqEmpno
     */
    public String getZreqEmpno() {
        return zreqEmpno;
    }

    /**
     * @param zreqEmpno the zreqEmpno to set
     */
    public void setZreqEmpno(String zreqEmpno) {
        this.zreqEmpno = zreqEmpno;
    }

    /**
     * @return the zemail
     */
    public String getZemail() {
        return zemail;
    }

    /**
     * @param zemail the zemail to set
     */
    public void setZemail(String zemail) {
        this.zemail = zemail;
    }

    /**
     * @return the ztell
     */
    public String getZtell() {
        return ztell;
    }

    /**
     * @param ztell the ztell to set
     */
    public void setZtell(String ztell) {
        this.ztell = ztell;
    }

    /**
     * @return the zimpgb
     */
    public String getZimpgb() {
        return zimpgb;
    }

    /**
     * @param zimpgb the zimpgb to set
     */
    public void setZimpgb(String zimpgb) {
        this.zimpgb = zimpgb;
    }

    /**
     * @return the zoccType
     */
    public String getZoccType() {
        return zoccType;
    }

    /**
     * @param zoccType the zoccType to set
     */
    public void setZoccType(String zoccType) {
        this.zoccType = zoccType;
    }

    /**
     * @return the zunfitType
     */
    public String getZunfitType() {
        return zunfitType;
    }

    /**
     * @param zunfitType the zunfitType to set
     */
    public void setZunfitType(String zunfitType) {
        this.zunfitType = zunfitType;
    }

    /**
     * @return the zunfTxt
     */
    public String getZunfTxt() {
        return zunfTxt;
    }

    /**
     * @param zunfTxt the zunfTxt to set
     */
    public void setZunfTxt(String zunfTxt) {
        this.zunfTxt = zunfTxt;
    }

    /**
     * @return the zreqTxt
     */
    public String getZreqTxt() {
        return zreqTxt;
    }

    /**
     * @param zreqTxt the zreqTxt to set
     */
    public void setZreqTxt(String zreqTxt) {
        this.zreqTxt = zreqTxt;
    }

    /**
     * @return the zspcFile
     */
    public String getZspcFile() {
        return zspcFile;
    }

    /**
     * @param zspcFile the zspcFile to set
     */
    public void setZspcFile(String zspcFile) {
        this.zspcFile = zspcFile;
    }

    /**
     * @return the zunfFile
     */
    public String getZunfFile() {
        return zunfFile;
    }

    /**
     * @param zunfFile the zunfFile to set
     */
    public void setZunfFile(String zunfFile) {
        this.zunfFile = zunfFile;
    }

    /**
     * @return the stype
     */
    public String getStype() {
        return stype;
    }

    /**
     * @param stype the stype to set
     */
    public void setStype(String stype) {
        this.stype = stype;
    }

    /**
     * @return the eZspcno
     */
    public String geteZspcno() {
        return eZspcno;
    }

    /**
     * @param eZspcno the eZspcno to set
     */
    public void seteZspcno(String eZspcno) {
        this.eZspcno = eZspcno;
    }

    /**
     * @return the zfscode
     */
    public String getZfscode() {
        return zfscode;
    }

    /**
     * @param zfscode the zfscode to set
     */
    public void setZfscode(String zfscode) {
        this.zfscode = zfscode;
    }

    /**
     * @return the zspcFileSeqno
     */
    public String getZspcFileSeqno() {
        return zspcFileSeqno;
    }

    /**
     * @param zspcFileSeqno the zspcFileSeqno to set
     */
    public void setZspcFileSeqno(String zspcFileSeqno) {
        this.zspcFileSeqno = zspcFileSeqno;
    }

    /**
     * @return the zspcFileRefNo
     */
    public String getZspcFileRefNo() {
        return zspcFileRefNo;
    }

    /**
     * @param zspcFileRefNo the zspcFileRefNo to set
     */
    public void setZspcFileRefNo(String zspcFileRefNo) {
        this.zspcFileRefNo = zspcFileRefNo;
    }

    /**
     * @return the zunfFileSeqno
     */
    public String getZunfFileSeqno() {
        return zunfFileSeqno;
    }

    /**
     * @param zunfFileSeqno the zunfFileSeqno to set
     */
    public void setZunfFileSeqno(String zunfFileSeqno) {
        this.zunfFileSeqno = zunfFileSeqno;
    }

    /**
     * @return the zunfFileRefNo
     */
    public String getZunfFileRefNo() {
        return zunfFileRefNo;
    }

    /**
     * @param zunfFileRefNo the zunfFileRefNo to set
     */
    public void setZunfFileRefNo(String zunfFileRefNo) {
        this.zunfFileRefNo = zunfFileRefNo;
    }

    /**
     * @return the eFscode
     */
    public String geteFscode() {
        return eFscode;
    }

    /**
     * @param eFscode the eFscode to set
     */
    public void seteFscode(String eFscode) {
        this.eFscode = eFscode;
    }

    /**
     * @return the eRefNo1
     */
    public String geteRefNo1() {
        return eRefNo1;
    }

    /**
     * @param eRefNo1 the eRefNo1 to set
     */
    public void seteRefNo1(String eRefNo1) {
        this.eRefNo1 = eRefNo1;
    }

    /**
     * @return the eRefNo2
     */
    public String geteRefNo2() {
        return eRefNo2;
    }

    /**
     * @param eRefNo2 the eRefNo2 to set
     */
    public void seteRefNo2(String eRefNo2) {
        this.eRefNo2 = eRefNo2;
    }

    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }

    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }

    /**
     * @return the zreqDate
     */
    public String getZreqDate() {
        return zreqDate;
    }

    /**
     * @param zreqDate the zreqDate to set
     */
    public void setZreqDate(String zreqDate) {
        this.zreqDate = zreqDate;
    }

    /**
     * @return the zimpDept
     */
    public String getZimpDept() {
        return zimpDept;
    }

    /**
     * @param zimpDept the zimpDept to set
     */
    public void setZimpDept(String zimpDept) {
        this.zimpDept = zimpDept;
    }
    
}
