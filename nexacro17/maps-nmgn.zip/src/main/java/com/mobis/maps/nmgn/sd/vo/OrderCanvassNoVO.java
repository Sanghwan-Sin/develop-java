package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;
import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderCanvassNoVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author hong.minho
 * @since 2020. 3. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 10.     hong.minho     	최초 생성
 * </pre>
 */

public class OrderCanvassNoVO extends MapsCommSapRfcIfCommVO {
    /** Category */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CATEGORY" )
    private String iCategory;
    /** 단일 문자 표시 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** H/K Common */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    
    /** Canvass No */
    private List<?> tResult;
    
//    -----[T_RESULT] START-----
    /** H/K 구분 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** Canvass No. */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCANVNO" )
    private String zcanvno;
    /** Canvass Name */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCANVNM" )
    private String zcanvnm;
    /** Category */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCATEGORY" )
    private String zcategory;
    /** 완료요청일 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZDUEDT" )
    private Date zduedt;
    /** 오더번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO" )
    private String zordno;
//    -----[T_RESULT] END-----    
    
    private String canvassDesc; // 화면display 용
    
    /**
     * @return the iCategory
     */
    public String getiCategory() {
        return iCategory;
    }
    /**
     * @param iCategory the iCategory to set
     */
    public void setiCategory(String iCategory) {
        this.iCategory = iCategory;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the tResult
     */
    public List<?> gettResult() {
        return tResult;
    }
    /**
     * @param tResult the tResult to set
     */
    public void settResult(List<?> tResult) {
        this.tResult = tResult;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zcanvno
     */
    public String getZcanvno() {
        return zcanvno;
    }
    /**
     * @param zcanvno the zcanvno to set
     */
    public void setZcanvno(String zcanvno) {
        this.zcanvno = zcanvno;
    }
    /**
     * @return the zcanvnm
     */
    public String getZcanvnm() {
        return zcanvnm;
    }
    /**
     * @param zcanvnm the zcanvnm to set
     */
    public void setZcanvnm(String zcanvnm) {
        this.zcanvnm = zcanvnm;
    }
    /**
     * @return the zcategory
     */
    public String getZcategory() {
        return zcategory;
    }
    /**
     * @param zcategory the zcategory to set
     */
    public void setZcategory(String zcategory) {
        this.zcategory = zcategory;
    }
    /**
     * @return the zduedt
     */
    public Date getZduedt() {
        return zduedt;
    }
    /**
     * @param zduedt the zduedt to set
     */
    public void setZduedt(Date zduedt) {
        this.zduedt = zduedt;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the canvassDesc
     */
    public String getCanvassDesc() {
        return canvassDesc;
    }
    /**
     * @param canvassDesc the canvassDesc to set
     */
    public void setCanvassDesc(String canvassDesc) {
        this.canvassDesc = canvassDesc;
    }
    
}
