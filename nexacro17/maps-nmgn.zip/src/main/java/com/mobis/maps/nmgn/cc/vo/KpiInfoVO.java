package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : KpiInfoOneVO.java
 * @Description : Monthly KPI Report   (RFC 입출력)
 *                ZPSD_NMGN_R_KPI
 * @author hong.minho
 * @since 2020. 11. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 11. 24.     hong.minho     	최초 생성
 * </pre>
 */

public class KpiInfoVO extends MapsCommSapRfcIfCommVO {
    
    // *** INPUT
    /** 회계연도 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_GJAHR" )
    private String iGjahr; // 년도
    
    /** 대리점코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm; // dist cd
    
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** R,C,U,D */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 영업 조직 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** 유통 경로 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    /** SD 문서 통화 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_WAERS" )
    private String iWaers;
    
    
    // *** OUTPUT
    private String lastUpdt; // Update date
    
    /** KPI Factor */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZFACTOR|ZFACTOR" )
    private String zfactor    ;
    
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT01|ZKPIAMT01" )
    private String zkpiamt01  ; // 01
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT02|ZKPIAMT02" )
    private String zkpiamt02  ; // 02
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT03|ZKPIAMT03" )
    private String zkpiamt03  ; // 03
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT04|ZKPIAMT04" )
    private String zkpiamt04  ; // 04
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT05|ZKPIAMT05" )
    private String zkpiamt05  ; // 05
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT06|ZKPIAMT06" )
    private String zkpiamt06  ; // 06
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT07|ZKPIAMT07" )
    private String zkpiamt07  ; // 07
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT08|ZKPIAMT08" )
    private String zkpiamt08  ; // 08
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT09|ZKPIAMT09" )
    private String zkpiamt09  ; // 09
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT10|ZKPIAMT10" )
    private String zkpiamt10  ; // 10
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT11|ZKPIAMT11" )
    private String zkpiamt11  ; // 11
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZKPIAMT12|ZKPIAMT12" )
    private String zkpiamt12  ; // 12
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZTOAMT|ZTOAMT" )
    private String ztoamt    ; // Total
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZAVAMT|ZAVAMT" )
    private String zavamt    ; // Average
    /** Order Value */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZTGAMT|ZTGAMT" )
    private String ztgamt   ; // Target
    /** Currency Key */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="WAERS|WAERS" )
    private String waers;
    
    
    
    
    
    /**
     * @return the iGjahr
     */
    public String getiGjahr() {
        return iGjahr;
    }
    /**
     * @param iGjahr the iGjahr to set
     */
    public void setiGjahr(String stdYear) {
        this.iGjahr = stdYear;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String distCd) {
        this.iZsacutm = distCd;
    }
    /**
     * @return the lastUpdt
     */
    public String getLastUpdt() {
        return lastUpdt;
    }
    /**
     * @param lastUpdt the lastUpdt to set
     */
    public void setLastUpdt(String lastUpdt) {
        this.lastUpdt = lastUpdt;
    }
    /**
     * @return the zfactor
     */
    public String getZfactor() {
        return zfactor;
    }
    /**
     * @param zfactor the zfactor to set
     */
    public void setZfactor(String kpicd) {
        this.zfactor = kpicd;
    }
    /**
     * @return the zkpiamt01
     */
    public String getZkpiamt01() {
        return zkpiamt01;
    }
    /**
     * @param zkpiamt01 the zkpiamt01 to set
     */
    public void setZkpiamt01(String mon01) {
        this.zkpiamt01 = mon01;
    }
    /**
     * @return the zkpiamt02
     */
    public String getZkpiamt02() {
        return zkpiamt02;
    }
    /**
     * @param zkpiamt02 the zkpiamt02 to set
     */
    public void setZkpiamt02(String mon02) {
        this.zkpiamt02 = mon02;
    }
    /**
     * @return the zkpiamt03
     */
    public String getZkpiamt03() {
        return zkpiamt03;
    }
    /**
     * @param zkpiamt03 the zkpiamt03 to set
     */
    public void setZkpiamt03(String mon03) {
        this.zkpiamt03 = mon03;
    }
    /**
     * @return the zkpiamt04
     */
    public String getZkpiamt04() {
        return zkpiamt04;
    }
    /**
     * @param zkpiamt04 the zkpiamt04 to set
     */
    public void setZkpiamt04(String mon04) {
        this.zkpiamt04 = mon04;
    }
    /**
     * @return the zkpiamt05
     */
    public String getZkpiamt05() {
        return zkpiamt05;
    }
    /**
     * @param zkpiamt05 the zkpiamt05 to set
     */
    public void setZkpiamt05(String mon05) {
        this.zkpiamt05 = mon05;
    }
    /**
     * @return the zkpiamt06
     */
    public String getZkpiamt06() {
        return zkpiamt06;
    }
    /**
     * @param zkpiamt06 the zkpiamt06 to set
     */
    public void setZkpiamt06(String mon06) {
        this.zkpiamt06 = mon06;
    }
    /**
     * @return the zkpiamt07
     */
    public String getZkpiamt07() {
        return zkpiamt07;
    }
    /**
     * @param zkpiamt07 the zkpiamt07 to set
     */
    public void setZkpiamt07(String mon07) {
        this.zkpiamt07 = mon07;
    }
    /**
     * @return the zkpiamt08
     */
    public String getZkpiamt08() {
        return zkpiamt08;
    }
    /**
     * @param zkpiamt08 the zkpiamt08 to set
     */
    public void setZkpiamt08(String mon08) {
        this.zkpiamt08 = mon08;
    }
    /**
     * @return the zkpiamt09
     */
    public String getZkpiamt09() {
        return zkpiamt09;
    }
    /**
     * @param zkpiamt09 the zkpiamt09 to set
     */
    public void setZkpiamt09(String mon09) {
        this.zkpiamt09 = mon09;
    }
    /**
     * @return the zkpiamt10
     */
    public String getZkpiamt10() {
        return zkpiamt10;
    }
    /**
     * @param zkpiamt10 the zkpiamt10 to set
     */
    public void setZkpiamt10(String mon10) {
        this.zkpiamt10 = mon10;
    }
    /**
     * @return the zkpiamt11
     */
    public String getZkpiamt11() {
        return zkpiamt11;
    }
    /**
     * @param zkpiamt11 the zkpiamt11 to set
     */
    public void setZkpiamt11(String mon11) {
        this.zkpiamt11 = mon11;
    }
    /**
     * @return the zkpiamt12
     */
    public String getZkpiamt12() {
        return zkpiamt12;
    }
    /**
     * @param zkpiamt12 the zkpiamt12 to set
     */
    public void setZkpiamt12(String mon12) {
        this.zkpiamt12 = mon12;
    }
    /**
     * @return the ztoamt
     */
    public String getZtoamt() {
        return ztoamt;
    }
    /**
     * @param ztoamt the ztoamt to set
     */
    public void setZtoamt(String tot) {
        this.ztoamt = tot;
    }
    /**
     * @return the zavamt
     */
    public String getZavamt() {
        return zavamt;
    }
    /**
     * @param zavamt the zavamt to set
     */
    public void setZavamt(String avg) {
        this.zavamt = avg;
    }
    /**
     * @return the ztgamt
     */
    public String getZtgamt() {
        return ztgamt;
    }
    /**
     * @param ztgamt the ztgamt to set
     */
    public void setZtgamt(String trgt) {
        this.ztgamt = trgt;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the iWaers
     */
    public String getiWaers() {
        return iWaers;
    }
    /**
     * @param iWaers the iWaers to set
     */
    public void setiWaers(String iWaers) {
        this.iWaers = iWaers;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
}
