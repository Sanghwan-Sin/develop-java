package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.BackOrderStatusService;
import com.mobis.maps.nmgn.sd.vo.BackOrderStatusVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : BackOrderStatusController.java
 * @Description : ZJSDR30060 BackOrder Status
 * @author 이수지
 * @since 2020. 06. 08.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 08.     이수지               최초 생성
 * </pre>
 */

@Controller
public class BackOrderStatusController extends HController {

    @Resource(name = "backOrderStatusService")
    private BackOrderStatusService backOrderStatusService;

    /**
     * selectBackOrderStatus
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectBackOrderStatus.do")
    public NexacroResult selectBackOrderStatus(@ParamDataSet(name="dsInput") BackOrderStatusVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = backOrderStatusService.selectBackOrderStatus(loginInfo, params);
        
        BackOrderStatusVO total = (BackOrderStatusVO)retMap.get("result1");
        @SuppressWarnings("unchecked")
        List<BackOrderStatusVO> list = (List<BackOrderStatusVO>)retMap.get("result2");
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput1", total);
        result.addDataSet("dsOutput2", list);
        
        return result;
    }
    
    /**
     * selectBackOrderStatusExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectBackOrderStatusExcelDown.do")
    public NexacroResult selectBackOrderStatusExcelDown(@ParamDataSet(name="dsInput") BackOrderStatusVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        Map<String, Object> retMap = backOrderStatusService.selectBackOrderStatus(loginInfo, params);
      
        BackOrderStatusVO total = (BackOrderStatusVO)retMap.get("result1");
        @SuppressWarnings("unchecked")
        List<BackOrderStatusVO> list = (List<BackOrderStatusVO>)retMap.get("result2");
        
        result.addDataSet("dsOutput1", total);
        result.addDataSet("dsOutput2", list);

        return result;
    }
}
