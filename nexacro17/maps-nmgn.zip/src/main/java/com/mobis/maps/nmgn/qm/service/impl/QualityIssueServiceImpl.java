package com.mobis.maps.nmgn.qm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.qm.service.QualityIssueService;
import com.mobis.maps.nmgn.qm.vo.ClaimCodeListVO;
import com.mobis.maps.nmgn.qm.vo.QualityIssueDetailVO;
import com.mobis.maps.nmgn.qm.vo.QualityIssueQnaVO;
import com.mobis.maps.nmgn.qm.vo.QualityIssueVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoStructure;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityIssueServiceImpl.java
 * @Description : Quality Issue
 * @author jiyongdo
 * @since 2020. 3. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 17.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("qualityIssueService")
public class QualityIssueServiceImpl extends HService implements QualityIssueService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityIssueService#selectQualityIssueList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.QualityIssueVO)
     */
    @Override
    public Map<String, Object> selectQualityIssueList(LoginInfoVO loginInfo, QualityIssueVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_R_QUALITY_ISSUE_LIST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<QualityIssueVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", paramVO, QualityIssueVO.class);

        retMap.put("body", odrLst);      
        
        return retMap; 
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityIssueService#selectClaimCodeList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.ClaimCodeListVO)
     */
    @Override
    public List<ClaimCodeListVO> selectIssueTypeList(LoginInfoVO loginInfo, ClaimCodeListVO paramVO) throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_S_CLAIMCODE;
        //paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        //mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO); 
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        //ClaimDetailVO detailVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "T_DATA", ClaimDetailVO.class); 
        List<ClaimCodeListVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", paramVO, ClaimCodeListVO.class);
        //ClaimDetailVO detailVo = odrLst.get(0);
        
        return odrLst;
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityIssueService#selectQualityIssueDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.QualityIssueDetailVO)
     */
    @Override
    public Map<String, Object> selectQualityIssueDetail(LoginInfoVO loginInfo, QualityIssueDetailVO paramVO)
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_QM_ISSUE_CRUD;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        JCoStructure isData = func.getImportParameterList().getStructure("IS_DATA");
        isData.setValue("ZCRUD", paramVO.getZcrud());    
        isData.setValue("ZQISSUENO", paramVO.getZqissueno());    
        isData.setValue("BUKRS", paramVO.getBukrs2());    
        isData.setValue("ZSYSCODE", paramVO.getZsyscode());   
        
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        //List<QualityIssueDetailVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", paramVO, QualityIssueDetailVO.class);
        QualityIssueDetailVO rtnVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_DATA", QualityIssueDetailVO.class);

        retMap.put("body", rtnVo);      
        
        return retMap; 
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityIssueService#multiQualityIssueDetail(com.mobis.maps.nmgn.qm.vo.QualityIssueDetailVO, com.mobis.maps.nmgn.qm.vo.QualityIssueDetailVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, Object> multiQualityIssueDetail(QualityIssueDetailVO paramVO, QualityIssueDetailVO rtnParamVO,
            LoginInfoVO loginInfo) throws Exception {
        
        Map<String, Object> retMap = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_QM_ISSUE_CRUD;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        //MapsRfcMappperUtil.setImportParamList(func, paramVO);
        rtnParamVO.setZcrud(paramVO.getZcrud());
        rtnParamVO.setZsyscode(paramVO.getZsyscode());
        MapsRfcMappperUtil.setImportStructure(func, "IS_DATA", rtnParamVO);
        // 파라미터(Import) 셋팅
        //JCoStructure isData = func.getImportParameterList().getStructure("IS_DATA");
        //isData.setValue("ZCRUD", paramVO.getZcrud());
        
        
        //MapsRfcMappperUtil.appendImportStructureTableRow(func, "IS_DATA", rtnParamVO);
          
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        // 개별데이타 추출
        QualityIssueDetailVO rtnList =  MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_DATA", QualityIssueDetailVO.class);
        retMap.put("body", rtnList);
        
        return retMap;
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityIssueService#selectQualityIssueQna(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.QualityIssueQnaVO)
     */
    @Override
    public Map<String, Object> selectQualityIssueQna(LoginInfoVO loginInfo, QualityIssueQnaVO paramVO)
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_R_QUALITY_ISSUE_QNA;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        JCoStructure isData = func.getImportParameterList().getStructure("IS_DATA");
        isData.setValue("ZTYPE", "R");    
        isData.setValue("ZQISSUENO", paramVO.getZqissueno());    
        isData.setValue("BUKRS", paramVO.getBukrs());    
        //isData.setValue("ZSEQ", paramVO.getZseq());   
        
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<QualityIssueQnaVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", paramVO, QualityIssueQnaVO.class);
        //QualityIssueQnaVO rtnVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "ET_DATA", QualityIssueQnaVO.class);
        MapsRfcMappperUtil.setExportParamList(funcRslt, paramVO, loginInfo.getUserLcale());
        retMap.put("body", odrLst);      
        
        return retMap; 
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityIssueService#multiQualityIssueQna(com.mobis.maps.nmgn.qm.vo.QualityIssueQnaVO, com.mobis.maps.nmgn.qm.vo.QualityIssueQnaVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, Object> multiQualityIssueQna(QualityIssueQnaVO paramVO, QualityIssueQnaVO rtnParamVO,
            LoginInfoVO loginInfo) throws Exception {
        Map<String, Object> retMap = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_R_QUALITY_ISSUE_QNA;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        
        rtnParamVO.setZtype("C");    
        rtnParamVO.setZqissueno(paramVO.getZqissueno());    
        rtnParamVO.setBukrs(paramVO.getBukrs());    
        //rtnParamVO.setZseq(paramVO.getZseq());    
        rtnParamVO.setZqstid(loginInfo.getUserId());    
        rtnParamVO.setZqstname(loginInfo.getUserNm());
        rtnParamVO.setZqstmail(loginInfo.getEmail());       
        MapsRfcMappperUtil.setImportStructure(func, "IS_DATA", rtnParamVO);
        // 파라미터(Import) 셋팅
          
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        // 개별데이타 추출
//        QualityIssueQnaVO rtnList =  MapsRfcMappperUtil.getExportStructure(funcRslt, "ET_DATA", QualityIssueQnaVO.class);
//        retMap.put("body", rtnList);
        
        return retMap;
    }
}
