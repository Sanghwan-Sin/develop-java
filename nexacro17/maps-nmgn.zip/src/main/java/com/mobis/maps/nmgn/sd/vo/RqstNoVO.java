package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : RqstNoVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 2. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 27.     jiyongdo     	최초 생성
 * </pre>
 */

public class RqstNoVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_AMEND" )
    private String iAmend;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQDT" )
    private Date iReqdt;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    //-----[T_RESULT] START-----
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="REQNO_CURRENT" )
    private String reqnoCurrent;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="REQNO_TOBE" )
    private String reqnoTobe;
    //-----[T_RESULT] END-----
    /**
     * @return the iAmend
     */
    public String getiAmend() {
        return iAmend;
    }
    /**
     * @param iAmend the iAmend to set
     */
    public void setiAmend(String iAmend) {
        this.iAmend = iAmend;
    }
    /**
     * @return the iReqdt
     */
    public Date getiReqdt() {
        return iReqdt;
    }
    /**
     * @param iReqdt the iReqdt to set
     */
    public void setiReqdt(Date iReqdt) {
        this.iReqdt = iReqdt;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the reqnoCurrent
     */
    public String getReqnoCurrent() {
        return reqnoCurrent;
    }
    /**
     * @param reqnoCurrent the reqnoCurrent to set
     */
    public void setReqnoCurrent(String reqnoCurrent) {
        this.reqnoCurrent = reqnoCurrent;
    }
    /**
     * @return the reqnoTobe
     */
    public String getReqnoTobe() {
        return reqnoTobe;
    }
    /**
     * @param reqnoTobe the reqnoTobe to set
     */
    public void setReqnoTobe(String reqnoTobe) {
        this.reqnoTobe = reqnoTobe;
    }
}
