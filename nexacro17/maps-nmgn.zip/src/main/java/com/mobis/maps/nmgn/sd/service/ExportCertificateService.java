package com.mobis.maps.nmgn.sd.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.vo.SearchInfoVO;
import com.mobis.maps.nmgn.sd.vo.CertificateRequestVO;
import com.mobis.maps.nmgn.sd.vo.CertificateVO;
import com.mobis.maps.nmgn.sd.vo.ExportCertificateVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ExportCertificateService.java
 * @Description : Export Certificate Search & Download
 * @author 이수지
 * @since 2020. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 20.      이수지	            최초 생성
 * </pre>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
 */

public interface ExportCertificateService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<CertificateVO> selectcertificate(LoginInfoVO loginInfo) throws Exception;
    
    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<ExportCertificateVO> selectExportCertificate(LoginInfoVO loginInfo, ExportCertificateVO params) throws Exception;

    /**
     * selectcertificateDoc
     *
     * @param loginInfo
     * @return
     */
    List<CertificateRequestVO> selectCertificateDoc(LoginInfoVO loginInfo) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    Map<String, Object> selectCertificateRequestList(LoginInfoVO loginInfo, CertificateRequestVO params) throws Exception;

    /**
     * Statements
     *
     * @param paramVO
     * @param paramHead
     * @param paramDetail
     * @param paramList
     * @param loginInfo
     * @return
     */
    Map<String, Object> multiCertificateRequest(CertificateRequestVO paramVO, CertificateRequestVO paramHead,
            List<CertificateRequestVO> paramDetail, List<CertificateRequestVO> paramList, LoginInfoVO loginInfo) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<CertificateRequestVO> selectcertificateChk(LoginInfoVO loginInfo, CertificateRequestVO params, List<CertificateRequestVO> paramList) throws Exception;
    
    /**
     * 플렌트/사급업체/제품업체/국가코드 조회
     *
     * @param loginVo
     * @param paramVo
     * @return
     * @throws Exception
     */
    public Map<String, Object> selectVendorList(LoginInfoVO loginVo, SearchInfoVO paramVo) throws Exception;
}
