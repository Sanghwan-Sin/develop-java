package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.ExchangePurchaseSalesService;
import com.mobis.maps.nmgn.sd.vo.ExchangePurchaseDetailVO;
import com.mobis.maps.nmgn.sd.vo.ExchangePurchaseSalesVO;
import com.mobis.maps.nmgn.sd.vo.PartInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ExchangePurchaseSalesController.java
 * @Description : Dist. Exchange Purchase Sales List/Add
 * @author jiyongdo
 * @since 2020. 2. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 19.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class ExchangePurchaseSalesController extends HController{
    
    @Resource(name = "exchangePurchaseSalesService")
    private ExchangePurchaseSalesService exchangePurchaseSalesService;

    /**
     * selectExchangePurchaseSalesList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectExchangePurchaseSalesList.do")
    public NexacroResult selectExchangePurchaseSalesList(@ParamDataSet(name="dsInput") ExchangePurchaseSalesVO paramVO
                                                       , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = exchangePurchaseSalesService.selectExchangePurchaseSalesList(loginInfo, paramVO);

        @SuppressWarnings("unchecked")
        List<ExchangePurchaseSalesVO> retList = (List<ExchangePurchaseSalesVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", paramVO);    

        return result;
    }
    
    /**
     * selectExchangePurchaseSalesListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/sd/selectExchangePurchaseSalesListExcelDown.do")
    public NexacroResult selectExchangePurchaseSalesListExcelDown(@ParamDataSet(name="dsInput") ExchangePurchaseSalesVO paramVO
                                                                , NexacroResult result) throws Exception {
         
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);        
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        Map<String, Object> retMap = exchangePurchaseSalesService.selectExchangePurchaseSalesList(loginInfo, paramVO);

        @SuppressWarnings("unchecked")
        List<ExchangePurchaseSalesVO> retList = (List<ExchangePurchaseSalesVO>)retMap.get("body");

        result.addDataSet("dsOutput", retList);

        return result;
    }    
    
    /**
     * selectDistExchangeDetailList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectDistExchangeDetailList.do")
    public NexacroResult selectDistExchangeDetailList(@ParamDataSet(name="dsInput") ExchangePurchaseDetailVO paramVO
                                                       , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = exchangePurchaseSalesService.selectDistExchangeDetailList(loginInfo, paramVO);

        //ExchangePurchaseDetailVO totList = (ExchangePurchaseDetailVO) retMap.get("head");
        @SuppressWarnings("unchecked")
        List<ExchangePurchaseDetailVO> retList = (List<ExchangePurchaseDetailVO>)retMap.get("body");
        @SuppressWarnings("unchecked")
        List<ExchangePurchaseDetailVO> headList = (List<ExchangePurchaseDetailVO>)retMap.get("head");        
        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", headList);    
        result.addDataSet("dsOutput3", paramVO);

        return result;
    }    
    
    /**
     * selectPartInfoList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPartInfoList.do")
    public NexacroResult selectPartInfoList(@ParamDataSet(name="dsInput") PartInfoVO paramVO
                                          , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = exchangePurchaseSalesService.selectPartInfoList(loginInfo, paramVO);

        //ExchangePurchaseDetailVO totList = (ExchangePurchaseDetailVO) retMap.get("head");
        @SuppressWarnings("unchecked")
        List<PartInfoVO> retList = (List<PartInfoVO>)retMap.get("body");      
        
        result.addDataSet("dsOutput", retList);  
        result.addDataSet("dsOutput2", paramVO);  

        return result;
    }      
    
    @RequestMapping(value = "/sd/multiDistExchangeDetailList.do")
    public NexacroResult multiDistExchangeDetailList(@ParamDataSet(name="dsInput") ExchangePurchaseDetailVO paramVO
                                                  , @ParamDataSet(name="dsInput2") ExchangePurchaseDetailVO headerVO
                                                  , @ParamDataSet(name="dsInput3") List<ExchangePurchaseDetailVO> paramList
                                                  , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = exchangePurchaseSalesService.multiSaveDistExchangeDetailList(paramVO, headerVO, paramList, loginInfo);
        
        //ExchangePurchaseDetailVO retVO = (ExchangePurchaseDetailVO)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<ExchangePurchaseDetailVO> retList = (List<ExchangePurchaseDetailVO>)retMap.get("body");
        @SuppressWarnings("unchecked")
        List<ExchangePurchaseDetailVO> headList = (List<ExchangePurchaseDetailVO>)retMap.get("head");        
        
        result.addDataSet("dsOutput", paramVO);
        result.addDataSet("dsOutput2", retList);        
        result.addDataSet("dsOutput3", headList);        

        return result;
    }       
    
    @RequestMapping(value = "/sd/deleteDistExchangeDetailList.do")
    public NexacroResult deleteDistExchangeDetailList(@ParamDataSet(name="dsInput") ExchangePurchaseDetailVO paramVO
                                                   , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = exchangePurchaseSalesService.deleteDistExchangeDetailList(paramVO, loginInfo);
        @SuppressWarnings("unchecked")
        List<ExchangePurchaseDetailVO> bodyList = (List<ExchangePurchaseDetailVO>)retMap.get("body");
        @SuppressWarnings("unchecked")
        List<ExchangePurchaseDetailVO> headList = (List<ExchangePurchaseDetailVO>)retMap.get("head");
        result.addDataSet("dsOutput", paramVO);
        result.addDataSet("dsOutput2", bodyList);      
        result.addDataSet("dsOutput3", headList);      

        return result;
    }          
}
