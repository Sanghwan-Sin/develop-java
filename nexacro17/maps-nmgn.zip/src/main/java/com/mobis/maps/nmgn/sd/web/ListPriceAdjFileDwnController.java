package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.ListPriceAdjFileDwnService;
import com.mobis.maps.nmgn.sd.vo.ListPriceAdjFileDwnVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceAdjFileDwnController.java
 * @Description : ZJSDR20220 List Price Adjustment 파일 Download
 * @author 이수지
 * @since 2020. 1. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 28.       이수지                최초 생성
 * </pre>
 */

@Controller
public class ListPriceAdjFileDwnController extends HController {

    @Resource(name = "listPriceAdjFileDwnService")
    private ListPriceAdjFileDwnService listPriceAdjFileDwnService;

    /**
     * selectListPriceAdjFileDwn
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectListPriceAdjFileDwn.do")
    public NexacroResult selectListPriceAdjFileDwn(@ParamDataSet(name="dsInput") ListPriceAdjFileDwnVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
       
        List<ListPriceAdjFileDwnVO> list = listPriceAdjFileDwnService.selectListPriceAdjFileDwn(loginInfo, params);
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectListPriceAdjFileExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectListPriceAdjFileExcelDown.do")
    public NexacroResult selectListPriceAdjFileExcelDown(@ParamDataSet(name="dsInput") ListPriceAdjFileDwnVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<ListPriceAdjFileDwnVO> list = listPriceAdjFileDwnService.selectListPriceAdjFileDwn(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
}
