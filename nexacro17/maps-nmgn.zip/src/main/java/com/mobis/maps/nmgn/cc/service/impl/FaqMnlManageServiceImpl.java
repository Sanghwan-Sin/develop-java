package com.mobis.maps.nmgn.cc.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.nmgn.cc.service.FaqMnlManageService;
import com.mobis.maps.nmgn.cc.service.dao.FaqMnlManageMDAO;
import com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FaqMnlManageServiceImpl.java
 * @Description : FaqMnlManageServiceImpl
 * @author choi.cheolho
 * @since 2019. 10. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 17.  choi.cheolho         최초 생성
 * </pre>
 */
@Service("faqMnlManageService")
public class FaqMnlManageServiceImpl extends HService implements FaqMnlManageService {

    @Resource(name = "faqMnlManageMDAO")
    private FaqMnlManageMDAO faqMnlManageMDAO;

    /* FAQ List 조회
     * @see com.mobis.maps.nmgn.cc.service.FaqMnlManageService#selectFaqList(com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO)
     */
    @Override
    public List<FaqMnlManageVO> selectFaqList(FaqMnlManageVO paramVO) {
        
       if ("Y".equals(paramVO.getDetail())) {
           paramVO.setPgSize(50000);
       }
        List<FaqMnlManageVO> retList = faqMnlManageMDAO.selectFaqList(paramVO);
        return retList;
    }

  
    /* FAQ 단건 조회
     * @see com.mobis.maps.nmgn.cc.service.FaqMnlManageService#selectFaq(com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO)
     */
    @Override
    public FaqMnlManageVO selectFaq(FaqMnlManageVO paramVO) {
        FaqMnlManageVO ret = faqMnlManageMDAO.selectFaq(paramVO);
        return ret;
    }
    
    /* FAQ 등록
     * @see com.mobis.maps.nmgn.cc.service.FaqMnlManageService#insertFaqManage(com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO)
     */
    @Override
    public int insertFaqManage(FaqMnlManageVO paramVO) throws Exception {
        faqMnlManageMDAO.insertFaqManage(paramVO);
        return 1;
    }

    /* FAQ 수정
     * @see com.mobis.maps.nmgn.cc.service.FaqMnlManageService#updateFaqManage(com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO)
     */
    @Override
    public int updateFaqManage(FaqMnlManageVO paramVO)  throws Exception {
        int procCnt = 0;
        
        procCnt = faqMnlManageMDAO.updateFaqManage(paramVO);
        return procCnt;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.FaqMnlManageService#deleteFaqManage(com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO)
     */
    @Override
    public int deleteFaqManage(FaqMnlManageVO paramVO)  throws Exception {
        int procCnt = 0;
        
        procCnt = faqMnlManageMDAO.deleteFaqManage(paramVO);
        return procCnt;
    }


    /*
     * @see com.mobis.maps.nmgn.cc.service.FaqMnlManageService#selectFaqEditList(com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO)
     */
    @Override
    public FaqMnlManageVO selectFaqEditList(FaqMnlManageVO paramVO) throws Exception {
        FaqMnlManageVO retVo = faqMnlManageMDAO.selectFaqEditList(paramVO);
        return retVo;
    }
}
