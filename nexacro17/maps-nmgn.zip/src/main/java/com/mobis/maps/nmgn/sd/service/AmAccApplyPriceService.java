package com.mobis.maps.nmgn.sd.service;

import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.AmAccApplyPriceVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AmAccApplyPriceService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 25.     jiyongdo     	최초 생성
 * </pre>
 */

public interface AmAccApplyPriceService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectAmAccApplyPriceList(LoginInfoVO loginInfo, AmAccApplyPriceVO paramVO) throws Exception;

}
