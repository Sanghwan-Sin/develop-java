package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceNoListVO.java
 * @Description : Invoice List, Header, Detail
 * @author jiyongdo
 * @since 2020. 2. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 3.     jiyongdo     	최초 생성
 * </pre>
 */

public class InvoiceNoListVO extends MapsCommSapRfcIfCommVO{
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_FROM_DT" )
    private Date iFromDt;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TO_DT" )
    private Date iToDt;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFSHPMD" )
    private String iZfshpmd;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_FROM_SHPDT" )
    private Date iFromShpdt;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TO_SHPDT" )
    private Date iToShpdt;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SEQ" )
    private Integer no;
    /** Invoice No. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFCIVNO" )
    private String zfcivno;
    /** Invoice Date */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFCIVDT" )
    private Date zfcivdt;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZSEND_DATE" )
    private Date zsendDate;
    /** On Board Date */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFOBDT" )
    private Date zfobdt;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ITEM" )
    private Integer item;
    /** Quantity */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFLFIMGSUM" )
    private BigDecimal zflfimgsum;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFFOBAMT" )
    private BigDecimal zffobamt;
    /** Net Value in Document Currency */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFNETWRSUM" )
    private BigDecimal zfnetwrsum;
    /** SD 문서 통화 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name 1 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /**
     * @return the iFromDt
     */
    public Date getiFromDt() {
        return iFromDt;
    }
    /**
     * @param iFromDt the iFromDt to set
     */
    public void setiFromDt(Date iFromDt) {
        this.iFromDt = iFromDt;
    }
    /**
     * @return the iToDt
     */
    public Date getiToDt() {
        return iToDt;
    }
    /**
     * @param iToDt the iToDt to set
     */
    public void setiToDt(Date iToDt) {
        this.iToDt = iToDt;
    }
    /**
     * @return the iZfshpmd
     */
    public String getiZfshpmd() {
        return iZfshpmd;
    }
    /**
     * @param iZfshpmd the iZfshpmd to set
     */
    public void setiZfshpmd(String iZfshpmd) {
        this.iZfshpmd = iZfshpmd;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the no
     */
    public Integer getNo() {
        return no;
    }
    /**
     * @param no the no to set
     */
    public void setNo(Integer no) {
        this.no = no;
    }
    /**
     * @return the zfcivno
     */
    public String getZfcivno() {
        return zfcivno;
    }
    /**
     * @param zfcivno the zfcivno to set
     */
    public void setZfcivno(String zfcivno) {
        this.zfcivno = zfcivno;
    }
    /**
     * @return the zfcivdt
     */
    public Date getZfcivdt() {
        return zfcivdt;
    }
    /**
     * @param zfcivdt the zfcivdt to set
     */
    public void setZfcivdt(Date zfcivdt) {
        this.zfcivdt = zfcivdt;
    }
    /**
     * @return the zsendDate
     */
    public Date getZsendDate() {
        return zsendDate;
    }
    /**
     * @param zsendDate the zsendDate to set
     */
    public void setZsendDate(Date zsendDate) {
        this.zsendDate = zsendDate;
    }
    /**
     * @return the zfobdt
     */
    public Date getZfobdt() {
        return zfobdt;
    }
    /**
     * @param zfobdt the zfobdt to set
     */
    public void setZfobdt(Date zfobdt) {
        this.zfobdt = zfobdt;
    }
    /**
     * @return the item
     */
    public Integer getItem() {
        return item;
    }
    /**
     * @param item the item to set
     */
    public void setItem(Integer item) {
        this.item = item;
    }
    /**
     * @return the zflfimgsum
     */
    public BigDecimal getZflfimgsum() {
        return zflfimgsum;
    }
    /**
     * @param zflfimgsum the zflfimgsum to set
     */
    public void setZflfimgsum(BigDecimal zflfimgsum) {
        this.zflfimgsum = zflfimgsum;
    }
    /**
     * @return the zffobamt
     */
    public BigDecimal getZffobamt() {
        return zffobamt;
    }
    /**
     * @param zffobamt the zffobamt to set
     */
    public void setZffobamt(BigDecimal zffobamt) {
        this.zffobamt = zffobamt;
    }
    /**
     * @return the zfnetwrsum
     */
    public BigDecimal getZfnetwrsum() {
        return zfnetwrsum;
    }
    /**
     * @param zfnetwrsum the zfnetwrsum to set
     */
    public void setZfnetwrsum(BigDecimal zfnetwrsum) {
        this.zfnetwrsum = zfnetwrsum;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the iFromShpdt
     */
    public Date getiFromShpdt() {
        return iFromShpdt;
    }
    /**
     * @param iFromShpdt the iFromShpdt to set
     */
    public void setiFromShpdt(Date iFromShpdt) {
        this.iFromShpdt = iFromShpdt;
    }
    /**
     * @return the iToShpdt
     */
    public Date getiToShpdt() {
        return iToShpdt;
    }
    /**
     * @param iToShpdt the iToShpdt to set
     */
    public void setiToShpdt(Date iToShpdt) {
        this.iToShpdt = iToShpdt;
    }
    
}
