package com.mobis.maps.nmgn.qm.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.qm.vo.ClaimCodeListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimDetailVO;
import com.mobis.maps.nmgn.qm.vo.ClaimInvoiceListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimMarkUpVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimListService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 23.     jiyongdo     	최초 생성
 * </pre>
 */

public interface ClaimListService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectClaimList(LoginInfoVO loginInfo, ClaimListVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    ClaimDetailVO selectClaimDetail(LoginInfoVO loginInfo, ClaimDetailVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<ClaimInvoiceListVO> selectInvoiceNoList(LoginInfoVO loginInfo, ClaimInvoiceListVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<ClaimCodeListVO> selectClaimCodeList(LoginInfoVO loginInfo, ClaimCodeListVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVO
     * @param paramList
     * @param loginInfo
     * @return
     */
    ClaimDetailVO multiClaimDetail(ClaimDetailVO paramVO, List<ClaimDetailVO> paramList, LoginInfoVO loginInfo) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    ClaimMarkUpVO selectMarkUpList(LoginInfoVO loginInfo, ClaimMarkUpVO paramVO) throws Exception;

}
