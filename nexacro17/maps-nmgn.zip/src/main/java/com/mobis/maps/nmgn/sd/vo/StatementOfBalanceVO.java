package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : StatementOfBalanceVO.java
 * @Description : Statement of Balance
 * @author jiyongdo
 * @since 2020. 4. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 14.     jiyongdo     	최초 생성
 * </pre>
 */

public class StatementOfBalanceVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_FROM_DT" )
    private Date iFromDt;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TO_DT" )
    private Date iToDt;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_WAERS" )
    private String iWaers;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZACTNO" )
    private String iZactno;
    private String iZactnoNm;
    //-----[ES_LIST_H] START-----
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZACTNO" )
    private String zactno;
    /** Name */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** Currency Key */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /** Long Text */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="LTEXT" )
    private String ltext;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="SNAME" )
    private String sname;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="CODE1" )
    private String code1;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="STEXT" )
    private String stext;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZBANK_S" )
    private String zbankS;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZAMT_PERIOD" )
    private String zamtPeriod;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZAMT_CURRENT" )
    private String zamtCurrent;
    //-----[ES_LIST_H] END-----
    //-----[ET_LIST_D] START-----
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZDATE" )
    private Date zdate;
    /** SEQ */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZSEQ" )
    private String zseq;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZBLCTYP" )
    private String zblctyp;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZBLCTYP_DESC" )
    private String zblctypDesc;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZAMT_S" )
    private String zamtS;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZAMT_H" )
    private String zamtH;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZBLCAMT" )
    private String zblcamt;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZREFNO" )
    private String zrefno;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZREMARK" )
    private String zremark;
    //-----[ET_LIST_D] END-----
    /**
     * @return the iFromDt
     */
    public Date getiFromDt() {
        return iFromDt;
    }
    /**
     * @param iFromDt the iFromDt to set
     */
    public void setiFromDt(Date iFromDt) {
        this.iFromDt = iFromDt;
    }
    /**
     * @return the iToDt
     */
    public Date getiToDt() {
        return iToDt;
    }
    /**
     * @param iToDt the iToDt to set
     */
    public void setiToDt(Date iToDt) {
        this.iToDt = iToDt;
    }
    /**
     * @return the iWaers
     */
    public String getiWaers() {
        return iWaers;
    }
    /**
     * @param iWaers the iWaers to set
     */
    public void setiWaers(String iWaers) {
        this.iWaers = iWaers;
    }
    /**
     * @return the iZactno
     */
    public String getiZactno() {
        return iZactno;
    }
    /**
     * @param iZactno the iZactno to set
     */
    public void setiZactno(String iZactno) {
        this.iZactno = iZactno;
    }
    /**
     * @return the iZactnoNm
     */
    public String getiZactnoNm() {
        return iZactnoNm;
    }
    /**
     * @param iZactnoNm the iZactnoNm to set
     */
    public void setiZactnoNm(String iZactnoNm) {
        this.iZactnoNm = iZactnoNm;
    }
    /**
     * @return the zactno
     */
    public String getZactno() {
        return zactno;
    }
    /**
     * @param zactno the zactno to set
     */
    public void setZactno(String zactno) {
        this.zactno = zactno;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the ltext
     */
    public String getLtext() {
        return ltext;
    }
    /**
     * @param ltext the ltext to set
     */
    public void setLtext(String ltext) {
        this.ltext = ltext;
    }
    /**
     * @return the sname
     */
    public String getSname() {
        return sname;
    }
    /**
     * @param sname the sname to set
     */
    public void setSname(String sname) {
        this.sname = sname;
    }
    /**
     * @return the code1
     */
    public String getCode1() {
        return code1;
    }
    /**
     * @param code1 the code1 to set
     */
    public void setCode1(String code1) {
        this.code1 = code1;
    }
    /**
     * @return the stext
     */
    public String getStext() {
        return stext;
    }
    /**
     * @param stext the stext to set
     */
    public void setStext(String stext) {
        this.stext = stext;
    }
    /**
     * @return the zbankS
     */
    public String getZbankS() {
        return zbankS;
    }
    /**
     * @param zbankS the zbankS to set
     */
    public void setZbankS(String zbankS) {
        this.zbankS = zbankS;
    }
    /**
     * @return the zamtPeriod
     */
    public String getZamtPeriod() {
        return zamtPeriod;
    }
    /**
     * @param zamtPeriod the zamtPeriod to set
     */
    public void setZamtPeriod(String zamtPeriod) {
        this.zamtPeriod = zamtPeriod;
    }
    /**
     * @return the zamtCurrent
     */
    public String getZamtCurrent() {
        return zamtCurrent;
    }
    /**
     * @param zamtCurrent the zamtCurrent to set
     */
    public void setZamtCurrent(String zamtCurrent) {
        this.zamtCurrent = zamtCurrent;
    }
    /**
     * @return the zdate
     */
    public Date getZdate() {
        return zdate;
    }
    /**
     * @param zdate the zdate to set
     */
    public void setZdate(Date zdate) {
        this.zdate = zdate;
    }
    /**
     * @return the zseq
     */
    public String getZseq() {
        return zseq;
    }
    /**
     * @param zseq the zseq to set
     */
    public void setZseq(String zseq) {
        this.zseq = zseq;
    }
    /**
     * @return the zblctyp
     */
    public String getZblctyp() {
        return zblctyp;
    }
    /**
     * @param zblctyp the zblctyp to set
     */
    public void setZblctyp(String zblctyp) {
        this.zblctyp = zblctyp;
    }
    /**
     * @return the zblctypDesc
     */
    public String getZblctypDesc() {
        return zblctypDesc;
    }
    /**
     * @param zblctypDesc the zblctypDesc to set
     */
    public void setZblctypDesc(String zblctypDesc) {
        this.zblctypDesc = zblctypDesc;
    }
    /**
     * @return the zamtS
     */
    public String getZamtS() {
        return zamtS;
    }
    /**
     * @param zamtS the zamtS to set
     */
    public void setZamtS(String zamtS) {
        this.zamtS = zamtS;
    }
    /**
     * @return the zamtH
     */
    public String getZamtH() {
        return zamtH;
    }
    /**
     * @param zamtH the zamtH to set
     */
    public void setZamtH(String zamtH) {
        this.zamtH = zamtH;
    }
    /**
     * @return the zblcamt
     */
    public String getZblcamt() {
        return zblcamt;
    }
    /**
     * @param zblcamt the zblcamt to set
     */
    public void setZblcamt(String zblcamt) {
        this.zblcamt = zblcamt;
    }
    /**
     * @return the zrefno
     */
    public String getZrefno() {
        return zrefno;
    }
    /**
     * @param zrefno the zrefno to set
     */
    public void setZrefno(String zrefno) {
        this.zrefno = zrefno;
    }
    /**
     * @return the zremark
     */
    public String getZremark() {
        return zremark;
    }
    /**
     * @param zremark the zremark to set
     */
    public void setZremark(String zremark) {
        this.zremark = zremark;
    }
    
}
