package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ExchangePurchaseSalesVO.java
 * @Description : Dist. Exchange Purchase Sales List/Add
 * @author jiyongdo
 * @since 2020. 2. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 19.     jiyongdo     	최초 생성
 * </pre>
 */

public class ExchangePurchaseSalesVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PART" )
    private String iPart;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PSTYPE" )
    private String iPstype;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_DIST" )
    private String iZsacutmDist;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;    
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZWRDATE_FR" )
    private Date iZwrdateFr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZWRDATE_TO" )
    private Date iZwrdateTo;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZDOCNUM" )
    private String zdocnum;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPSTYPE" )
    private String zpstype;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZWRDATE" )
    private Date zwrdate;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSUBJECT" )
    private String zsubject;
    /** Country Key */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="LAND1" )
    private String land1;
    /** Country Name */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="LAND1_NAME" )
    private String land1Name;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM_DIST" )
    private String zsacutmDist;
    /** Name */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM_DIST_NM" )
    private String zsacutmDistNm;
    /** Customer Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZDIST" )
    private String zdist;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZREADCNT" )
    private BigDecimal zreadcnt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCONTENT" )
    private String zcontent;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZWRITER" )
    private String zwriter;
    /** Currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /**
     * @return the iPart
     */
    public String getiPart() {
        return iPart;
    }
    /**
     * @param iPart the iPart to set
     */
    public void setiPart(String iPart) {
        this.iPart = iPart;
    }
    /**
     * @return the iPstype
     */
    public String getiPstype() {
        return iPstype;
    }
    /**
     * @param iPstype the iPstype to set
     */
    public void setiPstype(String iPstype) {
        this.iPstype = iPstype;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZsacutmDist
     */
    public String getiZsacutmDist() {
        return iZsacutmDist;
    }
    /**
     * @param iZsacutmDist the iZsacutmDist to set
     */
    public void setiZsacutmDist(String iZsacutmDist) {
        this.iZsacutmDist = iZsacutmDist;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the iZwrdateFr
     */
    public Date getiZwrdateFr() {
        return iZwrdateFr;
    }
    /**
     * @param iZwrdateFr the iZwrdateFr to set
     */
    public void setiZwrdateFr(Date iZwrdateFr) {
        this.iZwrdateFr = iZwrdateFr;
    }
    /**
     * @return the iZwrdateTo
     */
    public Date getiZwrdateTo() {
        return iZwrdateTo;
    }
    /**
     * @param iZwrdateTo the iZwrdateTo to set
     */
    public void setiZwrdateTo(Date iZwrdateTo) {
        this.iZwrdateTo = iZwrdateTo;
    }
    /**
     * @return the zdocnum
     */
    public String getZdocnum() {
        return zdocnum;
    }
    /**
     * @param zdocnum the zdocnum to set
     */
    public void setZdocnum(String zdocnum) {
        this.zdocnum = zdocnum;
    }
    /**
     * @return the zpstype
     */
    public String getZpstype() {
        return zpstype;
    }
    /**
     * @param zpstype the zpstype to set
     */
    public void setZpstype(String zpstype) {
        this.zpstype = zpstype;
    }
    /**
     * @return the zwrdate
     */
    public Date getZwrdate() {
        return zwrdate;
    }
    /**
     * @param zwrdate the zwrdate to set
     */
    public void setZwrdate(Date zwrdate) {
        this.zwrdate = zwrdate;
    }
    /**
     * @return the zsubject
     */
    public String getZsubject() {
        return zsubject;
    }
    /**
     * @param zsubject the zsubject to set
     */
    public void setZsubject(String zsubject) {
        this.zsubject = zsubject;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the land1Name
     */
    public String getLand1Name() {
        return land1Name;
    }
    /**
     * @param land1Name the land1Name to set
     */
    public void setLand1Name(String land1Name) {
        this.land1Name = land1Name;
    }
    /**
     * @return the zsacutmDist
     */
    public String getZsacutmDist() {
        return zsacutmDist;
    }
    /**
     * @param zsacutmDist the zsacutmDist to set
     */
    public void setZsacutmDist(String zsacutmDist) {
        this.zsacutmDist = zsacutmDist;
    }
    /**
     * @return the zsacutmDistNm
     */
    public String getZsacutmDistNm() {
        return zsacutmDistNm;
    }
    /**
     * @param zsacutmDistNm the zsacutmDistNm to set
     */
    public void setZsacutmDistNm(String zsacutmDistNm) {
        this.zsacutmDistNm = zsacutmDistNm;
    }
    /**
     * @return the zdist
     */
    public String getZdist() {
        return zdist;
    }
    /**
     * @param zdist the zdist to set
     */
    public void setZdist(String zdist) {
        this.zdist = zdist;
    }
    /**
     * @return the zreadcnt
     */
    public BigDecimal getZreadcnt() {
        return zreadcnt;
    }
    /**
     * @param zreadcnt the zreadcnt to set
     */
    public void setZreadcnt(BigDecimal zreadcnt) {
        this.zreadcnt = zreadcnt;
    }
    /**
     * @return the zcontent
     */
    public String getZcontent() {
        return zcontent;
    }
    /**
     * @param zcontent the zcontent to set
     */
    public void setZcontent(String zcontent) {
        this.zcontent = zcontent;
    }
    /**
     * @return the zwriter
     */
    public String getZwriter() {
        return zwriter;
    }
    /**
     * @param zwriter the zwriter to set
     */
    public void setZwriter(String zwriter) {
        this.zwriter = zwriter;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
}
