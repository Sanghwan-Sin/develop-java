package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : EtdRequestDetailVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 9.     jiyongdo     	최초 생성
 * </pre>
 */

public class EtdRequestDetailVO extends MapsCommSapRfcIfCommVO {
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** C:Create, U:Change, R:Display, D:Delete */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** Reference No */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDOC_NUM" )
    private String iZdocNum;
    /** SMART/AMOS Customer */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    //-----[IT_HEAD] START-----
    /**  */
    @MapsRfcMappper( targetName="IT_HEAD|IT_ITEM", ipttSe="I|E", fieldKey="ZDOC_NUM" )
    private String zdocNum;
    /**  */
    @MapsRfcMappper( targetName="IT_HEAD", ipttSe="I|E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /**  */
    @MapsRfcMappper( targetName="IT_HEAD", ipttSe="I|E", fieldKey="ZSUBJECT" )
    private String zsubject;
    /**  */
    @MapsRfcMappper( targetName="IT_HEAD|IT_ITEM", ipttSe="I|E", fieldKey="ZREQ_DT" )
    private Date zreqDt;
    //-----[IT_HEAD] END-----
    //-----[IT_ITEM] START-----
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I", fieldKey="TYPE" )
    private String type;    
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I|E", fieldKey="ZSEQ_NUM" )
    private String zseqNum;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I|E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I|E", fieldKey="ZORDLN" )
    private String zordln;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I|E", fieldKey="ZORDLS" )
    private String zordls;
    /** Material Number */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I|E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I|E", fieldKey="MAKTX" )
    private String maktx;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I|E", fieldKey="MEINS" )
    private String meins;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZBOQTY" )
    private BigDecimal zboqty;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZIN_ETD_ORI" )
    private Date zinEtdOri;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZIN_QTY_ORI" )
    private BigDecimal zinQtyOri;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZBO_ETD_ORI" )
    private Date zboEtdOri;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZBO_QTY_ORI" )
    private BigDecimal zboQtyOri;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I|E", fieldKey="ZRE_REQUEST" )
    private String zreRequest;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="I|E", fieldKey="ZPROC_FLAG" )
    private String zprocFlag;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="MSGNO" )
    private String msgno;
    /**  */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZREMARK" )
    private String zremark;    
    private String chkCode;
    private String chkDesc;
    private String zreRequestImg;
    //-----[IT_ITEM] END-----
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZdocNum
     */
    public String getiZdocNum() {
        return iZdocNum;
    }
    /**
     * @param iZdocNum the iZdocNum to set
     */
    public void setiZdocNum(String iZdocNum) {
        this.iZdocNum = iZdocNum;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zdocNum
     */
    public String getZdocNum() {
        return zdocNum;
    }
    /**
     * @param zdocNum the zdocNum to set
     */
    public void setZdocNum(String zdocNum) {
        this.zdocNum = zdocNum;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the zsubject
     */
    public String getZsubject() {
        return zsubject;
    }
    /**
     * @param zsubject the zsubject to set
     */
    public void setZsubject(String zsubject) {
        this.zsubject = zsubject;
    }
    /**
     * @return the zreqDt
     */
    public Date getZreqDt() {
        return zreqDt;
    }
    /**
     * @param zreqDt the zreqDt to set
     */
    public void setZreqDt(Date zreqDt) {
        this.zreqDt = zreqDt;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the zseqNum
     */
    public String getZseqNum() {
        return zseqNum;
    }
    /**
     * @param zseqNum the zseqNum to set
     */
    public void setZseqNum(String zseqNum) {
        this.zseqNum = zseqNum;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zordls
     */
    public String getZordls() {
        return zordls;
    }
    /**
     * @param zordls the zordls to set
     */
    public void setZordls(String zordls) {
        this.zordls = zordls;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the meins
     */
    public String getMeins() {
        return meins;
    }
    /**
     * @param meins the meins to set
     */
    public void setMeins(String meins) {
        this.meins = meins;
    }
    /**
     * @return the zboqty
     */
    public BigDecimal getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(BigDecimal zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zinEtdOri
     */
    public Date getZinEtdOri() {
        return zinEtdOri;
    }
    /**
     * @param zinEtdOri the zinEtdOri to set
     */
    public void setZinEtdOri(Date zinEtdOri) {
        this.zinEtdOri = zinEtdOri;
    }
    /**
     * @return the zinQtyOri
     */
    public BigDecimal getZinQtyOri() {
        return zinQtyOri;
    }
    /**
     * @param zinQtyOri the zinQtyOri to set
     */
    public void setZinQtyOri(BigDecimal zinQtyOri) {
        this.zinQtyOri = zinQtyOri;
    }
    /**
     * @return the zboEtdOri
     */
    public Date getZboEtdOri() {
        return zboEtdOri;
    }
    /**
     * @param zboEtdOri the zboEtdOri to set
     */
    public void setZboEtdOri(Date zboEtdOri) {
        this.zboEtdOri = zboEtdOri;
    }
    /**
     * @return the zboQtyOri
     */
    public BigDecimal getZboQtyOri() {
        return zboQtyOri;
    }
    /**
     * @param zboQtyOri the zboQtyOri to set
     */
    public void setZboQtyOri(BigDecimal zboQtyOri) {
        this.zboQtyOri = zboQtyOri;
    }
    /**
     * @return the zreRequest
     */
    public String getZreRequest() {
        return zreRequest;
    }
    /**
     * @param zreRequest the zreRequest to set
     */
    public void setZreRequest(String zreRequest) {
        this.zreRequest = zreRequest;
    }
    /**
     * @return the zprocFlag
     */
    public String getZprocFlag() {
        return zprocFlag;
    }
    /**
     * @param zprocFlag the zprocFlag to set
     */
    public void setZprocFlag(String zprocFlag) {
        this.zprocFlag = zprocFlag;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public String getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(String msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the zremark
     */
    public String getZremark() {
        return zremark;
    }
    /**
     * @param zremark the zremark to set
     */
    public void setZremark(String zremark) {
        this.zremark = zremark;
    }
    /**
     * @return the chkCode
     */
    public String getChkCode() {
        return chkCode;
    }
    /**
     * @param chkCode the chkCode to set
     */
    public void setChkCode(String chkCode) {
        this.chkCode = chkCode;
    }
    /**
     * @return the chkDesc
     */
    public String getChkDesc() {
        return chkDesc;
    }
    /**
     * @param chkDesc the chkDesc to set
     */
    public void setChkDesc(String chkDesc) {
        this.chkDesc = chkDesc;
    }
    /**
     * @return the zreRequestImg
     */
    public String getZreRequestImg() {
        return zreRequestImg;
    }
    /**
     * @param zreRequestImg the zreRequestImg to set
     */
    public void setZreRequestImg(String zreRequestImg) {
        this.zreRequestImg = zreRequestImg;
    }
}
