package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.OrderConfirmationListVO;
import com.mobis.maps.nmgn.sd.vo.OrderNoListVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderConfirmationListService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author ChoKyungHo
 * @since 2020. 02. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 02. 20.   ChoKyungHo     	                    최초 생성
 * </pre>
 */

public interface OrderConfirmationListService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<OrderConfirmationListVO> selectOrderConfirmationList(LoginInfoVO loginInfo, OrderConfirmationListVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<OrderNoListVO> selectOrderNoList(LoginInfoVO loginInfo, OrderNoListVO paramVO) throws Exception;

}
