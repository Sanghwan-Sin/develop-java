package com.mobis.maps.nmgn.sd.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;
import com.mobis.maps.nmgn.cc.vo.SearchInfoVO;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.ExportCertificateService;
import com.mobis.maps.nmgn.sd.vo.CertificateRequestVO;
import com.mobis.maps.nmgn.sd.vo.CertificateVO;
import com.mobis.maps.nmgn.sd.vo.ExportCertificateVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoStructure;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ExportCertificate.java
 * @Description : Export Certificate Search & Download
 * @author 이수지
 * @since 2020. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 20.     이수지             	최초 생성
 * </pre>
 */

@Service("exportCertificateService")
public class ExportCertificateServiceImpl extends HService implements ExportCertificateService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
   
    /*
     * @see com.mobis.maps.nmgn.sd.service.ExportCertificateService#selectcertificate(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.ExportCertificateVO)
     */
    @Override
    public List<CertificateVO> selectcertificate(LoginInfoVO loginInfo)
            throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_S_CERTLIST;
        

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());


        MapsCommSapRfcIfCommVO paramVO = new MapsCommSapRfcIfCommVO();
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        //*** 조회결과
        List<CertificateVO> list = MapsRfcMappperUtil.getExportTableResultValues(funcRslt, "T_DATA", CertificateVO.class);
        
        return list;
    }
    
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.ExportCertificateService#selectExportCertificate(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.ExportCertificateVO)
     */
    @Override
    public List<ExportCertificateVO> selectExportCertificate(LoginInfoVO loginInfo, ExportCertificateVO params)
            throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_S_CERTDOWN;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<ExportCertificateVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", params, ExportCertificateVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ExportCertificateService#selectcertificateDoc(com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<CertificateRequestVO> selectCertificateDoc(LoginInfoVO loginInfo) throws Exception {
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_S_CERTDOC;
        

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());


        MapsCommSapRfcIfCommVO paramVO = new MapsCommSapRfcIfCommVO();
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        //*** 조회결과
        List<CertificateRequestVO> list = MapsRfcMappperUtil.getExportTableResultValues(funcRslt, "T_DATA", CertificateRequestVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ExportCertificateService#selectCertificateRequestList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.CertificateRequestVO)
     */
    @Override
    public Map<String, Object> selectCertificateRequestList(LoginInfoVO loginInfo, CertificateRequestVO params)
            throws Exception {
        //*** RFC Function 취득
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_S_TEMPSAVEDP2;
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        /* RFC 호출 조회정보 추출 */
        CertificateRequestVO head = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_HEAD", CertificateRequestVO.class);
        retMap.put("head", head);   
        /* RFC 호출 조회정보 추출 */
        List<CertificateRequestVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DOC", params, CertificateRequestVO.class);
        retMap.put("body1", odrLst);       
        /* RFC 호출 조회정보 추출 */
        List<CertificateRequestVO> itmLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_PART", params, CertificateRequestVO.class);
        retMap.put("body2", itmLst);      
        return retMap; 
    }


    /*
     * @see com.mobis.maps.nmgn.sd.service.ExportCertificateService#multiCertificateRequest(com.mobis.maps.nmgn.sd.vo.CertificateRequestVO, com.mobis.maps.nmgn.sd.vo.CertificateRequestVO, com.mobis.maps.nmgn.sd.vo.CertificateRequestVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, Object> multiCertificateRequest(CertificateRequestVO paramVO, CertificateRequestVO paramHead,
            List<CertificateRequestVO> paramDetail, List<CertificateRequestVO> paramList, LoginInfoVO loginInfo)
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_REQSAVE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        //MapsRfcMappperUtil.setImportParamList(func, paramVO);
       
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);    
        
        // 파라미터(TABLES) 적재
        MapsRfcMappperUtil.setImportStructure(func, "IS_HEAD", paramHead);
        // 파라미터(TABLES) 적재
        for(CertificateRequestVO tmpVO1 : paramDetail) {
            MapsRfcMappperUtil.appendImportTableRow(func, "T_DOC", tmpVO1);
        }             
        
        // 파라미터(TABLES) 적재
        for(CertificateRequestVO tmpVO2 : paramList) {
            MapsRfcMappperUtil.appendImportTableRow(func, "T_PART", tmpVO2);
        }          
        
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        retMap.put("head", paramVO);    
        
        return retMap;
    }


    /*
     * @see com.mobis.maps.nmgn.sd.service.ExportCertificateService#selectcertificateChk(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.CertificateRequestVO)
     */
    @Override
    public List<CertificateRequestVO> selectcertificateChk(LoginInfoVO loginInfo, CertificateRequestVO params, List<CertificateRequestVO> paramList)
            throws Exception {
        //Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_S_PARTVALID;
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        // 파라미터(Import) 셋팅
        //MapsRfcMappperUtil.setImportParamList(func, paramList);
        /* RFC 호출 */
        //FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        List<CertificateRequestVO> odrLst = new ArrayList<CertificateRequestVO>();     
        for(CertificateRequestVO tmpVO : paramList) {
            odrLst.add(tmpVO);
            if("S".equals(tmpVO.getChkCd())){
                continue;
            }
            func.getImportParameterList().setValue("I_MATNR", tmpVO.getMatnr());
            MapsRfcMappperUtil.setImportParamList(func, tmpVO);
            FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
            
            mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
            MapsRfcMappperUtil.setExportParamList(funcRslt, params, loginInfo.getUserLcale());

            if("S".equals(params.getMsgType())){
                odrLst.get(odrLst.size()-1).setChkCd("S");
                odrLst.get(odrLst.size()-1).setZptnm(params.geteZptnm());
            }else{
                odrLst.get(odrLst.size()-1).setChkRslt("Material does not exist");
            }
        }  
        
        return odrLst;  
    }
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.ExportCertificateService#selectVendorList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.SearchInfoVO)
     */
    @Override
    public Map<String, Object> selectVendorList(LoginInfoVO loginInfo, SearchInfoVO paramVO)
            throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
      
        /*RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_S_VENDOR_SEARCH;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        /*공통파라미터(Import) 셋팅*/
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        /*파라미터(Import) 셋팅 */
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /*RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        /*RFC 호출 공통결과 정보 추출*/
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        //SH 조회 결과 
        SearchInfoVO esReturn = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", SearchInfoVO.class);
        
        //결과 메시지 처리
        JCoStructure resReturn = funcRslt.getExportParameterList().getStructure("ES_RETURN");
        esReturn.setMsgType(resReturn.getString("MTYPE"));
        esReturn.setMsgId(resReturn.getString("MSGID"));
        esReturn.setMsgNo(resReturn.getString("MSGNO"));
        esReturn.setMsg(resReturn.getString("MESSAGE"));
        
        retMap.put("esReturn", esReturn);
        
        List<SearchInfoVO> etData  = MapsRfcMappperUtil.getExportTableValues(funcRslt, "ET_DATA", SearchInfoVO.class);
        
        retMap.put("etData", etData);

        return retMap;
    }
    
}
