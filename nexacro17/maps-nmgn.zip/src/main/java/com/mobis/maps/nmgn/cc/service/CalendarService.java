package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.nmgn.cc.vo.CalendarHdyVO;
import com.mobis.maps.nmgn.cc.vo.CalendarVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarService.java
 * @Description : Work Calendar
 * @author hong.minho
 * @since 2020. 5. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 20.     hong.minho     	최초 생성
 * </pre>
 */

public interface CalendarService {

    /**
     * 법인별 Calendar 조회
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    List<CalendarVO> selectCalendar(LoginInfoVO loginInfo, CalendarVO params) throws MapsBizException, Exception;

    
    /**
     * 월 Calendar 조회
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    List<CalendarVO> selectCalendarMon(LoginInfoVO loginInfo, MapsOrgnztDistVO orgInfo, CalendarVO params) throws MapsBizException, Exception;
    
    
    /**
     * 법인별 공휴일 조회
     *
     * @param loginInfo
     * @param orgInfo
     * @param params
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    List<CalendarHdyVO> selectHoliday(LoginInfoVO loginInfo, CalendarHdyVO params) throws MapsBizException, Exception;
}
