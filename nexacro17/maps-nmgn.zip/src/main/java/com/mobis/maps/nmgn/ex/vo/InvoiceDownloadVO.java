package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceDownloadVO.java
 * @Description : Invoice List, Header, Detail
 * @author jiyongdo
 * @since 2020. 2. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 7.     jiyongdo     	최초 생성
 * </pre>
 */

public class InvoiceDownloadVO extends MapsCommSapRfcIfCommVO{
    private String invoiceNo;
    /** Invoice No. */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /** Seq */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SEQ" )
    private Integer seq;
    /** 오더번호 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ORDER" )
    private String order;
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LINE_ITEM" )
    private String lineItem;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PART_NO" )
    private String partNo;
    /** AC(?) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="AC" )
    private String ac;
    /** 설계부품명칭 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PART_NAME" )
    private String partName;
    /** 국가 키 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ORIGIN" )
    private String origin;
    /** 실제수량납품 (판매단위) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SHIP_QTY" )
    private BigDecimal shipQty;
    /** 단가 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="UNIT_PRICE" )
    private BigDecimal unitPrice;
    /** 전표 통화의 오더 품목 정가 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="AMOUNT" )
    private BigDecimal amount;
    
    /**
     * @return the invoiceNo
     */
    public String getInvoiceNo() {
        return invoiceNo;
    }

    /**
     * @param invoiceNo the invoiceNo to set
     */
    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }

    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }

    /**
     * @return the seq
     */
    public Integer getSeq() {
        return seq;
    }

    /**
     * @param seq the seq to set
     */
    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    /**
     * @return the order
     */
    public String getOrder() {
        return order;
    }

    /**
     * @param order the order to set
     */
    public void setOrder(String order) {
        this.order = order;
    }

    /**
     * @return the lineItem
     */
    public String getLineItem() {
        return lineItem;
    }

    /**
     * @param lineItem the lineItem to set
     */
    public void setLineItem(String lineItem) {
        this.lineItem = lineItem;
    }

    /**
     * @return the partNo
     */
    public String getPartNo() {
        return partNo;
    }

    /**
     * @param partNo the partNo to set
     */
    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }

    /**
     * @return the ac
     */
    public String getAc() {
        return ac;
    }

    /**
     * @param ac the ac to set
     */
    public void setAc(String ac) {
        this.ac = ac;
    }

    /**
     * @return the partName
     */
    public String getPartName() {
        return partName;
    }

    /**
     * @param partName the partName to set
     */
    public void setPartName(String partName) {
        this.partName = partName;
    }

    /**
     * @return the origin
     */
    public String getOrigin() {
        return origin;
    }

    /**
     * @param origin the origin to set
     */
    public void setOrigin(String origin) {
        this.origin = origin;
    }

    /**
     * @return the shipQty
     */
    public BigDecimal getShipQty() {
        return shipQty;
    }

    /**
     * @param shipQty the shipQty to set
     */
    public void setShipQty(BigDecimal shipQty) {
        this.shipQty = shipQty;
    }

    /**
     * @return the unitPrice
     */
    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    /**
     * @param unitPrice the unitPrice to set
     */
    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    /**
     * @return the amount
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
