package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.nmgn.cc.vo.MapsNoticeAtchFileVO;
import com.mobis.maps.nmgn.cc.vo.MapsNoticeVO;



/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsNoticeService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

public interface MapsNoticeService {

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    List<MapsNoticeVO> selectNoticeList(MapsNoticeVO inputVO) throws Exception;

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsNoticeVO selectNoticeNewList(MapsNoticeVO inputVO) throws Exception;

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsNoticeVO multiNotice(MapsNoticeVO inputVO) throws Exception;
    
    
    int multiNoticeAtchFile(MapsNoticeAtchFileVO mapsNoticeAtchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception;

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    List<MapsNoticeVO> selectMainNoticeList(MapsNoticeVO inputVO) throws Exception;

}
