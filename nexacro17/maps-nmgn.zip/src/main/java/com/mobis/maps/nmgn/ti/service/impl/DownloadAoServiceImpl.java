package com.mobis.maps.nmgn.ti.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ti.service.DownloadAoService;
import com.mobis.maps.nmgn.ti.vo.DownloadAoFinishVO;
import com.mobis.maps.nmgn.ti.vo.DownloadAoRequestVO;
import com.mobis.maps.nmgn.ti.vo.DownloadAoVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DownloadAoServiceImpl.java
 * @Description : Download AO List
 * @author 이수지
 * @since 2020. 06. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 16.      이수지      	        최초 생성
 * </pre>
 */

@Service("downloadAoService")
public class DownloadAoServiceImpl extends HService implements DownloadAoService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.ti.service.DownloadAoService#selectDownloadAo(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.DownloadAoVO)
     */
    @Override
    public List<DownloadAoVO> selectDownloadAo(LoginInfoVO loginVo, DownloadAoVO params)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_R_DOWNLOAD_SEARCH;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<DownloadAoVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, DownloadAoVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.DownloadAoService#selectDownloadAoRequest(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.DownloadAoRequestVO)
     */
    @Override
    public void selectDownloadAoRequest(LoginInfoVO loginVo, DownloadAoRequestVO params)
            throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_R_DOWNLOAD_REQUEST;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);      

    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.DownloadAoService#selectDownloadAoRequest(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.DownloadAoFinishVO)
     */
    @Override
    public void selectDownloadAoFinish(LoginInfoVO loginInfo, DownloadAoFinishVO params) throws Exception {
       
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_R_DOWNLOAD_FINISH;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);      
        
    }

}
