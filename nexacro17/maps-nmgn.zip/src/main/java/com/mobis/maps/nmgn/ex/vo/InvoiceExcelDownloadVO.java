package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceExcelDownloadVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author ChoKyungHo
 * @since 2020. 2. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 18.    ChoKyungHo     	                     최초 생성
 * </pre>
 */

public class InvoiceExcelDownloadVO extends MapsCommSapRfcIfCommVO{
    
    /** Invoice No. */
    @MapsRfcMappper( targetName="IT_INVOICE", ipttSe="I", fieldKey="INVOICE" )
    private String iInvoice;

    /** Invoice No. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="INVOICE" )
    private String invoice;
    /** Invoice Date */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="INV_DATE" )
    private Date invDate;
    /** Port of Loading */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFPTLD" )
    private String zfptld;
    /** Place of Delivery */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFPLDV" )
    private String zfpldv;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZSHPTP" )
    private String zshptp;
    /** Vessel Name */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFCARNM" )
    private String zfcarnm;
    /** Voyage No. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFVYNO" )
    private String zfvyno;
    /** House B/L No. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFHBLNO" )
    private String zfhblno;
    /** On Board Date */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFOBDT" )
    private Date zfobdt;
    /** Quantity of allocated cartons */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NO_OF_BOX" )
    private BigDecimal noOfBox;
    /** Quantity of allocated cartons */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NO_OF_LINE" )
    private BigDecimal noOfLine;
    /** Auto-calculated Freight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="FRE_COST" )
    private BigDecimal freCost;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFOBPR" )
    private BigDecimal zfobpr;
    /** Container NO. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CONT_NUM" )
    private String contNum;
    /** Carton Box Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="OUT_BOX_NUM" )
    private String outBoxNum;
    /** Carton Box Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="IN_BOX_NUM" )
    private String inBoxNum;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZORDLN" )
    private BigDecimal zordln;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZORDLS" )
    private String zordls;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZMATNR_INPUT" )
    private String zmatnrInput;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CONF_MATNR" )
    private String confMatnr;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SPLY_MATNR" )
    private String splyMatnr;
    /** Net Price */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NETPR" )
    private BigDecimal netpr;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZCFMQTY" )
    private BigDecimal zcfmqty;
    /** Actual quantity delivered (in sales units) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SHIP_QTY" )
    private BigDecimal shipQty;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZBOQTY" )
    private BigDecimal zboqty;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZCANCQTY" )
    private BigDecimal zcancqty;
    /** Actual quantity delivered (in sales units) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SHIP_VALUE" )
    private BigDecimal shipValue;
    /** Actual quantity delivered (in sales units) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="TOT_SHIP_QTY" )
    private BigDecimal totShipQty;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZAMDCF" )
    private String zamdcf;
    /** Country Key */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LAND1" )
    private String land1;
    /** Net weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZWEIG" )
    private BigDecimal zweig;
    /** Gross weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="OUT_BOX_GRWEI" )
    private BigDecimal outBoxGrwei;
    /** Net weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="OUT_BOX_NTGEW" )
    private BigDecimal outBoxNtgew;
    /** LENGTH(Vertical) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="OUT_BOX_LENG" )
    private BigDecimal outBoxLeng;
    /** WIDTH */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="OUT_BOX_WID" )
    private BigDecimal outBoxWid;
    /** Height */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="OUT_BOX_HEI" )
    private BigDecimal outBoxHei;
    /** Gross weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="IN_BOX_GRWEI" )
    private BigDecimal inBoxGrwei;
    /** Net weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="IN_BOX_NTGEW" )
    private BigDecimal inBoxNtgew;
    /** LENGTH(Vertical) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="IN_BOX_LENG" )
    private BigDecimal inBoxLeng;
    /** WIDTH */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="IN_BOX_WID" )
    private BigDecimal inBoxWid;
    /** Height */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="IN_BOX_HEI" )
    private BigDecimal inBoxHei;
    /** Commodity Code */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CCNGN" )
    private String ccngn;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="INT" )
    private String int1;
    /** CIF */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFCIFAMT" )
    private BigDecimal zfcifamt;
    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }
    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }
    /**
     * @return the invoice
     */
    public String getInvoice() {
        return invoice;
    }
    /**
     * @param invoice the invoice to set
     */
    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }
    /**
     * @return the invDate
     */
    public Date getInvDate() {
        return invDate;
    }
    /**
     * @param invDate the invDate to set
     */
    public void setInvDate(Date invDate) {
        this.invDate = invDate;
    }
    /**
     * @return the zfptld
     */
    public String getZfptld() {
        return zfptld;
    }
    /**
     * @param zfptld the zfptld to set
     */
    public void setZfptld(String zfptld) {
        this.zfptld = zfptld;
    }
    /**
     * @return the zfpldv
     */
    public String getZfpldv() {
        return zfpldv;
    }
    /**
     * @param zfpldv the zfpldv to set
     */
    public void setZfpldv(String zfpldv) {
        this.zfpldv = zfpldv;
    }
    /**
     * @return the zshptp
     */
    public String getZshptp() {
        return zshptp;
    }
    /**
     * @param zshptp the zshptp to set
     */
    public void setZshptp(String zshptp) {
        this.zshptp = zshptp;
    }
    /**
     * @return the zfcarnm
     */
    public String getZfcarnm() {
        return zfcarnm;
    }
    /**
     * @param zfcarnm the zfcarnm to set
     */
    public void setZfcarnm(String zfcarnm) {
        this.zfcarnm = zfcarnm;
    }
    /**
     * @return the zfvyno
     */
    public String getZfvyno() {
        return zfvyno;
    }
    /**
     * @param zfvyno the zfvyno to set
     */
    public void setZfvyno(String zfvyno) {
        this.zfvyno = zfvyno;
    }
    /**
     * @return the zfhblno
     */
    public String getZfhblno() {
        return zfhblno;
    }
    /**
     * @param zfhblno the zfhblno to set
     */
    public void setZfhblno(String zfhblno) {
        this.zfhblno = zfhblno;
    }
    /**
     * @return the zfobdt
     */
    public Date getZfobdt() {
        return zfobdt;
    }
    /**
     * @param zfobdt the zfobdt to set
     */
    public void setZfobdt(Date zfobdt) {
        this.zfobdt = zfobdt;
    }
    /**
     * @return the noOfBox
     */
    public BigDecimal getNoOfBox() {
        return noOfBox;
    }
    /**
     * @param noOfBox the noOfBox to set
     */
    public void setNoOfBox(BigDecimal noOfBox) {
        this.noOfBox = noOfBox;
    }
    /**
     * @return the noOfLine
     */
    public BigDecimal getNoOfLine() {
        return noOfLine;
    }
    /**
     * @param noOfLine the noOfLine to set
     */
    public void setNoOfLine(BigDecimal noOfLine) {
        this.noOfLine = noOfLine;
    }
    /**
     * @return the freCost
     */
    public BigDecimal getFreCost() {
        return freCost;
    }
    /**
     * @param freCost the freCost to set
     */
    public void setFreCost(BigDecimal freCost) {
        this.freCost = freCost;
    }
    /**
     * @return the zfobpr
     */
    public BigDecimal getZfobpr() {
        return zfobpr;
    }
    /**
     * @param zfobpr the zfobpr to set
     */
    public void setZfobpr(BigDecimal zfobpr) {
        this.zfobpr = zfobpr;
    }
    /**
     * @return the contNum
     */
    public String getContNum() {
        return contNum;
    }
    /**
     * @param contNum the contNum to set
     */
    public void setContNum(String contNum) {
        this.contNum = contNum;
    }
    /**
     * @return the outBoxNum
     */
    public String getOutBoxNum() {
        return outBoxNum;
    }
    /**
     * @param outBoxNum the outBoxNum to set
     */
    public void setOutBoxNum(String outBoxNum) {
        this.outBoxNum = outBoxNum;
    }
    /**
     * @return the inBoxNum
     */
    public String getInBoxNum() {
        return inBoxNum;
    }
    /**
     * @param inBoxNum the inBoxNum to set
     */
    public void setInBoxNum(String inBoxNum) {
        this.inBoxNum = inBoxNum;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zordln
     */
    public BigDecimal getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(BigDecimal zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zordls
     */
    public String getZordls() {
        return zordls;
    }
    /**
     * @param zordls the zordls to set
     */
    public void setZordls(String zordls) {
        this.zordls = zordls;
    }
    /**
     * @return the zmatnrInput
     */
    public String getZmatnrInput() {
        return zmatnrInput;
    }
    /**
     * @param zmatnrInput the zmatnrInput to set
     */
    public void setZmatnrInput(String zmatnrInput) {
        this.zmatnrInput = zmatnrInput;
    }
    /**
     * @return the confMatnr
     */
    public String getConfMatnr() {
        return confMatnr;
    }
    /**
     * @param confMatnr the confMatnr to set
     */
    public void setConfMatnr(String confMatnr) {
        this.confMatnr = confMatnr;
    }
    /**
     * @return the splyMatnr
     */
    public String getSplyMatnr() {
        return splyMatnr;
    }
    /**
     * @param splyMatnr the splyMatnr to set
     */
    public void setSplyMatnr(String splyMatnr) {
        this.splyMatnr = splyMatnr;
    }
    /**
     * @return the netpr
     */
    public BigDecimal getNetpr() {
        return netpr;
    }
    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(BigDecimal netpr) {
        this.netpr = netpr;
    }
    /**
     * @return the zcfmqty
     */
    public BigDecimal getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(BigDecimal zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the shipQty
     */
    public BigDecimal getShipQty() {
        return shipQty;
    }
    /**
     * @param shipQty the shipQty to set
     */
    public void setShipQty(BigDecimal shipQty) {
        this.shipQty = shipQty;
    }
    /**
     * @return the zboqty
     */
    public BigDecimal getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(BigDecimal zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zcancqty
     */
    public BigDecimal getZcancqty() {
        return zcancqty;
    }
    /**
     * @param zcancqty the zcancqty to set
     */
    public void setZcancqty(BigDecimal zcancqty) {
        this.zcancqty = zcancqty;
    }
    /**
     * @return the shipValue
     */
    public BigDecimal getShipValue() {
        return shipValue;
    }
    /**
     * @param shipValue the shipValue to set
     */
    public void setShipValue(BigDecimal shipValue) {
        this.shipValue = shipValue;
    }
    /**
     * @return the totShipQty
     */
    public BigDecimal getTotShipQty() {
        return totShipQty;
    }
    /**
     * @param totShipQty the totShipQty to set
     */
    public void setTotShipQty(BigDecimal totShipQty) {
        this.totShipQty = totShipQty;
    }
    /**
     * @return the zamdcf
     */
    public String getZamdcf() {
        return zamdcf;
    }
    /**
     * @param zamdcf the zamdcf to set
     */
    public void setZamdcf(String zamdcf) {
        this.zamdcf = zamdcf;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the zweig
     */
    public BigDecimal getZweig() {
        return zweig;
    }
    /**
     * @param zweig the zweig to set
     */
    public void setZweig(BigDecimal zweig) {
        this.zweig = zweig;
    }
    /**
     * @return the outBoxGrwei
     */
    public BigDecimal getOutBoxGrwei() {
        return outBoxGrwei;
    }
    /**
     * @param outBoxGrwei the outBoxGrwei to set
     */
    public void setOutBoxGrwei(BigDecimal outBoxGrwei) {
        this.outBoxGrwei = outBoxGrwei;
    }
    /**
     * @return the outBoxNtgew
     */
    public BigDecimal getOutBoxNtgew() {
        return outBoxNtgew;
    }
    /**
     * @param outBoxNtgew the outBoxNtgew to set
     */
    public void setOutBoxNtgew(BigDecimal outBoxNtgew) {
        this.outBoxNtgew = outBoxNtgew;
    }
    /**
     * @return the outBoxLeng
     */
    public BigDecimal getOutBoxLeng() {
        return outBoxLeng;
    }
    /**
     * @param outBoxLeng the outBoxLeng to set
     */
    public void setOutBoxLeng(BigDecimal outBoxLeng) {
        this.outBoxLeng = outBoxLeng;
    }
    /**
     * @return the outBoxWid
     */
    public BigDecimal getOutBoxWid() {
        return outBoxWid;
    }
    /**
     * @param outBoxWid the outBoxWid to set
     */
    public void setOutBoxWid(BigDecimal outBoxWid) {
        this.outBoxWid = outBoxWid;
    }
    /**
     * @return the outBoxHei
     */
    public BigDecimal getOutBoxHei() {
        return outBoxHei;
    }
    /**
     * @param outBoxHei the outBoxHei to set
     */
    public void setOutBoxHei(BigDecimal outBoxHei) {
        this.outBoxHei = outBoxHei;
    }
    /**
     * @return the inBoxGrwei
     */
    public BigDecimal getInBoxGrwei() {
        return inBoxGrwei;
    }
    /**
     * @param inBoxGrwei the inBoxGrwei to set
     */
    public void setInBoxGrwei(BigDecimal inBoxGrwei) {
        this.inBoxGrwei = inBoxGrwei;
    }
    /**
     * @return the inBoxNtgew
     */
    public BigDecimal getInBoxNtgew() {
        return inBoxNtgew;
    }
    /**
     * @param inBoxNtgew the inBoxNtgew to set
     */
    public void setInBoxNtgew(BigDecimal inBoxNtgew) {
        this.inBoxNtgew = inBoxNtgew;
    }
    /**
     * @return the inBoxLeng
     */
    public BigDecimal getInBoxLeng() {
        return inBoxLeng;
    }
    /**
     * @param inBoxLeng the inBoxLeng to set
     */
    public void setInBoxLeng(BigDecimal inBoxLeng) {
        this.inBoxLeng = inBoxLeng;
    }
    /**
     * @return the inBoxWid
     */
    public BigDecimal getInBoxWid() {
        return inBoxWid;
    }
    /**
     * @param inBoxWid the inBoxWid to set
     */
    public void setInBoxWid(BigDecimal inBoxWid) {
        this.inBoxWid = inBoxWid;
    }
    /**
     * @return the inBoxHei
     */
    public BigDecimal getInBoxHei() {
        return inBoxHei;
    }
    /**
     * @param inBoxHei the inBoxHei to set
     */
    public void setInBoxHei(BigDecimal inBoxHei) {
        this.inBoxHei = inBoxHei;
    }
    /**
     * @return the ccngn
     */
    public String getCcngn() {
        return ccngn;
    }
    /**
     * @param ccngn the ccngn to set
     */
    public void setCcngn(String ccngn) {
        this.ccngn = ccngn;
    }
    /**
     * @return the int1
     */
    public String getInt1() {
        return int1;
    }
    /**
     * @param int1 the int1 to set
     */
    public void setInt1(String int1) {
        this.int1 = int1;
    }
    /**
     * @return the zfcifamt
     */
    public BigDecimal getZfcifamt() {
        return zfcifamt;
    }
    /**
     * @param zfcifamt the zfcifamt to set
     */
    public void setZfcifamt(BigDecimal zfcifamt) {
        this.zfcifamt = zfcifamt;
    }
   
    
}
