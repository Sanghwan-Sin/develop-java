package com.mobis.maps.nmgn.ex.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.vo.CertificateInvoiceExcelDownVO;
import com.mobis.maps.nmgn.ex.vo.CertificateInvoiceVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CertificateInvoiceService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author ChoKyungHo
 * @since 2020. 2. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 12.     ChoKyungHo     	          최초 생성
 * </pre>
 */

public interface CertificateInvoiceService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param param
     * @return
     */
    List<CertificateInvoiceVO> selectCertificateInvoice(LoginInfoVO loginInfo, CertificateInvoiceVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<CertificateInvoiceExcelDownVO> selectCertificateInvoiceExcelDown(LoginInfoVO loginInfo, CertificateInvoiceExcelDownVO paramVO)throws Exception;

}
  
