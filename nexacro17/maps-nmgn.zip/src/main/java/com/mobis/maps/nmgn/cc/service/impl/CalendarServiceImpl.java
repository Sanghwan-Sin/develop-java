package com.mobis.maps.nmgn.cc.service.impl;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.cc.service.CalendarService;
import com.mobis.maps.nmgn.cc.service.dao.CalendarMDAO;
import com.mobis.maps.nmgn.cc.vo.CalendarHdyVO;
import com.mobis.maps.nmgn.cc.vo.CalendarVO;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarServiceImpl.java
 * @Description : Work Calendar
 * @author hong.minho
 * @since 2020. 5. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 20.     hong.minho     	최초 생성
 * </pre>
 */

@Service("calendarService")
public class CalendarServiceImpl extends HService implements CalendarService {
    
    @Resource(name = "calendarMDAO")
    CalendarMDAO dao;
    
    @Resource(name = "mapsCmmnSapService")
    MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.cc.service.CalendarService#selectCalendar(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.CalendarVO)
     */
    @Override
    public List<CalendarVO> selectCalendar(LoginInfoVO loginInfo, CalendarVO params) throws MapsBizException, Exception {
        // 언어세팅
        params.setLang(loginInfo.getLangCd());
        
        
        /*************************************************
         * 1. 달력조회
         */
        List<CalendarVO> list = dao.selectCalendar(params);
        
        if (list == null) {
            logger.error("###### Calendar Inquiry Failed.");
            return null;
        }
        
        
        // 달력만 조회시 종료
        if ("Y".equals(params.getCalOnlyYn())) {
            return list;
        }
        

        // 달력 HashMap
        Map<String, CalendarVO> calMap = new HashMap<String, CalendarVO>();
        String lastCalKey = "";
        for(CalendarVO vo : list) {
            lastCalKey = vo.getMon() + vo.getWk();
            calMap.put(lastCalKey, vo);
        }
        
        
        /*************************************************
         * 2. MAPS Holiday 조회
         */
        CalendarHdyVO hdyVo = new CalendarHdyVO();
        hdyVo.setiBukrs(params.getBukrs());
        hdyVo.setiGjahr(params.getYear());
        
        List<CalendarHdyVO> hdyLst = this.selectHoliday(loginInfo, hdyVo);
        
        // 조회한 휴일 달력에 적용 (휴일여부, 휴일내용)
        this.selectProcHoliday(hdyLst, calMap, lastCalKey, "HdYn", "Desc");

        
        /*************************************************
         * 3. Calendar 관리 기념일 조회
         */
        List<CalendarHdyVO> annvsryLst = dao.selectAnniversary(params);

        // 조회한 기념일 달력에 적용 (기념일여부, 기념일내용)
        this.selectProcHoliday(annvsryLst, calMap, lastCalKey, "AnvsyYn", "AnvsyDesc");

        

        
        /*************************************************
         * 4. 월별 휴일설명목록 생성
         */
        // 휴일설명목록 Map
        Map<String, List<CalendarHdyVO>> descLstMap = new HashMap<String, List<CalendarHdyVO>>();
        params.setDescLstMap(descLstMap);
        
        // *** Holiday
        this.selectProcHdyDesc(hdyLst, descLstMap, "H");

        // *** Anniversary
        this.selectProcHdyDesc(annvsryLst, descLstMap, "A");
        
        // Sort
        for(int mon = 1; mon <= 12; mon ++) {
            String sMon = StringUtils.leftPad(String.valueOf(mon), 2, "0");
            List<CalendarHdyVO> lst = descLstMap.get(sMon);
            if (lst == null || lst.size() <= 0) continue;
            
            lst.sort(new Comparator<CalendarHdyVO>() {
                @Override
                public int compare(CalendarHdyVO arg0, CalendarHdyVO arg1) {
                    if (arg0 == null || arg1 == null) return 0;
                    if (arg0.getHoliday() == null) return 0;
                    if (arg1.getHoliday() == null) return 0;
                    
                    // Sort 1. holiday
                    int cmp = arg0.getHoliday().compareTo(arg1.getHoliday());
                    
                    // Sort 2. tp : H > A
                    if (cmp == 0) {
                        cmp = arg0.getTp().compareTo(arg1.getTp()) * -1;
                    }
                    
                    return cmp;
                }
            });
            
        }
        
        
        
        return list;
    }
    
    
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.CalendarService#selectCalendarMon(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.CalendarVO)
     */
    @Override
    public List<CalendarVO> selectCalendarMon(LoginInfoVO loginInfo, MapsOrgnztDistVO orgInfo, CalendarVO params)
            throws MapsBizException, Exception {
        
        // this month
        Calendar now = Calendar.getInstance(loginInfo.getUserLcale());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM", loginInfo.getUserLcale());
        String mon = sdf.format(now.getTime());

        // 년월 yyyyMM
        if (StringUtils.isBlank(params.getYm())) {
            params.setYm(mon);
        }
        
        // bukrs
        params.setBukrs(orgInfo == null || StringUtils.isBlank(orgInfo.getVkorg()) ? "1000" : orgInfo.getVkorg());        
        
        // year
        params.setYear(params.getYm().substring(0, 4));
        
        // 언어세팅
        params.setLang(loginInfo.getLangCd());
        
        
        
        /*************************************************
         * 1. 달력조회
         */
        List<CalendarVO> list = dao.selectCalendarMon(params);
        
        if (list == null) {
            logger.error("###### Calendar Inquiry Failed.");
            return null;
        }
        
        
        // 달력만 조회시 종료
        if ("Y".equals(params.getCalOnlyYn())) {
            return list;
        }
        

        // 달력 HashMap
        Map<String, CalendarVO> calMap = new HashMap<String, CalendarVO>();
        String lastCalKey = "";
        for(CalendarVO vo : list) {
            lastCalKey = vo.getMon() + vo.getWk();
            calMap.put(lastCalKey, vo);
        }
        
        
        /*************************************************
         * 2. MAPS Holiday 조회
         */
        CalendarHdyVO hdyVo = new CalendarHdyVO();
        hdyVo.setiBukrs(params.getBukrs());
        hdyVo.setiGjahr(params.getYear());
        
        List<CalendarHdyVO> hdyLst = this.selectHoliday(loginInfo, hdyVo);
        
        // 조회한 휴일 달력에 적용 (휴일여부, 휴일내용)
        this.selectProcHoliday(hdyLst, calMap, lastCalKey, "HdYn", "Desc");

        
        /*************************************************
         * 3. Calendar 관리 기념일 조회
         */
        List<CalendarHdyVO> annvsryLst = dao.selectAnniversary(params);

        // 조회한 기념일 달력에 적용 (기념일여부, 기념일내용)
        this.selectProcHoliday(annvsryLst, calMap, lastCalKey, "AnvsyYn", "AnvsyDesc");

        
        
        return list;
    }

    
    

    /*
     * @see com.mobis.maps.nmgn.cc.service.CalendarService#selectHoliday(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.CalendarHdyVO)
     */
    @Override
    public List<CalendarHdyVO> selectHoliday(LoginInfoVO loginInfo, CalendarHdyVO params)
            throws MapsBizException, Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_RFC_CH_HOLIDAY_CALD_INF;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        if (logger.isDebugEnabled()) {logger.debug("*** 공통파라미터(Import) 셋팅 ");}
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        
        //*** 파라미터(Import) 셋팅
        if (logger.isDebugEnabled()) {logger.debug("*** 파라미터(Import) 셋팅");}
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        if (logger.isDebugEnabled()) {logger.debug("*** RFC 호출");}
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        if (logger.isDebugEnabled()) {logger.debug("*** RFC 호출결과 정보 추출");}
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        if (logger.isDebugEnabled()) {logger.debug("*** params.getMsgType():" + params.getMsgType());}
        
        if ("E".equals(params.getMsgType())) {
            return null;
        }
        
        //*** 조회결과
        List<CalendarHdyVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_HOLIDAY", params, CalendarHdyVO.class);

        return list;
    }


    
    /**
     * 휴일데이터를 달력에 적용처리
     *
     * @param hdyLst
     * @param calMap
     * @param lastCalKey
     * @param colNmYn
     * @param colNmDesc
     * @throws MapsBizException
     * @throws Exception
     */
    private void selectProcHoliday(List<CalendarHdyVO> hdyLst, Map<String, CalendarVO> calMap, String lastCalKey,
            String colNmYn, String colNmDesc) throws MapsBizException, Exception {
        
        Calendar cal = Calendar.getInstance();

        if (hdyLst == null) return;
        
        for(CalendarHdyVO vo : hdyLst) {
            if (vo.getHoliday() == null) continue;
            cal.setTime(vo.getHoliday());
            
            int wk = cal.get(Calendar.WEEK_OF_YEAR);
            int dw = cal.get(Calendar.DAY_OF_WEEK);
            int dt = cal.get(Calendar.DAY_OF_MONTH);
            int mon = cal.get(Calendar.MONTH);
            String sMon = StringUtils.leftPad(String.valueOf(mon+1), 2, "0");

            String key = sMon + wk;
            
            if (mon == 11 && wk == 1 && dt > 15) { // New Year = 1주차로 바뀌는 경우 보정
                key = lastCalKey;
            }

            CalendarVO calItem = calMap.get(key);
            if (logger.isDebugEnabled()) {logger.debug("["+ dt + "/" + dw + "/" + sMon + "/" + wk + "]" + key + "==>" + (calItem != null ? calItem.getWk() : null));}
            
            if (calItem == null) {
                if (logger.isDebugEnabled()) {logger.debug(" ===> continued !");}
                continue;
            }
            
            if (!sMon.equals(calItem.getMon())) {
                if (logger.isDebugEnabled()) {logger.debug(" ===> wrong month. continued !");}
                continue;
            }

            
            // *** Holiday Yn 세팅
            Method setterHdYn = calItem.getClass().getMethod("set" + colNmYn +(dw-1), new Class[]{String.class});
            if (setterHdYn == null) {
                if (logger.isDebugEnabled()) {logger.debug("#### WARNNING: No Method found (" + "set" + colNmYn +(dw-1) + ")");}
                continue;
            }
                
            setterHdYn.invoke(calItem, new Object[]{"Y"});
            
            
            // *** Holiday Desc. 세팅
            Method setterDesc = calItem.getClass().getMethod("set" + colNmDesc + (dw-1), new Class[]{String.class});
            Method getterDesc = calItem.getClass().getMethod("get" + colNmDesc + (dw-1), new Class[]{});
            if (setterDesc == null) {
                if (logger.isDebugEnabled()) {logger.debug("#### WARNNING: No Method found (" + "set" + colNmDesc + (dw-1) + ")");}
                continue;
            }
            if (getterDesc == null) {
                if (logger.isDebugEnabled()) {logger.debug("#### WARNNING: No Method found (" + "get" + colNmDesc + (dw-1) + ")");}
                continue;
            }
            
            StringBuffer sBuf = new StringBuffer();
            String descTmp = (String)getterDesc.invoke(calItem, new Object[]{});
            
            if (!StringUtils.isBlank(descTmp)) {
                sBuf.append(descTmp).append("\n");
            }
            
            sBuf.append(vo.getHolidayTxt());
                
            setterDesc.invoke(calItem, new Object[]{sBuf.toString()});
        }
    }


    /**
     * 연휴설명목록 (우측) 생성
     *
     * @param hdyLst
     * @param descLstMap
     * @param hdyTp
     * @throws MapsBizException
     * @throws Exception
     */
    private void selectProcHdyDesc(List<CalendarHdyVO> hdyLst, Map<String, List<CalendarHdyVO>> descLstMap, String hdyTp)
            throws MapsBizException, Exception {
        Calendar cal = Calendar.getInstance();
        Date dtStrt = null;
        CalendarHdyVO hdyItem = null;
        StringBuffer sDesc = new StringBuffer();
        StringBuffer sBuf = new StringBuffer();


        // Holiday Loop
        for(int idx = 0; hdyLst != null && idx < hdyLst.size(); idx++) {
            CalendarHdyVO vo = hdyLst.get(idx);
            if (vo == null) continue;

            CalendarHdyVO voNext = ((idx+1) >= (hdyLst.size()) ? null : hdyLst.get(idx+1)); // next vo
            
            cal.setTime(vo.getHoliday());
            int mon = cal.get(Calendar.MONTH); // start 0
            int dt = cal.get(Calendar.DAY_OF_MONTH); // start 1
            String sMon = StringUtils.leftPad(String.valueOf(mon+1), 2, "0");
            int nMonStrt = -1;
            int nDtStrt = -1;
            
            
            List<CalendarHdyVO> lst = descLstMap.get(sMon);
            if (lst == null) {
                lst = new ArrayList<CalendarHdyVO>();
                descLstMap.put(sMon, lst);
            }

            // 연휴이면 continue;
            if (vo.getHolydayGroupTxt() != null && 
                    voNext != null &&
                    vo.getHolydayGroupTxt().equals(voNext.getHolydayGroupTxt())) {
                if (dtStrt == null) {dtStrt = cal.getTime();}
                continue;
            }

            
            // 다음휴일이 연휴가 아니면 이후로 진행

            boolean bAcross = false;
            sBuf.delete(0, sBuf.length());sBuf.setLength(0);
            
            if (dtStrt == null) { // 단일휴일
                sBuf.append(dt);
                
            } else { // 연속휴일
                cal.setTime(dtStrt);
                nMonStrt = cal.get(Calendar.MONTH); // start 0
                nDtStrt = cal.get(Calendar.DAY_OF_MONTH); // start 1

                if (mon != nMonStrt) { // 다른월에 걸쳐 연휴
                    bAcross = true;
                    
                    sBuf.append(nMonStrt+1).append("/").append(nDtStrt);
                    sBuf.append("~");
                    sBuf.append(mon+1).append("/").append(dt);
                    
                } else { // 동일월
                    sBuf.append(nDtStrt).append("~").append(dt);
                }
            } // 연속휴일
            
            sDesc.delete(0, sDesc.length());sDesc.setLength(0);
            sDesc.append(vo.getHolidayTxt().replaceAll("([^\\(0-9]+).*", "$1"));
            sDesc.append("(").append(sBuf.toString()).append(")");

            // 달 걸친 연휴면 시작일에도 세팅
            for(int nnMon = nMonStrt; bAcross && nnMon < mon; nnMon++) {
                hdyItem = new CalendarHdyVO();
                
                if (nnMon == nMonStrt) {
                    hdyItem.setHoliday(dtStrt);
                
                } else { // 첫달 외에는 1일로 세팅
                    hdyItem.setHoliday(DateUtils.truncate(DateUtils.addMonths(dtStrt, (nnMon-nMonStrt)), Calendar.MONTH));
                }
                
if (logger.isDebugEnabled()) logger.debug("### [" + nnMon + "]연휴 세팅 일:" + hdyItem.getHoliday().toString());
                
                hdyItem.setHolidayTxt(sDesc.toString());
                hdyItem.setTp(hdyTp);
                
                List<CalendarHdyVO> lstTmp = descLstMap.get(StringUtils.leftPad(String.valueOf(nnMon+1), 2, "0"));
                if (lstTmp == null) {
                    lstTmp = new ArrayList<CalendarHdyVO>();
                    descLstMap.put(sMon, lstTmp);
                }
                
                lstTmp.add(hdyItem);
            } // 달 걸친 연휴면 시작일에도 세팅
            
            hdyItem = new CalendarHdyVO();
            hdyItem.setHoliday(vo.getHoliday());
            hdyItem.setHolidayTxt(sDesc.toString());
            hdyItem.setTp(hdyTp);
            lst.add(hdyItem);
        
            dtStrt = null; // 연휴 시작일 초기화
        }
        
    }

}
