package com.mobis.maps.nmgn.sd.web;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.OrderStatusItemService;
import com.mobis.maps.nmgn.sd.vo.OrderStatusItemVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderStatusItemController.java
 * @Description : ZJSDR30800 Order Processing Status
 * @author 홍민호
 * @since 2019. 12. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 24.     홍민호     	최초 생성
 * </pre>
 */

@Controller
public class OrderStatusItemController extends HController {

    @Resource(name = "orderStatusItemService")
    private OrderStatusItemService orderStatusItemService;

    /**
     * selectOrderStatusItem
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderStatusItem.do")
    public NexacroResult selectOrderStatusItem(@ParamDataSet(name="dsInput") OrderStatusItemVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        OrderStatusItemVO rsltVo = orderStatusItemService.selectOrderStatusItem(loginInfo, params);

        if (rsltVo != null) {
            result.addDataSet("dsOutput", rsltVo.gettResult());
            result.addDataSet("dsStatus", rsltVo.getEsTotal());
        }

        result.addDataSet("dsReturn", params);
        
        return result;
    }
    

    /**
     * selectOrderStatusItemExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderStatusItemExcelDown.do")
    public NexacroResult selectOrderStatusItemExcelDown(@ParamDataSet(name="dsInput") OrderStatusItemVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        
        // 목록조회
        OrderStatusItemVO rsltVo = orderStatusItemService.selectOrderStatusItem(loginInfo, params);
        
        if (rsltVo != null) {
            result.addDataSet("dsOutput", rsltVo.gettResult());
        }

        result.addDataSet("dsReturn", params);
        
        return result;
    }
}
