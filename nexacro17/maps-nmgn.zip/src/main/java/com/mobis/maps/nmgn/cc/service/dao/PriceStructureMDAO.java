package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.PriceStructureVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PriceStructureMDAO.java
 * @Description : PriceStructure
 * @author ha.jeongryeong
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     ha.jeongryeong         최초 생성
 * </pre>
 */

@Mapper("priceStructureMDAO")
public interface PriceStructureMDAO {

    /**
     * 조회(list)
     *
     * @param inputVO
     * @return
     */
    List<PriceStructureVO> selectPriceStructureList(PriceStructureVO paramVO);

    /**
     * 조회(detail)
     *
     * @param inputVO
     * @return
     */
    PriceStructureVO selectPriceStructure(PriceStructureVO paramVO);
    
    /**
     * 삭제(detail)
     *
     * @param inputVO
     * @return
     */
    int deletePriceStructure(PriceStructureVO paramVO);
    
    /**
     * 저장(detail)
     *
     * @param inputVO
     * @return
     */
    int insertPriceStructure(PriceStructureVO paramVO);
}
