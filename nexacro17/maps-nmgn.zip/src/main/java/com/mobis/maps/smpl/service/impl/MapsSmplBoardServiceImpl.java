package com.mobis.maps.smpl.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.smpl.service.MapsSmplBoardService;
import com.mobis.maps.smpl.service.dao.MapsSmplBoardMDAO;
import com.mobis.maps.smpl.vo.MapsSmplBoardVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplBoardServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

@Service("mapsSmplBoardService")
public class MapsSmplBoardServiceImpl extends HService implements MapsSmplBoardService{
    @Resource(name = "mapsSmplBoardMDAO")
    private MapsSmplBoardMDAO mapsSmplBoardMDAO;
    
    @Resource(name="mapsCommFileService")
    private MapsCommFileService mapsCommFileService;   
    /*
     * @see com.mobis.maps.smpl.service.MapsSmplBoardService#selectSmplBoardList(com.mobis.maps.smpl.vo.MapsSmplBoardVO)
     */
    @Override
    public List<MapsSmplBoardVO> selectSmplBoardList(MapsSmplBoardVO inputVO) {
        List<MapsSmplBoardVO> mapsSmplBoardVO = mapsSmplBoardMDAO.selectSmplBoardList(inputVO);
        return mapsSmplBoardVO;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplBoardService#selectSmplBoardNewList(com.mobis.maps.smpl.vo.MapsSmplBoardVO)
     */
    @Override
    public MapsSmplBoardVO selectSmplBoardNewList(MapsSmplBoardVO inputVO) throws Exception {
        MapsSmplBoardVO mapsSmplBoardVO = mapsSmplBoardMDAO.selectSmplBoardNewList(inputVO);
        return mapsSmplBoardVO;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplBoardService#multiSmplBoard(com.mobis.maps.smpl.vo.MapsSmplBoardVO)
     */
    @Override
    public MapsSmplBoardVO multiSmplBoard(MapsSmplBoardVO inputVO) throws Exception {
        //int nProcCnt = 0;
        MapsSmplBoardVO rtnVo = new MapsSmplBoardVO();
        if("S".equals(inputVO.getSaveType()))
        {
            MapsSmplBoardVO paramVo = mapsSmplBoardMDAO.selectContId(inputVO);
            if(!"".equals(paramVo.getBbscttId()) && !StringUtils.isEmpty(paramVo.getBbscttId()))
            {
                inputVO.setBbscttId(paramVo.getBbscttId());
            }
            else
            {
                inputVO.setBbscttId("0");
            }
            mapsSmplBoardMDAO.insertSmplBoard(inputVO);
            rtnVo.setAtchId(inputVO.getBbscttId());
        }
        else if("R".equals(inputVO.getSaveType()))
        {
            MapsSmplBoardVO paramVo = mapsSmplBoardMDAO.selectSeq(inputVO); 
            inputVO.setBbscttSeq(paramVo.getBbscttSeq());
            mapsSmplBoardMDAO.insertSmplBoardRply(inputVO);
            rtnVo.setAtchId(inputVO.getBbscttId());
            rtnVo.setSeqNo(paramVo.getBbscttSeq());
        }        
        else if("U".equals(inputVO.getSaveType()))
        {
            mapsSmplBoardMDAO.updateSmplBoard(inputVO);
        }
        else if("D".equals(inputVO.getSaveType()))
        {
            mapsSmplBoardMDAO.deleteSmplBoard(inputVO);
            MapsAtchFileVO atchFileVO = new MapsAtchFileVO();            
            atchFileVO.setAtchSe(inputVO.getAtchSe());
            atchFileVO.setAtchId(inputVO.getAtchId());
            
            mapsCommFileService.deleteAtchFileAll(atchFileVO);

        }
        return rtnVo;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplBoardService#multiAtchFile(com.mobis.maps.smpl.vo.MapsSmplBoardVO, java.util.List)
     */
    @Override
    public int multiAtchFile(MapsSmplBoardVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception {
        int retCnt = 0;
        if (atchFiles != null && atchFiles.size()>0) {
            AtchFileSe atchFileGubn = AtchFileSe.get(atchFileVO.getAtchSe()); 
            retCnt = mapsCommFileService.multiAtchFile(atchFileGubn, atchFileVO, atchFiles);    
        }
        return retCnt;
    }
}
