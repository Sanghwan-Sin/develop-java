package com.mobis.maps.nmgn.main.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.cc.vo.MapsOrderSummaryVO;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.main.service.MobisDefaultMainService;
import com.mobis.maps.nmgn.main.vo.MobisDefaultMainVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MobisDefaultMainServiceImpl.java
 * @Description : Main Impl
 * @author jiyongdo
 * @since 2020. 8. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 14.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("mobisDefaultMainService")
public class MobisDefaultMainServiceImpl extends HService implements MobisDefaultMainService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.main.service.MobisDefaultMainService#selectMainPaymentDueOrderList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.main.vo.MobisDefaultMainVO)
     */
    @Override
    public Map<String, Object> selectMainPaymentDueOrderList(LoginInfoVO loginInfo, MobisDefaultMainVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_MAIN_PAYMENT_DUE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        MobisDefaultMainVO odrLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_LIST_H", MobisDefaultMainVO.class);

        retMap.put("body", odrLst);      
        
        return retMap;
    }

    /*
     * @see com.mobis.maps.nmgn.main.service.MobisDefaultMainService#selectMainStatementofBalance(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.main.vo.MobisDefaultMainVO)
     */
    @Override
    public Map<String, Object> selectMainStatementofBalance(LoginInfoVO loginInfo, MobisDefaultMainVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_MAIN_BALANCE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        MapsRfcMappperUtil.setExportParamList(funcRslt, paramVO, loginInfo.getUserLcale());

        retMap.put("body", paramVO);      
        
        return retMap;
    }

    
    /*
     * @see com.mobis.maps.nmgn.main.service.MobisDefaultMainService#selectOrderProcessSummary(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.MapsOrderSummaryVO)
     */
    @Override
    public MapsOrderSummaryVO selectOrderProcessSummary(LoginInfoVO loginInfo, MapsOrderSummaryVO params)
            throws Exception {
        
        // VO 초기화
        params.setZordcnt  (BigDecimal.ZERO);
        params.setZbocnt   (BigDecimal.ZERO);
        params.setZalocnt  (BigDecimal.ZERO);
        params.setZpiccntOn(BigDecimal.ZERO);
        params.setZpaccntOn(BigDecimal.ZERO);
        params.setZpaccnt  (BigDecimal.ZERO);
        params.setZloadcnt (BigDecimal.ZERO);
        params.setZinvcnt  (BigDecimal.ZERO);
        params.setZshpcnt  (BigDecimal.ZERO);
        params.setZunprocnt(BigDecimal.ZERO);
        
        params.setZordqty  ("0");
        params.setZboqty   ("0");
        params.setZaloqty  ("0");
        params.setZpicqtyOn("0");
        params.setZpacqtyOn("0");
        params.setZpacqty  ("0");
        params.setZloadqty ("0");
        params.setZinvqty  ("0");
        params.setZshpqty  ("0");
        
        params.setZordamt  ("0.00");
        params.setZboamt   ("0.00");
        params.setZaloamt  ("0.00");
        params.setZpicamtOn("0.00");
        params.setZpacamtOn("0.00");
        params.setZpacamt  ("0.00");
        params.setZloadamt ("0.00");
        params.setZinvamt  ("0.00");
        params.setZshpamt  ("0.00");

        
        if (StringUtils.isBlank(params.getiZsacutm())) {
            return params;
        }
        
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_CUSTOMER_HOME;
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
//        // RFC 호출 공통결과 정보 추출
//        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        MapsOrderSummaryVO rsltVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_TOTAL", MapsOrderSummaryVO.class);
        rsltVo.setiZsacutm(params.getiZsacutm());
        
        return rsltVo;
    }

}
