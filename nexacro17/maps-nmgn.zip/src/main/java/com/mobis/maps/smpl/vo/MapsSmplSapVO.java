package com.mobis.maps.smpl.vo;

import com.mobis.maps.comm.vo.CommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSampleSapVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 16.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsSmplSapVO extends CommVO {

}
