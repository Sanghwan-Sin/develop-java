package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.DpomManualVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistributorPartsOperationManualMDAO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 10. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 22.     Jiyongdo     	최초 생성
 * </pre>
 */
@Mapper("distributorPartsOperationManualMDAO")
public interface DistributorPartsOperationManualMDAO {

    /**
     * DPOM 조회
     *
     * @param paramVO
     * @return
     */
    List<DpomManualVO> selectDpomList(DpomManualVO paramVO) throws Exception;

    /**
     * DPOM Edit 조회
     *
     * @param paramVO
     * @return
     */
    DpomManualVO selectDpomEditList(DpomManualVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVO
     * @return
     */
    int deleteDpomList(DpomManualVO paramVO) throws Exception;
    
    /**
     * Statements
     *
     * @param paramVOList
     * @return
     */
    int deleteDpom(DpomManualVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVOList
     * @return
     */
    int updateDpom(DpomManualVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVOList
     * @return
     */
    int insertDpom(DpomManualVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param tmpVO
     */
    void deleteAtchFileAll(DpomManualVO tmpVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVO
     */
    void updateDpomRdCnt(DpomManualVO paramVO);   
}
