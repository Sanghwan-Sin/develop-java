package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.vo.CalendarMngVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarMngService.java
 * @Description : Work Calendar Manage
 * @author 이수지
 * @since 2020. 5. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 25.     이수지            	최초 생성
 * </pre>
 */

public interface CalendarMngService {

    /**
     * Work Calendar Manage 조회
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws Exception
     */
    List<CalendarMngVO> selectCalendarMngList(LoginInfoVO loginInfo, CalendarMngVO params) throws Exception;

    /**
     * Work Calendar 저장/수정/삭제
     *
     * @param params2
     * @param params2 
     * @return
     */
    void multiCalendarMng(LoginInfoVO loginInfo, List<CalendarMngVO> params);
}
