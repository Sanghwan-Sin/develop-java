package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;
import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderStatusItemVO.java
 * @Description : ZPSD_NMGN_R_ORDER_ITEM_LIST
 * @author 홍민호
 * @since 2019. 12. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 23.     홍민호     	최초 생성
 * </pre>
 */

public class OrderStatusItemVO extends MapsCommSapRfcIfCommVO {

    private int rnum;


    /*** INPUT **********************************************/
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PARTNO" )
    private String iPartno;
    /** C:Create, U:Change, R:Display */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** ORDER HEAD PROCESS CODE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZOHPCD" )
    private String iZohpcd;
    /** ORDERED DATE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_FR" )
    private Date iZorddtFr;
    /** ORDERED DATE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_TO" )
    private Date iZorddtTo;
    /** 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_E" )
    private String iZordnoE;
    /** 고객 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_P" )
    private String iZordnoP;
    /** 오더유형 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDTYP" )
    private String iZordtyp;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    /** History Display */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_HISTORY" )
    private String iHistory;
    /* ORDER HEAD PROCESS CODE ( =' ') */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZOHPCD_EQ" )
    private String iZohpcdEq;
    
    
    /*** ES_TOTAL ******************************************************/
    private OrderStatusTotalVO esTotal = null;
    
    
    /*** T_RESULT ******************************************************/
    private List<?> tResult = null;
//    -----[T_RESULT] START-----
    /** 자재내역 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** EXPORT PRICE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NETPR" )
    private String netpr;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZNETPRU" )
    private String znetpru;
    /** Base D/C Rate */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZTOT_DC" )
    private String ztotDc;
    /** SD 문서 통화 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK_USD" )
    private String waerkUsd;
    /** 플랜트 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WERKS" )
    private String werks;
    /** Alloc. Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZALODT" )
    private Date zalodt;
    /** Processing Alloc. */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZALOQTY" )
    private String zaloqty = null;
    /** AMEND CODE LAST */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZAMDCL" )
    private String zamdcl;
    /** B/O Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZBODT" )
    private Date zbodt;
    /** Processing B/O */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZBOQTY" )
    private String zboqty = null;
    /** Cancelled Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCANCDT" )
    private Date zcancdt;
    /** 취소수량 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCANCQTY" )
    private String zcancqty = null;
    /** 직불설정여부 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCDKFG" )
    private String zcdkfg;
    /** CONFIRME DATE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCFMDT" )
    private Date zcfmdt;
    /** Pieces Confirmed */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCFMQTY" )
    private String zcfmqty = null;
    /** ETD DATE 1 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETDD1" )
    private Date zetdd1;
    /** ETD DATE 2 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETDD2" )
    private Date zetdd2;
    /** ETD DATE 3 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETDD3" )
    private Date zetdd3;
    /** ETD DATE 4 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETDD4" )
    private Date zetdd4;
    /** EXPORT PRICE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZEXPRC_CUST" )
    private String zexprcCust;
    /** Invoiced Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZINVDT" )
    private Date zinvdt;
    /** Processing Invoiced */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZINVQTY" )
    private String zinvqty = null;
    /** 최초부품코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMATNR_INPUT" )
    private String zmatnrInput;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMATNR_SHIP" )
    private String zmatnrShip;
    /** Memo */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMEMO" )
    private String zmemo;
    /** ORDER DETAIL FLAG CODE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZODFCD" )
    private String zodfcd;
    /** ORDER HEAD PROCESS CODE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZOHPCD" )
    private String zohpcd;
    /** On Pick Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZONPICDT" )
    private Date zonpicdt;
    /** On Pick Qty */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPICQTY_ON" )
    private String zpicqtyOn = null;
    /** Amount Ordered */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDAMT" )
    private String zordamt;
    /** ORDERED DATE */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDDT" )
    private Date zorddt;
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDLN" )
    private String zordln;
    /** 오더 Line Suffix */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDLS" )
    private String zordls;
    /** SEQ번호(청구번호) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO" )
    private String zordno;
    /** 오더번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /** 고객오더번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_P" )
    private String zordnoP;
    /** Pieces Ordered */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDQTY" )
    private String zordqty = null;
    /** 오더유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP" )
    private String zordtyp;
    /** Packed Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPACKDT" )
    private Date zpackdt;
    /** Processing Packed */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPACQTY" )
    private String zpacqty = null;
    /** Picked Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPICKDT" )
    private Date zpickdt;
    /** Processing Picked */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPICQTY" )
    private String zpicqty = null;
    /** Shipped Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSHIPDT" )
    private Date zshipdt;
    /** Processing Shipped */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSHPQTY" )
    private String zshpqty = null;
    /** SD 문서 통화 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZWAERK_CUST" )
    private String zwaerkCust;
    /** On Pack Qty */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPACQTY_ON" )
    private String zpacqtyOn;
    /** On Pack Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZONPACDT" )
    private Date zonpacdt;
    
    /** Shipping Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="VSART" )
    private String vsart;
    /** Customer Reference */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="BSTKD" )
    private String bstkd;
    /** Order Line Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZZORDLN" )
    private String zzordln;
    /** Order Line Suffix */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZZORDLS" )
    private String zzordls;

    
    /** Single-Character Flag */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="HISTORY" )
    private String history;
    
    
//    -----[T_RESULT] END-----
    
    
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the iPartno
     */
    public String getiPartno() {
        return iPartno;
    }
    /**
     * @param iPartno the iPartno to set
     */
    public void setiPartno(String iPartno) {
        this.iPartno = iPartno;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZohpcd
     */
    public String getiZohpcd() {
        return iZohpcd;
    }
    /**
     * @param iZohpcd the iZohpcd to set
     */
    public void setiZohpcd(String iZohpcd) {
        this.iZohpcd = iZohpcd;
    }
    /**
     * @return the iZorddtFr
     */
    public Date getiZorddtFr() {
        return iZorddtFr;
    }
    /**
     * @param iZorddtFr the iZorddtFr to set
     */
    public void setiZorddtFr(Date iZorddtFr) {
        this.iZorddtFr = iZorddtFr;
    }
    /**
     * @return the iZorddtTo
     */
    public Date getiZorddtTo() {
        return iZorddtTo;
    }
    /**
     * @param iZorddtTo the iZorddtTo to set
     */
    public void setiZorddtTo(Date iZorddtTo) {
        this.iZorddtTo = iZorddtTo;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the iZordnoP
     */
    public String getiZordnoP() {
        return iZordnoP;
    }
    /**
     * @param iZordnoP the iZordnoP to set
     */
    public void setiZordnoP(String iZordnoP) {
        this.iZordnoP = iZordnoP;
    }
    /**
     * @return the iZordtyp
     */
    public String getiZordtyp() {
        return iZordtyp;
    }
    /**
     * @param iZordtyp the iZordtyp to set
     */
    public void setiZordtyp(String iZordtyp) {
        this.iZordtyp = iZordtyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the tResult
     */
    public List<?> gettResult() {
        return tResult;
    }
    /**
     * @param tResult the tResult to set
     */
    public void settResult(List<?> tResult) {
        this.tResult = tResult;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the netpr
     */
    public String getNetpr() {
        return netpr;
    }
    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(String netpr) {
        this.netpr = netpr;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }
    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }
    /**
     * @return the zalodt
     */
    public Date getZalodt() {
        return zalodt;
    }
    /**
     * @param zalodt the zalodt to set
     */
    public void setZalodt(Date zalodt) {
        this.zalodt = zalodt;
    }
    /**
     * @return the zaloqty
     */
    public String getZaloqty() {
        return zaloqty;
    }
    /**
     * @param zaloqty the zaloqty to set
     */
    public void setZaloqty(String zaloqty) {
        this.zaloqty = zaloqty;
    }
    /**
     * @return the zamdcl
     */
    public String getZamdcl() {
        return zamdcl;
    }
    /**
     * @param zamdcl the zamdcl to set
     */
    public void setZamdcl(String zamdcl) {
        this.zamdcl = zamdcl;
    }
    /**
     * @return the zbodt
     */
    public Date getZbodt() {
        return zbodt;
    }
    /**
     * @param zbodt the zbodt to set
     */
    public void setZbodt(Date zbodt) {
        this.zbodt = zbodt;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zcancdt
     */
    public Date getZcancdt() {
        return zcancdt;
    }
    /**
     * @param zcancdt the zcancdt to set
     */
    public void setZcancdt(Date zcancdt) {
        this.zcancdt = zcancdt;
    }
    /**
     * @return the zcancqty
     */
    public String getZcancqty() {
        return zcancqty;
    }
    /**
     * @param zcancqty the zcancqty to set
     */
    public void setZcancqty(String zcancqty) {
        this.zcancqty = zcancqty;
    }
    /**
     * @return the zcdkfg
     */
    public String getZcdkfg() {
        return zcdkfg;
    }
    /**
     * @param zcdkfg the zcdkfg to set
     */
    public void setZcdkfg(String zcdkfg) {
        this.zcdkfg = zcdkfg;
    }
    /**
     * @return the zcfmdt
     */
    public Date getZcfmdt() {
        return zcfmdt;
    }
    /**
     * @param zcfmdt the zcfmdt to set
     */
    public void setZcfmdt(Date zcfmdt) {
        this.zcfmdt = zcfmdt;
    }
    /**
     * @return the zcfmqty
     */
    public String getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(String zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the zetdd1
     */
    public Date getZetdd1() {
        return zetdd1;
    }
    /**
     * @param zetdd1 the zetdd1 to set
     */
    public void setZetdd1(Date zetdd1) {
        this.zetdd1 = zetdd1;
    }
    /**
     * @return the zetdd2
     */
    public Date getZetdd2() {
        return zetdd2;
    }
    /**
     * @param zetdd2 the zetdd2 to set
     */
    public void setZetdd2(Date zetdd2) {
        this.zetdd2 = zetdd2;
    }
    /**
     * @return the zetdd3
     */
    public Date getZetdd3() {
        return zetdd3;
    }
    /**
     * @param zetdd3 the zetdd3 to set
     */
    public void setZetdd3(Date zetdd3) {
        this.zetdd3 = zetdd3;
    }
    /**
     * @return the zetdd4
     */
    public Date getZetdd4() {
        return zetdd4;
    }
    /**
     * @param zetdd4 the zetdd4 to set
     */
    public void setZetdd4(Date zetdd4) {
        this.zetdd4 = zetdd4;
    }
    /**
     * @return the zexprcCust
     */
    public String getZexprcCust() {
        return zexprcCust;
    }
    /**
     * @param zexprcCust the zexprcCust to set
     */
    public void setZexprcCust(String zexprcCust) {
        this.zexprcCust = zexprcCust;
    }
    /**
     * @return the zinvdt
     */
    public Date getZinvdt() {
        return zinvdt;
    }
    /**
     * @param zinvdt the zinvdt to set
     */
    public void setZinvdt(Date zinvdt) {
        this.zinvdt = zinvdt;
    }
    /**
     * @return the zinvqty
     */
    public String getZinvqty() {
        return zinvqty;
    }
    /**
     * @param zinvqty the zinvqty to set
     */
    public void setZinvqty(String zinvqty) {
        this.zinvqty = zinvqty;
    }
    /**
     * @return the zmatnrInput
     */
    public String getZmatnrInput() {
        return zmatnrInput;
    }
    /**
     * @param zmatnrInput the zmatnrInput to set
     */
    public void setZmatnrInput(String zmatnrInput) {
        this.zmatnrInput = zmatnrInput;
    }
    /**
     * @return the zmatnrShip
     */
    public String getZmatnrShip() {
        return zmatnrShip;
    }
    /**
     * @param zmatnrShip the zmatnrShip to set
     */
    public void setZmatnrShip(String zmatnrShip) {
        this.zmatnrShip = zmatnrShip;
    }
    /**
     * @return the zmemo
     */
    public String getZmemo() {
        return zmemo;
    }
    /**
     * @param zmemo the zmemo to set
     */
    public void setZmemo(String zmemo) {
        this.zmemo = zmemo;
    }
    /**
     * @return the zodfcd
     */
    public String getZodfcd() {
        return zodfcd;
    }
    /**
     * @param zodfcd the zodfcd to set
     */
    public void setZodfcd(String zodfcd) {
        this.zodfcd = zodfcd;
    }
    /**
     * @return the zohpcd
     */
    public String getZohpcd() {
        return zohpcd;
    }
    /**
     * @param zohpcd the zohpcd to set
     */
    public void setZohpcd(String zohpcd) {
        this.zohpcd = zohpcd;
    }
    /**
     * @return the zonpicdt
     */
    public Date getZonpicdt() {
        return zonpicdt;
    }
    /**
     * @param zonpicdt the zonpicdt to set
     */
    public void setZonpicdt(Date zonpicdt) {
        this.zonpicdt = zonpicdt;
    }
    /**
     * @return the zpicqtyOn
     */
    public String getZpicqtyOn() {
        return zpicqtyOn;
    }
    /**
     * @param zpicqtyOn the zpicqtyOn to set
     */
    public void setZpicqtyOn(String zonpicqty) {
        this.zpicqtyOn = zonpicqty;
    }
    /**
     * @return the zordamt
     */
    public String getZordamt() {
        return zordamt;
    }
    /**
     * @param zordamt the zordamt to set
     */
    public void setZordamt(String zordamt) {
        this.zordamt = zordamt;
    }
    /**
     * @return the zorddt
     */
    public Date getZorddt() {
        return zorddt;
    }
    /**
     * @param zorddt the zorddt to set
     */
    public void setZorddt(Date zorddt) {
        this.zorddt = zorddt;
    }
    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zordls
     */
    public String getZordls() {
        return zordls;
    }
    /**
     * @param zordls the zordls to set
     */
    public void setZordls(String zordls) {
        this.zordls = zordls;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zordqty
     */
    public String getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(String zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the zpackdt
     */
    public Date getZpackdt() {
        return zpackdt;
    }
    /**
     * @param zpackdt the zpackdt to set
     */
    public void setZpackdt(Date zpackdt) {
        this.zpackdt = zpackdt;
    }
    /**
     * @return the zpacqty
     */
    public String getZpacqty() {
        return zpacqty;
    }
    /**
     * @param zpacqty the zpacqty to set
     */
    public void setZpacqty(String zpacqty) {
        this.zpacqty = zpacqty;
    }
    /**
     * @return the zpickdt
     */
    public Date getZpickdt() {
        return zpickdt;
    }
    /**
     * @param zpickdt the zpickdt to set
     */
    public void setZpickdt(Date zpickdt) {
        this.zpickdt = zpickdt;
    }
    /**
     * @return the zpicqty
     */
    public String getZpicqty() {
        return zpicqty;
    }
    /**
     * @param zpicqty the zpicqty to set
     */
    public void setZpicqty(String zpicqty) {
        this.zpicqty = zpicqty;
    }
    /**
     * @return the zshipdt
     */
    public Date getZshipdt() {
        return zshipdt;
    }
    /**
     * @param zshipdt the zshipdt to set
     */
    public void setZshipdt(Date zshipdt) {
        this.zshipdt = zshipdt;
    }
    /**
     * @return the zshpqty
     */
    public String getZshpqty() {
        return zshpqty;
    }
    /**
     * @param zshpqty the zshpqty to set
     */
    public void setZshpqty(String zshpqty) {
        this.zshpqty = zshpqty;
    }
    /**
     * @return the zwaerkCust
     */
    public String getZwaerkCust() {
        return zwaerkCust;
    }
    /**
     * @param zwaerkCust the zwaerkCust to set
     */
    public void setZwaerkCust(String zwaerkCust) {
        this.zwaerkCust = zwaerkCust;
    }
    /**
     * @return the esTotal
     */
    public OrderStatusTotalVO getEsTotal() {
        return esTotal;
    }
    /**
     * @param esTotal the esTotal to set
     */
    public void setEsTotal(OrderStatusTotalVO esTotal) {
        this.esTotal = esTotal;
    }
    /**
     * @return the ztotDc
     */
    public String getZtotDc() {
        return ztotDc;
    }
    /**
     * @param ztotDc the ztotDc to set
     */
    public void setZtotDc(String ztotDc) {
        this.ztotDc = ztotDc;
    }
    /**
     * @return the zordnoP
     */
    public String getZordnoP() {
        return zordnoP;
    }
    /**
     * @param zordnoP the zordnoP to set
     */
    public void setZordnoP(String zordnoP) {
        this.zordnoP = zordnoP;
    }
    /**
     * @return the znetpru
     */
    public String getZnetpru() {
        return znetpru;
    }
    /**
     * @param znetpru the znetpru to set
     */
    public void setZnetpru(String znetpru) {
        this.znetpru = znetpru;
    }
    /**
     * @return the waerkUsd
     */
    public String getWaerkUsd() {
        return waerkUsd;
    }
    /**
     * @param waerkUsd the waerkUsd to set
     */
    public void setWaerkUsd(String waerkUsd) {
        this.waerkUsd = waerkUsd;
    }
    /**
     * @return the zpacqtyOn
     */
    public String getZpacqtyOn() {
        return zpacqtyOn;
    }
    /**
     * @param zpacqtyOn the zpacqtyOn to set
     */
    public void setZpacqtyOn(String zpacqtyOn) {
        this.zpacqtyOn = zpacqtyOn;
    }
    /**
     * @return the zonpacdt
     */
    public Date getZonpacdt() {
        return zonpacdt;
    }
    /**
     * @param zonpacdt the zonpacdt to set
     */
    public void setZonpacdt(Date zonpacdt) {
        this.zonpacdt = zonpacdt;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the iHistory
     */
    public String getiHistory() {
        return iHistory;
    }
    /**
     * @param iHistory the iHistory to set
     */
    public void setiHistory(String iHistory) {
        this.iHistory = iHistory;
    }
    /**
     * @return the history
     */
    public String getHistory() {
        return history;
    }
    /**
     * @param history the history to set
     */
    public void setHistory(String history) {
        this.history = history;
    }
    /**
     * @return the vsart
     */
    public String getVsart() {
        return vsart;
    }
    /**
     * @param vsart the vsart to set
     */
    public void setVsart(String vsart) {
        this.vsart = vsart;
    }
    /**
     * @return the bstkd
     */
    public String getBstkd() {
        return bstkd;
    }
    /**
     * @param bstkd the bstkd to set
     */
    public void setBstkd(String bstkd) {
        this.bstkd = bstkd;
    }
    /**
     * @return the zzordln
     */
    public String getZzordln() {
        return zzordln;
    }
    /**
     * @param zzordln the zzordln to set
     */
    public void setZzordln(String zzordln) {
        this.zzordln = zzordln;
    }
    /**
     * @return the zzordls
     */
    public String getZzordls() {
        return zzordls;
    }
    /**
     * @param zzordls the zzordls to set
     */
    public void setZzordls(String zzordls) {
        this.zzordls = zzordls;
    }
    /**
     * @return the iZohpcdEq
     */
    public String getiZohpcdEq() {
        return iZohpcdEq;
    }
    /**
     * @param iZohpcdEq the iZohpcdEq to set
     */
    public void setiZohpcdEq(String iZohpcdEq) {
        this.iZohpcdEq = iZohpcdEq;
    }          
}
