package com.mobis.maps.smpl.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.smpl.service.MapsSmplQmPersnMngrService;
import com.mobis.maps.smpl.vo.MapsSmplQmMngrVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmpQmPersnMngrController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 10.     Sin Sanghwan       최초 생성
 * </pre>
 */
@Controller
public class MapsSmpQmPersnMngrController extends HController {

    @Resource(name = "mapsSmplQmPersnMngrService")
    private MapsSmplQmPersnMngrService mapsSmplQmPersnMngrService;
    
    @RequestMapping(value = "/smpl/sap/selectQmPersnList.do")
    public NexacroResult selectQmPersnList(
            @ParamDataSet(name="dsInput") MapsSmplQmMngrVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
//        paramVO.setUname(loginInfo.getUserId());
//        paramVO.setTzone(loginInfo.getRfcTzone());
//        paramVO.setSpras(loginInfo.getRfcLang());
//        
//        List<MapsSmplQmMngrVO> retList = mapsSmplQmPersnMngrService.rfcSelectQmPersnList(paramVO);
        List<MapsSmplQmMngrVO> retList = mapsSmplQmPersnMngrService.selectQmPersnList(paramVO, loginInfo);
        result.addDataSet("dsOutput", retList);

        return result;
    }
    
    @RequestMapping(value = "/smpl/sap/multiSaveQmPersnList.do")
    public NexacroResult multiSaveQmPersnList(
            @ParamDataSet(name="dsInput") MapsSmplQmMngrVO paramVO
            , @ParamDataSet(name="dsInput2") List<MapsSmplQmMngrVO> paramList
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
//        paramVO.setUname(loginInfo.getUserId());
//        paramVO.setTzone(loginInfo.getRfcTzone());
//        paramVO.setSpras(loginInfo.getRfcLang());
//        
//        Map<String, Object> retMap = mapsSmplQmPersnMngrService.rfcSaveQmPersnList(paramVO, paramList);
//        
//        MapsSmplQmMngrVO retVO = (MapsSmplQmMngrVO)retMap.get("head");
//        @SuppressWarnings("unchecked")
//        List<MapsSmplQmMngrVO> retList = (List<MapsSmplQmMngrVO>)retMap.get("body");
//        
//        result.addDataSet("dsOutput", retVO);
//        result.addDataSet("dsOutput2", retList);
        
        List<MapsSmplQmMngrVO> retList = mapsSmplQmPersnMngrService.multiQmPersn(paramVO, paramList, loginInfo);
        
        result.addDataSet("dsOutput", paramVO);
        result.addDataSet("dsOutput2", retList);

        return result;
    }

}
