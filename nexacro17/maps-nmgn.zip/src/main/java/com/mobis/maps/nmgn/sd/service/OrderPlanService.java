package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.OrderPlanVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderPlanService.java
 * @Description : ZJSDO30220 Parts Order Plan
 * @author 홍민호
 * @since 2020. 2. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 5.     홍민호         최초 생성
 * </pre>
 */

public interface OrderPlanService {
    
    
    /**
     * OrderPlan 조회
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<OrderPlanVO> selectOrderPlan (LoginInfoVO loginVo, OrderPlanVO params) throws Exception;
    

    /**
     * OrderPlan 저장
     *
     * @param loginVo
     * @param params
     * @param paramLst
     * @return
     * @throws Exception
     */
    OrderPlanVO multiSaveOrderPlan (LoginInfoVO loginVo, OrderPlanVO params, List<OrderPlanVO> paramLst) throws Exception;
    
}
