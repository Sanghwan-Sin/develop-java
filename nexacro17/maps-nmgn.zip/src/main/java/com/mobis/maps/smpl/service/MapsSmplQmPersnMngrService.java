package com.mobis.maps.smpl.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.smpl.vo.MapsSmplQmMngrVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsQmPersnMngrService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     Sin Sanghwan       최초 생성
 * </pre>
 */

public interface MapsSmplQmPersnMngrService {
    
    /**
     * Statements
     *
     * @param paramVO
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsSmplQmMngrVO> selectQmPersnList(MapsSmplQmMngrVO paramVO, LoginInfoVO loginInfo) throws Exception;
    
    /**
     * Statements
     *
     * @param paramVO
     * @param paramList
     * @param loginInfo
     * @return
     * @throws Exception
     */
    public List<MapsSmplQmMngrVO> multiQmPersn(MapsSmplQmMngrVO paramVO, List<MapsSmplQmMngrVO> paramList, LoginInfoVO loginInfo) throws Exception;

    /**
     * Statements
     *
     * @param sampleMsgVO
     * @return
     * @throws Exception
     */
    public List<MapsSmplQmMngrVO> selectQmPersnList(MapsSmplQmMngrVO paramVO) throws Exception;
    
    /**
     * Statements
     *
     * @param sampleMsgVO
     * @return
     * @throws Exception
     */
    public Map<String, Object> insertQmPersnList(MapsSmplQmMngrVO paramVO, List<MapsSmplQmMngrVO> paramList) throws Exception;
}
