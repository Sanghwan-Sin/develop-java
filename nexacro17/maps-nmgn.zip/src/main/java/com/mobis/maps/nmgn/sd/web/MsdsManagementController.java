package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.MsdsManagementService;
import com.mobis.maps.nmgn.sd.vo.MsdsManagementVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MsdsManagementController.java
 * @Description : ZJSDR80140 MSDS Management
 * @author 이수지
 * @since 2020. 07. 15.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 07. 15.       이수지                최초 생성
 * </pre>
 */

@Controller
public class MsdsManagementController extends HController {

    @Resource(name = "msdsManagementService")
    private MsdsManagementService msdsManagementService;

    /**
     * selectMsdsManagement
     *
     * @param params
     * @param results
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectMsdsManagement.do")
    public NexacroResult selectMsdsManagement(@ParamDataSet(name="dsInput") MsdsManagementVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MsdsManagementVO> list = msdsManagementService.selectMsdsManagement(loginInfo, params);
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectMsdsManagementExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectMsdsManagementExcelDown.do")
    public NexacroResult selectMsdsManagementExcelDown(@ParamDataSet(name="dsInput") MsdsManagementVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<MsdsManagementVO> list = msdsManagementService.selectMsdsManagement(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }

}
