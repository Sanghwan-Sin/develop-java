package com.mobis.maps.nmgn.cc.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarHdyVO.java
 * @Description : MAPS Holiday 정보 
 *                ZPCA_RFC_CH_HOLIDAY_CALD_INF
 * @author hong.minho
 * @since 2020. 5. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 25.     hong.minho     	최초 생성
 * </pre>
 */

public class CalendarHdyVO extends MapsCommSapRfcIfCommVO {
    
    private String tp; // 구분 : H-Holiday, A-Anniversary

    /** 회사 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_BUKRS" )
    private String iBukrs;
    /** 회계연도 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_GJAHR" )
    private String iGjahr;
    
    
    //-----[ES_INFO] START-----
    /** 회사 코드 */
    @MapsRfcMappper( targetName="ES_INFO", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** 공장 달력 키 */
    @MapsRfcMappper( targetName="ES_INFO", ipttSe="E", fieldKey="FABKL" )
    private String fabkl;
    // -----[ES_INFO] END-----
    
    // -----[IT_HOLIDAY] START-----
    /** 일자 */
    @MapsRfcMappper( targetName="IT_HOLIDAY", ipttSe="E", fieldKey="HOLIDAY" )
    private Date holiday;
    /** 공휴일설명 */
    @MapsRfcMappper( targetName="IT_HOLIDAY", ipttSe="E", fieldKey="HOLIDAY_TXT" )
    private String holidayTxt;
    /** 공휴일,내역 */
    @MapsRfcMappper( targetName="IT_HOLIDAY", ipttSe="E", fieldKey="HOLYDAY_GROUP_TXT" )
    private String holydayGroupTxt;
    // -----[IT_HOLIDAY] END-----
    
    /**
     * @return the iBukrs
     */
    public String getiBukrs() {
        return iBukrs;
    }
    /**
     * @param iBukrs the iBukrs to set
     */
    public void setiBukrs(String iBukrs) {
        this.iBukrs = iBukrs;
    }
    /**
     * @return the iGjahr
     */
    public String getiGjahr() {
        return iGjahr;
    }
    /**
     * @param iGjahr the iGjahr to set
     */
    public void setiGjahr(String iGjahr) {
        this.iGjahr = iGjahr;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the fabkl
     */
    public String getFabkl() {
        return fabkl;
    }
    /**
     * @param fabkl the fabkl to set
     */
    public void setFabkl(String fabkl) {
        this.fabkl = fabkl;
    }
    /**
     * @return the holiday
     */
    public Date getHoliday() {
        return holiday;
    }
    /**
     * @param holiday the holiday to set
     */
    public void setHoliday(Date holiday) {
        this.holiday = holiday;
    }
    /**
     * @return the holidayTxt
     */
    public String getHolidayTxt() {
        return holidayTxt;
    }
    /**
     * @param holidayTxt the holidayTxt to set
     */
    public void setHolidayTxt(String holidayTxt) {
        this.holidayTxt = holidayTxt;
    }
    /**
     * @return the tp
     */
    public String getTp() {
        return tp;
    }
    /**
     * @param tp the tp to set
     */
    public void setTp(String tp) {
        this.tp = tp;
    }
    /**
     * @return the holydayGroupTxt
     */
    public String getHolydayGroupTxt() {
        return holydayGroupTxt;
    }
    /**
     * @param holydayGroupTxt the holydayGroupTxt to set
     */
    public void setHolydayGroupTxt(String holydayGroupTxt) {
        this.holydayGroupTxt = holydayGroupTxt;
    }
}
