package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CertificateInvoiceVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author ChoKyungHo
 * @since 2020. 2. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 12.     ChoKyungHo     	         최초 생성
 * </pre>
 */

public class CertificateInvoiceVO extends MapsCommSapRfcIfCommVO{
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /** DATS 유형 필드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_FROM_DT" )
    private Date iFromDt;
    /** DATS 유형 필드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TO_DT" )
    private Date iToDt;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;

    //-----[ET_LIST] START-----
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SEQ" )
    private Integer seq;
    /** Company Code */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** Company Code */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZDISTCOM" )
    private String zdistcom;
    /** Customer group 1 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /** Dist. Code */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name 1 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** Invoice No. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFCIVNO" )
    private String zfcivno;
    /** Invoice Date */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFCIVDT" )
    private Date zfcivdt;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LGREG" )
    private String lgreg;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZCOONO" )
    private String zcoono;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** Quantity */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LFIMG" )
    private BigDecimal lfimg;
    /** Sales unit */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="VRKME" )
    private String vrkme;
    /** Net Price */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NETPR" )
    private BigDecimal netpr;
    /** Net Value of the Order Item in Document Currency */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NETWR" )
    private BigDecimal netwr;
    /** SD document currency */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** Commodity Code */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CCNGN" )
    private String ccngn;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="RCT" )
    private String rct;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="RVCR" )
    private BigDecimal rvcr;
    /** Country Key */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LAND1" )
    private String land1;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="COFLGR" )
    private String coflgr;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZCONO" )
    private String zcono;
    //-----[ET_LIST] END-----    
    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }
    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }
    /**
     * @return the seq
     */
    public Integer getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the zdistcom
     */
    public String getZdistcom() {
        return zdistcom;
    }
    /**
     * @param zdistcom the zdistcom to set
     */
    public void setZdistcom(String zdistcom) {
        this.zdistcom = zdistcom;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zfcivno
     */
    public String getZfcivno() {
        return zfcivno;
    }
    /**
     * @param zfcivno the zfcivno to set
     */
    public void setZfcivno(String zfcivno) {
        this.zfcivno = zfcivno;
    }
    /**
     * @return the zfcivdt
     */
    public Date getZfcivdt() {
        return zfcivdt;
    }
    /**
     * @param zfcivdt the zfcivdt to set
     */
    public void setZfcivdt(Date zfcivdt) {
        this.zfcivdt = zfcivdt;
    }
    /**
     * @return the lgreg
     */
    public String getLgreg() {
        return lgreg;
    }
    /**
     * @param lgreg the lgreg to set
     */
    public void setLgreg(String lgreg) {
        this.lgreg = lgreg;
    }
    /**
     * @return the zcoono
     */
    public String getZcoono() {
        return zcoono;
    }
    /**
     * @param zcoono the zcoono to set
     */
    public void setZcoono(String zcoono) {
        this.zcoono = zcoono;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the lfimg
     */
    public BigDecimal getLfimg() {
        return lfimg;
    }
    /**
     * @param lfimg the lfimg to set
     */
    public void setLfimg(BigDecimal lfimg) {
        this.lfimg = lfimg;
    }
    /**
     * @return the vrkme
     */
    public String getVrkme() {
        return vrkme;
    }
    /**
     * @param vrkme the vrkme to set
     */
    public void setVrkme(String vrkme) {
        this.vrkme = vrkme;
    }
    /**
     * @return the netpr
     */
    public BigDecimal getNetpr() {
        return netpr;
    }
    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(BigDecimal netpr) {
        this.netpr = netpr;
    }
    /**
     * @return the netwr
     */
    public BigDecimal getNetwr() {
        return netwr;
    }
    /**
     * @param netwr the netwr to set
     */
    public void setNetwr(BigDecimal netwr) {
        this.netwr = netwr;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the ccngn
     */
    public String getCcngn() {
        return ccngn;
    }
    /**
     * @param ccngn the ccngn to set
     */
    public void setCcngn(String ccngn) {
        this.ccngn = ccngn;
    }
    /**
     * @return the rct
     */
    public String getRct() {
        return rct;
    }
    /**
     * @param rct the rct to set
     */
    public void setRct(String rct) {
        this.rct = rct;
    }
    /**
     * @return the rvcr
     */
    public BigDecimal getRvcr() {
        return rvcr;
    }
    /**
     * @param rvcr the rvcr to set
     */
    public void setRvcr(BigDecimal rvcr) {
        this.rvcr = rvcr;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the coflgr
     */
    public String getCoflgr() {
        return coflgr;
    }
    /**
     * @param coflgr the coflgr to set
     */
    public void setCoflgr(String coflgr) {
        this.coflgr = coflgr;
    }
    /**
     * @return the zcono
     */
    public String getZcono() {
        return zcono;
    }
    /**
     * @param zcono the zcono to set
     */
    public void setZcono(String zcono) {
        this.zcono = zcono;
    }
    /**
     * @return the iFromDt
     */
    public Date getiFromDt() {
        return iFromDt;
    }
    /**
     * @param iFromDt the iFromDt to set
     */
    public void setiFromDt(Date iFromDt) {
        this.iFromDt = iFromDt;
    }
    /**
     * @return the iToDt
     */
    public Date getiToDt() {
        return iToDt;
    }
    /**
     * @param iToDt the iToDt to set
     */
    public void setiToDt(Date iToDt) {
        this.iToDt = iToDt;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    
}
