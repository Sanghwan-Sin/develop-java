package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OdrUnprocessedItmLstVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 6.     jiyongdo     	최초 생성
 * </pre>
 */

public class OdrUnprocessedItmLstVO extends MapsCommSapRfcIfCommVO{
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PARTNO" )
    private String iPartno;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAMDCL" )
    private String iZamdcl;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_FR" )
    private String iZorddtFr;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_TO" )
    private String iZorddtTo;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_E" )
    private String iZordnoE;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_P" )
    private String iZordnoP;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;    
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZOHPCD" )
    private String zohpcd;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDDT" )
    private Date zorddt;
    /** Customer group 1 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZCFMDT" )
    private Date zcfmdt;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZRCVDT" )
    private String zrcvdt;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZELAPS" )
    private Integer zelaps;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDLN" )
    private BigDecimal zordln;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZMATNR_INPUT" )
    private String zmatnrInput;
    /** Material Number */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZAMDCL" )
    private String zamdcl;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZAMDCLNM" )
    private String zamdclnm;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZCFMQTY" )
    private String zcfmqty;
    /** Sales unit */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="VRKME" )
    private String vrkme;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZCFAFG" )
    private String zcfafg;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_TOT" )
    private BigDecimal iTotTot;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_UP" )
    private BigDecimal iTotUp;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_AO" )
    private BigDecimal iTotAo;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_NA" )
    private BigDecimal iTotNa;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_NE" )
    private BigDecimal iTotNe;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_NF" )
    private BigDecimal iTotNf;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_CQ" )
    private BigDecimal iTotCq;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_MX" )
    private BigDecimal iTotMx;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_MZ" )
    private BigDecimal iTotMz;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_SI" )
    private BigDecimal iTotSi;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_UD" )
    private BigDecimal iTotUd;
    /**  */
    @MapsRfcMappper( targetName="IT_SUMMARY", ipttSe="E", fieldKey="I_TOT_OT" )
    private BigDecimal iTotOt;
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iPartno
     */
    public String getiPartno() {
        return iPartno;
    }
    /**
     * @param iPartno the iPartno to set
     */
    public void setiPartno(String iPartno) {
        this.iPartno = iPartno;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the iZamdcl
     */
    public String getiZamdcl() {
        return iZamdcl;
    }
    /**
     * @param iZamdcl the iZamdcl to set
     */
    public void setiZamdcl(String iZamdcl) {
        this.iZamdcl = iZamdcl;
    }
    /**
     * @return the iZorddtFr
     */
    public String getiZorddtFr() {
        return iZorddtFr;
    }
    /**
     * @param iZorddtFr the iZorddtFr to set
     */
    public void setiZorddtFr(String iZorddtFr) {
        this.iZorddtFr = iZorddtFr;
    }
    /**
     * @return the iZorddtTo
     */
    public String getiZorddtTo() {
        return iZorddtTo;
    }
    /**
     * @param iZorddtTo the iZorddtTo to set
     */
    public void setiZorddtTo(String iZorddtTo) {
        this.iZorddtTo = iZorddtTo;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the iZordnoP
     */
    public String getiZordnoP() {
        return iZordnoP;
    }
    /**
     * @param iZordnoP the iZordnoP to set
     */
    public void setiZordnoP(String iZordnoP) {
        this.iZordnoP = iZordnoP;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zohpcd
     */
    public String getZohpcd() {
        return zohpcd;
    }
    /**
     * @param zohpcd the zohpcd to set
     */
    public void setZohpcd(String zohpcd) {
        this.zohpcd = zohpcd;
    }
    /**
     * @return the zorddt
     */
    public Date getZorddt() {
        return zorddt;
    }
    /**
     * @param zorddt the zorddt to set
     */
    public void setZorddt(Date zorddt) {
        this.zorddt = zorddt;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the zcfmdt
     */
    public Date getZcfmdt() {
        return zcfmdt;
    }
    /**
     * @param zcfmdt the zcfmdt to set
     */
    public void setZcfmdt(Date zcfmdt) {
        this.zcfmdt = zcfmdt;
    }
    /**
     * @return the zrcvdt
     */
    public String getZrcvdt() {
        return zrcvdt;
    }
    /**
     * @param zrcvdt the zrcvdt to set
     */
    public void setZrcvdt(String zrcvdt) {
        this.zrcvdt = zrcvdt;
    }
    /**
     * @return the zelaps
     */
    public Integer getZelaps() {
        return zelaps;
    }
    /**
     * @param zelaps the zelaps to set
     */
    public void setZelaps(Integer zelaps) {
        this.zelaps = zelaps;
    }
    /**
     * @return the zordln
     */
    public BigDecimal getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(BigDecimal zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zmatnrInput
     */
    public String getZmatnrInput() {
        return zmatnrInput;
    }
    /**
     * @param zmatnrInput the zmatnrInput to set
     */
    public void setZmatnrInput(String zmatnrInput) {
        this.zmatnrInput = zmatnrInput;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zamdcl
     */
    public String getZamdcl() {
        return zamdcl;
    }
    /**
     * @param zamdcl the zamdcl to set
     */
    public void setZamdcl(String zamdcl) {
        this.zamdcl = zamdcl;
    }
    /**
     * @return the zcfmqty
     */
    public String getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(String zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the vrkme
     */
    public String getVrkme() {
        return vrkme;
    }
    /**
     * @param vrkme the vrkme to set
     */
    public void setVrkme(String vrkme) {
        this.vrkme = vrkme;
    }
    /**
     * @return the zcfafg
     */
    public String getZcfafg() {
        return zcfafg;
    }
    /**
     * @param zcfafg the zcfafg to set
     */
    public void setZcfafg(String zcfafg) {
        this.zcfafg = zcfafg;
    }
    /**
     * @return the iTotTot
     */
    public BigDecimal getiTotTot() {
        return iTotTot;
    }
    /**
     * @param iTotTot the iTotTot to set
     */
    public void setiTotTot(BigDecimal iTotTot) {
        this.iTotTot = iTotTot;
    }
    /**
     * @return the iTotUp
     */
    public BigDecimal getiTotUp() {
        return iTotUp;
    }
    /**
     * @param iTotUp the iTotUp to set
     */
    public void setiTotUp(BigDecimal iTotUp) {
        this.iTotUp = iTotUp;
    }
    /**
     * @return the iTotAo
     */
    public BigDecimal getiTotAo() {
        return iTotAo;
    }
    /**
     * @param iTotAo the iTotAo to set
     */
    public void setiTotAo(BigDecimal iTotAo) {
        this.iTotAo = iTotAo;
    }
    /**
     * @return the iTotNa
     */
    public BigDecimal getiTotNa() {
        return iTotNa;
    }
    /**
     * @param iTotNa the iTotNa to set
     */
    public void setiTotNa(BigDecimal iTotNa) {
        this.iTotNa = iTotNa;
    }
    /**
     * @return the iTotNe
     */
    public BigDecimal getiTotNe() {
        return iTotNe;
    }
    /**
     * @param iTotNe the iTotNe to set
     */
    public void setiTotNe(BigDecimal iTotNe) {
        this.iTotNe = iTotNe;
    }
    /**
     * @return the iTotNf
     */
    public BigDecimal getiTotNf() {
        return iTotNf;
    }
    /**
     * @param iTotNf the iTotNf to set
     */
    public void setiTotNf(BigDecimal iTotNf) {
        this.iTotNf = iTotNf;
    }
    /**
     * @return the iTotCq
     */
    public BigDecimal getiTotCq() {
        return iTotCq;
    }
    /**
     * @param iTotCq the iTotCq to set
     */
    public void setiTotCq(BigDecimal iTotCq) {
        this.iTotCq = iTotCq;
    }
    /**
     * @return the iTotMx
     */
    public BigDecimal getiTotMx() {
        return iTotMx;
    }
    /**
     * @param iTotMx the iTotMx to set
     */
    public void setiTotMx(BigDecimal iTotMx) {
        this.iTotMx = iTotMx;
    }
    /**
     * @return the iTotMz
     */
    public BigDecimal getiTotMz() {
        return iTotMz;
    }
    /**
     * @param iTotMz the iTotMz to set
     */
    public void setiTotMz(BigDecimal iTotMz) {
        this.iTotMz = iTotMz;
    }
    /**
     * @return the iTotSi
     */
    public BigDecimal getiTotSi() {
        return iTotSi;
    }
    /**
     * @param iTotSi the iTotSi to set
     */
    public void setiTotSi(BigDecimal iTotSi) {
        this.iTotSi = iTotSi;
    }
    /**
     * @return the iTotUd
     */
    public BigDecimal getiTotUd() {
        return iTotUd;
    }
    /**
     * @param iTotUd the iTotUd to set
     */
    public void setiTotUd(BigDecimal iTotUd) {
        this.iTotUd = iTotUd;
    }
    /**
     * @return the iTotOt
     */
    public BigDecimal getiTotOt() {
        return iTotOt;
    }
    /**
     * @param iTotOt the iTotOt to set
     */
    public void setiTotOt(BigDecimal iTotOt) {
        this.iTotOt = iTotOt;
    }
    /**
     * @return the zamdclnm
     */
    public String getZamdclnm() {
        return zamdclnm;
    }
    /**
     * @param zamdclnm the zamdclnm to set
     */
    public void setZamdclnm(String zamdclnm) {
        this.zamdclnm = zamdclnm;
    }
    
}
