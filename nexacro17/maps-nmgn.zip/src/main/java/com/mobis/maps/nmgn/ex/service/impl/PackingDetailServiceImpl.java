package com.mobis.maps.nmgn.ex.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ex.service.PackingDetailService;
import com.mobis.maps.nmgn.ex.vo.PackingDetailVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingDetailServiceImpl.java
 * @Description : ZJEXR00190 Packing Detail
 * @author 이수지
 * @since 2020. 2. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 10.       이수지      	        최초 생성
 * </pre>
 */

@Service("packingDetailService")
public class PackingDetailServiceImpl extends HService implements PackingDetailService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.ex.service.PackingDetailService#selectPackingDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.PackingDetailVO)
     */
    @Override
    public List<PackingDetailVO> selectPackingDetail(LoginInfoVO loginVo, PackingDetailVO params)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_GET_PACKING_DETAIL;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        
        //*** 조회결과
        List<PackingDetailVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", params, PackingDetailVO.class);
        
        return list;
    }

}
