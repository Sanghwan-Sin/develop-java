package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.BatteryShippingService;
import com.mobis.maps.nmgn.sd.vo.BatteryShippingVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : BatteryShipping.java
 * @Description : Battery Shipping By Air
 * @author 이수지
 * @since 2020. 8. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 10.     이수지             	최초 생성
 * </pre>
 */

@Service("batteryShippingService")
public class BatteryShippingServiceImpl extends HService implements BatteryShippingService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.BatteryShippingService#selectBatteryShipping(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.BatteryShippingVO)
     */
    @Override
    public List<BatteryShippingVO> selectBatteryShipping(LoginInfoVO loginVo, BatteryShippingVO params)
            throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_S_BATTERY;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<BatteryShippingVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", params, BatteryShippingVO.class);
        
        return list;
    }

}
