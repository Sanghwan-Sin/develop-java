package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.AmendCodeVO;
import com.mobis.maps.nmgn.sd.vo.VocRequestVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : VocRequestService.java
 * @Description : VOC Request (HQ)
 * @author hong.minho
 * @since 2020. 6. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 8.     hong.minho     	최초 생성
 * </pre>
 */

public interface VocRequestService {
    
    /**
     * VOC Detail
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    public VocRequestVO selectVOCDetail (LoginInfoVO loginInfo, VocRequestVO params) throws MapsBizException, Exception;
    
    
    /**
     * VOC Save
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    public VocRequestVO multiSaveVOCDetail (LoginInfoVO loginInfo, VocRequestVO params) throws MapsBizException, Exception;


    /**
     * Amend Code List
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    public List<AmendCodeVO> selectAmendCdLst(LoginInfoVO loginInfo, AmendCodeVO params) throws MapsBizException, Exception;
}
