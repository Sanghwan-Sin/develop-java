package com.mobis.maps.smpl.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.util.fmt.DateUtil;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.smpl.service.MapsSmplSapService;
import com.mobis.maps.smpl.vo.MapsSmplMsgVO;
import com.mobis.maps.smpl.vo.MapsSmplSbookVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MineSampleCommonController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 10.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Controller
public class MapsSmplSapController extends HController {

    @Resource(name = "mapsSmplSapService")
    private MapsSmplSapService mapsSmplSapService;


    @RequestMapping(value = "/smpl/sap/selectSbookList.do")
    public NexacroResult selectSbookList(
            @ParamDataSet(name="dsInput") MapsSmplSbookVO sbookVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<MapsSmplSbookVO> lstSbook = mapsSmplSapService.selectSbookList(loginInfo, sbookVO);

        result.addDataSet("dsOutput", lstSbook);

        return result;
    }
    
    /**
     * test2 
     *
     * @param msgVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/smpl/sap/selectMsgList.do")
    public NexacroResult selectMsgList(
            @ParamDataSet(name="dsInput") MapsSmplMsgVO msgVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        msgVO.setUname(loginInfo.getUserId());
        msgVO.setTzone(loginInfo.getRfcTzone());
        msgVO.setSpras(loginInfo.getRfcLang());
        
        List<MapsSmplMsgVO> lstMsg = mapsSmplSapService.selectRfcMsgList(msgVO);

        result.addDataSet("dsOutput", lstMsg);

        return result;
    }

    @RequestMapping(value = "/smpl/sap/selectNewSbookList.do")
    public NexacroResult selectNewSbookList(
            @ParamDataSet(name="dsInput") MapsSmplSbookVO sbookVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        sbookVO.setUname(loginInfo.getUserId());
        sbookVO.setTzone(loginInfo.getRfcTzone());
        sbookVO.setSpras(loginInfo.getRfcLang());
        
        List<MapsSmplSbookVO> lstSbook = mapsSmplSapService.selectRfcSbookList(sbookVO);

        result.addDataSet("dsOutput", lstSbook);

        return result;
    }

    @RequestMapping(value = "/smpl/sap/selectRfcSbookList.do")
    public NexacroResult selectRfcSbookList(
            @ParamDataSet(name="dsInput") MapsSmplSbookVO sbookVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<?> lstSbook = mapsSmplSapService.selectRfcSbookList(loginInfo, sbookVO);

        result.addDataSet("dsOutput", lstSbook);

        return result;
    }

    
    @RequestMapping(value = "/smpl/sap/selectSbookListExcelDown.do")
    public NexacroResult selectSbookListExcelDown(
            @ParamDataSet(name="dsInput") MapsSmplSbookVO sbookVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        sbookVO.setUname(loginInfo.getUserId());
        sbookVO.setTzone(loginInfo.getRfcTzone());
        sbookVO.setSpras(loginInfo.getRfcLang());
        
        List<MapsSmplSbookVO> lstSbook = mapsSmplSapService.selectRfcSbookList(sbookVO);

        result.addDataSet("dsOutput", lstSbook);

        return result;
    }
    
    @RequestMapping(value = "/smpl/sap/selectSbookListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectSbookListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<MapsSmplSbookVO> lstSbook = new ArrayList<MapsSmplSbookVO>();

        List<String[]> rowList = ExcelUtil.importExcelToList(request, 1, 14, 0, "N");
        
        if (rowList != null && !rowList.isEmpty()) {

            for (String[] arrCol : rowList) {

                MapsSmplSbookVO smplSbook = new MapsSmplSbookVO();
                
                smplSbook.setCarrId(arrCol[1]);
                smplSbook.setCarrNm(arrCol[2]);
                smplSbook.setConnId(arrCol[3]);
                smplSbook.setFlDate(DateUtil.stringToDate(arrCol[4]));
                smplSbook.setBookId(arrCol[5]);
                smplSbook.setFlClass(arrCol[6]);
                smplSbook.setAgencyNum(arrCol[5]);
                smplSbook.setLocCurAm(arrCol[8]);
                smplSbook.setLocCurKey(arrCol[9]);
                smplSbook.setMsgType(arrCol[10]);
                smplSbook.setMsgId(arrCol[11]);
                smplSbook.setMsgNo(arrCol[12]);
                smplSbook.setMsg(arrCol[13]);

                lstSbook.add(smplSbook);
            }
        }

        result.addDataSet("dsOutput", lstSbook);

        return result;
    }
    
    /**
     * Test 주석 추가
     *
     * @param sbookVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/smpl/sap/selectSbooNewkList.do")
    public NexacroResult selectSbooNewkList(
            @ParamDataSet(name="dsPgInput") MapsSmplSbookVO sbookVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        sbookVO.setUname(loginInfo.getUserId());
        sbookVO.setTzone(loginInfo.getRfcTzone());
        sbookVO.setSpras(loginInfo.getRfcLang());
        
        List<MapsSmplSbookVO> lstSbook = mapsSmplSapService.selectRfcSbookList(sbookVO);

        result.addDataSet("dsPgOutput", lstSbook);

        return result;
    }
}
