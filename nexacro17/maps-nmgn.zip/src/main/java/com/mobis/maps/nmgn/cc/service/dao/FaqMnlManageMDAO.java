package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FaqMnlManageMDAO.java
 * @Description : FaqMnlManageMDAO
 * @author choi.cheolho
 * @since 2019. 10. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 17.  choi.cheolho         최초 생성
 * </pre>
 */

@Mapper("faqMnlManageMDAO")
public interface FaqMnlManageMDAO {

    /**
     * FAQ List 조회
     *
     * @param paramVO
     * @return
     */
    List<FaqMnlManageVO> selectFaqList(FaqMnlManageVO paramVO);

    /**
     * FAQ 등록
     *
     * @param paramVO
     */
    void insertFaqManage(FaqMnlManageVO paramVO);

    /**
     * FAQ 조회
     *
     * @param paramVO
     * @return
     */
    FaqMnlManageVO selectFaq(FaqMnlManageVO paramVO);

    /**
     * Statements
     *
     * @param paramVO
     * @return
     */
    int updateFaqManage(FaqMnlManageVO paramVO);

    /**
     * Statements
     *
     * @param paramVO
     * @return
     */
    int deleteFaqManage(FaqMnlManageVO paramVO);

    /**
     * Statements
     *
     * @param paramVO
     * @return
     */
    FaqMnlManageVO selectFaqEditList(FaqMnlManageVO paramVO) throws Exception;
}
