package com.mobis.maps.nmgn.sd.vo;


import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ExportCertificateVO.java
 * @Description : ZPSD_NMGN_S_CERTDOWN
 * @author 이수지
 * @since 2020. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *   2020. 8. 20.     이수지     	       최초 생성
 * </pre>
 */

public class ExportCertificateVO extends MapsCommSapRfcIfCommVO {
    
    /** 공급업체 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_LIFNR" )
    private String iLifnr;
    /** 자재번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** 인증/법규 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCERTI_CD" )
    private String iZcertiCd;
    
    /** -----[T_DATA] START----- */
    
    /** Company Code */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCERTI_CD" )
    private String zcertiCd;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCERTI_NAME" )
    private String zcertiName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDOC_CD" )
    private String zdocCd;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDOC_NAME" )
    private String zdocName;
    /** Material Number */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /** Account Number of Vendor or Creditor */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LIFNR" )
    private String lifnr;
    /** Name 3 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="NAME3" )
    private String name3;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZREGISTER_DAT" )
    private Date zregisterDat;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDUE_DAT" )
    private Date zdueDat;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REF_NO" )
    private String refNo;
    
    /** -----[T_DATA] END----- */
    
    
    /**
     * @return the iLifnr
     */
    public String getiLifnr() {
        return iLifnr;
    }
    /**
     * @param iLifnr the iLifnr to set
     */
    public void setiLifnr(String iLifnr) {
        this.iLifnr = iLifnr;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iZcertiCd
     */
    public String getiZcertiCd() {
        return iZcertiCd;
    }
    /**
     * @param iZcertiCd the iZcertiCd to set
     */
    public void setiZcertiCd(String iZcertiCd) {
        this.iZcertiCd = iZcertiCd;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the zcertiCd
     */
    public String getZcertiCd() {
        return zcertiCd;
    }
    /**
     * @param zcertiCd the zcertiCd to set
     */
    public void setZcertiCd(String zcertiCd) {
        this.zcertiCd = zcertiCd;
    }
    /**
     * @return the zcertiName
     */
    public String getZcertiName() {
        return zcertiName;
    }
    /**
     * @param zcertiName the zcertiName to set
     */
    public void setZcertiName(String zcertiName) {
        this.zcertiName = zcertiName;
    }
    /**
     * @return the zdocCd
     */
    public String getZdocCd() {
        return zdocCd;
    }
    /**
     * @param zdocCd the zdocCd to set
     */
    public void setZdocCd(String zdocCd) {
        this.zdocCd = zdocCd;
    }
    /**
     * @return the zdocName
     */
    public String getZdocName() {
        return zdocName;
    }
    /**
     * @param zdocName the zdocName to set
     */
    public void setZdocName(String zdocName) {
        this.zdocName = zdocName;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the name3
     */
    public String getName3() {
        return name3;
    }
    /**
     * @param name3 the name3 to set
     */
    public void setName3(String name3) {
        this.name3 = name3;
    }
    /**
     * @return the zregisterDat
     */
    public Date getZregisterDat() {
        return zregisterDat;
    }
    /**
     * @param zregisterDat the zregisterDat to set
     */
    public void setZregisterDat(Date zregisterDat) {
        this.zregisterDat = zregisterDat;
    }
    /**
     * @return the zdueDat
     */
    public Date getZdueDat() {
        return zdueDat;
    }
    /**
     * @param zdueDat the zdueDat to set
     */
    public void setZdueDat(Date zdueDat) {
        this.zdueDat = zdueDat;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
     
}
