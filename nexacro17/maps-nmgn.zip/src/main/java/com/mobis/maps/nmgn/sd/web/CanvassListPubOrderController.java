package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.CanvassListPubOrderService;
import com.mobis.maps.nmgn.sd.vo.CanvassListPubOrderVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CanvassListPubOrderController.java
 * @Description : ZJSDO30240_P Canvass List for Publication Order
 * @author 이수지
 * @since 2020. 2. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 20.       이수지                최초 생성
 * </pre>
 */

@Controller
public class CanvassListPubOrderController extends HController {

    @Resource(name = "canvassListPubOrderService")
    private CanvassListPubOrderService canvassListPubOrderService;

    /**
     * selectCanvassListPubOrder
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectCanvassListPubOrder.do")
    public NexacroResult selectCanvassListPubOrder(@ParamDataSet(name="dsInput") CanvassListPubOrderVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<CanvassListPubOrderVO> list = canvassListPubOrderService.selectCanvassListPubOrder(loginInfo, params);
        
        for(int i = 0; i < list.size(); i++)
        {
            list.get(i).setQty("");
            list.get(i).setRemark("");
            list.get(i).setiZcanvno(params.getiZcanvno());
        }
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
}
