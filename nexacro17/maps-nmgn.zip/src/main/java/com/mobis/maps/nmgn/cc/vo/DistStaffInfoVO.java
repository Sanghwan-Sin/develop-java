package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistStaffInfoVO.java
 * @Description : 대리점 직원 정보
 * @author DT048782
 * @since 2019. 10. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 17.     DT048782     	최초 생성
 * </pre>
 */

public class DistStaffInfoVO extends PgBascVO {
    
private String agcCode; // 대리점
private String chgFlag; // 직위
private int seqNum = 0;
private String idFlag;
private String agcName; // 대리점명
private String empName; // 담당자
private String empChgFlag; // 담당구분
private String areaFlag; // 수출지역구분
private String oldNewFlag; // O/N
private String telNum; // 전화번호
private String areaCode; // 지역
private String nationCode; // 국가
private String agcFlag; // 대리점구분
private String staffName; // 직원명
private String regionalSpec; // 기술사양지역
private String autoPrcFlag; // Auto
private String faxNum; // Fax번호
private String president; // 대표자명
private String eMailId; // 직원e-mail
private String partManager; // Part Manager
private String address; // 주소
private String eMailRecv;
private String staffPhoto;

// Mailing
private String chk0; // ALL
private String chk1; // Order
private String chk2; // Claim
private String chk3; // Accessory
private String chk4; // Download
private String chk5; // circular Letter
private String chk6; // Payment
private String chk7; // Monthly report
private String chk8; // Voc


// Attach
private String atchSe;
private String atchId;
private String fileNo;
private String filePath;
private String streFileNm;
private String orginlFileNm;

private String uname;



/**
 * @return the agcCode
 */
public String getAgcCode() {
    return agcCode;
}
/**
 * @param agcCode the agcCode to set
 */
public void setAgcCode(String agcCode) {
    this.agcCode = agcCode;
}
/**
 * @return the agcName
 */
public String getAgcName() {
    return agcName;
}
/**
 * @param agcName the agcName to set
 */
public void setAgcName(String agcName) {
    this.agcName = agcName;
}
/**
 * @return the empName
 */
public String getEmpName() {
    return empName;
}
/**
 * @param empName the empName to set
 */
public void setEmpName(String empName) {
    this.empName = empName;
}
/**
 * @return the chgFlag
 */
public String getChgFlag() {
    return chgFlag;
}
/**
 * @param chgFlag the chgFlag to set
 */
public void setChgFlag(String chgFlag) {
    this.chgFlag = chgFlag;
}
/**
 * @return the areaFlag
 */
public String getAreaFlag() {
    return areaFlag;
}
/**
 * @param areaFlag the areaFlag to set
 */
public void setAreaFlag(String areaFlag) {
    this.areaFlag = areaFlag;
}
/**
 * @return the oldNewFlag
 */
public String getOldNewFlag() {
    return oldNewFlag;
}
/**
 * @param oldNewFlag the oldNewFlag to set
 */
public void setOldNewFlag(String oldNewFlag) {
    this.oldNewFlag = oldNewFlag;
}
/**
 * @return the telNum
 */
public String getTelNum() {
    return telNum;
}
/**
 * @param telNum the telNum to set
 */
public void setTelNum(String telNum) {
    this.telNum = telNum;
}
/**
 * @return the areaCode
 */
public String getAreaCode() {
    return areaCode;
}
/**
 * @param areaCode the areaCode to set
 */
public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
}
/**
 * @return the nationCode
 */
public String getNationCode() {
    return nationCode;
}
/**
 * @param nationCode the nationCode to set
 */
public void setNationCode(String nationCode) {
    this.nationCode = nationCode;
}
/**
 * @return the agcFlag
 */
public String getAgcFlag() {
    return agcFlag;
}
/**
 * @param agcFlag the agcFlag to set
 */
public void setAgcFlag(String agcFlag) {
    this.agcFlag = agcFlag;
}
/**
 * @return the staffName
 */
public String getStaffName() {
    return staffName;
}
/**
 * @param staffName the staffName to set
 */
public void setStaffName(String staffName) {
    this.staffName = staffName;
}
/**
 * @return the regionalSpec
 */
public String getRegionalSpec() {
    return regionalSpec;
}
/**
 * @param regionalSpec the regionalSpec to set
 */
public void setRegionalSpec(String regionalSpec) {
    this.regionalSpec = regionalSpec;
}
/**
 * @return the autoPrcFlag
 */
public String getAutoPrcFlag() {
    return autoPrcFlag;
}
/**
 * @param autoPrcFlag the autoPrcFlag to set
 */
public void setAutoPrcFlag(String autoPrcFlag) {
    this.autoPrcFlag = autoPrcFlag;
}
/**
 * @return the faxNum
 */
public String getFaxNum() {
    return faxNum;
}
/**
 * @param faxNum the faxNum to set
 */
public void setFaxNum(String faxNum) {
    this.faxNum = faxNum;
}
/**
 * @return the president
 */
public String getPresident() {
    return president;
}
/**
 * @param president the president to set
 */
public void setPresident(String president) {
    this.president = president;
}
/**
 * @return the eMailId
 */
public String geteMailId() {
    return eMailId;
}
/**
 * @param eMailId the eMailId to set
 */
public void seteMailId(String eMailId) {
    this.eMailId = eMailId;
}
/**
 * @return the partManager
 */
public String getPartManager() {
    return partManager;
}
/**
 * @param partManager the partManager to set
 */
public void setPartManager(String partManager) {
    this.partManager = partManager;
}
/**
 * @return the address
 */
public String getAddress() {
    return address;
}
/**
 * @param address the address to set
 */
public void setAddress(String address) {
    this.address = address;
}
/**
 * @return the seqNum
 */
public int getSeqNum() {
    return seqNum;
}
/**
 * @param seqNum the seqNum to set
 */
public void setSeqNum(int seqNum) {
    this.seqNum = seqNum;
}
/**
 * @return the empChgFlag
 */
public String getEmpChgFlag() {
    return empChgFlag;
}
/**
 * @param empChgFlag the empChgFlag to set
 */
public void setEmpChgFlag(String empChgFlag) {
    this.empChgFlag = empChgFlag;
}
/**
 * @return the idFlag
 */
public String getIdFlag() {
    return idFlag;
}
/**
 * @param idFlag the idFlag to set
 */
public void setIdFlag(String idFlag) {
    this.idFlag = idFlag;
}
/**
 * @return the eMailRecv
 */
public String geteMailRecv() {
    return eMailRecv;
}
/**
 * @param eMailRecv the eMailRecv to set
 */
public void seteMailRecv(String eMailRecv) {
    this.eMailRecv = eMailRecv;
}
/**
 * @return the chk0
 */
public String getChk0() {
    return chk0;
}
/**
 * @param chk0 the chk0 to set
 */
public void setChk0(String chk0) {
    this.chk0 = chk0;
}
/**
 * @return the chk1
 */
public String getChk1() {
    return chk1;
}
/**
 * @param chk1 the chk1 to set
 */
public void setChk1(String chk1) {
    this.chk1 = chk1;
}
/**
 * @return the chk2
 */
public String getChk2() {
    return chk2;
}
/**
 * @param chk2 the chk2 to set
 */
public void setChk2(String chk2) {
    this.chk2 = chk2;
}
/**
 * @return the chk3
 */
public String getChk3() {
    return chk3;
}
/**
 * @param chk3 the chk3 to set
 */
public void setChk3(String chk3) {
    this.chk3 = chk3;
}
/**
 * @return the chk4
 */
public String getChk4() {
    return chk4;
}
/**
 * @param chk4 the chk4 to set
 */
public void setChk4(String chk4) {
    this.chk4 = chk4;
}
/**
 * @return the chk5
 */
public String getChk5() {
    return chk5;
}
/**
 * @param chk5 the chk5 to set
 */
public void setChk5(String chk5) {
    this.chk5 = chk5;
}
/**
 * @return the chk6
 */
public String getChk6() {
    return chk6;
}
/**
 * @param chk6 the chk6 to set
 */
public void setChk6(String chk6) {
    this.chk6 = chk6;
}
/**
 * @return the chk7
 */
public String getChk7() {
    return chk7;
}
/**
 * @param chk7 the chk7 to set
 */
public void setChk7(String chk7) {
    this.chk7 = chk7;
}
/**
 * @return the chk8
 */
public String getChk8() {
    return chk8;
}
/**
 * @param chk8 the chk8 to set
 */
public void setChk8(String chk8) {
    this.chk8 = chk8;
}
/**
 * @return the atchSe
 */
public String getAtchSe() {
    return atchSe;
}
/**
 * @param atchSe the atchSe to set
 */
public void setAtchSe(String atchSe) {
    this.atchSe = atchSe;
}
/**
 * @return the atchId
 */
public String getAtchId() {
    return atchId;
}
/**
 * @param atchId the atchId to set
 */
public void setAtchId(String atchId) {
    this.atchId = atchId;
}
/**
 * @return the fileNo
 */
public String getFileNo() {
    return fileNo;
}
/**
 * @param fileNo the fileNo to set
 */
public void setFileNo(String fileNo) {
    this.fileNo = fileNo;
}
/**
 * @return the filePath
 */
public String getFilePath() {
    return filePath;
}
/**
 * @param filePath the filePath to set
 */
public void setFilePath(String filePath) {
    this.filePath = filePath;
}
/**
 * @return the streFileNm
 */
public String getStreFileNm() {
    return streFileNm;
}
/**
 * @param streFileNm the streFileNm to set
 */
public void setStreFileNm(String streFileNm) {
    this.streFileNm = streFileNm;
}
/**
 * @return the orginlFileNm
 */
public String getOrginlFileNm() {
    return orginlFileNm;
}
/**
 * @param orginlFileNm the orginlFileNm to set
 */
public void setOrginlFileNm(String orginlFileNm) {
    this.orginlFileNm = orginlFileNm;
}
/**
 * @return the uname
 */
public String getUname() {
    return uname;
}
/**
 * @param uname the uname to set
 */
public void setUname(String uname) {
    this.uname = uname;
}
/**
 * @return the staffPhoto
 */
public String getStaffPhoto() {
    return staffPhoto;
}
/**
 * @param staffPhoto the staffPhoto to set
 */
public void setStaffPhoto(String staffPhoto) {
    this.staffPhoto = staffPhoto;
}
    
}
