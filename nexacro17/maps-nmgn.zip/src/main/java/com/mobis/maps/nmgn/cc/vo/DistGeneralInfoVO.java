package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : MapsSmplMngrVO.java
 * @Description : MapsSmplMngrVO
 * @author ha.jeongryeong
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.    ha.jeongryeong     	최초 생성
 *  2020.04. 03.    ChoKyungHo          To-be 테이블 변경
 *               </pre>
 */

public class DistGeneralInfoVO extends MapsCommSapRfcIfCommVO {

    /* 조회조건 */
    private String iVkorg;
    private String iVtweg;
    private String iZlregio;
    private String iZmregio;
    private String iZsregio;
    private String iKvgr1;
    private String iLand1;
    private String iZsacutm;
    private String iZkunam;

    /* 조회결과 */
    private int rnum;
    private String nationName;
    private String distCode;
    private String distName;
    private String address;
    private String person;
    private String position;
    private String tel;
    private String fax;
    private String email;
    
    private String zsalesPer; // 담당직원
    private String zsalesPerNm; // 담당직원명
    
    
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the nationName
     */
    public String getNationName() {
        return nationName;
    }
    /**
     * @param nationName the nationName to set
     */
    public void setNationName(String nationName) {
        this.nationName = nationName;
    }
    /**
     * @return the distCode
     */
    public String getDistCode() {
        return distCode;
    }
    /**
     * @param distCode the distCode to set
     */
    public void setDistCode(String distCode) {
        this.distCode = distCode;
    }
    /**
     * @return the distName
     */
    public String getDistName() {
        return distName;
    }
    /**
     * @param distName the distName to set
     */
    public void setDistName(String distName) {
        this.distName = distName;
    }
    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }
    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }
    /**
     * @return the person
     */
    public String getPerson() {
        return person;
    }
    /**
     * @param person the person to set
     */
    public void setPerson(String person) {
        this.person = person;
    }
    /**
     * @return the position
     */
    public String getPosition() {
        return position;
    }
    /**
     * @param position the position to set
     */
    public void setPosition(String position) {
        this.position = position;
    }
    /**
     * @return the tel
     */
    public String getTel() {
        return tel;
    }
    /**
     * @param tel the tel to set
     */
    public void setTel(String tel) {
        this.tel = tel;
    }
    /**
     * @return the fax
     */
    public String getFax() {
        return fax;
    }
    /**
     * @param fax the fax to set
     */
    public void setFax(String fax) {
        this.fax = fax;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iZlregio
     */
    public String getiZlregio() {
        return iZlregio;
    }
    /**
     * @param iZlregio the iZlregio to set
     */
    public void setiZlregio(String iZlregio) {
        this.iZlregio = iZlregio;
    }
    /**
     * @return the iZmregio
     */
    public String getiZmregio() {
        return iZmregio;
    }
    /**
     * @param iZmregio the iZmregio to set
     */
    public void setiZmregio(String iZmregio) {
        this.iZmregio = iZmregio;
    }
    /**
     * @return the iZsregio
     */
    public String getiZsregio() {
        return iZsregio;
    }
    /**
     * @param iZsregio the iZsregio to set
     */
    public void setiZsregio(String iZsregio) {
        this.iZsregio = iZsregio;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iLand1
     */
    public String getiLand1() {
        return iLand1;
    }
    /**
     * @param iLand1 the iLand1 to set
     */
    public void setiLand1(String iLand1) {
        this.iLand1 = iLand1;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZkunam
     */
    public String getiZkunam() {
        return iZkunam;
    }
    /**
     * @param iZkunam the iZkunam to set
     */
    public void setiZkunam(String iZkunam) {
        this.iZkunam = iZkunam;
    }
    /**
     * @return the zsalesPer
     */
    public String getZsalesPer() {
        return zsalesPer;
    }
    /**
     * @param zsalesPer the zsalesPer to set
     */
    public void setZsalesPer(String zsalesPer) {
        this.zsalesPer = zsalesPer;
    }
    /**
     * @return the zsalesPerNm
     */
    public String getZsalesPerNm() {
        return zsalesPerNm;
    }
    /**
     * @param zsalesPerNm the zsalesPerNm to set
     */
    public void setZsalesPerNm(String zsalesPerNm) {
        this.zsalesPerNm = zsalesPerNm;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
   
}
