package com.mobis.maps.nmgn.cc.vo;

import java.math.BigDecimal;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : KpiInfoOneVO.java
 * @Description : Monthly KPI Report  (단일 row로 변환된 VO)
 * @author hong.minho
 * @since 2020. 11. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 11. 24.     hong.minho     	최초 생성
 * </pre>
 */

public class KpiInfoOneVO extends MapsCommSapRfcIfCommVO {
    
    // *** INPUT
    private String distCd; // dist cd
    private String stdYear; // 년도
    private String vkorg; // 조직코드
    private String vtweg; // 유통경로
    
    
    // *** OUTPUT
    private String lastUpdt; // Update date
    
    private String k01cd     ;
    private BigDecimal k01mon01  ;
    private BigDecimal k01mon02  ;
    private BigDecimal k01mon03  ;
    private BigDecimal k01mon04  ;
    private BigDecimal k01mon05  ;
    private BigDecimal k01mon06  ;
    private BigDecimal k01mon07  ;
    private BigDecimal k01mon08  ;
    private BigDecimal k01mon09  ;
    private BigDecimal k01mon10  ;
    private BigDecimal k01mon11  ;
    private BigDecimal k01mon12  ;
    private BigDecimal k01tot    ;
    private BigDecimal k01avg    ;
    private BigDecimal k01trgt   ;
    
    private String k02cd     ;
    private BigDecimal k02mon01  ;
    private BigDecimal k02mon02  ;
    private BigDecimal k02mon03  ;
    private BigDecimal k02mon04  ;
    private BigDecimal k02mon05  ;
    private BigDecimal k02mon06  ;
    private BigDecimal k02mon07  ;
    private BigDecimal k02mon08  ;
    private BigDecimal k02mon09  ;
    private BigDecimal k02mon10  ;
    private BigDecimal k02mon11  ;
    private BigDecimal k02mon12  ;
    private BigDecimal k02tot    ;
    private BigDecimal k02avg    ;
    private BigDecimal k02trgt   ;
    
    private String k03cd     ;
    private BigDecimal k03mon01  ;
    private BigDecimal k03mon02  ;
    private BigDecimal k03mon03  ;
    private BigDecimal k03mon04  ;
    private BigDecimal k03mon05  ;
    private BigDecimal k03mon06  ;
    private BigDecimal k03mon07  ;
    private BigDecimal k03mon08  ;
    private BigDecimal k03mon09  ;
    private BigDecimal k03mon10  ;
    private BigDecimal k03mon11  ;
    private BigDecimal k03mon12  ;
    private BigDecimal k03tot    ;
    private BigDecimal k03avg    ;
    private BigDecimal k03trgt   ;
    
    private String k04cd     ;
    private BigDecimal k04mon01  ;
    private BigDecimal k04mon02  ;
    private BigDecimal k04mon03  ;
    private BigDecimal k04mon04  ;
    private BigDecimal k04mon05  ;
    private BigDecimal k04mon06  ;
    private BigDecimal k04mon07  ;
    private BigDecimal k04mon08  ;
    private BigDecimal k04mon09  ;
    private BigDecimal k04mon10  ;
    private BigDecimal k04mon11  ;
    private BigDecimal k04mon12  ;
    private BigDecimal k04tot    ;
    private BigDecimal k04avg    ;
    private BigDecimal k04trgt   ;
    
    private String k05cd     ;
    private BigDecimal k05mon01  ;
    private BigDecimal k05mon02  ;
    private BigDecimal k05mon03  ;
    private BigDecimal k05mon04  ;
    private BigDecimal k05mon05  ;
    private BigDecimal k05mon06  ;
    private BigDecimal k05mon07  ;
    private BigDecimal k05mon08  ;
    private BigDecimal k05mon09  ;
    private BigDecimal k05mon10  ;
    private BigDecimal k05mon11  ;
    private BigDecimal k05mon12  ;
    private BigDecimal k05tot    ;
    private BigDecimal k05avg    ;
    private BigDecimal k05trgt   ;
    
    private String k06cd     ;
    private BigDecimal k06mon01  ;
    private BigDecimal k06mon02  ;
    private BigDecimal k06mon03  ;
    private BigDecimal k06mon04  ;
    private BigDecimal k06mon05  ;
    private BigDecimal k06mon06  ;
    private BigDecimal k06mon07  ;
    private BigDecimal k06mon08  ;
    private BigDecimal k06mon09  ;
    private BigDecimal k06mon10  ;
    private BigDecimal k06mon11  ;
    private BigDecimal k06mon12  ;
    private BigDecimal k06tot    ;
    private BigDecimal k06avg    ;
    private BigDecimal k06trgt   ;
    
    private String k07cd     ;
    private BigDecimal k07mon01  ;
    private BigDecimal k07mon02  ;
    private BigDecimal k07mon03  ;
    private BigDecimal k07mon04  ;
    private BigDecimal k07mon05  ;
    private BigDecimal k07mon06  ;
    private BigDecimal k07mon07  ;
    private BigDecimal k07mon08  ;
    private BigDecimal k07mon09  ;
    private BigDecimal k07mon10  ;
    private BigDecimal k07mon11  ;
    private BigDecimal k07mon12  ;
    private BigDecimal k07tot    ;
    private BigDecimal k07avg    ;
    private BigDecimal k07trgt   ;
    
    private String k08cd     ;
    private BigDecimal k08mon01  ;
    private BigDecimal k08mon02  ;
    private BigDecimal k08mon03  ;
    private BigDecimal k08mon04  ;
    private BigDecimal k08mon05  ;
    private BigDecimal k08mon06  ;
    private BigDecimal k08mon07  ;
    private BigDecimal k08mon08  ;
    private BigDecimal k08mon09  ;
    private BigDecimal k08mon10  ;
    private BigDecimal k08mon11  ;
    private BigDecimal k08mon12  ;
    private BigDecimal k08tot    ;
    private BigDecimal k08avg    ;
    private BigDecimal k08trgt   ;
    
    private String k09cd     ;
    private BigDecimal k09mon01  ;
    private BigDecimal k09mon02  ;
    private BigDecimal k09mon03  ;
    private BigDecimal k09mon04  ;
    private BigDecimal k09mon05  ;
    private BigDecimal k09mon06  ;
    private BigDecimal k09mon07  ;
    private BigDecimal k09mon08  ;
    private BigDecimal k09mon09  ;
    private BigDecimal k09mon10  ;
    private BigDecimal k09mon11  ;
    private BigDecimal k09mon12  ;
    private BigDecimal k09tot    ;
    private BigDecimal k09avg    ;
    private BigDecimal k09trgt   ;
    
    private String k10cd     ;
    private BigDecimal k10mon01  ;
    private BigDecimal k10mon02  ;
    private BigDecimal k10mon03  ;
    private BigDecimal k10mon04  ;
    private BigDecimal k10mon05  ;
    private BigDecimal k10mon06  ;
    private BigDecimal k10mon07  ;
    private BigDecimal k10mon08  ;
    private BigDecimal k10mon09  ;
    private BigDecimal k10mon10  ;
    private BigDecimal k10mon11  ;
    private BigDecimal k10mon12  ;
    private BigDecimal k10tot    ;
    private BigDecimal k10avg    ;
    private BigDecimal k10trgt   ;
    
    private String k11cd     ;
    private BigDecimal k11mon01  ;
    private BigDecimal k11mon02  ;
    private BigDecimal k11mon03  ;
    private BigDecimal k11mon04  ;
    private BigDecimal k11mon05  ;
    private BigDecimal k11mon06  ;
    private BigDecimal k11mon07  ;
    private BigDecimal k11mon08  ;
    private BigDecimal k11mon09  ;
    private BigDecimal k11mon10  ;
    private BigDecimal k11mon11  ;
    private BigDecimal k11mon12  ;
    private BigDecimal k11tot    ;
    private BigDecimal k11avg    ;
    private BigDecimal k11trgt   ;
    
    private String k12cd     ;
    private BigDecimal k12mon01  ;
    private BigDecimal k12mon02  ;
    private BigDecimal k12mon03  ;
    private BigDecimal k12mon04  ;
    private BigDecimal k12mon05  ;
    private BigDecimal k12mon06  ;
    private BigDecimal k12mon07  ;
    private BigDecimal k12mon08  ;
    private BigDecimal k12mon09  ;
    private BigDecimal k12mon10  ;
    private BigDecimal k12mon11  ;
    private BigDecimal k12mon12  ;
    private BigDecimal k12tot    ;
    private BigDecimal k12avg    ;
    private BigDecimal k12trgt   ;
    
    private String k13cd     ;
    private BigDecimal k13mon01  ;
    private BigDecimal k13mon02  ;
    private BigDecimal k13mon03  ;
    private BigDecimal k13mon04  ;
    private BigDecimal k13mon05  ;
    private BigDecimal k13mon06  ;
    private BigDecimal k13mon07  ;
    private BigDecimal k13mon08  ;
    private BigDecimal k13mon09  ;
    private BigDecimal k13mon10  ;
    private BigDecimal k13mon11  ;
    private BigDecimal k13mon12  ;
    private BigDecimal k13tot    ;
    private BigDecimal k13avg    ;
    private BigDecimal k13trgt   ;
    
    private String k14cd     ;
    private BigDecimal k14mon01  ;
    private BigDecimal k14mon02  ;
    private BigDecimal k14mon03  ;
    private BigDecimal k14mon04  ;
    private BigDecimal k14mon05  ;
    private BigDecimal k14mon06  ;
    private BigDecimal k14mon07  ;
    private BigDecimal k14mon08  ;
    private BigDecimal k14mon09  ;
    private BigDecimal k14mon10  ;
    private BigDecimal k14mon11  ;
    private BigDecimal k14mon12  ;
    private BigDecimal k14tot    ;
    private BigDecimal k14avg    ;
    private BigDecimal k14trgt   ;
    
    private String k15cd     ;
    private BigDecimal k15mon01  ;
    private BigDecimal k15mon02  ;
    private BigDecimal k15mon03  ;
    private BigDecimal k15mon04  ;
    private BigDecimal k15mon05  ;
    private BigDecimal k15mon06  ;
    private BigDecimal k15mon07  ;
    private BigDecimal k15mon08  ;
    private BigDecimal k15mon09  ;
    private BigDecimal k15mon10  ;
    private BigDecimal k15mon11  ;
    private BigDecimal k15mon12  ;
    private BigDecimal k15tot    ;
    private BigDecimal k15avg    ;
    private BigDecimal k15trgt   ;
    
    private String k16cd     ;
    private BigDecimal k16mon01  ;
    private BigDecimal k16mon02  ;
    private BigDecimal k16mon03  ;
    private BigDecimal k16mon04  ;
    private BigDecimal k16mon05  ;
    private BigDecimal k16mon06  ;
    private BigDecimal k16mon07  ;
    private BigDecimal k16mon08  ;
    private BigDecimal k16mon09  ;
    private BigDecimal k16mon10  ;
    private BigDecimal k16mon11  ;
    private BigDecimal k16mon12  ;
    private BigDecimal k16tot    ;
    private BigDecimal k16avg    ;
    private BigDecimal k16trgt   ;
    
    private String k17cd     ;
    private BigDecimal k17mon01  ;
    private BigDecimal k17mon02  ;
    private BigDecimal k17mon03  ;
    private BigDecimal k17mon04  ;
    private BigDecimal k17mon05  ;
    private BigDecimal k17mon06  ;
    private BigDecimal k17mon07  ;
    private BigDecimal k17mon08  ;
    private BigDecimal k17mon09  ;
    private BigDecimal k17mon10  ;
    private BigDecimal k17mon11  ;
    private BigDecimal k17mon12  ;
    private BigDecimal k17tot    ;
    private BigDecimal k17avg    ;
    private BigDecimal k17trgt   ;
    /**
     * @return the stdYear
     */
    public String getStdYear() {
        return stdYear;
    }
    /**
     * @param stdYear the stdYear to set
     */
    public void setStdYear(String stdYear) {
        this.stdYear = stdYear;
    }
    /**
     * @return the distCd
     */
    public String getDistCd() {
        return distCd;
    }
    /**
     * @param distCd the distCd to set
     */
    public void setDistCd(String distCd) {
        this.distCd = distCd;
    }
    /**
     * @return the lastUpdt
     */
    public String getLastUpdt() {
        return lastUpdt;
    }
    /**
     * @param lastUpdt the lastUpdt to set
     */
    public void setLastUpdt(String lastUpdt) {
        this.lastUpdt = lastUpdt;
    }
    /**
     * @return the k01cd
     */
    public String getK01cd() {
        return k01cd;
    }
    /**
     * @param k01cd the k01cd to set
     */
    public void setK01cd(String k01cd) {
        this.k01cd = k01cd;
    }
    /**
     * @return the k01mon01
     */
    public BigDecimal getK01mon01() {
        return k01mon01;
    }
    /**
     * @param k01mon01 the k01mon01 to set
     */
    public void setK01mon01(BigDecimal k01mon01) {
        this.k01mon01 = k01mon01;
    }
    /**
     * @return the k01mon02
     */
    public BigDecimal getK01mon02() {
        return k01mon02;
    }
    /**
     * @param k01mon02 the k01mon02 to set
     */
    public void setK01mon02(BigDecimal k01mon02) {
        this.k01mon02 = k01mon02;
    }
    /**
     * @return the k01mon03
     */
    public BigDecimal getK01mon03() {
        return k01mon03;
    }
    /**
     * @param k01mon03 the k01mon03 to set
     */
    public void setK01mon03(BigDecimal k01mon03) {
        this.k01mon03 = k01mon03;
    }
    /**
     * @return the k01mon04
     */
    public BigDecimal getK01mon04() {
        return k01mon04;
    }
    /**
     * @param k01mon04 the k01mon04 to set
     */
    public void setK01mon04(BigDecimal k01mon04) {
        this.k01mon04 = k01mon04;
    }
    /**
     * @return the k01mon05
     */
    public BigDecimal getK01mon05() {
        return k01mon05;
    }
    /**
     * @param k01mon05 the k01mon05 to set
     */
    public void setK01mon05(BigDecimal k01mon05) {
        this.k01mon05 = k01mon05;
    }
    /**
     * @return the k01mon06
     */
    public BigDecimal getK01mon06() {
        return k01mon06;
    }
    /**
     * @param k01mon06 the k01mon06 to set
     */
    public void setK01mon06(BigDecimal k01mon06) {
        this.k01mon06 = k01mon06;
    }
    /**
     * @return the k01mon07
     */
    public BigDecimal getK01mon07() {
        return k01mon07;
    }
    /**
     * @param k01mon07 the k01mon07 to set
     */
    public void setK01mon07(BigDecimal k01mon07) {
        this.k01mon07 = k01mon07;
    }
    /**
     * @return the k01mon08
     */
    public BigDecimal getK01mon08() {
        return k01mon08;
    }
    /**
     * @param k01mon08 the k01mon08 to set
     */
    public void setK01mon08(BigDecimal k01mon08) {
        this.k01mon08 = k01mon08;
    }
    /**
     * @return the k01mon09
     */
    public BigDecimal getK01mon09() {
        return k01mon09;
    }
    /**
     * @param k01mon09 the k01mon09 to set
     */
    public void setK01mon09(BigDecimal k01mon09) {
        this.k01mon09 = k01mon09;
    }
    /**
     * @return the k01mon10
     */
    public BigDecimal getK01mon10() {
        return k01mon10;
    }
    /**
     * @param k01mon10 the k01mon10 to set
     */
    public void setK01mon10(BigDecimal k01mon10) {
        this.k01mon10 = k01mon10;
    }
    /**
     * @return the k01mon11
     */
    public BigDecimal getK01mon11() {
        return k01mon11;
    }
    /**
     * @param k01mon11 the k01mon11 to set
     */
    public void setK01mon11(BigDecimal k01mon11) {
        this.k01mon11 = k01mon11;
    }
    /**
     * @return the k01mon12
     */
    public BigDecimal getK01mon12() {
        return k01mon12;
    }
    /**
     * @param k01mon12 the k01mon12 to set
     */
    public void setK01mon12(BigDecimal k01mon12) {
        this.k01mon12 = k01mon12;
    }
    /**
     * @return the k01tot
     */
    public BigDecimal getK01tot() {
        return k01tot;
    }
    /**
     * @param k01tot the k01tot to set
     */
    public void setK01tot(BigDecimal k01tot) {
        this.k01tot = k01tot;
    }
    /**
     * @return the k01avg
     */
    public BigDecimal getK01avg() {
        return k01avg;
    }
    /**
     * @param k01avg the k01avg to set
     */
    public void setK01avg(BigDecimal k01avg) {
        this.k01avg = k01avg;
    }
    /**
     * @return the k01trgt
     */
    public BigDecimal getK01trgt() {
        return k01trgt;
    }
    /**
     * @param k01trgt the k01trgt to set
     */
    public void setK01trgt(BigDecimal k01trgt) {
        this.k01trgt = k01trgt;
    }
    /**
     * @return the k02cd
     */
    public String getK02cd() {
        return k02cd;
    }
    /**
     * @param k02cd the k02cd to set
     */
    public void setK02cd(String k02cd) {
        this.k02cd = k02cd;
    }
    /**
     * @return the k02mon01
     */
    public BigDecimal getK02mon01() {
        return k02mon01;
    }
    /**
     * @param k02mon01 the k02mon01 to set
     */
    public void setK02mon01(BigDecimal k02mon01) {
        this.k02mon01 = k02mon01;
    }
    /**
     * @return the k02mon02
     */
    public BigDecimal getK02mon02() {
        return k02mon02;
    }
    /**
     * @param k02mon02 the k02mon02 to set
     */
    public void setK02mon02(BigDecimal k02mon02) {
        this.k02mon02 = k02mon02;
    }
    /**
     * @return the k02mon03
     */
    public BigDecimal getK02mon03() {
        return k02mon03;
    }
    /**
     * @param k02mon03 the k02mon03 to set
     */
    public void setK02mon03(BigDecimal k02mon03) {
        this.k02mon03 = k02mon03;
    }
    /**
     * @return the k02mon04
     */
    public BigDecimal getK02mon04() {
        return k02mon04;
    }
    /**
     * @param k02mon04 the k02mon04 to set
     */
    public void setK02mon04(BigDecimal k02mon04) {
        this.k02mon04 = k02mon04;
    }
    /**
     * @return the k02mon05
     */
    public BigDecimal getK02mon05() {
        return k02mon05;
    }
    /**
     * @param k02mon05 the k02mon05 to set
     */
    public void setK02mon05(BigDecimal k02mon05) {
        this.k02mon05 = k02mon05;
    }
    /**
     * @return the k02mon06
     */
    public BigDecimal getK02mon06() {
        return k02mon06;
    }
    /**
     * @param k02mon06 the k02mon06 to set
     */
    public void setK02mon06(BigDecimal k02mon06) {
        this.k02mon06 = k02mon06;
    }
    /**
     * @return the k02mon07
     */
    public BigDecimal getK02mon07() {
        return k02mon07;
    }
    /**
     * @param k02mon07 the k02mon07 to set
     */
    public void setK02mon07(BigDecimal k02mon07) {
        this.k02mon07 = k02mon07;
    }
    /**
     * @return the k02mon08
     */
    public BigDecimal getK02mon08() {
        return k02mon08;
    }
    /**
     * @param k02mon08 the k02mon08 to set
     */
    public void setK02mon08(BigDecimal k02mon08) {
        this.k02mon08 = k02mon08;
    }
    /**
     * @return the k02mon09
     */
    public BigDecimal getK02mon09() {
        return k02mon09;
    }
    /**
     * @param k02mon09 the k02mon09 to set
     */
    public void setK02mon09(BigDecimal k02mon09) {
        this.k02mon09 = k02mon09;
    }
    /**
     * @return the k02mon10
     */
    public BigDecimal getK02mon10() {
        return k02mon10;
    }
    /**
     * @param k02mon10 the k02mon10 to set
     */
    public void setK02mon10(BigDecimal k02mon10) {
        this.k02mon10 = k02mon10;
    }
    /**
     * @return the k02mon11
     */
    public BigDecimal getK02mon11() {
        return k02mon11;
    }
    /**
     * @param k02mon11 the k02mon11 to set
     */
    public void setK02mon11(BigDecimal k02mon11) {
        this.k02mon11 = k02mon11;
    }
    /**
     * @return the k02mon12
     */
    public BigDecimal getK02mon12() {
        return k02mon12;
    }
    /**
     * @param k02mon12 the k02mon12 to set
     */
    public void setK02mon12(BigDecimal k02mon12) {
        this.k02mon12 = k02mon12;
    }
    /**
     * @return the k02tot
     */
    public BigDecimal getK02tot() {
        return k02tot;
    }
    /**
     * @param k02tot the k02tot to set
     */
    public void setK02tot(BigDecimal k02tot) {
        this.k02tot = k02tot;
    }
    /**
     * @return the k02avg
     */
    public BigDecimal getK02avg() {
        return k02avg;
    }
    /**
     * @param k02avg the k02avg to set
     */
    public void setK02avg(BigDecimal k02avg) {
        this.k02avg = k02avg;
    }
    /**
     * @return the k02trgt
     */
    public BigDecimal getK02trgt() {
        return k02trgt;
    }
    /**
     * @param k02trgt the k02trgt to set
     */
    public void setK02trgt(BigDecimal k02trgt) {
        this.k02trgt = k02trgt;
    }
    /**
     * @return the k03cd
     */
    public String getK03cd() {
        return k03cd;
    }
    /**
     * @param k03cd the k03cd to set
     */
    public void setK03cd(String k03cd) {
        this.k03cd = k03cd;
    }
    /**
     * @return the k03mon01
     */
    public BigDecimal getK03mon01() {
        return k03mon01;
    }
    /**
     * @param k03mon01 the k03mon01 to set
     */
    public void setK03mon01(BigDecimal k03mon01) {
        this.k03mon01 = k03mon01;
    }
    /**
     * @return the k03mon02
     */
    public BigDecimal getK03mon02() {
        return k03mon02;
    }
    /**
     * @param k03mon02 the k03mon02 to set
     */
    public void setK03mon02(BigDecimal k03mon02) {
        this.k03mon02 = k03mon02;
    }
    /**
     * @return the k03mon03
     */
    public BigDecimal getK03mon03() {
        return k03mon03;
    }
    /**
     * @param k03mon03 the k03mon03 to set
     */
    public void setK03mon03(BigDecimal k03mon03) {
        this.k03mon03 = k03mon03;
    }
    /**
     * @return the k03mon04
     */
    public BigDecimal getK03mon04() {
        return k03mon04;
    }
    /**
     * @param k03mon04 the k03mon04 to set
     */
    public void setK03mon04(BigDecimal k03mon04) {
        this.k03mon04 = k03mon04;
    }
    /**
     * @return the k03mon05
     */
    public BigDecimal getK03mon05() {
        return k03mon05;
    }
    /**
     * @param k03mon05 the k03mon05 to set
     */
    public void setK03mon05(BigDecimal k03mon05) {
        this.k03mon05 = k03mon05;
    }
    /**
     * @return the k03mon06
     */
    public BigDecimal getK03mon06() {
        return k03mon06;
    }
    /**
     * @param k03mon06 the k03mon06 to set
     */
    public void setK03mon06(BigDecimal k03mon06) {
        this.k03mon06 = k03mon06;
    }
    /**
     * @return the k03mon07
     */
    public BigDecimal getK03mon07() {
        return k03mon07;
    }
    /**
     * @param k03mon07 the k03mon07 to set
     */
    public void setK03mon07(BigDecimal k03mon07) {
        this.k03mon07 = k03mon07;
    }
    /**
     * @return the k03mon08
     */
    public BigDecimal getK03mon08() {
        return k03mon08;
    }
    /**
     * @param k03mon08 the k03mon08 to set
     */
    public void setK03mon08(BigDecimal k03mon08) {
        this.k03mon08 = k03mon08;
    }
    /**
     * @return the k03mon09
     */
    public BigDecimal getK03mon09() {
        return k03mon09;
    }
    /**
     * @param k03mon09 the k03mon09 to set
     */
    public void setK03mon09(BigDecimal k03mon09) {
        this.k03mon09 = k03mon09;
    }
    /**
     * @return the k03mon10
     */
    public BigDecimal getK03mon10() {
        return k03mon10;
    }
    /**
     * @param k03mon10 the k03mon10 to set
     */
    public void setK03mon10(BigDecimal k03mon10) {
        this.k03mon10 = k03mon10;
    }
    /**
     * @return the k03mon11
     */
    public BigDecimal getK03mon11() {
        return k03mon11;
    }
    /**
     * @param k03mon11 the k03mon11 to set
     */
    public void setK03mon11(BigDecimal k03mon11) {
        this.k03mon11 = k03mon11;
    }
    /**
     * @return the k03mon12
     */
    public BigDecimal getK03mon12() {
        return k03mon12;
    }
    /**
     * @param k03mon12 the k03mon12 to set
     */
    public void setK03mon12(BigDecimal k03mon12) {
        this.k03mon12 = k03mon12;
    }
    /**
     * @return the k03tot
     */
    public BigDecimal getK03tot() {
        return k03tot;
    }
    /**
     * @param k03tot the k03tot to set
     */
    public void setK03tot(BigDecimal k03tot) {
        this.k03tot = k03tot;
    }
    /**
     * @return the k03avg
     */
    public BigDecimal getK03avg() {
        return k03avg;
    }
    /**
     * @param k03avg the k03avg to set
     */
    public void setK03avg(BigDecimal k03avg) {
        this.k03avg = k03avg;
    }
    /**
     * @return the k03trgt
     */
    public BigDecimal getK03trgt() {
        return k03trgt;
    }
    /**
     * @param k03trgt the k03trgt to set
     */
    public void setK03trgt(BigDecimal k03trgt) {
        this.k03trgt = k03trgt;
    }
    /**
     * @return the k04cd
     */
    public String getK04cd() {
        return k04cd;
    }
    /**
     * @param k04cd the k04cd to set
     */
    public void setK04cd(String k04cd) {
        this.k04cd = k04cd;
    }
    /**
     * @return the k04mon01
     */
    public BigDecimal getK04mon01() {
        return k04mon01;
    }
    /**
     * @param k04mon01 the k04mon01 to set
     */
    public void setK04mon01(BigDecimal k04mon01) {
        this.k04mon01 = k04mon01;
    }
    /**
     * @return the k04mon02
     */
    public BigDecimal getK04mon02() {
        return k04mon02;
    }
    /**
     * @param k04mon02 the k04mon02 to set
     */
    public void setK04mon02(BigDecimal k04mon02) {
        this.k04mon02 = k04mon02;
    }
    /**
     * @return the k04mon03
     */
    public BigDecimal getK04mon03() {
        return k04mon03;
    }
    /**
     * @param k04mon03 the k04mon03 to set
     */
    public void setK04mon03(BigDecimal k04mon03) {
        this.k04mon03 = k04mon03;
    }
    /**
     * @return the k04mon04
     */
    public BigDecimal getK04mon04() {
        return k04mon04;
    }
    /**
     * @param k04mon04 the k04mon04 to set
     */
    public void setK04mon04(BigDecimal k04mon04) {
        this.k04mon04 = k04mon04;
    }
    /**
     * @return the k04mon05
     */
    public BigDecimal getK04mon05() {
        return k04mon05;
    }
    /**
     * @param k04mon05 the k04mon05 to set
     */
    public void setK04mon05(BigDecimal k04mon05) {
        this.k04mon05 = k04mon05;
    }
    /**
     * @return the k04mon06
     */
    public BigDecimal getK04mon06() {
        return k04mon06;
    }
    /**
     * @param k04mon06 the k04mon06 to set
     */
    public void setK04mon06(BigDecimal k04mon06) {
        this.k04mon06 = k04mon06;
    }
    /**
     * @return the k04mon07
     */
    public BigDecimal getK04mon07() {
        return k04mon07;
    }
    /**
     * @param k04mon07 the k04mon07 to set
     */
    public void setK04mon07(BigDecimal k04mon07) {
        this.k04mon07 = k04mon07;
    }
    /**
     * @return the k04mon08
     */
    public BigDecimal getK04mon08() {
        return k04mon08;
    }
    /**
     * @param k04mon08 the k04mon08 to set
     */
    public void setK04mon08(BigDecimal k04mon08) {
        this.k04mon08 = k04mon08;
    }
    /**
     * @return the k04mon09
     */
    public BigDecimal getK04mon09() {
        return k04mon09;
    }
    /**
     * @param k04mon09 the k04mon09 to set
     */
    public void setK04mon09(BigDecimal k04mon09) {
        this.k04mon09 = k04mon09;
    }
    /**
     * @return the k04mon10
     */
    public BigDecimal getK04mon10() {
        return k04mon10;
    }
    /**
     * @param k04mon10 the k04mon10 to set
     */
    public void setK04mon10(BigDecimal k04mon10) {
        this.k04mon10 = k04mon10;
    }
    /**
     * @return the k04mon11
     */
    public BigDecimal getK04mon11() {
        return k04mon11;
    }
    /**
     * @param k04mon11 the k04mon11 to set
     */
    public void setK04mon11(BigDecimal k04mon11) {
        this.k04mon11 = k04mon11;
    }
    /**
     * @return the k04mon12
     */
    public BigDecimal getK04mon12() {
        return k04mon12;
    }
    /**
     * @param k04mon12 the k04mon12 to set
     */
    public void setK04mon12(BigDecimal k04mon12) {
        this.k04mon12 = k04mon12;
    }
    /**
     * @return the k04tot
     */
    public BigDecimal getK04tot() {
        return k04tot;
    }
    /**
     * @param k04tot the k04tot to set
     */
    public void setK04tot(BigDecimal k04tot) {
        this.k04tot = k04tot;
    }
    /**
     * @return the k04avg
     */
    public BigDecimal getK04avg() {
        return k04avg;
    }
    /**
     * @param k04avg the k04avg to set
     */
    public void setK04avg(BigDecimal k04avg) {
        this.k04avg = k04avg;
    }
    /**
     * @return the k04trgt
     */
    public BigDecimal getK04trgt() {
        return k04trgt;
    }
    /**
     * @param k04trgt the k04trgt to set
     */
    public void setK04trgt(BigDecimal k04trgt) {
        this.k04trgt = k04trgt;
    }
    /**
     * @return the k05cd
     */
    public String getK05cd() {
        return k05cd;
    }
    /**
     * @param k05cd the k05cd to set
     */
    public void setK05cd(String k05cd) {
        this.k05cd = k05cd;
    }
    /**
     * @return the k05mon01
     */
    public BigDecimal getK05mon01() {
        return k05mon01;
    }
    /**
     * @param k05mon01 the k05mon01 to set
     */
    public void setK05mon01(BigDecimal k05mon01) {
        this.k05mon01 = k05mon01;
    }
    /**
     * @return the k05mon02
     */
    public BigDecimal getK05mon02() {
        return k05mon02;
    }
    /**
     * @param k05mon02 the k05mon02 to set
     */
    public void setK05mon02(BigDecimal k05mon02) {
        this.k05mon02 = k05mon02;
    }
    /**
     * @return the k05mon03
     */
    public BigDecimal getK05mon03() {
        return k05mon03;
    }
    /**
     * @param k05mon03 the k05mon03 to set
     */
    public void setK05mon03(BigDecimal k05mon03) {
        this.k05mon03 = k05mon03;
    }
    /**
     * @return the k05mon04
     */
    public BigDecimal getK05mon04() {
        return k05mon04;
    }
    /**
     * @param k05mon04 the k05mon04 to set
     */
    public void setK05mon04(BigDecimal k05mon04) {
        this.k05mon04 = k05mon04;
    }
    /**
     * @return the k05mon05
     */
    public BigDecimal getK05mon05() {
        return k05mon05;
    }
    /**
     * @param k05mon05 the k05mon05 to set
     */
    public void setK05mon05(BigDecimal k05mon05) {
        this.k05mon05 = k05mon05;
    }
    /**
     * @return the k05mon06
     */
    public BigDecimal getK05mon06() {
        return k05mon06;
    }
    /**
     * @param k05mon06 the k05mon06 to set
     */
    public void setK05mon06(BigDecimal k05mon06) {
        this.k05mon06 = k05mon06;
    }
    /**
     * @return the k05mon07
     */
    public BigDecimal getK05mon07() {
        return k05mon07;
    }
    /**
     * @param k05mon07 the k05mon07 to set
     */
    public void setK05mon07(BigDecimal k05mon07) {
        this.k05mon07 = k05mon07;
    }
    /**
     * @return the k05mon08
     */
    public BigDecimal getK05mon08() {
        return k05mon08;
    }
    /**
     * @param k05mon08 the k05mon08 to set
     */
    public void setK05mon08(BigDecimal k05mon08) {
        this.k05mon08 = k05mon08;
    }
    /**
     * @return the k05mon09
     */
    public BigDecimal getK05mon09() {
        return k05mon09;
    }
    /**
     * @param k05mon09 the k05mon09 to set
     */
    public void setK05mon09(BigDecimal k05mon09) {
        this.k05mon09 = k05mon09;
    }
    /**
     * @return the k05mon10
     */
    public BigDecimal getK05mon10() {
        return k05mon10;
    }
    /**
     * @param k05mon10 the k05mon10 to set
     */
    public void setK05mon10(BigDecimal k05mon10) {
        this.k05mon10 = k05mon10;
    }
    /**
     * @return the k05mon11
     */
    public BigDecimal getK05mon11() {
        return k05mon11;
    }
    /**
     * @param k05mon11 the k05mon11 to set
     */
    public void setK05mon11(BigDecimal k05mon11) {
        this.k05mon11 = k05mon11;
    }
    /**
     * @return the k05mon12
     */
    public BigDecimal getK05mon12() {
        return k05mon12;
    }
    /**
     * @param k05mon12 the k05mon12 to set
     */
    public void setK05mon12(BigDecimal k05mon12) {
        this.k05mon12 = k05mon12;
    }
    /**
     * @return the k05tot
     */
    public BigDecimal getK05tot() {
        return k05tot;
    }
    /**
     * @param k05tot the k05tot to set
     */
    public void setK05tot(BigDecimal k05tot) {
        this.k05tot = k05tot;
    }
    /**
     * @return the k05avg
     */
    public BigDecimal getK05avg() {
        return k05avg;
    }
    /**
     * @param k05avg the k05avg to set
     */
    public void setK05avg(BigDecimal k05avg) {
        this.k05avg = k05avg;
    }
    /**
     * @return the k05trgt
     */
    public BigDecimal getK05trgt() {
        return k05trgt;
    }
    /**
     * @param k05trgt the k05trgt to set
     */
    public void setK05trgt(BigDecimal k05trgt) {
        this.k05trgt = k05trgt;
    }
    /**
     * @return the k06cd
     */
    public String getK06cd() {
        return k06cd;
    }
    /**
     * @param k06cd the k06cd to set
     */
    public void setK06cd(String k06cd) {
        this.k06cd = k06cd;
    }
    /**
     * @return the k06mon01
     */
    public BigDecimal getK06mon01() {
        return k06mon01;
    }
    /**
     * @param k06mon01 the k06mon01 to set
     */
    public void setK06mon01(BigDecimal k06mon01) {
        this.k06mon01 = k06mon01;
    }
    /**
     * @return the k06mon02
     */
    public BigDecimal getK06mon02() {
        return k06mon02;
    }
    /**
     * @param k06mon02 the k06mon02 to set
     */
    public void setK06mon02(BigDecimal k06mon02) {
        this.k06mon02 = k06mon02;
    }
    /**
     * @return the k06mon03
     */
    public BigDecimal getK06mon03() {
        return k06mon03;
    }
    /**
     * @param k06mon03 the k06mon03 to set
     */
    public void setK06mon03(BigDecimal k06mon03) {
        this.k06mon03 = k06mon03;
    }
    /**
     * @return the k06mon04
     */
    public BigDecimal getK06mon04() {
        return k06mon04;
    }
    /**
     * @param k06mon04 the k06mon04 to set
     */
    public void setK06mon04(BigDecimal k06mon04) {
        this.k06mon04 = k06mon04;
    }
    /**
     * @return the k06mon05
     */
    public BigDecimal getK06mon05() {
        return k06mon05;
    }
    /**
     * @param k06mon05 the k06mon05 to set
     */
    public void setK06mon05(BigDecimal k06mon05) {
        this.k06mon05 = k06mon05;
    }
    /**
     * @return the k06mon06
     */
    public BigDecimal getK06mon06() {
        return k06mon06;
    }
    /**
     * @param k06mon06 the k06mon06 to set
     */
    public void setK06mon06(BigDecimal k06mon06) {
        this.k06mon06 = k06mon06;
    }
    /**
     * @return the k06mon07
     */
    public BigDecimal getK06mon07() {
        return k06mon07;
    }
    /**
     * @param k06mon07 the k06mon07 to set
     */
    public void setK06mon07(BigDecimal k06mon07) {
        this.k06mon07 = k06mon07;
    }
    /**
     * @return the k06mon08
     */
    public BigDecimal getK06mon08() {
        return k06mon08;
    }
    /**
     * @param k06mon08 the k06mon08 to set
     */
    public void setK06mon08(BigDecimal k06mon08) {
        this.k06mon08 = k06mon08;
    }
    /**
     * @return the k06mon09
     */
    public BigDecimal getK06mon09() {
        return k06mon09;
    }
    /**
     * @param k06mon09 the k06mon09 to set
     */
    public void setK06mon09(BigDecimal k06mon09) {
        this.k06mon09 = k06mon09;
    }
    /**
     * @return the k06mon10
     */
    public BigDecimal getK06mon10() {
        return k06mon10;
    }
    /**
     * @param k06mon10 the k06mon10 to set
     */
    public void setK06mon10(BigDecimal k06mon10) {
        this.k06mon10 = k06mon10;
    }
    /**
     * @return the k06mon11
     */
    public BigDecimal getK06mon11() {
        return k06mon11;
    }
    /**
     * @param k06mon11 the k06mon11 to set
     */
    public void setK06mon11(BigDecimal k06mon11) {
        this.k06mon11 = k06mon11;
    }
    /**
     * @return the k06mon12
     */
    public BigDecimal getK06mon12() {
        return k06mon12;
    }
    /**
     * @param k06mon12 the k06mon12 to set
     */
    public void setK06mon12(BigDecimal k06mon12) {
        this.k06mon12 = k06mon12;
    }
    /**
     * @return the k06tot
     */
    public BigDecimal getK06tot() {
        return k06tot;
    }
    /**
     * @param k06tot the k06tot to set
     */
    public void setK06tot(BigDecimal k06tot) {
        this.k06tot = k06tot;
    }
    /**
     * @return the k06avg
     */
    public BigDecimal getK06avg() {
        return k06avg;
    }
    /**
     * @param k06avg the k06avg to set
     */
    public void setK06avg(BigDecimal k06avg) {
        this.k06avg = k06avg;
    }
    /**
     * @return the k06trgt
     */
    public BigDecimal getK06trgt() {
        return k06trgt;
    }
    /**
     * @param k06trgt the k06trgt to set
     */
    public void setK06trgt(BigDecimal k06trgt) {
        this.k06trgt = k06trgt;
    }
    /**
     * @return the k07cd
     */
    public String getK07cd() {
        return k07cd;
    }
    /**
     * @param k07cd the k07cd to set
     */
    public void setK07cd(String k07cd) {
        this.k07cd = k07cd;
    }
    /**
     * @return the k07mon01
     */
    public BigDecimal getK07mon01() {
        return k07mon01;
    }
    /**
     * @param k07mon01 the k07mon01 to set
     */
    public void setK07mon01(BigDecimal k07mon01) {
        this.k07mon01 = k07mon01;
    }
    /**
     * @return the k07mon02
     */
    public BigDecimal getK07mon02() {
        return k07mon02;
    }
    /**
     * @param k07mon02 the k07mon02 to set
     */
    public void setK07mon02(BigDecimal k07mon02) {
        this.k07mon02 = k07mon02;
    }
    /**
     * @return the k07mon03
     */
    public BigDecimal getK07mon03() {
        return k07mon03;
    }
    /**
     * @param k07mon03 the k07mon03 to set
     */
    public void setK07mon03(BigDecimal k07mon03) {
        this.k07mon03 = k07mon03;
    }
    /**
     * @return the k07mon04
     */
    public BigDecimal getK07mon04() {
        return k07mon04;
    }
    /**
     * @param k07mon04 the k07mon04 to set
     */
    public void setK07mon04(BigDecimal k07mon04) {
        this.k07mon04 = k07mon04;
    }
    /**
     * @return the k07mon05
     */
    public BigDecimal getK07mon05() {
        return k07mon05;
    }
    /**
     * @param k07mon05 the k07mon05 to set
     */
    public void setK07mon05(BigDecimal k07mon05) {
        this.k07mon05 = k07mon05;
    }
    /**
     * @return the k07mon06
     */
    public BigDecimal getK07mon06() {
        return k07mon06;
    }
    /**
     * @param k07mon06 the k07mon06 to set
     */
    public void setK07mon06(BigDecimal k07mon06) {
        this.k07mon06 = k07mon06;
    }
    /**
     * @return the k07mon07
     */
    public BigDecimal getK07mon07() {
        return k07mon07;
    }
    /**
     * @param k07mon07 the k07mon07 to set
     */
    public void setK07mon07(BigDecimal k07mon07) {
        this.k07mon07 = k07mon07;
    }
    /**
     * @return the k07mon08
     */
    public BigDecimal getK07mon08() {
        return k07mon08;
    }
    /**
     * @param k07mon08 the k07mon08 to set
     */
    public void setK07mon08(BigDecimal k07mon08) {
        this.k07mon08 = k07mon08;
    }
    /**
     * @return the k07mon09
     */
    public BigDecimal getK07mon09() {
        return k07mon09;
    }
    /**
     * @param k07mon09 the k07mon09 to set
     */
    public void setK07mon09(BigDecimal k07mon09) {
        this.k07mon09 = k07mon09;
    }
    /**
     * @return the k07mon10
     */
    public BigDecimal getK07mon10() {
        return k07mon10;
    }
    /**
     * @param k07mon10 the k07mon10 to set
     */
    public void setK07mon10(BigDecimal k07mon10) {
        this.k07mon10 = k07mon10;
    }
    /**
     * @return the k07mon11
     */
    public BigDecimal getK07mon11() {
        return k07mon11;
    }
    /**
     * @param k07mon11 the k07mon11 to set
     */
    public void setK07mon11(BigDecimal k07mon11) {
        this.k07mon11 = k07mon11;
    }
    /**
     * @return the k07mon12
     */
    public BigDecimal getK07mon12() {
        return k07mon12;
    }
    /**
     * @param k07mon12 the k07mon12 to set
     */
    public void setK07mon12(BigDecimal k07mon12) {
        this.k07mon12 = k07mon12;
    }
    /**
     * @return the k07tot
     */
    public BigDecimal getK07tot() {
        return k07tot;
    }
    /**
     * @param k07tot the k07tot to set
     */
    public void setK07tot(BigDecimal k07tot) {
        this.k07tot = k07tot;
    }
    /**
     * @return the k07avg
     */
    public BigDecimal getK07avg() {
        return k07avg;
    }
    /**
     * @param k07avg the k07avg to set
     */
    public void setK07avg(BigDecimal k07avg) {
        this.k07avg = k07avg;
    }
    /**
     * @return the k07trgt
     */
    public BigDecimal getK07trgt() {
        return k07trgt;
    }
    /**
     * @param k07trgt the k07trgt to set
     */
    public void setK07trgt(BigDecimal k07trgt) {
        this.k07trgt = k07trgt;
    }
    /**
     * @return the k08cd
     */
    public String getK08cd() {
        return k08cd;
    }
    /**
     * @param k08cd the k08cd to set
     */
    public void setK08cd(String k08cd) {
        this.k08cd = k08cd;
    }
    /**
     * @return the k08mon01
     */
    public BigDecimal getK08mon01() {
        return k08mon01;
    }
    /**
     * @param k08mon01 the k08mon01 to set
     */
    public void setK08mon01(BigDecimal k08mon01) {
        this.k08mon01 = k08mon01;
    }
    /**
     * @return the k08mon02
     */
    public BigDecimal getK08mon02() {
        return k08mon02;
    }
    /**
     * @param k08mon02 the k08mon02 to set
     */
    public void setK08mon02(BigDecimal k08mon02) {
        this.k08mon02 = k08mon02;
    }
    /**
     * @return the k08mon03
     */
    public BigDecimal getK08mon03() {
        return k08mon03;
    }
    /**
     * @param k08mon03 the k08mon03 to set
     */
    public void setK08mon03(BigDecimal k08mon03) {
        this.k08mon03 = k08mon03;
    }
    /**
     * @return the k08mon04
     */
    public BigDecimal getK08mon04() {
        return k08mon04;
    }
    /**
     * @param k08mon04 the k08mon04 to set
     */
    public void setK08mon04(BigDecimal k08mon04) {
        this.k08mon04 = k08mon04;
    }
    /**
     * @return the k08mon05
     */
    public BigDecimal getK08mon05() {
        return k08mon05;
    }
    /**
     * @param k08mon05 the k08mon05 to set
     */
    public void setK08mon05(BigDecimal k08mon05) {
        this.k08mon05 = k08mon05;
    }
    /**
     * @return the k08mon06
     */
    public BigDecimal getK08mon06() {
        return k08mon06;
    }
    /**
     * @param k08mon06 the k08mon06 to set
     */
    public void setK08mon06(BigDecimal k08mon06) {
        this.k08mon06 = k08mon06;
    }
    /**
     * @return the k08mon07
     */
    public BigDecimal getK08mon07() {
        return k08mon07;
    }
    /**
     * @param k08mon07 the k08mon07 to set
     */
    public void setK08mon07(BigDecimal k08mon07) {
        this.k08mon07 = k08mon07;
    }
    /**
     * @return the k08mon08
     */
    public BigDecimal getK08mon08() {
        return k08mon08;
    }
    /**
     * @param k08mon08 the k08mon08 to set
     */
    public void setK08mon08(BigDecimal k08mon08) {
        this.k08mon08 = k08mon08;
    }
    /**
     * @return the k08mon09
     */
    public BigDecimal getK08mon09() {
        return k08mon09;
    }
    /**
     * @param k08mon09 the k08mon09 to set
     */
    public void setK08mon09(BigDecimal k08mon09) {
        this.k08mon09 = k08mon09;
    }
    /**
     * @return the k08mon10
     */
    public BigDecimal getK08mon10() {
        return k08mon10;
    }
    /**
     * @param k08mon10 the k08mon10 to set
     */
    public void setK08mon10(BigDecimal k08mon10) {
        this.k08mon10 = k08mon10;
    }
    /**
     * @return the k08mon11
     */
    public BigDecimal getK08mon11() {
        return k08mon11;
    }
    /**
     * @param k08mon11 the k08mon11 to set
     */
    public void setK08mon11(BigDecimal k08mon11) {
        this.k08mon11 = k08mon11;
    }
    /**
     * @return the k08mon12
     */
    public BigDecimal getK08mon12() {
        return k08mon12;
    }
    /**
     * @param k08mon12 the k08mon12 to set
     */
    public void setK08mon12(BigDecimal k08mon12) {
        this.k08mon12 = k08mon12;
    }
    /**
     * @return the k08tot
     */
    public BigDecimal getK08tot() {
        return k08tot;
    }
    /**
     * @param k08tot the k08tot to set
     */
    public void setK08tot(BigDecimal k08tot) {
        this.k08tot = k08tot;
    }
    /**
     * @return the k08avg
     */
    public BigDecimal getK08avg() {
        return k08avg;
    }
    /**
     * @param k08avg the k08avg to set
     */
    public void setK08avg(BigDecimal k08avg) {
        this.k08avg = k08avg;
    }
    /**
     * @return the k08trgt
     */
    public BigDecimal getK08trgt() {
        return k08trgt;
    }
    /**
     * @param k08trgt the k08trgt to set
     */
    public void setK08trgt(BigDecimal k08trgt) {
        this.k08trgt = k08trgt;
    }
    /**
     * @return the k09cd
     */
    public String getK09cd() {
        return k09cd;
    }
    /**
     * @param k09cd the k09cd to set
     */
    public void setK09cd(String k09cd) {
        this.k09cd = k09cd;
    }
    /**
     * @return the k09mon01
     */
    public BigDecimal getK09mon01() {
        return k09mon01;
    }
    /**
     * @param k09mon01 the k09mon01 to set
     */
    public void setK09mon01(BigDecimal k09mon01) {
        this.k09mon01 = k09mon01;
    }
    /**
     * @return the k09mon02
     */
    public BigDecimal getK09mon02() {
        return k09mon02;
    }
    /**
     * @param k09mon02 the k09mon02 to set
     */
    public void setK09mon02(BigDecimal k09mon02) {
        this.k09mon02 = k09mon02;
    }
    /**
     * @return the k09mon03
     */
    public BigDecimal getK09mon03() {
        return k09mon03;
    }
    /**
     * @param k09mon03 the k09mon03 to set
     */
    public void setK09mon03(BigDecimal k09mon03) {
        this.k09mon03 = k09mon03;
    }
    /**
     * @return the k09mon04
     */
    public BigDecimal getK09mon04() {
        return k09mon04;
    }
    /**
     * @param k09mon04 the k09mon04 to set
     */
    public void setK09mon04(BigDecimal k09mon04) {
        this.k09mon04 = k09mon04;
    }
    /**
     * @return the k09mon05
     */
    public BigDecimal getK09mon05() {
        return k09mon05;
    }
    /**
     * @param k09mon05 the k09mon05 to set
     */
    public void setK09mon05(BigDecimal k09mon05) {
        this.k09mon05 = k09mon05;
    }
    /**
     * @return the k09mon06
     */
    public BigDecimal getK09mon06() {
        return k09mon06;
    }
    /**
     * @param k09mon06 the k09mon06 to set
     */
    public void setK09mon06(BigDecimal k09mon06) {
        this.k09mon06 = k09mon06;
    }
    /**
     * @return the k09mon07
     */
    public BigDecimal getK09mon07() {
        return k09mon07;
    }
    /**
     * @param k09mon07 the k09mon07 to set
     */
    public void setK09mon07(BigDecimal k09mon07) {
        this.k09mon07 = k09mon07;
    }
    /**
     * @return the k09mon08
     */
    public BigDecimal getK09mon08() {
        return k09mon08;
    }
    /**
     * @param k09mon08 the k09mon08 to set
     */
    public void setK09mon08(BigDecimal k09mon08) {
        this.k09mon08 = k09mon08;
    }
    /**
     * @return the k09mon09
     */
    public BigDecimal getK09mon09() {
        return k09mon09;
    }
    /**
     * @param k09mon09 the k09mon09 to set
     */
    public void setK09mon09(BigDecimal k09mon09) {
        this.k09mon09 = k09mon09;
    }
    /**
     * @return the k09mon10
     */
    public BigDecimal getK09mon10() {
        return k09mon10;
    }
    /**
     * @param k09mon10 the k09mon10 to set
     */
    public void setK09mon10(BigDecimal k09mon10) {
        this.k09mon10 = k09mon10;
    }
    /**
     * @return the k09mon11
     */
    public BigDecimal getK09mon11() {
        return k09mon11;
    }
    /**
     * @param k09mon11 the k09mon11 to set
     */
    public void setK09mon11(BigDecimal k09mon11) {
        this.k09mon11 = k09mon11;
    }
    /**
     * @return the k09mon12
     */
    public BigDecimal getK09mon12() {
        return k09mon12;
    }
    /**
     * @param k09mon12 the k09mon12 to set
     */
    public void setK09mon12(BigDecimal k09mon12) {
        this.k09mon12 = k09mon12;
    }
    /**
     * @return the k09tot
     */
    public BigDecimal getK09tot() {
        return k09tot;
    }
    /**
     * @param k09tot the k09tot to set
     */
    public void setK09tot(BigDecimal k09tot) {
        this.k09tot = k09tot;
    }
    /**
     * @return the k09avg
     */
    public BigDecimal getK09avg() {
        return k09avg;
    }
    /**
     * @param k09avg the k09avg to set
     */
    public void setK09avg(BigDecimal k09avg) {
        this.k09avg = k09avg;
    }
    /**
     * @return the k09trgt
     */
    public BigDecimal getK09trgt() {
        return k09trgt;
    }
    /**
     * @param k09trgt the k09trgt to set
     */
    public void setK09trgt(BigDecimal k09trgt) {
        this.k09trgt = k09trgt;
    }
    /**
     * @return the k10cd
     */
    public String getK10cd() {
        return k10cd;
    }
    /**
     * @param k10cd the k10cd to set
     */
    public void setK10cd(String k10cd) {
        this.k10cd = k10cd;
    }
    /**
     * @return the k10mon01
     */
    public BigDecimal getK10mon01() {
        return k10mon01;
    }
    /**
     * @param k10mon01 the k10mon01 to set
     */
    public void setK10mon01(BigDecimal k10mon01) {
        this.k10mon01 = k10mon01;
    }
    /**
     * @return the k10mon02
     */
    public BigDecimal getK10mon02() {
        return k10mon02;
    }
    /**
     * @param k10mon02 the k10mon02 to set
     */
    public void setK10mon02(BigDecimal k10mon02) {
        this.k10mon02 = k10mon02;
    }
    /**
     * @return the k10mon03
     */
    public BigDecimal getK10mon03() {
        return k10mon03;
    }
    /**
     * @param k10mon03 the k10mon03 to set
     */
    public void setK10mon03(BigDecimal k10mon03) {
        this.k10mon03 = k10mon03;
    }
    /**
     * @return the k10mon04
     */
    public BigDecimal getK10mon04() {
        return k10mon04;
    }
    /**
     * @param k10mon04 the k10mon04 to set
     */
    public void setK10mon04(BigDecimal k10mon04) {
        this.k10mon04 = k10mon04;
    }
    /**
     * @return the k10mon05
     */
    public BigDecimal getK10mon05() {
        return k10mon05;
    }
    /**
     * @param k10mon05 the k10mon05 to set
     */
    public void setK10mon05(BigDecimal k10mon05) {
        this.k10mon05 = k10mon05;
    }
    /**
     * @return the k10mon06
     */
    public BigDecimal getK10mon06() {
        return k10mon06;
    }
    /**
     * @param k10mon06 the k10mon06 to set
     */
    public void setK10mon06(BigDecimal k10mon06) {
        this.k10mon06 = k10mon06;
    }
    /**
     * @return the k10mon07
     */
    public BigDecimal getK10mon07() {
        return k10mon07;
    }
    /**
     * @param k10mon07 the k10mon07 to set
     */
    public void setK10mon07(BigDecimal k10mon07) {
        this.k10mon07 = k10mon07;
    }
    /**
     * @return the k10mon08
     */
    public BigDecimal getK10mon08() {
        return k10mon08;
    }
    /**
     * @param k10mon08 the k10mon08 to set
     */
    public void setK10mon08(BigDecimal k10mon08) {
        this.k10mon08 = k10mon08;
    }
    /**
     * @return the k10mon09
     */
    public BigDecimal getK10mon09() {
        return k10mon09;
    }
    /**
     * @param k10mon09 the k10mon09 to set
     */
    public void setK10mon09(BigDecimal k10mon09) {
        this.k10mon09 = k10mon09;
    }
    /**
     * @return the k10mon10
     */
    public BigDecimal getK10mon10() {
        return k10mon10;
    }
    /**
     * @param k10mon10 the k10mon10 to set
     */
    public void setK10mon10(BigDecimal k10mon10) {
        this.k10mon10 = k10mon10;
    }
    /**
     * @return the k10mon11
     */
    public BigDecimal getK10mon11() {
        return k10mon11;
    }
    /**
     * @param k10mon11 the k10mon11 to set
     */
    public void setK10mon11(BigDecimal k10mon11) {
        this.k10mon11 = k10mon11;
    }
    /**
     * @return the k10mon12
     */
    public BigDecimal getK10mon12() {
        return k10mon12;
    }
    /**
     * @param k10mon12 the k10mon12 to set
     */
    public void setK10mon12(BigDecimal k10mon12) {
        this.k10mon12 = k10mon12;
    }
    /**
     * @return the k10tot
     */
    public BigDecimal getK10tot() {
        return k10tot;
    }
    /**
     * @param k10tot the k10tot to set
     */
    public void setK10tot(BigDecimal k10tot) {
        this.k10tot = k10tot;
    }
    /**
     * @return the k10avg
     */
    public BigDecimal getK10avg() {
        return k10avg;
    }
    /**
     * @param k10avg the k10avg to set
     */
    public void setK10avg(BigDecimal k10avg) {
        this.k10avg = k10avg;
    }
    /**
     * @return the k10trgt
     */
    public BigDecimal getK10trgt() {
        return k10trgt;
    }
    /**
     * @param k10trgt the k10trgt to set
     */
    public void setK10trgt(BigDecimal k10trgt) {
        this.k10trgt = k10trgt;
    }
    /**
     * @return the k11cd
     */
    public String getK11cd() {
        return k11cd;
    }
    /**
     * @param k11cd the k11cd to set
     */
    public void setK11cd(String k11cd) {
        this.k11cd = k11cd;
    }
    /**
     * @return the k11mon01
     */
    public BigDecimal getK11mon01() {
        return k11mon01;
    }
    /**
     * @param k11mon01 the k11mon01 to set
     */
    public void setK11mon01(BigDecimal k11mon01) {
        this.k11mon01 = k11mon01;
    }
    /**
     * @return the k11mon02
     */
    public BigDecimal getK11mon02() {
        return k11mon02;
    }
    /**
     * @param k11mon02 the k11mon02 to set
     */
    public void setK11mon02(BigDecimal k11mon02) {
        this.k11mon02 = k11mon02;
    }
    /**
     * @return the k11mon03
     */
    public BigDecimal getK11mon03() {
        return k11mon03;
    }
    /**
     * @param k11mon03 the k11mon03 to set
     */
    public void setK11mon03(BigDecimal k11mon03) {
        this.k11mon03 = k11mon03;
    }
    /**
     * @return the k11mon04
     */
    public BigDecimal getK11mon04() {
        return k11mon04;
    }
    /**
     * @param k11mon04 the k11mon04 to set
     */
    public void setK11mon04(BigDecimal k11mon04) {
        this.k11mon04 = k11mon04;
    }
    /**
     * @return the k11mon05
     */
    public BigDecimal getK11mon05() {
        return k11mon05;
    }
    /**
     * @param k11mon05 the k11mon05 to set
     */
    public void setK11mon05(BigDecimal k11mon05) {
        this.k11mon05 = k11mon05;
    }
    /**
     * @return the k11mon06
     */
    public BigDecimal getK11mon06() {
        return k11mon06;
    }
    /**
     * @param k11mon06 the k11mon06 to set
     */
    public void setK11mon06(BigDecimal k11mon06) {
        this.k11mon06 = k11mon06;
    }
    /**
     * @return the k11mon07
     */
    public BigDecimal getK11mon07() {
        return k11mon07;
    }
    /**
     * @param k11mon07 the k11mon07 to set
     */
    public void setK11mon07(BigDecimal k11mon07) {
        this.k11mon07 = k11mon07;
    }
    /**
     * @return the k11mon08
     */
    public BigDecimal getK11mon08() {
        return k11mon08;
    }
    /**
     * @param k11mon08 the k11mon08 to set
     */
    public void setK11mon08(BigDecimal k11mon08) {
        this.k11mon08 = k11mon08;
    }
    /**
     * @return the k11mon09
     */
    public BigDecimal getK11mon09() {
        return k11mon09;
    }
    /**
     * @param k11mon09 the k11mon09 to set
     */
    public void setK11mon09(BigDecimal k11mon09) {
        this.k11mon09 = k11mon09;
    }
    /**
     * @return the k11mon10
     */
    public BigDecimal getK11mon10() {
        return k11mon10;
    }
    /**
     * @param k11mon10 the k11mon10 to set
     */
    public void setK11mon10(BigDecimal k11mon10) {
        this.k11mon10 = k11mon10;
    }
    /**
     * @return the k11mon11
     */
    public BigDecimal getK11mon11() {
        return k11mon11;
    }
    /**
     * @param k11mon11 the k11mon11 to set
     */
    public void setK11mon11(BigDecimal k11mon11) {
        this.k11mon11 = k11mon11;
    }
    /**
     * @return the k11mon12
     */
    public BigDecimal getK11mon12() {
        return k11mon12;
    }
    /**
     * @param k11mon12 the k11mon12 to set
     */
    public void setK11mon12(BigDecimal k11mon12) {
        this.k11mon12 = k11mon12;
    }
    /**
     * @return the k11tot
     */
    public BigDecimal getK11tot() {
        return k11tot;
    }
    /**
     * @param k11tot the k11tot to set
     */
    public void setK11tot(BigDecimal k11tot) {
        this.k11tot = k11tot;
    }
    /**
     * @return the k11avg
     */
    public BigDecimal getK11avg() {
        return k11avg;
    }
    /**
     * @param k11avg the k11avg to set
     */
    public void setK11avg(BigDecimal k11avg) {
        this.k11avg = k11avg;
    }
    /**
     * @return the k11trgt
     */
    public BigDecimal getK11trgt() {
        return k11trgt;
    }
    /**
     * @param k11trgt the k11trgt to set
     */
    public void setK11trgt(BigDecimal k11trgt) {
        this.k11trgt = k11trgt;
    }
    /**
     * @return the k12cd
     */
    public String getK12cd() {
        return k12cd;
    }
    /**
     * @param k12cd the k12cd to set
     */
    public void setK12cd(String k12cd) {
        this.k12cd = k12cd;
    }
    /**
     * @return the k12mon01
     */
    public BigDecimal getK12mon01() {
        return k12mon01;
    }
    /**
     * @param k12mon01 the k12mon01 to set
     */
    public void setK12mon01(BigDecimal k12mon01) {
        this.k12mon01 = k12mon01;
    }
    /**
     * @return the k12mon02
     */
    public BigDecimal getK12mon02() {
        return k12mon02;
    }
    /**
     * @param k12mon02 the k12mon02 to set
     */
    public void setK12mon02(BigDecimal k12mon02) {
        this.k12mon02 = k12mon02;
    }
    /**
     * @return the k12mon03
     */
    public BigDecimal getK12mon03() {
        return k12mon03;
    }
    /**
     * @param k12mon03 the k12mon03 to set
     */
    public void setK12mon03(BigDecimal k12mon03) {
        this.k12mon03 = k12mon03;
    }
    /**
     * @return the k12mon04
     */
    public BigDecimal getK12mon04() {
        return k12mon04;
    }
    /**
     * @param k12mon04 the k12mon04 to set
     */
    public void setK12mon04(BigDecimal k12mon04) {
        this.k12mon04 = k12mon04;
    }
    /**
     * @return the k12mon05
     */
    public BigDecimal getK12mon05() {
        return k12mon05;
    }
    /**
     * @param k12mon05 the k12mon05 to set
     */
    public void setK12mon05(BigDecimal k12mon05) {
        this.k12mon05 = k12mon05;
    }
    /**
     * @return the k12mon06
     */
    public BigDecimal getK12mon06() {
        return k12mon06;
    }
    /**
     * @param k12mon06 the k12mon06 to set
     */
    public void setK12mon06(BigDecimal k12mon06) {
        this.k12mon06 = k12mon06;
    }
    /**
     * @return the k12mon07
     */
    public BigDecimal getK12mon07() {
        return k12mon07;
    }
    /**
     * @param k12mon07 the k12mon07 to set
     */
    public void setK12mon07(BigDecimal k12mon07) {
        this.k12mon07 = k12mon07;
    }
    /**
     * @return the k12mon08
     */
    public BigDecimal getK12mon08() {
        return k12mon08;
    }
    /**
     * @param k12mon08 the k12mon08 to set
     */
    public void setK12mon08(BigDecimal k12mon08) {
        this.k12mon08 = k12mon08;
    }
    /**
     * @return the k12mon09
     */
    public BigDecimal getK12mon09() {
        return k12mon09;
    }
    /**
     * @param k12mon09 the k12mon09 to set
     */
    public void setK12mon09(BigDecimal k12mon09) {
        this.k12mon09 = k12mon09;
    }
    /**
     * @return the k12mon10
     */
    public BigDecimal getK12mon10() {
        return k12mon10;
    }
    /**
     * @param k12mon10 the k12mon10 to set
     */
    public void setK12mon10(BigDecimal k12mon10) {
        this.k12mon10 = k12mon10;
    }
    /**
     * @return the k12mon11
     */
    public BigDecimal getK12mon11() {
        return k12mon11;
    }
    /**
     * @param k12mon11 the k12mon11 to set
     */
    public void setK12mon11(BigDecimal k12mon11) {
        this.k12mon11 = k12mon11;
    }
    /**
     * @return the k12mon12
     */
    public BigDecimal getK12mon12() {
        return k12mon12;
    }
    /**
     * @param k12mon12 the k12mon12 to set
     */
    public void setK12mon12(BigDecimal k12mon12) {
        this.k12mon12 = k12mon12;
    }
    /**
     * @return the k12tot
     */
    public BigDecimal getK12tot() {
        return k12tot;
    }
    /**
     * @param k12tot the k12tot to set
     */
    public void setK12tot(BigDecimal k12tot) {
        this.k12tot = k12tot;
    }
    /**
     * @return the k12avg
     */
    public BigDecimal getK12avg() {
        return k12avg;
    }
    /**
     * @param k12avg the k12avg to set
     */
    public void setK12avg(BigDecimal k12avg) {
        this.k12avg = k12avg;
    }
    /**
     * @return the k12trgt
     */
    public BigDecimal getK12trgt() {
        return k12trgt;
    }
    /**
     * @param k12trgt the k12trgt to set
     */
    public void setK12trgt(BigDecimal k12trgt) {
        this.k12trgt = k12trgt;
    }
    /**
     * @return the k13cd
     */
    public String getK13cd() {
        return k13cd;
    }
    /**
     * @param k13cd the k13cd to set
     */
    public void setK13cd(String k13cd) {
        this.k13cd = k13cd;
    }
    /**
     * @return the k13mon01
     */
    public BigDecimal getK13mon01() {
        return k13mon01;
    }
    /**
     * @param k13mon01 the k13mon01 to set
     */
    public void setK13mon01(BigDecimal k13mon01) {
        this.k13mon01 = k13mon01;
    }
    /**
     * @return the k13mon02
     */
    public BigDecimal getK13mon02() {
        return k13mon02;
    }
    /**
     * @param k13mon02 the k13mon02 to set
     */
    public void setK13mon02(BigDecimal k13mon02) {
        this.k13mon02 = k13mon02;
    }
    /**
     * @return the k13mon03
     */
    public BigDecimal getK13mon03() {
        return k13mon03;
    }
    /**
     * @param k13mon03 the k13mon03 to set
     */
    public void setK13mon03(BigDecimal k13mon03) {
        this.k13mon03 = k13mon03;
    }
    /**
     * @return the k13mon04
     */
    public BigDecimal getK13mon04() {
        return k13mon04;
    }
    /**
     * @param k13mon04 the k13mon04 to set
     */
    public void setK13mon04(BigDecimal k13mon04) {
        this.k13mon04 = k13mon04;
    }
    /**
     * @return the k13mon05
     */
    public BigDecimal getK13mon05() {
        return k13mon05;
    }
    /**
     * @param k13mon05 the k13mon05 to set
     */
    public void setK13mon05(BigDecimal k13mon05) {
        this.k13mon05 = k13mon05;
    }
    /**
     * @return the k13mon06
     */
    public BigDecimal getK13mon06() {
        return k13mon06;
    }
    /**
     * @param k13mon06 the k13mon06 to set
     */
    public void setK13mon06(BigDecimal k13mon06) {
        this.k13mon06 = k13mon06;
    }
    /**
     * @return the k13mon07
     */
    public BigDecimal getK13mon07() {
        return k13mon07;
    }
    /**
     * @param k13mon07 the k13mon07 to set
     */
    public void setK13mon07(BigDecimal k13mon07) {
        this.k13mon07 = k13mon07;
    }
    /**
     * @return the k13mon08
     */
    public BigDecimal getK13mon08() {
        return k13mon08;
    }
    /**
     * @param k13mon08 the k13mon08 to set
     */
    public void setK13mon08(BigDecimal k13mon08) {
        this.k13mon08 = k13mon08;
    }
    /**
     * @return the k13mon09
     */
    public BigDecimal getK13mon09() {
        return k13mon09;
    }
    /**
     * @param k13mon09 the k13mon09 to set
     */
    public void setK13mon09(BigDecimal k13mon09) {
        this.k13mon09 = k13mon09;
    }
    /**
     * @return the k13mon10
     */
    public BigDecimal getK13mon10() {
        return k13mon10;
    }
    /**
     * @param k13mon10 the k13mon10 to set
     */
    public void setK13mon10(BigDecimal k13mon10) {
        this.k13mon10 = k13mon10;
    }
    /**
     * @return the k13mon11
     */
    public BigDecimal getK13mon11() {
        return k13mon11;
    }
    /**
     * @param k13mon11 the k13mon11 to set
     */
    public void setK13mon11(BigDecimal k13mon11) {
        this.k13mon11 = k13mon11;
    }
    /**
     * @return the k13mon12
     */
    public BigDecimal getK13mon12() {
        return k13mon12;
    }
    /**
     * @param k13mon12 the k13mon12 to set
     */
    public void setK13mon12(BigDecimal k13mon12) {
        this.k13mon12 = k13mon12;
    }
    /**
     * @return the k13tot
     */
    public BigDecimal getK13tot() {
        return k13tot;
    }
    /**
     * @param k13tot the k13tot to set
     */
    public void setK13tot(BigDecimal k13tot) {
        this.k13tot = k13tot;
    }
    /**
     * @return the k13avg
     */
    public BigDecimal getK13avg() {
        return k13avg;
    }
    /**
     * @param k13avg the k13avg to set
     */
    public void setK13avg(BigDecimal k13avg) {
        this.k13avg = k13avg;
    }
    /**
     * @return the k13trgt
     */
    public BigDecimal getK13trgt() {
        return k13trgt;
    }
    /**
     * @param k13trgt the k13trgt to set
     */
    public void setK13trgt(BigDecimal k13trgt) {
        this.k13trgt = k13trgt;
    }
    /**
     * @return the k14cd
     */
    public String getK14cd() {
        return k14cd;
    }
    /**
     * @param k14cd the k14cd to set
     */
    public void setK14cd(String k14cd) {
        this.k14cd = k14cd;
    }
    /**
     * @return the k14mon01
     */
    public BigDecimal getK14mon01() {
        return k14mon01;
    }
    /**
     * @param k14mon01 the k14mon01 to set
     */
    public void setK14mon01(BigDecimal k14mon01) {
        this.k14mon01 = k14mon01;
    }
    /**
     * @return the k14mon02
     */
    public BigDecimal getK14mon02() {
        return k14mon02;
    }
    /**
     * @param k14mon02 the k14mon02 to set
     */
    public void setK14mon02(BigDecimal k14mon02) {
        this.k14mon02 = k14mon02;
    }
    /**
     * @return the k14mon03
     */
    public BigDecimal getK14mon03() {
        return k14mon03;
    }
    /**
     * @param k14mon03 the k14mon03 to set
     */
    public void setK14mon03(BigDecimal k14mon03) {
        this.k14mon03 = k14mon03;
    }
    /**
     * @return the k14mon04
     */
    public BigDecimal getK14mon04() {
        return k14mon04;
    }
    /**
     * @param k14mon04 the k14mon04 to set
     */
    public void setK14mon04(BigDecimal k14mon04) {
        this.k14mon04 = k14mon04;
    }
    /**
     * @return the k14mon05
     */
    public BigDecimal getK14mon05() {
        return k14mon05;
    }
    /**
     * @param k14mon05 the k14mon05 to set
     */
    public void setK14mon05(BigDecimal k14mon05) {
        this.k14mon05 = k14mon05;
    }
    /**
     * @return the k14mon06
     */
    public BigDecimal getK14mon06() {
        return k14mon06;
    }
    /**
     * @param k14mon06 the k14mon06 to set
     */
    public void setK14mon06(BigDecimal k14mon06) {
        this.k14mon06 = k14mon06;
    }
    /**
     * @return the k14mon07
     */
    public BigDecimal getK14mon07() {
        return k14mon07;
    }
    /**
     * @param k14mon07 the k14mon07 to set
     */
    public void setK14mon07(BigDecimal k14mon07) {
        this.k14mon07 = k14mon07;
    }
    /**
     * @return the k14mon08
     */
    public BigDecimal getK14mon08() {
        return k14mon08;
    }
    /**
     * @param k14mon08 the k14mon08 to set
     */
    public void setK14mon08(BigDecimal k14mon08) {
        this.k14mon08 = k14mon08;
    }
    /**
     * @return the k14mon09
     */
    public BigDecimal getK14mon09() {
        return k14mon09;
    }
    /**
     * @param k14mon09 the k14mon09 to set
     */
    public void setK14mon09(BigDecimal k14mon09) {
        this.k14mon09 = k14mon09;
    }
    /**
     * @return the k14mon10
     */
    public BigDecimal getK14mon10() {
        return k14mon10;
    }
    /**
     * @param k14mon10 the k14mon10 to set
     */
    public void setK14mon10(BigDecimal k14mon10) {
        this.k14mon10 = k14mon10;
    }
    /**
     * @return the k14mon11
     */
    public BigDecimal getK14mon11() {
        return k14mon11;
    }
    /**
     * @param k14mon11 the k14mon11 to set
     */
    public void setK14mon11(BigDecimal k14mon11) {
        this.k14mon11 = k14mon11;
    }
    /**
     * @return the k14mon12
     */
    public BigDecimal getK14mon12() {
        return k14mon12;
    }
    /**
     * @param k14mon12 the k14mon12 to set
     */
    public void setK14mon12(BigDecimal k14mon12) {
        this.k14mon12 = k14mon12;
    }
    /**
     * @return the k14tot
     */
    public BigDecimal getK14tot() {
        return k14tot;
    }
    /**
     * @param k14tot the k14tot to set
     */
    public void setK14tot(BigDecimal k14tot) {
        this.k14tot = k14tot;
    }
    /**
     * @return the k14avg
     */
    public BigDecimal getK14avg() {
        return k14avg;
    }
    /**
     * @param k14avg the k14avg to set
     */
    public void setK14avg(BigDecimal k14avg) {
        this.k14avg = k14avg;
    }
    /**
     * @return the k14trgt
     */
    public BigDecimal getK14trgt() {
        return k14trgt;
    }
    /**
     * @param k14trgt the k14trgt to set
     */
    public void setK14trgt(BigDecimal k14trgt) {
        this.k14trgt = k14trgt;
    }
    /**
     * @return the k15cd
     */
    public String getK15cd() {
        return k15cd;
    }
    /**
     * @param k15cd the k15cd to set
     */
    public void setK15cd(String k15cd) {
        this.k15cd = k15cd;
    }
    /**
     * @return the k15mon01
     */
    public BigDecimal getK15mon01() {
        return k15mon01;
    }
    /**
     * @param k15mon01 the k15mon01 to set
     */
    public void setK15mon01(BigDecimal k15mon01) {
        this.k15mon01 = k15mon01;
    }
    /**
     * @return the k15mon02
     */
    public BigDecimal getK15mon02() {
        return k15mon02;
    }
    /**
     * @param k15mon02 the k15mon02 to set
     */
    public void setK15mon02(BigDecimal k15mon02) {
        this.k15mon02 = k15mon02;
    }
    /**
     * @return the k15mon03
     */
    public BigDecimal getK15mon03() {
        return k15mon03;
    }
    /**
     * @param k15mon03 the k15mon03 to set
     */
    public void setK15mon03(BigDecimal k15mon03) {
        this.k15mon03 = k15mon03;
    }
    /**
     * @return the k15mon04
     */
    public BigDecimal getK15mon04() {
        return k15mon04;
    }
    /**
     * @param k15mon04 the k15mon04 to set
     */
    public void setK15mon04(BigDecimal k15mon04) {
        this.k15mon04 = k15mon04;
    }
    /**
     * @return the k15mon05
     */
    public BigDecimal getK15mon05() {
        return k15mon05;
    }
    /**
     * @param k15mon05 the k15mon05 to set
     */
    public void setK15mon05(BigDecimal k15mon05) {
        this.k15mon05 = k15mon05;
    }
    /**
     * @return the k15mon06
     */
    public BigDecimal getK15mon06() {
        return k15mon06;
    }
    /**
     * @param k15mon06 the k15mon06 to set
     */
    public void setK15mon06(BigDecimal k15mon06) {
        this.k15mon06 = k15mon06;
    }
    /**
     * @return the k15mon07
     */
    public BigDecimal getK15mon07() {
        return k15mon07;
    }
    /**
     * @param k15mon07 the k15mon07 to set
     */
    public void setK15mon07(BigDecimal k15mon07) {
        this.k15mon07 = k15mon07;
    }
    /**
     * @return the k15mon08
     */
    public BigDecimal getK15mon08() {
        return k15mon08;
    }
    /**
     * @param k15mon08 the k15mon08 to set
     */
    public void setK15mon08(BigDecimal k15mon08) {
        this.k15mon08 = k15mon08;
    }
    /**
     * @return the k15mon09
     */
    public BigDecimal getK15mon09() {
        return k15mon09;
    }
    /**
     * @param k15mon09 the k15mon09 to set
     */
    public void setK15mon09(BigDecimal k15mon09) {
        this.k15mon09 = k15mon09;
    }
    /**
     * @return the k15mon10
     */
    public BigDecimal getK15mon10() {
        return k15mon10;
    }
    /**
     * @param k15mon10 the k15mon10 to set
     */
    public void setK15mon10(BigDecimal k15mon10) {
        this.k15mon10 = k15mon10;
    }
    /**
     * @return the k15mon11
     */
    public BigDecimal getK15mon11() {
        return k15mon11;
    }
    /**
     * @param k15mon11 the k15mon11 to set
     */
    public void setK15mon11(BigDecimal k15mon11) {
        this.k15mon11 = k15mon11;
    }
    /**
     * @return the k15mon12
     */
    public BigDecimal getK15mon12() {
        return k15mon12;
    }
    /**
     * @param k15mon12 the k15mon12 to set
     */
    public void setK15mon12(BigDecimal k15mon12) {
        this.k15mon12 = k15mon12;
    }
    /**
     * @return the k15tot
     */
    public BigDecimal getK15tot() {
        return k15tot;
    }
    /**
     * @param k15tot the k15tot to set
     */
    public void setK15tot(BigDecimal k15tot) {
        this.k15tot = k15tot;
    }
    /**
     * @return the k15avg
     */
    public BigDecimal getK15avg() {
        return k15avg;
    }
    /**
     * @param k15avg the k15avg to set
     */
    public void setK15avg(BigDecimal k15avg) {
        this.k15avg = k15avg;
    }
    /**
     * @return the k15trgt
     */
    public BigDecimal getK15trgt() {
        return k15trgt;
    }
    /**
     * @param k15trgt the k15trgt to set
     */
    public void setK15trgt(BigDecimal k15trgt) {
        this.k15trgt = k15trgt;
    }
    /**
     * @return the k16cd
     */
    public String getK16cd() {
        return k16cd;
    }
    /**
     * @param k16cd the k16cd to set
     */
    public void setK16cd(String k16cd) {
        this.k16cd = k16cd;
    }
    /**
     * @return the k16mon01
     */
    public BigDecimal getK16mon01() {
        return k16mon01;
    }
    /**
     * @param k16mon01 the k16mon01 to set
     */
    public void setK16mon01(BigDecimal k16mon01) {
        this.k16mon01 = k16mon01;
    }
    /**
     * @return the k16mon02
     */
    public BigDecimal getK16mon02() {
        return k16mon02;
    }
    /**
     * @param k16mon02 the k16mon02 to set
     */
    public void setK16mon02(BigDecimal k16mon02) {
        this.k16mon02 = k16mon02;
    }
    /**
     * @return the k16mon03
     */
    public BigDecimal getK16mon03() {
        return k16mon03;
    }
    /**
     * @param k16mon03 the k16mon03 to set
     */
    public void setK16mon03(BigDecimal k16mon03) {
        this.k16mon03 = k16mon03;
    }
    /**
     * @return the k16mon04
     */
    public BigDecimal getK16mon04() {
        return k16mon04;
    }
    /**
     * @param k16mon04 the k16mon04 to set
     */
    public void setK16mon04(BigDecimal k16mon04) {
        this.k16mon04 = k16mon04;
    }
    /**
     * @return the k16mon05
     */
    public BigDecimal getK16mon05() {
        return k16mon05;
    }
    /**
     * @param k16mon05 the k16mon05 to set
     */
    public void setK16mon05(BigDecimal k16mon05) {
        this.k16mon05 = k16mon05;
    }
    /**
     * @return the k16mon06
     */
    public BigDecimal getK16mon06() {
        return k16mon06;
    }
    /**
     * @param k16mon06 the k16mon06 to set
     */
    public void setK16mon06(BigDecimal k16mon06) {
        this.k16mon06 = k16mon06;
    }
    /**
     * @return the k16mon07
     */
    public BigDecimal getK16mon07() {
        return k16mon07;
    }
    /**
     * @param k16mon07 the k16mon07 to set
     */
    public void setK16mon07(BigDecimal k16mon07) {
        this.k16mon07 = k16mon07;
    }
    /**
     * @return the k16mon08
     */
    public BigDecimal getK16mon08() {
        return k16mon08;
    }
    /**
     * @param k16mon08 the k16mon08 to set
     */
    public void setK16mon08(BigDecimal k16mon08) {
        this.k16mon08 = k16mon08;
    }
    /**
     * @return the k16mon09
     */
    public BigDecimal getK16mon09() {
        return k16mon09;
    }
    /**
     * @param k16mon09 the k16mon09 to set
     */
    public void setK16mon09(BigDecimal k16mon09) {
        this.k16mon09 = k16mon09;
    }
    /**
     * @return the k16mon10
     */
    public BigDecimal getK16mon10() {
        return k16mon10;
    }
    /**
     * @param k16mon10 the k16mon10 to set
     */
    public void setK16mon10(BigDecimal k16mon10) {
        this.k16mon10 = k16mon10;
    }
    /**
     * @return the k16mon11
     */
    public BigDecimal getK16mon11() {
        return k16mon11;
    }
    /**
     * @param k16mon11 the k16mon11 to set
     */
    public void setK16mon11(BigDecimal k16mon11) {
        this.k16mon11 = k16mon11;
    }
    /**
     * @return the k16mon12
     */
    public BigDecimal getK16mon12() {
        return k16mon12;
    }
    /**
     * @param k16mon12 the k16mon12 to set
     */
    public void setK16mon12(BigDecimal k16mon12) {
        this.k16mon12 = k16mon12;
    }
    /**
     * @return the k16tot
     */
    public BigDecimal getK16tot() {
        return k16tot;
    }
    /**
     * @param k16tot the k16tot to set
     */
    public void setK16tot(BigDecimal k16tot) {
        this.k16tot = k16tot;
    }
    /**
     * @return the k16avg
     */
    public BigDecimal getK16avg() {
        return k16avg;
    }
    /**
     * @param k16avg the k16avg to set
     */
    public void setK16avg(BigDecimal k16avg) {
        this.k16avg = k16avg;
    }
    /**
     * @return the k16trgt
     */
    public BigDecimal getK16trgt() {
        return k16trgt;
    }
    /**
     * @param k16trgt the k16trgt to set
     */
    public void setK16trgt(BigDecimal k16trgt) {
        this.k16trgt = k16trgt;
    }
    /**
     * @return the k17cd
     */
    public String getK17cd() {
        return k17cd;
    }
    /**
     * @param k17cd the k17cd to set
     */
    public void setK17cd(String k17cd) {
        this.k17cd = k17cd;
    }
    /**
     * @return the k17mon01
     */
    public BigDecimal getK17mon01() {
        return k17mon01;
    }
    /**
     * @param k17mon01 the k17mon01 to set
     */
    public void setK17mon01(BigDecimal k17mon01) {
        this.k17mon01 = k17mon01;
    }
    /**
     * @return the k17mon02
     */
    public BigDecimal getK17mon02() {
        return k17mon02;
    }
    /**
     * @param k17mon02 the k17mon02 to set
     */
    public void setK17mon02(BigDecimal k17mon02) {
        this.k17mon02 = k17mon02;
    }
    /**
     * @return the k17mon03
     */
    public BigDecimal getK17mon03() {
        return k17mon03;
    }
    /**
     * @param k17mon03 the k17mon03 to set
     */
    public void setK17mon03(BigDecimal k17mon03) {
        this.k17mon03 = k17mon03;
    }
    /**
     * @return the k17mon04
     */
    public BigDecimal getK17mon04() {
        return k17mon04;
    }
    /**
     * @param k17mon04 the k17mon04 to set
     */
    public void setK17mon04(BigDecimal k17mon04) {
        this.k17mon04 = k17mon04;
    }
    /**
     * @return the k17mon05
     */
    public BigDecimal getK17mon05() {
        return k17mon05;
    }
    /**
     * @param k17mon05 the k17mon05 to set
     */
    public void setK17mon05(BigDecimal k17mon05) {
        this.k17mon05 = k17mon05;
    }
    /**
     * @return the k17mon06
     */
    public BigDecimal getK17mon06() {
        return k17mon06;
    }
    /**
     * @param k17mon06 the k17mon06 to set
     */
    public void setK17mon06(BigDecimal k17mon06) {
        this.k17mon06 = k17mon06;
    }
    /**
     * @return the k17mon07
     */
    public BigDecimal getK17mon07() {
        return k17mon07;
    }
    /**
     * @param k17mon07 the k17mon07 to set
     */
    public void setK17mon07(BigDecimal k17mon07) {
        this.k17mon07 = k17mon07;
    }
    /**
     * @return the k17mon08
     */
    public BigDecimal getK17mon08() {
        return k17mon08;
    }
    /**
     * @param k17mon08 the k17mon08 to set
     */
    public void setK17mon08(BigDecimal k17mon08) {
        this.k17mon08 = k17mon08;
    }
    /**
     * @return the k17mon09
     */
    public BigDecimal getK17mon09() {
        return k17mon09;
    }
    /**
     * @param k17mon09 the k17mon09 to set
     */
    public void setK17mon09(BigDecimal k17mon09) {
        this.k17mon09 = k17mon09;
    }
    /**
     * @return the k17mon10
     */
    public BigDecimal getK17mon10() {
        return k17mon10;
    }
    /**
     * @param k17mon10 the k17mon10 to set
     */
    public void setK17mon10(BigDecimal k17mon10) {
        this.k17mon10 = k17mon10;
    }
    /**
     * @return the k17mon11
     */
    public BigDecimal getK17mon11() {
        return k17mon11;
    }
    /**
     * @param k17mon11 the k17mon11 to set
     */
    public void setK17mon11(BigDecimal k17mon11) {
        this.k17mon11 = k17mon11;
    }
    /**
     * @return the k17mon12
     */
    public BigDecimal getK17mon12() {
        return k17mon12;
    }
    /**
     * @param k17mon12 the k17mon12 to set
     */
    public void setK17mon12(BigDecimal k17mon12) {
        this.k17mon12 = k17mon12;
    }
    /**
     * @return the k17tot
     */
    public BigDecimal getK17tot() {
        return k17tot;
    }
    /**
     * @param k17tot the k17tot to set
     */
    public void setK17tot(BigDecimal k17tot) {
        this.k17tot = k17tot;
    }
    /**
     * @return the k17avg
     */
    public BigDecimal getK17avg() {
        return k17avg;
    }
    /**
     * @param k17avg the k17avg to set
     */
    public void setK17avg(BigDecimal k17avg) {
        this.k17avg = k17avg;
    }
    /**
     * @return the k17trgt
     */
    public BigDecimal getK17trgt() {
        return k17trgt;
    }
    /**
     * @param k17trgt the k17trgt to set
     */
    public void setK17trgt(BigDecimal k17trgt) {
        this.k17trgt = k17trgt;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }

}
