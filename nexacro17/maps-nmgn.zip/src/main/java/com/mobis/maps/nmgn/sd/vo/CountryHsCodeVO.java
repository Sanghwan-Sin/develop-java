package com.mobis.maps.nmgn.sd.vo;



import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CountryHsCodeVO.java
 * @Description : ZPSD_NMGN_S_HSCODE_FOR_COUNTRY
 * @author 이수지
 * @since 2020. 01. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 01. 20.     이수지     	       최초 생성
 * </pre>
 */

public class CountryHsCodeVO extends MapsCommSapRfcIfCommVO {
    
    /** DATS 유형 필드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_EFDAT" )
    private Date ivEfdat;
    /** Country Key */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_LAND1" )
    private String ivLand1;
    
    /** -----[CT_DATA] START----- */
    
    /** Country Key */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="LAND1" )
    private String land1;
    /** Material Number */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** effective date */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="EFDAT" )
    private Date efdat;
    /** Material description */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** PNC */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="ZPNC" )
    private String zpnc;
    /** 영문명 */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="ZPNC_TXT" )
    private String zpncTxt;
    /** Trade Classification Numbering Scheme */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="STCTS" )
    private String stcts;
    /** Number */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="CCNGN" )
    private String ccngn;
    /** Character 1500 */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="CCNGN_TXT" )
    private String ccngnTxt;
    /** Valid From */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="DATAB" )
    private Date datab;
    /** Valid To */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="DATBI" )
    private Date datbi;
    
    /** -----[CT_DATA] END----- */
           
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @return the ivEfdat
     */
    public Date getIvEfdat() {
        return ivEfdat;
    }
    /**
     * @param ivEfdat the ivEfdat to set
     */
    public void setIvEfdat(Date ivEfdat) {
        this.ivEfdat = ivEfdat;
    }
    /**
     * @return the ivLand1
     */
    public String getIvLand1() {
        return ivLand1;
    }
    /**
     * @param ivLand1 the ivLand1 to set
     */
    public void setIvLand1(String ivLand1) {
        this.ivLand1 = ivLand1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the efdat
     */
    public Date getEfdat() {
        return efdat;
    }
    /**
     * @param efdat the efdat to set
     */
    public void setEfdat(Date efdat) {
        this.efdat = efdat;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zpnc
     */
    public String getZpnc() {
        return zpnc;
    }
    /**
     * @param zpnc the zpnc to set
     */
    public void setZpnc(String zpnc) {
        this.zpnc = zpnc;
    }
    /**
     * @return the zpncTxt
     */
    public String getZpncTxt() {
        return zpncTxt;
    }
    /**
     * @param zpncTxt the zpncTxt to set
     */
    public void setZpncTxt(String zpncTxt) {
        this.zpncTxt = zpncTxt;
    }
    /**
     * @return the stcts
     */
    public String getStcts() {
        return stcts;
    }
    /**
     * @param stcts the stcts to set
     */
    public void setStcts(String stcts) {
        this.stcts = stcts;
    }
    /**
     * @return the ccngn
     */
    public String getCcngn() {
        return ccngn;
    }
    /**
     * @param ccngn the ccngn to set
     */
    public void setCcngn(String ccngn) {
        this.ccngn = ccngn;
    }
    /**
     * @return the ccngnTxt
     */
    public String getCcngnTxt() {
        return ccngnTxt;
    }
    /**
     * @param ccngnTxt the ccngnTxt to set
     */
    public void setCcngnTxt(String ccngnTxt) {
        this.ccngnTxt = ccngnTxt;
    }
    /**
     * @return the datab
     */
    public Date getDatab() {
        return datab;
    }
    /**
     * @param datab the datab to set
     */
    public void setDatab(Date datab) {
        this.datab = datab;
    }
    /**
     * @return the datbi
     */
    public Date getDatbi() {
        return datbi;
    }
    /**
     * @param datbi the datbi to set
     */
    public void setDatbi(Date datbi) {
        this.datbi = datbi;
    }
    
}
