package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.OrderProcCodeService;
import com.mobis.maps.nmgn.cc.vo.OrderProcCodeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderProcCodeController.java
 * @Description : OrderProcCodeController
 * @author ha.jeongryeong
 * @since 2019. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 10.     ha.jeongryeong         최초 생성
 * </pre>
 */
@Controller
public class OrderProcCodeController extends HController {

    @Resource(name = "orderProcCodeService")
    private OrderProcCodeService orderProcCodeService;
    
    /**
     * 조회
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectOrderProcCodeList.do")
    public NexacroResult selectOrderProcCodeList(
            @ParamDataSet(name="dsInput") OrderProcCodeVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        List<OrderProcCodeVO> retList = orderProcCodeService.selectOrderProcCodeList(paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }
    
    
    /**
     * 조회
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectOrderProcCodeListExcelDown.do")
    public NexacroResult selectOrderProcCodeListExcelDown(
            @ParamDataSet(name="dsInput") OrderProcCodeVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        paramVO.setExcelDwnlYn("Y");
        List<OrderProcCodeVO> retList = orderProcCodeService.selectOrderProcCodeList(paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }
}
