package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AmendCodeVO.java
 * @Description : Amend Code List
 * @author hong.minho
 * @since 2020. 6. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 30.     hong.minho     	최초 생성
 * </pre>
 */

public class AmendCodeVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_AMEND_FR" )
    private String iAmendFr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_AMEND_TO" )
    private String iAmendTo;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    
    //-----[IT_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZAMENDCD" )
    private String zamendcd;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="AMEND_TXT" )
    private String amendTxt;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZCFAFG" )
    private String zcfafg;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZOWNDEPT" )
    private String zowndept;
    /** Explanatory Short Text */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZOWNDEPT_TXT" )
    private String zowndeptTxt;
    //-----[IT_DATA] END-----
    
    /**
     * @return the iAmendFr
     */
    public String getiAmendFr() {
        return iAmendFr;
    }
    /**
     * @param iAmendFr the iAmendFr to set
     */
    public void setiAmendFr(String iAmendFr) {
        this.iAmendFr = iAmendFr;
    }
    /**
     * @return the iAmendTo
     */
    public String getiAmendTo() {
        return iAmendTo;
    }
    /**
     * @param iAmendTo the iAmendTo to set
     */
    public void setiAmendTo(String iAmendTo) {
        this.iAmendTo = iAmendTo;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the zamendcd
     */
    public String getZamendcd() {
        return zamendcd;
    }
    /**
     * @param zamendcd the zamendcd to set
     */
    public void setZamendcd(String zamendcd) {
        this.zamendcd = zamendcd;
    }
    /**
     * @return the amendTxt
     */
    public String getAmendTxt() {
        return amendTxt;
    }
    /**
     * @param amendTxt the amendTxt to set
     */
    public void setAmendTxt(String amendTxt) {
        this.amendTxt = amendTxt;
    }
    /**
     * @return the zcfafg
     */
    public String getZcfafg() {
        return zcfafg;
    }
    /**
     * @param zcfafg the zcfafg to set
     */
    public void setZcfafg(String zcfafg) {
        this.zcfafg = zcfafg;
    }
    /**
     * @return the zowndept
     */
    public String getZowndept() {
        return zowndept;
    }
    /**
     * @param zowndept the zowndept to set
     */
    public void setZowndept(String zowndept) {
        this.zowndept = zowndept;
    }
    /**
     * @return the zowndeptTxt
     */
    public String getZowndeptTxt() {
        return zowndeptTxt;
    }
    /**
     * @param zowndeptTxt the zowndeptTxt to set
     */
    public void setZowndeptTxt(String zowndeptTxt) {
        this.zowndeptTxt = zowndeptTxt;
    }
}
