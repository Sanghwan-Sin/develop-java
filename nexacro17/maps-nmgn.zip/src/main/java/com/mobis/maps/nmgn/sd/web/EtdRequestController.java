package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.EtdRequestService;
import com.mobis.maps.nmgn.sd.vo.EtdRequestChkVO;
import com.mobis.maps.nmgn.sd.vo.EtdRequestDetailVO;
import com.mobis.maps.nmgn.sd.vo.EtdRequestVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : EtdRequestController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 8.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class EtdRequestController extends HController{
    @Resource(name = "etdRequestService")
    private EtdRequestService etdRequestService;
    
    /**
     * selectEtdRequesList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectEtdRequesList.do")
    public NexacroResult selectEtdRequesList(@ParamDataSet(name="dsInput") EtdRequestVO paramVO
                                           , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = etdRequestService.selectEtdRequesList(loginInfo, paramVO);

        @SuppressWarnings("unchecked")
        List<EtdRequestVO> retList1 = (List<EtdRequestVO>)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<EtdRequestVO> retList2 = (List<EtdRequestVO>)retMap.get("body");        
        
        result.addDataSet("dsOutput", retList1);
        result.addDataSet("dsOutput2", retList2);
        result.addDataSet("dsOutput3", paramVO);    

        return result;
    }
    
    /**
     * selectExchangePurchaseSalesListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/sd/selectEtdRequesListExcelDown.do")
    public NexacroResult selectEtdRequesListExcelDown(@ParamDataSet(name="dsInput") EtdRequestVO paramVO
                                                    , NexacroResult result) throws Exception {
         
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);        
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        Map<String, Object> retMap = etdRequestService.selectEtdRequesList(loginInfo, paramVO);

        @SuppressWarnings("unchecked")
        List<EtdRequestVO> retList1 = (List<EtdRequestVO>)retMap.get("head");

        result.addDataSet("dsOutput", retList1);

        return result;
    }      
    
    /**
     * selectEtdRequesDetailList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectEtdRequesDetailList.do")
    public NexacroResult selectEtdRequesDetailList(@ParamDataSet(name="dsInput") EtdRequestDetailVO paramVO
                                                 , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = etdRequestService.selectEtdRequesDetailList(loginInfo, paramVO);

        @SuppressWarnings("unchecked")
        List<EtdRequestDetailVO> retList1 = (List<EtdRequestDetailVO>)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<EtdRequestDetailVO> retList2 = (List<EtdRequestDetailVO>)retMap.get("body");        
        
        result.addDataSet("dsOutput", retList1);
        result.addDataSet("dsOutput2", retList2);
        result.addDataSet("dsOutput3", paramVO);      

        return result;
    }    
    
    /**
     * multiEtdRequesDetail
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/sd/multiEtdRequesDetail.do")
    public NexacroResult multiEtdRequesDetail(@ParamDataSet(name="dsInput") EtdRequestDetailVO paramVO
                                            , @ParamDataSet(name="dsInput2") EtdRequestDetailVO param      
                                            , @ParamDataSet(name="dsInput3") List<EtdRequestDetailVO> paramList
                                            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = etdRequestService.multiEtdRequesDetail(paramVO, param, paramList, loginInfo);
        
        //ExchangePurchaseDetailVO retVO = (ExchangePurchaseDetailVO)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<EtdRequestDetailVO> retList = (List<EtdRequestDetailVO>)retMap.get("body");
        @SuppressWarnings("unchecked")
        List<EtdRequestDetailVO> headList = (List<EtdRequestDetailVO>)retMap.get("head");        
        
        result.addDataSet("dsOutput1", headList);
        result.addDataSet("dsOutput2", retList);        
        result.addDataSet("dsReturn", paramVO);        

        return result;
    }    
    
    /**
     * selectEtdRechkRtn
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectEtdRechkRtn.do")
    public NexacroResult selectEtdRechkRtn(@ParamDataSet(name = "dsChkReq") EtdRequestChkVO chkVo,
            @ParamDataSet(name = "dsSearchRes2") List<EtdRequestDetailVO> itemLst, NexacroResult result)
            throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<EtdRequestDetailVO> rsltLst = etdRequestService.selectEtdRechkRtn(loginInfo, chkVo, itemLst);

        result.addDataSet("dsOutput", rsltLst);    

        return result;
    }       
}
