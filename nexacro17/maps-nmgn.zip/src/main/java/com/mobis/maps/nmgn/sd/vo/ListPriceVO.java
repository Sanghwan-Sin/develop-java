package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceVO.java
 * @Description : ZPSD_MGN_R_LIST_PRICE
 * @author 이수지
 * @since 2020. 01. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 01. 10.     이수지     	       최초 생성
 * </pre>
 */

public class ListPriceVO extends MapsCommSapRfcIfCommVO {
    
    
    /** List Price 조건 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_LPCON" )
    private String iLpcon;
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** 가격 리스트 유형 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PLTYP" )
    private String iPltyp;
    /** Mode(C/R/U/D) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** Car Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDPCCD" )
    private String iZdpccd;
    /** H/K 구분 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** AS-IS 구코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** List Price Result */
    private List<?> tResult = null;
    
    /** -----[T_RESULT] START----- */
    
    /** 고객코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** H/K 구분 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** Description */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD_DESC" )
    private String zhkcdDesc;
    /** Material Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** 승상용구분(내수) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZDPCCD" )
    private String zdpccd;
    /** 코드 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZDPCCD_DESC" )
    private String zdpccdDesc;
    /** Price List Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PLTYP" )
    private String pltyp;
    /** Text (20 Characters) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PTEXT" )
    private String ptext;
    /** Currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="LIST_PRICE" )
    private String listPrice;
    /** Quantity(20자리) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZQFP" )
    private String zqfp;
    /** Create Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /** Create User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCRNAME" )
    private String zcrname;
    /** Change Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDLDATE" )
    private Date zudldate;
    /** Change User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDNAME" )
    private String zudname;
    /** 메세지 결과: S 성공, E 오류 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /** 메시지 텍스트 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MSGNO" )
    private BigDecimal msgno;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="STD_PRICE" )
    private String stdPrice;
    
    /** -----[T_RESULT] END----- */
    
    
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iPltyp
     */
    public String getiPltyp() {
        return iPltyp;
    }
    /**
     * @param iPltyp the iPltyp to set
     */
    public void setiPltyp(String iPltyp) {
        this.iPltyp = iPltyp;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZdpccd
     */
    public String getiZdpccd() {
        return iZdpccd;
    }
    /**
     * @param iZdpccd the iZdpccd to set
     */
    public void setiZdpccd(String iZdpccd) {
        this.iZdpccd = iZdpccd;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the tResult
     */
    public List<?> gettResult() {
        return tResult;
    }
    /**
     * @param tResult the tResult to set
     */
    public void settResult(List<?> tResult) {
        this.tResult = tResult;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zhkcdDesc
     */
    public String getZhkcdDesc() {
        return zhkcdDesc;
    }
    /**
     * @param zhkcdDesc the zhkcdDesc to set
     */
    public void setZhkcdDesc(String zhkcdDesc) {
        this.zhkcdDesc = zhkcdDesc;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zdpccd
     */
    public String getZdpccd() {
        return zdpccd;
    }
    /**
     * @param zdpccd the zdpccd to set
     */
    public void setZdpccd(String zdpccd) {
        this.zdpccd = zdpccd;
    }
    /**
     * @return the zdpccdDesc
     */
    public String getZdpccdDesc() {
        return zdpccdDesc;
    }
    /**
     * @param zdpccdDesc the zdpccdDesc to set
     */
    public void setZdpccdDesc(String zdpccdDesc) {
        this.zdpccdDesc = zdpccdDesc;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the ptext
     */
    public String getPtext() {
        return ptext;
    }
    /**
     * @param ptext the ptext to set
     */
    public void setPtext(String ptext) {
        this.ptext = ptext;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the listPrice
     */
    public String getListPrice() {
        return listPrice;
    }
    /**
     * @param listPrice the listPrice to set
     */
    public void setListPrice(String listPrice) {
        this.listPrice = listPrice;
    }
    /**
     * @return the zqfp
     */
    public String getZqfp() {
        return zqfp;
    }
    /**
     * @param zqfp the zqfp to set
     */
    public void setZqfp(String zqfp) {
        this.zqfp = zqfp;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zcrname
     */
    public String getZcrname() {
        return zcrname;
    }
    /**
     * @param zcrname the zcrname to set
     */
    public void setZcrname(String zcrname) {
        this.zcrname = zcrname;
    }
    /**
     * @return the zudldate
     */
    public Date getZudldate() {
        return zudldate;
    }
    /**
     * @param zudldate the zudldate to set
     */
    public void setZudldate(Date zudldate) {
        this.zudldate = zudldate;
    }
    /**
     * @return the zudname
     */
    public String getZudname() {
        return zudname;
    }
    /**
     * @param zudname the zudname to set
     */
    public void setZudname(String zudname) {
        this.zudname = zudname;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public BigDecimal getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(BigDecimal msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the iLpcon
     */
    public String getiLpcon() {
        return iLpcon;
    }
    /**
     * @param iLpcon the iLpcon to set
     */
    public void setiLpcon(String iLpcon) {
        this.iLpcon = iLpcon;
    }
    /**
     * @return the stdPrice
     */
    public String getStdPrice() {
        return stdPrice;
    }
    /**
     * @param stdPrice the stdPrice to set
     */
    public void setStdPrice(String stdPrice) {
        this.stdPrice = stdPrice;
    }        
    
}
