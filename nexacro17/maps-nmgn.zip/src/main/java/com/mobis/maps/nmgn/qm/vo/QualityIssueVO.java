package com.mobis.maps.nmgn.qm.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityIssueVO.java
 * @Description : Quality Issue
 * @author jiyongdo
 * @since 2020. 3. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 17.     jiyongdo     	최초 생성
 * </pre>
 */

public class QualityIssueVO extends MapsCommSapRfcIfCommVO{
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_BUKRS" )
    private String iBukrs;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CLCODEGR1" )
    private String iClcodegr1;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDATETYPE" )
    private String iZdatetype;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDATE_FROM" )
    private Date iZdateFrom;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDATE_TO" )
    private Date iZdateTo;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDIST" )
    private String iZdist;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDIST_SUB" )
    private String iZdistSub;    
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPRCCODE" )
    private String iZprccode;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZQISSUENO" )
    private String iZqissueno;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQCODE" )
    private String iZreqcode;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSTSCODE" )
    private String iZstscode;
    //-----[ET_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSEQ" )
    private BigDecimal zseq;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZQISSUENO" )
    private String zqissueno;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZREQCODE" )
    private String zreqcode;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZREQCODET" )
    private String zreqcodet;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSTSCODE" )
    private String zstscode;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSTSCODET" )
    private String zstscodet;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZDIST" )
    private String zdist;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZDISTT" )
    private String zdistt;
    /** Company Code */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** Name of Company Code or Company */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="BUKRST" )
    private String bukrst;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPSLOT" )
    private String zpslot;
    /** Quantity */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MENGE" )
    private BigDecimal menge;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MEINS" )
    private String meins;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="CLCODEGR1" )
    private String clcodegr1;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="CLCODEGR1T" )
    private String clcodegr1t;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPRCCODE" )
    private String zprccode;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPRCCODET" )
    private String zprccodet;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSMBDATE" )
    private Date zsmbdate;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPRCDATE" )
    private Date zprcdate;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZLT" )
    private BigDecimal zlt;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPRCID" )
    private String zprcid;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPRCIDT" )
    private String zprcidt;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MSGNO" )
    private BigDecimal msgno;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MATNRT" )
    private String matnrt;    
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZQNA" )
    private String zqna;    
    //-----[ET_DATA] END-----
    /**
     * @return the iBukrs
     */
    public String getiBukrs() {
        return iBukrs;
    }
    /**
     * @param iBukrs the iBukrs to set
     */
    public void setiBukrs(String iBukrs) {
        this.iBukrs = iBukrs;
    }
    /**
     * @return the iClcodegr1
     */
    public String getiClcodegr1() {
        return iClcodegr1;
    }
    /**
     * @param iClcodegr1 the iClcodegr1 to set
     */
    public void setiClcodegr1(String iClcodegr1) {
        this.iClcodegr1 = iClcodegr1;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iZdatetype
     */
    public String getiZdatetype() {
        return iZdatetype;
    }
    /**
     * @param iZdatetype the iZdatetype to set
     */
    public void setiZdatetype(String iZdatetype) {
        this.iZdatetype = iZdatetype;
    }
    /**
     * @return the iZdateFrom
     */
    public Date getiZdateFrom() {
        return iZdateFrom;
    }
    /**
     * @param iZdateFrom the iZdateFrom to set
     */
    public void setiZdateFrom(Date iZdateFrom) {
        this.iZdateFrom = iZdateFrom;
    }
    /**
     * @return the iZdateTo
     */
    public Date getiZdateTo() {
        return iZdateTo;
    }
    /**
     * @param iZdateTo the iZdateTo to set
     */
    public void setiZdateTo(Date iZdateTo) {
        this.iZdateTo = iZdateTo;
    }
    /**
     * @return the iZdist
     */
    public String getiZdist() {
        return iZdist;
    }
    /**
     * @param iZdist the iZdist to set
     */
    public void setiZdist(String iZdist) {
        this.iZdist = iZdist;
    }
    /**
     * @return the iZdistSub
     */
    public String getiZdistSub() {
        return iZdistSub;
    }
    /**
     * @param iZdistSub the iZdistSub to set
     */
    public void setiZdistSub(String iZdistSub) {
        this.iZdistSub = iZdistSub;
    }
    /**
     * @return the iZprccode
     */
    public String getiZprccode() {
        return iZprccode;
    }
    /**
     * @param iZprccode the iZprccode to set
     */
    public void setiZprccode(String iZprccode) {
        this.iZprccode = iZprccode;
    }
    /**
     * @return the iZqissueno
     */
    public String getiZqissueno() {
        return iZqissueno;
    }
    /**
     * @param iZqissueno the iZqissueno to set
     */
    public void setiZqissueno(String iZqissueno) {
        this.iZqissueno = iZqissueno;
    }
    /**
     * @return the iZreqcode
     */
    public String getiZreqcode() {
        return iZreqcode;
    }
    /**
     * @param iZreqcode the iZreqcode to set
     */
    public void setiZreqcode(String iZreqcode) {
        this.iZreqcode = iZreqcode;
    }
    /**
     * @return the iZstscode
     */
    public String getiZstscode() {
        return iZstscode;
    }
    /**
     * @param iZstscode the iZstscode to set
     */
    public void setiZstscode(String iZstscode) {
        this.iZstscode = iZstscode;
    }
    /**
     * @return the zseq
     */
    public BigDecimal getZseq() {
        return zseq;
    }
    /**
     * @param zseq the zseq to set
     */
    public void setZseq(BigDecimal zseq) {
        this.zseq = zseq;
    }
    /**
     * @return the zqissueno
     */
    public String getZqissueno() {
        return zqissueno;
    }
    /**
     * @param zqissueno the zqissueno to set
     */
    public void setZqissueno(String zqissueno) {
        this.zqissueno = zqissueno;
    }
    /**
     * @return the zreqcode
     */
    public String getZreqcode() {
        return zreqcode;
    }
    /**
     * @param zreqcode the zreqcode to set
     */
    public void setZreqcode(String zreqcode) {
        this.zreqcode = zreqcode;
    }
    /**
     * @return the zreqcodet
     */
    public String getZreqcodet() {
        return zreqcodet;
    }
    /**
     * @param zreqcodet the zreqcodet to set
     */
    public void setZreqcodet(String zreqcodet) {
        this.zreqcodet = zreqcodet;
    }
    /**
     * @return the zstscode
     */
    public String getZstscode() {
        return zstscode;
    }
    /**
     * @param zstscode the zstscode to set
     */
    public void setZstscode(String zstscode) {
        this.zstscode = zstscode;
    }
    /**
     * @return the zstscodet
     */
    public String getZstscodet() {
        return zstscodet;
    }
    /**
     * @param zstscodet the zstscodet to set
     */
    public void setZstscodet(String zstscodet) {
        this.zstscodet = zstscodet;
    }
    /**
     * @return the zdist
     */
    public String getZdist() {
        return zdist;
    }
    /**
     * @param zdist the zdist to set
     */
    public void setZdist(String zdist) {
        this.zdist = zdist;
    }
    /**
     * @return the zdistt
     */
    public String getZdistt() {
        return zdistt;
    }
    /**
     * @param zdistt the zdistt to set
     */
    public void setZdistt(String zdistt) {
        this.zdistt = zdistt;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the bukrst
     */
    public String getBukrst() {
        return bukrst;
    }
    /**
     * @param bukrst the bukrst to set
     */
    public void setBukrst(String bukrst) {
        this.bukrst = bukrst;
    }
    /**
     * @return the zpslot
     */
    public String getZpslot() {
        return zpslot;
    }
    /**
     * @param zpslot the zpslot to set
     */
    public void setZpslot(String zpslot) {
        this.zpslot = zpslot;
    }
    /**
     * @return the menge
     */
    public BigDecimal getMenge() {
        return menge;
    }
    /**
     * @param menge the menge to set
     */
    public void setMenge(BigDecimal menge) {
        this.menge = menge;
    }
    /**
     * @return the meins
     */
    public String getMeins() {
        return meins;
    }
    /**
     * @param meins the meins to set
     */
    public void setMeins(String meins) {
        this.meins = meins;
    }
    /**
     * @return the clcodegr1
     */
    public String getClcodegr1() {
        return clcodegr1;
    }
    /**
     * @param clcodegr1 the clcodegr1 to set
     */
    public void setClcodegr1(String clcodegr1) {
        this.clcodegr1 = clcodegr1;
    }
    /**
     * @return the clcodegr1t
     */
    public String getClcodegr1t() {
        return clcodegr1t;
    }
    /**
     * @param clcodegr1t the clcodegr1t to set
     */
    public void setClcodegr1t(String clcodegr1t) {
        this.clcodegr1t = clcodegr1t;
    }
    /**
     * @return the zprccode
     */
    public String getZprccode() {
        return zprccode;
    }
    /**
     * @param zprccode the zprccode to set
     */
    public void setZprccode(String zprccode) {
        this.zprccode = zprccode;
    }
    /**
     * @return the zprccodet
     */
    public String getZprccodet() {
        return zprccodet;
    }
    /**
     * @param zprccodet the zprccodet to set
     */
    public void setZprccodet(String zprccodet) {
        this.zprccodet = zprccodet;
    }
    /**
     * @return the zsmbdate
     */
    public Date getZsmbdate() {
        return zsmbdate;
    }
    /**
     * @param zsmbdate the zsmbdate to set
     */
    public void setZsmbdate(Date zsmbdate) {
        this.zsmbdate = zsmbdate;
    }
    /**
     * @return the zprcdate
     */
    public Date getZprcdate() {
        return zprcdate;
    }
    /**
     * @param zprcdate the zprcdate to set
     */
    public void setZprcdate(Date zprcdate) {
        this.zprcdate = zprcdate;
    }
    /**
     * @return the zlt
     */
    public BigDecimal getZlt() {
        return zlt;
    }
    /**
     * @param zlt the zlt to set
     */
    public void setZlt(BigDecimal zlt) {
        this.zlt = zlt;
    }
    /**
     * @return the zprcid
     */
    public String getZprcid() {
        return zprcid;
    }
    /**
     * @param zprcid the zprcid to set
     */
    public void setZprcid(String zprcid) {
        this.zprcid = zprcid;
    }
    /**
     * @return the zprcidt
     */
    public String getZprcidt() {
        return zprcidt;
    }
    /**
     * @param zprcidt the zprcidt to set
     */
    public void setZprcidt(String zprcidt) {
        this.zprcidt = zprcidt;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public BigDecimal getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(BigDecimal msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the matnrt
     */
    public String getMatnrt() {
        return matnrt;
    }
    /**
     * @param matnrt the matnrt to set
     */
    public void setMatnrt(String matnrt) {
        this.matnrt = matnrt;
    }
    /**
     * @return the zqna
     */
    public String getZqna() {
        return zqna;
    }
    /**
     * @param zqna the zqna to set
     */
    public void setZqna(String zqna) {
        this.zqna = zqna;
    }
}
