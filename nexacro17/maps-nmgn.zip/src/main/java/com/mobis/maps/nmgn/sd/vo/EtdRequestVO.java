package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : EtdRequestVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 8.     jiyongdo     	최초 생성
 * </pre>
 */

public class EtdRequestVO extends MapsCommSapRfcIfCommVO {
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** Request Date */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQDT_FR" )
    private Date iReqdtFr;
    /** Request Date */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQDT_TO" )
    private Date iReqdtTo;
    /** C:Create, U:Change, R:Display, D:Delete */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** Reference No */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDOC_NUM" )
    private String iZdocNum;
    /** H/K Common */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** L-REGION */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZLREGIO" )
    private String iZlregio;
    /** M-REGION */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZMREGIO" )
    private String iZmregio;
    /** 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_E" )
    private String iZordnoE;
    /** Process Status */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPROC_FLAG" )
    private String iZprocFlag;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    /** S-REGION */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSREGIO" )
    private String iZsregio;
    //-----[IT_HEAD] START-----
    /** Category */
    @MapsRfcMappper( targetName="IT_HEAD", ipttSe="E", fieldKey="ZCATEGORY" )
    private String zcategory;
    /** Reference No */
    @MapsRfcMappper( targetName="IT_HEAD|IT_ITEM", ipttSe="E", fieldKey="ZDOC_NUM" )
    private String zdocNum;
    /** Subject */
    @MapsRfcMappper( targetName="IT_HEAD", ipttSe="E", fieldKey="ZSUBJECT" )
    private String zsubject;
    /** Re-Request */
    @MapsRfcMappper( targetName="IT_HEAD|IT_ITEM", ipttSe="E", fieldKey="ZRE_REQUEST" )
    private String zreRequest;
    /** Request Date */
    @MapsRfcMappper( targetName="IT_HEAD", ipttSe="E", fieldKey="ZREQ_DT" )
    private Date zreqDt;
    /** Process Status */
    @MapsRfcMappper( targetName="IT_HEAD|IT_ITEM", ipttSe="E", fieldKey="ZPROC_FLAG" )
    private String zprocFlag;
    //-----[IT_HEAD] END-----
    //-----[IT_ITEM] START-----
    /** Seq. No. */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZSEQ_NUM" )
    private String zseqNum;
    /** 오더번호 */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZORDLN" )
    private String zordln;
    /** 오더 Line Suffix */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZORDLS" )
    private String zordls;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** 자재내역 */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** 기본 단위 */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="MEINS" )
    private String meins;
    /** Back Order Qty */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZBOQTY" )
    private BigDecimal zboqty;
    /** In Process ETD (Original) */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZIN_ETD_ORI" )
    private Date zinEtdOri;
    /** In Process Qty (Original) */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZIN_QTY_ORI" )
    private BigDecimal zinQtyOri;
    /** B/O ETD (Original) */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZBO_ETD_ORI" )
    private Date zboEtdOri;
    /** B/O Qty (Original) */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZBO_QTY_ORI" )
    private BigDecimal zboQtyOri;
    /** In Process ETD (Changed) */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZIN_ETD_CHG" )
    private Date zinEtdChg;
    /** In Process Qty (Changed) */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZIN_QTY_CHG" )
    private BigDecimal zinQtyChg;
    /** B/O ETD (Changed) */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZBO_ETD_CHG" )
    private Date zboEtdChg;
    /** B/O Qty (Changed) */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZBO_QTY_CHG" )
    private BigDecimal zboQtyChg;
    /** Shipped Date */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZSHIP_DT" )
    private Date zshipDt;
    /** Reply Date */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZREPL_DT" )
    private Date zreplDt;
    /** Lead Time */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZLTIME" )
    private BigDecimal zltime;
    /** Supply Problem Code */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZPROBLEM" )
    private String zproblem;
    /** Re-Request */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZRE_REQUEST_E" )
    private String zreRequestE;
    /** REMARK */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZREMARK" )
    private String zremark;
    /** ZPROBLEM_R */
    @MapsRfcMappper( targetName="IT_ITEM", ipttSe="E", fieldKey="ZPROBLEM_R" )
    private String zproblemR;
    
    private String chkXn;
    //-----[IT_ITEM] END-----
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iReqdtFr
     */
    public Date getiReqdtFr() {
        return iReqdtFr;
    }
    /**
     * @param iReqdtFr the iReqdtFr to set
     */
    public void setiReqdtFr(Date iReqdtFr) {
        this.iReqdtFr = iReqdtFr;
    }
    /**
     * @return the iReqdtTo
     */
    public Date getiReqdtTo() {
        return iReqdtTo;
    }
    /**
     * @param iReqdtTo the iReqdtTo to set
     */
    public void setiReqdtTo(Date iReqdtTo) {
        this.iReqdtTo = iReqdtTo;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZdocNum
     */
    public String getiZdocNum() {
        return iZdocNum;
    }
    /**
     * @param iZdocNum the iZdocNum to set
     */
    public void setiZdocNum(String iZdocNum) {
        this.iZdocNum = iZdocNum;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZlregio
     */
    public String getiZlregio() {
        return iZlregio;
    }
    /**
     * @param iZlregio the iZlregio to set
     */
    public void setiZlregio(String iZlregio) {
        this.iZlregio = iZlregio;
    }
    /**
     * @return the iZmregio
     */
    public String getiZmregio() {
        return iZmregio;
    }
    /**
     * @param iZmregio the iZmregio to set
     */
    public void setiZmregio(String iZmregio) {
        this.iZmregio = iZmregio;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the iZprocFlag
     */
    public String getiZprocFlag() {
        return iZprocFlag;
    }
    /**
     * @param iZprocFlag the iZprocFlag to set
     */
    public void setiZprocFlag(String iZprocFlag) {
        this.iZprocFlag = iZprocFlag;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the iZsregio
     */
    public String getiZsregio() {
        return iZsregio;
    }
    /**
     * @param iZsregio the iZsregio to set
     */
    public void setiZsregio(String iZsregio) {
        this.iZsregio = iZsregio;
    }
    /**
     * @return the zcategory
     */
    public String getZcategory() {
        return zcategory;
    }
    /**
     * @param zcategory the zcategory to set
     */
    public void setZcategory(String zcategory) {
        this.zcategory = zcategory;
    }
    /**
     * @return the zdocNum
     */
    public String getZdocNum() {
        return zdocNum;
    }
    /**
     * @param zdocNum the zdocNum to set
     */
    public void setZdocNum(String zdocNum) {
        this.zdocNum = zdocNum;
    }
    /**
     * @return the zsubject
     */
    public String getZsubject() {
        return zsubject;
    }
    /**
     * @param zsubject the zsubject to set
     */
    public void setZsubject(String zsubject) {
        this.zsubject = zsubject;
    }
    /**
     * @return the zreRequest
     */
    public String getZreRequest() {
        return zreRequest;
    }
    /**
     * @param zreRequest the zreRequest to set
     */
    public void setZreRequest(String zreRequest) {
        this.zreRequest = zreRequest;
    }
    /**
     * @return the zreqDt
     */
    public Date getZreqDt() {
        return zreqDt;
    }
    /**
     * @param zreqDt the zreqDt to set
     */
    public void setZreqDt(Date zreqDt) {
        this.zreqDt = zreqDt;
    }
    /**
     * @return the zprocFlag
     */
    public String getZprocFlag() {
        return zprocFlag;
    }
    /**
     * @param zprocFlag the zprocFlag to set
     */
    public void setZprocFlag(String zprocFlag) {
        this.zprocFlag = zprocFlag;
    }
    /**
     * @return the zseqNum
     */
    public String getZseqNum() {
        return zseqNum;
    }
    /**
     * @param zseqNum the zseqNum to set
     */
    public void setZseqNum(String zseqNum) {
        this.zseqNum = zseqNum;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zordls
     */
    public String getZordls() {
        return zordls;
    }
    /**
     * @param zordls the zordls to set
     */
    public void setZordls(String zordls) {
        this.zordls = zordls;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the meins
     */
    public String getMeins() {
        return meins;
    }
    /**
     * @param meins the meins to set
     */
    public void setMeins(String meins) {
        this.meins = meins;
    }
    /**
     * @return the zboqty
     */
    public BigDecimal getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(BigDecimal zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zinEtdOri
     */
    public Date getZinEtdOri() {
        return zinEtdOri;
    }
    /**
     * @param zinEtdOri the zinEtdOri to set
     */
    public void setZinEtdOri(Date zinEtdOri) {
        this.zinEtdOri = zinEtdOri;
    }
    /**
     * @return the zinQtyOri
     */
    public BigDecimal getZinQtyOri() {
        return zinQtyOri;
    }
    /**
     * @param zinQtyOri the zinQtyOri to set
     */
    public void setZinQtyOri(BigDecimal zinQtyOri) {
        this.zinQtyOri = zinQtyOri;
    }
    /**
     * @return the zboEtdOri
     */
    public Date getZboEtdOri() {
        return zboEtdOri;
    }
    /**
     * @param zboEtdOri the zboEtdOri to set
     */
    public void setZboEtdOri(Date zboEtdOri) {
        this.zboEtdOri = zboEtdOri;
    }
    /**
     * @return the zboQtyOri
     */
    public BigDecimal getZboQtyOri() {
        return zboQtyOri;
    }
    /**
     * @param zboQtyOri the zboQtyOri to set
     */
    public void setZboQtyOri(BigDecimal zboQtyOri) {
        this.zboQtyOri = zboQtyOri;
    }
    /**
     * @return the zinEtdChg
     */
    public Date getZinEtdChg() {
        return zinEtdChg;
    }
    /**
     * @param zinEtdChg the zinEtdChg to set
     */
    public void setZinEtdChg(Date zinEtdChg) {
        this.zinEtdChg = zinEtdChg;
    }
    /**
     * @return the zinQtyChg
     */
    public BigDecimal getZinQtyChg() {
        return zinQtyChg;
    }
    /**
     * @param zinQtyChg the zinQtyChg to set
     */
    public void setZinQtyChg(BigDecimal zinQtyChg) {
        this.zinQtyChg = zinQtyChg;
    }
    /**
     * @return the zboEtdChg
     */
    public Date getZboEtdChg() {
        return zboEtdChg;
    }
    /**
     * @param zboEtdChg the zboEtdChg to set
     */
    public void setZboEtdChg(Date zboEtdChg) {
        this.zboEtdChg = zboEtdChg;
    }
    /**
     * @return the zboQtyChg
     */
    public BigDecimal getZboQtyChg() {
        return zboQtyChg;
    }
    /**
     * @param zboQtyChg the zboQtyChg to set
     */
    public void setZboQtyChg(BigDecimal zboQtyChg) {
        this.zboQtyChg = zboQtyChg;
    }
    /**
     * @return the zshipDt
     */
    public Date getZshipDt() {
        return zshipDt;
    }
    /**
     * @param zshipDt the zshipDt to set
     */
    public void setZshipDt(Date zshipDt) {
        this.zshipDt = zshipDt;
    }
    /**
     * @return the zreplDt
     */
    public Date getZreplDt() {
        return zreplDt;
    }
    /**
     * @param zreplDt the zreplDt to set
     */
    public void setZreplDt(Date zreplDt) {
        this.zreplDt = zreplDt;
    }
    /**
     * @return the zltime
     */
    public BigDecimal getZltime() {
        return zltime;
    }
    /**
     * @param zltime the zltime to set
     */
    public void setZltime(BigDecimal zltime) {
        this.zltime = zltime;
    }
    /**
     * @return the zproblem
     */
    public String getZproblem() {
        return zproblem;
    }
    /**
     * @param zproblem the zproblem to set
     */
    public void setZproblem(String zproblem) {
        this.zproblem = zproblem;
    }
    /**
     * @return the zreRequestE
     */
    public String getZreRequestE() {
        return zreRequestE;
    }
    /**
     * @param zreRequestE the zreRequestE to set
     */
    public void setZreRequestE(String zreRequestE) {
        this.zreRequestE = zreRequestE;
    }
    /**
     * @return the zremark
     */
    public String getZremark() {
        return zremark;
    }
    /**
     * @param zremark the zremark to set
     */
    public void setZremark(String zremark) {
        this.zremark = zremark;
    }
    /**
     * @return the chkXn
     */
    public String getChkXn() {
        return chkXn;
    }
    /**
     * @param chkXn the chkXn to set
     */
    public void setChkXn(String chkXn) {
        this.chkXn = chkXn;
    }
    /**
     * @return the zproblemR
     */
    public String getZproblemR() {
        return zproblemR;
    }
    /**
     * @param zproblemR the zproblemR to set
     */
    public void setZproblemR(String zproblemR) {
        this.zproblemR = zproblemR;
    }
    
}
