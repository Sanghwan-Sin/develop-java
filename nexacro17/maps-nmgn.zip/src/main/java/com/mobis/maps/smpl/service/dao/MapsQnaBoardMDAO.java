package com.mobis.maps.smpl.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.smpl.vo.MapsQnaBoardVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsQnaBoardMDAO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048105
 * @since 2020. 4. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 7.     DT048105     	최초 생성
 * </pre>
 */

@Mapper("mapsQnaBoardMDAO")
public interface MapsQnaBoardMDAO {

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    List<MapsQnaBoardVO> selectQnaBoardList(MapsQnaBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsQnaBoardVO selectQnaBoardNewList(MapsQnaBoardVO inputVO);
    
    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    void updateQnaBoardCount(MapsQnaBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int insertQnaBoard(MapsQnaBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int updateQnaBoard(MapsQnaBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int deleteQnaBoard(MapsQnaBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsQnaBoardVO selectContId(MapsQnaBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsQnaBoardVO selectSeq(MapsQnaBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int insertQnaBoardRply(MapsQnaBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     */
    void deleteAtchFileAll(MapsQnaBoardVO inputVO);

}
