package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.DngrsGoodsService;
import com.mobis.maps.nmgn.sd.vo.DngrsGoodsVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DngrsGoodsServiceImpl.java
 * @Description : ZJSDR80140 UD DOT/ EU BAM - Dangerous Goods (위험물)
 * @author hong.minho
 * @since 2020. 5. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 11.     hong.minho     	최초 생성
 * </pre>
 */

@Service("dngrsGoodsService")
public class DngrsGoodsServiceImpl extends HService implements DngrsGoodsService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.DngrsGoodsService#selectDangerGood(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.DngrsGoodsVO)
     */
    @Override
    public List<DngrsGoodsVO> selectDangerGood(LoginInfoVO loginVo, DngrsGoodsVO params) throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_S_DANGERGOOD;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** IFCOMM 셋팅
        if (logger.isDebugEnabled()) {logger.debug("*** IFCOMM 셋팅 ");}
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** IMPORT 셋팅
        if (logger.isDebugEnabled()) {logger.debug("*** IMPORT 셋팅");}
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** IT_MATNR 셋팅
        if (logger.isDebugEnabled()) {logger.debug("*** IT_MATNR 셋팅");}
        JCoTable jcoTbl = func.getImportStructureTable("IT_MATNR");
        jcoTbl.appendRow();
        jcoTbl.setValue(0, params.getiMatnr());
        
        
        //*** RFC 호출
        if (logger.isDebugEnabled()) {logger.debug("*** RFC 호출");}
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        if (logger.isDebugEnabled()) {logger.debug("*** RFC 호출결과 정보 추출");}
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        if (logger.isDebugEnabled()) {logger.debug("*** params.getMsgType():" + params.getMsgType());}
        
        if ("E".equals(params.getMsgType())) {
            return null;
        }
        
        //*** 조회결과
        List<DngrsGoodsVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", params, DngrsGoodsVO.class);

        return list;
    }

}
