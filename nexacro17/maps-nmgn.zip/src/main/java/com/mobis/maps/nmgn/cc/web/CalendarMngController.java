package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.CalendarMngService;
import com.mobis.maps.nmgn.cc.vo.CalendarMngVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarMngController.java
 * @Description : Work Calendat Manage
 * @author 이수지
 * @since 2020. 5. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 25.       이수지                최초 생성
 * </pre>
 */

@Controller
public class CalendarMngController extends HController {

    @Resource(name = "calendarMngService")
    private CalendarMngService calendarMngService;
    
    /**
     * selectCalendarMng
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectCalendarMngList.do")
    public NexacroResult selectCalendarMngList(@ParamDataSet(name="dsInput") CalendarMngVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<CalendarMngVO> list = calendarMngService.selectCalendarMngList(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * multiCalendarMng
     *
     * @param params
     * @param results
     * @return 
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/multiCalendarMng.do")
    public NexacroResult multiCalendarMng(@ParamDataSet(name="dsInput") List <CalendarMngVO> params
                                        , @ParamDataSet(name="dsInput2") CalendarMngVO params2
                                        , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        for (int idx = 0; idx < params.size(); idx++) {
            params.get(idx).setSalesOrg(params2.getSalesOrg()); // 조직코드
        }

        calendarMngService.multiCalendarMng(loginInfo, params);

        return result;
    }
    
}
