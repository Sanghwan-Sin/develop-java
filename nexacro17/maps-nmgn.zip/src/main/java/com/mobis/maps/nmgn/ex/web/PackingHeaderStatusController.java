package com.mobis.maps.nmgn.ex.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.service.PackingHeaderStatusService;
import com.mobis.maps.nmgn.ex.vo.PackingHeaderStatusVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingHeaderStatusController.java
 * @Description : ZJEXR00170 Packing Header Status
 * @author 이수지
 * @since 2020. 2. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 4.       이수지                 최초 생성
 * </pre>
 */

@Controller
public class PackingHeaderStatusController extends HController {

    @Resource(name = "packingHeaderStatusService")
    private PackingHeaderStatusService packingHeaderStatusService;

    /**
     * selectPackingHeaderStatus
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectPackingHeaderStatus.do")
    public NexacroResult selectPackingHeaderStatus(@ParamDataSet(name="dsInput") PackingHeaderStatusVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PackingHeaderStatusVO> list = packingHeaderStatusService.selectPackingHeaderStatus(loginInfo, params);

        if (list.size() > 0) {
            list.get(0).setCaseNo(params.getiCaseNo());
        }        
         
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectPackingHeaderStatusExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectPackingHeaderStatusExcelDown.do")
    public NexacroResult selectPackingHeaderStatusExcelDown(@ParamDataSet(name="dsInput") PackingHeaderStatusVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<PackingHeaderStatusVO> list = packingHeaderStatusService.selectPackingHeaderStatus(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
}
