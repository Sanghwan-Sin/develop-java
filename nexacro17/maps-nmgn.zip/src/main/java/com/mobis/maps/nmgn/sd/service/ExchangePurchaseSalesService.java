package com.mobis.maps.nmgn.sd.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.ExchangePurchaseDetailVO;
import com.mobis.maps.nmgn.sd.vo.ExchangePurchaseSalesVO;
import com.mobis.maps.nmgn.sd.vo.PartInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ExchangePurchaseSalesService.java
 * @Description : Dist. Exchange Purchase Sales List/Add
 * @author jiyongdo
 * @since 2020. 2. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 19.     jiyongdo     	최초 생성
 * </pre>
 */

public interface ExchangePurchaseSalesService {

    /**
     * 리스트 조회
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectExchangePurchaseSalesList(LoginInfoVO loginInfo, ExchangePurchaseSalesVO paramVO) throws Exception;

    /**
     * 디테일 조회
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectDistExchangeDetailList(LoginInfoVO loginInfo, ExchangePurchaseDetailVO paramVO) throws Exception;

    /**
     * 부품정보 조회
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectPartInfoList(LoginInfoVO loginInfo, PartInfoVO paramVO) throws Exception;

    /**
     * 저장
     *
     * @param paramVO
     * @param headerVO
     * @param paramList
     * @param loginInfo
     * @return
     */
    Map<String, Object> multiSaveDistExchangeDetailList(ExchangePurchaseDetailVO paramVO, ExchangePurchaseDetailVO headerVO,
            List<ExchangePurchaseDetailVO> paramList, LoginInfoVO loginInfo) throws Exception;

    /**
     * 삭제
     *
     * @param paramVO
     * @param loginInfo
     * @return
     */
    Map<String, Object> deleteDistExchangeDetailList(ExchangePurchaseDetailVO paramVO, LoginInfoVO loginInfo) throws Exception;

}
