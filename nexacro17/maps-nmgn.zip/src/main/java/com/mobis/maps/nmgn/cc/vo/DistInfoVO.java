package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : DistInfoVO.java
 * @Description : DistInfoVO
 * @author ha.jeongryeong
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.    ha.jeongryeong      최초 생성
 *  2020.03. 27.    ChoKyungHo          To-be 테이블 변경
 *               </pre>
 */

public class DistInfoVO extends MapsCommSapRfcIfCommVO {

    /* 조회조건 */
    private String iVkorg;
    private String iZlregio;
    private String iZmregio;
    private String iZsregio;
    private String iKvgr1;
    private String iDistCd;
    
    /* 조회결과 */
    private int rnum;
    private String zsacutm;
    private String zkunam;
    private String land1;
    private String zsregio;
    private String vkorg;
    private String zkunnr;
    private String zkunn2;
    private String vtweg;
    
    
    private String zsalesPer; // 담당직원
    private String zsalesPerNm; // 담당직원명
    
    
    private String stras;
    private String zbubign;
    private String franchise1;
    private String franchise2;
    private String franchise3;
    private String franchise4;
    private String kunnr;
    
    private String chkYn;
    private String chgFlag;
    private String chgName;
    private String staffName;
    private String telNum;
    private String faxNum;
    private String email;
    private String staffPhoto;
    private String emailRecv;
    private String mailAll;
    private String mailOrd;
    private String mailCla;
    private String mailAcc;
    private String mailDow;
    private String mailCir;
    private String mailPay;
    private String mailMon;
    private String distCode;
    
    private String code;
    private String codeNm;
    
    //첨부파일키
    private String atchSe;
    private String seq;
    
    private String president;
    private String partMngr;
    private String partEmail;
    private String partTel;
    private String partFax;
    private int seqNum;
    private String seqNumStr;
    private String idFlag;
    
    //첨부파일 정보
    private String fileId;
    private String originalFileName;
    private String storedFileName;
    private String fileSize;
    private String folderPath;
    private String fileNm;
    
    
    // Mailing Classification
    private String mailTp0;
    private String mailTp1;
    private String mailTp2;
    private String mailTp3;
    private String mailTp4;
    private String mailTp5;
    private String mailTp6;
    private String mailTp7;
    private String mailTp8;
    private String mailTp9;
    private String mailTp10;
    private String mailTp11;
    private String mailTp12;
    private String mailTp13;
    private String mailTp14;
    private String mailTp15;
    private String mailTp16;
    private String mailTp17;
    private String mailTp18;
    private String mailTp19;
    private String mailTp20;
    private String mailTp21;
    private String mailTp22;
    private String mailTp23;
    private String mailTp24;
    private String mailTp25;
    private String mailTp26;
    private String mailTp27;
    private String mailTp28;
    private String mailTp29;
    private String mailTp30;
    private String mailTp31;
    private String mailTp32;
    private String mailTp33;
    private String mailTp34;
    private String mailTp35;
    private String mailTp36;
    private String mailTp37;
    private String mailTp38;
    private String mailTp39;
    private String mailTp40;
    private String mailTp41;
    private String mailTp42;
    private String mailTp43;
    private String mailTp44;
    private String mailTp45;
    private String mailTp46;
    private String mailTp47;
    private String mailTp48;
    private String mailTp49;
    private String mailTp50;
    private String mailTp51;
    private String mailTp52;
    private String mailTp53;
    private String mailTp54;
    private String mailTp55;
    private String mailTp56;
    private String mailTp57;
    private String mailTp58;
    private String mailTp59;
    private String mailTp60;
    private String mailTp61;
    private String mailTp62;
    private String mailTp63;
    private String mailTp64;
    private String mailTp65;
    private String mailTp66;
    private String mailTp67;
    private String mailTp68;
    private String mailTp69;
    private String mailTp70;
    private String mailTp71;
    private String mailTp72;
    private String mailTp73;
    private String mailTp74;
    private String mailTp75;
    private String mailTp76;
    private String mailTp77;
    private String mailTp78;
    private String mailTp79;
    private String mailTp80;
    private String mailTp81;
    private String mailTp82;
    private String mailTp83;
    private String mailTp84;
    private String mailTp85;
    private String mailTp86;
    private String mailTp87;
    private String mailTp88;
    private String mailTp89;
    private String mailTp90;
    private String mailTp91;
    private String mailTp92;
    private String mailTp93;
    private String mailTp94;
    private String mailTp95;
    private String mailTp96;
    private String mailTp97;
    private String mailTp98;
    private String mailTp99;
    
    
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iZlregio
     */
    public String getiZlregio() {
        return iZlregio;
    }
    /**
     * @param iZlregio the iZlregio to set
     */
    public void setiZlregio(String iZlregio) {
        this.iZlregio = iZlregio;
    }
    /**
     * @return the iZmregio
     */
    public String getiZmregio() {
        return iZmregio;
    }
    /**
     * @param iZmregio the iZmregio to set
     */
    public void setiZmregio(String iZmregio) {
        this.iZmregio = iZmregio;
    }
    /**
     * @return the iZsregio
     */
    public String getiZsregio() {
        return iZsregio;
    }
    /**
     * @param iZsregio the iZsregio to set
     */
    public void setiZsregio(String iZsregio) {
        this.iZsregio = iZsregio;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iDistCd
     */
    public String getiDistCd() {
        return iDistCd;
    }
    /**
     * @param iDistCd the iDistCd to set
     */
    public void setiDistCd(String iDistCd) {
        this.iDistCd = iDistCd;
    }
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the zkunam
     */
    public String getZkunam() {
        return zkunam;
    }
    /**
     * @param zkunam the zkunam to set
     */
    public void setZkunam(String zkunam) {
        this.zkunam = zkunam;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the zsregio
     */
    public String getZsregio() {
        return zsregio;
    }
    /**
     * @param zsregio the zsregio to set
     */
    public void setZsregio(String zsregio) {
        this.zsregio = zsregio;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the zkunnr
     */
    public String getZkunnr() {
        return zkunnr;
    }
    /**
     * @param zkunnr the zkunnr to set
     */
    public void setZkunnr(String zkunnr) {
        this.zkunnr = zkunnr;
    }
    /**
     * @return the zkunn2
     */
    public String getZkunn2() {
        return zkunn2;
    }
    /**
     * @param zkunn2 the zkunn2 to set
     */
    public void setZkunn2(String zkunn2) {
        this.zkunn2 = zkunn2;
    }
    /**
     * @return the stras
     */
    public String getStras() {
        return stras;
    }
    /**
     * @param stras the stras to set
     */
    public void setStras(String stras) {
        this.stras = stras;
    }
    /**
     * @return the zbubign
     */
    public String getZbubign() {
        return zbubign;
    }
    /**
     * @param zbubign the zbubign to set
     */
    public void setZbubign(String zbubign) {
        this.zbubign = zbubign;
    }
    
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the chgFlag
     */
    public String getChgFlag() {
        return chgFlag;
    }
    /**
     * @param chgFlag the chgFlag to set
     */
    public void setChgFlag(String chgFlag) {
        this.chgFlag = chgFlag;
    }
    /**
     * @return the chgName
     */
    public String getChgName() {
        return chgName;
    }
    /**
     * @param chgName the chgName to set
     */
    public void setChgName(String chgName) {
        this.chgName = chgName;
    }
    /**
     * @return the staffName
     */
    public String getStaffName() {
        return staffName;
    }
    /**
     * @param staffName the staffName to set
     */
    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }
    /**
     * @return the telNum
     */
    public String getTelNum() {
        return telNum;
    }
    /**
     * @param telNum the telNum to set
     */
    public void setTelNum(String telNum) {
        this.telNum = telNum;
    }
    /**
     * @return the faxNum
     */
    public String getFaxNum() {
        return faxNum;
    }
    /**
     * @param faxNum the faxNum to set
     */
    public void setFaxNum(String faxNum) {
        this.faxNum = faxNum;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the staffPhoto
     */
    public String getStaffPhoto() {
        return staffPhoto;
    }
    /**
     * @param staffPhoto the staffPhoto to set
     */
    public void setStaffPhoto(String staffPhoto) {
        this.staffPhoto = staffPhoto;
    }
    /**
     * @return the emailRecv
     */
    public String getEmailRecv() {
        return emailRecv;
    }
    /**
     * @param emailRecv the emailRecv to set
     */
    public void setEmailRecv(String emailRecv) {
        this.emailRecv = emailRecv;
    }
    /**
     * @return the mailAll
     */
    public String getMailAll() {
        return mailAll;
    }
    /**
     * @param mailAll the mailAll to set
     */
    public void setMailAll(String mailAll) {
        this.mailAll = mailAll;
    }
    /**
     * @return the mailOrd
     */
    public String getMailOrd() {
        return mailOrd;
    }
    /**
     * @param mailOrd the mailOrd to set
     */
    public void setMailOrd(String mailOrd) {
        this.mailOrd = mailOrd;
    }
    /**
     * @return the mailCla
     */
    public String getMailCla() {
        return mailCla;
    }
    /**
     * @param mailCla the mailCla to set
     */
    public void setMailCla(String mailCla) {
        this.mailCla = mailCla;
    }
    /**
     * @return the mailAcc
     */
    public String getMailAcc() {
        return mailAcc;
    }
    /**
     * @param mailAcc the mailAcc to set
     */
    public void setMailAcc(String mailAcc) {
        this.mailAcc = mailAcc;
    }
    /**
     * @return the mailDow
     */
    public String getMailDow() {
        return mailDow;
    }
    /**
     * @param mailDow the mailDow to set
     */
    public void setMailDow(String mailDow) {
        this.mailDow = mailDow;
    }
    /**
     * @return the mailCir
     */
    public String getMailCir() {
        return mailCir;
    }
    /**
     * @param mailCir the mailCir to set
     */
    public void setMailCir(String mailCir) {
        this.mailCir = mailCir;
    }
    /**
     * @return the mailPay
     */
    public String getMailPay() {
        return mailPay;
    }
    /**
     * @param mailPay the mailPay to set
     */
    public void setMailPay(String mailPay) {
        this.mailPay = mailPay;
    }
    /**
     * @return the mailMon
     */
    public String getMailMon() {
        return mailMon;
    }
    /**
     * @param mailMon the mailMon to set
     */
    public void setMailMon(String mailMon) {
        this.mailMon = mailMon;
    }
    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
    
    /**
     * @return the codeNm
     */
    public String getCodeNm() {
        return codeNm;
    }
    /**
     * @param codeNm the codeNm to set
     */
    public void setCodeNm(String codeNm) {
        this.codeNm = codeNm;
    }
    /**
     * @return the atchSe
     */
    public String getAtchSe() {
        return atchSe;
    }
    /**
     * @param atchSe the atchSe to set
     */
    public void setAtchSe(String atchSe) {
        this.atchSe = atchSe;
    }
    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }
    /**
     * @return the president
     */
    public String getPresident() {
        return president;
    }
    /**
     * @param president the president to set
     */
    public void setPresident(String president) {
        this.president = president;
    }
    /**
     * @return the partMngr
     */
    public String getPartMngr() {
        return partMngr;
    }
    /**
     * @param partMngr the partMngr to set
     */
    public void setPartMngr(String partMngr) {
        this.partMngr = partMngr;
    }
    /**
     * @return the partEmail
     */
    public String getPartEmail() {
        return partEmail;
    }
    /**
     * @param partEmail the partEmail to set
     */
    public void setPartEmail(String partEmail) {
        this.partEmail = partEmail;
    }
    /**
     * @return the partTel
     */
    public String getPartTel() {
        return partTel;
    }
    /**
     * @param partTel the partTel to set
     */
    public void setPartTel(String partTel) {
        this.partTel = partTel;
    }
    /**
     * @return the partFax
     */
    public String getPartFax() {
        return partFax;
    }
    /**
     * @param partFax the partFax to set
     */
    public void setPartFax(String partFax) {
        this.partFax = partFax;
    }
    /**
     * @return the seqNum
     */
    public int getSeqNum() {
        return seqNum;
    }
    /**
     * @param seqNum the seqNum to set
     */
    public void setSeqNum(int seqNum) {
        this.seqNum = seqNum;
    }
    /**
     * @return the idFlag
     */
    public String getIdFlag() {
        return idFlag;
    }
    /**
     * @param idFlag the idFlag to set
     */
    public void setIdFlag(String idFlag) {
        this.idFlag = idFlag;
    }
    /**
     * @return the fileId
     */
    public String getFileId() {
        return fileId;
    }
    /**
     * @param fileId the fileId to set
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
    /**
     * @return the originalFileName
     */
    public String getOriginalFileName() {
        return originalFileName;
    }
    /**
     * @param originalFileName the originalFileName to set
     */
    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }
    /**
     * @return the storedFileName
     */
    public String getStoredFileName() {
        return storedFileName;
    }
    /**
     * @param storedFileName the storedFileName to set
     */
    public void setStoredFileName(String storedFileName) {
        this.storedFileName = storedFileName;
    }
    /**
     * @return the fileSize
     */
    public String getFileSize() {
        return fileSize;
    }
    /**
     * @param fileSize the fileSize to set
     */
    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }
    /**
     * @return the folderPath
     */
    public String getFolderPath() {
        return folderPath;
    }
    /**
     * @param folderPath the folderPath to set
     */
    public void setFolderPath(String folderPath) {
        this.folderPath = folderPath;
    }
    /**
     * @return the fileNm
     */
    public String getFileNm() {
        return fileNm;
    }
    /**
     * @param fileNm the fileNm to set
     */
    public void setFileNm(String fileNm) {
        this.fileNm = fileNm;
    }
    /**
     * @return the chkYn
     */
    public String getChkYn() {
        return chkYn;
    }
    /**
     * @param chkYn the chkYn to set
     */
    public void setChkYn(String chkYn) {
        this.chkYn = chkYn;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the franchise1
     */
    public String getFranchise1() {
        return franchise1;
    }
    /**
     * @param franchise1 the franchise1 to set
     */
    public void setFranchise1(String franchise1) {
        this.franchise1 = franchise1;
    }
    /**
     * @return the franchise2
     */
    public String getFranchise2() {
        return franchise2;
    }
    /**
     * @param franchise2 the franchise2 to set
     */
    public void setFranchise2(String franchise2) {
        this.franchise2 = franchise2;
    }
    /**
     * @return the franchise3
     */
    public String getFranchise3() {
        return franchise3;
    }
    /**
     * @param franchise3 the franchise3 to set
     */
    public void setFranchise3(String franchise3) {
        this.franchise3 = franchise3;
    }
    /**
     * @return the franchise4
     */
    public String getFranchise4() {
        return franchise4;
    }
    /**
     * @param franchise4 the franchise4 to set
     */
    public void setFranchise4(String franchise4) {
        this.franchise4 = franchise4;
    }
    /**
     * @return the distCode
     */
    public String getDistCode() {
        return distCode;
    }
    /**
     * @param distCode the distCode to set
     */
    public void setDistCode(String distCode) {
        this.distCode = distCode;
    }
    /**
     * @return the mailTp0
     */
    public String getMailTp0() {
        return mailTp0;
    }
    /**
     * @param mailTp0 the mailTp0 to set
     */
    public void setMailTp0(String mailTp0) {
        this.mailTp0 = mailTp0;
    }
    /**
     * @return the mailTp1
     */
    public String getMailTp1() {
        return mailTp1;
    }
    /**
     * @param mailTp1 the mailTp1 to set
     */
    public void setMailTp1(String mailTp1) {
        this.mailTp1 = mailTp1;
    }
    /**
     * @return the mailTp2
     */
    public String getMailTp2() {
        return mailTp2;
    }
    /**
     * @param mailTp2 the mailTp2 to set
     */
    public void setMailTp2(String mailTp2) {
        this.mailTp2 = mailTp2;
    }
    /**
     * @return the mailTp3
     */
    public String getMailTp3() {
        return mailTp3;
    }
    /**
     * @param mailTp3 the mailTp3 to set
     */
    public void setMailTp3(String mailTp3) {
        this.mailTp3 = mailTp3;
    }
    /**
     * @return the mailTp4
     */
    public String getMailTp4() {
        return mailTp4;
    }
    /**
     * @param mailTp4 the mailTp4 to set
     */
    public void setMailTp4(String mailTp4) {
        this.mailTp4 = mailTp4;
    }
    /**
     * @return the mailTp5
     */
    public String getMailTp5() {
        return mailTp5;
    }
    /**
     * @param mailTp5 the mailTp5 to set
     */
    public void setMailTp5(String mailTp5) {
        this.mailTp5 = mailTp5;
    }
    /**
     * @return the mailTp6
     */
    public String getMailTp6() {
        return mailTp6;
    }
    /**
     * @param mailTp6 the mailTp6 to set
     */
    public void setMailTp6(String mailTp6) {
        this.mailTp6 = mailTp6;
    }
    /**
     * @return the mailTp7
     */
    public String getMailTp7() {
        return mailTp7;
    }
    /**
     * @param mailTp7 the mailTp7 to set
     */
    public void setMailTp7(String mailTp7) {
        this.mailTp7 = mailTp7;
    }
    /**
     * @return the mailTp8
     */
    public String getMailTp8() {
        return mailTp8;
    }
    /**
     * @param mailTp8 the mailTp8 to set
     */
    public void setMailTp8(String mailTp8) {
        this.mailTp8 = mailTp8;
    }
    /**
     * @return the mailTp9
     */
    public String getMailTp9() {
        return mailTp9;
    }
    /**
     * @param mailTp9 the mailTp9 to set
     */
    public void setMailTp9(String mailTp9) {
        this.mailTp9 = mailTp9;
    }
    /**
     * @return the mailTp10
     */
    public String getMailTp10() {
        return mailTp10;
    }
    /**
     * @param mailTp10 the mailTp10 to set
     */
    public void setMailTp10(String mailTp10) {
        this.mailTp10 = mailTp10;
    }
    /**
     * @return the mailTp11
     */
    public String getMailTp11() {
        return mailTp11;
    }
    /**
     * @param mailTp11 the mailTp11 to set
     */
    public void setMailTp11(String mailTp11) {
        this.mailTp11 = mailTp11;
    }
    /**
     * @return the mailTp12
     */
    public String getMailTp12() {
        return mailTp12;
    }
    /**
     * @param mailTp12 the mailTp12 to set
     */
    public void setMailTp12(String mailTp12) {
        this.mailTp12 = mailTp12;
    }
    /**
     * @return the mailTp13
     */
    public String getMailTp13() {
        return mailTp13;
    }
    /**
     * @param mailTp13 the mailTp13 to set
     */
    public void setMailTp13(String mailTp13) {
        this.mailTp13 = mailTp13;
    }
    /**
     * @return the mailTp14
     */
    public String getMailTp14() {
        return mailTp14;
    }
    /**
     * @param mailTp14 the mailTp14 to set
     */
    public void setMailTp14(String mailTp14) {
        this.mailTp14 = mailTp14;
    }
    /**
     * @return the mailTp15
     */
    public String getMailTp15() {
        return mailTp15;
    }
    /**
     * @param mailTp15 the mailTp15 to set
     */
    public void setMailTp15(String mailTp15) {
        this.mailTp15 = mailTp15;
    }
    /**
     * @return the mailTp16
     */
    public String getMailTp16() {
        return mailTp16;
    }
    /**
     * @param mailTp16 the mailTp16 to set
     */
    public void setMailTp16(String mailTp16) {
        this.mailTp16 = mailTp16;
    }
    /**
     * @return the mailTp17
     */
    public String getMailTp17() {
        return mailTp17;
    }
    /**
     * @param mailTp17 the mailTp17 to set
     */
    public void setMailTp17(String mailTp17) {
        this.mailTp17 = mailTp17;
    }
    /**
     * @return the mailTp18
     */
    public String getMailTp18() {
        return mailTp18;
    }
    /**
     * @param mailTp18 the mailTp18 to set
     */
    public void setMailTp18(String mailTp18) {
        this.mailTp18 = mailTp18;
    }
    /**
     * @return the mailTp19
     */
    public String getMailTp19() {
        return mailTp19;
    }
    /**
     * @param mailTp19 the mailTp19 to set
     */
    public void setMailTp19(String mailTp19) {
        this.mailTp19 = mailTp19;
    }
    /**
     * @return the mailTp20
     */
    public String getMailTp20() {
        return mailTp20;
    }
    /**
     * @param mailTp20 the mailTp20 to set
     */
    public void setMailTp20(String mailTp20) {
        this.mailTp20 = mailTp20;
    }
    /**
     * @return the mailTp21
     */
    public String getMailTp21() {
        return mailTp21;
    }
    /**
     * @param mailTp21 the mailTp21 to set
     */
    public void setMailTp21(String mailTp21) {
        this.mailTp21 = mailTp21;
    }
    /**
     * @return the mailTp22
     */
    public String getMailTp22() {
        return mailTp22;
    }
    /**
     * @param mailTp22 the mailTp22 to set
     */
    public void setMailTp22(String mailTp22) {
        this.mailTp22 = mailTp22;
    }
    /**
     * @return the mailTp23
     */
    public String getMailTp23() {
        return mailTp23;
    }
    /**
     * @param mailTp23 the mailTp23 to set
     */
    public void setMailTp23(String mailTp23) {
        this.mailTp23 = mailTp23;
    }
    /**
     * @return the mailTp24
     */
    public String getMailTp24() {
        return mailTp24;
    }
    /**
     * @param mailTp24 the mailTp24 to set
     */
    public void setMailTp24(String mailTp24) {
        this.mailTp24 = mailTp24;
    }
    /**
     * @return the mailTp25
     */
    public String getMailTp25() {
        return mailTp25;
    }
    /**
     * @param mailTp25 the mailTp25 to set
     */
    public void setMailTp25(String mailTp25) {
        this.mailTp25 = mailTp25;
    }
    /**
     * @return the mailTp26
     */
    public String getMailTp26() {
        return mailTp26;
    }
    /**
     * @param mailTp26 the mailTp26 to set
     */
    public void setMailTp26(String mailTp26) {
        this.mailTp26 = mailTp26;
    }
    /**
     * @return the mailTp27
     */
    public String getMailTp27() {
        return mailTp27;
    }
    /**
     * @param mailTp27 the mailTp27 to set
     */
    public void setMailTp27(String mailTp27) {
        this.mailTp27 = mailTp27;
    }
    /**
     * @return the mailTp28
     */
    public String getMailTp28() {
        return mailTp28;
    }
    /**
     * @param mailTp28 the mailTp28 to set
     */
    public void setMailTp28(String mailTp28) {
        this.mailTp28 = mailTp28;
    }
    /**
     * @return the mailTp29
     */
    public String getMailTp29() {
        return mailTp29;
    }
    /**
     * @param mailTp29 the mailTp29 to set
     */
    public void setMailTp29(String mailTp29) {
        this.mailTp29 = mailTp29;
    }
    /**
     * @return the mailTp30
     */
    public String getMailTp30() {
        return mailTp30;
    }
    /**
     * @param mailTp30 the mailTp30 to set
     */
    public void setMailTp30(String mailTp30) {
        this.mailTp30 = mailTp30;
    }
    /**
     * @return the mailTp31
     */
    public String getMailTp31() {
        return mailTp31;
    }
    /**
     * @param mailTp31 the mailTp31 to set
     */
    public void setMailTp31(String mailTp31) {
        this.mailTp31 = mailTp31;
    }
    /**
     * @return the mailTp32
     */
    public String getMailTp32() {
        return mailTp32;
    }
    /**
     * @param mailTp32 the mailTp32 to set
     */
    public void setMailTp32(String mailTp32) {
        this.mailTp32 = mailTp32;
    }
    /**
     * @return the mailTp33
     */
    public String getMailTp33() {
        return mailTp33;
    }
    /**
     * @param mailTp33 the mailTp33 to set
     */
    public void setMailTp33(String mailTp33) {
        this.mailTp33 = mailTp33;
    }
    /**
     * @return the mailTp34
     */
    public String getMailTp34() {
        return mailTp34;
    }
    /**
     * @param mailTp34 the mailTp34 to set
     */
    public void setMailTp34(String mailTp34) {
        this.mailTp34 = mailTp34;
    }
    /**
     * @return the mailTp35
     */
    public String getMailTp35() {
        return mailTp35;
    }
    /**
     * @param mailTp35 the mailTp35 to set
     */
    public void setMailTp35(String mailTp35) {
        this.mailTp35 = mailTp35;
    }
    /**
     * @return the mailTp36
     */
    public String getMailTp36() {
        return mailTp36;
    }
    /**
     * @param mailTp36 the mailTp36 to set
     */
    public void setMailTp36(String mailTp36) {
        this.mailTp36 = mailTp36;
    }
    /**
     * @return the mailTp37
     */
    public String getMailTp37() {
        return mailTp37;
    }
    /**
     * @param mailTp37 the mailTp37 to set
     */
    public void setMailTp37(String mailTp37) {
        this.mailTp37 = mailTp37;
    }
    /**
     * @return the mailTp38
     */
    public String getMailTp38() {
        return mailTp38;
    }
    /**
     * @param mailTp38 the mailTp38 to set
     */
    public void setMailTp38(String mailTp38) {
        this.mailTp38 = mailTp38;
    }
    /**
     * @return the mailTp39
     */
    public String getMailTp39() {
        return mailTp39;
    }
    /**
     * @param mailTp39 the mailTp39 to set
     */
    public void setMailTp39(String mailTp39) {
        this.mailTp39 = mailTp39;
    }
    /**
     * @return the mailTp40
     */
    public String getMailTp40() {
        return mailTp40;
    }
    /**
     * @param mailTp40 the mailTp40 to set
     */
    public void setMailTp40(String mailTp40) {
        this.mailTp40 = mailTp40;
    }
    /**
     * @return the mailTp41
     */
    public String getMailTp41() {
        return mailTp41;
    }
    /**
     * @param mailTp41 the mailTp41 to set
     */
    public void setMailTp41(String mailTp41) {
        this.mailTp41 = mailTp41;
    }
    /**
     * @return the mailTp42
     */
    public String getMailTp42() {
        return mailTp42;
    }
    /**
     * @param mailTp42 the mailTp42 to set
     */
    public void setMailTp42(String mailTp42) {
        this.mailTp42 = mailTp42;
    }
    /**
     * @return the mailTp43
     */
    public String getMailTp43() {
        return mailTp43;
    }
    /**
     * @param mailTp43 the mailTp43 to set
     */
    public void setMailTp43(String mailTp43) {
        this.mailTp43 = mailTp43;
    }
    /**
     * @return the mailTp44
     */
    public String getMailTp44() {
        return mailTp44;
    }
    /**
     * @param mailTp44 the mailTp44 to set
     */
    public void setMailTp44(String mailTp44) {
        this.mailTp44 = mailTp44;
    }
    /**
     * @return the mailTp45
     */
    public String getMailTp45() {
        return mailTp45;
    }
    /**
     * @param mailTp45 the mailTp45 to set
     */
    public void setMailTp45(String mailTp45) {
        this.mailTp45 = mailTp45;
    }
    /**
     * @return the mailTp46
     */
    public String getMailTp46() {
        return mailTp46;
    }
    /**
     * @param mailTp46 the mailTp46 to set
     */
    public void setMailTp46(String mailTp46) {
        this.mailTp46 = mailTp46;
    }
    /**
     * @return the mailTp47
     */
    public String getMailTp47() {
        return mailTp47;
    }
    /**
     * @param mailTp47 the mailTp47 to set
     */
    public void setMailTp47(String mailTp47) {
        this.mailTp47 = mailTp47;
    }
    /**
     * @return the mailTp48
     */
    public String getMailTp48() {
        return mailTp48;
    }
    /**
     * @param mailTp48 the mailTp48 to set
     */
    public void setMailTp48(String mailTp48) {
        this.mailTp48 = mailTp48;
    }
    /**
     * @return the mailTp49
     */
    public String getMailTp49() {
        return mailTp49;
    }
    /**
     * @param mailTp49 the mailTp49 to set
     */
    public void setMailTp49(String mailTp49) {
        this.mailTp49 = mailTp49;
    }
    /**
     * @return the mailTp50
     */
    public String getMailTp50() {
        return mailTp50;
    }
    /**
     * @param mailTp50 the mailTp50 to set
     */
    public void setMailTp50(String mailTp50) {
        this.mailTp50 = mailTp50;
    }
    /**
     * @return the mailTp51
     */
    public String getMailTp51() {
        return mailTp51;
    }
    /**
     * @param mailTp51 the mailTp51 to set
     */
    public void setMailTp51(String mailTp51) {
        this.mailTp51 = mailTp51;
    }
    /**
     * @return the mailTp52
     */
    public String getMailTp52() {
        return mailTp52;
    }
    /**
     * @param mailTp52 the mailTp52 to set
     */
    public void setMailTp52(String mailTp52) {
        this.mailTp52 = mailTp52;
    }
    /**
     * @return the mailTp53
     */
    public String getMailTp53() {
        return mailTp53;
    }
    /**
     * @param mailTp53 the mailTp53 to set
     */
    public void setMailTp53(String mailTp53) {
        this.mailTp53 = mailTp53;
    }
    /**
     * @return the mailTp54
     */
    public String getMailTp54() {
        return mailTp54;
    }
    /**
     * @param mailTp54 the mailTp54 to set
     */
    public void setMailTp54(String mailTp54) {
        this.mailTp54 = mailTp54;
    }
    /**
     * @return the mailTp55
     */
    public String getMailTp55() {
        return mailTp55;
    }
    /**
     * @param mailTp55 the mailTp55 to set
     */
    public void setMailTp55(String mailTp55) {
        this.mailTp55 = mailTp55;
    }
    /**
     * @return the mailTp56
     */
    public String getMailTp56() {
        return mailTp56;
    }
    /**
     * @param mailTp56 the mailTp56 to set
     */
    public void setMailTp56(String mailTp56) {
        this.mailTp56 = mailTp56;
    }
    /**
     * @return the mailTp57
     */
    public String getMailTp57() {
        return mailTp57;
    }
    /**
     * @param mailTp57 the mailTp57 to set
     */
    public void setMailTp57(String mailTp57) {
        this.mailTp57 = mailTp57;
    }
    /**
     * @return the mailTp58
     */
    public String getMailTp58() {
        return mailTp58;
    }
    /**
     * @param mailTp58 the mailTp58 to set
     */
    public void setMailTp58(String mailTp58) {
        this.mailTp58 = mailTp58;
    }
    /**
     * @return the mailTp59
     */
    public String getMailTp59() {
        return mailTp59;
    }
    /**
     * @param mailTp59 the mailTp59 to set
     */
    public void setMailTp59(String mailTp59) {
        this.mailTp59 = mailTp59;
    }
    /**
     * @return the mailTp60
     */
    public String getMailTp60() {
        return mailTp60;
    }
    /**
     * @param mailTp60 the mailTp60 to set
     */
    public void setMailTp60(String mailTp60) {
        this.mailTp60 = mailTp60;
    }
    /**
     * @return the mailTp61
     */
    public String getMailTp61() {
        return mailTp61;
    }
    /**
     * @param mailTp61 the mailTp61 to set
     */
    public void setMailTp61(String mailTp61) {
        this.mailTp61 = mailTp61;
    }
    /**
     * @return the mailTp62
     */
    public String getMailTp62() {
        return mailTp62;
    }
    /**
     * @param mailTp62 the mailTp62 to set
     */
    public void setMailTp62(String mailTp62) {
        this.mailTp62 = mailTp62;
    }
    /**
     * @return the mailTp63
     */
    public String getMailTp63() {
        return mailTp63;
    }
    /**
     * @param mailTp63 the mailTp63 to set
     */
    public void setMailTp63(String mailTp63) {
        this.mailTp63 = mailTp63;
    }
    /**
     * @return the mailTp64
     */
    public String getMailTp64() {
        return mailTp64;
    }
    /**
     * @param mailTp64 the mailTp64 to set
     */
    public void setMailTp64(String mailTp64) {
        this.mailTp64 = mailTp64;
    }
    /**
     * @return the mailTp65
     */
    public String getMailTp65() {
        return mailTp65;
    }
    /**
     * @param mailTp65 the mailTp65 to set
     */
    public void setMailTp65(String mailTp65) {
        this.mailTp65 = mailTp65;
    }
    /**
     * @return the mailTp66
     */
    public String getMailTp66() {
        return mailTp66;
    }
    /**
     * @param mailTp66 the mailTp66 to set
     */
    public void setMailTp66(String mailTp66) {
        this.mailTp66 = mailTp66;
    }
    /**
     * @return the mailTp67
     */
    public String getMailTp67() {
        return mailTp67;
    }
    /**
     * @param mailTp67 the mailTp67 to set
     */
    public void setMailTp67(String mailTp67) {
        this.mailTp67 = mailTp67;
    }
    /**
     * @return the mailTp68
     */
    public String getMailTp68() {
        return mailTp68;
    }
    /**
     * @param mailTp68 the mailTp68 to set
     */
    public void setMailTp68(String mailTp68) {
        this.mailTp68 = mailTp68;
    }
    /**
     * @return the mailTp69
     */
    public String getMailTp69() {
        return mailTp69;
    }
    /**
     * @param mailTp69 the mailTp69 to set
     */
    public void setMailTp69(String mailTp69) {
        this.mailTp69 = mailTp69;
    }
    /**
     * @return the mailTp70
     */
    public String getMailTp70() {
        return mailTp70;
    }
    /**
     * @param mailTp70 the mailTp70 to set
     */
    public void setMailTp70(String mailTp70) {
        this.mailTp70 = mailTp70;
    }
    /**
     * @return the mailTp71
     */
    public String getMailTp71() {
        return mailTp71;
    }
    /**
     * @param mailTp71 the mailTp71 to set
     */
    public void setMailTp71(String mailTp71) {
        this.mailTp71 = mailTp71;
    }
    /**
     * @return the mailTp72
     */
    public String getMailTp72() {
        return mailTp72;
    }
    /**
     * @param mailTp72 the mailTp72 to set
     */
    public void setMailTp72(String mailTp72) {
        this.mailTp72 = mailTp72;
    }
    /**
     * @return the mailTp73
     */
    public String getMailTp73() {
        return mailTp73;
    }
    /**
     * @param mailTp73 the mailTp73 to set
     */
    public void setMailTp73(String mailTp73) {
        this.mailTp73 = mailTp73;
    }
    /**
     * @return the mailTp74
     */
    public String getMailTp74() {
        return mailTp74;
    }
    /**
     * @param mailTp74 the mailTp74 to set
     */
    public void setMailTp74(String mailTp74) {
        this.mailTp74 = mailTp74;
    }
    /**
     * @return the mailTp75
     */
    public String getMailTp75() {
        return mailTp75;
    }
    /**
     * @param mailTp75 the mailTp75 to set
     */
    public void setMailTp75(String mailTp75) {
        this.mailTp75 = mailTp75;
    }
    /**
     * @return the mailTp76
     */
    public String getMailTp76() {
        return mailTp76;
    }
    /**
     * @param mailTp76 the mailTp76 to set
     */
    public void setMailTp76(String mailTp76) {
        this.mailTp76 = mailTp76;
    }
    /**
     * @return the mailTp77
     */
    public String getMailTp77() {
        return mailTp77;
    }
    /**
     * @param mailTp77 the mailTp77 to set
     */
    public void setMailTp77(String mailTp77) {
        this.mailTp77 = mailTp77;
    }
    /**
     * @return the mailTp78
     */
    public String getMailTp78() {
        return mailTp78;
    }
    /**
     * @param mailTp78 the mailTp78 to set
     */
    public void setMailTp78(String mailTp78) {
        this.mailTp78 = mailTp78;
    }
    /**
     * @return the mailTp79
     */
    public String getMailTp79() {
        return mailTp79;
    }
    /**
     * @param mailTp79 the mailTp79 to set
     */
    public void setMailTp79(String mailTp79) {
        this.mailTp79 = mailTp79;
    }
    /**
     * @return the mailTp80
     */
    public String getMailTp80() {
        return mailTp80;
    }
    /**
     * @param mailTp80 the mailTp80 to set
     */
    public void setMailTp80(String mailTp80) {
        this.mailTp80 = mailTp80;
    }
    /**
     * @return the mailTp81
     */
    public String getMailTp81() {
        return mailTp81;
    }
    /**
     * @param mailTp81 the mailTp81 to set
     */
    public void setMailTp81(String mailTp81) {
        this.mailTp81 = mailTp81;
    }
    /**
     * @return the mailTp82
     */
    public String getMailTp82() {
        return mailTp82;
    }
    /**
     * @param mailTp82 the mailTp82 to set
     */
    public void setMailTp82(String mailTp82) {
        this.mailTp82 = mailTp82;
    }
    /**
     * @return the mailTp83
     */
    public String getMailTp83() {
        return mailTp83;
    }
    /**
     * @param mailTp83 the mailTp83 to set
     */
    public void setMailTp83(String mailTp83) {
        this.mailTp83 = mailTp83;
    }
    /**
     * @return the mailTp84
     */
    public String getMailTp84() {
        return mailTp84;
    }
    /**
     * @param mailTp84 the mailTp84 to set
     */
    public void setMailTp84(String mailTp84) {
        this.mailTp84 = mailTp84;
    }
    /**
     * @return the mailTp85
     */
    public String getMailTp85() {
        return mailTp85;
    }
    /**
     * @param mailTp85 the mailTp85 to set
     */
    public void setMailTp85(String mailTp85) {
        this.mailTp85 = mailTp85;
    }
    /**
     * @return the mailTp86
     */
    public String getMailTp86() {
        return mailTp86;
    }
    /**
     * @param mailTp86 the mailTp86 to set
     */
    public void setMailTp86(String mailTp86) {
        this.mailTp86 = mailTp86;
    }
    /**
     * @return the mailTp87
     */
    public String getMailTp87() {
        return mailTp87;
    }
    /**
     * @param mailTp87 the mailTp87 to set
     */
    public void setMailTp87(String mailTp87) {
        this.mailTp87 = mailTp87;
    }
    /**
     * @return the mailTp88
     */
    public String getMailTp88() {
        return mailTp88;
    }
    /**
     * @param mailTp88 the mailTp88 to set
     */
    public void setMailTp88(String mailTp88) {
        this.mailTp88 = mailTp88;
    }
    /**
     * @return the mailTp89
     */
    public String getMailTp89() {
        return mailTp89;
    }
    /**
     * @param mailTp89 the mailTp89 to set
     */
    public void setMailTp89(String mailTp89) {
        this.mailTp89 = mailTp89;
    }
    /**
     * @return the mailTp90
     */
    public String getMailTp90() {
        return mailTp90;
    }
    /**
     * @param mailTp90 the mailTp90 to set
     */
    public void setMailTp90(String mailTp90) {
        this.mailTp90 = mailTp90;
    }
    /**
     * @return the mailTp91
     */
    public String getMailTp91() {
        return mailTp91;
    }
    /**
     * @param mailTp91 the mailTp91 to set
     */
    public void setMailTp91(String mailTp91) {
        this.mailTp91 = mailTp91;
    }
    /**
     * @return the mailTp92
     */
    public String getMailTp92() {
        return mailTp92;
    }
    /**
     * @param mailTp92 the mailTp92 to set
     */
    public void setMailTp92(String mailTp92) {
        this.mailTp92 = mailTp92;
    }
    /**
     * @return the mailTp93
     */
    public String getMailTp93() {
        return mailTp93;
    }
    /**
     * @param mailTp93 the mailTp93 to set
     */
    public void setMailTp93(String mailTp93) {
        this.mailTp93 = mailTp93;
    }
    /**
     * @return the mailTp94
     */
    public String getMailTp94() {
        return mailTp94;
    }
    /**
     * @param mailTp94 the mailTp94 to set
     */
    public void setMailTp94(String mailTp94) {
        this.mailTp94 = mailTp94;
    }
    /**
     * @return the mailTp95
     */
    public String getMailTp95() {
        return mailTp95;
    }
    /**
     * @param mailTp95 the mailTp95 to set
     */
    public void setMailTp95(String mailTp95) {
        this.mailTp95 = mailTp95;
    }
    /**
     * @return the mailTp96
     */
    public String getMailTp96() {
        return mailTp96;
    }
    /**
     * @param mailTp96 the mailTp96 to set
     */
    public void setMailTp96(String mailTp96) {
        this.mailTp96 = mailTp96;
    }
    /**
     * @return the mailTp97
     */
    public String getMailTp97() {
        return mailTp97;
    }
    /**
     * @param mailTp97 the mailTp97 to set
     */
    public void setMailTp97(String mailTp97) {
        this.mailTp97 = mailTp97;
    }
    /**
     * @return the mailTp98
     */
    public String getMailTp98() {
        return mailTp98;
    }
    /**
     * @param mailTp98 the mailTp98 to set
     */
    public void setMailTp98(String mailTp98) {
        this.mailTp98 = mailTp98;
    }
    /**
     * @return the mailTp99
     */
    public String getMailTp99() {
        return mailTp99;
    }
    /**
     * @param mailTp99 the mailTp99 to set
     */
    public void setMailTp99(String mailTp99) {
        this.mailTp99 = mailTp99;
    }
    /**
     * @return the seqNumStr
     */
    public String getSeqNumStr() {
        return seqNumStr;
    }
    /**
     * @param seqNumStr the seqNumStr to set
     */
    public void setSeqNumStr(String seqNumStr) {
        this.seqNumStr = seqNumStr;
    }
    /**
     * @return the zsalesPer
     */
    public String getZsalesPer() {
        return zsalesPer;
    }
    /**
     * @param zsalesPer the zsalesPer to set
     */
    public void setZsalesPer(String zsalesPer) {
        this.zsalesPer = zsalesPer;
    }
    /**
     * @return the zsalesPerNm
     */
    public String getZsalesPerNm() {
        return zsalesPerNm;
    }
    /**
     * @param zsalesPerNm the zsalesPerNm to set
     */
    public void setZsalesPerNm(String zsalesPerNm) {
        this.zsalesPerNm = zsalesPerNm;
    }
    
    
}
