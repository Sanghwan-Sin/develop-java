package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.OdrUnprocessedItmLstService;
import com.mobis.maps.nmgn.sd.vo.OdrUnprocessedItmLstVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OdrUnprocessedItmLstController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 6.     jiyongdo     	최초 생성
 * </pre>
 */
@Controller
public class OdrUnprocessedItmLstController extends HController{

    @Resource(name = "odrUnprocessedItmLstService")
    private OdrUnprocessedItmLstService odrUnprocessedItmLstService;
    
    @RequestMapping(value = "/sd/selectOdrUnprocessedItmList.do")
    public NexacroResult selectOdrUnprocessedItmList(@ParamDataSet(name="dsInput") OdrUnprocessedItmLstVO paramVO
                                                   , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = odrUnprocessedItmLstService.selectOdrUnprocessedItmList(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<OdrUnprocessedItmLstVO> totList = (List<OdrUnprocessedItmLstVO>)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<OdrUnprocessedItmLstVO> retList = (List<OdrUnprocessedItmLstVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", totList);   
        result.addDataSet("dsOutput3", paramVO);   

        return result;
    }
    
    @RequestMapping(value = "/sd/selectOdrUnprocessedItmListExcelDown.do")
    public NexacroResult selectOdrUnprocessedItmListExcelDown(@ParamDataSet(name="dsInput") OdrUnprocessedItmLstVO paramVO
                                                            , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt()); 
        
        Map<String, Object> retMap = odrUnprocessedItmLstService.selectOdrUnprocessedItmList(loginInfo, paramVO);  
        @SuppressWarnings("unchecked")
        List<OdrUnprocessedItmLstVO> retList = (List<OdrUnprocessedItmLstVO>)retMap.get("body");        
        result.addDataSet("dsOutput", retList);

        return result;
    }      
}
