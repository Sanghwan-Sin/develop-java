package com.mobis.maps.nmgn.qm.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.qm.service.ClaimReportService;
import com.mobis.maps.nmgn.qm.vo.ClaimReportVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimReportController.java
 * @Description : Claim Report
 * @author hong.minho
 * @since 2020. 10. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 10. 12.     hong.minho     	최초 생성
 * </pre>
 */

@Controller
public class ClaimReportController extends HController {
    
    @Resource(name="claimReportService")
    ClaimReportService service;
    

    /***
     * Claim Report 조회
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/qm/selectClaimReport.do")
    public NexacroResult selectClaimReport(@ParamDataSet(name = "dsInput") ClaimReportVO paramVO, NexacroResult result)
            throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        

        // *** 1.목록 조회
        paramVO.setiSeltyp("2");
        List<ClaimReportVO> lst = service.selectClaimReport(loginInfo, paramVO);
        
        // *** 2.SUM 조회
        ClaimReportVO sumVo = new ClaimReportVO();
        BeanUtils.copyProperties(sumVo, paramVO);
        
        sumVo.setPgNum(1); // page=1 이 아니면 SUM 조회가 안되서 초기화
        sumVo.setPgSize(20);
        
        sumVo.setiSeltyp("1");
        List<ClaimReportVO> sum = service.selectClaimReport(loginInfo, sumVo);
        

        result.addDataSet("dsEsReturn", paramVO);   
        result.addDataSet("dsOutput", lst);
        result.addDataSet("dsSum", (sum != null && sum.size() > 0 ? sum.get(0) : null));

        return result;
    }
    
    
    /***
     * Claim Report Excel Download
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/qm/selectClaimReportExcelDown.do")
    public NexacroResult selectClaimReportExcelDown(@ParamDataSet(name = "dsInput") ClaimReportVO paramVO,
            NexacroResult result) throws Exception {
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());

        
        return selectClaimReport(paramVO, result);
    } 
}
