package com.mobis.maps.nmgn.qm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.qm.service.ClaimListService;
import com.mobis.maps.nmgn.qm.vo.ClaimCodeListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimDetailVO;
import com.mobis.maps.nmgn.qm.vo.ClaimInvoiceListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimMarkUpVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimListServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 23.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("claimListService")
public class ClaimListServiceImpl extends HService implements ClaimListService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.qm.service.QualityNonconfirmityService#selectQualityNonconfirmityList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.QualityNonconfirmityVO)
     */
    @Override
    public Map<String, Object> selectClaimList(LoginInfoVO loginInfo, ClaimListVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_S_CLAIM_EXPORT_LIST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<ClaimListVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", paramVO, ClaimListVO.class);
        //List<OdrUnprocessedItmLstVO> totLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_SUMMARY", paramVO, OdrUnprocessedItmLstVO.class);
        //ClaimListVO rtnLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", ClaimListVO.class);
        
        //retMap.put("head", rtnLst);
        retMap.put("body", odrLst);      
        
        return retMap;           
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.ClaimListService#selectClaimDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.ClaimDetailVO)
     */
    @Override
    public ClaimDetailVO selectClaimDetail(LoginInfoVO loginInfo, ClaimDetailVO paramVO) throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_R_CLAIM_SAVE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO); 
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<ClaimDetailVO> mainLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", paramVO, ClaimDetailVO.class);
        List<ClaimDetailVO> sub1Lst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA_JU", paramVO, ClaimDetailVO.class);
        List<ClaimDetailVO> sub2Lst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA_SC", paramVO, ClaimDetailVO.class);
        MapsRfcMappperUtil.setExportParamList(funcRslt, paramVO, loginInfo.getUserLcale());
        
        paramVO.setBody1(mainLst);
        paramVO.setBody2(sub1Lst);
        paramVO.setBody3(sub2Lst);
        
        return paramVO;
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.ClaimListService#selectInvoiceNoList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.ClaimInvoiceListVO)
     */
    @Override
    public List<ClaimInvoiceListVO> selectInvoiceNoList(LoginInfoVO loginInfo, ClaimInvoiceListVO paramVO)
            throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_S_INVOICE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        //mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO); 
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        //ClaimDetailVO detailVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "T_DATA", ClaimDetailVO.class); 
        List<ClaimInvoiceListVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", paramVO, ClaimInvoiceListVO.class);
        //ClaimDetailVO detailVo = odrLst.get(0);
        
        return odrLst;
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.ClaimListService#selectClaimCodeList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.ClaimCodeListVO)
     */
    @Override
    public List<ClaimCodeListVO> selectClaimCodeList(LoginInfoVO loginInfo, ClaimCodeListVO paramVO) throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_S_CLAIMCODE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        //mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO); 
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        //ClaimDetailVO detailVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "T_DATA", ClaimDetailVO.class); 
        List<ClaimCodeListVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", paramVO, ClaimCodeListVO.class);
        //ClaimDetailVO detailVo = odrLst.get(0);
        
        return odrLst;
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.ClaimListService#multiClaimDetail(com.mobis.maps.nmgn.qm.vo.ClaimListVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public ClaimDetailVO multiClaimDetail(ClaimDetailVO paramVO, List<ClaimDetailVO> paramList,
            LoginInfoVO loginInfo) throws Exception {
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_R_CLAIM_SAVE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);              
        
        if("US".equals(paramVO.getiCrud())){  
            MapsRfcMappperUtil.appendImportTableRow(func, "T_DATA_SC", paramList.get(0));
        }else if("QI".equals(paramVO.getiCrud())){
            if (logger.isDebugEnabled()) {
                logger.debug("## I_CRUD : QI");
            }
        }else{
            
            if("A1".equals(paramVO.getiCrud())){
                paramList.get(0).setZchcrid(loginInfo.getUserId());
                paramList.get(0).setZchcridname(loginInfo.getUserNm());
            }else if("U2".equals(paramVO.getiCrud())){
                paramList.get(0).setZsubmbyname(loginInfo.getUserNm());
            }else if("C1".equals(paramVO.getiCrud())){
                paramList.get(0).setZcanbyname(loginInfo.getUserNm());
            }              
            
            MapsRfcMappperUtil.appendImportTableRow(func, "T_DATA", paramList.get(0));
        }
        
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        List<ClaimDetailVO> retList =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_DATA", ClaimDetailVO.class);
        // 개별데이타 추출
        //List<ExchangePurchaseDetailVO> odrLst =  MapsRfcMappperUtil.getExportTableResultValues(funcRslt, "IT_DATA", ExchangePurchaseDetailVO.class);
        if("US".equals(paramVO.getiCrud())){  
            retList =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_DATA_SC", ClaimDetailVO.class);
        }       
        ClaimDetailVO fileCont = new ClaimDetailVO();
        MapsRfcMappperUtil.setExportParamList(funcRslt, fileCont, loginInfo.getUserLcale());
        
        if (!"E".equals(paramVO.getMsgType())) {
            paramVO.setiCrud("D1");
            paramVO.setiZclano(retList.get(0).getZclano());            
            
            selectClaimDetail(loginInfo, paramVO);
            
            paramVO.setBody4(fileCont);
        
        } else {
            List<ClaimDetailVO> nullVo = new ArrayList<ClaimDetailVO>();
            
            paramVO.setBody1(retList);
            paramVO.setBody2(nullVo);
            paramVO.setBody3(nullVo);
        }
        
        return paramVO;
    }

    /*
     * @see com.mobis.maps.nmgn.qm.service.ClaimListService#selectMarkUpList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.qm.vo.ClaimInvoiceListVO)
     */
    @Override
    public ClaimMarkUpVO selectMarkUpList(LoginInfoVO loginInfo, ClaimMarkUpVO paramVO)
            throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_S_MARKUP;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        //mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO); 
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        //ClaimDetailVO detailVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "T_DATA", ClaimDetailVO.class); 
        MapsRfcMappperUtil.setExportParamList(funcRslt, paramVO, loginInfo.getUserLcale());
        //ClaimDetailVO detailVo = odrLst.get(0);
        
        return paramVO;
    }
}
