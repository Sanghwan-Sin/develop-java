package com.mobis.maps.nmgn.ti.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DownloadAoFinishVO.java
 * @Description : ZPTI_NMGN_R_DOWNLOAD_FINISH 
 * @author 이수지
 * @since 2020. 06. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 16.     이수지     	       최초 생성
 * </pre>
 */

public class DownloadAoFinishVO extends MapsCommSapRfcIfCommVO {
    
    /** Dist Code  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDISTCD" )
    private String iZdistcd;
    /** 실행 결과 지시자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPFLAG" )
    private String iZpflag;
    /** 일련번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSEQNO" )
    private String iZseqno;
    
    /**
     * @return the iZdistcd
     */
    public String getiZdistcd() {
        return iZdistcd;
    }
    /**
     * @param iZdistcd the iZdistcd to set
     */
    public void setiZdistcd(String iZdistcd) {
        this.iZdistcd = iZdistcd;
    }
    /**
     * @return the iZpflag
     */
    public String getiZpflag() {
        return iZpflag;
    }
    /**
     * @param iZpflag the iZpflag to set
     */
    public void setiZpflag(String iZpflag) {
        this.iZpflag = iZpflag;
    }
    /**
     * @return the iZseqno
     */
    public String getiZseqno() {
        return iZseqno;
    }
    /**
     * @param iZseqno the iZseqno to set
     */
    public void setiZseqno(String iZseqno) {
        this.iZseqno = iZseqno;
    }
    
    
    
}
