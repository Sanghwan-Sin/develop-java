package com.mobis.maps.nmgn.cc.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.PropertiesUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommEmailService;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.comm.vo.EmailSndngVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.nmgn.cc.service.DistMailingMgrService;
import com.mobis.maps.nmgn.cc.service.NewsLetterService;
import com.mobis.maps.nmgn.cc.service.dao.NewsLetterMDAO;
import com.mobis.maps.nmgn.cc.vo.MailingVO;
import com.mobis.maps.nmgn.cc.vo.NewsLetterVO;
import com.mobis.maps.nmgn.cc.vo.TargetTreeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : NewsLetterServiceImpl.java
 * @Description : News Letter
 * @author 이수지
 * @since 2020. 03. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 31.     이수지             	최초 생성
 * </pre>
 */
@Service("newsLetterService")
public class NewsLetterServiceImpl extends HService implements NewsLetterService{

    private final static String ADM_EMAIL_ADDR = "admin@mobis.co.kr";
    
    @Resource(name = "newsLetterMDAO")
    NewsLetterMDAO newsLetterMDAO;
    
    @Resource(name="mapsCommFileService")
    private MapsCommFileService mapsCommFileService;
    
    @Resource(name = "mapsCommEmailService")
    private MapsCommEmailService mailService;
    
    @Resource(name = "distMailingMgrService")
    private DistMailingMgrService distMailingMgrService;
    
    @Resource(name = "newsLetterService")
    private NewsLetterService newsLetterService;

    /*
     * @see com.mobis.maps.nmgn.cc.service.NewsLetterService#selectNewsLetter(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.NewsLetterVO)
     */
    @Override
    public List<NewsLetterVO> selectNewsLetter(LoginInfoVO loginInfo, NewsLetterVO params) throws Exception {

        List<NewsLetterVO> retList = newsLetterMDAO.selectNewsLetter(params);
        
        return retList;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.NewsLetterService#selectNewsLetterDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.NewsLetterVO)
     */
    @Override
    public List<NewsLetterVO> selectNewsLetterDetail(LoginInfoVO loginInfo, NewsLetterVO params) throws Exception {
        
        newsLetterMDAO.updateNewsLetterReadCount(params);
        List<NewsLetterVO> retList = newsLetterMDAO.selectNewsLetterDetail(params);

        return retList;
    }
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.NewsLetterService#insertNewsLetter(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.NewsLetterVO)
     */
    @Override
    public NewsLetterVO insertNewsLetter(NewsLetterVO params) throws Exception {               
        
        if (!StringUtils.isBlank(params.getStatYn())) {
            if ("S".equals(params.getStatYn())) { // 저장
                newsLetterMDAO.insertNewsLetter(params);
            } else if ("U".equals(params.getStatYn())) { // 수정
                newsLetterMDAO.updateNewsLetter(params);
            } else if ("D".equals(params.getStatYn())) { // 삭제
                newsLetterMDAO.deleteNewsLetter(params);
            }
        }
        NewsLetterVO retVo = new NewsLetterVO();
        
        retVo.setRefNo(params.getRefNo());
        
        return retVo;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.NewsLetterService#multiAtchFile(com.mobis.maps.nmgn.cc.vo.NewsLetterVO, java.util.List)
     */
    @Override
    public int multiAtchFile(NewsLetterVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception {
        
        int retCnt = 0;
        
        if (atchFiles != null && atchFiles.size() > 0) {
            AtchFileSe atchFileGubn = AtchFileSe.get(atchFileVO.getAtchSe()); 
            retCnt = mapsCommFileService.multiAtchFile(atchFileGubn, atchFileVO, atchFiles);    
        }
        return retCnt;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.NewsLetterService#selectTargetTreeList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.comm.vo.MapsCommCodeVO, com.mobis.maps.nmgn.cc.vo.TargetTreeVO)
     */
    @Override
    public List<TargetTreeVO> selectTargetTreeList(LoginInfoVO loginInfo, MapsCommCodeVO commCodeVO,
            TargetTreeVO params) throws Exception {      
        
        String sysid = PropertiesUtil.getString("sapcode.pc.sys.id");
        String mandt = PropertiesUtil.getString("sapcode.pc.sys.client");
        
        params.setSpras(loginInfo.getRfcLang());
        params.setSysid(sysid);
        params.setMandt(mandt);
        
        List<TargetTreeVO> retList = newsLetterMDAO.selectTargetTreeList(params);
        
        return retList;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.NewsLetterService#updateNewsLetteMail(com.mobis.maps.nmgn.cc.vo.NewsLetterVO)
     */
    @Override
    public void updateNewsLetteMail(NewsLetterVO params) {
        
        newsLetterMDAO.updateNewsLetteMail(params);
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.NewsLetterService#insertNewsLetterMailSend(java.util.List)
     */
    @Override
    public void insertNewsLetterMailSend(LoginInfoVO loginInfo, List<NewsLetterVO> list) throws Exception {
        
        if (list == null || list.size() <= 0) {
            logger.error("ERROR : List<NewsLetterVO> list is null");
            return;
        }
        
        NewsLetterVO letterVo = list.get(0);
        if (letterVo == null) {
            logger.error("ERROR : list.get(0) is null");
            return;
        }
        
        MapsAtchFileVO fileVo = new MapsAtchFileVO();
        fileVo.setAtchSe("NMGN007");
        fileVo.setAtchId(letterVo.getRefNo());
        List<MapsAtchFileVO> lstAtchFile = mapsCommFileService.selectAtchFileList(fileVo);
          
        // *** 0. Mail 주소
        String mailTo = distMailingMgrService.selectMailingString(letterVo.getRecptnEmail(), MailingVO.CD_EMLTP_60); // MAILING : 60-News Letter
        String mailCc = distMailingMgrService.selectMailingString(letterVo.getRecptnCc(), MailingVO.CD_EMLTP_60); // MAILING : 60-News Letter
        String inputTo = "";
        if (!StringUtils.isEmpty(letterVo.getEmailTo())) {
            inputTo = letterVo.getEmailTo();
        }
        
        inputTo = inputTo.replaceAll("\\s*\\;\\s*", ",").replaceAll("\\s+", "");
        
        StringBuffer rcptTo = new StringBuffer();
        StringBuffer rcptCc = new StringBuffer();
        
        rcptTo.append(mailTo);
        if (!StringUtils.isEmpty(inputTo)) {
            if (rcptTo.length() > 0) {rcptTo.append(",");}
            rcptTo.append(inputTo);
        }
        
        rcptCc.append(mailCc);
        
        if (logger.isDebugEnabled()) {
            logger.debug("##### RCPT_TO : " + rcptTo.toString());
        logger.debug("##### RCPT_CC : " + rcptCc.toString());
        }
        
        // *** 1. 메일BODY
        EmailSndngVO vo = new EmailSndngVO();
        
        StringBuffer sender = new StringBuffer();
        sender.append(letterVo.getSndngId()).append("<").append(ADM_EMAIL_ADDR).append(">"); // 보내는메일
        
        vo.setSndngProgrm(this.getClass().getName());
        vo.setSndngEmail(sender.toString()); // MAIL FROM : 로그인 EMAIL주소, NULL 이면 DEFAULT값 "admin@mobis.co.kr"
        vo.setRecptnEmail(rcptTo.toString()); // MAIL TO
        vo.setRecptnCc(rcptCc.toString()); // MAIL CC
        vo.setEmailSj(letterVo.getNewsletterSj()); // News Letter 제목
        vo.setEmailBdt(StringUtils.isBlank(letterVo.getNewsletterCn()) ? "<div></div>" : letterVo.getNewsletterCn()); // News Letter 내용
        vo.setHtmlYn("Y"); // HTML 여부
        vo.setAtchYn("Y"); // 첨부파일 여부
        vo.setRegistId(letterVo.getRegistId()); // 등록자
        
        if (StringUtils.isEmpty(mailTo) && StringUtils.isEmpty(inputTo)) {
            throw new MapsBizException(this.messageSource, "WMM0000001", MapsConstants.DFLT_LOCALE, null); // There are no staffs in the Distributor who can receive newsletters.
        }
                 
        // *** 3. 메일전송
        mailService.multiSendEmail(vo, lstAtchFile);
        
        letterVo.setSndngId(loginInfo.getUserId()); // 전송자
        letterVo.setSndngYn("Y"); // 전송여부
        
        newsLetterService.updateNewsLetteMail(letterVo); // 메일전송 상태 업데이트
    }

}
