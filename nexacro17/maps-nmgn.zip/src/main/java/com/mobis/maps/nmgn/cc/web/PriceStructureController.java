package com.mobis.maps.nmgn.cc.web;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.PriceStructureService;
import com.mobis.maps.nmgn.cc.vo.PriceStructureVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PriceStructureController.java
 * @Description : PriceStructureController
 * @author ha.jeongryeong
 * @since 2019. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 10.     ha.jeongryeong         최초 생성
 * </pre>
 */
@Controller
public class PriceStructureController extends HController {

    @Resource(name = "priceStructureService")
    private PriceStructureService priceStructureService;

    /**
     * 조회(detail)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectPriceStructure.do")
    public NexacroResult selectPriceStructure(
            @ParamDataSet(name="dsInput") PriceStructureVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        PriceStructureVO retVO = priceStructureService.selectPriceStructure(paramVO, loginInfo);

        result.addDataSet("dsOutput", retVO);

        return result;
    }

    
    /**
     * 조회detail(엑셀)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectPriceStructureDetailExcelDown.do")
    public NexacroResult selectPriceStructureDetailExcelDown(
            @ParamDataSet(name="dsInput") PriceStructureVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setExcelDwnlYn("Y");
        PriceStructureVO retVO = priceStructureService.selectPriceStructure(paramVO, loginInfo);

        result.addDataSet("dsOutput", retVO);

        return result;
    }

    
    /**
     * 저장(detail)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/multiPriceStructure.do")
    public NexacroResult multiPriceStructure(
            @ParamDataSet(name="dsInput") PriceStructureVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        // 저장
        priceStructureService.multiPriceStructure(paramVO, loginInfo);
        
        // 재조회
        return this.selectPriceStructure(paramVO, result);
    }
    
    
}
