package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.DngrsGoodsVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DngrsGoodsService.java
 * @Description : ZJSDR80140 UD DOT/ EU BAM - Dangerous Goods (위험물)
 * @author hong.minho
 * @since 2020. 5. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 11.     hong.minho     	최초 생성
 * </pre>
 */

public interface DngrsGoodsService {

    /**
     * select UD DOT/ EU BAM List
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<DngrsGoodsVO> selectDangerGood (LoginInfoVO loginVo, DngrsGoodsVO params) throws Exception; 
    
}
