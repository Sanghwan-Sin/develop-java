package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.nmgn.cc.service.CalendarService;
import com.mobis.maps.nmgn.cc.vo.CalendarHdyVO;
import com.mobis.maps.nmgn.cc.vo.CalendarVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarController.java
 * @Description : Work Calendar
 * @author hong.minho
 * @since 2020. 5. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 20.     hong.minho     	최초 생성
 * </pre>
 */

@Controller
public class CalendarController extends HController {
    
    @Resource(name = "calendarService")
    CalendarService service;

    /**
     * 법인별 Calendar 조회
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectCalendar.do")
    public NexacroResult selectCalendar(@ParamDataSet(name="dsInput") CalendarVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<CalendarVO> retList = service.selectCalendar(loginInfo, paramVO);
        
        // *** 12개 개월로 분리
        int nMon = 1;
        int preIdx = 0;
        for(int idx = 0; retList != null && idx < retList.size(); idx++) {
            CalendarVO wk = retList.get(idx);
            if (wk == null) continue;
            
            if (!wk.getMon().equals(StringUtils.leftPad(String.valueOf(nMon), 2, "0"))) {
                result.addDataSet("dsCal"+nMon, retList.subList(preIdx, idx));
                nMon ++;
                preIdx = idx;
            }
        }
        result.addDataSet("dsCal"+nMon, retList.subList(preIdx, retList.size()));
        
        // *** 휴일내용 12개월치
        if (paramVO.getDescLstMap() != null) {
            for(int mon = 1; mon <= 12; mon ++) {
                String sMon = StringUtils.leftPad(String.valueOf(mon), 2, "0");
                List<CalendarHdyVO> lst = paramVO.getDescLstMap().get(sMon);
                
                result.addDataSet("dsCalDesc"+mon, lst);
            }
        }
        
        

        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsReturn", paramVO);

        return result;
    }

    
    /**
     * 월 Calendar 조회
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectCalendarMon.do")
    public NexacroResult selectCalendarMon(@ParamDataSet(name="dsInput") CalendarVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsOrgnztDistVO orgInfo = (MapsOrgnztDistVO) getSessionAttribute(MapsConstants.SSS_ORGNZT_INFO);
        
        List<CalendarVO> retList = service.selectCalendarMon(loginInfo, orgInfo, paramVO);

        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsReturn", paramVO);
        
        return result;
    }
}
