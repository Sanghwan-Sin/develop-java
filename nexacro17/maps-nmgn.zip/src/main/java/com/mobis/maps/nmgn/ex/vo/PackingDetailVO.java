package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingDetailVO.java
 * @Description : ZPEX_MGN_GET_PACKING_DETAIL
 * @author 이수지
 * @since 2020. 2. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 10.       이수지     	       최초 생성
 * </pre>
 */

public class PackingDetailVO extends MapsCommSapRfcIfCommVO {
    
    /** Case Number */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CASE_NO" )
    private String iCaseNo;
    /** Container NO. */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CNTR_NO" )
    private String iCntrNo;
    /** Invoice Number */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /** Part Number */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PART_NO" )
    private String iPartNo;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    
    
    /** -----[ET_LIST] START----- */
    
    
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LINE_ITEM" )
    private String lineItem;
    /** 오더번호 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ORDER" )
    private String order;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PART_NO" )
    private String partNo;
    /** Actual quantity delivered (in sales units) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="QTY" )
    private BigDecimal qty;
    /** Net weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="UNIT_WEIGHT" )
    private BigDecimal unitWeight;
    /** Carton Box Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CASE_NO" )
    private String caseNo;
    /** Container NO. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CONTAINER_NO" )
    private String containerNo;
    
    private String invoice;
    
    /** -----[ET_LIST] END----- */
    
    /**
     * @return the iCaseNo
     */
    public String getiCaseNo() {
        return iCaseNo;
    }
    /**
     * @param iCaseNo the iCaseNo to set
     */
    public void setiCaseNo(String iCaseNo) {
        this.iCaseNo = iCaseNo;
    }
    /**
     * @return the iCntrNo
     */
    public String getiCntrNo() {
        return iCntrNo;
    }
    /**
     * @param iCntrNo the iCntrNo to set
     */
    public void setiCntrNo(String iCntrNo) {
        this.iCntrNo = iCntrNo;
    }
    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }
    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }
    /**
     * @return the iPartNo
     */
    public String getiPartNo() {
        return iPartNo;
    }
    /**
     * @param iPartNo the iPartNo to set
     */
    public void setiPartNo(String iPartNo) {
        this.iPartNo = iPartNo;
    }
    /**
     * @return the lineItem
     */
    public String getLineItem() {
        return lineItem;
    }
    /**
     * @param lineItem the lineItem to set
     */
    public void setLineItem(String lineItem) {
        this.lineItem = lineItem;
    }
    /**
     * @return the order
     */
    public String getOrder() {
        return order;
    }
    /**
     * @param order the order to set
     */
    public void setOrder(String order) {
        this.order = order;
    }
    /**
     * @return the partNo
     */
    public String getPartNo() {
        return partNo;
    }
    /**
     * @param partNo the partNo to set
     */
    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }
    /**
     * @return the qty
     */
    public BigDecimal getQty() {
        return qty;
    }
    /**
     * @param qty the qty to set
     */
    public void setQty(BigDecimal qty) {
        this.qty = qty;
    }
    /**
     * @return the unitWeight
     */
    public BigDecimal getUnitWeight() {
        return unitWeight;
    }
    /**
     * @param unitWeight the unitWeight to set
     */
    public void setUnitWeight(BigDecimal unitWeight) {
        this.unitWeight = unitWeight;
    }
    /**
     * @return the caseNo
     */
    public String getCaseNo() {
        return caseNo;
    }
    /**
     * @param caseNo the caseNo to set
     */
    public void setCaseNo(String caseNo) {
        this.caseNo = caseNo;
    }
    /**
     * @return the containerNo
     */
    public String getContainerNo() {
        return containerNo;
    }
    /**
     * @param containerNo the containerNo to set
     */
    public void setContainerNo(String containerNo) {
        this.containerNo = containerNo;
    }
    /**
     * @return the invoice
     */
    public String getInvoice() {
        return invoice;
    }
    /**
     * @param invoice the invoice to set
     */
    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    
}
