package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : IssueTrackerVO.java
 * @Description : Issue Tracker(VOC Request)VO
 * @author ChoKyungHo
 * @since 2020. 03. 02.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 02.    ChoKyungHo                 최초 생성
 * </pre>
 */

public class IssueTrackerVO extends MapsCommSapRfcIfCommVO{
    
    
    /** 단일 문자 표시 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATETYP" )
    private String iDatetyp;
    /** From 일자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_FRDATE" )
    private Date iFrdate;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** T: Issue Tracker, H: Issue Tracker History 기본값 T*/
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MODE" )
    private String iMode;
    /** To 일자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TODATE" )
    private Date iTodate;
    /** C:Create, U:Change, R:Display 기본값 R */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** Amend Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAMENDCD" )
    private String iZamendcd;
    /** Category L */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCTGR_L" )
    private String iZctgrL;
    /** Category M */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCTGR_M" )
    private String iZctgrM;
    /** L-REGION */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZLREGIO" )
    private String iZlregio;
    /** M-REGION */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZMREGIO" )
    private String iZmregio;
    /** Process Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPRC_CD" )
    private String iZprcCd;
    /** Distributor Code(구) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_DIST" )
    private String iZsacutmDist;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    /** S-REGION */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSREGIO" )
    private String iZsregio;
    
    
    /**  -----[T_RESULT] START-----*/
    /** 영업조직 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZVKORG_DIST" )
    private String zvkorgDist;
    /** 성 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZDEALER_TXT" )
    private String zdealerTxt;
    /** 고객코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM_DLR" )
    private String zsacutmDlr;
    /** 성 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KUNNR_TXT" )
    private String kunnrTxt;
    /** 고객코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM_DIST" )
    private String zsacutmDist;
    /** Create Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /** Reply Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZREPL_DT" )
    private Date zreplDt;
    /** Completion Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCPLT_DT" )
    private Date zcpltDt;
    /** Requested Department */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZREQ_DPMT" )
    private String zreqDpmt;
    /** 코드 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZREQ_DPMT_TXT" )
    private String zreqDpmtTxt;
    /** Category L */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCTGR_L" )
    private String zctgrL;
    /** 코드 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCTGR_L_TXT" )
    private String zctgrLTxt;
    /** Category M */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCTGR_M" )
    private String zctgrM;
    /** 코드 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCTGR_M_TXT" )
    private String zctgrMTxt;
    /** Category S */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCTGR_S" )
    private String zctgrS;
    /** 코드 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCTGR_S_TXT" )
    private String zctgrSTxt;
    /** Assignee */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZIASS_ID" )
    private String ziassId;
    /** 코드 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZIASS_ID_TXT" )
    private String ziassIdTxt;
    /** SEQ번호(청구번호) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO" )
    private String zordno;
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDLN" )
    private BigDecimal zordln;
    /** 신청수량 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZREQQTY" )
    private BigDecimal zreqqty;
    /** 기본 단위 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MEINS" )
    private String meins;
    /** Material Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** Case No */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCAS_NO" )
    private String zcasNo;
    /** Ticket No. */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZTICKET_NO" )
    private String zticketNo;
    /** Reference No */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZREF_NO" )
    private BigDecimal zrefNo; // 0925 추가
    /** 숫자 3, 내부사용 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSEQ" )
    private BigDecimal zseq; // 0925 추가
    /** H/K */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /** L-REGION */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZLREGIO" )
    private String zlregio;
    /** M-REGION */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMREGIO" )
    private String zmregio;
    /** S-REGION */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSREGIO" )
    private String zsregio;
    /** Amend Code */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZAMENDCD" )
    private String zamendcd;
    /** 코드 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZAMENDCD_TXT" )
    private String zamendcdTxt;
    /** Invoice No. */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZINV_NO" )
    private String zinvNo;
    /** Public Flag */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPUBLIC" )
    private String zpublic;
    /** Analyst */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZANALYST" )
    private String zanalyst;
    /** Change User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDNAME" )
    private String zudname;
    /** 성 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDNAME_TXT" )
    private String zudnameTxt;
    /** Change Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDLDATE" )
    private Date zudldate;
    /** Change Local Time */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDLTIME" )
    private Date zudltime;
    /** Process Code */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRC_CD" )
    private String zprcCd;
    /** 코드 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRC_CD_TXT" )
    private String zprcCdTxt;
    /** Request Count */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZREQCNT" )
    private BigDecimal zreqcnt;
    /** Subject */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSBJT" )
    private String zsbjt;
    /** Attached File 1 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZATH_FLE1" )
    private String zathFle1;
    /** Attached File 2 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZATH_FLE2" )
    private String zathFle2;
    /** Attached File 3 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZATH_FLE3" )
    private String zathFle3;
    /** Attached File 4 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZATH_FLE4" )
    private String zathFle4;
    /** Attached File 5 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZATH_FLE5" )
    private String zathFle5;
    /**
     * @return the iDatetyp
     */
    public String getiDatetyp() {
        return iDatetyp;
    }
    /**
     * @param iDatetyp the iDatetyp to set
     */
    public void setiDatetyp(String iDatetyp) {
        this.iDatetyp = iDatetyp;
    }
    /**
     * @return the iFrdate
     */
    public Date getiFrdate() {
        return iFrdate;
    }
    /**
     * @param iFrdate the iFrdate to set
     */
    public void setiFrdate(Date iFrdate) {
        this.iFrdate = iFrdate;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iMode
     */
    public String getiMode() {
        return iMode;
    }
    /**
     * @param iMode the iMode to set
     */
    public void setiMode(String iMode) {
        this.iMode = iMode;
    }
    /**
     * @return the iTodate
     */
    public Date getiTodate() {
        return iTodate;
    }
    /**
     * @param iTodate the iTodate to set
     */
    public void setiTodate(Date iTodate) {
        this.iTodate = iTodate;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZamendcd
     */
    public String getiZamendcd() {
        return iZamendcd;
    }
    /**
     * @param iZamendcd the iZamendcd to set
     */
    public void setiZamendcd(String iZamendcd) {
        this.iZamendcd = iZamendcd;
    }
    /**
     * @return the iZctgrL
     */
    public String getiZctgrL() {
        return iZctgrL;
    }
    /**
     * @param iZctgrL the iZctgrL to set
     */
    public void setiZctgrL(String iZctgrL) {
        this.iZctgrL = iZctgrL;
    }
    /**
     * @return the iZctgrM
     */
    public String getiZctgrM() {
        return iZctgrM;
    }
    /**
     * @param iZctgrM the iZctgrM to set
     */
    public void setiZctgrM(String iZctgrM) {
        this.iZctgrM = iZctgrM;
    }
    /**
     * @return the iZlregio
     */
    public String getiZlregio() {
        return iZlregio;
    }
    /**
     * @param iZlregio the iZlregio to set
     */
    public void setiZlregio(String iZlregio) {
        this.iZlregio = iZlregio;
    }
    /**
     * @return the iZmregio
     */
    public String getiZmregio() {
        return iZmregio;
    }
    /**
     * @param iZmregio the iZmregio to set
     */
    public void setiZmregio(String iZmregio) {
        this.iZmregio = iZmregio;
    }
    /**
     * @return the iZprcCd
     */
    public String getiZprcCd() {
        return iZprcCd;
    }
    /**
     * @param iZprcCd the iZprcCd to set
     */
    public void setiZprcCd(String iZprcCd) {
        this.iZprcCd = iZprcCd;
    }
    /**
     * @return the iZsacutmDist
     */
    public String getiZsacutmDist() {
        return iZsacutmDist;
    }
    /**
     * @param iZsacutmDist the iZsacutmDist to set
     */
    public void setiZsacutmDist(String iZsacutmDist) {
        this.iZsacutmDist = iZsacutmDist;
    }
    /**
     * @return the iZsregio
     */
    public String getiZsregio() {
        return iZsregio;
    }
    /**
     * @param iZsregio the iZsregio to set
     */
    public void setiZsregio(String iZsregio) {
        this.iZsregio = iZsregio;
    }
    /**
     * @return the zvkorgDist
     */
    public String getZvkorgDist() {
        return zvkorgDist;
    }
    /**
     * @param zvkorgDist the zvkorgDist to set
     */
    public void setZvkorgDist(String zvkorgDist) {
        this.zvkorgDist = zvkorgDist;
    }
    /**
     * @return the zdealerTxt
     */
    public String getZdealerTxt() {
        return zdealerTxt;
    }
    /**
     * @param zdealerTxt the zdealerTxt to set
     */
    public void setZdealerTxt(String zdealerTxt) {
        this.zdealerTxt = zdealerTxt;
    }
    /**
     * @return the zsacutmDlr
     */
    public String getZsacutmDlr() {
        return zsacutmDlr;
    }
    /**
     * @param zsacutmDlr the zsacutmDlr to set
     */
    public void setZsacutmDlr(String zsacutmDlr) {
        this.zsacutmDlr = zsacutmDlr;
    }
    /**
     * @return the kunnrTxt
     */
    public String getKunnrTxt() {
        return kunnrTxt;
    }
    /**
     * @param kunnrTxt the kunnrTxt to set
     */
    public void setKunnrTxt(String kunnrTxt) {
        this.kunnrTxt = kunnrTxt;
    }
    /**
     * @return the zsacutmDist
     */
    public String getZsacutmDist() {
        return zsacutmDist;
    }
    /**
     * @param zsacutmDist the zsacutmDist to set
     */
    public void setZsacutmDist(String zsacutmDist) {
        this.zsacutmDist = zsacutmDist;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zcpltDt
     */
    public Date getZcpltDt() {
        return zcpltDt;
    }
    /**
     * @param zcpltDt the zcpltDt to set
     */
    public void setZcpltDt(Date zcpltDt) {
        this.zcpltDt = zcpltDt;
    }
    /**
     * @return the zreqDpmt
     */
    public String getZreqDpmt() {
        return zreqDpmt;
    }
    /**
     * @param zreqDpmt the zreqDpmt to set
     */
    public void setZreqDpmt(String zreqDpmt) {
        this.zreqDpmt = zreqDpmt;
    }
    /**
     * @return the zreqDpmtTxt
     */
    public String getZreqDpmtTxt() {
        return zreqDpmtTxt;
    }
    /**
     * @param zreqDpmtTxt the zreqDpmtTxt to set
     */
    public void setZreqDpmtTxt(String zreqDpmtTxt) {
        this.zreqDpmtTxt = zreqDpmtTxt;
    }
    /**
     * @return the zctgrL
     */
    public String getZctgrL() {
        return zctgrL;
    }
    /**
     * @param zctgrL the zctgrL to set
     */
    public void setZctgrL(String zctgrL) {
        this.zctgrL = zctgrL;
    }
    /**
     * @return the zctgrLTxt
     */
    public String getZctgrLTxt() {
        return zctgrLTxt;
    }
    /**
     * @param zctgrLTxt the zctgrLTxt to set
     */
    public void setZctgrLTxt(String zctgrLTxt) {
        this.zctgrLTxt = zctgrLTxt;
    }
    /**
     * @return the zctgrM
     */
    public String getZctgrM() {
        return zctgrM;
    }
    /**
     * @param zctgrM the zctgrM to set
     */
    public void setZctgrM(String zctgrM) {
        this.zctgrM = zctgrM;
    }
    /**
     * @return the zctgrMTxt
     */
    public String getZctgrMTxt() {
        return zctgrMTxt;
    }
    /**
     * @param zctgrMTxt the zctgrMTxt to set
     */
    public void setZctgrMTxt(String zctgrMTxt) {
        this.zctgrMTxt = zctgrMTxt;
    }
    /**
     * @return the zctgrS
     */
    public String getZctgrS() {
        return zctgrS;
    }
    /**
     * @param zctgrS the zctgrS to set
     */
    public void setZctgrS(String zctgrS) {
        this.zctgrS = zctgrS;
    }
    /**
     * @return the zctgrSTxt
     */
    public String getZctgrSTxt() {
        return zctgrSTxt;
    }
    /**
     * @param zctgrSTxt the zctgrSTxt to set
     */
    public void setZctgrSTxt(String zctgrSTxt) {
        this.zctgrSTxt = zctgrSTxt;
    }
    /**
     * @return the ziassId
     */
    public String getZiassId() {
        return ziassId;
    }
    /**
     * @param ziassId the ziassId to set
     */
    public void setZiassId(String ziassId) {
        this.ziassId = ziassId;
    }
    /**
     * @return the ziassIdTxt
     */
    public String getZiassIdTxt() {
        return ziassIdTxt;
    }
    /**
     * @param ziassIdTxt the ziassIdTxt to set
     */
    public void setZiassIdTxt(String ziassIdTxt) {
        this.ziassIdTxt = ziassIdTxt;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the zordln
     */
    public BigDecimal getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(BigDecimal zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zreqqty
     */
    public BigDecimal getZreqqty() {
        return zreqqty;
    }
    /**
     * @param zreqqty the zreqqty to set
     */
    public void setZreqqty(BigDecimal zreqqty) {
        this.zreqqty = zreqqty;
    }
    /**
     * @return the meins
     */
    public String getMeins() {
        return meins;
    }
    /**
     * @param meins the meins to set
     */
    public void setMeins(String meins) {
        this.meins = meins;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zcasNo
     */
    public String getZcasNo() {
        return zcasNo;
    }
    /**
     * @param zcasNo the zcasNo to set
     */
    public void setZcasNo(String zcasNo) {
        this.zcasNo = zcasNo;
    }
    /**
     * @return the zticketNo
     */
    public String getZticketNo() {
        return zticketNo;
    }
    /**
     * @param zticketNo the zticketNo to set
     */
    public void setZticketNo(String zticketNo) {
        this.zticketNo = zticketNo;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the zlregio
     */
    public String getZlregio() {
        return zlregio;
    }
    /**
     * @param zlregio the zlregio to set
     */
    public void setZlregio(String zlregio) {
        this.zlregio = zlregio;
    }
    /**
     * @return the zmregio
     */
    public String getZmregio() {
        return zmregio;
    }
    /**
     * @param zmregio the zmregio to set
     */
    public void setZmregio(String zmregio) {
        this.zmregio = zmregio;
    }
    /**
     * @return the zsregio
     */
    public String getZsregio() {
        return zsregio;
    }
    /**
     * @param zsregio the zsregio to set
     */
    public void setZsregio(String zsregio) {
        this.zsregio = zsregio;
    }
    /**
     * @return the zamendcd
     */
    public String getZamendcd() {
        return zamendcd;
    }
    /**
     * @param zamendcd the zamendcd to set
     */
    public void setZamendcd(String zamendcd) {
        this.zamendcd = zamendcd;
    }
    /**
     * @return the zamendcdTxt
     */
    public String getZamendcdTxt() {
        return zamendcdTxt;
    }
    /**
     * @param zamendcdTxt the zamendcdTxt to set
     */
    public void setZamendcdTxt(String zamendcdTxt) {
        this.zamendcdTxt = zamendcdTxt;
    }
    /**
     * @return the zinvNo
     */
    public String getZinvNo() {
        return zinvNo;
    }
    /**
     * @param zinvNo the zinvNo to set
     */
    public void setZinvNo(String zinvNo) {
        this.zinvNo = zinvNo;
    }
    /**
     * @return the zpublic
     */
    public String getZpublic() {
        return zpublic;
    }
    /**
     * @param zpublic the zpublic to set
     */
    public void setZpublic(String zpublic) {
        this.zpublic = zpublic;
    }
    /**
     * @return the zanalyst
     */
    public String getZanalyst() {
        return zanalyst;
    }
    /**
     * @param zanalyst the zanalyst to set
     */
    public void setZanalyst(String zanalyst) {
        this.zanalyst = zanalyst;
    }
    /**
     * @return the zudname
     */
    public String getZudname() {
        return zudname;
    }
    /**
     * @param zudname the zudname to set
     */
    public void setZudname(String zudname) {
        this.zudname = zudname;
    }
    /**
     * @return the zudnameTxt
     */
    public String getZudnameTxt() {
        return zudnameTxt;
    }
    /**
     * @param zudnameTxt the zudnameTxt to set
     */
    public void setZudnameTxt(String zudnameTxt) {
        this.zudnameTxt = zudnameTxt;
    }
    /**
     * @return the zudldate
     */
    public Date getZudldate() {
        return zudldate;
    }
    /**
     * @param zudldate the zudldate to set
     */
    public void setZudldate(Date zudldate) {
        this.zudldate = zudldate;
    }
    /**
     * @return the zudltime
     */
    public Date getZudltime() {
        return zudltime;
    }
    /**
     * @param zudltime the zudltime to set
     */
    public void setZudltime(Date zudltime) {
        this.zudltime = zudltime;
    }
    /**
     * @return the zprcCd
     */
    public String getZprcCd() {
        return zprcCd;
    }
    /**
     * @param zprcCd the zprcCd to set
     */
    public void setZprcCd(String zprcCd) {
        this.zprcCd = zprcCd;
    }
    /**
     * @return the zprcCdTxt
     */
    public String getZprcCdTxt() {
        return zprcCdTxt;
    }
    /**
     * @param zprcCdTxt the zprcCdTxt to set
     */
    public void setZprcCdTxt(String zprcCdTxt) {
        this.zprcCdTxt = zprcCdTxt;
    }
    /**
     * @return the zreqcnt
     */
    public BigDecimal getZreqcnt() {
        return zreqcnt;
    }
    /**
     * @param zreqcnt the zreqcnt to set
     */
    public void setZreqcnt(BigDecimal zreqcnt) {
        this.zreqcnt = zreqcnt;
    }
    /**
     * @return the zsbjt
     */
    public String getZsbjt() {
        return zsbjt;
    }
    /**
     * @param zsbjt the zsbjt to set
     */
    public void setZsbjt(String zsbjt) {
        this.zsbjt = zsbjt;
    }
    /**
     * @return the zathFle1
     */
    public String getZathFle1() {
        return zathFle1;
    }
    /**
     * @param zathFle1 the zathFle1 to set
     */
    public void setZathFle1(String zathFle1) {
        this.zathFle1 = zathFle1;
    }
    /**
     * @return the zathFle2
     */
    public String getZathFle2() {
        return zathFle2;
    }
    /**
     * @param zathFle2 the zathFle2 to set
     */
    public void setZathFle2(String zathFle2) {
        this.zathFle2 = zathFle2;
    }
    /**
     * @return the zathFle3
     */
    public String getZathFle3() {
        return zathFle3;
    }
    /**
     * @param zathFle3 the zathFle3 to set
     */
    public void setZathFle3(String zathFle3) {
        this.zathFle3 = zathFle3;
    }
    /**
     * @return the zathFle4
     */
    public String getZathFle4() {
        return zathFle4;
    }
    /**
     * @param zathFle4 the zathFle4 to set
     */
    public void setZathFle4(String zathFle4) {
        this.zathFle4 = zathFle4;
    }
    /**
     * @return the zathFle5
     */
    public String getZathFle5() {
        return zathFle5;
    }
    /**
     * @param zathFle5 the zathFle5 to set
     */
    public void setZathFle5(String zathFle5) {
        this.zathFle5 = zathFle5;
    }
    /**
     * @return the zreplDt
     */
    public Date getZreplDt() {
        return zreplDt;
    }
    /**
     * @param zreplDt the zreplDt to set
     */
    public void setZreplDt(Date zreplDt) {
        this.zreplDt = zreplDt;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the zrefNo
     */
    public BigDecimal getZrefNo() {
        return zrefNo;
    }
    /**
     * @param zrefNo the zrefNo to set
     */
    public void setZrefNo(BigDecimal zrefNo) {
        this.zrefNo = zrefNo;
    }
    /**
     * @return the zseq
     */
    public BigDecimal getZseq() {
        return zseq;
    }
    /**
     * @param zseq the zseq to set
     */
    public void setZseq(BigDecimal zseq) {
        this.zseq = zseq;
    }    
    
}
