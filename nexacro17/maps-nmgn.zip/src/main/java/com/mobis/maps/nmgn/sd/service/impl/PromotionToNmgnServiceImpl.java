package com.mobis.maps.nmgn.sd.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.PromotionToNmgnService;
import com.mobis.maps.nmgn.sd.vo.PromotionProfileOrderTypeVO;
import com.mobis.maps.nmgn.sd.vo.PromotionProfileVO;
import com.mobis.maps.nmgn.sd.vo.PromotionToNmgnVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionToNmgnServiceImpl.java
 * @Description : ZJSDR20110 [채널 RFC] - Promotion to nMGN
 * @author ChoKyungHo
 * @since 2020. 02. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 02. 26.    ChoKyungHo    	                    최초 생성
 * </pre>
 */

@Service("promotionToNmgnService")
public class PromotionToNmgnServiceImpl extends HService implements PromotionToNmgnService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.PromotionToNmgnService#selectPromotionToNmgn(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.PromotionToNmgnVO)
     */
    @Override
    public Map<String, Object> selectPromotionToNmgn(LoginInfoVO loginInfo, PromotionToNmgnVO paramVO)
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_S_PROMOTION_HEADER;
        
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        MapsRfcMappperUtil.setImportStructure(func, "IS_DATES", paramVO);
        MapsRfcMappperUtil.setImportStructure(func, "IS_ZPPI", paramVO);
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        PromotionToNmgnVO rtnVO = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", PromotionToNmgnVO.class);        
        List<PromotionToNmgnVO> proToNmgnLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, PromotionToNmgnVO.class);
        
        retMap.put("head", rtnVO);
        retMap.put("body", proToNmgnLst);
        
        return retMap;   
    }
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.PromotionToNmgnService#selectPromotionProfileOrderTypeList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.PromotionProfileOrderTypeVO)
     */
    @Override
    public List<PromotionProfileOrderTypeVO> selectPromotionProfileOrderTypeList(LoginInfoVO loginInfo, PromotionProfileOrderTypeVO paramVO)
            throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_S_PROMOTION_ORD_TYPE;
        
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
     
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<PromotionProfileOrderTypeVO> rsltLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, PromotionProfileOrderTypeVO.class);

        return rsltLst;   

    }
    
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.PromotionToNmgnService#selectPromotionProfile(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.PromotionProfileVO)
     */
    @Override
    public List<PromotionProfileVO> selectPromotionProfile(LoginInfoVO loginInfo,
            PromotionProfileVO paramVO) throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_S_PROMOTION_PROFILE;
        
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        MapsRfcMappperUtil.setImportStructure(func, "IS_DATES", paramVO);
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<PromotionProfileVO> rtnLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, PromotionProfileVO.class);
  
        return rtnLst;   
    }
   
}
