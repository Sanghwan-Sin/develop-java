package com.mobis.maps.nmgn.ti.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SupersessionDetailVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 5. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 20.     jiyongdo     	최초 생성
 * </pre>
 */

public class SupersessionDetailVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAREA" )
    private String iZarea;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDISTCD" )
    private String iZdistcd;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZVHC" )
    private String iZvhc;

    //-----[ES_DATA] START-----
    /** Material Number */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPNC" )
    private String zpnc;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZOLD_PNO" )
    private String zoldPno;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZOLD_ITC" )
    private String zoldItc;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZNEW_PNO" )
    private String znewPno;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZNEW_ITC" )
    private String znewItc;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZSTKQTY" )
    private String zstkqty;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZDUE_IN" )
    private String zdueIn;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZLIST_PRICE" )
    private String zlistPrice;
    /** Currency Key */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZQFP" )
    private String zqfp;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZQUP" )
    private String zqup;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZQMP" )
    private String zqmp;
    /** Vehicle Type */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZVEH_TYP" )
    private String zvehTyp;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZLEG1" )
    private String zleg1;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZCHRR_CD" )
    private String zchrrCd;
    /** Color Part */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZCOL_FLG" )
    private String zcolFlg;
    /** HQ SUC */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZSUCCD" )
    private String zsuccd;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZWEIG" )
    private String zweig;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZWUNIT" )
    private String zwunit;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZLENG" )
    private String zleng;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZWIDT" )
    private String zwidt;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZHIGH" )
    private String zhigh;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZLUNIT" )
    private String zlunit;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZINTER_CODE" )
    private String zinterCode;
    //-----[ES_DATA] END-----

    
    //-----[ET_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSEQNO" )
    private Integer zseqno;
    /** Mobis Car Code (Model No) */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZVHC" )
    private String zvhc;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZVHCNM" )
    private String zvhcnm;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSUC" )
    private String zsuc;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZITC" )
    private String zitc;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZNPTNO" )
    private String znptno;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSTDTE" )
    private String zstdte;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZENDTE" )
    private String zendte;
    //-----[ET_DATA] END-----
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iZarea
     */
    public String getiZarea() {
        return iZarea;
    }
    /**
     * @param iZarea the iZarea to set
     */
    public void setiZarea(String iZarea) {
        this.iZarea = iZarea;
    }
    /**
     * @return the iZdistcd
     */
    public String getiZdistcd() {
        return iZdistcd;
    }
    /**
     * @param iZdistcd the iZdistcd to set
     */
    public void setiZdistcd(String iZdistcd) {
        this.iZdistcd = iZdistcd;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZvhc
     */
    public String getiZvhc() {
        return iZvhc;
    }
    /**
     * @param iZvhc the iZvhc to set
     */
    public void setiZvhc(String iZvhc) {
        this.iZvhc = iZvhc;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the zpnc
     */
    public String getZpnc() {
        return zpnc;
    }
    /**
     * @param zpnc the zpnc to set
     */
    public void setZpnc(String zpnc) {
        this.zpnc = zpnc;
    }
    /**
     * @return the zoldPno
     */
    public String getZoldPno() {
        return zoldPno;
    }
    /**
     * @param zoldPno the zoldPno to set
     */
    public void setZoldPno(String zoldPno) {
        this.zoldPno = zoldPno;
    }
    /**
     * @return the zoldItc
     */
    public String getZoldItc() {
        return zoldItc;
    }
    /**
     * @param zoldItc the zoldItc to set
     */
    public void setZoldItc(String zoldItc) {
        this.zoldItc = zoldItc;
    }
    /**
     * @return the znewPno
     */
    public String getZnewPno() {
        return znewPno;
    }
    /**
     * @param znewPno the znewPno to set
     */
    public void setZnewPno(String znewPno) {
        this.znewPno = znewPno;
    }
    /**
     * @return the znewItc
     */
    public String getZnewItc() {
        return znewItc;
    }
    /**
     * @param znewItc the znewItc to set
     */
    public void setZnewItc(String znewItc) {
        this.znewItc = znewItc;
    }
    /**
     * @return the zstkqty
     */
    public String getZstkqty() {
        return zstkqty;
    }
    /**
     * @param zstkqty the zstkqty to set
     */
    public void setZstkqty(String zstkqty) {
        this.zstkqty = zstkqty;
    }
    /**
     * @return the zdueIn
     */
    public String getZdueIn() {
        return zdueIn;
    }
    /**
     * @param zdueIn the zdueIn to set
     */
    public void setZdueIn(String zdueIn) {
        this.zdueIn = zdueIn;
    }
    /**
     * @return the zlistPrice
     */
    public String getZlistPrice() {
        return zlistPrice;
    }
    /**
     * @param zlistPrice the zlistPrice to set
     */
    public void setZlistPrice(String zlistPrice) {
        this.zlistPrice = zlistPrice;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the zqfp
     */
    public String getZqfp() {
        return zqfp;
    }
    /**
     * @param zqfp the zqfp to set
     */
    public void setZqfp(String zqfp) {
        this.zqfp = zqfp;
    }
    /**
     * @return the zqup
     */
    public String getZqup() {
        return zqup;
    }
    /**
     * @param zqup the zqup to set
     */
    public void setZqup(String zqup) {
        this.zqup = zqup;
    }
    /**
     * @return the zqmp
     */
    public String getZqmp() {
        return zqmp;
    }
    /**
     * @param zqmp the zqmp to set
     */
    public void setZqmp(String zqmp) {
        this.zqmp = zqmp;
    }
    /**
     * @return the zvehTyp
     */
    public String getZvehTyp() {
        return zvehTyp;
    }
    /**
     * @param zvehTyp the zvehTyp to set
     */
    public void setZvehTyp(String zvehTyp) {
        this.zvehTyp = zvehTyp;
    }
    /**
     * @return the zleg1
     */
    public String getZleg1() {
        return zleg1;
    }
    /**
     * @param zleg1 the zleg1 to set
     */
    public void setZleg1(String zleg1) {
        this.zleg1 = zleg1;
    }
    /**
     * @return the zchrrCd
     */
    public String getZchrrCd() {
        return zchrrCd;
    }
    /**
     * @param zchrrCd the zchrrCd to set
     */
    public void setZchrrCd(String zchrrCd) {
        this.zchrrCd = zchrrCd;
    }
    /**
     * @return the zcolFlg
     */
    public String getZcolFlg() {
        return zcolFlg;
    }
    /**
     * @param zcolFlg the zcolFlg to set
     */
    public void setZcolFlg(String zcolFlg) {
        this.zcolFlg = zcolFlg;
    }
    /**
     * @return the zsuccd
     */
    public String getZsuccd() {
        return zsuccd;
    }
    /**
     * @param zsuccd the zsuccd to set
     */
    public void setZsuccd(String zsuccd) {
        this.zsuccd = zsuccd;
    }
    /**
     * @return the zweig
     */
    public String getZweig() {
        return zweig;
    }
    /**
     * @param zweig the zweig to set
     */
    public void setZweig(String zweig) {
        this.zweig = zweig;
    }
    /**
     * @return the zwunit
     */
    public String getZwunit() {
        return zwunit;
    }
    /**
     * @param zwunit the zwunit to set
     */
    public void setZwunit(String zwunit) {
        this.zwunit = zwunit;
    }
    /**
     * @return the zleng
     */
    public String getZleng() {
        return zleng;
    }
    /**
     * @param zleng the zleng to set
     */
    public void setZleng(String zleng) {
        this.zleng = zleng;
    }
    /**
     * @return the zwidt
     */
    public String getZwidt() {
        return zwidt;
    }
    /**
     * @param zwidt the zwidt to set
     */
    public void setZwidt(String zwidt) {
        this.zwidt = zwidt;
    }
    /**
     * @return the zhigh
     */
    public String getZhigh() {
        return zhigh;
    }
    /**
     * @param zhigh the zhigh to set
     */
    public void setZhigh(String zhigh) {
        this.zhigh = zhigh;
    }
    /**
     * @return the zlunit
     */
    public String getZlunit() {
        return zlunit;
    }
    /**
     * @param zlunit the zlunit to set
     */
    public void setZlunit(String zlunit) {
        this.zlunit = zlunit;
    }
    /**
     * @return the zinterCode
     */
    public String getZinterCode() {
        return zinterCode;
    }
    /**
     * @param zinterCode the zinterCode to set
     */
    public void setZinterCode(String zinterCode) {
        this.zinterCode = zinterCode;
    }
    /**
     * @return the zseqno
     */
    public Integer getZseqno() {
        return zseqno;
    }
    /**
     * @param zseqno the zseqno to set
     */
    public void setZseqno(Integer zseqno) {
        this.zseqno = zseqno;
    }
    /**
     * @return the zvhc
     */
    public String getZvhc() {
        return zvhc;
    }
    /**
     * @param zvhc the zvhc to set
     */
    public void setZvhc(String zvhc) {
        this.zvhc = zvhc;
    }
    /**
     * @return the zvhcnm
     */
    public String getZvhcnm() {
        return zvhcnm;
    }
    /**
     * @param zvhcnm the zvhcnm to set
     */
    public void setZvhcnm(String zvhcnm) {
        this.zvhcnm = zvhcnm;
    }
    /**
     * @return the zsuc
     */
    public String getZsuc() {
        return zsuc;
    }
    /**
     * @param zsuc the zsuc to set
     */
    public void setZsuc(String zsuc) {
        this.zsuc = zsuc;
    }
    /**
     * @return the zitc
     */
    public String getZitc() {
        return zitc;
    }
    /**
     * @param zitc the zitc to set
     */
    public void setZitc(String zitc) {
        this.zitc = zitc;
    }
    /**
     * @return the znptno
     */
    public String getZnptno() {
        return znptno;
    }
    /**
     * @param znptno the znptno to set
     */
    public void setZnptno(String znptno) {
        this.znptno = znptno;
    }
    /**
     * @return the zstdte
     */
    public String getZstdte() {
        return zstdte;
    }
    /**
     * @param zstdte the zstdte to set
     */
    public void setZstdte(String zstdte) {
        this.zstdte = zstdte;
    }
    /**
     * @return the zendte
     */
    public String getZendte() {
        return zendte;
    }
    /**
     * @param zendte the zendte to set
     */
    public void setZendte(String zendte) {
        this.zendte = zendte;
    }
}
