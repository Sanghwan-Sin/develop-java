package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceFtaCoVO.java
 * @Description : Invoice List, Header, Detail
 * @author jiyongdo
 * @since 2020. 2. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 14.     jiyongdo     	최초 생성
 * </pre>
 */

public class InvoiceFtaCoVO extends MapsCommSapRfcIfCommVO {

    private String invoiceNo;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SEQ" )
    private Integer seq;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZORDLN" )
    private BigDecimal zordln;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="AC" )
    private String ac;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /** Country Key */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LAND1" )
    private String land1;
    /** Actual quantity delivered (in sales units) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LFIMG" )
    private BigDecimal lfimg;
    /** Net Price */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NETPR" )
    private BigDecimal netpr;
    /** Net Value in Document Currency */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NETWR" )
    private BigDecimal netwr;
    /** Commodity Code */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CCNGN" )
    private String ccngn;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LGREG" )
    private String lgreg;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="RCT" )
    private String rct;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="REMARK" )
    private String remark;
    /**
     * @return the invoiceNo
     */
    public String getInvoiceNo() {
        return invoiceNo;
    }

    /**
     * @param invoiceNo the invoiceNo to set
     */
    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }

    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }

    /**
     * @return the seq
     */
    public Integer getSeq() {
        return seq;
    }

    /**
     * @param seq the seq to set
     */
    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }

    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }

    /**
     * @return the zordln
     */
    public BigDecimal getZordln() {
        return zordln;
    }

    /**
     * @param zordln the zordln to set
     */
    public void setZordln(BigDecimal zordln) {
        this.zordln = zordln;
    }

    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }

    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }

    /**
     * @return the ac
     */
    public String getAc() {
        return ac;
    }

    /**
     * @param ac the ac to set
     */
    public void setAc(String ac) {
        this.ac = ac;
    }

    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }

    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }

    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }

    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }

    /**
     * @return the lfimg
     */
    public BigDecimal getLfimg() {
        return lfimg;
    }

    /**
     * @param lfimg the lfimg to set
     */
    public void setLfimg(BigDecimal lfimg) {
        this.lfimg = lfimg;
    }

    /**
     * @return the netpr
     */
    public BigDecimal getNetpr() {
        return netpr;
    }

    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(BigDecimal netpr) {
        this.netpr = netpr;
    }

    /**
     * @return the netwr
     */
    public BigDecimal getNetwr() {
        return netwr;
    }

    /**
     * @param netwr the netwr to set
     */
    public void setNetwr(BigDecimal netwr) {
        this.netwr = netwr;
    }

    /**
     * @return the ccngn
     */
    public String getCcngn() {
        return ccngn;
    }

    /**
     * @param ccngn the ccngn to set
     */
    public void setCcngn(String ccngn) {
        this.ccngn = ccngn;
    }

    /**
     * @return the lgreg
     */
    public String getLgreg() {
        return lgreg;
    }

    /**
     * @param lgreg the lgreg to set
     */
    public void setLgreg(String lgreg) {
        this.lgreg = lgreg;
    }

    /**
     * @return the rct
     */
    public String getRct() {
        return rct;
    }

    /**
     * @param rct the rct to set
     */
    public void setRct(String rct) {
        this.rct = rct;
    }

    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }
}
