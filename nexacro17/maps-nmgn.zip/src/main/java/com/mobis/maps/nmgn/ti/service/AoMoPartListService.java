package com.mobis.maps.nmgn.ti.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.vo.AoMoPartListVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AoMoPartListService.java
 * @Description : ZJTIR02090 AO/MO Part List
 * @author 이수지
 * @since 2020. 5. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 11.       이수지      	        최초 생성
 * </pre>
 */

public interface AoMoPartListService {

    /**
     * AO/MO Part List
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<AoMoPartListVO> selectAoMoPartList (LoginInfoVO loginVo, AoMoPartListVO params) throws Exception;
    
    /**
     * Region
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<AoMoPartListVO> selectRegion (LoginInfoVO loginVo, AoMoPartListVO params) throws Exception;
    
    /**
     * Model
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<AoMoPartListVO> selectModel (LoginInfoVO loginVo, AoMoPartListVO params) throws Exception;
    
    /**
     * AO Detail
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<AoMoPartListVO> selectAoDetail (LoginInfoVO loginVo, AoMoPartListVO params) throws Exception;

    /**
     * MO Detail
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<AoMoPartListVO> selectMoDetail(LoginInfoVO loginVo, AoMoPartListVO params) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<AoMoPartListVO> selectAoMoParentList(LoginInfoVO loginInfo, AoMoPartListVO params) throws Exception;
}
