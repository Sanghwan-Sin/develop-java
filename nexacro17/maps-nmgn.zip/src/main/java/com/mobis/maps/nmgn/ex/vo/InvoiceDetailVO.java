package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceDetailVO.java
 * @Description : Invoice List, Header, Detail
 * @author jiyongdo
 * @since 2020. 2. 6.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 6.     jiyongdo     	최초 생성
 * </pre>
 */

public class InvoiceDetailVO extends MapsCommSapRfcIfCommVO{
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /** 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;       
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ORDER" )
    private String order;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZORDLN" )
    private String zordln;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /** Actual quantity delivered (in sales units) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LFIMG" )
    private BigDecimal lfimg;
    /** Net Price */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NETPR" )
    private BigDecimal netpr;
    /** Net Value in Document Currency */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NETWR" )
    private BigDecimal netwr;
    /** Container NO. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFCARTNO" )
    private String zfcartno;
    /** Country Key */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LAND1" )
    private String land1;
    /** Invoice No. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="INVOICE" )
    private String invoice;
    private String invoiceNo;
    /** Net weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="UNIT_WEIGHT" )
    private BigDecimal unitWeight;
    /** SD 문서 통화 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** 중량 단위 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="GEWEI" )
    private String gewei;    
    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }
    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the order
     */
    public String getOrder() {
        return order;
    }
    /**
     * @param order the order to set
     */
    public void setOrder(String order) {
        this.order = order;
    }
    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the lfimg
     */
    public BigDecimal getLfimg() {
        return lfimg;
    }
    /**
     * @param lfimg the lfimg to set
     */
    public void setLfimg(BigDecimal lfimg) {
        this.lfimg = lfimg;
    }
    /**
     * @return the netpr
     */
    public BigDecimal getNetpr() {
        return netpr;
    }
    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(BigDecimal netpr) {
        this.netpr = netpr;
    }
    /**
     * @return the netwr
     */
    public BigDecimal getNetwr() {
        return netwr;
    }
    /**
     * @param netwr the netwr to set
     */
    public void setNetwr(BigDecimal netwr) {
        this.netwr = netwr;
    }
    /**
     * @return the zfcartno
     */
    public String getZfcartno() {
        return zfcartno;
    }
    /**
     * @param zfcartno the zfcartno to set
     */
    public void setZfcartno(String zfcartno) {
        this.zfcartno = zfcartno;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the invoice
     */
    public String getInvoice() {
        return invoice;
    }
    /**
     * @param invoice the invoice to set
     */
    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }
    /**
     * @return the invoiceNo
     */
    public String getInvoiceNo() {
        return invoiceNo;
    }
    /**
     * @param invoiceNo the invoiceNo to set
     */
    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }
    /**
     * @return the unitWeight
     */
    public BigDecimal getUnitWeight() {
        return unitWeight;
    }
    /**
     * @param unitWeight the unitWeight to set
     */
    public void setUnitWeight(BigDecimal unitWeight) {
        this.unitWeight = unitWeight;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the gewei
     */
    public String getGewei() {
        return gewei;
    }
    /**
     * @param gewei the gewei to set
     */
    public void setGewei(String gewei) {
        this.gewei = gewei;
    }
}
