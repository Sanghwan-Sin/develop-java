package com.mobis.maps.nmgn.sd.service.impl;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.FiexedFieldLenTxtToVoUtil;
import com.mobis.maps.cmmn.util.FileUploadUtil;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileVO;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.OrderConfirmDownloadService;
import com.mobis.maps.nmgn.sd.vo.OrderConfirmDownloadVO;
import com.mobis.maps.nmgn.sd.vo.ZPSDS3256VO;
import com.mobis.maps.nmgn.sd.vo.ZPSDS3258VO;
import com.mobis.maps.nmgn.sd.vo.ZPSDS3260VO;
import com.mobis.maps.nmgn.sd.vo.ZPSDS3266VO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderConfirmDownloadServiceImpl.java
 * @Description : Order Confirm Download
 * @author jiyongdo
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     jiyongdo     	최초 생성
 *  2020. 6.24.     hong.minho      txt to Excel 추가
 * </pre>
 */
@Service("orderConfirmDownloadService")
public class OrderConfirmDownloadServiceImpl extends HService implements OrderConfirmDownloadService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    @Resource(name = "mapsCommFileService")
    private MapsCommFileService mapsCommFileService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderConfirmDownloadService#selectConfirmDownloadList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderConfirmDownloadVO)
     */
    @Override
    public List<OrderConfirmDownloadVO> selectConfirmDownloadList(LoginInfoVO loginInfo,
            OrderConfirmDownloadVO params) throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER_DL_LIST;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        MapsRfcMappperUtil.setImportStructure(func, "IS_DATES", params);
                
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        MapsRfcMappperUtil.setExportParamList(funcRslt, params, loginInfo.getUserLcale());
        
        //*** 조회결과
        List<OrderConfirmDownloadVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, OrderConfirmDownloadVO.class);
        
        return list;
    }

    
    
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderConfirmDownloadService#selectOrderExcelDown(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.comm.vo.MapsCommSapAtchFileVO)
     */
    @Override
    public <T> List<T> selectOrderExcelDown(LoginInfoVO loginInfo, MapsCommSapAtchFileVO params, Class<? extends T> c)
            throws Exception {

        
        // ***** 1. MAPS 첨부파일 다운로드 ************************
        
        MapsCommSapAtchFileVO commSapAtchFile = mapsCommFileService.selectSapAtchFileDetail(params, loginInfo);
        if (commSapAtchFile == null || StringUtils.isBlank(commSapAtchFile.getFilePath())) {
            if (logger.isDebugEnabled()) logger.debug("##### File not exists.");
            return null;
        }
        
        File file = FileUploadUtil.getSapFilePath(commSapAtchFile.getFilePath());
        if (file == null || !file.exists() || !file.isFile()) {
            if (logger.isDebugEnabled()) logger.debug("##### File not exists :", commSapAtchFile.getFilePath());
            return null;
        }

        
        String fileDataTmp = FileUtils.readFileToString(file);
        String[] fileLines = fileDataTmp.split("\n");
        
        if (fileLines == null || fileLines.length <= 0) {
            if (logger.isDebugEnabled()) logger.debug("##### Blank File :", commSapAtchFile.getFilePath());
            return null;
        }


        // ***** 2. TXT 파일을 Dataset 으로 변환 ***************************
        List<T> dsList = this.selectConvert2Data(params, file, c);
        
        return dsList;
        
        
    }
    
    
    
    
    /**
     * Class 별  File Convert
     *
     * @param file
     * @param c
     * @return
     * @throws Exception
     */
    private <T> List<T> selectConvert2Data(MapsCommSapAtchFileVO params, File file, Class<? extends T> c) throws Exception {
        String fileDataTmp = FileUtils.readFileToString(file);
        String[] fileLines = fileDataTmp.split("\n");
        
        if (fileLines == null || fileLines.length <= 0) {
            if (logger.isDebugEnabled()) logger.debug("##### Blank File End.");
            return null;
        }        
    
        // ***** util 초기화 
        FiexedFieldLenTxtToVoUtil convertUtil = new FiexedFieldLenTxtToVoUtil();
        
        // ***** 항목정의
        String[] sDefinitions = this.selectFileSpec(c);
        if (sDefinitions == null || sDefinitions.length <= 0) {
            if (logger.isDebugEnabled()) logger.debug("##### No Spec found.");
            return null;
        }
        convertUtil.setDefinition(sDefinitions);
        
        // ***** field 딜리미터 설정 (입력하지 않으면 " " 스페이스문자)
        convertUtil.setFieldFillDelim(" ");
        
        // ***** row 의 식별인자 (입력하지 않으면 "\r\n")
        convertUtil.setRowDelim("\n");

        
        // Header, Footer 추출
        StringBuffer fileData = new StringBuffer();
        for(int ln = 0; fileLines != null && ln < fileLines.length; ln++) {
            if (ln == 0) { 
                params.setFilePathLeg(fileLines[ln]); // Header
                continue;
            }
            
            if (ln == (fileLines.length - 1) 
                    && fileLines[ln].toUpperCase().trim().startsWith("EOF")) { 
                params.setFilePathLeg2(fileLines[ln]); // Footer
                continue;
            }
            
            if (StringUtils.isBlank(fileLines[ln])) continue;
            
            fileData.append(fileLines[ln]).append("\n");
        }
        
        // list 구성
        List<T> dataList = convertUtil.getExportTxtValues(fileData.toString(), c);
        if(logger.isDebugEnabled()){logger.debug("##### vo Size :", dataList.size()); }
        
        return dataList;
    }




    /**
     * Class 별 Spec. 리턴
     *
     * @param c
     * @return
     * @throws Exception
     */
    private String[] selectFileSpec(Class<?> c) throws Exception {
        String[] rowDefinition = null;
        
        /*
         * ZPSDS3256VO - MOFF : Order Confirm List
         * ZPSDS3266VO - MOSR : Order Status Report
         * ZPSDS3260VO - METD : ETD Result
         * ZPSDS3258VO - MBOR : Backorder Status
         */
        
        if (c == ZPSDS3256VO.class) {
            rowDefinition = new String[]{
                    "detail01,0~10"     ,"detail02,10~18"   ,"detail03,18~26"   ,"detail04,26~37"   ,"detail05,37~46"   ,
                    "detail06,46~53"    ,"detail07,53~60"   ,"detail08,60~67"   ,"detail09,67~71"   ,"detail10,71~72"   ,
                    "detail11,72~90"    ,"detail12,90~103"  ,"detail13,103~110" ,"detail14,110~117" ,"detail15,117~124" ,
                    "detail16,124~126"  ,"detail17,126~144" ,"detail18,144~152" ,"detail19,152~153"
                };
        
        } else if (c == ZPSDS3266VO.class) {
            rowDefinition = new String[]{
                    "dstcd,0~6"         ,"issdt,6~14"       ,"tocnt,14~19"      ,"tbitm,19~26"      ,"tbqty,26~33"      ,
                    "tbamt,33~44"       ,"rcvdt,44~52"      ,"ordno,52~62"      ,"shpmd,62~63"      ,"ordln,63~67"      ,
                    "ordls,67~68"       ,"bptno,68~86"      ,"amdcd,86~88"      ,"bptnm,88~103"     ,"cptno,103~121"    ,
                    "cfqty,121~128"     ,"etddt,128~136"    ,"boqty,136~143"    ,"flqty,143~150"    ,"paqty,150~157"    ,
                    "spqty,157~164"     ,"shpdt,164~172"    ,"invno,172~180"    ,"odfcd,180~181"    ,"intcd,181~182"                    
                };
        
        } else if (c == ZPSDS3260VO.class) {
            rowDefinition = new String[]{
                    "ordno,0~10"        ,"ordln,10~14"      ,"ordls,14~15"      ,"ptno,15~33"       ,"fbqty,33~40"      ,
                    "lbqty,40~47"       ,"prqty,47~54"      ,"spqty,54~61"      ,"prEtddt,61~69"    ,"prEtdqt,69~76"    ,
                    "prNoetd,76~78"     ,"boEtddt,78~86"    ,"boEtdqt,86~93"    ,"boNoetd,93~95"    ,"boProbm,95~97"
                };
        
        } else if (c == ZPSDS3258VO.class) {
            rowDefinition = new String[]{
                    "ordno,0~10"        ,"ordln,10~14"      ,"ordls,14~15"      ,"bptno,15~33"      ,"cfqty,33~38"      ,
                    "spqty,38~43"       ,"fbqty,43~48"      ,"ubqty,48~53"      ,"etddt,53~61"      ,"cptno,61~79"      ,
                    "intcd,79~80"
                };
        
        }
        
        return rowDefinition;
    }



}
