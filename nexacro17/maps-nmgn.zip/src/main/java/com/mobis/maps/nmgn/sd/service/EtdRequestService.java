package com.mobis.maps.nmgn.sd.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.EtdRequestChkVO;
import com.mobis.maps.nmgn.sd.vo.EtdRequestDetailVO;
import com.mobis.maps.nmgn.sd.vo.EtdRequestVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : EtdRequestService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 8.     jiyongdo     	최초 생성
 * </pre>
 */

public interface EtdRequestService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectEtdRequesList(LoginInfoVO loginInfo, EtdRequestVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectEtdRequesDetailList(LoginInfoVO loginInfo, EtdRequestDetailVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVO
     * @param param 
     * @param paramList
     * @param loginInfo
     * @return
     */
    Map<String, Object> multiEtdRequesDetail(EtdRequestDetailVO paramVO, EtdRequestDetailVO param, List<EtdRequestDetailVO> paramList,
            LoginInfoVO loginInfo) throws Exception;

    /**
     * ETD Item Check
     *
     * @param loginInfo
     * @param chkVo
     * @param itemLst
     * @return
     * @throws Exception
     */
    List<EtdRequestDetailVO> selectEtdRechkRtn(LoginInfoVO loginInfo, EtdRequestChkVO chkVo, List<EtdRequestDetailVO> itemLst) throws Exception;

}
