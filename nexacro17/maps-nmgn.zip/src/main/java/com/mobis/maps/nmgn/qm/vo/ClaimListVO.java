package com.mobis.maps.nmgn.qm.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimListVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 23.     jiyongdo     	최초 생성
 * </pre>
 */

public class ClaimListVO extends MapsCommSapRfcIfCommVO{
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CLCODE" )
    private String iClcode;    
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATE_FROM" )
    private String iDateFrom;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATE_TO" )
    private String iDateTo;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_RESULT" )
    private String iResult;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_SCRAP" )
    private String iScrap;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_STATUS" )
    private String iStatus;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCLANO" )
    private String iZclano;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDIST" )
    private String iZdist;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHK" )
    private String iZhk;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPARTGR" )
    private String iZpartgr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSUBDIST" )
    private String iZsubdist;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCRLDATEF" )
    private Date iZcrldatef;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCRLDATET" )
    private Date iZcrldatet;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSUBMDATEF" )
    private Date iZsubmdatef;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSUBMDATET" )
    private Date iZsubmdatet;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZJU_DATEF" )
    private Date iZjuDatef;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZJU_DATET" )
    private Date iZjuDatet;    
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;    
    //-----[T_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="SEQ" )
    private Integer seq;
    /** Customer group 1 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDIST" )
    private String zdist;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDISTX" )
    private String zdistx;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCLANO" )
    private String zclano;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCLSTATUS" )
    private String zclstatus;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCLSTATUS_NAME" )
    private String zclstatusName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZSUSTATUS" )
    private String zsustatus;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZSUSTATTX" )
    private String zsustattx;
    /** Invoice No. */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZINVOICE" )
    private String zinvoice;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCASENO" )
    private String zcaseno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_SUBCLANOH" )
    private String zjuSubclanoh;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZPARTTP" )
    private String zparttp;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZPARTTPX" )
    private String zparttpx;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZPARTGR" )
    private String zpartgr;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZPARTGRX" )
    private String zpartgrx;
    /** Material Number */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZPACKLOT" )
    private String zpacklot;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLCODE" )
    private String clcode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLCODE_NAME" )
    private String clcodeName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLQTY" )
    private String clqty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LAGME" )
    private String lagme;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_CLCODE" )
    private String zjuClcode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_CLCODE_NAME" )
    private String zjuClcodeName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_QTY" )
    private String zjuQty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_QTYUNIT" )
    private String zjuQtyunit;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_RESULT" )
    private String zjuResult;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_RESULTX" )
    private String zjuResultx;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_LASUP" )
    private String zjuLasup;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_LASUPX" )
    private String zjuLasupx;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_LATYPE" )
    private String zjuLatype;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_LATYPEX" )
    private String zjuLatypex;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_RECODE" )
    private String zjuRecode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_RECODEX" )
    private String zjuRecodex;
    /** Create Local Date */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZSUBMDATE" )
    private Date zsubmdate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZSUBMBY" )
    private String zsubmby;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_DATE" )
    private Date zjuDate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_NAME" )
    private String zjuName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_FINHDATE" )
    private Date zjuFinhdate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_SCRAPCHK" )
    private String zjuScrapchk;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_FOCNOH" )
    private String zjuFocnoh;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_UPRICE" )
    private String zjuUprice;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_MARKUP" )
    private String zjuMarkup;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_TOTALRECOST" )
    private String zjuTotalrecost;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_TOTALRECOSTCUR" )
    private String zjuTotalrecostcur;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_AMT3" )
    private String zjuAmt3;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_AMTCU" )
    private String zjuAmtcu;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZREDOCTY" )
    private String zredocty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZREDOCNO" )
    private String zredocno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_FOACT" )
    private String zjuFoact;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_FOACT_NAME" )
    private String zjuFoactName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZJU_ACFINHDATE" )
    private Date zjuAcfinhdate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZRESTDT" )
    private Date zrestdt;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZRESTBY" )
    private String zrestby;    
    //-----[T_DATA] END-----
    private Date claimQtyUnit;
    private Date claimQty;
    
    /**
     * @return the iClcode
     */
    public String getiClcode() {
        return iClcode;
    }
    /**
     * @param iClcode the iClcode to set
     */
    public void setiClcode(String iClcode) {
        this.iClcode = iClcode;
    }
    /**
     * @return the iDateFrom
     */
    public String getiDateFrom() {
        return iDateFrom;
    }
    /**
     * @param iDateFrom the iDateFrom to set
     */
    public void setiDateFrom(String iDateFrom) {
        this.iDateFrom = iDateFrom;
    }
    /**
     * @return the iDateTo
     */
    public String getiDateTo() {
        return iDateTo;
    }
    /**
     * @param iDateTo the iDateTo to set
     */
    public void setiDateTo(String iDateTo) {
        this.iDateTo = iDateTo;
    }
    /**
     * @return the iResult
     */
    public String getiResult() {
        return iResult;
    }
    /**
     * @param iResult the iResult to set
     */
    public void setiResult(String iResult) {
        this.iResult = iResult;
    }
    /**
     * @return the iScrap
     */
    public String getiScrap() {
        return iScrap;
    }
    /**
     * @param iScrap the iScrap to set
     */
    public void setiScrap(String iScrap) {
        this.iScrap = iScrap;
    }
    /**
     * @return the iStatus
     */
    public String getiStatus() {
        return iStatus;
    }
    /**
     * @param iStatus the iStatus to set
     */
    public void setiStatus(String iStatus) {
        this.iStatus = iStatus;
    }
    /**
     * @return the iZclano
     */
    public String getiZclano() {
        return iZclano;
    }
    /**
     * @param iZclano the iZclano to set
     */
    public void setiZclano(String iZclano) {
        this.iZclano = iZclano;
    }
    /**
     * @return the iZdist
     */
    public String getiZdist() {
        return iZdist;
    }
    /**
     * @param iZdist the iZdist to set
     */
    public void setiZdist(String iZdist) {
        this.iZdist = iZdist;
    }
    /**
     * @return the iZhk
     */
    public String getiZhk() {
        return iZhk;
    }
    /**
     * @param iZhk the iZhk to set
     */
    public void setiZhk(String iZhk) {
        this.iZhk = iZhk;
    }
    /**
     * @return the iZpartgr
     */
    public String getiZpartgr() {
        return iZpartgr;
    }
    /**
     * @param iZpartgr the iZpartgr to set
     */
    public void setiZpartgr(String iZpartgr) {
        this.iZpartgr = iZpartgr;
    }
    /**
     * @return the iZsubdist
     */
    public String getiZsubdist() {
        return iZsubdist;
    }
    /**
     * @param iZsubdist the iZsubdist to set
     */
    public void setiZsubdist(String iZsubdist) {
        this.iZsubdist = iZsubdist;
    }
    /**
     * @return the iZcrldatef
     */
    public Date getiZcrldatef() {
        return iZcrldatef;
    }
    /**
     * @param iZcrldatef the iZcrldatef to set
     */
    public void setiZcrldatef(Date iZcrldatef) {
        this.iZcrldatef = iZcrldatef;
    }
    /**
     * @return the iZcrldatet
     */
    public Date getiZcrldatet() {
        return iZcrldatet;
    }
    /**
     * @param iZcrldatet the iZcrldatet to set
     */
    public void setiZcrldatet(Date iZcrldatet) {
        this.iZcrldatet = iZcrldatet;
    }
    /**
     * @return the iZsubmdatef
     */
    public Date getiZsubmdatef() {
        return iZsubmdatef;
    }
    /**
     * @param iZsubmdatef the iZsubmdatef to set
     */
    public void setiZsubmdatef(Date iZsubmdatef) {
        this.iZsubmdatef = iZsubmdatef;
    }
    /**
     * @return the iZsubmdatet
     */
    public Date getiZsubmdatet() {
        return iZsubmdatet;
    }
    /**
     * @param iZsubmdatet the iZsubmdatet to set
     */
    public void setiZsubmdatet(Date iZsubmdatet) {
        this.iZsubmdatet = iZsubmdatet;
    }
    /**
     * @return the iZjuDatef
     */
    public Date getiZjuDatef() {
        return iZjuDatef;
    }
    /**
     * @param iZjuDatef the iZjuDatef to set
     */
    public void setiZjuDatef(Date iZjuDatef) {
        this.iZjuDatef = iZjuDatef;
    }
    /**
     * @return the iZjuDatet
     */
    public Date getiZjuDatet() {
        return iZjuDatet;
    }
    /**
     * @param iZjuDatet the iZjuDatet to set
     */
    public void setiZjuDatet(Date iZjuDatet) {
        this.iZjuDatet = iZjuDatet;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the seq
     */
    public Integer getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the zdist
     */
    public String getZdist() {
        return zdist;
    }
    /**
     * @param zdist the zdist to set
     */
    public void setZdist(String zdist) {
        this.zdist = zdist;
    }
    /**
     * @return the zdistx
     */
    public String getZdistx() {
        return zdistx;
    }
    /**
     * @param zdistx the zdistx to set
     */
    public void setZdistx(String zdistx) {
        this.zdistx = zdistx;
    }
    /**
     * @return the zclano
     */
    public String getZclano() {
        return zclano;
    }
    /**
     * @param zclano the zclano to set
     */
    public void setZclano(String zclano) {
        this.zclano = zclano;
    }
    /**
     * @return the zclstatus
     */
    public String getZclstatus() {
        return zclstatus;
    }
    /**
     * @param zclstatus the zclstatus to set
     */
    public void setZclstatus(String zclstatus) {
        this.zclstatus = zclstatus;
    }
    /**
     * @return the zclstatusName
     */
    public String getZclstatusName() {
        return zclstatusName;
    }
    /**
     * @param zclstatusName the zclstatusName to set
     */
    public void setZclstatusName(String zclstatusName) {
        this.zclstatusName = zclstatusName;
    }
    /**
     * @return the zsustatus
     */
    public String getZsustatus() {
        return zsustatus;
    }
    /**
     * @param zsustatus the zsustatus to set
     */
    public void setZsustatus(String zsustatus) {
        this.zsustatus = zsustatus;
    }
    /**
     * @return the zsustattx
     */
    public String getZsustattx() {
        return zsustattx;
    }
    /**
     * @param zsustattx the zsustattx to set
     */
    public void setZsustattx(String zsustattx) {
        this.zsustattx = zsustattx;
    }
    /**
     * @return the zinvoice
     */
    public String getZinvoice() {
        return zinvoice;
    }
    /**
     * @param zinvoice the zinvoice to set
     */
    public void setZinvoice(String zinvoice) {
        this.zinvoice = zinvoice;
    }
    /**
     * @return the zcaseno
     */
    public String getZcaseno() {
        return zcaseno;
    }
    /**
     * @param zcaseno the zcaseno to set
     */
    public void setZcaseno(String zcaseno) {
        this.zcaseno = zcaseno;
    }
    /**
     * @return the zjuSubclanoh
     */
    public String getZjuSubclanoh() {
        return zjuSubclanoh;
    }
    /**
     * @param zjuSubclanoh the zjuSubclanoh to set
     */
    public void setZjuSubclanoh(String zjuSubclanoh) {
        this.zjuSubclanoh = zjuSubclanoh;
    }
    /**
     * @return the zparttp
     */
    public String getZparttp() {
        return zparttp;
    }
    /**
     * @param zparttp the zparttp to set
     */
    public void setZparttp(String zparttp) {
        this.zparttp = zparttp;
    }
    /**
     * @return the zparttpx
     */
    public String getZparttpx() {
        return zparttpx;
    }
    /**
     * @param zparttpx the zparttpx to set
     */
    public void setZparttpx(String zparttpx) {
        this.zparttpx = zparttpx;
    }
    /**
     * @return the zpartgr
     */
    public String getZpartgr() {
        return zpartgr;
    }
    /**
     * @param zpartgr the zpartgr to set
     */
    public void setZpartgr(String zpartgr) {
        this.zpartgr = zpartgr;
    }
    /**
     * @return the zpartgrx
     */
    public String getZpartgrx() {
        return zpartgrx;
    }
    /**
     * @param zpartgrx the zpartgrx to set
     */
    public void setZpartgrx(String zpartgrx) {
        this.zpartgrx = zpartgrx;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zpacklot
     */
    public String getZpacklot() {
        return zpacklot;
    }
    /**
     * @param zpacklot the zpacklot to set
     */
    public void setZpacklot(String zpacklot) {
        this.zpacklot = zpacklot;
    }
    /**
     * @return the clcode
     */
    public String getClcode() {
        return clcode;
    }
    /**
     * @param clcode the clcode to set
     */
    public void setClcode(String clcode) {
        this.clcode = clcode;
    }
    /**
     * @return the clcodeName
     */
    public String getClcodeName() {
        return clcodeName;
    }
    /**
     * @param clcodeName the clcodeName to set
     */
    public void setClcodeName(String clcodeName) {
        this.clcodeName = clcodeName;
    }
    /**
     * @return the clqty
     */
    public String getClqty() {
        return clqty;
    }
    /**
     * @param clqty the clqty to set
     */
    public void setClqty(String clqty) {
        this.clqty = clqty;
    }
    /**
     * @return the lagme
     */
    public String getLagme() {
        return lagme;
    }
    /**
     * @param lagme the lagme to set
     */
    public void setLagme(String lagme) {
        this.lagme = lagme;
    }
    /**
     * @return the zjuClcode
     */
    public String getZjuClcode() {
        return zjuClcode;
    }
    /**
     * @param zjuClcode the zjuClcode to set
     */
    public void setZjuClcode(String zjuClcode) {
        this.zjuClcode = zjuClcode;
    }
    /**
     * @return the zjuClcodeName
     */
    public String getZjuClcodeName() {
        return zjuClcodeName;
    }
    /**
     * @param zjuClcodeName the zjuClcodeName to set
     */
    public void setZjuClcodeName(String zjuClcodeName) {
        this.zjuClcodeName = zjuClcodeName;
    }
    /**
     * @return the zjuQty
     */
    public String getZjuQty() {
        return zjuQty;
    }
    /**
     * @param zjuQty the zjuQty to set
     */
    public void setZjuQty(String zjuQty) {
        this.zjuQty = zjuQty;
    }
    /**
     * @return the zjuQtyunit
     */
    public String getZjuQtyunit() {
        return zjuQtyunit;
    }
    /**
     * @param zjuQtyunit the zjuQtyunit to set
     */
    public void setZjuQtyunit(String zjuQtyunit) {
        this.zjuQtyunit = zjuQtyunit;
    }
    /**
     * @return the zjuResult
     */
    public String getZjuResult() {
        return zjuResult;
    }
    /**
     * @param zjuResult the zjuResult to set
     */
    public void setZjuResult(String zjuResult) {
        this.zjuResult = zjuResult;
    }
    /**
     * @return the zjuResultx
     */
    public String getZjuResultx() {
        return zjuResultx;
    }
    /**
     * @param zjuResultx the zjuResultx to set
     */
    public void setZjuResultx(String zjuResultx) {
        this.zjuResultx = zjuResultx;
    }
    /**
     * @return the zjuLasup
     */
    public String getZjuLasup() {
        return zjuLasup;
    }
    /**
     * @param zjuLasup the zjuLasup to set
     */
    public void setZjuLasup(String zjuLasup) {
        this.zjuLasup = zjuLasup;
    }
    /**
     * @return the zjuLasupx
     */
    public String getZjuLasupx() {
        return zjuLasupx;
    }
    /**
     * @param zjuLasupx the zjuLasupx to set
     */
    public void setZjuLasupx(String zjuLasupx) {
        this.zjuLasupx = zjuLasupx;
    }
    /**
     * @return the zjuLatype
     */
    public String getZjuLatype() {
        return zjuLatype;
    }
    /**
     * @param zjuLatype the zjuLatype to set
     */
    public void setZjuLatype(String zjuLatype) {
        this.zjuLatype = zjuLatype;
    }
    /**
     * @return the zjuLatypex
     */
    public String getZjuLatypex() {
        return zjuLatypex;
    }
    /**
     * @param zjuLatypex the zjuLatypex to set
     */
    public void setZjuLatypex(String zjuLatypex) {
        this.zjuLatypex = zjuLatypex;
    }
    /**
     * @return the zjuRecode
     */
    public String getZjuRecode() {
        return zjuRecode;
    }
    /**
     * @param zjuRecode the zjuRecode to set
     */
    public void setZjuRecode(String zjuRecode) {
        this.zjuRecode = zjuRecode;
    }
    /**
     * @return the zjuRecodex
     */
    public String getZjuRecodex() {
        return zjuRecodex;
    }
    /**
     * @param zjuRecodex the zjuRecodex to set
     */
    public void setZjuRecodex(String zjuRecodex) {
        this.zjuRecodex = zjuRecodex;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zsubmdate
     */
    public Date getZsubmdate() {
        return zsubmdate;
    }
    /**
     * @param zsubmdate the zsubmdate to set
     */
    public void setZsubmdate(Date zsubmdate) {
        this.zsubmdate = zsubmdate;
    }
    /**
     * @return the zsubmby
     */
    public String getZsubmby() {
        return zsubmby;
    }
    /**
     * @param zsubmby the zsubmby to set
     */
    public void setZsubmby(String zsubmby) {
        this.zsubmby = zsubmby;
    }
    /**
     * @return the zjuDate
     */
    public Date getZjuDate() {
        return zjuDate;
    }
    /**
     * @param zjuDate the zjuDate to set
     */
    public void setZjuDate(Date zjuDate) {
        this.zjuDate = zjuDate;
    }
    /**
     * @return the zjuName
     */
    public String getZjuName() {
        return zjuName;
    }
    /**
     * @param zjuName the zjuName to set
     */
    public void setZjuName(String zjuName) {
        this.zjuName = zjuName;
    }
    /**
     * @return the zjuFinhdate
     */
    public Date getZjuFinhdate() {
        return zjuFinhdate;
    }
    /**
     * @param zjuFinhdate the zjuFinhdate to set
     */
    public void setZjuFinhdate(Date zjuFinhdate) {
        this.zjuFinhdate = zjuFinhdate;
    }
    /**
     * @return the zjuScrapchk
     */
    public String getZjuScrapchk() {
        return zjuScrapchk;
    }
    /**
     * @param zjuScrapchk the zjuScrapchk to set
     */
    public void setZjuScrapchk(String zjuScrapchk) {
        this.zjuScrapchk = zjuScrapchk;
    }
    /**
     * @return the zjuFocnoh
     */
    public String getZjuFocnoh() {
        return zjuFocnoh;
    }
    /**
     * @param zjuFocnoh the zjuFocnoh to set
     */
    public void setZjuFocnoh(String zjuFocnoh) {
        this.zjuFocnoh = zjuFocnoh;
    }
    /**
     * @return the zjuUprice
     */
    public String getZjuUprice() {
        return zjuUprice;
    }
    /**
     * @param zjuUprice the zjuUprice to set
     */
    public void setZjuUprice(String zjuUprice) {
        this.zjuUprice = zjuUprice;
    }
    /**
     * @return the zjuMarkup
     */
    public String getZjuMarkup() {
        return zjuMarkup;
    }
    /**
     * @param zjuMarkup the zjuMarkup to set
     */
    public void setZjuMarkup(String zjuMarkup) {
        this.zjuMarkup = zjuMarkup;
    }
    /**
     * @return the zjuTotalrecost
     */
    public String getZjuTotalrecost() {
        return zjuTotalrecost;
    }
    /**
     * @param zjuTotalrecost the zjuTotalrecost to set
     */
    public void setZjuTotalrecost(String zjuTotalrecost) {
        this.zjuTotalrecost = zjuTotalrecost;
    }
    /**
     * @return the zjuTotalrecostcur
     */
    public String getZjuTotalrecostcur() {
        return zjuTotalrecostcur;
    }
    /**
     * @param zjuTotalrecostcur the zjuTotalrecostcur to set
     */
    public void setZjuTotalrecostcur(String zjuTotalrecostcur) {
        this.zjuTotalrecostcur = zjuTotalrecostcur;
    }
    /**
     * @return the zjuAmt3
     */
    public String getZjuAmt3() {
        return zjuAmt3;
    }
    /**
     * @param zjuAmt3 the zjuAmt3 to set
     */
    public void setZjuAmt3(String zjuAmt3) {
        this.zjuAmt3 = zjuAmt3;
    }
    /**
     * @return the zjuAmtcu
     */
    public String getZjuAmtcu() {
        return zjuAmtcu;
    }
    /**
     * @param zjuAmtcu the zjuAmtcu to set
     */
    public void setZjuAmtcu(String zjuAmtcu) {
        this.zjuAmtcu = zjuAmtcu;
    }
    /**
     * @return the zredocty
     */
    public String getZredocty() {
        return zredocty;
    }
    /**
     * @param zredocty the zredocty to set
     */
    public void setZredocty(String zredocty) {
        this.zredocty = zredocty;
    }
    /**
     * @return the zredocno
     */
    public String getZredocno() {
        return zredocno;
    }
    /**
     * @param zredocno the zredocno to set
     */
    public void setZredocno(String zredocno) {
        this.zredocno = zredocno;
    }
    /**
     * @return the zjuFoact
     */
    public String getZjuFoact() {
        return zjuFoact;
    }
    /**
     * @param zjuFoact the zjuFoact to set
     */
    public void setZjuFoact(String zjuFoact) {
        this.zjuFoact = zjuFoact;
    }
    /**
     * @return the zjuFoactName
     */
    public String getZjuFoactName() {
        return zjuFoactName;
    }
    /**
     * @param zjuFoactName the zjuFoactName to set
     */
    public void setZjuFoactName(String zjuFoactName) {
        this.zjuFoactName = zjuFoactName;
    }
    /**
     * @return the zjuAcfinhdate
     */
    public Date getZjuAcfinhdate() {
        return zjuAcfinhdate;
    }
    /**
     * @param zjuAcfinhdate the zjuAcfinhdate to set
     */
    public void setZjuAcfinhdate(Date zjuAcfinhdate) {
        this.zjuAcfinhdate = zjuAcfinhdate;
    }
    /**
     * @return the zrestdt
     */
    public Date getZrestdt() {
        return zrestdt;
    }
    /**
     * @param zrestdt the zrestdt to set
     */
    public void setZrestdt(Date zrestdt) {
        this.zrestdt = zrestdt;
    }
    /**
     * @return the zrestby
     */
    public String getZrestby() {
        return zrestby;
    }
    /**
     * @param zrestby the zrestby to set
     */
    public void setZrestby(String zrestby) {
        this.zrestby = zrestby;
    }
    /**
     * @return the claimQtyUnit
     */
    public Date getClaimQtyUnit() {
        return claimQtyUnit;
    }
    /**
     * @param claimQtyUnit the claimQtyUnit to set
     */
    public void setClaimQtyUnit(Date claimQtyUnit) {
        this.claimQtyUnit = claimQtyUnit;
    }
    /**
     * @return the claimQty
     */
    public Date getClaimQty() {
        return claimQty;
    }
    /**
     * @param claimQty the claimQty to set
     */
    public void setClaimQty(Date claimQty) {
        this.claimQty = claimQty;
    }
}
