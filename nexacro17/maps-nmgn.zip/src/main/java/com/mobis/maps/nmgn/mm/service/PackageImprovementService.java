package com.mobis.maps.nmgn.mm.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.mm.vo.DuplicationCheckVO;
import com.mobis.maps.nmgn.mm.vo.PackageImproveReqDetailVO;
import com.mobis.maps.nmgn.mm.vo.PackageImproveRequestVO;
import com.mobis.maps.nmgn.mm.vo.PackageImproveSatisfyVO;
import com.mobis.maps.nmgn.mm.vo.PackageImprovementVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingHeaderService.java
 * @Description : ZJMMO20100 포장 개선 리스트
 * @author 이수지
 * @since 2020. 3.5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3.5.        이수지      	        최초 생성
 * </pre>
 */

public interface PackageImprovementService {

    /**
     * Package Improvement
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<PackageImprovementVO> selectPackageImprovement (LoginInfoVO loginVo, PackageImprovementVO params) throws Exception;
    
    /**
     * Duplication Check
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */    
    void selectDuplicationCheck (LoginInfoVO loginVo, DuplicationCheckVO params) throws Exception;

    /**
     * Package Improvement Request 조회
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectPackageImproveRequest(LoginInfoVO loginInfo, PackageImproveReqDetailVO paramVO ) throws Exception;
    
    /**
     * Package Improvement Request 저장
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    void multiSavePackageImproveRequest(LoginInfoVO loginInfo, PackageImproveRequestVO paramVO ) throws Exception;
    
    
    /**
     * Package Improvement 만족도 저장
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    void multiSavePackageImproveSatisfaction(LoginInfoVO loginInfo, PackageImproveSatisfyVO paramVO ) throws Exception;

    /**
     * Package Improvement 삭제
     *
     * @param loginInfo
     * @param params
     */
    void deletePackageImprove(LoginInfoVO loginInfo, PackageImprovementVO params) throws Exception;
}
