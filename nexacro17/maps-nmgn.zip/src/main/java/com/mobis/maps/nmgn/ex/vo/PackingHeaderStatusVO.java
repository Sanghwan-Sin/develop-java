package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingHeaderStatusVO.java
 * @Description : ZPEX_MGN_GET_PACKING_STATUS
 * @author 이수지
 * @since 2020. 2. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 4.       이수지     	       최초 생성
 * </pre>
 */

public class PackingHeaderStatusVO extends MapsCommSapRfcIfCommVO {
    
    /** Carton Box Number */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CASE_NO" )
    private String iCaseNo;
    /** Invoice No. */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    
    /** 총 중량 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_BRGEW_CASE" )
    private BigDecimal eBrgewCase;
    /** [EX] HEIGHT */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_HEIGHT" )
    private Integer eHeight;
    /** [EX] LENGTH */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_LENGTH" )
    private Integer eLength;
    /** 순 중량 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_NTGEW_CASE" )
    private BigDecimal eNtgewCase;
    /** [EX] WIDTH */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_WIDTH" )
    private Integer eWidth;
    /** CBM */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFCBM" )
    private BigDecimal eZfcbm;

    private String caseNo;
    
    /** -----[ET_LIST] START----- */
    
    /** 오더번호 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ORDER" )
    private String order;
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZORDLN" )
    private String zordln;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** 실제수량납품 (판매단위) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LFIMG" )
    private BigDecimal lfimg;
    /** 무게 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZWEIG" )
    private BigDecimal zweig;
    /** Container NO. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFCNTRNO" )
    private String zfcntrno;
    /** Invoice No */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="INVOICE" )
    private String invoice;
    
    /** -----[ET_LIST] END----- */ 
    
    /**
     * @return the iCaseNo
     */
    public String getiCaseNo() {
        return iCaseNo;
    }
    /**
     * @param iCaseNo the iCaseNo to set
     */
    public void setiCaseNo(String iCaseNo) {
        this.iCaseNo = iCaseNo;
    }
    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }
    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }
    /**
     * @return the eBrgewCase
     */
    public BigDecimal geteBrgewCase() {
        return eBrgewCase;
    }
    /**
     * @param eBrgewCase the eBrgewCase to set
     */
    public void seteBrgewCase(BigDecimal eBrgewCase) {
        this.eBrgewCase = eBrgewCase;
    }
    /**
     * @return the eHeight
     */
    public Integer geteHeight() {
        return eHeight;
    }
    /**
     * @param eHeight the eHeight to set
     */
    public void seteHeight(Integer eHeight) {
        this.eHeight = eHeight;
    }
    /**
     * @return the eLength
     */
    public Integer geteLength() {
        return eLength;
    }
    /**
     * @param eLength the eLength to set
     */
    public void seteLength(Integer eLength) {
        this.eLength = eLength;
    }
    /**
     * @return the eNtgewCase
     */
    public BigDecimal geteNtgewCase() {
        return eNtgewCase;
    }
    /**
     * @param eNtgewCase the eNtgewCase to set
     */
    public void seteNtgewCase(BigDecimal eNtgewCase) {
        this.eNtgewCase = eNtgewCase;
    }
    /**
     * @return the eWidth
     */
    public Integer geteWidth() {
        return eWidth;
    }
    /**
     * @param eWidth the eWidth to set
     */
    public void seteWidth(Integer eWidth) {
        this.eWidth = eWidth;
    }
    /**
     * @return the eZfcbm
     */
    public BigDecimal geteZfcbm() {
        return eZfcbm;
    }
    /**
     * @param eZfcbm the eZfcbm to set
     */
    public void seteZfcbm(BigDecimal eZfcbm) {
        this.eZfcbm = eZfcbm;
    }
    /**
     * @return the order
     */
    public String getOrder() {
        return order;
    }
    /**
     * @param order the order to set
     */
    public void setOrder(String order) {
        this.order = order;
    }
    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the lfimg
     */
    public BigDecimal getLfimg() {
        return lfimg;
    }
    /**
     * @param lfimg the lfimg to set
     */
    public void setLfimg(BigDecimal lfimg) {
        this.lfimg = lfimg;
    }
    /**
     * @return the zweig
     */
    public BigDecimal getZweig() {
        return zweig;
    }
    /**
     * @param zweig the zweig to set
     */
    public void setZweig(BigDecimal zweig) {
        this.zweig = zweig;
    }
    /**
     * @return the zfcntrno
     */
    public String getZfcntrno() {
        return zfcntrno;
    }
    /**
     * @param zfcntrno the zfcntrno to set
     */
    public void setZfcntrno(String zfcntrno) {
        this.zfcntrno = zfcntrno;
    }
    /**
     * @return the caseNo
     */
    public String getCaseNo() {
        return caseNo;
    }
    /**
     * @param caseNo the caseNo to set
     */
    public void setCaseNo(String caseNo) {
        this.caseNo = caseNo;
    }
    /**
     * @return the invoice
     */
    public String getInvoice() {
        return invoice;
    }
    /**
     * @param invoice the invoice to set
     */
    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
              
}
