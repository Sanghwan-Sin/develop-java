package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.nmgn.cc.vo.MailingVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistMailingMgrService.java
 * @Description : 대리점Mailing 대상 조회 , 메일보내기
 * @author hong.minho
 * @since 2020. 4. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 14.     hong.minho     	최초 생성
 * </pre>
 */

public interface DistMailingMgrService {
    
    /**
     * Mailing Group ID 를 해당 그룹 조회조건VO로 파싱
     *
     * @param gids
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    public List<MailingVO> selectParseGID(String gids) throws MapsBizException, Exception;
    
    /**
     * 메일링목록조회
     *
     * @param vo
     * @return
     * @throws Exception
     */
    public List<MailingVO> selectMailingLst(MailingVO vo) throws MapsBizException, Exception;
    
    
    
    /**
     * 메일링목록조회
     *
     * @param gids 메일링그룹ID ex) ASIA, OTHERS<|H|ASA|APC|AUS> , ASIA<|H|ASA>, A00HAS TEST Dist<|H|ASA|APC|AUS|1I4OA00HAS>
     * @param emlTp 메일링구분 (M000000021) ex) 10:Order, 11:claim, 13:VOC, 60:news Letter
     * @return
     * @throws Exception
     */
    public List<MailingVO> selectMailingLst(String gids, String emlTp) throws MapsBizException, Exception;


    /**
     * 메일링목록조회
     *
     * @param gids 메일링그룹ID ex) ASIA, OTHERS<|H|ASA|APC|AUS> , ASIA<|H|ASA>, A00HAS TEST Dist<|H|ASA|APC|AUS|1I4OA00HAS>
     * @param emlTp 메일링구분 (M000000021) ex) 10:Order, 11:claim, 13:VOC, 60:news Letter
     * @return 컴마(,)로 구분된 메일주소들의 String  ex) foo@gmail.com,bar@gmail.com
     * @throws Exception
     */
    public String selectMailingString(String gids, String emlTp) throws MapsBizException, Exception;
}
