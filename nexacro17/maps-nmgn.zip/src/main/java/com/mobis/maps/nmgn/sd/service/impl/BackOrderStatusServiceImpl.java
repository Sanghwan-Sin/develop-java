package com.mobis.maps.nmgn.sd.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.BackOrderStatusService;
import com.mobis.maps.nmgn.sd.vo.BackOrderStatusVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : BackOrderStatusServiceImpl.java
 * @Description : BackOrder Status
 * @author 이수지
 * @since 2020. 06. 08.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 08.      이수지      	        최초 생성
 * </pre>
 */

@Service("backOrderStatusService")
public class BackOrderStatusServiceImpl extends HService implements BackOrderStatusService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.BackOrderStatusService#selectListPrice(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.BackOrderStatusVO)
     */
    @Override
    public Map<String, Object> selectBackOrderStatus(LoginInfoVO loginVo, BackOrderStatusVO params)
            throws Exception {

        Map<String, Object> retMap  = new HashMap<String, Object>();
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_BO_STATUS;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과        
        BackOrderStatusVO total = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_TOTAL", BackOrderStatusVO.class);
        List<BackOrderStatusVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, BackOrderStatusVO.class);
        
        retMap.put("result1", total);
        retMap.put("result2", list);
        
        return retMap;
    }

}
