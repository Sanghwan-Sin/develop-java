package com.mobis.maps.nmgn.mm.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.mm.service.PackageImprovementService;
import com.mobis.maps.nmgn.mm.vo.DuplicationCheckVO;
import com.mobis.maps.nmgn.mm.vo.PackageImproveReqDetailVO;
import com.mobis.maps.nmgn.mm.vo.PackageImproveRequestVO;
import com.mobis.maps.nmgn.mm.vo.PackageImproveSatisfyVO;
import com.mobis.maps.nmgn.mm.vo.PackageImprovementVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingHeaderController.java
 * @Description : ZJMMO20100 포장 개선 리스트
 * @author 이수지
 * @since 2020. 3.5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3.5.        이수지                최초 생성
 * </pre>
 */

@Controller
public class PackageImprovementController extends HController {

    @Resource(name = "packageImprovementService")
    private PackageImprovementService packageImprovementService;

    /**
     * selectPackageImprovement
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/mm/selectPackageImprovement.do")
    public NexacroResult selectPackageImprovement(@ParamDataSet(name="dsInput") PackageImprovementVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PackageImprovementVO> list = packageImprovementService.selectPackageImprovement(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectPackageImprovementExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/mm/selectPackageImprovementExcelDown.do")
    public NexacroResult selectPackageImprovementExcelDown(@ParamDataSet(name = "dsInput") PackageImprovementVO params,
            NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());

        List<PackageImprovementVO> list = packageImprovementService.selectPackageImprovement(loginInfo, params);

        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectDuplicationCheck
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/mm/selectDuplicationCheck.do")
    public NexacroResult selectDuplicationCheck(@ParamDataSet(name = "dsInput") DuplicationCheckVO params,
            NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        packageImprovementService.selectDuplicationCheck(loginInfo, params);

        result.addDataSet("dsOutput", params);

        return result;
    }
    
    /**
     * selectPackageImproveRequest 조회
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/mm/selectPackageImproveRequest.do")
    public NexacroResult selectPackageImproveRequest(@ParamDataSet(name="dsInput") PackageImproveReqDetailVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = packageImprovementService.selectPackageImproveRequest(loginInfo, paramVO);

        PackageImproveReqDetailVO retVO = (PackageImproveReqDetailVO)retMap.get("rsltVO");
        
        result.addDataSet("dsReturn", paramVO);
        result.addDataSet("dsOutput", retVO);
        
        return result;
    }
    
    /**
     * savePackageImproveRequest 임시저장 및 신규 생성
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/mm/multiSavePackageImproveRequest.do")
    public NexacroResult multiSavePackageImproveRequest(@ParamDataSet(name="dsInput") PackageImproveRequestVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        packageImprovementService.multiSavePackageImproveRequest(loginInfo, paramVO);

        result.addDataSet("dsReturn", paramVO);
        result.addDataSet("dsOutput", paramVO);
        
        return result;
    }
    
    
    /**
     * savePackageImproveSatisfaction 만족도 저장
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/mm/multiSavePackageImproveSatisfaction.do")
    public NexacroResult multiSavePackageImproveSatisfaction(@ParamDataSet(name="dsInput") PackageImproveSatisfyVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        packageImprovementService.multiSavePackageImproveSatisfaction(loginInfo, paramVO);

        result.addDataSet("dsReturn", paramVO);
        
        return result;
    }
    
    /**
     * deletePackageImprove
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/mm/deletePackageImprove.do")
    public NexacroResult deletePackageImprove(@ParamDataSet(name = "dsInput") PackageImprovementVO params,
            NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        packageImprovementService.deletePackageImprove(loginInfo, params);

        result.addDataSet("dsOutput", params);

        return result;
    }
}
