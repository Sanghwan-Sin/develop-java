package com.mobis.maps.smpl.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.smpl.service.MapsSmplBoardService;
import com.mobis.maps.smpl.vo.MapsSmplBoardVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplBoardController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class MapsSmplBoardController extends HController{
    @Resource(name = "mapsSmplBoardService")
    private MapsSmplBoardService mapsSmplBoardService;
    
    @RequestMapping(value = "/smpl/selectSmplBoardList.do")
    public NexacroResult selectSmplBoardList(@ParamDataSet(name="dsInput") MapsSmplBoardVO inputVO
                                           , NexacroResult result) throws Exception {
        List<MapsSmplBoardVO> resultVo = mapsSmplBoardService.selectSmplBoardList(inputVO);

        result.addDataSet("dsOutput", resultVo);

        return result;
    }    
    
    @RequestMapping(value = "/smpl/selectSmplBoardNewList.do")
    public NexacroResult selectSmplBoardNewList(@ParamDataSet(name="dsInput") MapsSmplBoardVO inputVO
                                              , NexacroResult result) throws Exception {
        MapsSmplBoardVO resultVo = mapsSmplBoardService.selectSmplBoardNewList(inputVO);

        result.addDataSet("dsOutput", resultVo);

        return result;
    }      
    
    @RequestMapping(value = "/smpl/multiSmplBoard.do")
    public NexacroResult multiSmplBoard(@ParamDataSet(name="dsInput") MapsSmplBoardVO inputVO
                                      , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        inputVO.setRegistId(loginInfo.getUserId());
        inputVO.setUpdtId(loginInfo.getUserId());
        
        MapsSmplBoardVO resultVo = mapsSmplBoardService.multiSmplBoard(inputVO);
        //int cnt = mapsSmplBoardService.multiSmplBoard(inputVO);
        //result.addVariable("procCnt", cnt);
        result.addDataSet("dsOutput", resultVo);

        return result;
    }   
    
    /**
     * 샘플 첨부파일 등록
     *
     * @param DpomManualVO
     * @param atchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/smpl/multiAtchFile.do")
    public NexacroResult multiAtchFile(
            @ParamDataSet(name="dsInput") MapsSmplBoardVO atchFileVO
            , @ParamDataSet(name="dsInputAtchFile") List<MapsAtchFileVO> atchFiles
            , NexacroResult result) throws Exception {
        
        int procCnt = mapsSmplBoardService.multiAtchFile(atchFileVO, atchFiles);

        result.addVariable("procCnt", procCnt);

        return result;
    }        
}
