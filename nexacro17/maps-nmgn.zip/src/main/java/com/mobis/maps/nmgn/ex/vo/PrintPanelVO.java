package com.mobis.maps.nmgn.ex.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PrintPanelVO.java
 * @Description : ZPEX_MGN_GET_PANEL_LIST , ZPEX_MGN_GET_SHIPPING_ADVICE
 * @author 이수지
 * @since 2020. 06. 03.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 03      이수지     	       최초 생성
 * </pre>
 */

public class PrintPanelVO extends MapsCommSapRfcIfCommVO {    
    
    /** Doc Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="DOC_TYPE" )
    private String docType;
    /** Invoice No */
    @MapsRfcMappper( ipttSe="I", fieldKey="INVOICE_SA" )
    private String invoiceSa;
    /** Invoice No */
    @MapsRfcMappper( ipttSe="I", fieldKey="INVOICE_NO" )
    private String invoiceNo;
   
    /** -----[ET_FILE] START----- */
    
    /** Insurance */
    @MapsRfcMappper( targetName="ET_FILE", ipttSe="E", fieldKey="IP" )
    private String ip;
    /** Certificate of Origin */
    @MapsRfcMappper( targetName="ET_FILE", ipttSe="E", fieldKey="CO" )
    private String co;
    /** Bill of Lading */
    @MapsRfcMappper( targetName="ET_FILE", ipttSe="E", fieldKey="BL" )
    private String bl;
    /**  */
    @MapsRfcMappper( targetName="ET_FILE", ipttSe="E", fieldKey="FTA" )
    private String fta;
    /**  */
    @MapsRfcMappper( targetName="ET_FILE", ipttSe="E", fieldKey="ETC" )
    private String etc;
    
    /** -----[ET_FILE] END----- */
    
    
    /** -----[ET_TAB1] START----- */
    
    /** File ID */
    @MapsRfcMappper( targetName="ET_TAB1", ipttSe="E", fieldKey="FILE_SEQNO" )
    private String fileSeqno;
    /** Ref No */
    @MapsRfcMappper( targetName="ET_TAB1", ipttSe="E", fieldKey="REF_NO" )
    private String refNo;
    /** File Server ID */
    @MapsRfcMappper( targetName="ET_TAB1", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;
    /** File Name */
    @MapsRfcMappper( targetName="ET_TAB1", ipttSe="E", fieldKey="FILE_NAME" )
    private String fileName;
    
    /** -----[ET_TAB1] END----- */
       

    /** -----[ET_TAB1,ET_TAB2,ET_TAB3] START----- */
    
    /** Company Code */
    @MapsRfcMappper( targetName="ET_TAB1|ET_TAB2|ET_TAB3", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** Code Name */
    @MapsRfcMappper( targetName="ET_TAB1|ET_TAB2|ET_TAB3", ipttSe="E", fieldKey="DOC_NAME" )
    private String docName;
    /** Managerment Code */
    @MapsRfcMappper( targetName="ET_TAB1|ET_TAB2|ET_TAB3", ipttSe="E", fieldKey="DOC_CODE" )
    private String docCode;
    /**  */
    @MapsRfcMappper( targetName="ET_TAB1|ET_TAB2|ET_TAB3", ipttSe="E", fieldKey="CHK_BOX" )
    private String chkBox;
    /** Code 7 */
    @MapsRfcMappper( targetName="ET_TAB1|ET_TAB2|ET_TAB3", ipttSe="E", fieldKey="FUNC_NAME" )
    private String funcName;
    /** Print sheets */
    @MapsRfcMappper( targetName="ET_TAB2", ipttSe="E", fieldKey="COPIES" )
    private Integer copies;
    /** 유형 구분 */
    @MapsRfcMappper( targetName="ET_TAB1|ET_TAB2|ET_TAB3", ipttSe="E", fieldKey="PRT_TYPE" )
    private String prtType;
   
  
    /** -----[ET_TAB1,ET_TAB2,ET_TAB3] END----- */

    /**
     * @return the fileSeqno
     */
    public String getFileSeqno() {
        return fileSeqno;
    }
    /**
     * @param fileSeqno the fileSeqno to set
     */
    public void setFileSeqno(String fileSeqno) {
        this.fileSeqno = fileSeqno;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }
    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    /**
     * @return the invoiceNo
     */
    public String getInvoiceNo() {
        return invoiceNo;
    }
    /**
     * @param invoiceNo the invoiceNo to set
     */
    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the docName
     */
    public String getDocName() {
        return docName;
    }
    /**
     * @param docName the docName to set
     */
    public void setDocName(String docName) {
        this.docName = docName;
    }
    /**
     * @return the docCode
     */
    public String getDocCode() {
        return docCode;
    }
    /**
     * @param docCode the docCode to set
     */
    public void setDocCode(String docCode) {
        this.docCode = docCode;
    }
    /**
     * @return the chkBox
     */
    public String getChkBox() {
        return chkBox;
    }
    /**
     * @param chkBox the chkBox to set
     */
    public void setChkBox(String chkBox) {
        this.chkBox = chkBox;
    }
    /**
     * @return the funcName
     */
    public String getFuncName() {
        return funcName;
    }
    /**
     * @param funcName the funcName to set
     */
    public void setFuncName(String funcName) {
        this.funcName = funcName;
    }
    /**
     * @return the copies
     */
    public Integer getCopies() {
        return copies;
    }
    /**
     * @param copies the copies to set
     */
    public void setCopies(Integer copies) {
        this.copies = copies;
    }
    /**
     * @return the docType
     */
    public String getDocType() {
        return docType;
    }
    /**
     * @param docType the docType to set
     */
    public void setDocType(String docType) {
        this.docType = docType;
    }
    /**
     * @return the invoiceSa
     */
    public String getInvoiceSa() {
        return invoiceSa;
    }
    /**
     * @param invoiceSa the invoiceSa to set
     */
    public void setInvoiceSa(String invoiceSa) {
        this.invoiceSa = invoiceSa;
    }
    /**
     * @return the prtType
     */
    public String getPrtType() {
        return prtType;
    }
    /**
     * @param prtType the prtType to set
     */
    public void setPrtType(String prtType) {
        this.prtType = prtType;
    }
    /**
     * @return the ip
     */
    public String getIp() {
        return ip;
    }
    /**
     * @param ip the ip to set
     */
    public void setIp(String ip) {
        this.ip = ip;
    }
    /**
     * @return the co
     */
    public String getCo() {
        return co;
    }
    /**
     * @param co the co to set
     */
    public void setCo(String co) {
        this.co = co;
    }
    /**
     * @return the bl
     */
    public String getBl() {
        return bl;
    }
    /**
     * @param bl the bl to set
     */
    public void setBl(String bl) {
        this.bl = bl;
    }
    /**
     * @return the fta
     */
    public String getFta() {
        return fta;
    }
    /**
     * @param fta the fta to set
     */
    public void setFta(String fta) {
        this.fta = fta;
    }
    /**
     * @return the etc
     */
    public String getEtc() {
        return etc;
    }
    /**
     * @param etc the etc to set
     */
    public void setEtc(String etc) {
        this.etc = etc;
    }
    
}