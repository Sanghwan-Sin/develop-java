package com.mobis.maps.nmgn.ex.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.service.CertificateInvoiceService;
import com.mobis.maps.nmgn.ex.vo.CertificateInvoiceVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CertiOriginInvoiceController.java
 * @Description : ZJEXR00200 Packing Detail
 * @author 조경호
 * @since 2020. 2. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 12.       조경호                                           최초 생성
 * </pre>
 */

@Controller
public class CertiOriginInvoiceController extends HController {

    @Resource(name = "certificateInvoiceService")
    private CertificateInvoiceService certificateInvoiceService;

    /**
     * selectCertificateInvoice
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectCertificateInvoice.do")
    public NexacroResult selectCertificateInvoice(@ParamDataSet(name="dsInput") CertificateInvoiceVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<CertificateInvoiceVO> list = certificateInvoiceService.selectCertificateInvoice(loginInfo, paramVO);

        result.addDataSet("dsReturn", paramVO);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectCertificateInvoiceExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectCertificateInvoiceExcelDown.do")
    public NexacroResult selectCertificateInvoiceExcelDown(@ParamDataSet(name="dsInput") CertificateInvoiceVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());
        
//        List<CertificateInvoiceExcelDownVO> list = certificateInvoiceService.selectCertificateInvoiceExcelDown(loginInfo, paramVO);
//        
//        if (list.size()==0) {
//            throw new MapsBizException(messageSource, "WC00000013"); // Data does not exist.
//        }else{
//            result.addDataSet("dsOutput", list);
//            result.addDataSet("dsReturn", paramVO);
//        }
        List<CertificateInvoiceVO> list = certificateInvoiceService.selectCertificateInvoice(loginInfo, paramVO);

        result.addDataSet("dsOutput", list);        
        
        return result;
    }
}
