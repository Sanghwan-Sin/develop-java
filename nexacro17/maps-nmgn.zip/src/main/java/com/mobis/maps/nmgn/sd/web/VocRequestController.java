package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.nmgn.sd.service.VocRequestService;
import com.mobis.maps.nmgn.sd.vo.AmendCodeVO;
import com.mobis.maps.nmgn.sd.vo.VocRequestVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : VocRequestController.java
 * @Description : VOC Request (HQ)
 * @author hong.minho
 * @since 2020. 6. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 8.     hong.minho     	최초 생성
 * </pre>
 */

@Controller
public class VocRequestController extends HController {
    
    @Resource(name="vocRequestService")
    VocRequestService service;


    /**
     * VOC Detail
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectVOCDetail.do")
    public NexacroResult selectVOCDetail(@ParamDataSet(name = "dsInput") VocRequestVO paramVO,
            NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        VocRequestVO rsltVo = service.selectVOCDetail(loginInfo, paramVO);
        
        result.addDataSet("dsOutput", rsltVo);
        result.addDataSet("dsReturn", paramVO);
        result.addDataSet("dsContents", rsltVo.gettContents());
        
        return result;
    }


    /**
     * Statements
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/multiSaveVOCDetail.do")
    public NexacroResult multiSaveVOCDetail(@ParamDataSet(name = "dsInput") VocRequestVO paramVO,
            NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        VocRequestVO rsltVo = service.multiSaveVOCDetail(loginInfo, paramVO);
        
        if (logger.isDebugEnabled()) { // FSCODE
            logger.debug("### FSCODE:" + rsltVo.getFscode());
        }
        
        // 결과 성공이면 재조회
        if (!"E".equals(paramVO.getMsgType())) {
            paramVO.setZticketNo(rsltVo.getZticketNo());
            
            return this.selectVOCDetail(paramVO, result);
        }

        // 오류인 경우만 흐름
        result.addDataSet("dsOutput", rsltVo);
        result.addDataSet("dsReturn", paramVO);
        result.addDataSet("dsContents", rsltVo.gettContents());
        
        return result;
    }


    
    /**
     * Amend Code List
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/comm/code/selectAmendCdLst.do")
    public NexacroResult selectAmendCdLst(@ParamDataSet(name = "dsInput") AmendCodeVO paramVO,
            NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsOrgnztDistVO orgInfo = (MapsOrgnztDistVO) getSessionAttribute(MapsConstants.SSS_ORGNZT_INFO);
        
        if (orgInfo == null) { // default value
            orgInfo = new MapsOrgnztDistVO();
            orgInfo.setVkorg("1000");
            orgInfo.setVtweg("E");
        }
        
        // Params Setting
        paramVO.setiVkorg(StringUtils.isBlank(paramVO.getiVkorg()) ? orgInfo.getVkorg() : paramVO.getiVkorg()); // 법인코드
        paramVO.setiVtweg(StringUtils.isBlank(paramVO.getiVtweg()) ? orgInfo.getVtweg() : paramVO.getiVtweg()); // 유통구분
        paramVO.setiType("R");
        paramVO.setPgSize(5000);
        
        List<AmendCodeVO> rsltVo = service.selectAmendCdLst(loginInfo, paramVO);
        
        result.addDataSet("dsOutput", rsltVo);
        result.addDataSet("dsReturn", paramVO);
        
        return result;
    }
    
}
