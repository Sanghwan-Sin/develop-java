package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.AmAccApplyPriceService;
import com.mobis.maps.nmgn.sd.vo.AmAccApplyPriceVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AmAccApplyPriceController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 25.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class AmAccApplyPriceController extends HController{
    
    @Resource(name = "amAccApplyPriceService")
    private AmAccApplyPriceService amAccApplyPriceService;

    /**
     * 조회
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectAmAccApplyPriceList.do")
    public NexacroResult selectAmAccApplyPriceList (@ParamDataSet(name="dsInput") AmAccApplyPriceVO paramVO
                                                  , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = amAccApplyPriceService.selectAmAccApplyPriceList(loginInfo, paramVO);
        
        @SuppressWarnings("unchecked")
        List<AmAccApplyPriceVO> retList = (List<AmAccApplyPriceVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList);

        result.addDataSet("dsReturn", paramVO);   

        return result;
    }
    
    /**
     * selectAccountCdListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectAmAccApplyPriceListExcelDown.do")
    public NexacroResult selectAmAccApplyPriceListExcelDown(@ParamDataSet(name="dsInput") AmAccApplyPriceVO paramVO
                                                             , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);     
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(5000);        
        
        Map<String, Object> retMap = amAccApplyPriceService.selectAmAccApplyPriceList(loginInfo, paramVO);
        
        @SuppressWarnings("unchecked")
        List<AmAccApplyPriceVO> retList = (List<AmAccApplyPriceVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList);

        return result;
    }       
}
