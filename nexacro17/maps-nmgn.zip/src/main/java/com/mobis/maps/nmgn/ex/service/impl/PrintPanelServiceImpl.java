package com.mobis.maps.nmgn.ex.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ex.service.PrintPanelService;
import com.mobis.maps.nmgn.ex.vo.PrintPanelVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PrintPanelServiceImpl.java
 * @Description : ZPEXF00290 Print Panel
 * @author 이수지
 * @since 2020. 06. 03.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 03.      이수지      	      최초 생성
 * </pre>
 */

@Service("printPanelService")
public class PrintPanelServiceImpl extends HService implements PrintPanelService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.ex.service.PrintPanelService#selectPrintPanel(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.PrintPanelVO)
     */
    @Override
    public List<PrintPanelVO> selectShippingAdviceImageFile(LoginInfoVO loginVo, PrintPanelVO params)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_GET_SHIPPING_ADVICE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        
        //*** 조회결과
        List<PrintPanelVO> list = MapsRfcMappperUtil.getExportTableValues(funcRslt, "ET_TAB1", PrintPanelVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.PrintPanelService#selectPrintPanel(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ex.vo.PrintPanelVO)
     */
    @Override
    public Map<String, Object> selectPrintPanel(LoginInfoVO loginVo, PrintPanelVO params) 
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_GET_PANEL_LIST;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<PrintPanelVO> list1 = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_TAB1", params, PrintPanelVO.class);
        List<PrintPanelVO> list2 = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_TAB2", params, PrintPanelVO.class);
        List<PrintPanelVO> list3 = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_TAB3", params, PrintPanelVO.class);
        List<PrintPanelVO> fileVo = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_FILE", params, PrintPanelVO.class);
        
        retMap.put("table1", list1);
        retMap.put("table2", list2);
        retMap.put("table3", list3);
        retMap.put("table4", fileVo);
        
        return retMap;
    }

}
