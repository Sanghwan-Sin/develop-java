package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.FaqMnlManageService;
import com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FaqMnlManageController.java
 * @Description : FaqMnlManageController
 * @author choi.cheolho
 * @since 2019. 10. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 17.     choi.cheolho         최초 생성
 * </pre>
 */
@Controller
public class FaqMnlManageController extends HController {

    @Resource(name = "faqMnlManageService")
    private FaqMnlManageService faqMnlManageService;
    
    /**
     * FAQ List 조회
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectFaqList.do")
    public NexacroResult selectFaqList(
            @ParamDataSet(name="dsInput") FaqMnlManageVO paramVO
            , NexacroResult result) throws Exception {
        
        List<FaqMnlManageVO> retList = faqMnlManageService.selectFaqList(paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }
    
    /**
     * FAQ 조회
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectFaqEditList.do")
    public NexacroResult selectFaqEditList(@ParamDataSet(name="dsInput") FaqMnlManageVO paramVO
                                         , NexacroResult result) throws Exception {
        
        FaqMnlManageVO ret = faqMnlManageService.selectFaqEditList(paramVO);

        result.addDataSet("dsOutput", ret);

        return result;
    }
    
    
    
    
    /**
     * FAQ 등록
     *
     * @param msgInfos
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/insertFaqManage.do")
    public NexacroResult insertFaqManage(
            @ParamDataSet(name="dsInput") FaqMnlManageVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setRegistId(loginInfo.getUserId());
        paramVO.setUpdtId(loginInfo.getUserId());

        int procCnt = faqMnlManageService.insertFaqManage(paramVO);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
    
    /**
     * 수정
     *
     * @param commCodeGroupVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/updateFaqManage.do")
    public NexacroResult updateFaqManage(
            @ParamDataSet(name="dsInput") FaqMnlManageVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setUpdtId(loginInfo.getUserId());

        int procCnt = faqMnlManageService.updateFaqManage(paramVO);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }

    /**
     * 삭제
     *
     * @param commCodeGroupVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/deleteFaqManage.do")
    public NexacroResult deleteFaqManage(
            @ParamDataSet(name="dsInput") FaqMnlManageVO paramVO
            , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUpdtId(loginInfo.getUserId());
        int procCnt = faqMnlManageService.deleteFaqManage(paramVO);
        
        result.addVariable("procCnt", procCnt);
        
        return result;
    }
}
