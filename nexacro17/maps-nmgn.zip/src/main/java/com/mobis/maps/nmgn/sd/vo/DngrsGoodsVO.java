package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DngrsGoodsVO.java
 * @Description : Dangerous Goods (위험물) - UD DOT/ EU BAM
 * @author hong.minho
 * @since 2020. 5. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 11.     hong.minho     	최초 생성
 * </pre>
 */

public class DngrsGoodsVO extends MapsCommSapRfcIfCommVO {

    private String iMatnr; // Part No.

    /**  Sales Org. */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_BUKRS" )
    private String ivBukrs;

    /** Supplier Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_LIFNR" )
    private String ivLifnr;


    // -----[IT_MATNR] START-----
    /** Material Number */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="I", fieldKey="MATNR" )
    private String tvMatnr;
    // -----[IT_MATNR] END-----


    // -----[T_DATA] START-----
    /** Company Code */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** Supplier Cd */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LIFNR" )
    private String lifnr;
    /** Supplier Name */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LITXT" )
    private String litxt;
    /** Material Number */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** File Server ID */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;
    /** DOT NO */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDOT_NO" )
    private String zdotNo;
    /** Register date */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDOT_DATE" )
    private Date zdotDate;
    /** Download */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDOT_DOC" )
    private String zdotDoc;
    /** File ID */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDOT_FILE_SEQNO" )
    private String zdotFileSeqno;
    /** BAM NO */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZBAM_NO" )
    private String zbamNo;
    /** Register date */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZBAM_DATE" )
    private Date zbamDate;
    /** Download */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZBAM_DOC" )
    private String zbamDoc;
    /** File ID */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZBAM_FILE_SEQNO" )
    private String zbamFileSeqno;
    
    
    // -----[T_DATA] END-----
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the ivBukrs
     */
    public String getIvBukrs() {
        return ivBukrs;
    }
    /**
     * @param ivBukrs the ivBukrs to set
     */
    public void setIvBukrs(String ivBukrs) {
        this.ivBukrs = ivBukrs;
    }
    /**
     * @return the ivLifnr
     */
    public String getIvLifnr() {
        return ivLifnr;
    }
    /**
     * @param ivLifnr the ivLifnr to set
     */
    public void setIvLifnr(String ivLifnr) {
        this.ivLifnr = ivLifnr;
    }
    /**
     * @return the tvMatnr
     */
    public String getTvMatnr() {
        return tvMatnr;
    }
    /**
     * @param tvMatnr the tvMatnr to set
     */
    public void setTvMatnr(String tvMatnr) {
        this.tvMatnr = tvMatnr;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the litxt
     */
    public String getLitxt() {
        return litxt;
    }
    /**
     * @param litxt the litxt to set
     */
    public void setLitxt(String litxt) {
        this.litxt = litxt;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the zdotNo
     */
    public String getZdotNo() {
        return zdotNo;
    }
    /**
     * @param zdotNo the zdotNo to set
     */
    public void setZdotNo(String zdotNo) {
        this.zdotNo = zdotNo;
    }
    /**
     * @return the zdotDate
     */
    public Date getZdotDate() {
        return zdotDate;
    }
    /**
     * @param zdotDate the zdotDate to set
     */
    public void setZdotDate(Date zdotDate) {
        this.zdotDate = zdotDate;
    }
    /**
     * @return the zdotDoc
     */
    public String getZdotDoc() {
        return zdotDoc;
    }
    /**
     * @param zdotDoc the zdotDoc to set
     */
    public void setZdotDoc(String zdotDoc) {
        this.zdotDoc = zdotDoc;
    }
    /**
     * @return the zbamNo
     */
    public String getZbamNo() {
        return zbamNo;
    }
    /**
     * @param zbamNo the zbamNo to set
     */
    public void setZbamNo(String zbamNo) {
        this.zbamNo = zbamNo;
    }
    /**
     * @return the zbamDate
     */
    public Date getZbamDate() {
        return zbamDate;
    }
    /**
     * @param zbamDate the zbamDate to set
     */
    public void setZbamDate(Date zbamDate) {
        this.zbamDate = zbamDate;
    }
    /**
     * @return the zbamDoc
     */
    public String getZbamDoc() {
        return zbamDoc;
    }
    /**
     * @param zbamDoc the zbamDoc to set
     */
    public void setZbamDoc(String zbamDoc) {
        this.zbamDoc = zbamDoc;
    }
    /**
     * @return the zdotFileSeqno
     */
    public String getZdotFileSeqno() {
        return zdotFileSeqno;
    }
    /**
     * @param zdotFileSeqno the zdotFileSeqno to set
     */
    public void setZdotFileSeqno(String zdotFileSeqno) {
        this.zdotFileSeqno = zdotFileSeqno;
    }
    /**
     * @return the zbamFileSeqno
     */
    public String getZbamFileSeqno() {
        return zbamFileSeqno;
    }
    /**
     * @param zbamFileSeqno the zbamFileSeqno to set
     */
    public void setZbamFileSeqno(String zbamFileSeqno) {
        this.zbamFileSeqno = zbamFileSeqno;
    }
}
