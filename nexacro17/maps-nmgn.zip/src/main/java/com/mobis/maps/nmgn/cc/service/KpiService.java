package com.mobis.maps.nmgn.cc.service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.vo.KpiInfoOneVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : KpiService.java
 * @Description : Monthly KPI Info
 * @author hong.minho
 * @since 2020. 11. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 11. 24.     hong.minho     	최초 생성
 * </pre>
 */

public interface KpiService {

    /**
     * Monthly KPI Report 조회 
     *
     * @param loginInfo
     * @param paramVO
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    int selectKpiInfo(LoginInfoVO loginInfo, KpiInfoOneVO paramVO) throws MapsBizException, Exception;
    
    
    /**
     * Monthly KPI Report 저장 
     *
     * @param loginInfo
     * @param paramVO
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    int multiKpiInfo(LoginInfoVO loginInfo, KpiInfoOneVO paramVO) throws MapsBizException, Exception;
}
