package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderStatusTotalVO.java
 * @Description : ZPSD_NMGN_R_ORDER_ITEM_LIST
 * @author 홍민호
 * @since 2020. 1. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 7.     홍민호     	최초 생성
 * </pre>
 */

public class OrderStatusTotalVO extends MapsCommSapRfcIfCommVO {

    /*** ES_TOTAL ******************************************************/
    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZORDCNT" )
//    private BigDecimal zordcnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCFMCNT" )
//    private BigDecimal zcfmcnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCANCCNT" )
//    private BigDecimal zcanccnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZBOCNT" )
//    private BigDecimal zbocnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZALOCNT" )
//    private BigDecimal zalocnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICCNT_ON" )
//    private BigDecimal zpiccntOn;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACCNT_ON" )
//    private BigDecimal zpaccntOn;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICCNT" )
//    private BigDecimal zpiccnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACCNT" )
//    private BigDecimal zpaccnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZTRFCNT" )
//    private BigDecimal ztrfcnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZLOADCNT" )
//    private BigDecimal zloadcnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZINVCNT" )
//    private BigDecimal zinvcnt;
//    /**  */
//    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZSHPCNT" )
//    private BigDecimal zshpcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZORDQTY" )
    private String zordqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCFMQTY" )
    private String zcfmqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCANCQTY" )
    private String zcancqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZBOQTY" )
    private String zboqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZALOQTY" )
    private String zaloqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICQTY_ON" )
    private String zpicqtyOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACQTY_ON" )
    private String zpacqtyOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICQTY" )
    private String zpicqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACQTY" )
    private String zpacqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZINVQTY" )
    private String zinvqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZSHPQTY" )
    private String zshpqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZORDAMT" )
    private String zordamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCFMAMT" )
    private String zcfmamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCANCAMT" )
    private String zcancamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZBOAMT" )
    private String zboamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZALOAMT" )
    private String zaloamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICAMT_ON" )
    private String zpicamtOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACAMT_ON" )
    private String zpacamtOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICAMT" )
    private String zpicamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACAMT" )
    private String zpacamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZINVAMT" )
    private String zinvamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZSHPAMT" )
    private String zshpamt;
//    -----[ES_TOTAL] END-----
    /**
     * @return the zordqty
     */
    public String getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(String zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zcfmqty
     */
    public String getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(String zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the zcancqty
     */
    public String getZcancqty() {
        return zcancqty;
    }
    /**
     * @param zcancqty the zcancqty to set
     */
    public void setZcancqty(String zcancqty) {
        this.zcancqty = zcancqty;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zaloqty
     */
    public String getZaloqty() {
        return zaloqty;
    }
    /**
     * @param zaloqty the zaloqty to set
     */
    public void setZaloqty(String zaloqty) {
        this.zaloqty = zaloqty;
    }
    /**
     * @return the zpicqtyOn
     */
    public String getZpicqtyOn() {
        return zpicqtyOn;
    }
    /**
     * @param zpicqtyOn the zpicqtyOn to set
     */
    public void setZpicqtyOn(String zpicqtyOn) {
        this.zpicqtyOn = zpicqtyOn;
    }
    /**
     * @return the zpacqtyOn
     */
    public String getZpacqtyOn() {
        return zpacqtyOn;
    }
    /**
     * @param zpacqtyOn the zpacqtyOn to set
     */
    public void setZpacqtyOn(String zpacqtyOn) {
        this.zpacqtyOn = zpacqtyOn;
    }
    /**
     * @return the zpicqty
     */
    public String getZpicqty() {
        return zpicqty;
    }
    /**
     * @param zpicqty the zpicqty to set
     */
    public void setZpicqty(String zpicqty) {
        this.zpicqty = zpicqty;
    }
    /**
     * @return the zpacqty
     */
    public String getZpacqty() {
        return zpacqty;
    }
    /**
     * @param zpacqty the zpacqty to set
     */
    public void setZpacqty(String zpacqty) {
        this.zpacqty = zpacqty;
    }
    /**
     * @return the zinvqty
     */
    public String getZinvqty() {
        return zinvqty;
    }
    /**
     * @param zinvqty the zinvqty to set
     */
    public void setZinvqty(String zinvqty) {
        this.zinvqty = zinvqty;
    }
    /**
     * @return the zshpqty
     */
    public String getZshpqty() {
        return zshpqty;
    }
    /**
     * @param zshpqty the zshpqty to set
     */
    public void setZshpqty(String zshpqty) {
        this.zshpqty = zshpqty;
    }
    /**
     * @return the zordamt
     */
    public String getZordamt() {
        return zordamt;
    }
    /**
     * @param zordamt the zordamt to set
     */
    public void setZordamt(String zordamt) {
        this.zordamt = zordamt;
    }
    /**
     * @return the zcfmamt
     */
    public String getZcfmamt() {
        return zcfmamt;
    }
    /**
     * @param zcfmamt the zcfmamt to set
     */
    public void setZcfmamt(String zcfmamt) {
        this.zcfmamt = zcfmamt;
    }
    /**
     * @return the zcancamt
     */
    public String getZcancamt() {
        return zcancamt;
    }
    /**
     * @param zcancamt the zcancamt to set
     */
    public void setZcancamt(String zcancamt) {
        this.zcancamt = zcancamt;
    }
    /**
     * @return the zboamt
     */
    public String getZboamt() {
        return zboamt;
    }
    /**
     * @param zboamt the zboamt to set
     */
    public void setZboamt(String zboamt) {
        this.zboamt = zboamt;
    }
    /**
     * @return the zaloamt
     */
    public String getZaloamt() {
        return zaloamt;
    }
    /**
     * @param zaloamt the zaloamt to set
     */
    public void setZaloamt(String zaloamt) {
        this.zaloamt = zaloamt;
    }
    /**
     * @return the zpicamtOn
     */
    public String getZpicamtOn() {
        return zpicamtOn;
    }
    /**
     * @param zpicamtOn the zpicamtOn to set
     */
    public void setZpicamtOn(String zpicamtOn) {
        this.zpicamtOn = zpicamtOn;
    }
    /**
     * @return the zpacamtOn
     */
    public String getZpacamtOn() {
        return zpacamtOn;
    }
    /**
     * @param zpacamtOn the zpacamtOn to set
     */
    public void setZpacamtOn(String zpacamtOn) {
        this.zpacamtOn = zpacamtOn;
    }
    /**
     * @return the zpicamt
     */
    public String getZpicamt() {
        return zpicamt;
    }
    /**
     * @param zpicamt the zpicamt to set
     */
    public void setZpicamt(String zpicamt) {
        this.zpicamt = zpicamt;
    }
    /**
     * @return the zpacamt
     */
    public String getZpacamt() {
        return zpacamt;
    }
    /**
     * @param zpacamt the zpacamt to set
     */
    public void setZpacamt(String zpacamt) {
        this.zpacamt = zpacamt;
    }
    /**
     * @return the zinvamt
     */
    public String getZinvamt() {
        return zinvamt;
    }
    /**
     * @param zinvamt the zinvamt to set
     */
    public void setZinvamt(String zinvamt) {
        this.zinvamt = zinvamt;
    }
    /**
     * @return the zshpamt
     */
    public String getZshpamt() {
        return zshpamt;
    }
    /**
     * @param zshpamt the zshpamt to set
     */
    public void setZshpamt(String zshpamt) {
        this.zshpamt = zshpamt;
    }
    
    
}
