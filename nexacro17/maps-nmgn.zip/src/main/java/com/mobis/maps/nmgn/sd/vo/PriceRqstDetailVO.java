package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PriceRqstDetailVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 2. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 27.     jiyongdo     	최초 생성
 * </pre>
 */

public class PriceRqstDetailVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQNO" )
    private String iReqno;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_SEQNO" )
    private Integer iSeqno;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    //-----[T_RESULT] START-----
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="TYPE" )
    private String type;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="REQNO" )
    private String reqno;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="SEQNO" )
    private Integer seqno;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="LISTNO" )
    private Integer listno;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="COMP_PRICE_LV" )
    private String compPriceLv;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="COMP_MATCH" )
    private String compMatch;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="MAT_TYPE" )
    private String matType;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="COMP_MAKER" )
    private String compMaker;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="COMP_MODEL" )
    private String compModel;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="COMP_CURR" )
    private String compCurr;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="COMP_MSRP" )
    private String compMsrp;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MSGNO" )
    private BigDecimal msgno;
    //-----[T_RESULT] END-----
    /**
     * @return the iReqno
     */
    public String getiReqno() {
        return iReqno;
    }
    /**
     * @param iReqno the iReqno to set
     */
    public void setiReqno(String iReqno) {
        this.iReqno = iReqno;
    }
    /**
     * @return the iSeqno
     */
    public Integer getiSeqno() {
        return iSeqno;
    }
    /**
     * @param iSeqno the iSeqno to set
     */
    public void setiSeqno(Integer iSeqno) {
        this.iSeqno = iSeqno;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the reqno
     */
    public String getReqno() {
        return reqno;
    }
    /**
     * @param reqno the reqno to set
     */
    public void setReqno(String reqno) {
        this.reqno = reqno;
    }
    /**
     * @return the seqno
     */
    public Integer getSeqno() {
        return seqno;
    }
    /**
     * @param seqno the seqno to set
     */
    public void setSeqno(Integer seqno) {
        this.seqno = seqno;
    }
    /**
     * @return the listno
     */
    public Integer getListno() {
        return listno;
    }
    /**
     * @param listno the listno to set
     */
    public void setListno(Integer listno) {
        this.listno = listno;
    }
    /**
     * @return the compPriceLv
     */
    public String getCompPriceLv() {
        return compPriceLv;
    }
    /**
     * @param compPriceLv the compPriceLv to set
     */
    public void setCompPriceLv(String compPriceLv) {
        this.compPriceLv = compPriceLv;
    }
    /**
     * @return the compMatch
     */
    public String getCompMatch() {
        return compMatch;
    }
    /**
     * @param compMatch the compMatch to set
     */
    public void setCompMatch(String compMatch) {
        this.compMatch = compMatch;
    }
    /**
     * @return the matType
     */
    public String getMatType() {
        return matType;
    }
    /**
     * @param matType the matType to set
     */
    public void setMatType(String matType) {
        this.matType = matType;
    }
    /**
     * @return the compMaker
     */
    public String getCompMaker() {
        return compMaker;
    }
    /**
     * @param compMaker the compMaker to set
     */
    public void setCompMaker(String compMaker) {
        this.compMaker = compMaker;
    }
    /**
     * @return the compModel
     */
    public String getCompModel() {
        return compModel;
    }
    /**
     * @param compModel the compModel to set
     */
    public void setCompModel(String compModel) {
        this.compModel = compModel;
    }
    /**
     * @return the compCurr
     */
    public String getCompCurr() {
        return compCurr;
    }
    /**
     * @param compCurr the compCurr to set
     */
    public void setCompCurr(String compCurr) {
        this.compCurr = compCurr;
    }
    /**
     * @return the compMsrp
     */
    public String getCompMsrp() {
        return compMsrp;
    }
    /**
     * @param compMsrp the compMsrp to set
     */
    public void setCompMsrp(String compMsrp) {
        this.compMsrp = compMsrp;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public BigDecimal getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(BigDecimal msgno) {
        this.msgno = msgno;
    }
}
