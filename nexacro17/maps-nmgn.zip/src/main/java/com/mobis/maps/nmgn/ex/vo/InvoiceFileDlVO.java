package com.mobis.maps.nmgn.ex.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AirInvoiceVO.java
 * @Description : ZPEX_MGN_INVOICE_FILE_LIST
 * @author 이수지
 * @since 2020. 07. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 07. 27.       이수지     	       최초 생성
 * </pre>
 */

public class InvoiceFileDlVO extends MapsCommSapRfcIfCommVO {
    
    /** Date */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_FROM_DT" )
    private Date iFromDt;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** Date */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TO_DT" )
    private Date iToDt;
    /** ACCOUNT */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZACTNO" )
    private String iZactno;
    /** Shipmode */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFSHPMD" )
    private String iZfshpmd;

    /** -----[ET_LIST] START----- */
    
    /** 수신일자 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFRECVDT" )
    private Date zfrecvdt;
    /** 파일명 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFFILNM" )
    private String zffilnm;
    /** File Description */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZFDESC" )
    private String zfdesc;
    
    /** -----[ET_LIST] END----- */
    
    
    /**
     * @return the iFromDt
     */
    public Date getiFromDt() {
        return iFromDt;
    }
    /**
     * @param iFromDt the iFromDt to set
     */
    public void setiFromDt(Date iFromDt) {
        this.iFromDt = iFromDt;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iToDt
     */
    public Date getiToDt() {
        return iToDt;
    }
    /**
     * @param iToDt the iToDt to set
     */
    public void setiToDt(Date iToDt) {
        this.iToDt = iToDt;
    }
    /**
     * @return the iZactno
     */
    public String getiZactno() {
        return iZactno;
    }
    /**
     * @param iZactno the iZactno to set
     */
    public void setiZactno(String iZactno) {
        this.iZactno = iZactno;
    }
    /**
     * @return the iZfshpmd
     */
    public String getiZfshpmd() {
        return iZfshpmd;
    }
    /**
     * @param iZfshpmd the iZfshpmd to set
     */
    public void setiZfshpmd(String iZfshpmd) {
        this.iZfshpmd = iZfshpmd;
    }
    /**
     * @return the zfrecvdt
     */
    public Date getZfrecvdt() {
        return zfrecvdt;
    }
    /**
     * @param zfrecvdt the zfrecvdt to set
     */
    public void setZfrecvdt(Date zfrecvdt) {
        this.zfrecvdt = zfrecvdt;
    }
    /**
     * @return the zffilnm
     */
    public String getZffilnm() {
        return zffilnm;
    }
    /**
     * @param zffilnm the zffilnm to set
     */
    public void setZffilnm(String zffilnm) {
        this.zffilnm = zffilnm;
    }
    /**
     * @return the zfdesc
     */
    public String getZfdesc() {
        return zfdesc;
    }
    /**
     * @param zfdesc the zfdesc to set
     */
    public void setZfdesc(String zfdesc) {
        this.zfdesc = zfdesc;
    } 
    
}
