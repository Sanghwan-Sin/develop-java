package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.ListPriceAdjFileDwnVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceAdjFileDwnService.java
 * @Description : ZJSDR20220 List Price Adjustment 파일 Download
 * @author 이수지
 * @since 2020. 1. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 28.       이수지      	        최초 생성
 * </pre>
 */

public interface ListPriceAdjFileDwnService {

    /**
     * List Price Adjustment 파일 Download
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<ListPriceAdjFileDwnVO> selectListPriceAdjFileDwn (LoginInfoVO loginVo, ListPriceAdjFileDwnVO params) throws Exception;
}
