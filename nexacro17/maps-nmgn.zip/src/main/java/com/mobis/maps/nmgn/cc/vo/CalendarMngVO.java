package com.mobis.maps.nmgn.cc.vo;

import java.util.Date;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : NewsLetterVO.java
 * @Description : News Letter
 * @author 이수지
 * @since 2020. 03. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 31.     이수지            	최초 생성
 * </pre>
 */

public class CalendarMngVO extends PgBascVO{
    
    /* 조회조건 */
    /** Sales Org */
    private String salesOrg;
    /** 기준년 */
    private String stdyy;

    /* 조회결과 */
    /** 순번 */
    private String dtSn;
    /** 기준언어 */ 
    private String stdlang;
    /** 기준일 */
    private Date stddt;
    /** 기준일str */
    private String stddtstr;    
    /** 기념일 내용 */
    private String annvrsryDesc;
    /** 기념일 그룹내용 */
    private String groupDesc;
    /** 등록자ID */
    private String registId;
    /** 등록일 */
    private Date registDate;
    /** 수정자ID */
    private String updtId;
    /** 수정일 */
    private Date updtDate;
    
    
    /**
     * @return the salesOrg
     */
    public String getSalesOrg() {
        return salesOrg;
    }
    /**
     * @param salesOrg the salesOrg to set
     */
    public void setSalesOrg(String salesOrg) {
        this.salesOrg = salesOrg;
    }
    /**
     * @return the stdyy
     */
    public String getStdyy() {
        return stdyy;
    }
    /**
     * @param stdyy the stdyy to set
     */
    public void setStdyy(String stdyy) {
        this.stdyy = stdyy;
    }
    /**
     * @return the dtSn
     */
    public String getDtSn() {
        return dtSn;
    }
    /**
     * @param dtSn the dtSn to set
     */
    public void setDtSn(String dtSn) {
        this.dtSn = dtSn;
    }
    /**
     * @return the stdlang
     */
    public String getStdlang() {
        return stdlang;
    }
    /**
     * @param stdlang the stdlang to set
     */
    public void setStdlang(String stdlang) {
        this.stdlang = stdlang;
    }
    /**
     * @return the stddt
     */
    public Date getStddt() {
        return stddt;
    }
    /**
     * @param stddt the stddt to set
     */
    public void setStddt(Date stddt) {
        this.stddt = stddt;
    }
    /**
     * @return the annvrsryDesc
     */
    public String getAnnvrsryDesc() {
        return annvrsryDesc;
    }
    /**
     * @param annvrsryDesc the annvrsryDesc to set
     */
    public void setAnnvrsryDesc(String annvrsryDesc) {
        this.annvrsryDesc = annvrsryDesc;
    }
    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }
    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }
    /**
     * @return the registDate
     */
    public Date getRegistDate() {
        return registDate;
    }
    /**
     * @param registDate the registDate to set
     */
    public void setRegistDate(Date registDate) {
        this.registDate = registDate;
    }
    /**
     * @return the updtId
     */
    public String getUpdtId() {
        return updtId;
    }
    /**
     * @param updtId the updtId to set
     */
    public void setUpdtId(String updtId) {
        this.updtId = updtId;
    }
    /**
     * @return the updtDate
     */
    public Date getUpdtDate() {
        return updtDate;
    }
    /**
     * @param updtDate the updtDate to set
     */
    public void setUpdtDate(Date updtDate) {
        this.updtDate = updtDate;
    }
    /**
     * @return the stddtstr
     */
    public String getStddtstr() {
        return stddtstr;
    }
    /**
     * @param stddtstr the stddtstr to set
     */
    public void setStddtstr(String stddtstr) {
        this.stddtstr = stddtstr;
    }
    /**
     * @return the groupDesc
     */
    public String getGroupDesc() {
        return groupDesc;
    }
    /**
     * @param groupDesc the groupDesc to set
     */
    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc;
    }    
}
