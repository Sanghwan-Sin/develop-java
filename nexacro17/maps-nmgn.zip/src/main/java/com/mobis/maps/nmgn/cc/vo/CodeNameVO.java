package com.mobis.maps.nmgn.cc.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : CodeNameVO.java
 * @Description : CodeNameVO
 * @author ha.jeongryeong
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.    ha.jeongryeong      최초 생성
 *               </pre>
 */

public class CodeNameVO {
    //조회조건
    private String cond1;
    private String cond2;
    private String cond3;
    
    //결과
    private String code;
    private String codeNm;
    /**
     * @return the cond1
     */
    public String getCond1() {
        return cond1;
    }
    /**
     * @param cond1 the cond1 to set
     */
    public void setCond1(String cond1) {
        this.cond1 = cond1;
    }
    /**
     * @return the cond2
     */
    public String getCond2() {
        return cond2;
    }
    /**
     * @param cond2 the cond2 to set
     */
    public void setCond2(String cond2) {
        this.cond2 = cond2;
    }
    /**
     * @return the cond3
     */
    public String getCond3() {
        return cond3;
    }
    /**
     * @param cond3 the cond3 to set
     */
    public void setCond3(String cond3) {
        this.cond3 = cond3;
    }
    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
    /**
     * @return the codeNm
     */
    public String getCodeNm() {
        return codeNm;
    }
    /**
     * @param codeNm the codeNm to set
     */
    public void setCodeNm(String codeNm) {
        this.codeNm = codeNm;
    }
}
