package com.mobis.maps.nmgn.qm.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.SapCodeVO;
import com.mobis.maps.comm.service.MapsCommCodeService;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.nmgn.qm.service.ClaimListService;
import com.mobis.maps.nmgn.qm.vo.ClaimCodeListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimDetailVO;
import com.mobis.maps.nmgn.qm.vo.ClaimInvoiceListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimMarkUpVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimListController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 23.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 23.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class ClaimListController extends HController{

    @Resource(name = "claimListService")
    private ClaimListService claimListService;
    

    @Resource(name = "mapsCommCodeService")
    private MapsCommCodeService mapsCommCodeService;
    
    /**
     * selectClaimList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */        
    @RequestMapping(value = "/qm/selectClaimList.do")
    public NexacroResult selectClaimList(@ParamDataSet(name="dsInput") ClaimListVO paramVO
                                       , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = claimListService.selectClaimList(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        //ClaimListVO totList = (ClaimListVO) retMap.get("head");
        @SuppressWarnings("unchecked")
        List<ClaimListVO> retList = (List<ClaimListVO>)retMap.get("body");
        for(int i = 0; i < retList.size(); i++)
        {
            retList.get(i).setRnum(retList.get(i).getRnum()+1);
        }        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", paramVO);   

        return result;
    }
    
    /**
     * selectClaimListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */        
    @RequestMapping(value = "/qm/selectClaimListExcelDown.do")
    public NexacroResult selectClaimListExcelDown(@ParamDataSet(name="dsInput") ClaimListVO paramVO
                                                , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt()); 
        Map<String, Object> retMap = claimListService.selectClaimList(loginInfo, paramVO);

        @SuppressWarnings("unchecked")
        List<ClaimListVO> retList = (List<ClaimListVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList); 

        return result;
    }    
    
    /**
     * selectClaimDetail
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/qm/selectClaimDetail.do")
    public NexacroResult selectClaimDetail(@ParamDataSet(name="dsInput") ClaimDetailVO paramVO
                                         , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        
        // 1) Attach 필수코드 조회
        MapsCommCodeVO commCodeVO = new MapsCommCodeVO();
        // 코드조회
        //MapsCommCodeVO commCodeVO = new MapsCommCodeVO();
        commCodeVO.setCboSjTy("");
        commCodeVO.setDispTy("KV");
        commCodeVO.setCodeGroup("CD-QM-0094");
        List<SapCodeVO> fileCodes = mapsCommCodeService.selectSapCodeList(commCodeVO, loginInfo);
        result.addDataSet("dsClaimCdForFile", fileCodes);
        
        // 2) Lot 필수코드 조회
        //MapsCommCodeVO commCodeVO = new MapsCommCodeVO();
        commCodeVO.setCodeGroup("CD-QM-0097");
        List<SapCodeVO> lotCodes = mapsCommCodeService.selectSapCodeList(commCodeVO, loginInfo);
        result.addDataSet("dsClaimCdForLot", lotCodes);
        
        
        // 3) Claim Detail 조회
        if (!StringUtils.isBlank(paramVO.getiZclano())) { // Detail 조회
            claimListService.selectClaimDetail(loginInfo, paramVO);
        } else { // 신규
            paramVO.setBody1(new ArrayList<ClaimDetailVO>());
            paramVO.setBody2(new ArrayList<ClaimDetailVO>());
            paramVO.setBody3(new ArrayList<ClaimDetailVO>());
        }
        

        result.addDataSet("dsOutput", paramVO.getBody1()); 
        result.addDataSet("dsOutput2", paramVO.getBody2()); 
        result.addDataSet("dsOutput3", paramVO.getBody3()); 
        result.addDataSet("dsOutput4", paramVO); 
        
        return result;
    }    
    
    /**
     * selectInvoiceNoList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/qm/selectInvoiceNoList.do")
    public NexacroResult selectInvoiceNoList(@ParamDataSet(name="dsInput") ClaimInvoiceListVO paramVO
                                           , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<ClaimInvoiceListVO> retVo = claimListService.selectInvoiceNoList(loginInfo, paramVO);
        
        result.addDataSet("dsOutput", retVo);
        result.addDataSet("dsOutput2", paramVO);

        return result;
    }       
    
    /**
     * selectClaimCodeList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/qm/selectClaimCodeList.do")
    public NexacroResult selectClaimCodeList(@ParamDataSet(name="dsInput") ClaimCodeListVO paramVO
                                           , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<ClaimCodeListVO> retVo = claimListService.selectClaimCodeList(loginInfo, paramVO);
        
        for(int i = 0; i < retVo.size(); i++)
        {
            retVo.get(i).setClcodeName(retVo.get(i).getClcode() + " : " + retVo.get(i).getClcodeName());
        }        
        
        result.addDataSet("dsOutput", retVo);
        result.addDataSet("dsOutput2", paramVO);
       

        return result;
    }     
    
    /**
     * multiClaimDetail
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/qm/multiClaimDetail.do")
    public NexacroResult multiClaimDetail(@ParamDataSet(name="dsInput") ClaimDetailVO paramVO
                                            , @ParamDataSet(name="dsInput2") List<ClaimDetailVO> paramList
                                            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        claimListService.multiClaimDetail(paramVO, paramList, loginInfo);
        
        result.addDataSet("dsOutput", paramVO.getBody1()); 
        result.addDataSet("dsOutput2", paramVO.getBody2()); 
        result.addDataSet("dsOutput3", paramVO.getBody3());         
        result.addDataSet("dsOutput4", paramVO);   

        return result;
    }    
    
    /**
     * selectInvoiceNoList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/qm/selectMarkUpList.do")
    public NexacroResult selectMarkUpList(@ParamDataSet(name="dsInput") ClaimMarkUpVO paramVO
                                           , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        ClaimMarkUpVO retVo = claimListService.selectMarkUpList(loginInfo, paramVO);
        
        result.addDataSet("dsOutput", retVo);

        return result;
    }          
}
