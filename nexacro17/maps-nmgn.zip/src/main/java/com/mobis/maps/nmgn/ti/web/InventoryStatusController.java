package com.mobis.maps.nmgn.ti.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.service.InventoryStatusService;
import com.mobis.maps.nmgn.ti.vo.InventoryStatusVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InventoryStatusController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 7. 15.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 15.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class InventoryStatusController extends HController{
    
    @Resource(name = "inventoryStatusService")
    private InventoryStatusService inventoryStatusService;
    
    /**
     * selectInventoryStatusList
     *
     * @param params, paramList
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectInventoryStatusList.do")
    public NexacroResult selectInventoryStatusList(@ParamDataSet(name="dsInput") InventoryStatusVO params
                                                 , @ParamDataSet(name="dsInput2") List<InventoryStatusVO> paramList
                                                 , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<InventoryStatusVO> list = inventoryStatusService.selectInventoryStatusList(loginInfo, params, paramList);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }      
    
    /**
     * selectInventoryStatusListExcelDown
     *
     * @param params, paramList
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ti/selectInventoryStatusListExcelDown.do")
    public NexacroResult selectInventoryStatusListExcelDown(@ParamDataSet(name="dsInput") InventoryStatusVO params
                                                          , @ParamDataSet(name="dsInput2") List<InventoryStatusVO> paramList
                                                          , NexacroResult result) throws Exception {
         
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);        
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());        
        
        List<InventoryStatusVO> list = inventoryStatusService.selectInventoryStatusList(loginInfo, params, paramList);

        result.addDataSet("dsOutput", list);

        return result;
    }     
    
    /**
     * selectInventoryStatusListExcelUp
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */     
    @RequestMapping(value = "/ti/selectInventoryStatusListExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectInventoryStatusListExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        List<InventoryStatusVO> lstUpload = new ArrayList<InventoryStatusVO>();
        List<String[]> rowList = ExcelUtil.importExcelToList(request, 1, 2, 0, "N");
        
        if (rowList != null && !rowList.isEmpty()) {

            for (String[] arrCol : rowList) {

                InventoryStatusVO uploadVo = new InventoryStatusVO();
                
                uploadVo.setMatnr(arrCol[0]);
                lstUpload.add(uploadVo);
            }
        }

        result.addDataSet("dsOutput", lstUpload);

        return result;
    }     
}
