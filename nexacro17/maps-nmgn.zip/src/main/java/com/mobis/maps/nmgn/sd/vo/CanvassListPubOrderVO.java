package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CanvassListPubOrderVO.java
 * @Description : ZPSD_NMGN_R_ORDER_PUBLICATION
 * @author 이수지
 * @since 2020. 2. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 20.      이수지     	       최초 생성
 * </pre>
 */

public class CanvassListPubOrderVO extends MapsCommSapRfcIfCommVO {
    
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** Canvass No */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCANVNO" )
    private String iZcanvno;
    /** Order Due. Date */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDUEDT" )
    private Date iZduedt;

    
    /** -----[IT_RESULT] START----- */
    
    /** Line Number */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZCANVLN" )
    private BigDecimal zcanvln;
    /** Material Number */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    private String qty;
    private String remark;
    
    /** -----[IT_RESULT] END----- */
    
    
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZcanvno
     */
    public String getiZcanvno() {
        return iZcanvno;
    }
    /**
     * @param iZcanvno the iZcanvno to set
     */
    public void setiZcanvno(String iZcanvno) {
        this.iZcanvno = iZcanvno;
    }
    /**
     * @return the iZduedt
     */
    public Date getiZduedt() {
        return iZduedt;
    }
    /**
     * @param iZduedt the iZduedt to set
     */
    public void setiZduedt(Date iZduedt) {
        this.iZduedt = iZduedt;
    }
    /**
     * @return the zcanvln
     */
    public BigDecimal getZcanvln() {
        return zcanvln;
    }
    /**
     * @param zcanvln the zcanvln to set
     */
    public void setZcanvln(BigDecimal zcanvln) {
        this.zcanvln = zcanvln;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the qty
     */
    public String getQty() {
        return qty;
    }
    /**
     * @param qty the qty to set
     */
    public void setQty(String qty) {
        this.qty = qty;
    }
    /**
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }
    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }
}
