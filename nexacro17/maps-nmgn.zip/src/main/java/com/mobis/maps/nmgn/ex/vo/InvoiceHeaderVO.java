package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceHeaderVO.java
 * @Description : Invoice List, Header, Detail
 * @author jiyongdo
 * @since 2020. 2. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 14.     jiyongdo     	최초 생성
 * </pre>
 */

public class InvoiceHeaderVO extends MapsCommSapRfcIfCommVO{
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /** 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;    
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_BRGEW" )
    private BigDecimal eBrgew;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_CONT_20FT" )
    private Integer eCont20ft;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_CONT_40FT" )
    private Integer eCont40ft;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_CONT_HC" )
    private Integer eContHc;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ITEMS" )
    private Integer eItems;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_NO_OF_CASE" )
    private Integer eNoOfCase;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_NTGEW" )
    private BigDecimal eNtgew;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFCIFAMT" )
    private BigDecimal eZfcifamt;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFFOBAMT" )
    private BigDecimal eZffobamt;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFHBLNO" )
    private String eZfhblno;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFINSAMT" )
    private BigDecimal eZfinsamt;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFLFIMGSUM" )
    private BigDecimal eZflfimgsum;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFOBDT" )
    private Date eZfobdt;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFSHCP" )
    private String eZfshcp;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFTRSAMT" )
    private BigDecimal eZftrsamt;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZFVYNO" )
    private String eZfvyno;
    /** 중량 단위 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_GEWEI" )
    private String eGewei;
    /** SD 문서 통화 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_WAERK" )
    private String eWaerk;    
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ORDER" )
    private String order;
    private String order1;
    private String order2;
    private String order3;
    private String order4;
    private String order5;
    private String order6;
    private String order7;
    private String order8;
    private String order9;
    private String order10;
    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }
    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the eBrgew
     */
    public BigDecimal geteBrgew() {
        return eBrgew;
    }
    /**
     * @param eBrgew the eBrgew to set
     */
    public void seteBrgew(BigDecimal eBrgew) {
        this.eBrgew = eBrgew;
    }
    /**
     * @return the eCont20ft
     */
    public Integer geteCont20ft() {
        return eCont20ft;
    }
    /**
     * @param eCont20ft the eCont20ft to set
     */
    public void seteCont20ft(Integer eCont20ft) {
        this.eCont20ft = eCont20ft;
    }
    /**
     * @return the eCont40ft
     */
    public Integer geteCont40ft() {
        return eCont40ft;
    }
    /**
     * @param eCont40ft the eCont40ft to set
     */
    public void seteCont40ft(Integer eCont40ft) {
        this.eCont40ft = eCont40ft;
    }
    /**
     * @return the eContHc
     */
    public Integer geteContHc() {
        return eContHc;
    }
    /**
     * @param eContHc the eContHc to set
     */
    public void seteContHc(Integer eContHc) {
        this.eContHc = eContHc;
    }
    /**
     * @return the eItems
     */
    public Integer geteItems() {
        return eItems;
    }
    /**
     * @param eItems the eItems to set
     */
    public void seteItems(Integer eItems) {
        this.eItems = eItems;
    }
    /**
     * @return the eNoOfCase
     */
    public Integer geteNoOfCase() {
        return eNoOfCase;
    }
    /**
     * @param eNoOfCase the eNoOfCase to set
     */
    public void seteNoOfCase(Integer eNoOfCase) {
        this.eNoOfCase = eNoOfCase;
    }
    /**
     * @return the eNtgew
     */
    public BigDecimal geteNtgew() {
        return eNtgew;
    }
    /**
     * @param eNtgew the eNtgew to set
     */
    public void seteNtgew(BigDecimal eNtgew) {
        this.eNtgew = eNtgew;
    }
    /**
     * @return the eZfcifamt
     */
    public BigDecimal geteZfcifamt() {
        return eZfcifamt;
    }
    /**
     * @param eZfcifamt the eZfcifamt to set
     */
    public void seteZfcifamt(BigDecimal eZfcifamt) {
        this.eZfcifamt = eZfcifamt;
    }
    /**
     * @return the eZffobamt
     */
    public BigDecimal geteZffobamt() {
        return eZffobamt;
    }
    /**
     * @param eZffobamt the eZffobamt to set
     */
    public void seteZffobamt(BigDecimal eZffobamt) {
        this.eZffobamt = eZffobamt;
    }
    /**
     * @return the eZfhblno
     */
    public String geteZfhblno() {
        return eZfhblno;
    }
    /**
     * @param eZfhblno the eZfhblno to set
     */
    public void seteZfhblno(String eZfhblno) {
        this.eZfhblno = eZfhblno;
    }
    /**
     * @return the eZfinsamt
     */
    public BigDecimal geteZfinsamt() {
        return eZfinsamt;
    }
    /**
     * @param eZfinsamt the eZfinsamt to set
     */
    public void seteZfinsamt(BigDecimal eZfinsamt) {
        this.eZfinsamt = eZfinsamt;
    }
    /**
     * @return the eZflfimgsum
     */
    public BigDecimal geteZflfimgsum() {
        return eZflfimgsum;
    }
    /**
     * @param eZflfimgsum the eZflfimgsum to set
     */
    public void seteZflfimgsum(BigDecimal eZflfimgsum) {
        this.eZflfimgsum = eZflfimgsum;
    }
    /**
     * @return the eZfobdt
     */
    public Date geteZfobdt() {
        return eZfobdt;
    }
    /**
     * @param eZfobdt the eZfobdt to set
     */
    public void seteZfobdt(Date eZfobdt) {
        this.eZfobdt = eZfobdt;
    }
    /**
     * @return the eZfshcp
     */
    public String geteZfshcp() {
        return eZfshcp;
    }
    /**
     * @param eZfshcp the eZfshcp to set
     */
    public void seteZfshcp(String eZfshcp) {
        this.eZfshcp = eZfshcp;
    }
    /**
     * @return the eZftrsamt
     */
    public BigDecimal geteZftrsamt() {
        return eZftrsamt;
    }
    /**
     * @param eZftrsamt the eZftrsamt to set
     */
    public void seteZftrsamt(BigDecimal eZftrsamt) {
        this.eZftrsamt = eZftrsamt;
    }
    /**
     * @return the eZfvyno
     */
    public String geteZfvyno() {
        return eZfvyno;
    }
    /**
     * @param eZfvyno the eZfvyno to set
     */
    public void seteZfvyno(String eZfvyno) {
        this.eZfvyno = eZfvyno;
    }
    /**
     * @return the eGewei
     */
    public String geteGewei() {
        return eGewei;
    }
    /**
     * @param eGewei the eGewei to set
     */
    public void seteGewei(String eGewei) {
        this.eGewei = eGewei;
    }
    /**
     * @return the eWaerk
     */
    public String geteWaerk() {
        return eWaerk;
    }
    /**
     * @param eWaerk the eWaerk to set
     */
    public void seteWaerk(String eWaerk) {
        this.eWaerk = eWaerk;
    }
    /**
     * @return the order
     */
    public String getOrder() {
        return order;
    }
    /**
     * @param order the order to set
     */
    public void setOrder(String order) {
        this.order = order;
    }
    /**
     * @return the order1
     */
    public String getOrder1() {
        return order1;
    }
    /**
     * @param order1 the order1 to set
     */
    public void setOrder1(String order1) {
        this.order1 = order1;
    }
    /**
     * @return the order2
     */
    public String getOrder2() {
        return order2;
    }
    /**
     * @param order2 the order2 to set
     */
    public void setOrder2(String order2) {
        this.order2 = order2;
    }
    /**
     * @return the order3
     */
    public String getOrder3() {
        return order3;
    }
    /**
     * @param order3 the order3 to set
     */
    public void setOrder3(String order3) {
        this.order3 = order3;
    }
    /**
     * @return the order4
     */
    public String getOrder4() {
        return order4;
    }
    /**
     * @param order4 the order4 to set
     */
    public void setOrder4(String order4) {
        this.order4 = order4;
    }
    /**
     * @return the order5
     */
    public String getOrder5() {
        return order5;
    }
    /**
     * @param order5 the order5 to set
     */
    public void setOrder5(String order5) {
        this.order5 = order5;
    }
    /**
     * @return the order6
     */
    public String getOrder6() {
        return order6;
    }
    /**
     * @param order6 the order6 to set
     */
    public void setOrder6(String order6) {
        this.order6 = order6;
    }
    /**
     * @return the order7
     */
    public String getOrder7() {
        return order7;
    }
    /**
     * @param order7 the order7 to set
     */
    public void setOrder7(String order7) {
        this.order7 = order7;
    }
    /**
     * @return the order8
     */
    public String getOrder8() {
        return order8;
    }
    /**
     * @param order8 the order8 to set
     */
    public void setOrder8(String order8) {
        this.order8 = order8;
    }
    /**
     * @return the order9
     */
    public String getOrder9() {
        return order9;
    }
    /**
     * @param order9 the order9 to set
     */
    public void setOrder9(String order9) {
        this.order9 = order9;
    }
    /**
     * @return the order10
     */
    public String getOrder10() {
        return order10;
    }
    /**
     * @param order10 the order10 to set
     */
    public void setOrder10(String order10) {
        this.order10 = order10;
    }
}
