package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ExchangePurchaseDetailVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 2. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 20.     jiyongdo     	최초 생성
 * </pre>
 */

public class ExchangePurchaseDetailVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDOCNUM" )
    private String iZdocnum;
    //-----[CS_HEADER] START-----
    /**  */ 
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZDOCNUM" )
    private String zdocnum;                        
    /**  */                                        
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZPSTYPE" )
    private String zpstype;                          
    /**  */                                          
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZWRDATE" )
    private Date zwrdate;                            
    /**  */                                          
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZSUBJECT" )
    private String zsubject;                         
    /** Country Key */                               
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="LAND1" )
    private String land1;                            
    /** Country Name */                              
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="LAND1_NAME" )
    private String land1Name;                        
    /**  */                                          
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZSACUTM_DIST" )
    private String zsacutmDist;                      
    /** Name */                                      
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZSACUTM_DIST_NM" )
    private String zsacutmDistNm;                    
    /** Customer Number */                           
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZDIST" )
    private String zdist;                            
    /**  */                                          
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZREADCNT" )
    private BigDecimal zreadcnt;                     
    /**  */                                          
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZCONTENT" )
    private String zcontent;                         
    /**  */                                          
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="ZWRITER" )
    private String zwriter;                          
    /** Currency */                                  
    @MapsRfcMappper( targetName="CS_HEADER", ipttSe="I|E", fieldKey="WAERS" )   
    private String waers;
    //-----[CS_HEADER] END-----

    //-----[T_ITEM] START-----
    /**  */    
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="I|E", fieldKey="ZLINENO" )
    private String zlineno;                    
    /**  */                                        
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="I|E", fieldKey="ZHKCD" )
    private String zhkcd;                          
    /** Material Number */                         
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="I|E", fieldKey="MATNR" )
    private String matnr;                          
    /** Material description */                    
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="I|E", fieldKey="MATNR_NM" )
    private String matnrNm;                        
    /**  */                                        
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="I|E", fieldKey="ZORDQTY" )
    private BigDecimal zordqty;                    
    /**  */                                        
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="I|E", fieldKey="ZPRICE" )
    private BigDecimal zprice;                     
    /**  */                                        
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="I|E", fieldKey="ZREMARK" )
    private String zremark;                        
    /** Single-Character Flag */                   
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="I|E", fieldKey="ZCRUD" )
    private String zcrud;
    private String flag;
    /** 메세지 결과: S 성공, E 오류 */
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="E", fieldKey="MTYPE" )
    private String msgType;
    /** 메시지 텍스트 */
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="E", fieldKey="MESSAGE" )
    private String msg;
    /** Message Class */
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** 메시지 번호 */
    @MapsRfcMappper( targetName="T_ITEM", ipttSe="E", fieldKey="MSGNO" )
    private BigDecimal msgno; 
    private String highDistCd; 
    
    //-----[T_ITEM] END-----
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZdocnum
     */
    public String getiZdocnum() {
        return iZdocnum;
    }
    /**
     * @param iZdocnum the iZdocnum to set
     */
    public void setiZdocnum(String iZdocnum) {
        this.iZdocnum = iZdocnum;
    }
    /**
     * @return the zdocnum
     */
    public String getZdocnum() {
        return zdocnum;
    }
    /**
     * @param zdocnum the zdocnum to set
     */
    public void setZdocnum(String zdocnum) {
        this.zdocnum = zdocnum;
    }
    /**
     * @return the zpstype
     */
    public String getZpstype() {
        return zpstype;
    }
    /**
     * @param zpstype the zpstype to set
     */
    public void setZpstype(String zpstype) {
        this.zpstype = zpstype;
    }
    /**
     * @return the zwrdate
     */
    public Date getZwrdate() {
        return zwrdate;
    }
    /**
     * @param zwrdate the zwrdate to set
     */
    public void setZwrdate(Date zwrdate) {
        this.zwrdate = zwrdate;
    }
    /**
     * @return the zsubject
     */
    public String getZsubject() {
        return zsubject;
    }
    /**
     * @param zsubject the zsubject to set
     */
    public void setZsubject(String zsubject) {
        this.zsubject = zsubject;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the land1Name
     */
    public String getLand1Name() {
        return land1Name;
    }
    /**
     * @param land1Name the land1Name to set
     */
    public void setLand1Name(String land1Name) {
        this.land1Name = land1Name;
    }
    /**
     * @return the zsacutmDist
     */
    public String getZsacutmDist() {
        return zsacutmDist;
    }
    /**
     * @param zsacutmDist the zsacutmDist to set
     */
    public void setZsacutmDist(String zsacutmDist) {
        this.zsacutmDist = zsacutmDist;
    }
    /**
     * @return the zsacutmDistNm
     */
    public String getZsacutmDistNm() {
        return zsacutmDistNm;
    }
    /**
     * @param zsacutmDistNm the zsacutmDistNm to set
     */
    public void setZsacutmDistNm(String zsacutmDistNm) {
        this.zsacutmDistNm = zsacutmDistNm;
    }
    /**
     * @return the zdist
     */
    public String getZdist() {
        return zdist;
    }
    /**
     * @param zdist the zdist to set
     */
    public void setZdist(String zdist) {
        this.zdist = zdist;
    }
    /**
     * @return the zreadcnt
     */
    public BigDecimal getZreadcnt() {
        return zreadcnt;
    }
    /**
     * @param zreadcnt the zreadcnt to set
     */
    public void setZreadcnt(BigDecimal zreadcnt) {
        this.zreadcnt = zreadcnt;
    }
    /**
     * @return the zcontent
     */
    public String getZcontent() {
        return zcontent;
    }
    /**
     * @param zcontent the zcontent to set
     */
    public void setZcontent(String zcontent) {
        this.zcontent = zcontent;
    }
    /**
     * @return the zwriter
     */
    public String getZwriter() {
        return zwriter;
    }
    /**
     * @param zwriter the zwriter to set
     */
    public void setZwriter(String zwriter) {
        this.zwriter = zwriter;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the zlineno
     */
    public String getZlineno() {
        return zlineno;
    }
    /**
     * @param zlineno the zlineno to set
     */
    public void setZlineno(String zlineno) {
        this.zlineno = zlineno;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the matnrNm
     */
    public String getMatnrNm() {
        return matnrNm;
    }
    /**
     * @param matnrNm the matnrNm to set
     */
    public void setMatnrNm(String matnrNm) {
        this.matnrNm = matnrNm;
    }
    /**
     * @return the zordqty
     */
    public BigDecimal getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(BigDecimal zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zprice
     */
    public BigDecimal getZprice() {
        return zprice;
    }
    /**
     * @param zprice the zprice to set
     */
    public void setZprice(BigDecimal zprice) {
        this.zprice = zprice;
    }
    /**
     * @return the zremark
     */
    public String getZremark() {
        return zremark;
    }
    /**
     * @param zremark the zremark to set
     */
    public void setZremark(String zremark) {
        this.zremark = zremark;
    }
    /**
     * @return the zcrud
     */
    public String getZcrud() {
        return zcrud;
    }
    /**
     * @param zcrud the zcrud to set
     */
    public void setZcrud(String zcrud) {
        this.zcrud = zcrud;
    }
    /**
     * @return the flag
     */
    public String getFlag() {
        return flag;
    }
    /**
     * @param flag the flag to set
     */
    public void setFlag(String flag) {
        this.flag = flag;
    }
    /**
     * @return the msgType
     */
    public String getMsgType() {
        return msgType;
    }
    /**
     * @param msgType the msgType to set
     */
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }
    /**
     * @return the msg
     */
    public String getMsg() {
        return msg;
    }
    /**
     * @param msg the msg to set
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public BigDecimal getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(BigDecimal msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the highDistCd
     */
    public String getHighDistCd() {
        return highDistCd;
    }
    /**
     * @param highDistCd the highDistCd to set
     */
    public void setHighDistCd(String highDistCd) {
        this.highDistCd = highDistCd;
    }
}
