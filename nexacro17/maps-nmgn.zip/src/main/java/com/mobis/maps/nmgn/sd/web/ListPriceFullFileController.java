package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.ListPriceFullFileService;
import com.mobis.maps.nmgn.sd.vo.ListPriceFullFileVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceFullFileController.java
 * @Description : ZJSDR20210 List Price Full 파일 생성 요청 및 Download
 * @author 이수지
 * @since 2020. 2. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 12.       이수지                최초 생성
 * </pre>
 */

@Controller
public class ListPriceFullFileController extends HController {

    @Resource(name = "listPriceFullFileService")
    private ListPriceFullFileService listPriceFullFileService;

    /**
     * selectListPriceFullFile
     *
     * @param params
     * @param results
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectListPriceFullFile.do")
    public NexacroResult selectListPriceFullFile(@ParamDataSet(name="dsInput") ListPriceFullFileVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ListPriceFullFileVO> list = listPriceFullFileService.selectListPriceFullFile(loginInfo, params);
        for (int i = 0; i < list.size(); i++)
        {
            list.get(i).setRnum(list.get(i).getRnum() + 1);
        }
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectListPriceFullFileExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectListPriceFullFileExcelDown.do")
    public NexacroResult selectListPriceFullFileExcelDown(@ParamDataSet(name="dsInput") ListPriceFullFileVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<ListPriceFullFileVO> list = listPriceFullFileService.selectListPriceFullFile(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectCustomerInfo
     *
     * @param params
     * @param results
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectCustomerInfo.do")
    public NexacroResult selectCustomerInfo(@ParamDataSet(name="dsInput") ListPriceFullFileVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ListPriceFullFileVO> list = listPriceFullFileService.selectCustomerInfo(loginInfo, params);

        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * multiListPriceFullFile
     *
     * @param params
     * @param results
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/multiListPriceFullFile.do")
    public NexacroResult multiListPriceFullFile(@ParamDataSet(name="dsInput") ListPriceFullFileVO params
                                            , @ParamDataSet(name="dsInput2") List<ListPriceFullFileVO> paramList
                                            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = listPriceFullFileService.multiListPriceFullFile(loginInfo, params, paramList);
        
        @SuppressWarnings("unchecked")
        List<ListPriceFullFileVO> list = (List<ListPriceFullFileVO>)retMap.get("body");
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);

        return result;
    }
}
