package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderMatnrValidateMultiVO.java
 * @Description : 부품체크
 *                ZPSD_NMGN_R_MATERIAL_VALIDATE2
 * @author hong.minho
 * @since 2020. 8. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 14.     hong.minho     	최초 생성
 * </pre>
 */

public class OrderMatnrValidateMultiVO extends MapsCommSapRfcIfCommVO {
    
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_WERKS" )
    private String iWerks;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** 오더유형 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDTYP" )
    private String iZordtyp;
    /** Dist.Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    
    
    //-----[IT_MATNR] START-----
    /** Material Number */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="I|E", fieldKey="MATNR|MATNR" )
    private String matnr;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="MEINS" )
    private String meins;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZPTNM_NTV" )
    private String zptnmNtv;
    /** HQ SUC */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSUCCD" )
    private String zsuccd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSUCCD_NM" )
    private String zsuccdNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZQUP" )
    private String zqup;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZQOP" )
    private String zqop;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZQFP" )
    private String zqfp;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    //-----[IT_MATNR] END-----
    
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the iWerks
     */
    public String getiWerks() {
        return iWerks;
    }
    /**
     * @param iWerks the iWerks to set
     */
    public void setiWerks(String iWerks) {
        this.iWerks = iWerks;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the meins
     */
    public String getMeins() {
        return meins;
    }
    /**
     * @param meins the meins to set
     */
    public void setMeins(String meins) {
        this.meins = meins;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the zptnmNtv
     */
    public String getZptnmNtv() {
        return zptnmNtv;
    }
    /**
     * @param zptnmNtv the zptnmNtv to set
     */
    public void setZptnmNtv(String zptnmNtv) {
        this.zptnmNtv = zptnmNtv;
    }
    /**
     * @return the zsuccd
     */
    public String getZsuccd() {
        return zsuccd;
    }
    /**
     * @param zsuccd the zsuccd to set
     */
    public void setZsuccd(String zsuccd) {
        this.zsuccd = zsuccd;
    }
    /**
     * @return the zsuccdNm
     */
    public String getZsuccdNm() {
        return zsuccdNm;
    }
    /**
     * @param zsuccdNm the zsuccdNm to set
     */
    public void setZsuccdNm(String zsuccdNm) {
        this.zsuccdNm = zsuccdNm;
    }
    /**
     * @return the zqup
     */
    public String getZqup() {
        return zqup;
    }
    /**
     * @param zqup the zqup to set
     */
    public void setZqup(String zqup) {
        this.zqup = zqup;
    }
    /**
     * @return the zqop
     */
    public String getZqop() {
        return zqop;
    }
    /**
     * @param zqop the zqop to set
     */
    public void setZqop(String zqop) {
        this.zqop = zqop;
    }
    /**
     * @return the zqfp
     */
    public String getZqfp() {
        return zqfp;
    }
    /**
     * @param zqfp the zqfp to set
     */
    public void setZqfp(String zqfp) {
        this.zqfp = zqfp;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the iZordtyp
     */
    public String getiZordtyp() {
        return iZordtyp;
    }
    /**
     * @param iZordtyp the iZordtyp to set
     */
    public void setiZordtyp(String iZordtyp) {
        this.iZordtyp = iZordtyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
}
