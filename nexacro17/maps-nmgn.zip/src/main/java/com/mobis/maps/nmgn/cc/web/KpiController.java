package com.mobis.maps.nmgn.cc.web;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.KpiService;
import com.mobis.maps.nmgn.cc.vo.KpiInfoOneVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : KpiController.java
 * @Description : Monthly KPI Info
 * @author hong.minho
 * @since 2020. 11. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 11. 24.     hong.minho     	최초 생성
 * </pre>
 */

@Controller
public class KpiController extends HController {
    
    @Resource(name="kpiService")
    KpiService service;
    
    /**
     * Monthly KPI Report 조회 
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectKpiInfo.do")
    public NexacroResult selectKpiInfo(@ParamDataSet(name="dsInput") KpiInfoOneVO paramVO
            , NexacroResult result) throws Exception {
        KpiInfoOneVO prevYearVo = new KpiInfoOneVO();

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int nRslt = service.selectKpiInfo(loginInfo, paramVO);
        if (logger.isDebugEnabled()) {logger.debug("### Result:" + nRslt);}
        
        // 전년도 조회
        int nYear = toInt(paramVO.getStdYear());
        if (nYear > 1001) {
            nYear --;
            
            BeanUtils.copyProperties(prevYearVo, paramVO);
            prevYearVo.setStdYear(String.valueOf(nYear));
            
            nRslt = service.selectKpiInfo(loginInfo, prevYearVo);
            if (logger.isDebugEnabled()) {logger.debug("### Prev. Year retrieve result:" + nRslt);}
        }

        result.addDataSet("dsOutput", paramVO);
        result.addDataSet("dsOutPrevYear", prevYearVo);
        
        result.addDataSet("dsReturn", paramVO);

        return result;
   }
    

    /**
     * Excel Download
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectKpiInfoExcelDown.do")
    public NexacroResult selectKpiInfoExcelDown(@ParamDataSet(name="dsInput") KpiInfoOneVO paramVO
            , NexacroResult result) throws Exception {

        return selectKpiInfo(paramVO, result);
   }



    /**
     * Monthly KPI Report 저장 
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/multiKpiInfo.do")
    public NexacroResult multiKpiInfo(@ParamDataSet(name="dsInput") KpiInfoOneVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        int nRslt = service.multiKpiInfo(loginInfo, paramVO);
        if (logger.isDebugEnabled()) {logger.debug("### Result:" + nRslt);}

        result.addDataSet("dsOutput", paramVO);
        result.addDataSet("dsReturn", paramVO);

        return result;
    }

    
    /**
     * String 2 int
     *
     * @param sYear
     * @return
     */
    private int toInt(String sYear) {
        int nYear = -1;
        if (StringUtils.isBlank(sYear)) return nYear;
        
        try {
            nYear = Integer.parseInt(sYear);
        } catch (Exception e1) {
            if (logger.isDebugEnabled()) {logger.debug("Integer.parseInt ERROR:" + e1.getMessage());}
            nYear = -1;
        }
        
        return nYear;
    }

}
