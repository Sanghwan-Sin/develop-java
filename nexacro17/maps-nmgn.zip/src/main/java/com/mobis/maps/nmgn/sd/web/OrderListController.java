package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.OrderListService;
import com.mobis.maps.nmgn.sd.vo.OrderListVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderListController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2019. 12. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 16.     jiyongdo     	최초 생성
 * </pre>
 */
@Controller
public class OrderListController extends HController{
    
    @Resource(name = "orderListService")
    private OrderListService orderListService;

    @RequestMapping(value = "/sd/selectOrderList.do")
    public NexacroResult selectOrderList(@ParamDataSet(name="dsInput") OrderListVO paramVO
                                       , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<OrderListVO> rtnLst = orderListService.selectOrderList(loginInfo, paramVO);

        for(int i = 0; i < rtnLst.size(); i++)
        {
            rtnLst.get(i).setRnum(rtnLst.get(i).getRnum()+1);
        }
        
        result.addDataSet("dsOutput", rtnLst);
        result.addDataSet("dsOutput2", paramVO);

        return result;
    }
    
    @RequestMapping(value = "/sd/selectOrderListExcelDown.do")
    public NexacroResult selectOrderListExcelDown(@ParamDataSet(name="dsInput") OrderListVO paramVO
                                                , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        List<OrderListVO> rtnLst = orderListService.selectOrderList(loginInfo, paramVO);

        for(int i = 0; i < rtnLst.size(); i++)
        {
            rtnLst.get(i).setRnum(rtnLst.get(i).getRnum()+1);
        }
        
        result.addDataSet("dsOutput", rtnLst);

        return result;
    }    
}
