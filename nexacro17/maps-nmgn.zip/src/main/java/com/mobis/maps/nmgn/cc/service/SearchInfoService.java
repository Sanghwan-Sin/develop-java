package com.mobis.maps.nmgn.cc.service;

import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.vo.SearchInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SearchInfoService.java
 * @Description : 구매 공통 팝업 조회
 * @author DT060152
 * @since 2020. 01. 29.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 01. 29.     DT060152      최초 생성
 * </pre>
 */

public interface SearchInfoService {

    /**
     * 플렌트/사급업체/제품업체/국가코드 조회
     *
     * @param loginVo
     * @param paramVo
     * @return
     * @throws Exception
     */
    public Map<String, Object> selectSearchInfoList(LoginInfoVO loginVo, SearchInfoVO paramVo) throws Exception;
}