package com.mobis.maps.nmgn.cc.vo;

import java.util.Date;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplBoardVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplBoardVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 28.     Jiyongdo     	최초 생성
 * </pre>
 */
public class MapsNoticeVO extends PgBascVO{
    /* 조회조건 */
    /** Interface ID */
    private String ifCode;
    /** 회사 코드 */
    private String bukRs;
    /** Source System */
    private String srfcId;
    /** Target System */
    private String trfcId;
    private String strDate;
    private String endDate;    
    
    /** 게시글ID */
    private String bbscttId;
    /** 게시글일련 */
    private int bbscttSeq;
    /** 카테고리코드 */
    private String categoryCd;
    /** 게시시작일 */
    private Date popupBgnde;
    /** 게시종료일 */
    private Date popupEndde;
    /** 게시여부 */
    private String emrgncyYn;
    /** 게시글제목 */
    private String bbscttSj;
    /** 게시글내용 */
    private String bbscttCn;
    /** 조회수 */
    private int rdCnt;
    /** 삭제여부 */
    private String delYn;
    
    private String saveType   ; //저장타입
    
    private String atchSe;
    private String atchId;
    private String salesOrg;
    private String popYn;

    /**
     * @return the ifCode
     */
    public String getIfCode() {
        return ifCode;
    }

    /**
     * @param ifCode the ifCode to set
     */
    public void setIfCode(String ifCode) {
        this.ifCode = ifCode;
    }

    /**
     * @return the bukRs
     */
    public String getBukRs() {
        return bukRs;
    }

    /**
     * @param bukRs the bukRs to set
     */
    public void setBukRs(String bukRs) {
        this.bukRs = bukRs;
    }

    /**
     * @return the srfcId
     */
    public String getSrfcId() {
        return srfcId;
    }

    /**
     * @param srfcId the srfcId to set
     */
    public void setSrfcId(String srfcId) {
        this.srfcId = srfcId;
    }

    /**
     * @return the trfcId
     */
    public String getTrfcId() {
        return trfcId;
    }

    /**
     * @return the strDate
     */
    public String getStrDate() {
        return strDate;
    }

    /**
     * @param strDate the strDate to set
     */
    public void setStrDate(String strDate) {
        this.strDate = strDate;
    }

    /**
     * @return the endDate
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * @param trfcId the trfcId to set
     */
    public void setTrfcId(String trfcId) {
        this.trfcId = trfcId;
    }
   

    /**
     * @return the bbscttId
     */
    public String getBbscttId() {
        return bbscttId;
    }

    /**
     * @param bbscttId the bbscttId to set
     */
    public void setBbscttId(String bbscttId) {
        this.bbscttId = bbscttId;
    }

    /**
     * @return the bbscttSeq
     */
    public int getBbscttSeq() {
        return bbscttSeq;
    }

    /**
     * @param bbscttSeq the bbscttSeq to set
     */
    public void setBbscttSeq(int bbscttSeq) {
        this.bbscttSeq = bbscttSeq;
    }

    /**
     * @return the categoryCd
     */
    public String getCategoryCd() {
        return categoryCd;
    }

    /**
     * @param categoryCd the categoryCd to set
     */
    public void setCategoryCd(String categoryCd) {
        this.categoryCd = categoryCd;
    }

    /**
     * @return the popupBgnde
     */
    public Date getPopupBgnde() {
        return popupBgnde;
    }

    /**
     * @param popupBgnde the popupBgnde to set
     */
    public void setPopupBgnde(Date popupBgnde) {
        this.popupBgnde = popupBgnde;
    }

    /**
     * @return the popupEndde
     */
    public Date getPopupEndde() {
        return popupEndde;
    }

    /**
     * @param popupEndde the popupEndde to set
     */
    public void setPopupEndde(Date popupEndde) {
        this.popupEndde = popupEndde;
    }

    /**
     * @return the emrgncyYn
     */
    public String getEmrgncyYn() {
        return emrgncyYn;
    }

    /**
     * @param emrgncyYn the emrgncyYn to set
     */
    public void setEmrgncyYn(String emrgncyYn) {
        this.emrgncyYn = emrgncyYn;
    }

    /**
     * @return the bbscttSj
     */
    public String getBbscttSj() {
        return bbscttSj;
    }

    /**
     * @param bbscttSj the bbscttSj to set
     */
    public void setBbscttSj(String bbscttSj) {
        this.bbscttSj = bbscttSj;
    }

    /**
     * @return the bbscttCn
     */
    public String getBbscttCn() {
        return bbscttCn;
    }

    /**
     * @param bbscttCn the bbscttCn to set
     */
    public void setBbscttCn(String bbscttCn) {
        this.bbscttCn = bbscttCn;
    }

    /**
     * @return the rdCnt
     */
    public int getRdCnt() {
        return rdCnt;
    }

    /**
     * @param rdCnt the rdCnt to set
     */
    public void setRdCnt(int rdCnt) {
        this.rdCnt = rdCnt;
    }

    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }

    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }

    /**


    /**
     * @return the saveType
     */
    public String getSaveType() {
        return saveType;
    }

    /**
     * @param saveType the saveType to set
     */
    public void setSaveType(String saveType) {
        this.saveType = saveType;
    }
    
    /**
     * @return the atchSe
     */
    public String getAtchSe() {
        return atchSe;
    }

    /**
     * @param atchSe the atchSe to set
     */
    public void setAtchSe(String atchSe) {
        this.atchSe = atchSe;
    }

    
    /**
     * @return the atchId
     */
    public String getAtchId() {
        return atchId;
    }

    /**
     * @param atchId the atchId to set
     */
    public void setAtchId(String atchId) {
        this.atchId = atchId;
    }

    /**
     * @return the salesOrg
     */
    public String getSalesOrg() {
        return salesOrg;
    }

    /**
     * @param salesOrg the salesOrg to set
     */
    public void setSalesOrg(String salesOrg) {
        this.salesOrg = salesOrg;
    }

    /**
     * @return the popYn
     */
    public String getPopYn() {
        return popYn;
    }

    /**
     * @param popYn the popYn to set
     */
    public void setPopYn(String popYn) {
        this.popYn = popYn;
    } 
}
