package com.mobis.maps.nmgn.ti.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.vo.DownloadAoFinishVO;
import com.mobis.maps.nmgn.ti.vo.DownloadAoRequestVO;
import com.mobis.maps.nmgn.ti.vo.DownloadAoVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DownloadAoService.java
 * @Description : Download AO List
 * @author 이수지
 * @since 2020. 06. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 16.       이수지      	    최초 생성
 * </pre>
 */

public interface DownloadAoService {

    /**
     * Download AO List
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<DownloadAoVO> selectDownloadAo (LoginInfoVO loginVo, DownloadAoVO params) throws Exception;

    /**
     * Download AO Request
     *
     * @param loginInfo
     * @param params
     * @throws Exception 
     */
    void selectDownloadAoRequest(LoginInfoVO loginInfo, DownloadAoRequestVO params) throws Exception;

    /**
     * Download AO Finish
     *
     * @param loginInfo
     * @param params
     */
    void selectDownloadAoFinish(LoginInfoVO loginInfo, DownloadAoFinishVO params) throws Exception;

}
