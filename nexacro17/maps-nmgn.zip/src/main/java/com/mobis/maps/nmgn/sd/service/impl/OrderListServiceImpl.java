package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.OrderListService;
import com.mobis.maps.nmgn.sd.vo.OrderListVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderListServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2019. 12. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 16.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("orderListService")
public class OrderListServiceImpl extends HService implements OrderListService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.OrderListService#selectSbookList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.OrderListVO)
     */
    @Override
    public List<OrderListVO> selectOrderList(LoginInfoVO loginInfo, OrderListVO paramVO) throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER_LIST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        /* RFC 파라미터(Import) 셋팅 */
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);        
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<OrderListVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, OrderListVO.class);     

        return odrLst;
    }

}
