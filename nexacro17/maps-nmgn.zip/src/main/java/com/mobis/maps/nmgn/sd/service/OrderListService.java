package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.OrderListVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderListService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2019. 12. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 16.     jiyongdo     	최초 생성
 * </pre>
 */

public interface OrderListService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<OrderListVO> selectOrderList(LoginInfoVO loginInfo, OrderListVO paramVO) throws Exception;

}
