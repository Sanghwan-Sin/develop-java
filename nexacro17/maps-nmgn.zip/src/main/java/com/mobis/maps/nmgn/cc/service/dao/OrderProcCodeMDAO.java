package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.OrderProcCodeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderProcCodeMDAO.java
 * @Description : Parts Order Plan DAO
 * @author ha.jeongryeong
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     ha.jeongryeong         최초 생성
 * </pre>
 */

@Mapper("orderProcCodeMDAO")
public interface OrderProcCodeMDAO {

    /**
     * 조회
     *
     * @param inputVO
     * @return
     */
    List<OrderProcCodeVO> selectOrderProcCodeList(OrderProcCodeVO paramVO);

}
