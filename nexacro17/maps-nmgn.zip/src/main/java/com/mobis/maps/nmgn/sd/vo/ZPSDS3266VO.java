package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ZPSDS3266VO.java
 * @Description : MOSR : Order Status Report
 * @author hong.minho
 * @since 2020. 7. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 20.     hong.minho     	최초 생성
 * </pre>
 */

public class ZPSDS3266VO extends MapsCommSapRfcIfCommVO {
    private String dstcd;   /* [dstcd,0~6       ] Distributor Code */
    private String issdt;   /* [issdt,6~14      ] Date */
    private String tocnt;   /* [tocnt,14~19     ] Total Count of Order Number */
    private String tbitm;   /* [tbitm,19~26     ] Total Count of Back Order Items */
    private String tbqty;   /* [tbqty,26~33     ] Total Pieces of Back Order */
    private String tbamt;   /* [tbamt,33~44     ] Total Amount of Back Order */
    private String rcvdt;   /* [rcvdt,44~52     ] Order Receipt Date */
    private String ordno;   /* [ordno,52~62     ] Order Number */
    private String shpmd;   /* [shpmd,62~63     ] Ship Mode */
    private String ordln;   /* [ordln,63~67     ] Line Item Number */
    private String ordls;   /* [ordls,67~68     ] Line Item Number Suffix */
    private String bptno;   /* [bptno,68~86     ] Supplied Part Number */
    private String amdcd;   /* [amdcd,86~88     ] Amend Code */
    private String bptnm;   /* [bptnm,88~103    ] Part Name */
    private String cptno;   /* [cptno,103~121   ] Confirmed Part Number */
    private String cfqty;   /* [cfqty,121~128   ] Supplied Plan Quantity */
    private String etddt;   /* [etddt,128~136   ] ETD */
    private String boqty;   /* [boqty,136~143   ] Back Order Quantity */
    private String flqty;   /* [flqty,143~150   ] Processing Quantity */
    private String paqty;   /* [paqty,150~157   ] Packed Quantity */
    private String spqty;   /* [spqty,157~164   ] Shipped Quantity */
    private String shpdt;   /* [shpdt,164~172   ] Last Shipped Date */
    private String invno;   /* [invno,172~180   ] Last Invoice Number */
    private String odfcd;   /* [odfcd,180~181   ] Flag Code */
    private String intcd;   /* [intcd,181~182   ] Intermediary Trade */
    /**
     * @return the dstcd
     */
    public String getDstcd() {
        return dstcd;
    }
    /**
     * @param dstcd the dstcd to set
     */
    public void setDstcd(String dstcd) {
        this.dstcd = dstcd;
    }
    /**
     * @return the issdt
     */
    public String getIssdt() {
        return issdt;
    }
    /**
     * @param issdt the issdt to set
     */
    public void setIssdt(String issdt) {
        this.issdt = issdt;
    }
    /**
     * @return the tocnt
     */
    public String getTocnt() {
        return tocnt;
    }
    /**
     * @param tocnt the tocnt to set
     */
    public void setTocnt(String tocnt) {
        this.tocnt = tocnt;
    }
    /**
     * @return the tbitm
     */
    public String getTbitm() {
        return tbitm;
    }
    /**
     * @param tbitm the tbitm to set
     */
    public void setTbitm(String tbitm) {
        this.tbitm = tbitm;
    }
    /**
     * @return the tbqty
     */
    public String getTbqty() {
        return tbqty;
    }
    /**
     * @param tbqty the tbqty to set
     */
    public void setTbqty(String tbqty) {
        this.tbqty = tbqty;
    }
    /**
     * @return the tbamt
     */
    public String getTbamt() {
        return tbamt;
    }
    /**
     * @param tbamt the tbamt to set
     */
    public void setTbamt(String tbamt) {
        this.tbamt = tbamt;
    }
    /**
     * @return the rcvdt
     */
    public String getRcvdt() {
        return rcvdt;
    }
    /**
     * @param rcvdt the rcvdt to set
     */
    public void setRcvdt(String rcvdt) {
        this.rcvdt = rcvdt;
    }
    /**
     * @return the ordno
     */
    public String getOrdno() {
        return ordno;
    }
    /**
     * @param ordno the ordno to set
     */
    public void setOrdno(String ordno) {
        this.ordno = ordno;
    }
    /**
     * @return the shpmd
     */
    public String getShpmd() {
        return shpmd;
    }
    /**
     * @param shpmd the shpmd to set
     */
    public void setShpmd(String shpmd) {
        this.shpmd = shpmd;
    }
    /**
     * @return the ordln
     */
    public String getOrdln() {
        return ordln;
    }
    /**
     * @param ordln the ordln to set
     */
    public void setOrdln(String ordln) {
        this.ordln = ordln;
    }
    /**
     * @return the ordls
     */
    public String getOrdls() {
        return ordls;
    }
    /**
     * @param ordls the ordls to set
     */
    public void setOrdls(String ordls) {
        this.ordls = ordls;
    }
    /**
     * @return the bptno
     */
    public String getBptno() {
        return bptno;
    }
    /**
     * @param bptno the bptno to set
     */
    public void setBptno(String bptno) {
        this.bptno = bptno;
    }
    /**
     * @return the amdcd
     */
    public String getAmdcd() {
        return amdcd;
    }
    /**
     * @param amdcd the amdcd to set
     */
    public void setAmdcd(String amdcd) {
        this.amdcd = amdcd;
    }
    /**
     * @return the bptnm
     */
    public String getBptnm() {
        return bptnm;
    }
    /**
     * @param bptnm the bptnm to set
     */
    public void setBptnm(String bptnm) {
        this.bptnm = bptnm;
    }
    /**
     * @return the cptno
     */
    public String getCptno() {
        return cptno;
    }
    /**
     * @param cptno the cptno to set
     */
    public void setCptno(String cptno) {
        this.cptno = cptno;
    }
    /**
     * @return the cfqty
     */
    public String getCfqty() {
        return cfqty;
    }
    /**
     * @param cfqty the cfqty to set
     */
    public void setCfqty(String cfqty) {
        this.cfqty = cfqty;
    }
    /**
     * @return the etddt
     */
    public String getEtddt() {
        return etddt;
    }
    /**
     * @param etddt the etddt to set
     */
    public void setEtddt(String etddt) {
        this.etddt = etddt;
    }
    /**
     * @return the boqty
     */
    public String getBoqty() {
        return boqty;
    }
    /**
     * @param boqty the boqty to set
     */
    public void setBoqty(String boqty) {
        this.boqty = boqty;
    }
    /**
     * @return the flqty
     */
    public String getFlqty() {
        return flqty;
    }
    /**
     * @param flqty the flqty to set
     */
    public void setFlqty(String flqty) {
        this.flqty = flqty;
    }
    /**
     * @return the paqty
     */
    public String getPaqty() {
        return paqty;
    }
    /**
     * @param paqty the paqty to set
     */
    public void setPaqty(String paqty) {
        this.paqty = paqty;
    }
    /**
     * @return the spqty
     */
    public String getSpqty() {
        return spqty;
    }
    /**
     * @param spqty the spqty to set
     */
    public void setSpqty(String spqty) {
        this.spqty = spqty;
    }
    /**
     * @return the shpdt
     */
    public String getShpdt() {
        return shpdt;
    }
    /**
     * @param shpdt the shpdt to set
     */
    public void setShpdt(String shpdt) {
        this.shpdt = shpdt;
    }
    /**
     * @return the invno
     */
    public String getInvno() {
        return invno;
    }
    /**
     * @param invno the invno to set
     */
    public void setInvno(String invno) {
        this.invno = invno;
    }
    /**
     * @return the odfcd
     */
    public String getOdfcd() {
        return odfcd;
    }
    /**
     * @param odfcd the odfcd to set
     */
    public void setOdfcd(String odfcd) {
        this.odfcd = odfcd;
    }
    /**
     * @return the intcd
     */
    public String getIntcd() {
        return intcd;
    }
    /**
     * @param intcd the intcd to set
     */
    public void setIntcd(String intcd) {
        this.intcd = intcd;
    }


}
