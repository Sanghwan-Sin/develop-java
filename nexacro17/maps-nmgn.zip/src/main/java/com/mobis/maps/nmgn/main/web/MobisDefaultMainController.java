package com.mobis.maps.nmgn.main.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.nmgn.cc.service.CalendarService;
import com.mobis.maps.nmgn.cc.service.MapsNoticeService;
import com.mobis.maps.nmgn.cc.service.NewsLetterService;
import com.mobis.maps.nmgn.cc.vo.CalendarVO;
import com.mobis.maps.nmgn.cc.vo.MapsNoticeVO;
import com.mobis.maps.nmgn.cc.vo.MapsOrderSummaryVO;
import com.mobis.maps.nmgn.cc.vo.NewsLetterVO;
import com.mobis.maps.nmgn.main.service.MobisDefaultMainService;
import com.mobis.maps.nmgn.main.vo.MobisDefaultMainVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MobisDefaultMainController.java
 * @Description : Main Controller
 * @author jiyongdo
 * @since 2020. 8. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 14.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class MobisDefaultMainController extends HController{
    
    @Resource(name = "mobisDefaultMainService")
    private MobisDefaultMainService mobisDefaultMainService;
    
    @Resource(name = "newsLetterService")
    private NewsLetterService newsLetterService;
    
    @Resource(name = "calendarService")
    private CalendarService calendarService;
    
    @Resource(name = "mapsNoticeService")
    private MapsNoticeService mapsNoticeService;
    
    /**
     * selectMainPaymentDueOrderList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */        
    @RequestMapping(value = "/main/selectMainPaymentDueOrderList.do")
    public NexacroResult selectMainPaymentDueOrderList(@ParamDataSet(name="dsInput") MobisDefaultMainVO paramVO
                                                     , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        Map<String, Object> retMap = mobisDefaultMainService.selectMainPaymentDueOrderList(loginInfo, paramVO);
        MobisDefaultMainVO retVo = (MobisDefaultMainVO)retMap.get("body");
        result.addDataSet("dsOutput", retVo);

        return result;
    }    
    
    /**
     * selectMainStatementofBalance
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */        
    @RequestMapping(value = "/main/selectMainStatementofBalance.do")
    public NexacroResult selectMainStatementofBalance(@ParamDataSet(name="dsInput") MobisDefaultMainVO paramVO
                                                    , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        Map<String, Object> retMap = mobisDefaultMainService.selectMainStatementofBalance(loginInfo, paramVO);
        MobisDefaultMainVO retVo = (MobisDefaultMainVO)retMap.get("body");
        result.addDataSet("dsOutput", retVo);

        return result;
    }
    
    /**
     * selectNewsLetter
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/main/selectNewsLetter.do")
    public NexacroResult selectNewsLetter(@ParamDataSet(name="dsInput") NewsLetterVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<NewsLetterVO> list = newsLetterService.selectNewsLetter(loginInfo, params);
        
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectNewsLetterDetail
     * 
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/main/selectNewsLetterDetail.do")
    public NexacroResult selectNewsLetterDetail(@ParamDataSet(name="dsInput") NewsLetterVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<NewsLetterVO> list = newsLetterService.selectNewsLetterDetail(loginInfo, params);

        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * 월 Calendar 조회
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/main/selectCalendarMon.do")
    public NexacroResult selectCalendarMon(@ParamDataSet(name="dsInput") CalendarVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsOrgnztDistVO orgInfo = (MapsOrgnztDistVO) getSessionAttribute(MapsConstants.SSS_ORGNZT_INFO);
        
        List<CalendarVO> retList = calendarService.selectCalendarMon(loginInfo, orgInfo, paramVO);

        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsReturn", paramVO);
        
        return result;
    }
    
    /**
     * selectNoticeList
     * 
     * @param inputVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/main/selectMainNoticeList.do")
    public NexacroResult selectMainNoticeList(@ParamDataSet(name="dsInput") MapsNoticeVO inputVO
                                           , NexacroResult result) throws Exception {
        List<MapsNoticeVO> resultVo = mapsNoticeService.selectMainNoticeList(inputVO);

        result.addDataSet("dsOutput", resultVo);

        return result;
    }       
    
    /**
     * selectNoticeNewList
     * 
     * @param inputVO
     * @param result
     * @return
     * @throws Exception
     */       
    @RequestMapping(value = "/main/selectNoticeNewList.do")
    public NexacroResult selectNoticeNewList(@ParamDataSet(name="dsInput") MapsNoticeVO inputVO
                                              , NexacroResult result) throws Exception {
        MapsNoticeVO resultVo = mapsNoticeService.selectNoticeNewList(inputVO);

        result.addDataSet("dsOutput", resultVo);

        return result;
    }      
    
    
    /**
     * Main
     * - Order Processing Summary
     * - Order Status Summary
     * - Order Unprocessed List
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/main/selectOrderProcessSummary.do")
    public NexacroResult selectOrderProcessSummary(@ParamDataSet(name="dsInput") MapsOrderSummaryVO params
                                              , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsOrderSummaryVO rsltVo = mobisDefaultMainService.selectOrderProcessSummary(loginInfo, params);

        result.addDataSet("dsOutput", rsltVo);
        
        return result;
    }      

}
