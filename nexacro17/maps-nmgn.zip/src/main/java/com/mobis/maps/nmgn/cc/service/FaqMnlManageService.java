package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.nmgn.cc.vo.FaqMnlManageVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FaqMnlManageService.java
 * @Description : FaqMnlManageService
 * @author choi.cheolho
 * @since 2019. 10. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 17.  choi.cheolho         최초 생성
 * </pre>
 */

public interface FaqMnlManageService {

    /**
     * FAQ List 조회
     *
     * @param paramVO
     * @return
     */
    List<FaqMnlManageVO> selectFaqList(FaqMnlManageVO paramVO);

    /**
     * FAQ 등록
     *
     * @param paramVO
     * @return
     */
    int insertFaqManage(FaqMnlManageVO paramVO) throws Exception;

    /**
     * 단건 조회
     *
     * @param paramVO
     * @return
     */
    FaqMnlManageVO selectFaq(FaqMnlManageVO paramVO) throws Exception;

    /**
     * 수정
     *
     * @param paramVO
     * @return
     */
    int updateFaqManage(FaqMnlManageVO paramVO) throws Exception;

    /**
     * 삭제
     *
     * @param paramVO
     * @return
     */
    int deleteFaqManage(FaqMnlManageVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVO
     * @return
     */
    FaqMnlManageVO selectFaqEditList(FaqMnlManageVO paramVO) throws Exception;

    /**
     * 조회
     *
     * @param sampleMsgVO
     * @return
     * @throws Exception
     
    public List<FaqMnlManageVO> selectWorkCalMgrList(WorkCalMgrVO paramVO) throws Exception;
    */
    
    /**
     * 저장(detail)
     *
     * @param inputVO
     * @return
     
    int multiWorkCalMgr(WorkCalMgrVO paramVO, List<WorkCalMgrVO> paramList) throws Exception;
    */
   
}
