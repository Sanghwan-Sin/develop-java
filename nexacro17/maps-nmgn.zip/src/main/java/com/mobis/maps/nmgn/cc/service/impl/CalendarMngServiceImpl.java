package com.mobis.maps.nmgn.cc.service.impl;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.CalendarMngService;
import com.mobis.maps.nmgn.cc.service.dao.CalendarMngMDAO;
import com.mobis.maps.nmgn.cc.vo.CalendarMngVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarMngServiceImpl.java
 * @Description : Work Calendar Manage
 * @author 이수지
 * @since 2020. 5. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 25.      이수지             	최초 생성
 * </pre>
 */
@Service("calendarMngService")
public class CalendarMngServiceImpl extends HService implements CalendarMngService{

    @Resource(name = "calendarMngMDAO")
    CalendarMngMDAO calendarMngMDAO;

    /*
     * @see com.mobis.maps.nmgn.cc.service.CalendarMngService#selectNewsLetter(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.CalendarMngVO)
     */
    @Override
    public List<CalendarMngVO> selectCalendarMngList(LoginInfoVO loginInfo, CalendarMngVO params) throws Exception {

        List<CalendarMngVO> retList = calendarMngMDAO.selectCalendarMngList(params);
        
        return retList;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.CalendarMngService#multiCalendarMng(com.mobis.maps.cmmn.vo.LoginInfoVO, java.util.List)
     */
    @Override
    public void multiCalendarMng(LoginInfoVO loginInfo, List<CalendarMngVO> params) {
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", loginInfo.getUserLcale());
               
        for(CalendarMngVO vo : params) {
            
            if (vo.getStddt() == null) continue;
            
            vo.setStdlang(loginInfo.getLangCd()); // 기준언어
            vo.setStddtstr(sdf.format(vo.getStddt()));
            vo.setUpdtId(loginInfo.getUserId());
            
            switch (vo.getRowSe()) {
                case "I":
                    vo.setRegistId(loginInfo.getUserId());
                    calendarMngMDAO.insertCalendarMng(vo);
                    break;
                case "U":
                    calendarMngMDAO.updateCalendarMng(vo);
                    break;
                case "D":
                    calendarMngMDAO.deleteCalendarMng(vo);
                    break;
                default:
                    break;
            }
        }
    }

}
