package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderMatnrValidateVO.java
 * @Description : 부품번호체크
 * @author 홍민호
 * @since 2020. 3. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 9.     홍민호    	최초 생성
 * </pre>
 */

public class OrderMatnrValidateVO extends MapsCommSapRfcIfCommVO {
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** 영업 조직 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** 유통 경로 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    /** 플랜트 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_WERKS" )
    private String iWerks;
    /** H/K Common */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    
    
    /** Unit of measure */
    @MapsRfcMappper( ipttSe="E", fieldKey="O_MEINS" )
    private String oMeins;
    /** 설계부품명칭 */
    @MapsRfcMappper( ipttSe="E", fieldKey="O_ZPTNM" )
    private String oZptnm;
    /** Native Part Name */
    @MapsRfcMappper( ipttSe="E", fieldKey="O_ZPTNM_NTV" )
    private String oZptnmNtv;
    /** SUC */
    @MapsRfcMappper( ipttSe="E", fieldKey="O_ZSUCCD" )
    private String oZsuccd;
    /** SUC Desc. */
    @MapsRfcMappper( ipttSe="E", fieldKey="O_ZSUCCD_NM" )
    private String oZsuccdNm;
    
    
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the iWerks
     */
    public String getiWerks() {
        return iWerks;
    }
    /**
     * @param iWerks the iWerks to set
     */
    public void setiWerks(String iWerks) {
        this.iWerks = iWerks;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the oMeins
     */
    public String getoMeins() {
        return oMeins;
    }
    /**
     * @param oMeins the oMeins to set
     */
    public void setoMeins(String oMeins) {
        this.oMeins = oMeins;
    }
    /**
     * @return the oZptnm
     */
    public String getoZptnm() {
        return oZptnm;
    }
    /**
     * @param oZptnm the oZptnm to set
     */
    public void setoZptnm(String oZptnm) {
        this.oZptnm = oZptnm;
    }
    /**
     * @return the oZptnmNtv
     */
    public String getoZptnmNtv() {
        return oZptnmNtv;
    }
    /**
     * @param oZptnmNtv the oZptnmNtv to set
     */
    public void setoZptnmNtv(String oZptnmNtv) {
        this.oZptnmNtv = oZptnmNtv;
    }
    /**
     * @return the oZsuccd
     */
    public String getoZsuccd() {
        return oZsuccd;
    }
    /**
     * @param oZsuccd the oZsuccd to set
     */
    public void setoZsuccd(String oZsuccd) {
        this.oZsuccd = oZsuccd;
    }
    /**
     * @return the oZsuccdNm
     */
    public String getoZsuccdNm() {
        return oZsuccdNm;
    }
    /**
     * @param oZsuccdNm the oZsuccdNm to set
     */
    public void setoZsuccdNm(String oZsuccdNm) {
        this.oZsuccdNm = oZsuccdNm;
    }
    
}
