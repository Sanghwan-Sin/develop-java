package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : EtdRequestChkVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 7. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 3.     jiyongdo     	최초 생성
 * </pre>
 */

public class EtdRequestChkVO extends MapsCommSapRfcIfCommVO{
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** C:Create, U:Change, R:Display, D:Delete */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** Order Line Number */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDLN" )
    private String iZordln;
    /** Order Line Suffix */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDLS" )
    private String iZordls;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_E" )
    private String iZordnoE;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    //-----[IT_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZBOQTY" )
    private String zboqty;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZCODE" )
    private String zcode;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZDESC" )
    private String zdesc;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZETD_QT_BO" )
    private String zetdQtBo;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZETD_QT_IV" )
    private String zetdQtIv;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZETD_BO" )
    private Date zetdBo;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZETD_IV" )
    private Date zetdIv;
    
    //-----[IT_DATA] END-----
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZordln
     */
    public String getiZordln() {
        return iZordln;
    }
    /**
     * @param iZordln the iZordln to set
     */
    public void setiZordln(String iZordln) {
        this.iZordln = iZordln;
    }
    /**
     * @return the iZordls
     */
    public String getiZordls() {
        return iZordls;
    }
    /**
     * @param iZordls the iZordls to set
     */
    public void setiZordls(String iZordls) {
        this.iZordls = iZordls;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zcode
     */
    public String getZcode() {
        return zcode;
    }
    /**
     * @param zcode the zcode to set
     */
    public void setZcode(String zcode) {
        this.zcode = zcode;
    }
    /**
     * @return the zdesc
     */
    public String getZdesc() {
        return zdesc;
    }
    /**
     * @param zdesc the zdesc to set
     */
    public void setZdesc(String zdesc) {
        this.zdesc = zdesc;
    }
    /**
     * @return the zetdQtBo
     */
    public String getZetdQtBo() {
        return zetdQtBo;
    }
    /**
     * @param zetdQtBo the zetdQtBo to set
     */
    public void setZetdQtBo(String zetdQtBo) {
        this.zetdQtBo = zetdQtBo;
    }
    /**
     * @return the zetdQtIv
     */
    public String getZetdQtIv() {
        return zetdQtIv;
    }
    /**
     * @param zetdQtIv the zetdQtIv to set
     */
    public void setZetdQtIv(String zetdQtIv) {
        this.zetdQtIv = zetdQtIv;
    }
    /**
     * @return the zetdBo
     */
    public Date getZetdBo() {
        return zetdBo;
    }
    /**
     * @param zetdBo the zetdBo to set
     */
    public void setZetdBo(Date zetdBo) {
        this.zetdBo = zetdBo;
    }
    /**
     * @return the zetdIv
     */
    public Date getZetdIv() {
        return zetdIv;
    }
    /**
     * @param zetdIv the zetdIv to set
     */
    public void setZetdIv(Date zetdIv) {
        this.zetdIv = zetdIv;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
}
