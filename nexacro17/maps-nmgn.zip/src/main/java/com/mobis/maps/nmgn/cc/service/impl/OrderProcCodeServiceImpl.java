package com.mobis.maps.nmgn.cc.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.nmgn.cc.service.OrderProcCodeService;
import com.mobis.maps.nmgn.cc.service.dao.OrderProcCodeMDAO;
import com.mobis.maps.nmgn.cc.vo.OrderProcCodeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplQmPersnMngrServiceImpl.java
 * @Description : OrderProcCodeServiceImpl
 * @author ha.jeongryeong
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     ha.jeongryeong         최초 생성
 * </pre>
 */
@Service("orderProcCodeService")
public class OrderProcCodeServiceImpl extends HService implements OrderProcCodeService {

    @Resource(name = "orderProcCodeMDAO")
    private OrderProcCodeMDAO orderProcCodeMDAO;

    /*
     * @see com.mobis.maps.nmgn.cc.service.OrderProcCodeService#selectOrderProcCodeList(com.mobis.maps.nmgn.cc.vo.OrderProcCodeVO)
     */
    @Override
    public List<OrderProcCodeVO> selectOrderProcCodeList(OrderProcCodeVO paramVO) throws Exception {
        List<OrderProcCodeVO> retList = orderProcCodeMDAO.selectOrderProcCodeList(paramVO);
        return retList;
    }
    
    
}
