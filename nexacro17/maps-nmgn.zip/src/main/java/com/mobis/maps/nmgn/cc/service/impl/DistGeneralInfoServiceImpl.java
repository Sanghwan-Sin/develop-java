package com.mobis.maps.nmgn.cc.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.nmgn.cc.service.DistGeneralInfoService;
import com.mobis.maps.nmgn.cc.service.dao.DistGeneralInfoMDAO;
import com.mobis.maps.nmgn.cc.vo.DistGeneralInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplQmPersnMngrServiceImpl.java
 * @Description : PartsOrderPlanServiceImpl
 * @author ha.jeongryeong
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     ha.jeongryeong     	최초 생성
 * </pre>
 */
@Service("distGeneralInfoService")
public class DistGeneralInfoServiceImpl extends HService implements DistGeneralInfoService {

    @Resource(name = "distGeneralInfoMDAO")
    private DistGeneralInfoMDAO distGeneralInfoDAO;

    /*
     * @see com.mobis.maps.nmgn.cc.service.PartsOrderPlanService#selectPartsOrderPlanList(com.mobis.maps.nmgn.cc.vo.PartsOrderPlanVO)
     */
    @Override
    public List<DistGeneralInfoVO> selectDistGeneralInfoList(DistGeneralInfoVO paramVO) throws Exception {
        List<DistGeneralInfoVO> retList = distGeneralInfoDAO.selectDistGeneralInfoList(paramVO);
        return retList;
    }


}
