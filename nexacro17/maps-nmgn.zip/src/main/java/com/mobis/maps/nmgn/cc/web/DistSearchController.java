package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.nmgn.cc.service.DistSearchService;
import com.mobis.maps.nmgn.cc.vo.DistSearchVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistSearchController.java
 * @Description : 대리점 검색
 * @author hong.minho
 * @since 2020. 3. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 13.     hong.minho     	최초 생성
 * </pre>
 */

@Controller
public class DistSearchController extends HController {
    
    @Resource(name = "distSearchService")
    DistSearchService service;

    /**
     * 대리점 검색
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDistSearch.do")
    public NexacroResult selectDistSearch (
            @ParamDataSet(name="dsInput") DistSearchVO paramVO
            , NexacroResult result) throws Exception {

//        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<DistSearchVO> retList = service.selectDistSearch(paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }


    
    /**
     * 대리점 검색 엑셀 다운로드
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDistSearchExcelDown.do")
    public NexacroResult selectDistSearchExcelDown (
            @ParamDataSet(name="dsInput") DistSearchVO paramVO
            , NexacroResult result) throws Exception {

//        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setExcelDwnlYn("Y");
        List<DistSearchVO> retList = service.selectDistSearch(paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }

    

    /**
     * 대리점 정보 조회
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDistInfo.do")
    public NexacroResult selectDistInfo (
            @ParamDataSet(name="dsInput") DistSearchVO paramVO
            , NexacroResult result) throws Exception {

//        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsOrgnztDistVO orgVo = (MapsOrgnztDistVO) getSessionAttribute(MapsConstants.SSS_ORGNZT_INFO);
        
        DistSearchVO vo = service.selectDistInfo(paramVO, orgVo);

        result.addDataSet("dsOutput", vo);

        return result;
    }


    /**
     * 하위대리점 조회 (대표대리점의 경우)
     *
     * @param params
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectSubDistLst.do")
    public NexacroResult selectSubDistLst (
            @ParamDataSet(name="dsInput") DistSearchVO params
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsOrgnztDistVO orgVo = (MapsOrgnztDistVO) getSessionAttribute(MapsConstants.SSS_ORGNZT_INFO);
        
        
        List<DistSearchVO> retList = service.selectSubDistLst(params, loginInfo, orgVo);

        result.addDataSet("dsOutput", retList);

        return result;
    }
   
}
