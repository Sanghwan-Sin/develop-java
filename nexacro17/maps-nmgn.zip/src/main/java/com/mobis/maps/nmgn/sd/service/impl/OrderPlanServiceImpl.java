package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.OrderPlanService;
import com.mobis.maps.nmgn.sd.vo.OrderPlanVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.nexacro17.xapi.data.DataSet;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderPlanServiceImpl.java
 * @Description : ZJSDO30220 Parts Order Plan
 * @author 홍민호
 * @since 2020. 2. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 5.     홍민호         최초 생성
 * </pre>
 */

@Service("orderPlanService")
public class OrderPlanServiceImpl extends HService implements OrderPlanService {

    
    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderPlanService#selectOrderPlan(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderPlanVO)
     */
    @Override
    public List<OrderPlanVO> selectOrderPlan(LoginInfoVO loginVo, OrderPlanVO params) throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER_PLAN;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        params.setiType("R"); // Select

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<OrderPlanVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_LIST", params, OrderPlanVO.class);

        return list;
    }

    
    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderPlanService#saveOrderPlan(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderPlanVO, java.util.List)
     */
    @Override
    public OrderPlanVO multiSaveOrderPlan(LoginInfoVO loginVo, OrderPlanVO params, List<OrderPlanVO> paramLst)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER_PLAN;
        params.setIfCode(sapRfcInfo.getIfCode());
        
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        params.setiType("U"); // Update
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        // TABLES 적재
        for(OrderPlanVO vo : paramLst) {
            if(vo.getRowType() == DataSet.ROW_TYPE_UPDATED) {
                MapsRfcMappperUtil.appendImportTableRow(func, "T_LIST", vo);
            }
        }
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 결과
        List<OrderPlanVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_LIST", params, OrderPlanVO.class);
        params.setList(list);
        
        return params;
    }

}
