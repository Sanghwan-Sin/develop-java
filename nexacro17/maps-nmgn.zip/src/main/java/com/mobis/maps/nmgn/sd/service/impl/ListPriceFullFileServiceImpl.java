package com.mobis.maps.nmgn.sd.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.ListPriceFullFileService;
import com.mobis.maps.nmgn.sd.vo.ListPriceFullFileVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceFullFileServiceImpl.java
 * @Description : ZJSDR20210 List Price Full 파일 생성 요청 및 Download
 * @author 이수지
 * @since 2020. 2. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 12.      이수지      	        최초 생성
 * </pre>
 */

@Service("listPriceFullFileService")
public class ListPriceFullFileServiceImpl extends HService implements ListPriceFullFileService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceFullFileService#selectListPriceFullFile(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.ListPriceFullFileVO)
     */
    @Override
    public List<ListPriceFullFileVO> selectListPriceFullFile(LoginInfoVO loginVo, ListPriceFullFileVO params)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_LIST_PRICE_FUL_FILE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        MapsRfcMappperUtil.setImportStructure(func, "IS_DATES", params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        MapsRfcMappperUtil.setExportParamList(funcRslt, params, loginVo.getUserLcale());
        
        //*** 조회결과
        List<ListPriceFullFileVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, ListPriceFullFileVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceFullFileService#selectCustomerInfo(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.ListPriceFullFileVO)
     */
    @Override
    public List<ListPriceFullFileVO> selectCustomerInfo(LoginInfoVO loginVo, ListPriceFullFileVO params)
            throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_CUSTOMER_INFO;
        
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<ListPriceFullFileVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, ListPriceFullFileVO.class);

        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceFullFileService#multiListPriceFullFile(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.ListPriceFullFileVO, java.util.List)
     */
    @Override
    public Map<String, Object> multiListPriceFullFile(LoginInfoVO loginVo, ListPriceFullFileVO params, List<ListPriceFullFileVO> paramList)
            throws Exception {
        
        //*** Destination 취득
        Map<String, Object> retMap  = new HashMap<String, Object>();
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_LIST_PRICE_FUL_FILE;
        
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** 파라미터(Import) 셋팅
        func.getImportParameterList().setValue("I_TYPE", "U");
        MapsRfcMappperUtil.setImportParamList(func, params);
        MapsRfcMappperUtil.setImportStructure(func, "IS_DATES", params);
        
        //*** 파라미터(TABLES) 추출, 적재        
        for (ListPriceFullFileVO tmpVO : paramList) {
           
            if (!"N".equals(tmpVO.getRowSe()) && "Y".equals(tmpVO.getChkYn())) {
                switch (tmpVO.getRowSe()) {
                    case "I":
                        tmpVO.setType("C");
                        tmpVO.setStatus("R");
                        tmpVO.setZcrname(loginVo.getUserId());
                        break;
                    case "U":
                        tmpVO.setType("U");
                        tmpVO.setZudname(loginVo.getUserId());
                        break;
                    case "D":
                        tmpVO.setType("D");
                        tmpVO.setLoevm("X");
                        tmpVO.setZudname(loginVo.getUserId());
                        break;
                    default:
                        break;
                }
                MapsRfcMappperUtil.appendImportTableRow(func, "T_RESULT", tmpVO);
            }
        }
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        List<ListPriceFullFileVO> retList = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, ListPriceFullFileVO.class);
        
        retMap.put("body", retList);
        
        return retMap;
    }
}
