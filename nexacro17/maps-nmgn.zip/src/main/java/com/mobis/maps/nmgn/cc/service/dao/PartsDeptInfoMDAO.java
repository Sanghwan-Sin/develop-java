package com.mobis.maps.nmgn.cc.service.dao;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.PartsDeptInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartsDeptInfoMDAO.java
 * @Description : PartsDeptInfo
 * @author ha.jeongryeong
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     ha.jeongryeong         최초 생성
 * </pre>
 */

@Mapper("partsDeptInfoMDAO")
public interface PartsDeptInfoMDAO {

    /**
     * 조회(detail)
     *
     * @param inputVO
     * @return
     */
    PartsDeptInfoVO selectPartsDeptInfo(PartsDeptInfoVO paramVO);
    
    /**
     * 삭제(detail)
     *
     * @param inputVO
     * @return
     */
    int deletePartsDeptInfo(PartsDeptInfoVO paramVO);
    
    /**
     * 저장(detail)
     *
     * @param inputVO
     * @return
     */
    int insertPartsDeptInfo(PartsDeptInfoVO paramVO);
}
