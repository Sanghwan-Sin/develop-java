package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PaymentDueOrderVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 4. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 17.     jiyongdo     	최초 생성
 * </pre>
 */

public class PaymentDueOrderVO extends MapsCommSapRfcIfCommVO{
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCURR" )
    private String iZcurr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    private String iZsacutmNm;
    //-----[ES_LIST_H] START-----
    /** Dist. Code */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    //-----[ES_LIST_H] END-----
    //-----[ET_LIST_D] START-----
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZORDNO" )
    private String zordno;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZRCVDT" )
    private Date zrcvdt;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZAORDT" )
    private Date zaordt;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZCALDT_C" )
    private BigDecimal zcaldtC;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZCALAMT_C" )
    private String zcalamtC;
    /** SD document currency */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** Long Text */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="LTEXT" )
    private String ltext;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZSHPTP" )
    private String zshptp;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="SNAME" )
    private String sname;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST_D", ipttSe="E", fieldKey="ZREFERENCE" )
    private String zreference;
    //-----[ET_LIST_D] END-----
    /**
     * @return the iZcurr
     */
    public String getiZcurr() {
        return iZcurr;
    }
    /**
     * @param iZcurr the iZcurr to set
     */
    public void setiZcurr(String iZcurr) {
        this.iZcurr = iZcurr;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZsacutmNm
     */
    public String getiZsacutmNm() {
        return iZsacutmNm;
    }
    /**
     * @param iZsacutmNm the iZsacutmNm to set
     */
    public void setiZsacutmNm(String iZsacutmNm) {
        this.iZsacutmNm = iZsacutmNm;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the zrcvdt
     */
    public Date getZrcvdt() {
        return zrcvdt;
    }
    /**
     * @param zrcvdt the zrcvdt to set
     */
    public void setZrcvdt(Date zrcvdt) {
        this.zrcvdt = zrcvdt;
    }
    /**
     * @return the zaordt
     */
    public Date getZaordt() {
        return zaordt;
    }
    /**
     * @param zaordt the zaordt to set
     */
    public void setZaordt(Date zaordt) {
        this.zaordt = zaordt;
    }
    /**
     * @return the zcaldtC
     */
    public BigDecimal getZcaldtC() {
        return zcaldtC;
    }
    /**
     * @param zcaldtC the zcaldtC to set
     */
    public void setZcaldtC(BigDecimal zcaldtC) {
        this.zcaldtC = zcaldtC;
    }
    /**
     * @return the zcalamtC
     */
    public String getZcalamtC() {
        return zcalamtC;
    }
    /**
     * @param zcalamtC the zcalamtC to set
     */
    public void setZcalamtC(String zcalamtC) {
        this.zcalamtC = zcalamtC;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the ltext
     */
    public String getLtext() {
        return ltext;
    }
    /**
     * @param ltext the ltext to set
     */
    public void setLtext(String ltext) {
        this.ltext = ltext;
    }
    /**
     * @return the zshptp
     */
    public String getZshptp() {
        return zshptp;
    }
    /**
     * @param zshptp the zshptp to set
     */
    public void setZshptp(String zshptp) {
        this.zshptp = zshptp;
    }
    /**
     * @return the sname
     */
    public String getSname() {
        return sname;
    }
    /**
     * @param sname the sname to set
     */
    public void setSname(String sname) {
        this.sname = sname;
    }
    /**
     * @return the zreference
     */
    public String getZreference() {
        return zreference;
    }
    /**
     * @param zreference the zreference to set
     */
    public void setZreference(String zreference) {
        this.zreference = zreference;
    }
}
