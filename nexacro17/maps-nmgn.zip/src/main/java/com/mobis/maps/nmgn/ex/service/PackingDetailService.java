package com.mobis.maps.nmgn.ex.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.vo.PackingDetailVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingDetailService.java
 * @Description : ZJEXR00190 Packing Detail
 * @author 이수지
 * @since 2020. 2. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 10.       이수지      	        최초 생성
 * </pre>
 */

public interface PackingDetailService {

    /**
     * Packing Detail
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<PackingDetailVO> selectPackingDetail (LoginInfoVO loginVo, PackingDetailVO params) throws Exception;
}
