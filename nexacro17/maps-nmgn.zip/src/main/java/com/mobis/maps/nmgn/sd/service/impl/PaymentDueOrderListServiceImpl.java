package com.mobis.maps.nmgn.sd.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.PaymentDueOrderListService;
import com.mobis.maps.nmgn.sd.vo.PaymentDueOrderVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PaymentDueOrderListServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 4. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 17.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("paymentDueOrderListService")
public class PaymentDueOrderListServiceImpl extends HService implements PaymentDueOrderListService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.sd.service.PaymentDueOrderListService#selectPaymentDueOrderList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.PaymentDueOrderVO)
     */
    @Override
    public Map<String, Object> selectPaymentDueOrderList(LoginInfoVO loginInfo, PaymentDueOrderVO paramVO) throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_PAYMENT_DUE_CF;
        //paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<PaymentDueOrderVO> rtnLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST_D", paramVO, PaymentDueOrderVO.class);
        PaymentDueOrderVO totLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_LIST_H", PaymentDueOrderVO.class);
        
        retMap.put("head", totLst);
        retMap.put("body", rtnLst);      
        
        return retMap;
    }
}
