package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.PromotionToNmgnService;
import com.mobis.maps.nmgn.sd.vo.PromotionProfileOrderTypeVO;
import com.mobis.maps.nmgn.sd.vo.PromotionProfileVO;
import com.mobis.maps.nmgn.sd.vo.PromotionToNmgnVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionToNmgnController.java
 * @Description : ZJSDR20110 [채널 RFC] - Promotion to nMGN
 * @author ChoKyungHo
 * @since 2020. 02. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 02. 26.    ChoKyungHo             최초 생성
 * </pre>
 */

@Controller
public class PromotionToNmgnController extends HController {

    @Resource(name = "promotionToNmgnService")
    private PromotionToNmgnService promotionToNmgnService;

    /**
     * selectPromotionToNmgn
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPromotionToNmgn.do")
    public NexacroResult selectPromotionToNmgn(@ParamDataSet(name="dsInput") PromotionToNmgnVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = promotionToNmgnService.selectPromotionToNmgn(loginInfo, paramVO);
    
        @SuppressWarnings("unchecked")
        List<PromotionToNmgnVO> retList = (List<PromotionToNmgnVO>)retMap.get("body");
       
        int count = 0;
        for (int idx = 0; idx < retList.size(); idx++) {           
            if ("0".equals(retList.get(idx).getZlevel())) {
                count++;
                retList.get(idx).setCount(count);
            }
        }
        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsReturn", paramVO);   

        return result;
    }
    

    /**
     * selectPromotionToNmgnExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPromotionToNmgnExcelDown.do")
    public NexacroResult selectPromotionToNmgnExcelDown(@ParamDataSet(name="dsInput") PromotionToNmgnVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        

        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());
        
        // 목록조회
        Map<String, Object> retMap = promotionToNmgnService.selectPromotionToNmgn(loginInfo, paramVO);
      
        @SuppressWarnings("unchecked")
        List<PromotionToNmgnVO> retList = (List<PromotionToNmgnVO>)retMap.get("body");
        
        int count = 0;
        for (int idx = 0; idx < retList.size(); idx++) {
            if ("0".equals(retList.get(idx).getZlevel())) {
                count++;
                retList.get(idx).setCount(count);
            }
        }
        
        result.addDataSet("dsOutput", retList);
     
        return result;
                     
    }
    
    
    /**
     * selectPromotionProfileOrderTypeList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPromotionProfileOrderTypeList.do")
    public NexacroResult selectPromotionProfileOrderTypeList(@ParamDataSet(name="dsInput") PromotionProfileOrderTypeVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<PromotionProfileOrderTypeVO> rtnLst = promotionToNmgnService.selectPromotionProfileOrderTypeList(loginInfo, paramVO);
        
        result.addDataSet("dsReturn", paramVO);
        result.addDataSet("dsOutput", rtnLst);

        return result;
    }
    
    /**
     * selectPromotionProfile
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */

    @RequestMapping(value = "/sd/selectPromotionProfile.do")
    public NexacroResult selectPromotionProfile(
            @ParamDataSet(name="dsInput") PromotionProfileVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<PromotionProfileVO> rtnLst = promotionToNmgnService.selectPromotionProfile(loginInfo, paramVO);
        
        result.addDataSet("dsReturn", paramVO);
        result.addDataSet("dsOutput", rtnLst);

        return result;
    }
}
