package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.OrderStatusItemService;
import com.mobis.maps.nmgn.sd.vo.OrderStatusItemVO;
import com.mobis.maps.nmgn.sd.vo.OrderStatusTotalVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderStatusItemServiceImpl.java
 * @Description : Order Status Item List
 * @author 홍민호
 * @since 2019. 12. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 24.     홍민호     	최초 생성
 * </pre>
 */

@Service("orderStatusItemService")
public class OrderStatusItemServiceImpl extends HService implements OrderStatusItemService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderStatusItemService#selectOrderStatusItem(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderStatusItemVO)
     */
    @Override
    public OrderStatusItemVO selectOrderStatusItem(LoginInfoVO loginVo, OrderStatusItemVO params)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER_ITEM_LIST;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<OrderStatusItemVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, OrderStatusItemVO.class);
        params.settResult(list);

        //*** Summary
        OrderStatusTotalVO esTotal = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_TOTAL", OrderStatusTotalVO.class);
        params.setEsTotal(esTotal);
        
        return params;
    }

}
