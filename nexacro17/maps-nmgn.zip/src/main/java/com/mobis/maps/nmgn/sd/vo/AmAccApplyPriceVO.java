package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AmAccApplyPriceVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 25.     jiyongdo     	최초 생성
 * </pre>
 */

public class AmAccApplyPriceVO extends MapsCommSapRfcIfCommVO {

    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_APPDT_FR" )
    private String iAppdtFr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_APPDT_TO" )
    private String iAppdtTo;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_APPFL" )
    private String iAppfl;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CONFL" )
    private String iConfl;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZKEY_VHC" )
    private String iZkeyVhc;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPROD_TYP" )
    private String iZprodTyp;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    //-----[T_RESULT] START-----
    /** Customer group 1 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /** Dist. Code */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name 1 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** Material Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /** Product Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPROD_TYP" )
    private String zprodTyp;
    /** Key Model Code */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZKEY_VHC" )
    private String zkeyVhc;
    /** Price List Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PLTYP" )
    private String pltyp;
    /** Currency Key */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="SPECIAL_PRICE" )
    private String specialPrice;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="INV_FOB_PRICE" )
    private String invFobPrice;
    /** Valid-From Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="DATAB" )
    private Date datab;
    /** Valid To Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="DATBI" )
    private Date datbi;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="APPFL" )
    private String appfl;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="CFDAT" )
    private Date cfdat;
    //-----[T_RESULT] END-----
    /**
     * @return the iAppdtFr
     */
    public String getiAppdtFr() {
        return iAppdtFr;
    }
    /**
     * @param iAppdtFr the iAppdtFr to set
     */
    public void setiAppdtFr(String iAppdtFr) {
        this.iAppdtFr = iAppdtFr;
    }
    /**
     * @return the iAppdtTo
     */
    public String getiAppdtTo() {
        return iAppdtTo;
    }
    /**
     * @param iAppdtTo the iAppdtTo to set
     */
    public void setiAppdtTo(String iAppdtTo) {
        this.iAppdtTo = iAppdtTo;
    }
    /**
     * @return the iAppfl
     */
    public String getiAppfl() {
        return iAppfl;
    }
    /**
     * @param iAppfl the iAppfl to set
     */
    public void setiAppfl(String iAppfl) {
        this.iAppfl = iAppfl;
    }
    /**
     * @return the iConfl
     */
    public String getiConfl() {
        return iConfl;
    }
    /**
     * @param iConfl the iConfl to set
     */
    public void setiConfl(String iConfl) {
        this.iConfl = iConfl;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iZkeyVhc
     */
    public String getiZkeyVhc() {
        return iZkeyVhc;
    }
    /**
     * @param iZkeyVhc the iZkeyVhc to set
     */
    public void setiZkeyVhc(String iZkeyVhc) {
        this.iZkeyVhc = iZkeyVhc;
    }
    /**
     * @return the iZprodTyp
     */
    public String getiZprodTyp() {
        return iZprodTyp;
    }
    /**
     * @param iZprodTyp the iZprodTyp to set
     */
    public void setiZprodTyp(String iZprodTyp) {
        this.iZprodTyp = iZprodTyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /** 
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the zprodTyp
     */
    public String getZprodTyp() {
        return zprodTyp;
    }
    /**
     * @param zprodTyp the zprodTyp to set
     */
    public void setZprodTyp(String zprodTyp) {
        this.zprodTyp = zprodTyp;
    }
    /**
     * @return the zkeyVhc
     */
    public String getZkeyVhc() {
        return zkeyVhc;
    }
    /**
     * @param zkeyVhc the zkeyVhc to set
     */
    public void setZkeyVhc(String zkeyVhc) {
        this.zkeyVhc = zkeyVhc;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the specialPrice
     */
    public String getSpecialPrice() {
        return specialPrice;
    }
    /**
     * @param specialPrice the specialPrice to set
     */
    public void setSpecialPrice(String specialPrice) {
        this.specialPrice = specialPrice;
    }
    /**
     * @return the invFobPrice
     */
    public String getInvFobPrice() {
        return invFobPrice;
    }
    /**
     * @param invFobPrice the invFobPrice to set
     */
    public void setInvFobPrice(String invFobPrice) {
        this.invFobPrice = invFobPrice;
    }
    /**
     * @return the datab
     */
    public Date getDatab() {
        return datab;
    }
    /**
     * @param datab the datab to set
     */
    public void setDatab(Date datab) {
        this.datab = datab;
    }
    /**
     * @return the datbi
     */
    public Date getDatbi() {
        return datbi;
    }
    /**
     * @param datbi the datbi to set
     */
    public void setDatbi(Date datbi) {
        this.datbi = datbi;
    }
    /**
     * @return the appfl
     */
    public String getAppfl() {
        return appfl;
    }
    /**
     * @param appfl the appfl to set
     */
    public void setAppfl(String appfl) {
        this.appfl = appfl;
    }
    /**
     * @return the cfdat
     */
    public Date getCfdat() {
        return cfdat;
    }
    /**
     * @param cfdat the cfdat to set
     */
    public void setCfdat(Date cfdat) {
        this.cfdat = cfdat;
    }
}
