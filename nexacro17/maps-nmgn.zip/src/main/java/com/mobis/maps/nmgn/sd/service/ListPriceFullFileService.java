package com.mobis.maps.nmgn.sd.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.ListPriceFullFileVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceFullFileService.java
 * @Description : ZJSDR20210 List Price Full 파일 생성 요청 및 Download
 * @author 이수지
 * @since 2020. 2. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 12.       이수지      	        최초 생성
 * </pre>
 */

public interface ListPriceFullFileService {

    /**
     * selectListPriceFullFile
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<ListPriceFullFileVO> selectListPriceFullFile (LoginInfoVO loginVo, ListPriceFullFileVO params) throws Exception;
    
    /**
     * selectCustomerInfo
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<ListPriceFullFileVO> selectCustomerInfo (LoginInfoVO loginVo, ListPriceFullFileVO params) throws Exception;
    
    /**
     * multiListPriceFullFile
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    public Map<String, Object> multiListPriceFullFile (LoginInfoVO loginVo, ListPriceFullFileVO params, List<ListPriceFullFileVO> paramList) throws Exception;
}
