package com.mobis.maps.nmgn.cc.web;

import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MgnCommController.java
 * @Description : MGN Common
 * @author hong.minho
 * @since 2020. 7. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 16.     hong.minho     	최초 생성
 * </pre>
 */

@Controller
public class MgnCommController extends HController {

    
    /**
     * Demo Message
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/comm/selectDemoMsg.do")
    public String selectDemoMsg( HttpServletRequest request, HttpServletResponse response) {
        return "comm/demoMsg";
    }



    /**
     * Video Guide
     *
     * @param gurl
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/main/selectVideoGuide.do", method = {RequestMethod.GET, RequestMethod.POST})
    public String selectVideoGuide(
              @RequestParam(value="gurl", required=false, defaultValue="") String gurl
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        request.setAttribute("gurl", URLDecoder.decode(gurl, "utf8"));
        
        return "comm/videoGuide";
    }





}
