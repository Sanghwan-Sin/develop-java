package com.mobis.maps.nmgn.ti.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.vo.SupersessionDetailVO;
import com.mobis.maps.nmgn.ti.vo.SupersessionHistoryVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SupersessionHistoryService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 5. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 19.     jiyongdo     	최초 생성
 * </pre>
 */

public interface SupersessionHistoryService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<SupersessionHistoryVO> selectSupersessionHistoryList(LoginInfoVO loginInfo, SupersessionHistoryVO params) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<SupersessionHistoryVO> selectRegionList(LoginInfoVO loginInfo, SupersessionHistoryVO params) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<SupersessionHistoryVO> selectModelList(LoginInfoVO loginInfo, SupersessionHistoryVO params) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    Map<String, Object> selectSupersessionDetailList(LoginInfoVO loginInfo, SupersessionDetailVO params) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    Map<String, Object> selectSupersessionDetailListExcelDown(LoginInfoVO loginInfo, SupersessionDetailVO params) throws Exception;


}
