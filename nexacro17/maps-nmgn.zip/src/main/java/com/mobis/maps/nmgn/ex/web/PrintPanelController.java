package com.mobis.maps.nmgn.ex.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.service.PrintPanelService;
import com.mobis.maps.nmgn.ex.vo.PrintPanelVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PrintPanelController.java
 * @Description : ZPEXF00290 Print Panel
 * @author 이수지
 * @since 2020. 06.03 
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06.03       이수지                최초 생성
 * </pre>
 */

@Controller
public class PrintPanelController extends HController {

    @Resource(name = "printPanelService")
    private PrintPanelService printPanelService;

    /**
     * selectShippingAdviceImageFile
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectShippingAdviceImageFile.do")
    public NexacroResult selectShippingAdviceImageFile(@ParamDataSet(name="dsInput") PrintPanelVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PrintPanelVO> list  = printPanelService.selectShippingAdviceImageFile(loginInfo, params);

        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectPrintPanel
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectPrintPanel.do")
    public NexacroResult selectPrintPanel(@ParamDataSet(name="dsInput") PrintPanelVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);      

        Map<String, Object> retMap = printPanelService.selectPrintPanel(loginInfo, params);
        
        @SuppressWarnings("unchecked")
        List<PrintPanelVO> retList1 = (List<PrintPanelVO>)retMap.get("table1");
        @SuppressWarnings("unchecked")
        List<PrintPanelVO> retList2 = (List<PrintPanelVO>)retMap.get("table2");
        @SuppressWarnings("unchecked")
        List<PrintPanelVO> retList3 = (List<PrintPanelVO>)retMap.get("table3");
        @SuppressWarnings("unchecked")
        List<PrintPanelVO> retVo = (List<PrintPanelVO>)retMap.get("table4");
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput1", retList1);
        result.addDataSet("dsOutput2", retList2);
        result.addDataSet("dsOutput3", retList3);
        result.addDataSet("dsOutput4", retVo);
        
        return result;
    }
  
}
