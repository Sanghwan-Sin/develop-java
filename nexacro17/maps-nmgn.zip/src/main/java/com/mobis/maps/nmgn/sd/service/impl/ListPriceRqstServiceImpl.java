package com.mobis.maps.nmgn.sd.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.cc.vo.NewsLetterVO;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.ListPriceRqstService;
import com.mobis.maps.nmgn.sd.vo.ListPriceRqstVO;
import com.mobis.maps.nmgn.sd.vo.PartInfoVO;
import com.mobis.maps.nmgn.sd.vo.PriceRqstDetailVO;
import com.mobis.maps.nmgn.sd.vo.RqstNoVO;
import com.mobis.maps.nmgn.sd.vo.ZsacutmVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmpListPriceRqstServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 9. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 26.     Jiyongdo       최초 생성
 * </pre>
 */
@Service("mapsSmpListPriceRqstService")
public class ListPriceRqstServiceImpl extends HService implements ListPriceRqstService{

    @Resource(name = "mapsCmmnSapService")  
    private MapsCommSapService mapsCmmnSapService;
    
    @Resource(name="mapsCommFileService")
    private MapsCommFileService mapsCommFileService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceRqstService#rfcSelectPriceRequestList(com.mobis.maps.nmgn.sd.vo.ListPriceRqstVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<ListPriceRqstVO> selectPriceRequestList(ListPriceRqstVO paramVO, LoginInfoVO loginInfo) throws Exception {

        //Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_PRICING_REQ;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        JCoStructure isReqNo = func.getImportParameterList().getStructure("IS_REQNO");
        isReqNo.setValue("SIGN", paramVO.getIsReqNoSign());    
        isReqNo.setValue("OPTION", paramVO.getIsReqNoOption());    
        isReqNo.setValue("LOW", paramVO.getIsReqNoLow());    
        isReqNo.setValue("HIGH", paramVO.getIsReqNoHigh());   
        
        JCoStructure isReqDt = func.getImportParameterList().getStructure("IS_REQDT");
        isReqDt.setValue("SIGN", paramVO.getIsReqDtsign());    
        isReqDt.setValue("OPTION", paramVO.getIsReqDtOption());    
        isReqDt.setValue("LOW", paramVO.getIsReqDtLow());    
        isReqDt.setValue("HIGH", paramVO.getIsReqDtHigh()); 

        JCoStructure isMatnr = func.getImportParameterList().getStructure("IS_MATNR");
        isMatnr.setValue("SIGN", paramVO.getIsMatnrSign());    
        isMatnr.setValue("OPTION", paramVO.getIsMatnrOption());    
        isMatnr.setValue("LOW", paramVO.getIsMatnrLow());    
        isMatnr.setValue("HIGH", paramVO.getIsMatnrHigh());          
        
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<ListPriceRqstVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, ListPriceRqstVO.class);
        
        for(int i = 0; i < odrLst.size(); i++)
        {
            odrLst.get(i).setRnum(odrLst.get(i).getRnum()+1);
        }
        //retMap.put("body", odrLst);       
        
        return odrLst;            
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceRqstService#selectZsacutm(com.mobis.maps.nmgn.sd.vo.ListPriceRqstVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<ZsacutmVO> selectZsacutm(ZsacutmVO paramVO, LoginInfoVO loginInfo) throws Exception {
        
        //Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_CUSTOMER_INFO;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<ZsacutmVO> odrLst = MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_RESULT", ZsacutmVO.class);
        
        //retMap.put("body", odrLst);       
        
        return odrLst;            
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmpListPriceRqstService#selectMaktx(com.mobis.maps.smpl.vo.MapsSmplPriceRqstVO)
     */
    @Override
    public List<PartInfoVO> selectMaktx(PartInfoVO paramVO, LoginInfoVO loginInfo) throws Exception {

        //Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_PART_INFO;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<PartInfoVO> odrLst = MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_RESULT", PartInfoVO.class);
        
        //retMap.put("body", odrLst);       
        
        return odrLst;  
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceRqstService#selectReqNo(com.mobis.maps.nmgn.sd.vo.ListPriceRqstVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<RqstNoVO> selectReqNo(RqstNoVO paramVO, LoginInfoVO loginInfo) throws Exception {

        //Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_GET_PRC_REQNO;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<RqstNoVO> odrLst = MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_RESULT", RqstNoVO.class);
        
        //retMap.put("body", odrLst);       
        
        return odrLst;  
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceRqstService#multiListPriceRequest(com.mobis.maps.nmgn.sd.vo.ListPriceRqstVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, Object> multiListPriceRequest(ListPriceRqstVO paramVO, List<ListPriceRqstVO> paramList, LoginInfoVO loginInfo) throws Exception {
        
        Map<String, Object> retMap = new HashMap<String, Object>();
        
        if (paramList == null) {
            if (logger.isDebugEnabled()) {logger.debug("##### paramList is Null.");}
            return null;
        }
        
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_PRICING_REQ;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        // 파라미터(Import) 셋팅
        func.getImportParameterList().setValue("I_TYPE", "C");   
        
        // 파라미터(TABLES) 적재
        for (ListPriceRqstVO tmpVO : paramList) {
            if (tmpVO == null) continue;
            
            if (tmpVO.getRowSe() == null || "N".equals(tmpVO.getRowSe())) {
                continue;
            }
            
            if (!"Y".equals(tmpVO.getChkYn())) {
                continue;
            }
            
            switch (tmpVO.getRowSe()) {
                case "I":
                    tmpVO.setType("C");
                    break;
                case "U":
                    tmpVO.setType("U");
                    break;
                case "D":
                    tmpVO.setType("D");
                    break;
                default:
                    break;
            }
            tmpVO.setZsacutm(paramVO.getiZsacutm());
            MapsRfcMappperUtil.appendImportTableRow(func, "T_RESULT", tmpVO);

        }      
        
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        // 개별데이타 추출
        //List<ExchangePurchaseDetailVO> odrLst =  MapsRfcMappperUtil.getExportTableResultValues(funcRslt, "IT_DATA", ExchangePurchaseDetailVO.class);
        List<ListPriceRqstVO> retList =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_RESULT", ListPriceRqstVO.class);
        retMap.put("body", retList);
        
        return retMap;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceRqstService#selectPriceRequestDetailList(com.mobis.maps.nmgn.sd.vo.ListPriceRqstVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<PriceRqstDetailVO> selectPriceRequestDetailList(PriceRqstDetailVO paramVO, LoginInfoVO loginInfo) throws Exception {
        
        //Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_PRICE_COMP_INFO;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        // 파라미터(Import) 셋팅
        func.getImportParameterList().setValue("I_TYPE", "R");
        func.getImportParameterList().setValue("I_REQNO", paramVO.getiReqno());    
        func.getImportParameterList().setValue("I_SEQNO", paramVO.getiSeqno());   
        
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<PriceRqstDetailVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, PriceRqstDetailVO.class);
        
        
        for(int i = 0; i < odrLst.size(); i++)
        {
            odrLst.get(i).setRnum(odrLst.get(i).getRnum()+1);
        }        
        //retMap.put("body", odrLst);       
        
        return odrLst;  
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceRqstService#multiPriceRequestDetail(com.mobis.maps.nmgn.sd.vo.ListPriceRqstVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, Object> multiPriceRequestDetail(PriceRqstDetailVO paramVO, List<PriceRqstDetailVO> paramList, LoginInfoVO loginInfo) throws Exception {
        
        Map<String, Object>    retMap  = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_PRICE_COMP_INFO;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        // 파라미터(Import) 셋팅
        func.getImportParameterList().setValue("I_TYPE", "C");   
        
        // 파라미터(TABLES) 적재
        for (PriceRqstDetailVO tmpVO : paramList) {
            if (!"N".equals(tmpVO.getRowSe()) && "Y".equals(tmpVO.getChkYn())) {
                switch (tmpVO.getRowSe()) {
                    case "I":
                        tmpVO.setType("C");
                        break;
                    case "U":
                        tmpVO.setType("U");
                        break;
                    case "D":
                        tmpVO.setType("D");
                        break;
                    default:
                        break;
                }
                MapsRfcMappperUtil.appendImportTableRow(func, "T_RESULT", tmpVO);
            }
        }   
        
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        // 개별데이타 추출
        //List<ExchangePurchaseDetailVO> odrLst =  MapsRfcMappperUtil.getExportTableResultValues(funcRslt, "IT_DATA", ExchangePurchaseDetailVO.class);
        List<PriceRqstDetailVO> retList =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_RESULT", PriceRqstDetailVO.class);
        retMap.put("body", retList);
        
        return retMap;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceRqstService#multiAtchFile(com.mobis.maps.nmgn.cc.vo.NewsLetterVO, java.util.List)
     */
    @Override
    public int multiAtchFile(NewsLetterVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception {
        int retCnt = 0;
        
        if (atchFiles != null && atchFiles.size() > 0) {
            AtchFileSe atchFileGubn = AtchFileSe.get(atchFileVO.getAtchSe()); 
            retCnt = mapsCommFileService.multiAtchFile(atchFileGubn, atchFileVO, atchFiles);    
        }
        return retCnt;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceRqstService#selectMaktxMulti(com.mobis.maps.nmgn.sd.vo.PartInfoVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<ListPriceRqstVO> selectMaktxMulti(PartInfoVO paramVO, List<ListPriceRqstVO> paramList, LoginInfoVO loginInfo) throws Exception {
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_PART_INFO;
        
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        
        for(int idx = 0; idx < paramList.size(); idx++){
            ListPriceRqstVO vo = paramList.get(idx);
            List<PartInfoVO> partVoList = new ArrayList<PartInfoVO>();
            ListPriceRqstVO partVo = new ListPriceRqstVO();  
            
            if("S".equals(paramList.get(idx).getChkRsltCd())){
                continue;
            }
            
            JCoTable clearTable = func.getImportTableParameter("T_RESULT");
            if(clearTable != null){
                clearTable.clear();
            }
            // 파라미터(Import) 셋팅
            func.getImportParameterList().setValue("I_MATNR", paramList.get(idx).getMatnr());
            func.getImportParameterList().setValue("I_ZSACUTM", paramVO.getiZsacutm());
            FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
            
            mapsCmmnSapService.selectSetRfcResult(funcRslt, partVo);
            /* RFC 호출 조회정보 추출 */
            partVoList = MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_RESULT", PartInfoVO.class);
            if("S".equals(partVo.getMsgType())){
                vo.setChkRsltCd("S");
                vo.setMaktx(partVoList.get(0).getMaktx());
                vo.setZveh(partVoList.get(0).getZkeyCar());
                vo.setZpnc(partVoList.get(0).getZpnc());
                vo.setZsuc(partVoList.get(0).getZsuccd());
                vo.setSpart(partVoList.get(0).getSpart());
                vo.setPltyp(partVoList.get(0).getPltyp());
                vo.setWaers(partVoList.get(0).getKonwa());
                vo.setReqListPrice(partVoList.get(0).getKbetr());
                vo.setReqty("A5");
                vo.setChkRslt("");
                if(StringUtils.isBlank(partVoList.get(0).getKbetr())){
                    vo.setReqty("P1");
                }else{
                    vo.setChkRsltCd("F");
                    vo.setChkYn("N");
                    vo.setChkRslt(MessageUtil.getMessage("WMM0000010", new String[]{}, loginInfo.getUserLcale()));                    
                }
            }else{
                vo.setChkRsltCd("F");
                vo.setMaktx("");
                vo.setZveh("");
                vo.setZpnc("");
                vo.setZsuc("");
                vo.setSpart("");
                vo.setPltyp("");
                vo.setWaers("");
                vo.setReqListPrice("");
                vo.setReqty("");
                vo.setChkYn("N");
                vo.setChkRslt(MessageUtil.getMessage("WM00000004", new String[]{}, loginInfo.getUserLcale()));
            }
        }             
        return paramList;  
    }
}
