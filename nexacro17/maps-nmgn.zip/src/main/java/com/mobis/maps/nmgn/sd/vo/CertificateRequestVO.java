package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CertificateRequestVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 9. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 9. 4.     jiyongdo     	최초 생성
 * </pre>
 */

public class CertificateRequestVO  extends MapsCommSapRfcIfCommVO {
    
    // Certification Doc Start
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCERTI_CD" )
    private String iZcertiCd;
    //-----[T_DATA] START-----
    /** Client */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MANDT" )
    private String mandt;
    /** Company Code */
    @MapsRfcMappper( targetName="IS_HEAD|T_DATA|ES_HEAD", ipttSe="I|E", fieldKey="BUKRS" )
    private String bukrs;
    /**  */
    @MapsRfcMappper( targetName="IS_HEAD|T_DATA|ES_HEAD", ipttSe="I|E", fieldKey="ZCERTI_CD" )
    private String zcertiCd;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DOC", ipttSe="I|E", fieldKey="ZDOC_CD" )
    private String zdocCd;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZDOC_NAME" )
    private String zdocName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZNUCHECK" )
    private String znucheck;
    /** Checkbox */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZUSEYN" )
    private String zuseyn;
    //-----[T_DATA] END-----
    // Certification Doc End

    // Certification Save Start
    //-----[IS_HEAD] START-----
    /**  */
    private String zkunam;
    
    @MapsRfcMappper( targetName="IS_HEAD|ES_HEAD", ipttSe="I|E", fieldKey="REQDT" )
    private Date reqdt;
    /** Dist. Code */
    @MapsRfcMappper( targetName="IS_HEAD|ES_HEAD", ipttSe="I|E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** E-Mail Address */
    @MapsRfcMappper( targetName="IS_HEAD|ES_HEAD", ipttSe="I|E", fieldKey="SMTP_ADDR" )
    private String smtpAddr;
    /**  */
    @MapsRfcMappper( targetName="IS_HEAD|ES_HEAD", ipttSe="I|E", fieldKey="REQ_TYPE" )
    private String reqType;
    /**  */
    @MapsRfcMappper( targetName="IS_HEAD|ES_HEAD", ipttSe="I|E", fieldKey="STATUS" )
    private String status;
    /**  */
    @MapsRfcMappper( targetName="IS_HEAD|ES_HEAD", ipttSe="I|E", fieldKey="REQ_NO" )
    private String reqNo;
    //-----[IS_HEAD] END-----
    /** undefined */
    private String eReqno;
    //-----[T_DOC] START-----
    /**  */
    @MapsRfcMappper( targetName="T_DOC", ipttSe="I|E", fieldKey="ZREMARK" )
    private String zremark;
    //-----[T_DOC] END-----
    //-----[T_PART] START-----
    /** Material Number */
    @MapsRfcMappper( targetName="T_PART", ipttSe="I|E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="T_PART", ipttSe="I|E", fieldKey="ZPTNM" )
    private String zptnm;
    //-----[T_PART] END-----
    // Certification Save End
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZPTNM" )
    private String eZptnm;    
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQ_NO" )
    private String iReqNo;
    private String chkRslt;
    private String chkCd;
    private String message;
  
    
    /**
     * @return the iZcertiCd
     */
    public String getiZcertiCd() {
        return iZcertiCd;
    }
    /**
     * @param iZcertiCd the iZcertiCd to set
     */
    public void setiZcertiCd(String iZcertiCd) {
        this.iZcertiCd = iZcertiCd;
    }
    /**
     * @return the mandt
     */
    public String getMandt() {
        return mandt;
    }
    /**
     * @param mandt the mandt to set
     */
    public void setMandt(String mandt) {
        this.mandt = mandt;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the zcertiCd
     */
    public String getZcertiCd() {
        return zcertiCd;
    }
    /**
     * @param zcertiCd the zcertiCd to set
     */
    public void setZcertiCd(String zcertiCd) {
        this.zcertiCd = zcertiCd;
    }
    /**
     * @return the zdocCd
     */
    public String getZdocCd() {
        return zdocCd;
    }
    /**
     * @param zdocCd the zdocCd to set
     */
    public void setZdocCd(String zdocCd) {
        this.zdocCd = zdocCd;
    }
    /**
     * @return the zdocName
     */
    public String getZdocName() {
        return zdocName;
    }
    /**
     * @param zdocName the zdocName to set
     */
    public void setZdocName(String zdocName) {
        this.zdocName = zdocName;
    }
    /**
     * @return the znucheck
     */
    public String getZnucheck() {
        return znucheck;
    }
    /**
     * @param znucheck the znucheck to set
     */
    public void setZnucheck(String znucheck) {
        this.znucheck = znucheck;
    }
    /**
     * @return the zuseyn
     */
    public String getZuseyn() {
        return zuseyn;
    }
    /**
     * @param zuseyn the zuseyn to set
     */
    public void setZuseyn(String zuseyn) {
        this.zuseyn = zuseyn;
    }
    /**
     * @return the reqdt
     */
    public Date getReqdt() {
        return reqdt;
    }
    /**
     * @param reqdt the reqdt to set
     */
    public void setReqdt(Date reqdt) {
        this.reqdt = reqdt;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the smtpAddr
     */
    public String getSmtpAddr() {
        return smtpAddr;
    }
    /**
     * @param smtpAddr the smtpAddr to set
     */
    public void setSmtpAddr(String smtpAddr) {
        this.smtpAddr = smtpAddr;
    }
    /**
     * @return the reqType
     */
    public String getReqType() {
        return reqType;
    }
    /**
     * @param reqType the reqType to set
     */
    public void setReqType(String reqType) {
        this.reqType = reqType;
    }
    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }
    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    /**
     * @return the reqNo
     */
    public String getReqNo() {
        return reqNo;
    }
    /**
     * @param reqNo the reqNo to set
     */
    public void setReqNo(String reqNo) {
        this.reqNo = reqNo;
    }
    /**
     * @return the eReqno
     */
    public String geteReqno() {
        return eReqno;
    }
    /**
     * @param eReqno the eReqno to set
     */
    public void seteReqno(String eReqno) {
        this.eReqno = eReqno;
    }
    /**
     * @return the zremark
     */
    public String getZremark() {
        return zremark;
    }
    /**
     * @param zremark the zremark to set
     */
    public void setZremark(String zremark) {
        this.zremark = zremark;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the eZptnm
     */
    public String geteZptnm() {
        return eZptnm;
    }
    /**
     * @param eZptnm the eZptnm to set
     */
    public void seteZptnm(String eZptnm) {
        this.eZptnm = eZptnm;
    }
    /**
     * @return the iReqNo
     */
    public String getiReqNo() {
        return iReqNo;
    }
    /**
     * @param iReqNo the iReqNo to set
     */
    public void setiReqNo(String iReqNo) {
        this.iReqNo = iReqNo;
    }
    /**
     * @return the chkRslt
     */
    public String getChkRslt() {
        return chkRslt;
    }
    /**
     * @param chkRslt the chkRslt to set
     */
    public void setChkRslt(String chkRslt) {
        this.chkRslt = chkRslt;
    }
    /**
     * @return the chkCd
     */
    public String getChkCd() {
        return chkCd;
    }
    /**
     * @param chkCd the chkCd to set
     */
    public void setChkCd(String chkCd) {
        this.chkCd = chkCd;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the zkunam
     */
    public String getZkunam() {
        return zkunam;
    }
    /**
     * @param zkunam the zkunam to set
     */
    public void setZkunam(String zkunam) {
        this.zkunam = zkunam;
    }
}
