package com.mobis.maps.nmgn.qm.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimInvoiceListVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 3. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 10.     jiyongdo     	최초 생성
 * </pre>
 */

public class ClaimInvoiceListVO extends MapsCommSapRfcIfCommVO{
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_AUDAT_FROM" )
    private Date iAudatFrom;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_AUDAT_TO" )
    private Date iAudatTo;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDIST" )
    private String iZdist;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFCARTNO" )
    private String iZfcartno;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFCIVNO" )
    private String iZfcivno;
    /** undefined */
    //-----[T_DATA] START-----
    /** Material Number */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="AKTX" )
    private String aktx;
    /** Invoice No. */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZFDONO" )
    private String zfdono;
    /** Carton Box Number */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZFCARTNO" )
    private String zfcartno;
    /** Invoice Date */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZFCIVDT" )
    private Date zfcivdt;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="KWMENG" )
    private String kwmeng;
    /** Sales unit */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="VRKME" )
    private String vrkme;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="NETPR" )
    private String netpr;
    /** Currency Key */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZFSHPMD" )
    private String zfshpmd;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="AUDAT" )
    private Date audat;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /** On Board Date */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZFOBDT" )
    private Date zfobdt;
    //-----[T_DATA] END-----
    /**
     * @return the iAudatFrom
     */
    public Date getiAudatFrom() {
        return iAudatFrom;
    }
    /**
     * @param iAudatFrom the iAudatFrom to set
     */
    public void setiAudatFrom(Date iAudatFrom) {
        this.iAudatFrom = iAudatFrom;
    }
    /**
     * @return the iAudatTo
     */
    public Date getiAudatTo() {
        return iAudatTo;
    }
    /**
     * @param iAudatTo the iAudatTo to set
     */
    public void setiAudatTo(Date iAudatTo) {
        this.iAudatTo = iAudatTo;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iZdist
     */
    public String getiZdist() {
        return iZdist;
    }
    /**
     * @param iZdist the iZdist to set
     */
    public void setiZdist(String iZdist) {
        this.iZdist = iZdist;
    }
    /**
     * @return the iZfcartno
     */
    public String getiZfcartno() {
        return iZfcartno;
    }
    /**
     * @param iZfcartno the iZfcartno to set
     */
    public void setiZfcartno(String iZfcartno) {
        this.iZfcartno = iZfcartno;
    }
    /**
     * @return the iZfcivno
     */
    public String getiZfcivno() {
        return iZfcivno;
    }
    /**
     * @param iZfcivno the iZfcivno to set
     */
    public void setiZfcivno(String iZfcivno) {
        this.iZfcivno = iZfcivno;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the aktx
     */
    public String getAktx() {
        return aktx;
    }
    /**
     * @param aktx the aktx to set
     */
    public void setAktx(String aktx) {
        this.aktx = aktx;
    }
    /**
     * @return the zfdono
     */
    public String getZfdono() {
        return zfdono;
    }
    /**
     * @param zfdono the zfdono to set
     */
    public void setZfdono(String zfdono) {
        this.zfdono = zfdono;
    }
    /**
     * @return the zfcartno
     */
    public String getZfcartno() {
        return zfcartno;
    }
    /**
     * @param zfcartno the zfcartno to set
     */
    public void setZfcartno(String zfcartno) {
        this.zfcartno = zfcartno;
    }
    /**
     * @return the zfcivdt
     */
    public Date getZfcivdt() {
        return zfcivdt;
    }
    /**
     * @param zfcivdt the zfcivdt to set
     */
    public void setZfcivdt(Date zfcivdt) {
        this.zfcivdt = zfcivdt;
    }
    /**
     * @return the kwmeng
     */
    public String getKwmeng() {
        return kwmeng;
    }
    /**
     * @param kwmeng the kwmeng to set
     */
    public void setKwmeng(String kwmeng) {
        this.kwmeng = kwmeng;
    }
    /**
     * @return the vrkme
     */
    public String getVrkme() {
        return vrkme;
    }
    /**
     * @param vrkme the vrkme to set
     */
    public void setVrkme(String vrkme) {
        this.vrkme = vrkme;
    }
    /**
     * @return the netpr
     */
    public String getNetpr() {
        return netpr;
    }
    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(String netpr) {
        this.netpr = netpr;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the zfshpmd
     */
    public String getZfshpmd() {
        return zfshpmd;
    }
    /**
     * @param zfshpmd the zfshpmd to set
     */
    public void setZfshpmd(String zfshpmd) {
        this.zfshpmd = zfshpmd;
    }
    /**
     * @return the audat
     */
    public Date getAudat() {
        return audat;
    }
    /**
     * @param audat the audat to set
     */
    public void setAudat(Date audat) {
        this.audat = audat;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zfobdt
     */
    public Date getZfobdt() {
        return zfobdt;
    }
    /**
     * @param zfobdt the zfobdt to set
     */
    public void setZfobdt(Date zfobdt) {
        this.zfobdt = zfobdt;
    }
}
