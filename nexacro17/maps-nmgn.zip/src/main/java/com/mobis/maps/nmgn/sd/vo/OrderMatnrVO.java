package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderMatnrVO.java
 * @Description : ZPSD_ORDER_MATNR - Order 자제정보 추출 
 * @author 홍민호
 * @since 2020. 2. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 27.     홍민호     	최초 생성
 * </pre>
 */

public class OrderMatnrVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** undefined */
    private List<?> itMatnr;
    
//    -----[IT_MATNR] START-----
    /** Plant */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="I|E", fieldKey="WERKS|WERKS" )
    private String werks;
    /** Material Number */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="I|E", fieldKey="MATNR|MATNR" )
    private String matnr;
    /** Division */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="I|E", fieldKey="SPART|SPART" )
    private String spart;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZPROD_TYP" )
    private String zprodTyp;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZPTNM_NTV" )
    private String zptnmNtv;
    /** Material belonging to the customer */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="KDMAT" )
    private String kdmat;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="I|E", fieldKey="ZHKCD|ZHKCD" )
    private String zhkcd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZEDCD" )
    private String zedcd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSRC_CD" )
    private String zsrcCd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSRC_CD_NM" )
    private String zsrcCdNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSRC_TYP" )
    private String zsrcTyp;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSRC_TYP_NM" )
    private String zsrcTypNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZDETCD" )
    private String zdetcd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZDETCD_NM" )
    private String zdetcdNm;
    /** Key Model Code */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZKEY_VHC" )
    private String zkeyVhc;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZVHCNM" )
    private String zvhcnm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSALES_CLASS" )
    private String zsalesClass;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSALES_CLASS_NM" )
    private String zsalesClassNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZMAIN_FUC" )
    private String zmainFuc;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZMAIN_FUC_NM" )
    private String zmainFucNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSUB_FUC" )
    private String zsubFuc;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSUB_FUC_NM" )
    private String zsubFucNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZUSG_QTY" )
    private BigDecimal zusgQty;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="MEINS" )
    private String meins;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZQUP" )
    private BigDecimal zqup;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZQFP" )
    private BigDecimal zqfp;
    /** HQ SUC */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSUCCD" )
    private String zsuccd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZSUCCD_NM" )
    private String zsuccdNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZVNDCD" )
    private String zvndcd;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZWUNIT" )
    private String zwunit;
    /** Net weight */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZWEIG" )
    private BigDecimal zweig;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZVUNIT" )
    private String zvunit;
    /** Net volume */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZVOL" )
    private BigDecimal zvol;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZMSQ" )
    private BigDecimal zmsq;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZCHRR_CD" )
    private String zchrrCd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZCHRR_CD_NM" )
    private String zchrrCdNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZPNC" )
    private String zpnc;
    /** Vehicle Type */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZVEH_TYP" )
    private String zvehTyp;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZVEH_TYP_NM" )
    private String zvehTypNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZPREM_MDL" )
    private String zpremMdl;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZPREM_MDL_NM" )
    private String zpremMdlNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZDC_FLG" )
    private String zdcFlg;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG1" )
    private String zleg1;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG1_NM" )
    private String zleg1Nm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG2" )
    private String zleg2;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG2_NM" )
    private String zleg2Nm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG3" )
    private String zleg3;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG3_NM" )
    private String zleg3Nm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG4" )
    private String zleg4;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG4_NM" )
    private String zleg4Nm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG5" )
    private String zleg5;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZLEG5_NM" )
    private String zleg5Nm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZMGT_CD" )
    private String zmgtCd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZTRANS_CTLCD" )
    private String ztransCtlcd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZTRANS_CTLCD_NM" )
    private String ztransCtlcdNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZPKU" )
    private BigDecimal zpku;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZORD_CTLCD" )
    private String zordCtlcd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZORD_CTLCD_NM" )
    private String zordCtlcdNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZWDMD_CTLCD" )
    private String zwdmdCtlcd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZWDMD_CTLCD_NM" )
    private String zwdmdCtlcdNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZWSALE_CTLCD" )
    private String zwsaleCtlcd;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZWSALE_CTLCD_NM" )
    private String zwsaleCtlcdNm;
    /** MRP Controller */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZCON_PER" )
    private String zconPer;
    /** Name of MRP controller */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="DSNAM" )
    private String dsnam;
    /** Material Price Group */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="KONDM" )
    private String kondm;
    /** Description */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="KONDM_NM" )
    private String kondmNm;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZCERT_APPL" )
    private String zcertAppl;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZCERT_YN" )
    private String zcertYn;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZGRS_WG" )
    private BigDecimal zgrsWg;
    /**  */
    @MapsRfcMappper( targetName="IT_MATNR", ipttSe="E", fieldKey="ZWHSCD" )
    private String zwhscd;
//    -----[IT_MATNR] END-----
    
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the itMatnr
     */
    public List<?> getItMatnr() {
        return itMatnr;
    }
    /**
     * @param itMatnr the itMatnr to set
     */
    public void setItMatnr(List<?> itMatnr) {
        this.itMatnr = itMatnr;
    }
    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }
    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the spart
     */
    public String getSpart() {
        return spart;
    }
    /**
     * @param spart the spart to set
     */
    public void setSpart(String spart) {
        this.spart = spart;
    }
    /**
     * @return the zprodTyp
     */
    public String getZprodTyp() {
        return zprodTyp;
    }
    /**
     * @param zprodTyp the zprodTyp to set
     */
    public void setZprodTyp(String zprodTyp) {
        this.zprodTyp = zprodTyp;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the zptnmNtv
     */
    public String getZptnmNtv() {
        return zptnmNtv;
    }
    /**
     * @param zptnmNtv the zptnmNtv to set
     */
    public void setZptnmNtv(String zptnmNtv) {
        this.zptnmNtv = zptnmNtv;
    }
    /**
     * @return the kdmat
     */
    public String getKdmat() {
        return kdmat;
    }
    /**
     * @param kdmat the kdmat to set
     */
    public void setKdmat(String kdmat) {
        this.kdmat = kdmat;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zedcd
     */
    public String getZedcd() {
        return zedcd;
    }
    /**
     * @param zedcd the zedcd to set
     */
    public void setZedcd(String zedcd) {
        this.zedcd = zedcd;
    }
    /**
     * @return the zsrcCd
     */
    public String getZsrcCd() {
        return zsrcCd;
    }
    /**
     * @param zsrcCd the zsrcCd to set
     */
    public void setZsrcCd(String zsrcCd) {
        this.zsrcCd = zsrcCd;
    }
    /**
     * @return the zsrcCdNm
     */
    public String getZsrcCdNm() {
        return zsrcCdNm;
    }
    /**
     * @param zsrcCdNm the zsrcCdNm to set
     */
    public void setZsrcCdNm(String zsrcCdNm) {
        this.zsrcCdNm = zsrcCdNm;
    }
    /**
     * @return the zsrcTyp
     */
    public String getZsrcTyp() {
        return zsrcTyp;
    }
    /**
     * @param zsrcTyp the zsrcTyp to set
     */
    public void setZsrcTyp(String zsrcTyp) {
        this.zsrcTyp = zsrcTyp;
    }
    /**
     * @return the zsrcTypNm
     */
    public String getZsrcTypNm() {
        return zsrcTypNm;
    }
    /**
     * @param zsrcTypNm the zsrcTypNm to set
     */
    public void setZsrcTypNm(String zsrcTypNm) {
        this.zsrcTypNm = zsrcTypNm;
    }
    /**
     * @return the zdetcd
     */
    public String getZdetcd() {
        return zdetcd;
    }
    /**
     * @param zdetcd the zdetcd to set
     */
    public void setZdetcd(String zdetcd) {
        this.zdetcd = zdetcd;
    }
    /**
     * @return the zdetcdNm
     */
    public String getZdetcdNm() {
        return zdetcdNm;
    }
    /**
     * @param zdetcdNm the zdetcdNm to set
     */
    public void setZdetcdNm(String zdetcdNm) {
        this.zdetcdNm = zdetcdNm;
    }
    /**
     * @return the zkeyVhc
     */
    public String getZkeyVhc() {
        return zkeyVhc;
    }
    /**
     * @param zkeyVhc the zkeyVhc to set
     */
    public void setZkeyVhc(String zkeyVhc) {
        this.zkeyVhc = zkeyVhc;
    }
    /**
     * @return the zvhcnm
     */
    public String getZvhcnm() {
        return zvhcnm;
    }
    /**
     * @param zvhcnm the zvhcnm to set
     */
    public void setZvhcnm(String zvhcnm) {
        this.zvhcnm = zvhcnm;
    }
    /**
     * @return the zsalesClass
     */
    public String getZsalesClass() {
        return zsalesClass;
    }
    /**
     * @param zsalesClass the zsalesClass to set
     */
    public void setZsalesClass(String zsalesClass) {
        this.zsalesClass = zsalesClass;
    }
    /**
     * @return the zsalesClassNm
     */
    public String getZsalesClassNm() {
        return zsalesClassNm;
    }
    /**
     * @param zsalesClassNm the zsalesClassNm to set
     */
    public void setZsalesClassNm(String zsalesClassNm) {
        this.zsalesClassNm = zsalesClassNm;
    }
    /**
     * @return the zmainFuc
     */
    public String getZmainFuc() {
        return zmainFuc;
    }
    /**
     * @param zmainFuc the zmainFuc to set
     */
    public void setZmainFuc(String zmainFuc) {
        this.zmainFuc = zmainFuc;
    }
    /**
     * @return the zmainFucNm
     */
    public String getZmainFucNm() {
        return zmainFucNm;
    }
    /**
     * @param zmainFucNm the zmainFucNm to set
     */
    public void setZmainFucNm(String zmainFucNm) {
        this.zmainFucNm = zmainFucNm;
    }
    /**
     * @return the zsubFuc
     */
    public String getZsubFuc() {
        return zsubFuc;
    }
    /**
     * @param zsubFuc the zsubFuc to set
     */
    public void setZsubFuc(String zsubFuc) {
        this.zsubFuc = zsubFuc;
    }
    /**
     * @return the zsubFucNm
     */
    public String getZsubFucNm() {
        return zsubFucNm;
    }
    /**
     * @param zsubFucNm the zsubFucNm to set
     */
    public void setZsubFucNm(String zsubFucNm) {
        this.zsubFucNm = zsubFucNm;
    }
    /**
     * @return the zusgQty
     */
    public BigDecimal getZusgQty() {
        return zusgQty;
    }
    /**
     * @param zusgQty the zusgQty to set
     */
    public void setZusgQty(BigDecimal zusgQty) {
        this.zusgQty = zusgQty;
    }
    /**
     * @return the meins
     */
    public String getMeins() {
        return meins;
    }
    /**
     * @param meins the meins to set
     */
    public void setMeins(String meins) {
        this.meins = meins;
    }
    /**
     * @return the zqup
     */
    public BigDecimal getZqup() {
        return zqup;
    }
    /**
     * @param zqup the zqup to set
     */
    public void setZqup(BigDecimal zqup) {
        this.zqup = zqup;
    }
    /**
     * @return the zqfp
     */
    public BigDecimal getZqfp() {
        return zqfp;
    }
    /**
     * @param zqfp the zqfp to set
     */
    public void setZqfp(BigDecimal zqfp) {
        this.zqfp = zqfp;
    }
    /**
     * @return the zsuccd
     */
    public String getZsuccd() {
        return zsuccd;
    }
    /**
     * @param zsuccd the zsuccd to set
     */
    public void setZsuccd(String zsuccd) {
        this.zsuccd = zsuccd;
    }
    /**
     * @return the zsuccdNm
     */
    public String getZsuccdNm() {
        return zsuccdNm;
    }
    /**
     * @param zsuccdNm the zsuccdNm to set
     */
    public void setZsuccdNm(String zsuccdNm) {
        this.zsuccdNm = zsuccdNm;
    }
    /**
     * @return the zvndcd
     */
    public String getZvndcd() {
        return zvndcd;
    }
    /**
     * @param zvndcd the zvndcd to set
     */
    public void setZvndcd(String zvndcd) {
        this.zvndcd = zvndcd;
    }
    /**
     * @return the zwunit
     */
    public String getZwunit() {
        return zwunit;
    }
    /**
     * @param zwunit the zwunit to set
     */
    public void setZwunit(String zwunit) {
        this.zwunit = zwunit;
    }
    /**
     * @return the zweig
     */
    public BigDecimal getZweig() {
        return zweig;
    }
    /**
     * @param zweig the zweig to set
     */
    public void setZweig(BigDecimal zweig) {
        this.zweig = zweig;
    }
    /**
     * @return the zvunit
     */
    public String getZvunit() {
        return zvunit;
    }
    /**
     * @param zvunit the zvunit to set
     */
    public void setZvunit(String zvunit) {
        this.zvunit = zvunit;
    }
    /**
     * @return the zvol
     */
    public BigDecimal getZvol() {
        return zvol;
    }
    /**
     * @param zvol the zvol to set
     */
    public void setZvol(BigDecimal zvol) {
        this.zvol = zvol;
    }
    /**
     * @return the zmsq
     */
    public BigDecimal getZmsq() {
        return zmsq;
    }
    /**
     * @param zmsq the zmsq to set
     */
    public void setZmsq(BigDecimal zmsq) {
        this.zmsq = zmsq;
    }
    /**
     * @return the zchrrCd
     */
    public String getZchrrCd() {
        return zchrrCd;
    }
    /**
     * @param zchrrCd the zchrrCd to set
     */
    public void setZchrrCd(String zchrrCd) {
        this.zchrrCd = zchrrCd;
    }
    /**
     * @return the zchrrCdNm
     */
    public String getZchrrCdNm() {
        return zchrrCdNm;
    }
    /**
     * @param zchrrCdNm the zchrrCdNm to set
     */
    public void setZchrrCdNm(String zchrrCdNm) {
        this.zchrrCdNm = zchrrCdNm;
    }
    /**
     * @return the zpnc
     */
    public String getZpnc() {
        return zpnc;
    }
    /**
     * @param zpnc the zpnc to set
     */
    public void setZpnc(String zpnc) {
        this.zpnc = zpnc;
    }
    /**
     * @return the zvehTyp
     */
    public String getZvehTyp() {
        return zvehTyp;
    }
    /**
     * @param zvehTyp the zvehTyp to set
     */
    public void setZvehTyp(String zvehTyp) {
        this.zvehTyp = zvehTyp;
    }
    /**
     * @return the zvehTypNm
     */
    public String getZvehTypNm() {
        return zvehTypNm;
    }
    /**
     * @param zvehTypNm the zvehTypNm to set
     */
    public void setZvehTypNm(String zvehTypNm) {
        this.zvehTypNm = zvehTypNm;
    }
    /**
     * @return the zpremMdl
     */
    public String getZpremMdl() {
        return zpremMdl;
    }
    /**
     * @param zpremMdl the zpremMdl to set
     */
    public void setZpremMdl(String zpremMdl) {
        this.zpremMdl = zpremMdl;
    }
    /**
     * @return the zpremMdlNm
     */
    public String getZpremMdlNm() {
        return zpremMdlNm;
    }
    /**
     * @param zpremMdlNm the zpremMdlNm to set
     */
    public void setZpremMdlNm(String zpremMdlNm) {
        this.zpremMdlNm = zpremMdlNm;
    }
    /**
     * @return the zdcFlg
     */
    public String getZdcFlg() {
        return zdcFlg;
    }
    /**
     * @param zdcFlg the zdcFlg to set
     */
    public void setZdcFlg(String zdcFlg) {
        this.zdcFlg = zdcFlg;
    }
    /**
     * @return the zleg1
     */
    public String getZleg1() {
        return zleg1;
    }
    /**
     * @param zleg1 the zleg1 to set
     */
    public void setZleg1(String zleg1) {
        this.zleg1 = zleg1;
    }
    /**
     * @return the zleg1Nm
     */
    public String getZleg1Nm() {
        return zleg1Nm;
    }
    /**
     * @param zleg1Nm the zleg1Nm to set
     */
    public void setZleg1Nm(String zleg1Nm) {
        this.zleg1Nm = zleg1Nm;
    }
    /**
     * @return the zleg2
     */
    public String getZleg2() {
        return zleg2;
    }
    /**
     * @param zleg2 the zleg2 to set
     */
    public void setZleg2(String zleg2) {
        this.zleg2 = zleg2;
    }
    /**
     * @return the zleg2Nm
     */
    public String getZleg2Nm() {
        return zleg2Nm;
    }
    /**
     * @param zleg2Nm the zleg2Nm to set
     */
    public void setZleg2Nm(String zleg2Nm) {
        this.zleg2Nm = zleg2Nm;
    }
    /**
     * @return the zleg3
     */
    public String getZleg3() {
        return zleg3;
    }
    /**
     * @param zleg3 the zleg3 to set
     */
    public void setZleg3(String zleg3) {
        this.zleg3 = zleg3;
    }
    /**
     * @return the zleg3Nm
     */
    public String getZleg3Nm() {
        return zleg3Nm;
    }
    /**
     * @param zleg3Nm the zleg3Nm to set
     */
    public void setZleg3Nm(String zleg3Nm) {
        this.zleg3Nm = zleg3Nm;
    }
    /**
     * @return the zleg4
     */
    public String getZleg4() {
        return zleg4;
    }
    /**
     * @param zleg4 the zleg4 to set
     */
    public void setZleg4(String zleg4) {
        this.zleg4 = zleg4;
    }
    /**
     * @return the zleg4Nm
     */
    public String getZleg4Nm() {
        return zleg4Nm;
    }
    /**
     * @param zleg4Nm the zleg4Nm to set
     */
    public void setZleg4Nm(String zleg4Nm) {
        this.zleg4Nm = zleg4Nm;
    }
    /**
     * @return the zleg5
     */
    public String getZleg5() {
        return zleg5;
    }
    /**
     * @param zleg5 the zleg5 to set
     */
    public void setZleg5(String zleg5) {
        this.zleg5 = zleg5;
    }
    /**
     * @return the zleg5Nm
     */
    public String getZleg5Nm() {
        return zleg5Nm;
    }
    /**
     * @param zleg5Nm the zleg5Nm to set
     */
    public void setZleg5Nm(String zleg5Nm) {
        this.zleg5Nm = zleg5Nm;
    }
    /**
     * @return the zmgtCd
     */
    public String getZmgtCd() {
        return zmgtCd;
    }
    /**
     * @param zmgtCd the zmgtCd to set
     */
    public void setZmgtCd(String zmgtCd) {
        this.zmgtCd = zmgtCd;
    }
    /**
     * @return the ztransCtlcd
     */
    public String getZtransCtlcd() {
        return ztransCtlcd;
    }
    /**
     * @param ztransCtlcd the ztransCtlcd to set
     */
    public void setZtransCtlcd(String ztransCtlcd) {
        this.ztransCtlcd = ztransCtlcd;
    }
    /**
     * @return the ztransCtlcdNm
     */
    public String getZtransCtlcdNm() {
        return ztransCtlcdNm;
    }
    /**
     * @param ztransCtlcdNm the ztransCtlcdNm to set
     */
    public void setZtransCtlcdNm(String ztransCtlcdNm) {
        this.ztransCtlcdNm = ztransCtlcdNm;
    }
    /**
     * @return the zpku
     */
    public BigDecimal getZpku() {
        return zpku;
    }
    /**
     * @param zpku the zpku to set
     */
    public void setZpku(BigDecimal zpku) {
        this.zpku = zpku;
    }
    /**
     * @return the zordCtlcd
     */
    public String getZordCtlcd() {
        return zordCtlcd;
    }
    /**
     * @param zordCtlcd the zordCtlcd to set
     */
    public void setZordCtlcd(String zordCtlcd) {
        this.zordCtlcd = zordCtlcd;
    }
    /**
     * @return the zordCtlcdNm
     */
    public String getZordCtlcdNm() {
        return zordCtlcdNm;
    }
    /**
     * @param zordCtlcdNm the zordCtlcdNm to set
     */
    public void setZordCtlcdNm(String zordCtlcdNm) {
        this.zordCtlcdNm = zordCtlcdNm;
    }
    /**
     * @return the zwdmdCtlcd
     */
    public String getZwdmdCtlcd() {
        return zwdmdCtlcd;
    }
    /**
     * @param zwdmdCtlcd the zwdmdCtlcd to set
     */
    public void setZwdmdCtlcd(String zwdmdCtlcd) {
        this.zwdmdCtlcd = zwdmdCtlcd;
    }
    /**
     * @return the zwdmdCtlcdNm
     */
    public String getZwdmdCtlcdNm() {
        return zwdmdCtlcdNm;
    }
    /**
     * @param zwdmdCtlcdNm the zwdmdCtlcdNm to set
     */
    public void setZwdmdCtlcdNm(String zwdmdCtlcdNm) {
        this.zwdmdCtlcdNm = zwdmdCtlcdNm;
    }
    /**
     * @return the zwsaleCtlcd
     */
    public String getZwsaleCtlcd() {
        return zwsaleCtlcd;
    }
    /**
     * @param zwsaleCtlcd the zwsaleCtlcd to set
     */
    public void setZwsaleCtlcd(String zwsaleCtlcd) {
        this.zwsaleCtlcd = zwsaleCtlcd;
    }
    /**
     * @return the zwsaleCtlcdNm
     */
    public String getZwsaleCtlcdNm() {
        return zwsaleCtlcdNm;
    }
    /**
     * @param zwsaleCtlcdNm the zwsaleCtlcdNm to set
     */
    public void setZwsaleCtlcdNm(String zwsaleCtlcdNm) {
        this.zwsaleCtlcdNm = zwsaleCtlcdNm;
    }
    /**
     * @return the zconPer
     */
    public String getZconPer() {
        return zconPer;
    }
    /**
     * @param zconPer the zconPer to set
     */
    public void setZconPer(String zconPer) {
        this.zconPer = zconPer;
    }
    /**
     * @return the dsnam
     */
    public String getDsnam() {
        return dsnam;
    }
    /**
     * @param dsnam the dsnam to set
     */
    public void setDsnam(String dsnam) {
        this.dsnam = dsnam;
    }
    /**
     * @return the kondm
     */
    public String getKondm() {
        return kondm;
    }
    /**
     * @param kondm the kondm to set
     */
    public void setKondm(String kondm) {
        this.kondm = kondm;
    }
    /**
     * @return the kondmNm
     */
    public String getKondmNm() {
        return kondmNm;
    }
    /**
     * @param kondmNm the kondmNm to set
     */
    public void setKondmNm(String kondmNm) {
        this.kondmNm = kondmNm;
    }
    /**
     * @return the zcertAppl
     */
    public String getZcertAppl() {
        return zcertAppl;
    }
    /**
     * @param zcertAppl the zcertAppl to set
     */
    public void setZcertAppl(String zcertAppl) {
        this.zcertAppl = zcertAppl;
    }
    /**
     * @return the zcertYn
     */
    public String getZcertYn() {
        return zcertYn;
    }
    /**
     * @param zcertYn the zcertYn to set
     */
    public void setZcertYn(String zcertYn) {
        this.zcertYn = zcertYn;
    }
    /**
     * @return the zgrsWg
     */
    public BigDecimal getZgrsWg() {
        return zgrsWg;
    }
    /**
     * @param zgrsWg the zgrsWg to set
     */
    public void setZgrsWg(BigDecimal zgrsWg) {
        this.zgrsWg = zgrsWg;
    }
    /**
     * @return the zwhscd
     */
    public String getZwhscd() {
        return zwhscd;
    }
    /**
     * @param zwhscd the zwhscd to set
     */
    public void setZwhscd(String zwhscd) {
        this.zwhscd = zwhscd;
    }
    
    
}
