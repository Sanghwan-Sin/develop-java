package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CertificateInvoiceExcelDownbVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author ChoKyungHo
 * @since 2020. 2. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 12.     ChoKyungHo     	         최초 생성
 * </pre>
 */

public class CertificateInvoiceExcelDownVO extends MapsCommSapRfcIfCommVO{
   
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
 
    /** 생산자 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** Part 번호 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PART_NO" )
    private String partNo;
    /** Part 이름 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PART_NAME" )
    private String partName;
    /** 선적수량 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SHIP_QTY" )
    private BigDecimal shipQty;
    /** Net Value in Document Currency */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="FOB" )
    private BigDecimal fob;
    /** Commodity Code */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="HS_CODE" )
    private String hsCode;
    /**원산지 결정 기준*/
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CRIT_ORIGIN_DET" )
    private String critOriginDet;
    /** Country Key */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ORIGIN_CNTY" )
    private String originCnty;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CRIT_ORIGIN" )
    private String critOrigin;
    /** Net weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NET_WEIGHT" )
    private BigDecimal netWeight;
    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }
    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the partNo
     */
    public String getPartNo() {
        return partNo;
    }
    /**
     * @param partNo the partNo to set
     */
    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }
    /**
     * @return the partName
     */
    public String getPartName() {
        return partName;
    }
    /**
     * @param partName the partName to set
     */
    public void setPartName(String partName) {
        this.partName = partName;
    }
    /**
     * @return the shipQty
     */
    public BigDecimal getShipQty() {
        return shipQty;
    }
    /**
     * @param shipQty the shipQty to set
     */
    public void setShipQty(BigDecimal shipQty) {
        this.shipQty = shipQty;
    }
    /**
     * @return the fob
     */
    public BigDecimal getFob() {
        return fob;
    }
    /**
     * @param fob the fob to set
     */
    public void setFob(BigDecimal fob) {
        this.fob = fob;
    }
    /**
     * @return the hsCode
     */
    public String getHsCode() {
        return hsCode;
    }
    /**
     * @param hsCode the hsCode to set
     */
    public void setHsCode(String hsCode) {
        this.hsCode = hsCode;
    }
    /**
     * @return the critOriginDet
     */
    public String getCritOriginDet() {
        return critOriginDet;
    }
    /**
     * @param critOriginDet the critOriginDet to set
     */
    public void setCritOriginDet(String critOriginDet) {
        this.critOriginDet = critOriginDet;
    }
    /**
     * @return the originCnty
     */
    public String getOriginCnty() {
        return originCnty;
    }
    /**
     * @param originCnty the originCnty to set
     */
    public void setOriginCnty(String originCnty) {
        this.originCnty = originCnty;
    }
    /**
     * @return the critOrigin
     */
    public String getCritOrigin() {
        return critOrigin;
    }
    /**
     * @param critOrigin the critOrigin to set
     */
    public void setCritOrigin(String critOrigin) {
        this.critOrigin = critOrigin;
    }
    /**
     * @return the netWeight
     */
    public BigDecimal getNetWeight() {
        return netWeight;
    }
    /**
     * @param netWeight the netWeight to set
     */
    public void setNetWeight(BigDecimal netWeight) {
        this.netWeight = netWeight;
    }
    
}
