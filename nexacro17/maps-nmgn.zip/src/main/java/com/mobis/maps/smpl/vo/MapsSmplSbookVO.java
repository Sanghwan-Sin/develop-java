package com.mobis.maps.smpl.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : PagingSbookVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.     Sin Sanghwan     	최초 생성
 *               </pre>
 */

public class MapsSmplSbookVO extends MapsCommSapRfcIfCommVO {
    /* 조회조건 */
    /** 항공사코드 */
    @MapsRfcMappper( targetName="P|IT_DATA", ipttSe="I|E", fieldKey="I_CARRID|CARRID" )
    private String carrId;
    /** 전체데이터 조회(성능테스트) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ALL", defaultVal=" " )
    private String allYn;
    /* 조회결과 */
    /** 항공사이름 */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="CARRNAME" )
    private String carrNm;
    /** 항공편연결번호 */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="CONNID" )
    private String connId;
    /** 항공편일자 */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="FLDATE" )
    private Date flDate;
    /** 예약번호 */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="BOOKID" )
    private String bookId;
    /** 항공편클래스 */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="CLASS" )
    private String flClass;
    /** 여행사번호 */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="AGENCYNUM" )
    private String agencyNum;
    /** 평가금액 */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="LOCCURAM" )
    private String locCurAm;
    /** 항공사의현지통화 */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="LOCCURKEY" )
    private String locCurKey;
    
    /**
     * @return the carrId
     */
    public String getCarrId() {
        return carrId;
    }
    /**
     * @param carrId the carrId to set
     */
    public void setCarrId(String carrId) {
        this.carrId = carrId;
    }
    /**
     * @return the allYn
     */
    public String getAllYn() {
        return allYn;
    }
    /**
     * @param allYn the allYn to set
     */
    public void setAllYn(String allYn) {
        this.allYn = allYn;
    }
    /**
     * @return the carrNm
     */
    public String getCarrNm() {
        return carrNm;
    }
    /**
     * @param carrNm the carrNm to set
     */
    public void setCarrNm(String carrNm) {
        this.carrNm = carrNm;
    }
    /**
     * @return the connId
     */
    public String getConnId() {
        return connId;
    }
    /**
     * @param connId the connId to set
     */
    public void setConnId(String connId) {
        this.connId = connId;
    }
    /**
     * @return the flDate
     */
    public Date getFlDate() {
        return flDate;
    }
    /**
     * @param flDate the flDate to set
     */
    public void setFlDate(Date flDate) {
        this.flDate = flDate;
    }
    /**
     * @return the bookId
     */
    public String getBookId() {
        return bookId;
    }
    /**
     * @param bookId the bookId to set
     */
    public void setBookId(String bookId) {
        this.bookId = bookId;
    }
    /**
     * @return the flClass
     */
    public String getFlClass() {
        return flClass;
    }
    /**
     * @param flClass the flClass to set
     */
    public void setFlClass(String flClass) {
        this.flClass = flClass;
    }
    /**
     * @return the agencyNum
     */
    public String getAgencyNum() {
        return agencyNum;
    }
    /**
     * @param agencyNum the agencyNum to set
     */
    public void setAgencyNum(String agencyNum) {
        this.agencyNum = agencyNum;
    }
    /**
     * @return the locCurAm
     */
    public String getLocCurAm() {
        return locCurAm;
    }
    /**
     * @param locCurAm the locCurAm to set
     */
    public void setLocCurAm(String locCurAm) {
        this.locCurAm = locCurAm;
    }
    /**
     * @return the locCurKey
     */
    public String getLocCurKey() {
        return locCurKey;
    }
    /**
     * @param locCurKey the locCurKey to set
     */
    public void setLocCurKey(String locCurKey) {
        this.locCurKey = locCurKey;
    }
}
