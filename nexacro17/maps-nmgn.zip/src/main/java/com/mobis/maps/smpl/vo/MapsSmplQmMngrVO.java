package com.mobis.maps.smpl.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : MapsSmplMngrVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.     Sin Sanghwan       최초 생성
 *               </pre>
 */

public class MapsSmplQmMngrVO extends MapsCommSapRfcIfCommVO {
    
    /* 조회조건 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_BUKRS" )
    private String iBukrs;
    @MapsRfcMappper( ipttSe="I", fieldKey="I_LIFNR" )
    private String iLinfnr;
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPROCCD" )
    private String iZproccd;
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZMATGB" )
    private String iZmatgb;
    @MapsRfcMappper( ipttSe="I", fieldKey="I_FLAG" )
    private String iFlag;
    /* 입력데이터 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I", fieldKey="ZFLAG" )
    private String zflag;
    /* 조회결과 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="SEQNO|SEQNO" )
    private String seqno;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="BUKRS|BUKRS" )
    private String bukrs;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="BUTXT|BUTXT" )
    private String butxt;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="LIFNR|LIFNR" )
    private String lifnr;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="NAME1|NAME1" )
    private String name1;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="ZPROCCD|ZPROCCD" )
    private String zproccd;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="ZPROCCD_TXT|ZPROCCD_TXT" )
    private String zproccdTxt;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="ZMATGB|ZMATGB" )
    private String zmatgb;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="ZMATGB_TXT|ZMATGB_TXT" )
    private String zmatgbTxt;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="NAME_LAST|NAME_LAST" )
    private String nameLast;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="TEL_NUMBER|TEL_NUMBER" )
    private String telNumber;
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="I|E", fieldKey="SMTP_ADDR|SMTP_ADDR" )
    private String smtpAddr;
    
    /**
     * @return the zflag
     */
    public String getZflag() {
        return zflag;
    }
    /**
     * @param zflag the zflag to set
     */
    public void setZflag(String zflag) {
        this.zflag = zflag;
    }
    /**
     * @return the iFlag
     */
    public String getiFlag() {
        return iFlag;
    }
    /**
     * @param iFlag the iFlag to set
     */
    public void setiFlag(String iFlag) {
        this.iFlag = iFlag;
    }
    /**
     * @return the iBukrs
     */
    public String getiBukrs() {
        return iBukrs;
    }
    /**
     * @param iBukrs the iBukrs to set
     */
    public void setiBukrs(String iBukrs) {
        this.iBukrs = iBukrs;
    }
    /**
     * @return the iLinfnr
     */
    public String getiLinfnr() {
        return iLinfnr;
    }
    /**
     * @param iLinfnr the iLinfnr to set
     */
    public void setiLinfnr(String iLinfnr) {
        this.iLinfnr = iLinfnr;
    }
    /**
     * @return the iZproccd
     */
    public String getiZproccd() {
        return iZproccd;
    }
    /**
     * @param iZproccd the iZproccd to set
     */
    public void setiZproccd(String iZproccd) {
        this.iZproccd = iZproccd;
    }
    /**
     * @return the iZmatgb
     */
    public String getiZmatgb() {
        return iZmatgb;
    }
    /**
     * @param iZmatgb the iZmatgb to set
     */
    public void setiZmatgb(String iZmatgb) {
        this.iZmatgb = iZmatgb;
    }
    /**
     * @return the seqno
     */
    public String getSeqno() {
        return seqno;
    }
    /**
     * @param seqno the seqno to set
     */
    public void setSeqno(String seqno) {
        this.seqno = seqno;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the butxt
     */
    public String getButxt() {
        return butxt;
    }
    /**
     * @param butxt the butxt to set
     */
    public void setButxt(String butxt) {
        this.butxt = butxt;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zproccd
     */
    public String getZproccd() {
        return zproccd;
    }
    /**
     * @param zproccd the zproccd to set
     */
    public void setZproccd(String zproccd) {
        this.zproccd = zproccd;
    }
    /**
     * @return the zproccdTxt
     */
    public String getZproccdTxt() {
        return zproccdTxt;
    }
    /**
     * @param zproccdTxt the zproccdTxt to set
     */
    public void setZproccdTxt(String zproccdTxt) {
        this.zproccdTxt = zproccdTxt;
    }
    /**
     * @return the zmatgb
     */
    public String getZmatgb() {
        return zmatgb;
    }
    /**
     * @param zmatgb the zmatgb to set
     */
    public void setZmatgb(String zmatgb) {
        this.zmatgb = zmatgb;
    }
    /**
     * @return the zmatgbTxt
     */
    public String getZmatgbTxt() {
        return zmatgbTxt;
    }
    /**
     * @param zmatgbTxt the zmatgbTxt to set
     */
    public void setZmatgbTxt(String zmatgbTxt) {
        this.zmatgbTxt = zmatgbTxt;
    }
    /**
     * @return the nameLast
     */
    public String getNameLast() {
        return nameLast;
    }
    /**
     * @param nameLast the nameLast to set
     */
    public void setNameLast(String nameLast) {
        this.nameLast = nameLast;
    }
    /**
     * @return the telNumber
     */
    public String getTelNumber() {
        return telNumber;
    }
    /**
     * @param telNumber the telNumber to set
     */
    public void setTelNumber(String telNumber) {
        this.telNumber = telNumber;
    }
    /**
     * @return the smtpAddr
     */
    public String getSmtpAddr() {
        return smtpAddr;
    }
    /**
     * @param smtpAddr the smtpAddr to set
     */
    public void setSmtpAddr(String smtpAddr) {
        this.smtpAddr = smtpAddr;
    }
    
    
}
