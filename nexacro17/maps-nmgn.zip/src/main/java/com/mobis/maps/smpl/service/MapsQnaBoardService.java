package com.mobis.maps.smpl.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.smpl.vo.MapsQnaBoardVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsQnaBoardService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048105
 * @since 2020. 4. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 7.     DT048105     	최초 생성
 * </pre>
 */

public interface MapsQnaBoardService {

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    List<MapsQnaBoardVO> selectQnaBoardList(MapsQnaBoardVO inputVO) throws Exception;
    
    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsQnaBoardVO selectQnaBoardNewList(MapsQnaBoardVO inputVO) throws Exception;
    
    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    void updateQnaBoardCount(MapsQnaBoardVO inputVO) throws Exception;

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsQnaBoardVO multiQnaBoard(MapsQnaBoardVO inputVO) throws Exception;

    /**
     * Statements
     *
     * @param atchFileVO
     * @param atchFiles
     * @return
     */
    int multiAtchFile(MapsQnaBoardVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception;

}
