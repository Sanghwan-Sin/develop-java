package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.nmgn.cc.service.NewsLetterService;
import com.mobis.maps.nmgn.cc.vo.NewsLetterVO;
import com.mobis.maps.nmgn.cc.vo.TargetTreeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : NewsLetterController.java
 * @Description : ZJSDR01710 News Letter
 * @author 이수지
 * @since 2020. 3. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 31.       이수지                최초 생성
 * </pre>
 */

@Controller
public class NewsLetterController extends HController {

    @Resource(name = "newsLetterService")
    private NewsLetterService newsLetterService;
    
    /**
     * selectNewsLetter
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectNewsLetter.do")
    public NexacroResult selectNewsLetter(@ParamDataSet(name="dsInput") NewsLetterVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<NewsLetterVO> list = newsLetterService.selectNewsLetter(loginInfo, params);
        
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectNewsLetterDetail
     * 
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectNewsLetterDetail.do")
    public NexacroResult selectNewsLetterDetail(@ParamDataSet(name="dsInput") NewsLetterVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<NewsLetterVO> list = newsLetterService.selectNewsLetterDetail(loginInfo, params);

        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * insertNewsLetter
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/insertNewsLetter.do")
    public NexacroResult insertNewsLetter(@ParamDataSet(name="dsInput") NewsLetterVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setUpdtId(loginInfo.getUserId());        
        
        if ("S".equals(params.getStatYn())) { // 신규 저장
            params.setRegistId(loginInfo.getUserId());
        }

        NewsLetterVO list = newsLetterService.insertNewsLetter(params);

        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * insertNewsLetterMail
     * 
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/insertNewsLetterMail.do")
    public NexacroResult insertNewsLetterMail(@ParamDataSet(name="dsInput") NewsLetterVO params
                                            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<NewsLetterVO> list = newsLetterService.selectNewsLetterDetail(loginInfo, params);
        newsLetterService.insertNewsLetterMailSend(loginInfo, list);        
        
        return result;
    }
    
    /**
     * multiNewsLetterAtchFile
     *
     * @param NewsLetterVO
     * @param atchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/multiNewsLetterAtchFile.do")
    public NexacroResult multiNewsLetterAtchFile(@ParamDataSet(name="dsInput") NewsLetterVO atchFileVO
                              , @ParamDataSet(name="dsInputAtchFile") List<MapsAtchFileVO> atchFiles
                              , NexacroResult result) throws Exception {
        
        int procCnt = newsLetterService.multiAtchFile(atchFileVO, atchFiles);

        result.addVariable("procCnt", procCnt);

        return result;
    }
    
    /**
     * selectTargetTreeList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectTargetTreeList.do")
    public NexacroResult selectTargetTreeList(@ParamDataSet(name="dsInput") TargetTreeVO params
                                            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsCommCodeVO commCodeVO = new MapsCommCodeVO();
        
        List<TargetTreeVO> targetList = newsLetterService.selectTargetTreeList(loginInfo, commCodeVO, params);

        result.addDataSet("dsOutput", targetList);

        return result;
    }      
}
