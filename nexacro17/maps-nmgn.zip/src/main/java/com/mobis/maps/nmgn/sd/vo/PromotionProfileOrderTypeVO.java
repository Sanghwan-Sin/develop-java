package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionProfileOrderTypeVO.java
 * @Description : Promotion Profile에 해당하는 Order Type을 조회하는 VO
 * @author ChoKyungHo
 * @since 2020. 03. 04.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 04.    ChoKyungHo     	                     최초 생성
 * </pre>
 */

public class PromotionProfileOrderTypeVO extends MapsCommSapRfcIfCommVO {
    
    /** C/R/U/D (조회:R) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 프로모션 프로파일 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPPI" )
    private String iZppi;
     
    /**  -----[T_RESULT] START-----*/
    /** 프로모션 프로파일 번호*/
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPI" )
    private String zppi;
    /** 오더유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP" )
    private String zordtyp;
    /** 오더유형 내역  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP_NM" )
    private String zordtypNm;
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZppi
     */
    public String getiZppi() {
        return iZppi;
    }
    /**
     * @param iZppi the iZppi to set
     */
    public void setiZppi(String iZppi) {
        this.iZppi = iZppi;
    }
    /**
     * @return the zppi
     */
    public String getZppi() {
        return zppi;
    }
    /**
     * @param zppi the zppi to set
     */
    public void setZppi(String zppi) {
        this.zppi = zppi;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the zordtypNm
     */
    public String getZordtypNm() {
        return zordtypNm;
    }
    /**
     * @param zordtypNm the zordtypNm to set
     */
    public void setZordtypNm(String zordtypNm) {
        this.zordtypNm = zordtypNm;
    }
    
}
