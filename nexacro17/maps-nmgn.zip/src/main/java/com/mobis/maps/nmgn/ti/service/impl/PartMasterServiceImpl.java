package com.mobis.maps.nmgn.ti.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ti.service.PartMasterService;
import com.mobis.maps.nmgn.ti.vo.PartMasterDetailVO;
import com.mobis.maps.nmgn.ti.vo.PartMasterVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartMasterServiceImpl.java
 * @Description : Part Master
 * @author 이수지
 * @since 2020. 5. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 21.     이수지             	최초 생성
 * </pre>
 */

@Service("partMasterService")
public class PartMasterServiceImpl extends HService implements PartMasterService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.ti.service.PartMasterService#selectPartMasterList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.PartMasterVO)
     */
    @Override
    public List<PartMasterVO> selectPartMasterList(LoginInfoVO loginInfo, PartMasterVO params) throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_PART_LIST_HQ;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());               
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<PartMasterVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, PartMasterVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.PartMasterService#selectRegionList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.PartMasterVO)
     */
    @Override
    public List<PartMasterVO> selectRegionList(LoginInfoVO loginInfo, PartMasterVO params)
            throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_SELECT_AREA_CODE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<PartMasterVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, PartMasterVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.PartMasterService#selectModelList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.PartMasterVO)
     */
    @Override
    public List<PartMasterVO> selectModelList(LoginInfoVO loginInfo, PartMasterVO params)
            throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_SELECT_MODEL_CODE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<PartMasterVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, PartMasterVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.PartMasterService#selectPartMasterDetailList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.PartMasterDetailVO)
     */
    @Override
    public Map<String, Object> selectPartMasterDetailList(LoginInfoVO loginInfo, PartMasterDetailVO params) throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_PART_DETAIL_HQ;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        /* RFC 호출 조회정보 추출 */
        PartMasterDetailVO rtnVo =  MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_DATA", PartMasterDetailVO.class);
        PartMasterDetailVO esRtnVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RETURN", PartMasterDetailVO.class);
        retMap.put("head", rtnVo);
        retMap.put("head1", esRtnVo);
        
        /* RFC Function 취득 */
        sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_REGION_MASTER_HQ;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        
        func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        /* RFC 호출 */
        funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        /* RFC 호출 조회정보 추출 */
        List<PartMasterDetailVO> rtnListVo = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, PartMasterDetailVO.class);
        retMap.put("body", rtnListVo);
        
        return retMap;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.PartMasterService#selectPartMasterDetailListExcelDown(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.PartMasterDetailVO)
     */
    @Override
    public Map<String, Object> selectPartMasterDetailListExcelDown(LoginInfoVO loginInfo, PartMasterDetailVO params)
            throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_REGION_MASTER_HQ;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        /* RFC 호출 조회정보 추출 */
        List<PartMasterDetailVO> rtnListVo = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, PartMasterDetailVO.class);

        retMap.put("head", rtnListVo);
        
        return retMap; 
    }

}
