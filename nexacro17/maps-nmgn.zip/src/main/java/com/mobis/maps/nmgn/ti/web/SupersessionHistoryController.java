package com.mobis.maps.nmgn.ti.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.service.SupersessionHistoryService;
import com.mobis.maps.nmgn.ti.vo.SupersessionDetailVO;
import com.mobis.maps.nmgn.ti.vo.SupersessionHistoryVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SupersessionHistoryController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 5. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 19.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class SupersessionHistoryController extends HController{

    @Resource(name = "supersessionHistoryService")
    private SupersessionHistoryService supersessionHistoryService;
    
    /**
     * selectSupersessionHistoryList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectSupersessionHistoryList.do")
    public NexacroResult selectSupersessionHistoryList(@ParamDataSet(name="dsInput") SupersessionHistoryVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<SupersessionHistoryVO> list = supersessionHistoryService.selectSupersessionHistoryList(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }    
    
    /**
     * selectRegionList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectRegionList.do")
    public NexacroResult selectRegionList(@ParamDataSet(name="dsInput") SupersessionHistoryVO params
                                      , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<SupersessionHistoryVO> list = supersessionHistoryService.selectRegionList(loginInfo, params);
        
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectModelList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectModelList.do")
    public NexacroResult selectModelList(@ParamDataSet(name="dsInput") SupersessionHistoryVO params
                                      , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<SupersessionHistoryVO> list = supersessionHistoryService.selectModelList(loginInfo, params);
        
        result.addDataSet("dsOutput", list);
        
        return result;
    }   
    
    /**
     * selectSupersessionHistoryListExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectSupersessionHistoryListExcelDown.do")
    public NexacroResult selectSupersessionHistoryListExcelDown(@ParamDataSet(name="dsInput") SupersessionHistoryVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<SupersessionHistoryVO> list = supersessionHistoryService.selectSupersessionHistoryList(loginInfo, params);

        result.addDataSet("dsOutput", list);
        
        return result;
    }    
    
    /**
     * selectSupersessionDetailList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectSupersessionDetailList.do")
    public NexacroResult selectSupersessionDetailList(@ParamDataSet(name="dsInput") SupersessionDetailVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        Map<String, Object> retMap = supersessionHistoryService.selectSupersessionDetailList(loginInfo, params);
        @SuppressWarnings("unchecked")
        List<SupersessionDetailVO> retList = (List<SupersessionDetailVO>)retMap.get("body");
        SupersessionDetailVO retVo = (SupersessionDetailVO)retMap.get("head");
        
        result.addDataSet("dsOutput", retVo);
        result.addDataSet("dsOutput2", retList);
        result.addDataSet("dsOutput3", params);
        
        return result;
    }        
    
    /**
     * selectSupersessionDetailListExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectSupersessionDetailListExcelDown.do")
    public NexacroResult selectSupersessionDetailListExcelDown(@ParamDataSet(name="dsInput") SupersessionDetailVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        Map<String, Object> retMap = supersessionHistoryService.selectSupersessionDetailListExcelDown(loginInfo, params);
        @SuppressWarnings("unchecked")
        List<SupersessionDetailVO> retList = (List<SupersessionDetailVO>)retMap.get("head");
        
        result.addDataSet("dsOutput", retList);
        
        return result;
    }        
}
