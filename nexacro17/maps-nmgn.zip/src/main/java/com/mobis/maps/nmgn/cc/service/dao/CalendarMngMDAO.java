package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.CalendarMngVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarMngMDAO.java
 * @Description : Work Calendar Manage
 * @author 이수지
 * @since 2020. 5. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 25.     이수지               	최초 생성
 * </pre>
 */
@Mapper("calendarMngMDAO")
public interface CalendarMngMDAO {

    /**
     * Work Calendar Manage 조회
     *
     * @param paramVO
     * @return
     */
    List<CalendarMngVO> selectCalendarMngList(CalendarMngVO params) throws Exception;

    /**
     * Work Calendar 저장
     *
     * @param params
     * @return
     */
    void insertCalendarMng(CalendarMngVO params);

    /**
     * Work Calendar 수정
     *
     * @param params
     */
    void updateCalendarMng(CalendarMngVO params);

    /**
     * Work Calendar 삭제
     *
     * @param params
     */
    void deleteCalendarMng(CalendarMngVO params);
    
}
