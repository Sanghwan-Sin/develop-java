package com.mobis.maps.nmgn.mm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PacakageImproveSatisfyVO.java
 * @Description : ZPMM_NMGN_R_CREATE_PI_REQ / 포장개선의뢰 만족도 저장
 * @author ChoKyungHo
 * @since 2020. 03. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 17.    ChoKyungHo              최초 생성
 * </pre>
 */

public class PackageImproveSatisfyVO extends MapsCommSapRfcIfCommVO {
    
    /** 의뢰번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFDB_GRADE" )
    private String iZfdbGrade;
    /** 만족도결과 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFDB_TEXT" )
    private String iZfdbText;
    /** 만족도의견 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSPCNO" )
    private String iZspcno;
    /**
     * @return the iZfdbGrade
     */
    public String getiZfdbGrade() {
        return iZfdbGrade;
    }
    /**
     * @param iZfdbGrade the iZfdbGrade to set
     */
    public void setiZfdbGrade(String iZfdbGrade) {
        this.iZfdbGrade = iZfdbGrade;
    }
    /**
     * @return the iZfdbText
     */
    public String getiZfdbText() {
        return iZfdbText;
    }
    /**
     * @param iZfdbText the iZfdbText to set
     */
    public void setiZfdbText(String iZfdbText) {
        this.iZfdbText = iZfdbText;
    }
    /**
     * @return the iZspcno
     */
    public String getiZspcno() {
        return iZspcno;
    }
    /**
     * @param iZspcno the iZspcno to set
     */
    public void setiZspcno(String iZspcno) {
        this.iZspcno = iZspcno;
    }
    
}
