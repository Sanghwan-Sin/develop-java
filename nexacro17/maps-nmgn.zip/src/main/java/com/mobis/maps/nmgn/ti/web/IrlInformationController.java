package com.mobis.maps.nmgn.ti.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.service.IrlInformationService;
import com.mobis.maps.nmgn.ti.vo.IrlInformationVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : IrlInformationController.java
 * @Description : IRL Information
 * @author 이수지
 * @since 2020. 06. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 18.     이수지              	최초 생성
 * </pre>
 */

@Controller
public class IrlInformationController extends HController{

    @Resource(name = "irlInformationService")
    private IrlInformationService irlInformationService;
    
    /**
     * selectIrlInformation
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectIrlInformation.do")
    public NexacroResult selectIrlInformation(@ParamDataSet(name="dsInput") IrlInformationVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<IrlInformationVO> list = irlInformationService.selectIrlInformation(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }     
    
    /**
     * selectIrlInformationExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectIrlInformationExcelDown.do")
    public NexacroResult selectIrlInformationExcelDown(@ParamDataSet(name="dsInput") IrlInformationVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<IrlInformationVO> list = irlInformationService.selectIrlInformation(loginInfo, params);

        result.addDataSet("dsOutput", list);
        
        return result;
    }    
 
}
