package com.mobis.maps.nmgn.ti.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : IrlInformationVO.java
 * @Description : 
 * @author 이수지
 * @since 2020. 06. 18.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 18.     이수지     	       최초 생성
 * </pre>
 */

public class IrlInformationVO extends MapsCommSapRfcIfCommVO {
    
    /** Region */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAREA" )
    private String iZarea;
    /** Dist Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDISTCD" )
    private String iZdistcd;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** model */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZVHC" )
    private String iZvhc;

    
    /** -----[ET_DATA] START----- */
    
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSEQNO" )
    private Integer zseqno;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPNC" )
    private String zpnc;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZAPLY_DATE" )
    private Date zaplyDate;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZEND_DATE" )
    private Date zendDate;
    /** Character field of length 6 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZUSG_QTY" )
    private String zusgQty;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZFOB_PRICE" )
    private String zfobPrice;
    /** Currency Key */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    
    
    /**  -----[ET_DATA] END----- */
    
    
    
    /**
     * @return the iZarea
     */
    public String getiZarea() {
        return iZarea;
    }
    /**
     * @param iZarea the iZarea to set
     */
    public void setiZarea(String iZarea) {
        this.iZarea = iZarea;
    }
    /**
     * @return the iZdistcd
     */
    public String getiZdistcd() {
        return iZdistcd;
    }
    /**
     * @param iZdistcd the iZdistcd to set
     */
    public void setiZdistcd(String iZdistcd) {
        this.iZdistcd = iZdistcd;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZvhc
     */
    public String getiZvhc() {
        return iZvhc;
    }
    /**
     * @param iZvhc the iZvhc to set
     */
    public void setiZvhc(String iZvhc) {
        this.iZvhc = iZvhc;
    }
    /**
     * @return the zseqno
     */
    public Integer getZseqno() {
        return zseqno;
    }
    /**
     * @param zseqno the zseqno to set
     */
    public void setZseqno(Integer zseqno) {
        this.zseqno = zseqno;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the zpnc
     */
    public String getZpnc() {
        return zpnc;
    }
    /**
     * @param zpnc the zpnc to set
     */
    public void setZpnc(String zpnc) {
        this.zpnc = zpnc;
    }
    /**
     * @return the zaplyDate
     */
    public Date getZaplyDate() {
        return zaplyDate;
    }
    /**
     * @param zaplyDate the zaplyDate to set
     */
    public void setZaplyDate(Date zaplyDate) {
        this.zaplyDate = zaplyDate;
    }
    /**
     * @return the zendDate
     */
    public Date getZendDate() {
        return zendDate;
    }
    /**
     * @param zendDate the zendDate to set
     */
    public void setZendDate(Date zendDate) {
        this.zendDate = zendDate;
    }
    /**
     * @return the zusgQty
     */
    public String getZusgQty() {
        return zusgQty;
    }
    /**
     * @param zusgQty the zusgQty to set
     */
    public void setZusgQty(String zusgQty) {
        this.zusgQty = zusgQty;
    }
    /**
     * @return the zfobPrice
     */
    public String getZfobPrice() {
        return zfobPrice;
    }
    /**
     * @param zfobPrice the zfobPrice to set
     */
    public void setZfobPrice(String zfobPrice) {
        this.zfobPrice = zfobPrice;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }

}
