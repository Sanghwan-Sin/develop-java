package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.DistGeneralInfoService;
import com.mobis.maps.nmgn.cc.vo.DistGeneralInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistGeneralInfoController.java
 * @Description : DistGeneralInfoController
 * @author ha.jeongryeong
 * @since 2019. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 10.     ha.jeongryeong     	최초 생성
 *  2020.04. 03.     ChoKyungHo             To-be 테이블로 변경
 * </pre>
 */
@Controller
public class DistGeneralInfoController extends HController {

    @Resource(name = "distGeneralInfoService")
    private DistGeneralInfoService distGeneralInfoService;
    
    /**
     * 조회
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDistGeneralInfoList.do")
    public NexacroResult selectDistGeneralInfoList(
            @ParamDataSet(name="dsInput") DistGeneralInfoVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        List<DistGeneralInfoVO> retList = distGeneralInfoService.selectDistGeneralInfoList(paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }
    
    /**
     * 조회(엑셀)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDistGeneralInfoListExcelDown.do")
    public NexacroResult selectDistGeneralInfoListExcelDown(
            @ParamDataSet(name="dsInput") DistGeneralInfoVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        paramVO.setExcelDwnlYn("Y");
        List<DistGeneralInfoVO> retList = distGeneralInfoService.selectDistGeneralInfoList(paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }
}
