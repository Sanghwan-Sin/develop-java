package com.mobis.maps.nmgn.sd.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.PromotionProfileOrderTypeVO;
import com.mobis.maps.nmgn.sd.vo.PromotionProfileVO;
import com.mobis.maps.nmgn.sd.vo.PromotionToNmgnVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionToNmgnService.java
 * @Description : ZJSDR20110 [채널 RFC] - Promotion to nMGN
 * @author ChoKyungHo
 * @since 2020. 02. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 02. 26.   ChoKyungHo     	                   최초 생성
 * </pre>
 */

public interface PromotionToNmgnService {
    
    /**
     * Promotion Head
     *
     * @param loginVO
     * @param paramVO
     * @return
     * @throws Exception
     */
    Map<String, Object> selectPromotionToNmgn (LoginInfoVO loginVO, PromotionToNmgnVO paramVO) throws Exception;

    /**
     * Promotion Profile Order Type List
     *
     * @param loginInfo
     * @param paramVO
     * @return
     * @throws Exception
     */
    List<PromotionProfileOrderTypeVO> selectPromotionProfileOrderTypeList(LoginInfoVO loginInfo,
            PromotionProfileOrderTypeVO paramVO) throws Exception;
    
    /**
     * Promotion Profile
     *
     * @param loginInfo
     * @param paramVO
     * @return
     * @throws Exception
     */
    List<PromotionProfileVO> selectPromotionProfile(LoginInfoVO loginInfo,
            PromotionProfileVO paramVO) throws Exception;

}
