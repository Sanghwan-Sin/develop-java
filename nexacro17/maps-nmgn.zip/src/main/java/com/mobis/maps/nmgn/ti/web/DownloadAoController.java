package com.mobis.maps.nmgn.ti.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.service.DownloadAoService;
import com.mobis.maps.nmgn.ti.vo.DownloadAoFinishVO;
import com.mobis.maps.nmgn.ti.vo.DownloadAoRequestVO;
import com.mobis.maps.nmgn.ti.vo.DownloadAoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DownloadAoServiceController.java
 * @Description : ZJSDR03020 Download AO List
 * @author 이수지
 * @since 2020. 06. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 16.       이수지              최초 생성
 * </pre>
 */

@Controller
public class DownloadAoController extends HController {

    @Resource(name = "downloadAoService")
    private DownloadAoService downloadAoService;

    /**
     * selectAoDownload
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectDownloadAo.do")
    public NexacroResult selectDownloadAo(@ParamDataSet(name="dsInput") DownloadAoVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<DownloadAoVO> list = downloadAoService.selectDownloadAo(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectDownloadAoExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectDownloadAoExcelDown.do")
    public NexacroResult selectDownloadAoExcelDown(@ParamDataSet(name="dsInput") DownloadAoVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<DownloadAoVO> list = downloadAoService.selectDownloadAo(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectAoDownloadRequest
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectDownloadAoRequest.do")
    public NexacroResult selectDownloadAoRequest(@ParamDataSet(name="dsInput") DownloadAoRequestVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setiZreqid(loginInfo.getUserId()); // 요청자 ID
       
        downloadAoService.selectDownloadAoRequest(loginInfo, params);

        result.addDataSet("dsReturn", params);
        
        return result;
    }
    
    /**
     * selectAoDownFinish
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectDownloadAoFinish.do")
    public NexacroResult selectDownloadAoFinish(@ParamDataSet(name="dsInput") DownloadAoFinishVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);       
       
        downloadAoService.selectDownloadAoFinish(loginInfo, params);

        result.addDataSet("dsReturn", params);
        
        return result;
    }
}
