package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CertificateVO.java
 * @Description : ZPSD_NMGN_S_CERTLIST
 * @author 이수지
 * @since 2020. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 20.     이수지             	최초 생성
 * </pre>
 */

public class CertificateVO extends MapsCommSapRfcIfCommVO {
    
    /** -----[T_DATA] START----- */
    
    /** Client */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MANDT" )
    private String mandt;
    /** Company Code */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCERTI_CD" )
    private String zcertiCd;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCERTI_NAME" )
    private String zcertiName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZCERTI_DESC" )
    private String zcertiDesc;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZNUCHECK" )
    private String znucheck;
    

    /** -----[T_DATA] END----- */
    
    
    /**
     * @return the mandt
     */
    public String getMandt() {
        return mandt;
    }
    /**
     * @param mandt the mandt to set
     */
    public void setMandt(String mandt) {
        this.mandt = mandt;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the zcertiCd
     */
    public String getZcertiCd() {
        return zcertiCd;
    }
    /**
     * @param zcertiCd the zcertiCd to set
     */
    public void setZcertiCd(String zcertiCd) {
        this.zcertiCd = zcertiCd;
    }
    /**
     * @return the zcertiName
     */
    public String getZcertiName() {
        return zcertiName;
    }
    /**
     * @param zcertiName the zcertiName to set
     */
    public void setZcertiName(String zcertiName) {
        this.zcertiName = zcertiName;
    }
    /**
     * @return the zcertiDesc
     */
    public String getZcertiDesc() {
        return zcertiDesc;
    }
    /**
     * @param zcertiDesc the zcertiDesc to set
     */
    public void setZcertiDesc(String zcertiDesc) {
        this.zcertiDesc = zcertiDesc;
    }
    /**
     * @return the znucheck
     */
    public String getZnucheck() {
        return znucheck;
    }
    /**
     * @param znucheck the znucheck to set
     */
    public void setZnucheck(String znucheck) {
        this.znucheck = znucheck;
    }
    
}
