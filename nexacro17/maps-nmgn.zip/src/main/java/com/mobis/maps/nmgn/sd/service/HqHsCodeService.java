package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.RfcOptionVO;
import com.mobis.maps.nmgn.sd.vo.HqFtaAgreementVO;
import com.mobis.maps.nmgn.sd.vo.HqHsCodeVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : HqHsCodeService.java
 * @Description : ZJSDR50030 HQ HS code by parts no
 * @author 이수지
 * @since 2020. 1. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 17.       이수지      	       최초 생성
 * </pre>
 */

public interface HqHsCodeService {

    /**
     * HqHsCodeService
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<HqHsCodeVO> selectHqHsCode (LoginInfoVO loginVo, HqHsCodeVO params, List<RfcOptionVO> paramList) throws Exception;
    
    /**
     * HqHsCodeService
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<HqFtaAgreementVO> selectHqFtaAgreement (LoginInfoVO loginVo, HqFtaAgreementVO params) throws Exception;
}
