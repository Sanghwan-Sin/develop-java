package com.mobis.maps.nmgn.ex.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoicePopVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 2. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 13.     jiyongdo     	최초 생성
 * </pre>
 */

public class InvoicePopVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATE_FROM" )
    private Date iDateFrom;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATE_TO" )
    private Date iDateTo;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** Invoice No. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="INVOICE" )
    private String invoice;
    /** Invoice Date */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="INVOICE_DATE" )
    private Date invoiceDate;
    /**
     * @return the iDateFrom
     */
    public Date getiDateFrom() {
        return iDateFrom;
    }
    /**
     * @param iDateFrom the iDateFrom to set
     */
    public void setiDateFrom(Date iDateFrom) {
        this.iDateFrom = iDateFrom;
    }
    /**
     * @return the iDateTo
     */
    public Date getiDateTo() {
        return iDateTo;
    }
    /**
     * @param iDateTo the iDateTo to set
     */
    public void setiDateTo(Date iDateTo) {
        this.iDateTo = iDateTo;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the invoice
     */
    public String getInvoice() {
        return invoice;
    }
    /**
     * @param invoice the invoice to set
     */
    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }
    /**
     * @return the invoiceDate
     */
    public Date getInvoiceDate() {
        return invoiceDate;
    }
    /**
     * @param invoiceDate the invoiceDate to set
     */
    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }
}
