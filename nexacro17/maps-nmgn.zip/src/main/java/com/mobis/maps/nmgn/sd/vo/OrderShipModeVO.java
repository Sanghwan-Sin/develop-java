package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderShipModeVO.java
 * @Description : Order Type에 따른 Ship Mode
 *                RFC: ZPSD_NMGN_R_SHIPMODE
 * @author hong.minho
 * @since 2020. 3. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 27.     hong.minho     	최초 생성
 * </pre>
 */

public class OrderShipModeVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ORDTYP" )
    private String iOrdtyp;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    
    
//    -----[IT_RESULT] START-----
    /** Shipping Type */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="VSART" )
    private String vsart;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="VSART_NM" )
    private String vsartNm;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MSGNO" )
    private BigDecimal msgno;
    
//    -----[IT_RESULT] END-----
    /**
     * @return the iOrdtyp
     */
    public String getiOrdtyp() {
        return iOrdtyp;
    }
    /**
     * @param iOrdtyp the iOrdtyp to set
     */
    public void setiOrdtyp(String iOrdtyp) {
        this.iOrdtyp = iOrdtyp;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the vsart
     */
    public String getVsart() {
        return vsart;
    }
    /**
     * @param vsart the vsart to set
     */
    public void setVsart(String vsart) {
        this.vsart = vsart;
    }
    /**
     * @return the vsartNm
     */
    public String getVsartNm() {
        return vsartNm;
    }
    /**
     * @param vsartNm the vsartNm to set
     */
    public void setVsartNm(String vsartNm) {
        this.vsartNm = vsartNm;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public BigDecimal getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(BigDecimal msgno) {
        this.msgno = msgno;
    }
}
