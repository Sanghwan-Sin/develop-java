package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceFtaCoPartsVO.java
 * @Description : Invoice List, Header, Detail
 * @author jiyongdo
 * @since 2020. 2. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 14.     jiyongdo     	최초 생성
 * </pre>
 */

public class InvoiceFtaCoPartsVO extends MapsCommSapRfcIfCommVO {

    private String invoiceNo;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PART_NUMBER" )
    private String partNumber;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PART_NAME" )
    private String partName;
    /** Actual quantity delivered (in sales units) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SHIP_QTY" )
    private BigDecimal shipQty;
    /** Sales unit */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="QTY_UNIT" )
    private String qtyUnit;
    /** Net Value of the Order Item in Document Currency */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="FOB_USD" )
    private BigDecimal fobUsd;
    /** SD document currency */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** Net Value of the Order Item in Document Currency */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="FOB_CUR" )
    private BigDecimal fobCur;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SHIPMODE" )
    private String shipmode;
    /** Commodity Code */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="HSCODE" )
    private String hscode;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="RCT" )
    private String rct;
    /** Country Key */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZCOOCTRY" )
    private String zcooctry;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="RCT_OC" )
    private String rctOc;
    /** Gross Weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NTGEW" )
    private BigDecimal ntgew;
    /** Net Weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="BRGEW" )
    private BigDecimal brgew;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="RVCR" )
    private BigDecimal rvcr;
    /**
     * @return the invoiceNo
     */
    public String getInvoiceNo() {
        return invoiceNo;
    }

    /**
     * @param invoiceNo the invoiceNo to set
     */
    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }

    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }

    /**
     * @return the partNumber
     */
    public String getPartNumber() {
        return partNumber;
    }

    /**
     * @param partNumber the partNumber to set
     */
    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    /**
     * @return the partName
     */
    public String getPartName() {
        return partName;
    }

    /**
     * @param partName the partName to set
     */
    public void setPartName(String partName) {
        this.partName = partName;
    }

    /**
     * @return the shipQty
     */
    public BigDecimal getShipQty() {
        return shipQty;
    }

    /**
     * @param shipQty the shipQty to set
     */
    public void setShipQty(BigDecimal shipQty) {
        this.shipQty = shipQty;
    }

    /**
     * @return the qtyUnit
     */
    public String getQtyUnit() {
        return qtyUnit;
    }

    /**
     * @param qtyUnit the qtyUnit to set
     */
    public void setQtyUnit(String qtyUnit) {
        this.qtyUnit = qtyUnit;
    }

    /**
     * @return the fobUsd
     */
    public BigDecimal getFobUsd() {
        return fobUsd;
    }

    /**
     * @param fobUsd the fobUsd to set
     */
    public void setFobUsd(BigDecimal fobUsd) {
        this.fobUsd = fobUsd;
    }

    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }

    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }

    /**
     * @return the fobCur
     */
    public BigDecimal getFobCur() {
        return fobCur;
    }

    /**
     * @param fobCur the fobCur to set
     */
    public void setFobCur(BigDecimal fobCur) {
        this.fobCur = fobCur;
    }

    /**
     * @return the shipmode
     */
    public String getShipmode() {
        return shipmode;
    }

    /**
     * @param shipmode the shipmode to set
     */
    public void setShipmode(String shipmode) {
        this.shipmode = shipmode;
    }

    /**
     * @return the hscode
     */
    public String getHscode() {
        return hscode;
    }

    /**
     * @param hscode the hscode to set
     */
    public void setHscode(String hscode) {
        this.hscode = hscode;
    }

    /**
     * @return the rct
     */
    public String getRct() {
        return rct;
    }

    /**
     * @param rct the rct to set
     */
    public void setRct(String rct) {
        this.rct = rct;
    }

    /**
     * @return the zcooctry
     */
    public String getZcooctry() {
        return zcooctry;
    }

    /**
     * @param zcooctry the zcooctry to set
     */
    public void setZcooctry(String zcooctry) {
        this.zcooctry = zcooctry;
    }

    /**
     * @return the rctOc
     */
    public String getRctOc() {
        return rctOc;
    }

    /**
     * @param rctOc the rctOc to set
     */
    public void setRctOc(String rctOc) {
        this.rctOc = rctOc;
    }

    /**
     * @return the ntgew
     */
    public BigDecimal getNtgew() {
        return ntgew;
    }

    /**
     * @param ntgew the ntgew to set
     */
    public void setNtgew(BigDecimal ntgew) {
        this.ntgew = ntgew;
    }

    /**
     * @return the brgew
     */
    public BigDecimal getBrgew() {
        return brgew;
    }

    /**
     * @param brgew the brgew to set
     */
    public void setBrgew(BigDecimal brgew) {
        this.brgew = brgew;
    }

    /**
     * @return the rvcr
     */
    public BigDecimal getRvcr() {
        return rvcr;
    }

    /**
     * @param rvcr the rvcr to set
     */
    public void setRvcr(BigDecimal rvcr) {
        this.rvcr = rvcr;
    }
}
