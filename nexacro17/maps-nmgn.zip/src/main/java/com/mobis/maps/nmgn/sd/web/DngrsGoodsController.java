package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.DngrsGoodsService;
import com.mobis.maps.nmgn.sd.vo.DngrsGoodsVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DngrsGoodsController.java
 * @Description : ZJSDR80140 UD DOT/ EU BAM - Dangerous Goods (위험물)
 * @author hong.minho
 * @since 2020. 5. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 11.     hong.minho     	최초 생성
 * </pre>
 */

@Controller
public class DngrsGoodsController extends HController {
    
    @Resource(name = "dngrsGoodsService")
    DngrsGoodsService service;

    /**
     * UD DOT/ EU BAM List
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectDangerGood.do")
    public NexacroResult selectDangerGood (@ParamDataSet(name="dsInput") DngrsGoodsVO params
                                            , NexacroResult result) throws Exception {

        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<DngrsGoodsVO> rsltLst = service.selectDangerGood(loginVo, params);
        
        result.addDataSet("dsOutput", rsltLst);
        result.addDataSet("dsReturn", params);

        return result;
    }



    /**
     * Excel download
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectDangerGoodExcelDown.do")
    public NexacroResult selectDangerGoodExcelDown (@ParamDataSet(name="dsInput") DngrsGoodsVO params
                                            , NexacroResult result) throws Exception {
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());        
        return this.selectDangerGood(params, result);
    }


}
