package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileVO;
import com.mobis.maps.nmgn.sd.service.OrderConfirmDownloadService;
import com.mobis.maps.nmgn.sd.vo.OrderConfirmDownloadVO;
import com.mobis.maps.nmgn.sd.vo.ZPSDS3256VO;
import com.mobis.maps.nmgn.sd.vo.ZPSDS3258VO;
import com.mobis.maps.nmgn.sd.vo.ZPSDS3260VO;
import com.mobis.maps.nmgn.sd.vo.ZPSDS3266VO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderConfirmDownloadController.java
 * @Description : Order Confirm Download
 * @author jiyongdo
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class OrderConfirmDownloadController extends HController{

    @Resource(name = "orderConfirmDownloadService")
    private OrderConfirmDownloadService orderConfirmDownloadService;
    
    /**
     * selectConfirmDownloadList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectConfirmDownloadList.do")
    public NexacroResult selectConfirmDownloadList(@ParamDataSet(name="dsInput") OrderConfirmDownloadVO params
                                                 , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
       
        List<OrderConfirmDownloadVO> list = orderConfirmDownloadService.selectConfirmDownloadList(loginInfo, params);
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectConfirmDownloadListExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectConfirmDownloadListExcelDown.do")
    public NexacroResult selectConfirmDownloadListExcelDown(@ParamDataSet(name="dsInput") OrderConfirmDownloadVO params
                                                          , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt()); 
        
        List<OrderConfirmDownloadVO> list = orderConfirmDownloadService.selectConfirmDownloadList(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }    



    /*
     * ZPSDS3256VO - MOFF : Order Confirm List
     * ZPSDS3266VO - MOSR : Order Status Report
     * ZPSDS3260VO - METD : ETD Result
     * ZPSDS3258VO - MBOR : Backorder Status
     */

    
    /**
     * Order File Download - ZPSDS3256VO - MOFF : Order Confirm List
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectMOFFExcelDown.do")
    public NexacroResult selectMOFFExcelDown(@ParamDataSet(name = "dsInFile") MapsCommSapAtchFileVO params,
            NexacroResult result) throws Exception {
        
        params.setSysId(StringUtils.isBlank(params.getSysId()) ? "PC" : params.getSysId());
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ZPSDS3256VO> list = orderConfirmDownloadService.selectOrderExcelDown(loginInfo, params, ZPSDS3256VO.class);
        result.addDataSet("dsExcelFile", list);
        result.addDataSet("dsExcelInfo", params);

        return result;
    }    

    /**
     * Order File Download - ZPSDS3266VO - MOSR : Order Status Report
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectMOSRExcelDown.do")
    public NexacroResult selectMOSRExcelDown(@ParamDataSet(name = "dsInFile") MapsCommSapAtchFileVO params,
            NexacroResult result) throws Exception {
        
        params.setSysId(StringUtils.isBlank(params.getSysId()) ? "PC" : params.getSysId());
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ZPSDS3266VO> list = orderConfirmDownloadService.selectOrderExcelDown(loginInfo, params, ZPSDS3266VO.class);
        result.addDataSet("dsExcelFile", list);
        result.addDataSet("dsExcelInfo", params);

        return result;
    }    


    /**
     * Order File Download - ZPSDS3260VO - METD : ETD Result
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectMETDExcelDown.do")
    public NexacroResult selectMETDExcelDown(@ParamDataSet(name = "dsInFile") MapsCommSapAtchFileVO params,
            NexacroResult result) throws Exception {
        
        params.setSysId(StringUtils.isBlank(params.getSysId()) ? "PC" : params.getSysId());
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ZPSDS3260VO> list = orderConfirmDownloadService.selectOrderExcelDown(loginInfo, params, ZPSDS3260VO.class);
        result.addDataSet("dsExcelFile", list);
        result.addDataSet("dsExcelInfo", params);

        return result;
    }    


    /**
     * Order File Download - ZPSDS3258VO - MBOR : Backorder Status
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectMBORExcelDown.do")
    public NexacroResult selectMBORExcelDown(@ParamDataSet(name = "dsInFile") MapsCommSapAtchFileVO params,
            NexacroResult result) throws Exception {
        
        params.setSysId(StringUtils.isBlank(params.getSysId()) ? "PC" : params.getSysId());
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ZPSDS3258VO> list = orderConfirmDownloadService.selectOrderExcelDown(loginInfo, params, ZPSDS3258VO.class);
        result.addDataSet("dsExcelFile", list);
        result.addDataSet("dsExcelInfo", params);

        return result;
    }    
}
