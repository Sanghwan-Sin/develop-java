package com.mobis.maps.nmgn.cc.service.impl;

import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.nmgn.cc.service.PartsDeptInfoService;
import com.mobis.maps.nmgn.cc.service.dao.PartsDeptInfoMDAO;
import com.mobis.maps.nmgn.cc.vo.PartsDeptInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartsDeptInfoServiceImpl.java
 * @Description : PartsDeptInfoServiceImpl
 * @author ha.jeongryeong
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     ha.jeongryeong         최초 생성
 * </pre>
 */
@Service("partsDeptInfoService")
public class PartsDeptInfoServiceImpl extends HService implements PartsDeptInfoService {

    @Resource(name = "partsDeptInfoMDAO")
    private PartsDeptInfoMDAO partsDeptInfoMDAO;


    /*
     * @see com.mobis.maps.nmgn.cc.service.PartsDeptInfoService#selectPartsDeptInfo(com.mobis.maps.nmgn.cc.vo.PartsDeptInfoVO)
     */
    @Override
    public PartsDeptInfoVO selectPartsDeptInfo(PartsDeptInfoVO paramVO) throws Exception {
        PartsDeptInfoVO retVO = partsDeptInfoMDAO.selectPartsDeptInfo(paramVO);
        if (retVO == null) {
            retVO = new PartsDeptInfoVO();
            retVO.setAgcCode(paramVO.getiDistCd());
            retVO.setSysDptPart("N");
            retVO.setSysDptSlz("N");
            retVO.setSysDptAcct("N");
            retVO.setSysDptSrvc("N");
            retVO.setSysDptEtc("N");
            
            retVO.setSysNetHq("N");
            retVO.setSysNetWrhs("N");
            retVO.setSysNetDeal("N");
            retVO.setSysNetBr("N");
            retVO.setSysNetEtc("N");
        }
        return retVO;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.PartsDeptInfoService#deletePartsDeptInfo(com.mobis.maps.nmgn.cc.vo.PartsDeptInfoVO)
     */
    @Override
    public int multiPartsDeptInfo(PartsDeptInfoVO paramVO) throws Exception {
        int retCnt = 0;
        
        String thisYear = Integer.toString(Calendar.getInstance().get(Calendar.YEAR));
        paramVO.setAplyYear(thisYear);
        
        partsDeptInfoMDAO.deletePartsDeptInfo(paramVO);
        retCnt = partsDeptInfoMDAO.insertPartsDeptInfo(paramVO);
        return retCnt;
    }
    
}
