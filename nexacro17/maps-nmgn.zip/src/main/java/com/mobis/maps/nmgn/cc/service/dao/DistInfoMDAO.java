package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.CodeNameVO;
import com.mobis.maps.nmgn.cc.vo.DistInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistInfoMDAO.java
 * @Description : Parts Order Plan DAO
 * @author ha.jeongryeong
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     ha.jeongryeong         최초 생성
 * </pre>
 */

@Mapper("distInfoMDAO")
public interface DistInfoMDAO {

    /**
     * 조회
     *
     * @param inputVO
     * @return
     */
    DistInfoVO selectDistInfoDetail(DistInfoVO paramVO);
    
    /**
     * 조회
     *
     * @param inputVO
     * @return
     */
    List<DistInfoVO> selectDistStaffInfoList(DistInfoVO paramVO);
    
    /**
     * 조회(코드)
     *
     * @param inputVO
     * @return
     */
    List<CodeNameVO> selectChgNameList();
    
    /**
     * 등록(detail)
     *
     * @param inputVO
     * @return
     */
    int updateDistDetailInfo(DistInfoVO paramVO);
    
    /**
     * 삭제(staff)
     *
     * @param inputVO
     * @return
     */
    int deleteDistStaffInfo(DistInfoVO paramVO);
    
    /**
     * 수정(staff)
     *
     * @param inputVO
     * @return
     */
    int updateDistStaffInfo(DistInfoVO paramVO);
    
    /**
     * 등록(staff)
     *
     * @param inputVO
     * @return
     */
    int insertDistStaffInfo(DistInfoVO paramVO);
    
    /**
     * 사진첨부여부(staff)
     *
     * @param inputVO
     * @return
     */
    int updateDistStaffPhotoYn(DistInfoVO paramVO);
    
}
