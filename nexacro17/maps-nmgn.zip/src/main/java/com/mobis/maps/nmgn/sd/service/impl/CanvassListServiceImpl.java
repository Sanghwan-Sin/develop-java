package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.CanvassListService;
import com.mobis.maps.nmgn.sd.vo.CanvassListVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CanvassListServiceImpl.java
 * @Description : ZJSDR30290 Canvass List
 * @author 이수지
 * @since 2020. 2. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 25.      이수지      	        최초 생성
 * </pre>
 */

@Service("canvassListService")
public class CanvassListServiceImpl extends HService implements CanvassListService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.CanvassListService#selectCanvassList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.CanvassListVO)
     */
    @Override
    public List<CanvassListVO> selectCanvassList(LoginInfoVO loginVo, CanvassListVO params)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_CANVASS_LIST;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<CanvassListVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, CanvassListVO.class);
        

        // *** Grid - 동일 canvass 그룹 별로 row의 배경색상을 변경 처리 위해
        String prevno = "";
        boolean bflag = false;
        for (int idx = 0; list != null && idx < list.size(); idx++) {
            CanvassListVO vo = list.get(idx);
            if (vo == null) continue;
            
            if (!StringUtils.isBlank(prevno) && !prevno.equals(vo.getZcanvno())) {
                bflag = !bflag;
            }

            vo.setEvenRow(bflag ? "E" : "O");
            prevno = vo.getZcanvno();
        }
 
        
        return list;
    }
      
}
