package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartInfoVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 2. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 21.     jiyongdo     	최초 생성
 * </pre>
 */

public class PartInfoVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    //-----[T_RESULT] START-----
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KBETR" )
    private String kbetr;
    /** 조건 단위(통화 또는 백분율) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KONWA" )
    private String konwa;
    /** 자재내역 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** 가격 리스트 유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PLTYP" )
    private String pltyp;
    /** 일자 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="REQ_DATE" )
    private Date reqDate;
    /** 제품군 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="SPART" )
    private String spart;
    /** 대표모델코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZKEY_CAR" )
    private String zkeyCar;
    /** PNC */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPNC" )
    private String zpnc;
    /** SUC CODE-최종 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSUCCD" )
    private String zsuccd;
    //-----[T_RESULT] END-----
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the kbetr
     */
    public String getKbetr() {
        return kbetr;
    }
    /**
     * @param kbetr the kbetr to set
     */
    public void setKbetr(String kbetr) {
        this.kbetr = kbetr;
    }
    /**
     * @return the konwa
     */
    public String getKonwa() {
        return konwa;
    }
    /**
     * @param konwa the konwa to set
     */
    public void setKonwa(String konwa) {
        this.konwa = konwa;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the reqDate
     */
    public Date getReqDate() {
        return reqDate;
    }
    /**
     * @param reqDate the reqDate to set
     */
    public void setReqDate(Date reqDate) {
        this.reqDate = reqDate;
    }
    /**
     * @return the spart
     */
    public String getSpart() {
        return spart;
    }
    /**
     * @param spart the spart to set
     */
    public void setSpart(String spart) {
        this.spart = spart;
    }
    /**
     * @return the zkeyCar
     */
    public String getZkeyCar() {
        return zkeyCar;
    }
    /**
     * @param zkeyCar the zkeyCar to set
     */
    public void setZkeyCar(String zkeyCar) {
        this.zkeyCar = zkeyCar;
    }
    /**
     * @return the zpnc
     */
    public String getZpnc() {
        return zpnc;
    }
    /**
     * @param zpnc the zpnc to set
     */
    public void setZpnc(String zpnc) {
        this.zpnc = zpnc;
    }
    /**
     * @return the zsuccd
     */
    public String getZsuccd() {
        return zsuccd;
    }
    /**
     * @param zsuccd the zsuccd to set
     */
    public void setZsuccd(String zsuccd) {
        this.zsuccd = zsuccd;
    }
}
