package com.mobis.maps.smpl.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.smpl.vo.MapsSmplMsgVO;
import com.mobis.maps.smpl.vo.MapsSmplSbookVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSampleSapService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 16.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public interface MapsSmplSapService {

    
    /**
     * RFC호출 샘플
     *
     * @param loginInfo
     * @param smplSbookVO
     * @return
     * @throws Exception
     */
    public List<MapsSmplSbookVO> selectSbookList(LoginInfoVO loginInfo, MapsSmplSbookVO smplSbookVO) throws Exception;
    
    /**
     * RFC호출 샘플(RFC정보관리 데이터 활용)
     *
     * @param loginInfo
     * @param smplSbookVO
     * @return
     * @throws Exception
     */
    public List<MapsSmplSbookVO> selectRfcSbookList(LoginInfoVO loginInfo, MapsSmplSbookVO smplSbookVO) throws Exception;
    
    /**
     * RFC호출 샘플
     *
     * @param smplSbookVO
     * @return
     * @throws Exception
     */
    public List<MapsSmplSbookVO> selectRfcSbookList(MapsSmplSbookVO smplSbookVO) throws Exception;
    
    /**
     * RFC호출 샘플
     *
     * @param sampleMsgVO
     * @return
     * @throws Exception
     */
    public List<MapsSmplMsgVO> selectRfcMsgList(MapsSmplMsgVO mplMsgVO) throws Exception;
}
