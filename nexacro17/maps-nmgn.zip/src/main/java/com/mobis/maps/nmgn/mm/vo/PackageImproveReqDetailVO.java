package com.mobis.maps.nmgn.mm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PacakageImproveReqDetailVO.java
 * @Description : ZPMM_NMGN_R_DISPLAY_PI_RST / 포장개선의뢰 상세조회 VO
 * @author ChoKyungHo
 * @since 2020. 03. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 17.    ChoKyungHo              최초 생성
 * </pre>
 */

public class PackageImproveReqDetailVO extends MapsCommSapRfcIfCommVO {
    /** 의뢰번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSPCNO" )
    private String iZspcno;

    
    /**-----[ES_RESULT] START----- **/ 
    /** 의뢰번호  */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZSPCNO" )
    private String zspcno;
    /** 회사 코드 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** 회사 코드 또는 회사 이름 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="BUTXT" )
    private String butxt;
    /** 사업장 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="WERKS" )
    private String werks;
    /** 사업장명 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZWERKS_TXT" )
    private String zwerksTxt;
    /** Customer Number */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="KUNNR" )
    private String kunnr;
    /** Name */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="KUNNR_TXT" )
    private String kunnrTxt;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** 자재내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** LAC */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZLAC" )
    private String zlac;
    /** MAC */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZMAC" )
    private String zmac;
    /** SAC */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZSAC" )
    private String zsac;
    /** H/K 구분 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** 내수/수출구분 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZEDCD" )
    private String zedcd;
    /** 부품/용품 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZPA_FLG" )
    private String zpaFlg;
    /** 부품/용품 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZPA_FLG_TXT" )
    private String zpaFlgTxt;
    /** 포장LOT */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZPSLOT" )
    private String zpslot;
    /** 발생지역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZAREA" )
    private String zarea;
    /** 발생지역 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZAREA_TXT" )
    private String zareaTxt;
    /** 발생처 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZOCC_GB" )
    private String zoccGb;
    /** 발생처 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZOCC_GB_TXT" )
    private String zoccGbTxt;
    /** 의뢰부서 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZDEPT" )
    private String zdept;
    /** 의뢰부서 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZDEPT_TXT" )
    private String zdeptTxt;
    /** 의뢰자 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZREQ_EMPNO" )
    private String zreqEmpno;
    /** Name */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZREQ_EMPNO_TXT" )
    private String zreqEmpnoTxt;
    /** 이메일 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZEMAIL" )
    private String zemail;
    /** 연락처 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZTELL" )
    private String ztell;
    /** 개선부서 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZIMP_DEPT" )
    private String zimpDept;
    /** 개선구분 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZIMPGB" )
    private String zimpgb;
    /** 개선구분 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZIMPGB_TXT" )
    private String zimpgbTxt;
    /** 예상발생유형 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZOCC_TYPE" )
    private String zoccType;
    /** 예상발생유형 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZOCC_TYPE_TXT" )
    private String zoccTypeTxt;
    /** 불량유형 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZUNFIT_TYPE" )
    private String zunfitType;
    /** 불량유형 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZUNFIT_TYPE_TXT" )
    private String zunfitTypeTxt;
    /** 불량내용 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZUNF_TXT" )
    private String zunfTxt;
    /** File Server ID */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZFSCODE" )
    private String zfscode;
    /** 포장상태 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZSPC_FILE" )
    private String zspcFile;
    /** File ID */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZSPC_FILE_SEQNO" )
    private String zspcFileSeqno;
    /** Reference Number */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZSPC_FILE_REF_NO" )
    private String zspcFileRefNo;
    /** 불량부위 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZUNF_FILE" )
    private String zunfFile;
    /** File ID */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZUNF_FILE_SEQNO" )
    private String zunfFileSeqno;
    /** Reference Number */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZUNF_FILE_REF_NO" )
    private String zunfFileRefNo;
    /** 요청사항 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZREQ_TXT" )
    private String zreqTxt;
    /** 물류담당자 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZSND_EMPNO" )
    private String zsndEmpno;
    /** Name */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZSND_EMPNO_TXT" )
    private String zsndEmpnoTxt;
    /** 1차검토결과 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZSND_RESULT" )
    private String zsndResult;
    /** 1차검토결과 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZSND_RESULT_TXT" )
    private String zsndResultTxt;
    /** 1차검토내용 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZRET_TXT" )
    private String zretTxt;
    /** 개선담당자 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZIMP_EMPNO" )
    private String zimpEmpno;
    /** Name */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZIMP_EMPNO_TXT" )
    private String zimpEmpnoTxt;
    /** 실제발생유형 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZOCC_FIX" )
    private String zoccFix;
    /** 실제발생유형 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZOCC_FIX_TXT" )
    private String zoccFixTxt;
    /** 포장업체 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="LIFNR" )
    private String lifnr;
    /** Name */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** 2차검토결과 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZRESULT" )
    private String zresult;
    /** 2차검토결과 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZRESULT_TXT" )
    private String zresultTxt;
    /** 2차검토내용 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZIMP_TXT" )
    private String zimpTxt;
    /** 최종검토결과 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZFIN_RESULT" )
    private String zfinResult;
    /** 최종검토결과 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZFIN_RESULT_TXT" )
    private String zfinResultTxt;
    /** 개선전포장사양 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZBEF_TXT" )
    private String zbefTxt;
    /** 개선후포장사양 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZAFT_TXT" )
    private String zaftTxt;
    /** 개선전포장상태 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZBEF_FILE" )
    private String zbefFile;
    /** File ID  */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZBEF_FILE_SEQNO" )
    private String zbefFileSeqno;
    /** Reference Number */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZBEF_FILE_REF_NO" )
    private String zbefFileRefNo;
    /** 개선후포장상태 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZAFT_FILE" )
    private String zaftFile;
    /** File ID  */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZAFT_FILE_SEQNO" )
    private String zaftFileSeqno;
    /** Reference Number */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZAFT_FILE_REF_NO" )
    private String zaftFileRefNo;
    /** 포장검토내용 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZFIN_TXT" )
    private String zfinTxt;
    /** 적용예정일 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZEXP_DATE" )
    private String zexpDate;
    /** 결재자 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZEND_EMPNO" )
    private String zendEmpno;
    /** Name */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZEND_EMPNO_TXT" )
    private String zendEmpnoTxt;
    /** 승인여부 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZEND_STATUS" )
    private String zendStatus;
    /** 승인여부 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZEND_STATUS_TXT" )
    private String zendStatusTxt;
    /** 결재의견 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZBAK_TXT" )
    private String zbakTxt;
    /** 만족도결과 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZFDB_GRADE" )
    private String zfdbGrade;
    /** 만족도결과 내역 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZFDB_GRADE_TXT" )
    private String zfdbGradeTxt;
    /** 만족도의견 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZFDB_TEXT" )
    private String zfdbText;
    /** 진행상태 */
    @MapsRfcMappper( targetName="ES_RESULT", ipttSe="E", fieldKey="ZREQ_STATUS" )
    private String zreqStatus;
    
    /**
     * @return the iZspcno
     */
    public String getiZspcno() {
        return iZspcno;
    }
    /**
     * @param iZspcno the iZspcno to set
     */
    public void setiZspcno(String iZspcno) {
        this.iZspcno = iZspcno;
    }
    /**
     * @return the zspcno
     */
    public String getZspcno() {
        return zspcno;
    }
    /**
     * @param zspcno the zspcno to set
     */
    public void setZspcno(String zspcno) {
        this.zspcno = zspcno;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the butxt
     */
    public String getButxt() {
        return butxt;
    }
    /**
     * @param butxt the butxt to set
     */
    public void setButxt(String butxt) {
        this.butxt = butxt;
    }
    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }
    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }
    /**
     * @return the zwerksTxt
     */
    public String getZwerksTxt() {
        return zwerksTxt;
    }
    /**
     * @param zwerksTxt the zwerksTxt to set
     */
    public void setZwerksTxt(String zwerksTxt) {
        this.zwerksTxt = zwerksTxt;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zlac
     */
    public String getZlac() {
        return zlac;
    }
    /**
     * @param zlac the zlac to set
     */
    public void setZlac(String zlac) {
        this.zlac = zlac;
    }
    /**
     * @return the zmac
     */
    public String getZmac() {
        return zmac;
    }
    /**
     * @param zmac the zmac to set
     */
    public void setZmac(String zmac) {
        this.zmac = zmac;
    }
    /**
     * @return the zsac
     */
    public String getZsac() {
        return zsac;
    }
    /**
     * @param zsac the zsac to set
     */
    public void setZsac(String zsac) {
        this.zsac = zsac;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zedcd
     */
    public String getZedcd() {
        return zedcd;
    }
    /**
     * @param zedcd the zedcd to set
     */
    public void setZedcd(String zedcd) {
        this.zedcd = zedcd;
    }
    /**
     * @return the zpaFlg
     */
    public String getZpaFlg() {
        return zpaFlg;
    }
    /**
     * @param zpaFlg the zpaFlg to set
     */
    public void setZpaFlg(String zpaFlg) {
        this.zpaFlg = zpaFlg;
    }
    /**
     * @return the zpaFlgTxt
     */
    public String getZpaFlgTxt() {
        return zpaFlgTxt;
    }
    /**
     * @param zpaFlgTxt the zpaFlgTxt to set
     */
    public void setZpaFlgTxt(String zpaFlgTxt) {
        this.zpaFlgTxt = zpaFlgTxt;
    }
    /**
     * @return the zpslot
     */
    public String getZpslot() {
        return zpslot;
    }
    /**
     * @param zpslot the zpslot to set
     */
    public void setZpslot(String zpslot) {
        this.zpslot = zpslot;
    }
    /**
     * @return the zarea
     */
    public String getZarea() {
        return zarea;
    }
    /**
     * @param zarea the zarea to set
     */
    public void setZarea(String zarea) {
        this.zarea = zarea;
    }
    /**
     * @return the zareaTxt
     */
    public String getZareaTxt() {
        return zareaTxt;
    }
    /**
     * @param zareaTxt the zareaTxt to set
     */
    public void setZareaTxt(String zareaTxt) {
        this.zareaTxt = zareaTxt;
    }
    /**
     * @return the zoccGb
     */
    public String getZoccGb() {
        return zoccGb;
    }
    /**
     * @param zoccGb the zoccGb to set
     */
    public void setZoccGb(String zoccGb) {
        this.zoccGb = zoccGb;
    }
    /**
     * @return the zoccGbTxt
     */
    public String getZoccGbTxt() {
        return zoccGbTxt;
    }
    /**
     * @param zoccGbTxt the zoccGbTxt to set
     */
    public void setZoccGbTxt(String zoccGbTxt) {
        this.zoccGbTxt = zoccGbTxt;
    }
    /**
     * @return the zdept
     */
    public String getZdept() {
        return zdept;
    }
    /**
     * @param zdept the zdept to set
     */
    public void setZdept(String zdept) {
        this.zdept = zdept;
    }
    /**
     * @return the zdeptTxt
     */
    public String getZdeptTxt() {
        return zdeptTxt;
    }
    /**
     * @param zdeptTxt the zdeptTxt to set
     */
    public void setZdeptTxt(String zdeptTxt) {
        this.zdeptTxt = zdeptTxt;
    }
    /**
     * @return the zreqEmpno
     */
    public String getZreqEmpno() {
        return zreqEmpno;
    }
    /**
     * @param zreqEmpno the zreqEmpno to set
     */
    public void setZreqEmpno(String zreqEmpno) {
        this.zreqEmpno = zreqEmpno;
    }
    /**
     * @return the zemail
     */
    public String getZemail() {
        return zemail;
    }
    /**
     * @param zemail the zemail to set
     */
    public void setZemail(String zemail) {
        this.zemail = zemail;
    }
    /**
     * @return the ztell
     */
    public String getZtell() {
        return ztell;
    }
    /**
     * @param ztell the ztell to set
     */
    public void setZtell(String ztell) {
        this.ztell = ztell;
    }
    /**
     * @return the zimpgb
     */
    public String getZimpgb() {
        return zimpgb;
    }
    /**
     * @param zimpgb the zimpgb to set
     */
    public void setZimpgb(String zimpgb) {
        this.zimpgb = zimpgb;
    }
    /**
     * @return the zimpgbTxt
     */
    public String getZimpgbTxt() {
        return zimpgbTxt;
    }
    /**
     * @param zimpgbTxt the zimpgbTxt to set
     */
    public void setZimpgbTxt(String zimpgbTxt) {
        this.zimpgbTxt = zimpgbTxt;
    }
    /**
     * @return the zoccType
     */
    public String getZoccType() {
        return zoccType;
    }
    /**
     * @param zoccType the zoccType to set
     */
    public void setZoccType(String zoccType) {
        this.zoccType = zoccType;
    }
    /**
     * @return the zoccTypeTxt
     */
    public String getZoccTypeTxt() {
        return zoccTypeTxt;
    }
    /**
     * @param zoccTypeTxt the zoccTypeTxt to set
     */
    public void setZoccTypeTxt(String zoccTypeTxt) {
        this.zoccTypeTxt = zoccTypeTxt;
    }
    /**
     * @return the zunfitType
     */
    public String getZunfitType() {
        return zunfitType;
    }
    /**
     * @param zunfitType the zunfitType to set
     */
    public void setZunfitType(String zunfitType) {
        this.zunfitType = zunfitType;
    }
    /**
     * @return the zunfitTypeTxt
     */
    public String getZunfitTypeTxt() {
        return zunfitTypeTxt;
    }
    /**
     * @param zunfitTypeTxt the zunfitTypeTxt to set
     */
    public void setZunfitTypeTxt(String zunfitTypeTxt) {
        this.zunfitTypeTxt = zunfitTypeTxt;
    }
    /**
     * @return the zunfTxt
     */
    public String getZunfTxt() {
        return zunfTxt;
    }
    /**
     * @param zunfTxt the zunfTxt to set
     */
    public void setZunfTxt(String zunfTxt) {
        this.zunfTxt = zunfTxt;
    }
    /**
     * @return the zspcFile
     */
    public String getZspcFile() {
        return zspcFile;
    }
    /**
     * @param zspcFile the zspcFile to set
     */
    public void setZspcFile(String zspcFile) {
        this.zspcFile = zspcFile;
    }
    /**
     * @return the zunfFile
     */
    public String getZunfFile() {
        return zunfFile;
    }
    /**
     * @param zunfFile the zunfFile to set
     */
    public void setZunfFile(String zunfFile) {
        this.zunfFile = zunfFile;
    }
    /**
     * @return the zreqTxt
     */
    public String getZreqTxt() {
        return zreqTxt;
    }
    /**
     * @param zreqTxt the zreqTxt to set
     */
    public void setZreqTxt(String zreqTxt) {
        this.zreqTxt = zreqTxt;
    }
    /**
     * @return the zsndEmpno
     */
    public String getZsndEmpno() {
        return zsndEmpno;
    }
    /**
     * @param zsndEmpno the zsndEmpno to set
     */
    public void setZsndEmpno(String zsndEmpno) {
        this.zsndEmpno = zsndEmpno;
    }
    /**
     * @return the zsndResult
     */
    public String getZsndResult() {
        return zsndResult;
    }
    /**
     * @param zsndResult the zsndResult to set
     */
    public void setZsndResult(String zsndResult) {
        this.zsndResult = zsndResult;
    }
    /**
     * @return the zsndResultTxt
     */
    public String getZsndResultTxt() {
        return zsndResultTxt;
    }
    /**
     * @param zsndResultTxt the zsndResultTxt to set
     */
    public void setZsndResultTxt(String zsndResultTxt) {
        this.zsndResultTxt = zsndResultTxt;
    }
    /**
     * @return the zretTxt
     */
    public String getZretTxt() {
        return zretTxt;
    }
    /**
     * @param zretTxt the zretTxt to set
     */
    public void setZretTxt(String zretTxt) {
        this.zretTxt = zretTxt;
    }
    /**
     * @return the zimpEmpno
     */
    public String getZimpEmpno() {
        return zimpEmpno;
    }
    /**
     * @param zimpEmpno the zimpEmpno to set
     */
    public void setZimpEmpno(String zimpEmpno) {
        this.zimpEmpno = zimpEmpno;
    }
    /**
     * @return the zoccFix
     */
    public String getZoccFix() {
        return zoccFix;
    }
    /**
     * @param zoccFix the zoccFix to set
     */
    public void setZoccFix(String zoccFix) {
        this.zoccFix = zoccFix;
    }
    /**
     * @return the zoccFixTxt
     */
    public String getZoccFixTxt() {
        return zoccFixTxt;
    }
    /**
     * @param zoccFixTxt the zoccFixTxt to set
     */
    public void setZoccFixTxt(String zoccFixTxt) {
        this.zoccFixTxt = zoccFixTxt;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the zresult
     */
    public String getZresult() {
        return zresult;
    }
    /**
     * @param zresult the zresult to set
     */
    public void setZresult(String zresult) {
        this.zresult = zresult;
    }
    /**
     * @return the zresultTxt
     */
    public String getZresultTxt() {
        return zresultTxt;
    }
    /**
     * @param zresultTxt the zresultTxt to set
     */
    public void setZresultTxt(String zresultTxt) {
        this.zresultTxt = zresultTxt;
    }
    /**
     * @return the zimpTxt
     */
    public String getZimpTxt() {
        return zimpTxt;
    }
    /**
     * @param zimpTxt the zimpTxt to set
     */
    public void setZimpTxt(String zimpTxt) {
        this.zimpTxt = zimpTxt;
    }
    /**
     * @return the zfinResult
     */
    public String getZfinResult() {
        return zfinResult;
    }
    /**
     * @param zfinResult the zfinResult to set
     */
    public void setZfinResult(String zfinResult) {
        this.zfinResult = zfinResult;
    }
    /**
     * @return the zfinResultTxt
     */
    public String getZfinResultTxt() {
        return zfinResultTxt;
    }
    /**
     * @param zfinResultTxt the zfinResultTxt to set
     */
    public void setZfinResultTxt(String zfinResultTxt) {
        this.zfinResultTxt = zfinResultTxt;
    }
    /**
     * @return the zbefTxt
     */
    public String getZbefTxt() {
        return zbefTxt;
    }
    /**
     * @param zbefTxt the zbefTxt to set
     */
    public void setZbefTxt(String zbefTxt) {
        this.zbefTxt = zbefTxt;
    }
    /**
     * @return the zaftTxt
     */
    public String getZaftTxt() {
        return zaftTxt;
    }
    /**
     * @param zaftTxt the zaftTxt to set
     */
    public void setZaftTxt(String zaftTxt) {
        this.zaftTxt = zaftTxt;
    }
    /**
     * @return the zbefFile
     */
    public String getZbefFile() {
        return zbefFile;
    }
    /**
     * @param zbefFile the zbefFile to set
     */
    public void setZbefFile(String zbefFile) {
        this.zbefFile = zbefFile;
    }
    /**
     * @return the zaftFile
     */
    public String getZaftFile() {
        return zaftFile;
    }
    /**
     * @param zaftFile the zaftFile to set
     */
    public void setZaftFile(String zaftFile) {
        this.zaftFile = zaftFile;
    }
    /**
     * @return the zfinTxt
     */
    public String getZfinTxt() {
        return zfinTxt;
    }
    /**
     * @param zfinTxt the zfinTxt to set
     */
    public void setZfinTxt(String zfinTxt) {
        this.zfinTxt = zfinTxt;
    }
    /**
     * @return the zexpDate
     */
    public String getZexpDate() {
        return zexpDate;
    }
    /**
     * @param zexpDate the zexpDate to set
     */
    public void setZexpDate(String zexpDate) {
        this.zexpDate = zexpDate;
    }
    /**
     * @return the zendEmpno
     */
    public String getZendEmpno() {
        return zendEmpno;
    }
    /**
     * @param zendEmpno the zendEmpno to set
     */
    public void setZendEmpno(String zendEmpno) {
        this.zendEmpno = zendEmpno;
    }
    /**
     * @return the zendStatus
     */
    public String getZendStatus() {
        return zendStatus;
    }
    /**
     * @param zendStatus the zendStatus to set
     */
    public void setZendStatus(String zendStatus) {
        this.zendStatus = zendStatus;
    }
    /**
     * @return the zendStatusTxt
     */
    public String getZendStatusTxt() {
        return zendStatusTxt;
    }
    /**
     * @param zendStatusTxt the zendStatusTxt to set
     */
    public void setZendStatusTxt(String zendStatusTxt) {
        this.zendStatusTxt = zendStatusTxt;
    }
    /**
     * @return the zbakTxt
     */
    public String getZbakTxt() {
        return zbakTxt;
    }
    /**
     * @param zbakTxt the zbakTxt to set
     */
    public void setZbakTxt(String zbakTxt) {
        this.zbakTxt = zbakTxt;
    }
    /**
     * @return the zfdbGrade
     */
    public String getZfdbGrade() {
        return zfdbGrade;
    }
    /**
     * @param zfdbGrade the zfdbGrade to set
     */
    public void setZfdbGrade(String zfdbGrade) {
        this.zfdbGrade = zfdbGrade;
    }
    /**
     * @return the zfdbGradeTxt
     */
    public String getZfdbGradeTxt() {
        return zfdbGradeTxt;
    }
    /**
     * @param zfdbGradeTxt the zfdbGradeTxt to set
     */
    public void setZfdbGradeTxt(String zfdbGradeTxt) {
        this.zfdbGradeTxt = zfdbGradeTxt;
    }
    /**
     * @return the zfdbText
     */
    public String getZfdbText() {
        return zfdbText;
    }
    /**
     * @param zfdbText the zfdbText to set
     */
    public void setZfdbText(String zfdbText) {
        this.zfdbText = zfdbText;
    }
    /**
     * @return the zfscode
     */
    public String getZfscode() {
        return zfscode;
    }
    /**
     * @param zfscode the zfscode to set
     */
    public void setZfscode(String zfscode) {
        this.zfscode = zfscode;
    }
    /**
     * @return the zspcFileSeqno
     */
    public String getZspcFileSeqno() {
        return zspcFileSeqno;
    }
    /**
     * @param zspcFileSeqno the zspcFileSeqno to set
     */
    public void setZspcFileSeqno(String zspcFileSeqno) {
        this.zspcFileSeqno = zspcFileSeqno;
    }
    /**
     * @return the zspcFileRefNo
     */
    public String getZspcFileRefNo() {
        return zspcFileRefNo;
    }
    /**
     * @param zspcFileRefNo the zspcFileRefNo to set
     */
    public void setZspcFileRefNo(String zspcFileRefNo) {
        this.zspcFileRefNo = zspcFileRefNo;
    }
    /**
     * @return the zunfFileSeqno
     */
    public String getZunfFileSeqno() {
        return zunfFileSeqno;
    }
    /**
     * @param zunfFileSeqno the zunfFileSeqno to set
     */
    public void setZunfFileSeqno(String zunfFileSeqno) {
        this.zunfFileSeqno = zunfFileSeqno;
    }
    /**
     * @return the zunfFileRefNo
     */
    public String getZunfFileRefNo() {
        return zunfFileRefNo;
    }
    /**
     * @param zunfFileRefNo the zunfFileRefNo to set
     */
    public void setZunfFileRefNo(String zunfFileRefNo) {
        this.zunfFileRefNo = zunfFileRefNo;
    }
    /**
     * @return the zbefFileSeqno
     */
    public String getZbefFileSeqno() {
        return zbefFileSeqno;
    }
    /**
     * @param zbefFileSeqno the zbefFileSeqno to set
     */
    public void setZbefFileSeqno(String zbefFileSeqno) {
        this.zbefFileSeqno = zbefFileSeqno;
    }
    /**
     * @return the zbefFileRefNo
     */
    public String getZbefFileRefNo() {
        return zbefFileRefNo;
    }
    /**
     * @param zbefFileRefNo the zbefFileRefNo to set
     */
    public void setZbefFileRefNo(String zbefFileRefNo) {
        this.zbefFileRefNo = zbefFileRefNo;
    }
    /**
     * @return the zaftFileSeqno
     */
    public String getZaftFileSeqno() {
        return zaftFileSeqno;
    }
    /**
     * @param zaftFileSeqno the zaftFileSeqno to set
     */
    public void setZaftFileSeqno(String zaftFileSeqno) {
        this.zaftFileSeqno = zaftFileSeqno;
    }
    /**
     * @return the zaftFileRefNo
     */
    public String getZaftFileRefNo() {
        return zaftFileRefNo;
    }
    /**
     * @param zaftFileRefNo the zaftFileRefNo to set
     */
    public void setZaftFileRefNo(String zaftFileRefNo) {
        this.zaftFileRefNo = zaftFileRefNo;
    }
    /**
     * @return the zreqEmpnoTxt
     */
    public String getZreqEmpnoTxt() {
        return zreqEmpnoTxt;
    }
    /**
     * @param zreqEmpnoTxt the zreqEmpnoTxt to set
     */
    public void setZreqEmpnoTxt(String zreqEmpnoTxt) {
        this.zreqEmpnoTxt = zreqEmpnoTxt;
    }
    /**
     * @return the zsndEmpnoTxt
     */
    public String getZsndEmpnoTxt() {
        return zsndEmpnoTxt;
    }
    /**
     * @param zsndEmpnoTxt the zsndEmpnoTxt to set
     */
    public void setZsndEmpnoTxt(String zsndEmpnoTxt) {
        this.zsndEmpnoTxt = zsndEmpnoTxt;
    }
    /**
     * @return the zimpEmpnoTxt
     */
    public String getZimpEmpnoTxt() {
        return zimpEmpnoTxt;
    }
    /**
     * @param zimpEmpnoTxt the zimpEmpnoTxt to set
     */
    public void setZimpEmpnoTxt(String zimpEmpnoTxt) {
        this.zimpEmpnoTxt = zimpEmpnoTxt;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zendEmpnoTxt
     */
    public String getZendEmpnoTxt() {
        return zendEmpnoTxt;
    }
    /**
     * @param zendEmpnoTxt the zendEmpnoTxt to set
     */
    public void setZendEmpnoTxt(String zendEmpnoTxt) {
        this.zendEmpnoTxt = zendEmpnoTxt;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the kunnrTxt
     */
    public String getKunnrTxt() {
        return kunnrTxt;
    }
    /**
     * @param kunnrTxt the kunnrTxt to set
     */
    public void setKunnrTxt(String kunnrTxt) {
        this.kunnrTxt = kunnrTxt;
    }
    /**
     * @return the zimpDept
     */
    public String getZimpDept() {
        return zimpDept;
    }
    /**
     * @param zimpDept the zimpDept to set
     */
    public void setZimpDept(String zimpDept) {
        this.zimpDept = zimpDept;
    }
    /**
     * @return the zreqStatus
     */
    public String getZreqStatus() {
        return zreqStatus;
    }
    /**
     * @param zreqStatus the zreqStatus to set
     */
    public void setZreqStatus(String zreqStatus) {
        this.zreqStatus = zreqStatus;
    }
    
}
