package com.mobis.maps.nmgn.cc.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.vo.CodeVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommCodeService;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.nmgn.cc.service.DistInfoService;
import com.mobis.maps.nmgn.cc.service.dao.DistInfoMDAO;
import com.mobis.maps.nmgn.cc.vo.CodeNameVO;
import com.mobis.maps.nmgn.cc.vo.DistInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DisInfoServiceImpl.java
 * @Description : DistInfoServiceImpl
 * @author ha.jeongryeong
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     ha.jeongryeong         최초 생성
 * </pre>
 */
@Service("distInfoService")
public class DistInfoServiceImpl extends HService implements DistInfoService {

    @Resource(name = "distInfoMDAO")
    private DistInfoMDAO distInfoMDAO;
    
    @Resource(name="mapsCommFileService")
    private MapsCommFileService mapsCommFileService;   
    
    @Resource(name="mapsCommCodeService")
    private MapsCommCodeService mapsCommCodeService;

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistInfoService#selectDistInfoDetail(com.mobis.maps.nmgn.cc.vo.DistInfoVO)
     */
    @Override
    public DistInfoVO selectDistInfoDetail(DistInfoVO paramVO) throws Exception{
        DistInfoVO retVO = distInfoMDAO.selectDistInfoDetail(paramVO);
        
        BeanUtils.copyProperties(paramVO, retVO);
        
        return paramVO;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistInfoService#selectDistStaffInfo(com.mobis.maps.nmgn.cc.vo.DistInfoVO)
     */
    @Override
    public List<DistInfoVO> selectDistStaffInfoList(DistInfoVO paramVO) throws Exception{
        
        List<DistInfoVO> retList = distInfoMDAO.selectDistStaffInfoList(paramVO);
        
        selectConvertCodeToYn(retList); // mailing code 변환
        
        return retList;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistInfoService#selectChgNameList(com.mobis.maps.nmgn.cc.vo.CodeNameVO)
     */
    @Override
    public List<CodeNameVO> selectChgNameList() throws Exception{
        
        List<CodeNameVO> retList = distInfoMDAO.selectChgNameList();
        
        return retList;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistInfoService#saveDistDetailInfo(com.mobis.maps.nmgn.cc.vo.DistInfoVO, java.util.List)
     */
    @Override
    public List<DistInfoVO> multiDistDetailInfo(DistInfoVO paramVO, List<MapsAtchFileVO> atchFiles, List<MapsAtchFileVO> atchFiles2, List<DistInfoVO> paramList) throws Exception{
                
        if (atchFiles != null && atchFiles.size() > 0) {
            AtchFileSe atchFileGubn = AtchFileSe.get("NMGN004");
            mapsCommFileService.multiAtchFile(atchFileGubn, paramVO, atchFiles);
        }
        if (atchFiles2 != null && atchFiles2.size() > 0) {
            AtchFileSe atchFileGubn = AtchFileSe.get("NMGN008");
            mapsCommFileService.multiAtchFile(atchFileGubn, paramVO, atchFiles2);
        }
        multiSaveDistInfo(paramVO, paramList);

        List<DistInfoVO> retList = selectDistStaffInfoList(paramVO);

        return retList;
    }
    
    /*
     * save Dist Info
     */
    private int multiSaveDistInfo(DistInfoVO paramVO, List<DistInfoVO> paramList) throws Exception {
        int retCnt = 0;
        
        distInfoMDAO.updateDistDetailInfo(paramVO);
        
        for(DistInfoVO tVO : paramList) {
            if("Y".equals(tVO.getChkYn())) {
                tVO.setVkorg(paramVO.getVkorg());
                tVO.setKunnr(paramVO.getKunnr());
                tVO.setVtweg(paramVO.getVtweg());
                tVO.setiDistCd(paramVO.getiDistCd());
                tVO.setUname(paramVO.getUname());
                tVO.setIdFlag(" ");
                
                switch (tVO.getRowSe()) {
                    case "I":
                        retCnt = distInfoMDAO.insertDistStaffInfo(tVO); 
                        break;
                    case "U" :
                        distInfoMDAO.updateDistStaffInfo(tVO);                  
                        break;
                    case "D" :
                        distInfoMDAO.deleteDistStaffInfo(tVO);
                        break;
                    default :
                        break;
                }
            }
        }
        
        return retCnt;
    }
    
    
    /*
     * mailing list code 변환
     */
    private void selectConvertCodeToYn(List<DistInfoVO> paramList) throws Exception {
        
        MapsCommCodeVO param = new MapsCommCodeVO();
        param.setCodeGroup("M000000021");
        param.setUseYn("Y");
        param.setDelYn("N");
        
        List<CodeVO> cdLst = this.mapsCommCodeService.selectCodeList(param);
        
        if (cdLst == null || cdLst.size() <= 0) return;
        
        
        Map<String, String> mailCd = new HashMap<String, String>();
        
        for(int idx = 0; idx < cdLst.size(); idx++) {
            CodeVO cd = cdLst.get(idx);
            mailCd.put(cd.getCode(), String.valueOf(idx));
        }
        
        
        for(DistInfoVO vo : paramList) {
            
            if (vo == null || StringUtils.isEmpty(vo.getEmailRecv())) continue;
            
            String[] cds = vo.getEmailRecv().replaceAll("\\s+", "").split("\\,");

            if ("ALL".equals(cds[0])) {
                vo.setMailAll("Y");
                
                for(int idx = 0; idx < cdLst.size(); idx++) {
                    vo.getClass().getMethod("setMailTp" + idx, String.class).invoke(vo, cdLst.get(idx).getCode());
                }
                
                continue;
            }
            
            for(String cd : cds) {
                String index = mailCd.get(cd);
                if (StringUtils.isEmpty(index)) continue;
                
                vo.getClass().getMethod("setMailTp" + index, String.class).invoke(vo, cd);
            } // END-FOR
        } // END-FOR
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistInfoService#multiDistStaffPhoto(com.mobis.maps.nmgn.cc.vo.DistInfoVO, java.util.List)
     */
    @Override
    public int multiDistStaffPhoto(DistInfoVO paramVO, List<MapsAtchFileVO> atchFiles) throws Exception {
        int retCnt = 0;
        if (atchFiles != null && atchFiles.size()>0) {
            AtchFileSe atchFileGubn = AtchFileSe.get(paramVO.getAtchSe()); 
            retCnt = mapsCommFileService.multiAtchFile(atchFileGubn, paramVO, atchFiles);    
        }
        return retCnt;
    }

}
