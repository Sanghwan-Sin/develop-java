package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderNoListVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 4. 1.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 1.     jiyongdo     	최초 생성
 * </pre>
 */

public class OrderNoListVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT" )
    private Date iZorddt;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_P" )
    private String iZordnoP;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDTYP" )
    private String iZordtyp;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    //-----[IT_RESULT] START-----
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDTYP" )
    private String zordtyp;
    /** H/K Common */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name 1 of organization */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDNO_P" )
    private String zordnoP;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDDT" )
    private Date zorddt;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MSGNO" )
    private BigDecimal msgno;
    //-----[IT_RESULT] END-----
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the iZorddt
     */
    public Date getiZorddt() {
        return iZorddt;
    }
    /**
     * @param iZorddt the iZorddt to set
     */
    public void setiZorddt(Date iZorddt) {
        this.iZorddt = iZorddt;
    }
    /**
     * @return the iZordnoP
     */
    public String getiZordnoP() {
        return iZordnoP;
    }
    /**
     * @param iZordnoP the iZordnoP to set
     */
    public void setiZordnoP(String iZordnoP) {
        this.iZordnoP = iZordnoP;
    }
    /**
     * @return the iZordtyp
     */
    public String getiZordtyp() {
        return iZordtyp;
    }
    /**
     * @param iZordtyp the iZordtyp to set
     */
    public void setiZordtyp(String iZordtyp) {
        this.iZordtyp = iZordtyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zordnoP
     */
    public String getZordnoP() {
        return zordnoP;
    }
    /**
     * @param zordnoP the zordnoP to set
     */
    public void setZordnoP(String zordnoP) {
        this.zordnoP = zordnoP;
    }
    /**
     * @return the zorddt
     */
    public Date getZorddt() {
        return zorddt;
    }
    /**
     * @param zorddt the zorddt to set
     */
    public void setZorddt(Date zorddt) {
        this.zorddt = zorddt;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public BigDecimal getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(BigDecimal msgno) {
        this.msgno = msgno;
    }
}
