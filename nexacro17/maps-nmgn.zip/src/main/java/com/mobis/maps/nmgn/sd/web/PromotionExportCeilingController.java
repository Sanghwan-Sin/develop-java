package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.PromotionExportCeilingService;
import com.mobis.maps.nmgn.sd.vo.PromotionExportCeilingVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionExportCeilingController.java
 * @Description : ZJSDR20125 Export Ceiling Promotion Result
 * @author 이수지
 * @since 2020. 06. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 22.      이수지                최초 생성
 * </pre>
 */

@Controller
public class PromotionExportCeilingController extends HController {

    @Resource(name = "promotionExportCeilingService")
    private PromotionExportCeilingService promotionExportCeilingService;

    /**
     * selectPromotionExportCeiling
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPromotionExportCeiling.do")
    public NexacroResult selectPromotionExportCeiling(@ParamDataSet(name="dsInput") PromotionExportCeilingVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PromotionExportCeilingVO> list = promotionExportCeilingService.selectPromotionExportCeiling(loginInfo, params);

        int count = 0;
        for (int idx = 0; idx < list.size(); idx++) {
            if ("0".equals(list.get(idx).getZlevel())) {
                count++;
                list.get(idx).setCount(count);
            }
        }
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectPromotionExportCeilingExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPromotionExportCeilingExcelDown.do")
    public NexacroResult selectPromotionExportCeilingExcelDown(@ParamDataSet(name="dsInput") PromotionExportCeilingVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<PromotionExportCeilingVO> list = promotionExportCeilingService.selectPromotionExportCeiling(loginInfo, params);
      
        int count = 0;
        for (int idx = 0; idx < list.size(); idx++) {
            if ("0".equals(list.get(idx).getZlevel())) {
                count++;
                list.get(idx).setCount(count);
            }
        }
        
        result.addDataSet("dsOutput", list);

        return result;
    }
}
