package com.mobis.maps.nmgn.ti.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.vo.PartMasterDetailVO;
import com.mobis.maps.nmgn.ti.vo.PartMasterVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartMasterService.java
 * @Description : Part Master
 * @since 2020. 5. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 21.     이수지             	최초 생성
 * </pre>
 */

public interface PartMasterService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<PartMasterVO> selectPartMasterList(LoginInfoVO loginInfo, PartMasterVO params) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<PartMasterVO> selectRegionList(LoginInfoVO loginInfo, PartMasterVO params) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<PartMasterVO> selectModelList(LoginInfoVO loginInfo, PartMasterVO params) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    Map<String, Object> selectPartMasterDetailList(LoginInfoVO loginInfo, PartMasterDetailVO params)  throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    Map<String, Object> selectPartMasterDetailListExcelDown(LoginInfoVO loginInfo, PartMasterDetailVO params) throws Exception;

}
