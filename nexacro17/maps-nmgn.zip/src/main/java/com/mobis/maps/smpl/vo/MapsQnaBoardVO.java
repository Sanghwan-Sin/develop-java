package com.mobis.maps.smpl.vo;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplBoardVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsQnaBoardVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048105
 * @since 2020. 4. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 7.     DT048105     	최초 생성
 * </pre>
 */
public class MapsQnaBoardVO extends PgBascVO{
    /* 조회조건 */
    /** Interface ID */
    private String ifCode;
    /** 회사 코드 */
    private String bukRs;
    /** Source System */
    private String srfcId;
    /** Target System */
    private String trfcId;
    
    private String bbscttId    ; //게시글ID
    private String bbscttSeq   ; //게시글일련
    private String jobTy       ; //업무타입
    private String bbscttDp    ; //게시글계층
    private String bbscttSj    ; //게시글제목
    private String bbscttCn    ; //게시글내용
    private String registId     ; //작성자ID
    private String registNm     ; //작성자명
    private String rdCnt       ; //조회수
    private String delYn    ; //삭제여부
    private String password;    //비밀번호
    private String scrinCd;     //화면 코드
    private String menuNm;      //메뉴명
    private String scrinUrl;    //화면 url
    private String atchSe;
    private String atchId;
    
    private String strDate    ; //시작일
    private String fnsDate    ; //종료일

    private String saveType   ; //저장타입
    private String seqNo   ;
    
    private String bbscttReply    ; //게시글답변
    private String vkorg    ;   //영억조직(법인코드)
    private String vtweg    ;   //유통경로
    private String kunnr    ;   //고객번호(대리점코드)
    private String kunam    ;   //대리점명
    private String type   ;   //의견구분유형    
    private String typeNm   ;   //의견구분유형 
    
    private String rcnt;        // 읽기 카운트
    /**
     * @return the ifCode
     */
    public String getIfCode() {
        return ifCode;
    }

    /**
     * @param ifCode the ifCode to set
     */
    public void setIfCode(String ifCode) {
        this.ifCode = ifCode;
    }

    /**
     * @return the bukRs
     */
    public String getBukRs() {
        return bukRs;
    }

    /**
     * @param bukRs the bukRs to set
     */
    public void setBukRs(String bukRs) {
        this.bukRs = bukRs;
    }

    /**
     * @return the srfcId
     */
    public String getSrfcId() {
        return srfcId;
    }

    /**
     * @param srfcId the srfcId to set
     */
    public void setSrfcId(String srfcId) {
        this.srfcId = srfcId;
    }

    /**
     * @return the trfcId
     */
    public String getTrfcId() {
        return trfcId;
    }

    /**
     * @param trfcId the trfcId to set
     */
    public void setTrfcId(String trfcId) {
        this.trfcId = trfcId;
    }

    /**
     * @return the bbscttId
     */
    public String getBbscttId() {
        return bbscttId;
    }

    /**
     * @param bbscttId the bbscttId to set
     */
    public void setBbscttId(String bbscttId) {
        this.bbscttId = bbscttId;
    }

    /**
     * @return the bbscttSeq
     */
    public String getBbscttSeq() {
        return bbscttSeq;
    }

    /**
     * @param bbscttSeq the bbscttSeq to set
     */
    public void setBbscttSeq(String bbscttSeq) {
        this.bbscttSeq = bbscttSeq;
    }

    /**
     * @return the jobTy
     */
    public String getJobTy() {
        return jobTy;
    }

    /**
     * @param jobTy the jobTy to set
     */
    public void setJobTy(String jobTy) {
        this.jobTy = jobTy;
    }

    /**
     * @return the bbscttDp
     */
    public String getBbscttDp() {
        return bbscttDp;
    }

    /**
     * @param bbscttDp the bbscttDp to set
     */
    public void setBbscttDp(String bbscttDp) {
        this.bbscttDp = bbscttDp;
    }

    /**
     * @return the bbscttSj
     */
    public String getBbscttSj() {
        return bbscttSj;
    }

    /**
     * @param bbscttSj the bbscttSj to set
     */
    public void setBbscttSj(String bbscttSj) {
        this.bbscttSj = bbscttSj;
    }

    /**
     * @return the bbscttCn
     */
    public String getBbscttCn() {
        return bbscttCn;
    }

    /**
     * @param bbscttCn the bbscttCn to set
     */
    public void setBbscttCn(String bbscttCn) {
        this.bbscttCn = bbscttCn;
    }

    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }

    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }

    /**
     * @return the registNm
     */
    public String getRegistNm() {
        return registNm;
    }

    /**
     * @param registNm the registNm to set
     */
    public void setRegistNm(String registNm) {
        this.registNm = registNm;
    }

    /**
     * @return the rdCnt
     */
    public String getRdCnt() {
        return rdCnt;
    }

    /**
     * @param rdCnt the rdCnt to set
     */
    public void setRdCnt(String rdCnt) {
        this.rdCnt = rdCnt;
    }

    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }

    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }

    /**
     * @return the strDate
     */
    public String getStrDate() {
        return strDate;
    }

    /**
     * @param strDate the strDate to set
     */
    public void setStrDate(String strDate) {
        this.strDate = strDate;
    }

    /**
     * @return the fnsDate
     */
    public String getFnsDate() {
        return fnsDate;
    }

    /**
     * @param fnsDate the fnsDate to set
     */
    public void setFnsDate(String fnsDate) {
        this.fnsDate = fnsDate;
    }

    /**
     * @return the saveType
     */
    public String getSaveType() {
        return saveType;
    }

    /**
     * @param saveType the saveType to set
     */
    public void setSaveType(String saveType) {
        this.saveType = saveType;
    }

    /**
     * @return the atchSe
     */
    public String getAtchSe() {
        return atchSe;
    }

    /**
     * @param atchSe the atchSe to set
     */
    public void setAtchSe(String atchSe) {
        this.atchSe = atchSe;
    }

    /**
     * @return the atchId
     */
    public String getAtchId() {
        return atchId;
    }

    /**
     * @param atchId the atchId to set
     */
    public void setAtchId(String atchId) {
        this.atchId = atchId;
    }

    /**
     * @return the seqNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo the seqNo to set
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @return the bbscttReply
     */
    public String getBbscttReply() {
        return bbscttReply;
    }

    /**
     * @param bbscttReply the bbscttReply to set
     */
    public void setBbscttReply(String bbscttReply) {
        this.bbscttReply = bbscttReply;
    }

    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }

    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }

    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }

    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }

    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }

    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the typeNm
     */
    public String getTypeNm() {
        return typeNm;
    }

    /**
     * @param typeNm the typeNm to set
     */
    public void setTypeNm(String typeNm) {
        this.typeNm = typeNm;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the scrinCd
     */
    public String getScrinCd() {
        return scrinCd;
    }

    /**
     * @param scrinCd the scrinCd to set
     */
    public void setScrinCd(String scrinCd) {
        this.scrinCd = scrinCd;
    }

    /**
     * @return the menuNm
     */
    public String getMenuNm() {
        return menuNm;
    }

    /**
     * @param menuNm the menuNm to set
     */
    public void setMenuNm(String menuNm) {
        this.menuNm = menuNm;
    }

    /**
     * @return the scrinUrl
     */
    public String getScrinUrl() {
        return scrinUrl;
    }

    /**
     * @param scrinUrl the scrinUrl to set
     */
    public void setScrinUrl(String scrinUrl) {
        this.scrinUrl = scrinUrl;
    }

    /**
     * @return the kunam
     */
    public String getKunam() {
        return kunam;
    }

    /**
     * @param kunam the kunam to set
     */
    public void setKunam(String kunam) {
        this.kunam = kunam;
    }

    /**
     * @return the rcnt
     */
    public String getRcnt() {
        return rcnt;
    }

    /**
     * @param rcnt the rcnt to set
     */
    public void setRcnt(String rcnt) {
        this.rcnt = rcnt;
    }
}
