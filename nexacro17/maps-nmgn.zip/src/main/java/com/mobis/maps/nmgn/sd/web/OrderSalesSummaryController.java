package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.OrderSalesSummaryService;
import com.mobis.maps.nmgn.sd.vo.OrderSalesSummaryVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderSalesSummaryController.java
 * @Description : ZJSDR30250 Order & Sales Summary
 * @author 이수지
 * @since 2020. 4. 08.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 08.       이수지                최초 생성
 * </pre>
 */

@Controller
public class OrderSalesSummaryController extends HController {

    @Resource(name = "orderSalesSummaryService")
    private OrderSalesSummaryService orderSalesSummaryService;

    /**
     * selectOrderSalesSummary
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderSalesSummary.do")
    public NexacroResult selectOrderSalesSummary(@ParamDataSet(name="dsInput") OrderSalesSummaryVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = orderSalesSummaryService.selectOrderSalesSummary(loginInfo, params);
        
        OrderSalesSummaryVO excelList = (OrderSalesSummaryVO) retMap.get("head");
        @SuppressWarnings("unchecked")
        List<OrderSalesSummaryVO> list = (List<OrderSalesSummaryVO>) retMap.get("body");
        
        if (list.size() > 0) {
            list.get(0).setYear(params.getiGjahr()); // Year
            list.get(0).setType(params.getiZtype()); // Type
        }
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsExcel", excelList);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectOrderSalesSummaryExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderSalesSummaryExcelDown.do")
    public NexacroResult selectOrderSalesSummaryExcelDown(@ParamDataSet(name="dsInput") OrderSalesSummaryVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        Map<String, Object> retMap = orderSalesSummaryService.selectOrderSalesSummary(loginInfo, params);
        
        OrderSalesSummaryVO excelList = (OrderSalesSummaryVO) retMap.get("head");
        @SuppressWarnings("unchecked")
        List<OrderSalesSummaryVO> list = (List<OrderSalesSummaryVO>) retMap.get("body");
   
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsExcel", excelList);
        result.addDataSet("dsOutput", list);
        
        return result;
    }    
}
