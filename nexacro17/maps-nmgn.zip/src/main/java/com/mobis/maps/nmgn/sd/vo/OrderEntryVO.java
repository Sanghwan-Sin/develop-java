package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;
import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderEntryVO.java
 * @Description : Order Entry
 * @author 홍민호
 * @since 2020. 2. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 19.     홍민호     	  최초 생성
 * </pre>
 */

public class OrderEntryVO extends MapsCommSapRfcIfCommVO {
    
    private String sortLvl = "0";
    

    /** I_TYPE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** AMEND CODE LAST */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAMDCL" )
    private String iZamdcl;
    /** ORDER HEAD FLAG CODE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZOHFCD" )
    private String iZohfcd;
    /** 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_E" )
    private String iZordnoE;
    /** 고객 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_P" )
    private String iZordnoP;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    
    
    /** Order Entry List */
    private List<OrderEntryVO> itResult = null;

    
//    -----[IT_RESULT] START-----
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZORDNO|ZORDNO" )
    private String zordno;
    /**  */
    
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZORDNO_P|ZORDNO_P" )
    private String zordnoP;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZORDNO_E|ZORDNO_E" )
    private String zordnoE;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="TYPE|TYPE" )
    private String type;
    /** Sales Organization */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="VKORG|VKORG" )
    private String vkorg;
    /** Distribution Channel */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="VTWEG|VTWEG" )
    private String vtweg;
    /** Division */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="SPART|SPART" )
    private String spart;
    /** Sales office */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="VKBUR|VKBUR" )
    private String vkbur;
    /** Sales group */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="VKGRP|VKGRP" )
    private String vkgrp;
    /** Customer Number */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="KUNNR|KUNNR" )
    private String kunnr;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZSACUTM|ZSACUTM" )
    private String zsacutm;
    /** Customer group 1 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="KVGR1|KVGR1" )
    private String kvgr1;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZORDTYP|ZORDTYP" )
    private String zordtyp;
    /** Shipping Type */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="VSART|VSART" )
    private String vsart;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZREM_NO|ZREM_NO" )
    private String zremNo;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZMESSAGE|ZMESSAGE" )
    private String zmessage;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZMEMO|ZMEMO" )
    private String zmemo;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZORDDT|ZORDDT" )
    private Date zorddt;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZCFMDT|ZCFMDT" )
    private Date zcfmdt;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZDLRDT|ZDLRDT" )
    private String zdlrdt;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZOHPCD|ZOHPCD" )
    private String zohpcd;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZOHFCD|ZOHFCD" )
    private String zohfcd;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZITEM_H|ZITEM_H" )
    private String zitemH;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZPCS_H|ZPCS_H" )
    private String zpcsH;
    /** SD document currency */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="WAERK|WAERK" )
    private String waerk;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZAMT_H|ZAMT_H" )
    private String zamtH;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZTAX_H|ZTAX_H" )
    private String ztaxH;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZTOTAMT_H|ZTOTAMT_H" )
    private String ztotamtH;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZCOMTY|ZCOMTY" )
    private String zcomty;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZORDLN|ZORDLN" )
    private String zordln;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZORDLS|ZORDLS" )
    private String zordls;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZMATNR_INPUT|ZMATNR_INPUT" )
    private String zmatnrInput;
    /** Material Number */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="MATNR|MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="MAKTX|MAKTX" )
    private String maktx;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZORDQTY|ZORDQTY" )
    private String zordqty;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZCFMQTY|ZCFMQTY" )
    private String zcfmqty;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZBOQTY|ZBOQTY" )
    private String zboqty;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZSUPQTY|ZSUPQTY" )
    private String zsupqty;
    /** Sales unit */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="VRKME|VRKME" )
    private String vrkme;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="NETPR|NETPR" )
    private String netpr;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZAMOUNT|ZAMOUNT" )
    private String zamount;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZAMDCL|ZAMDCL" )
    private String zamdcl;
    /** Number */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="CCNGN|CCNGN" )
    private String ccngn;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZIMEMO|ZIMEMO" )
    private String zimemo;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZODFCD|ZODFCD" )
    private String zodfcd;
    /** Character 100 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZCHKMSG|ZCHKMSG" )
    private String zchkmsg;
    private String zchkmsg2;
    /** HQ SUC */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZSUCCD|ZSUCCD" )
    private String zsuccd;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZSUCCD_NM|ZSUCCD_NM" )
    private String zsuccdNm;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZQUP|ZQUP" )
    private String zqup;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZQOP|ZQOP" )
    private String zqop;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="ZQFP|ZQFP" )
    private String zqfp;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="MTYPE|MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="MESSAGE|MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="MSGID|MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="I|E", fieldKey="MSGNO|MSGNO" )
    private String msgno;
//    -----[IT_RESULT] END-----
    
    
    
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZamdcl
     */
    public String getiZamdcl() {
        return iZamdcl;
    }
    /**
     * @param iZamdcl the iZamdcl to set
     */
    public void setiZamdcl(String iZamdcl) {
        this.iZamdcl = iZamdcl;
    }
    /**
     * @return the iZohfcd
     */
    public String getiZohfcd() {
        return iZohfcd;
    }
    /**
     * @param iZohfcd the iZohfcd to set
     */
    public void setiZohfcd(String iZohfcd) {
        this.iZohfcd = iZohfcd;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the iZordnoP
     */
    public String getiZordnoP() {
        return iZordnoP;
    }
    /**
     * @param iZordnoP the iZordnoP to set
     */
    public void setiZordnoP(String iZordnoP) {
        this.iZordnoP = iZordnoP;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the itResult
     */
    public List<OrderEntryVO> getItResult() {
        return itResult;
    }
    /**
     * @param itResult the itResult to set
     */
    public void setItResult(List<OrderEntryVO> itResult) {
        this.itResult = itResult;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the zordnoP
     */
    public String getZordnoP() {
        return zordnoP;
    }
    /**
     * @param zordnoP the zordnoP to set
     */
    public void setZordnoP(String zordnoP) {
        this.zordnoP = zordnoP;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the spart
     */
    public String getSpart() {
        return spart;
    }
    /**
     * @param spart the spart to set
     */
    public void setSpart(String spart) {
        this.spart = spart;
    }
    /**
     * @return the vkbur
     */
    public String getVkbur() {
        return vkbur;
    }
    /**
     * @param vkbur the vkbur to set
     */
    public void setVkbur(String vkbur) {
        this.vkbur = vkbur;
    }
    /**
     * @return the vkgrp
     */
    public String getVkgrp() {
        return vkgrp;
    }
    /**
     * @param vkgrp the vkgrp to set
     */
    public void setVkgrp(String vkgrp) {
        this.vkgrp = vkgrp;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the vsart
     */
    public String getVsart() {
        return vsart;
    }
    /**
     * @param vsart the vsart to set
     */
    public void setVsart(String vsart) {
        this.vsart = vsart;
    }
    /**
     * @return the zremNo
     */
    public String getZremNo() {
        return zremNo;
    }
    /**
     * @param zremNo the zremNo to set
     */
    public void setZremNo(String zremNo) {
        this.zremNo = zremNo;
    }
    /**
     * @return the zmemo
     */
    public String getZmemo() {
        return zmemo;
    }
    /**
     * @param zmemo the zmemo to set
     */
    public void setZmemo(String zmemo) {
        this.zmemo = zmemo;
    }
    /**
     * @return the zorddt
     */
    public Date getZorddt() {
        return zorddt;
    }
    /**
     * @param zorddt the zorddt to set
     */
    public void setZorddt(Date zorddt) {
        this.zorddt = zorddt;
    }
    /**
     * @return the zcfmdt
     */
    public Date getZcfmdt() {
        return zcfmdt;
    }
    /**
     * @param zcfmdt the zcfmdt to set
     */
    public void setZcfmdt(Date zcfmdt) {
        this.zcfmdt = zcfmdt;
    }
    /**
     * @return the zdlrdt
     */
    public String getZdlrdt() {
        return zdlrdt;
    }
    /**
     * @param zdlrdt the zdlrdt to set
     */
    public void setZdlrdt(String zdlrdt) {
        this.zdlrdt = zdlrdt;
    }
    /**
     * @return the zohpcd
     */
    public String getZohpcd() {
        return zohpcd;
    }
    /**
     * @param zohpcd the zohpcd to set
     */
    public void setZohpcd(String zohpcd) {
        this.zohpcd = zohpcd;
    }
    /**
     * @return the zohfcd
     */
    public String getZohfcd() {
        return zohfcd;
    }
    /**
     * @param zohfcd the zohfcd to set
     */
    public void setZohfcd(String zohfcd) {
        this.zohfcd = zohfcd;
    }
    /**
     * @return the zitemH
     */
    public String getZitemH() {
        return zitemH;
    }
    /**
     * @param zitemH the zitemH to set
     */
    public void setZitemH(String zitemH) {
        this.zitemH = zitemH;
    }
    /**
     * @return the zpcsH
     */
    public String getZpcsH() {
        return zpcsH;
    }
    /**
     * @param zpcsH the zpcsH to set
     */
    public void setZpcsH(String zpcsH) {
        this.zpcsH = zpcsH;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the zamtH
     */
    public String getZamtH() {
        return zamtH;
    }
    /**
     * @param zamtH the zamtH to set
     */
    public void setZamtH(String zamtH) {
        this.zamtH = zamtH;
    }
    /**
     * @return the ztaxH
     */
    public String getZtaxH() {
        return ztaxH;
    }
    /**
     * @param ztaxH the ztaxH to set
     */
    public void setZtaxH(String ztaxH) {
        this.ztaxH = ztaxH;
    }
    /**
     * @return the ztotamtH
     */
    public String getZtotamtH() {
        return ztotamtH;
    }
    /**
     * @param ztotamtH the ztotamtH to set
     */
    public void setZtotamtH(String ztotamtH) {
        this.ztotamtH = ztotamtH;
    }
    /**
     * @return the zcomty
     */
    public String getZcomty() {
        return zcomty;
    }
    /**
     * @param zcomty the zcomty to set
     */
    public void setZcomty(String zcomty) {
        this.zcomty = zcomty;
    }
    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zordls
     */
    public String getZordls() {
        return zordls;
    }
    /**
     * @param zordls the zordls to set
     */
    public void setZordls(String zordls) {
        this.zordls = zordls;
    }
    /**
     * @return the zmatnrInput
     */
    public String getZmatnrInput() {
        return zmatnrInput;
    }
    /**
     * @param zmatnrInput the zmatnrInput to set
     */
    public void setZmatnrInput(String zmatnrInput) {
        this.zmatnrInput = zmatnrInput;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zordqty
     */
    public String getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(String zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zcfmqty
     */
    public String getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(String zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zsupqty
     */
    public String getZsupqty() {
        return zsupqty;
    }
    /**
     * @param zsupqty the zsupqty to set
     */
    public void setZsupqty(String zsupqty) {
        this.zsupqty = zsupqty;
    }
    /**
     * @return the vrkme
     */
    public String getVrkme() {
        return vrkme;
    }
    /**
     * @param vrkme the vrkme to set
     */
    public void setVrkme(String vrkme) {
        this.vrkme = vrkme;
    }
    /**
     * @return the netpr
     */
    public String getNetpr() {
        return netpr;
    }
    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(String netpr) {
        this.netpr = netpr;
    }
    /**
     * @return the zamount
     */
    public String getZamount() {
        return zamount;
    }
    /**
     * @param zamount the zamount to set
     */
    public void setZamount(String zamount) {
        this.zamount = zamount;
    }
    /**
     * @return the zamdcl
     */
    public String getZamdcl() {
        return zamdcl;
    }
    /**
     * @param zamdcl the zamdcl to set
     */
    public void setZamdcl(String zamdcl) {
        this.zamdcl = zamdcl;
    }
    /**
     * @return the ccngn
     */
    public String getCcngn() {
        return ccngn;
    }
    /**
     * @param ccngn the ccngn to set
     */
    public void setCcngn(String ccngn) {
        this.ccngn = ccngn;
    }
    /**
     * @return the zimemo
     */
    public String getZimemo() {
        return zimemo;
    }
    /**
     * @param zimemo the zimemo to set
     */
    public void setZimemo(String zimemo) {
        this.zimemo = zimemo;
    }
    /**
     * @return the zodfcd
     */
    public String getZodfcd() {
        return zodfcd;
    }
    /**
     * @param zodfcd the zodfcd to set
     */
    public void setZodfcd(String zodfcd) {
        this.zodfcd = zodfcd;
    }
    /**
     * @return the zchkmsg
     */
    public String getZchkmsg() {
        return zchkmsg;
    }
    /**
     * @param zchkmsg the zchkmsg to set
     */
    public void setZchkmsg(String zchkmsg) {
        this.zchkmsg = zchkmsg;
    }
    /**
     * @return the zsuccd
     */
    public String getZsuccd() {
        return zsuccd;
    }
    /**
     * @param zsuccd the zsuccd to set
     */
    public void setZsuccd(String zsuccd) {
        this.zsuccd = zsuccd;
    }
    /**
     * @return the zsuccdNm
     */
    public String getZsuccdNm() {
        return zsuccdNm;
    }
    /**
     * @param zsuccdNm the zsuccdNm to set
     */
    public void setZsuccdNm(String zsuccdNm) {
        this.zsuccdNm = zsuccdNm;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public String getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(String msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the zmessage
     */
    public String getZmessage() {
        return zmessage;
    }
    /**
     * @param zmessage the zmessage to set
     */
    public void setZmessage(String zmessage) {
        this.zmessage = zmessage;
    }
    /**
     * @return the zqup
     */
    public String getZqup() {
        return zqup;
    }
    /**
     * @param zqup the zqup to set
     */
    public void setZqup(String zqup) {
        this.zqup = zqup;
    }
    /**
     * @return the zqop
     */
    public String getZqop() {
        return zqop;
    }
    /**
     * @param zqop the zqop to set
     */
    public void setZqop(String zqop) {
        this.zqop = zqop;
    }
    /**
     * @return the zqfp
     */
    public String getZqfp() {
        return zqfp;
    }
    /**
     * @param zqfp the zqfp to set
     */
    public void setZqfp(String zqfp) {
        this.zqfp = zqfp;
    }
    /**
     * @return the zchkmsg2
     */
    public String getZchkmsg2() {
        return zchkmsg2;
    }
    /**
     * @param zchkmsg2 the zchkmsg2 to set
     */
    public void setZchkmsg2(String zchkmsg2) {
        this.zchkmsg2 = zchkmsg2;
    }
    /**
     * @return the sortLvl
     */
    public String getSortLvl() {
        return sortLvl;
    }
    /**
     * @param sortLvl the sortLvl to set
     */
    public void setSortLvl(String sortLvl) {
        this.sortLvl = sortLvl;
    }
    
}
