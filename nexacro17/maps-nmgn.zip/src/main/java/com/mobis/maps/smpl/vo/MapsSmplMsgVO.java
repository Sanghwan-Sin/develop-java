package com.mobis.maps.smpl.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSampleSapRsltVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 16.     Sin Sanghwan     	최초 생성
 * </pre>
 */

public class MapsSmplMsgVO extends MapsCommSapRfcIfCommVO {

    private String werks;
    
    private String lgort;
    private String lgobe;
    private String lifnr;
    private String kunnr;
    private String menge;
    private String meins;
    private String netpr;
    private String waers;
    private String datum;
    private String uzeit;
    private String datlo;
    private String timlo;

    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }

    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }

    /**
     * @return the lgort
     */
    public String getLgort() {
        return lgort;
    }

    /**
     * @param lgort the lgort to set
     */
    public void setLgort(String lgort) {
        this.lgort = lgort;
    }

    /**
     * @return the lgobe
     */
    public String getLgobe() {
        return lgobe;
    }

    /**
     * @param lgobe the lgobe to set
     */
    public void setLgobe(String lgobe) {
        this.lgobe = lgobe;
    }

    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }

    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }

    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }

    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }

    /**
     * @return the menge
     */
    public String getMenge() {
        return menge;
    }

    /**
     * @param menge the menge to set
     */
    public void setMenge(String menge) {
        this.menge = menge;
    }

    /**
     * @return the meins
     */
    public String getMeins() {
        return meins;
    }

    /**
     * @param meins the meins to set
     */
    public void setMeins(String meins) {
        this.meins = meins;
    }

    /**
     * @return the netpr
     */
    public String getNetpr() {
        return netpr;
    }

    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(String netpr) {
        this.netpr = netpr;
    }

    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }

    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }

    /**
     * @return the datum
     */
    public String getDatum() {
        return datum;
    }

    /**
     * @param datum the datum to set
     */
    public void setDatum(String datum) {
        this.datum = datum;
    }

    /**
     * @return the uzeit
     */
    public String getUzeit() {
        return uzeit;
    }

    /**
     * @param uzeit the uzeit to set
     */
    public void setUzeit(String uzeit) {
        this.uzeit = uzeit;
    }

    /**
     * @return the datlo
     */
    public String getDatlo() {
        return datlo;
    }

    /**
     * @param datlo the datlo to set
     */
    public void setDatlo(String datlo) {
        this.datlo = datlo;
    }

    /**
     * @return the timlo
     */
    public String getTimlo() {
        return timlo;
    }

    /**
     * @param timlo the timlo to set
     */
    public void setTimlo(String timlo) {
        this.timlo = timlo;
    }
}
