package com.mobis.maps.nmgn.ex.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.vo.PackingHeaderVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingHeaderService.java
 * @Description : ZJEXR00160 Packing Header
 * @author 이수지
 * @since 2020. 2. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 3.       이수지      	        최초 생성
 * </pre>
 */

public interface PackingHeaderService {

    /**
     * Packing Header
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<PackingHeaderVO> selectPackingHeader (LoginInfoVO loginVo, PackingHeaderVO params) throws Exception;
}
