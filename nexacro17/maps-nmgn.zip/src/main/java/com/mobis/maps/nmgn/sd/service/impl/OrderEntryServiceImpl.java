package com.mobis.maps.nmgn.sd.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.comm.service.dao.MapsCommCodeMDAO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.OrderEntryService;
import com.mobis.maps.nmgn.sd.vo.OrderCanvassNoVO;
import com.mobis.maps.nmgn.sd.vo.OrderEntryVO;
import com.mobis.maps.nmgn.sd.vo.OrderMatnrValidateMultiVO;
import com.mobis.maps.nmgn.sd.vo.OrderShipModeVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderEntryServiceImpl.java
 * @Description : ZJSDO30240 Order Placement
 * @author 홍민호
 * @since 2020. 2. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 20.     홍민호        최초 생성
 * </pre>
 */

@Service("orderEntryService")
public class OrderEntryServiceImpl extends HService implements OrderEntryService {

    private final static String PLANT_ID_H = "1602"; // TODO : Plant 번호 - H
    private final static String PLANT_ID_K = "1603"; // TODO : Plant 번호 - K
    private final static String CD_ORDER_TYPE_PUBL = "G"; // Publication Order Type
    
    
    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    @Resource(name="mapsCommCodeMDAO")
    private MapsCommCodeMDAO mapsCommCodeMDAO;
    
    /* 
     * @see com.mobis.maps.nmgn.sd.service.OrderEntryService#selectOrderEntry(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderEntryVO)
     */
    @Override
    public List<OrderEntryVO> selectOrderEntry(LoginInfoVO loginVo, OrderEntryVO params) throws Exception {
        
        // Paging 없음
        params.setPgType("S");
        
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        params.setiType("R"); // Select
        
        // 조회 시 해당 대리점 코드 조건 추가 (타대리점 오더 조회 방지)
        if (!StringUtils.isBlank(params.getZsacutm())) {
            params.setiZsacutm(params.getZsacutm());
        }

        //*** 공통파라미터(Import) 셋팅
        if (logger.isDebugEnabled()) {logger.debug("*** 공통파라미터(Import) 셋팅 ");}
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** 파라미터(Import) 셋팅
        if (logger.isDebugEnabled()) {logger.debug("*** 파라미터(Import) 셋팅");}
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        if (logger.isDebugEnabled()) {logger.debug("*** RFC 호출");}
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        if (logger.isDebugEnabled()) {logger.debug("*** RFC 호출결과 정보 추출");}
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        if (logger.isDebugEnabled()) {logger.debug("*** params.getMsgType():" + params.getMsgType());}
        
        if ("E".equals(params.getMsgType())) {
            return null;
        }
        
        //*** 조회결과
        List<OrderEntryVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_RESULT", params, OrderEntryVO.class);

        if (list == null) return list;
        
        // 오더 수량 String 포맷팅 제거 (오류 방어)
        for(OrderEntryVO vo : list) {
            if (vo == null) continue;
            vo.setZordqty(StringUtils.trimToEmpty(vo.getZordqty()).replaceAll("\\D", ""));
        }

        return list;
    
    }

    
    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderEntryService#saveOrderEntry(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderEntryVO)
     */
    @Override
    public List<OrderEntryVO> multiSaveOrderEntry(LoginInfoVO loginVo, OrderEntryVO params, List<OrderEntryVO> paramLst) throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
      
        // Order List(IT_RESULT) 적재
        for(OrderEntryVO vo : paramLst) {
            if (StringUtils.isBlank(vo.getZmatnrInput())) continue; // 빈줄 건 skip
            
            MapsRfcMappperUtil.appendImportTableRow(func, "IT_RESULT", vo);
        }
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 처리결과
        List<OrderEntryVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_RESULT", params, OrderEntryVO.class);


        return list;
    }


    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderEntryService#selectOrderMatnrChk(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderEntryVO, java.util.List)
     */
    @Override
    public List<OrderEntryVO> selectOrderMatnrChk(LoginInfoVO loginVo, OrderEntryVO params, List<OrderEntryVO> paramLst)
            throws MapsBizException, Exception {
        
        OrderMatnrValidateMultiVO vo = new OrderMatnrValidateMultiVO();
        Map<String, Long> dupMap = new HashMap<String, Long>();
        
        if (paramLst == null || paramLst.size() <= 0) {
            if (logger.isDebugEnabled()) logger.debug("##### No Part items to Check. End.");
            return null;
        }

        if (logger.isDebugEnabled()) {logger.debug("###### Order Type : " + params.getZordtyp());}
        
        // params setting
        vo.setiVkorg(params.getVkorg()); // 영업 조직
        vo.setiVtweg(params.getVtweg()); // 유통 경로
        vo.setiZhkcd(params.getKvgr1()); // H/K
        vo.setiWerks("H".equals(vo.getiZhkcd()) ? PLANT_ID_H : PLANT_ID_K);
        vo.setiZordtyp(params.getZordtyp()); // Order Type
        vo.setiZsacutm(params.getZsacutm()); // dist.cd
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_MATERIAL_VALIDATE2;
        
        vo.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, vo);
        
        
        
        // *** 목록 Line No로 Sort 후 시작
        paramLst.sort(new Comparator<OrderEntryVO>() {
            @Override
            public int compare(OrderEntryVO arg0, OrderEntryVO arg1) {
                if (arg0 == null || arg1 == null) return 0;
                
                String val0 = StringUtils.trimToEmpty(arg0.getZordln());
                String val1 = StringUtils.trimToEmpty(arg1.getZordln());
                
                val0 = (val0.length() == 0 ? "zzzz" : val0);
                val1 = (val1.length() == 0 ? "zzzz" : val1);
                
                return val0.compareTo(val1);
            }
        });        
        
        // Line No Max 값 추출
        OrderEntryVO maxItem =
        Collections.max(paramLst, new Comparator<OrderEntryVO>() {
            @Override
            public int compare(OrderEntryVO arg0, OrderEntryVO arg1) {
                if (arg0 == null || arg1 == null) return 0;
                
                String val0 = StringUtils.trimToEmpty(arg0.getZordln());
                String val1 = StringUtils.trimToEmpty(arg1.getZordln());
                
                return val0.compareTo(val1);
            }
        });
        
        int nMax = this.selectParseIntLine(maxItem);

        
        // 부품번호(IT_MATNR) 적재
        JCoTable jcoTbl = func.getImportTableParameter("IT_MATNR");
        for(OrderEntryVO item : paramLst) {
            
            if (item == null) continue;
            if (StringUtils.isBlank(item.getZmatnrInput())) continue; // 빈줄 건 skip
            if ("D".equals(item.getRowSe())) continue; // 삭제대상
            if (!StringUtils.isBlank(item.getMatnr())) continue; // 기등록건 제외
            
            // Line 번호 채번
            if (StringUtils.isBlank(item.getZordln())) {
                item.setZordln(StringUtils.leftPad(String.valueOf(++nMax), 4, "0"));
            }
                
            // 부번의 space 모두 제거
            item.setZmatnrInput(item.getZmatnrInput().replaceAll("\\s", ""));
            
            jcoTbl.appendRow();
            jcoTbl.setValue("MATNR", item.getZmatnrInput());
        }        

        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
      
        //*** RFC 호출결과 정보 추출
        /*
         * MTYPE => msgType
         * MESSAGE => msg
         */
        mapsCmmnSapService.selectSetRfcResult(funcRslt, vo);
        if (logger.isDebugEnabled()) {
            logger.debug("#### 부번체크 호출 결과 : " + vo.getMsgType() + " / " + vo.getMsg());
        }
        
        if ("E".equals(vo.getMsgType())) {
            throw new MapsBizException(vo.getMsg());
        }
        
        
        //*** 체크결과 Table
        List<Map<String, Object>> rsltLst = funcRslt.getTable("IT_MATNR");
        int rnum = 0;
        
        
        // Part Item List
        for(int idx = 0; idx < paramLst.size(); idx++) {
            OrderEntryVO item = paramLst.get(idx);
            
            if (item == null) continue;
            if (StringUtils.isBlank(item.getZmatnrInput())) continue;
            if ("D".equals(item.getRowSe())) continue; // 삭제대상

            // *** 중복 체크
            Long dupCnt = dupMap.get(item.getZmatnrInput());
            if (dupCnt == null || dupCnt == 0) {
                dupCnt = new Long(1);
            } else {
                dupCnt ++;
            }
            dupMap.put(item.getZmatnrInput(), dupCnt);

            
            if (!StringUtils.isBlank(item.getMatnr())) continue; // 기등록건 skip
            
            
            Map<String, Object> rsltObj = rsltLst.get(rnum++);
            
            if (!item.getZmatnrInput().equals((String)rsltObj.get("MATNR"))) {
                logger.error("#### ERROR : Result List mapping failed. (" + item.getZmatnrInput() + "/" + rsltObj.get("MATNR") + ")");
                continue;
            }
            
            item.setMsgType((String)rsltObj.get("MTYPE"));
            item.setMsg((String)rsltObj.get("MESSAGE"));
            item.setChkYn("N");

            
            // *** 상태보정
//            switch (item.getRowSe()) {
//                case "C" :
//                case "I" :
//                    item.setRowType(2); // DataSet.ROW_TYPE_INSERTED);
//                    break;
//                case "U" :
//                    item.setRowType(4); // DataSet.ROW_TYPE_UPDATED);
//                    break;
//                case "D" :
//                    item.setRowType(8); // DataSet.ROW_TYPE_DELETED);
//                    break;
//                default :
//                    item.setRowType(1); // DataSet.ROW_TYPE_NORMAL);
//            }
            
            
            // *** 체크결과오류
            if ("E".equals(item.getMsgType())) { // 오류
                item.setZchkmsg(StringUtils.isBlank(item.getMsg()) ? "FAIL" : item.getMsg());
                item.setZchkmsg2("<fc v='red'>" + item.getZchkmsg() + "</fc>"); // styled message
                item.setChkYn("Y");
                
                continue;
            }
            
            // *** 체크결과 성공
            item.setMsgType("S");
            item.setZchkmsg(StringUtils.isBlank(item.getMsg()) ? "OK" : item.getMsg());
            item.setZchkmsg2(item.getZchkmsg());
            item.setMaktx((String)rsltObj.get("ZPTNM")); // 명칭
            item.setVrkme((String)rsltObj.get("MEINS")); // 단위
            item.setZqop((String)rsltObj.get("ZQOP")); // QMP
            
            item.setZsuccd((String)rsltObj.get("ZSUCCD")); // SUC
            item.setZsuccdNm((String)rsltObj.get("ZSUCCD_NM")); // SUC Desc.

            
            // *** Publication Order 체크 : Catalog Item이 아니면 오류 처리
            if (CD_ORDER_TYPE_PUBL.equals(params.getZordtyp())
                    && StringUtils.isBlank(item.getZremNo())) { // 근거번호 (canvass no) 없으면 오류처리
                if(logger.isDebugEnabled()) {logger.debug("### Publication Order - Invalid item : " + item.getZmatnrInput());}
                
                item.setMsgType("E");
                item.setZchkmsg(MessageUtil.getMessage("EMM0000002", new String[]{}, loginVo.getUserLcale())); // EMM0000002 해당 카탈로그에서 추가한 아이템이 아님
                item.setZchkmsg2("<fc v='red'>" + item.getZchkmsg() + "</fc>"); // styled message
                item.setChkYn("Y");
                item.setSortLvl("1");
                
                continue;
            }
            
            // *** 중복 체크
            if (dupCnt > 1 && !"E".equals(item.getMsgType())) {
//                item.setMsgType("E");
                item.setZchkmsg(MessageUtil.getMessage("WCM0000002", new String[]{}, loginVo.getUserLcale())); // 중복 메시지
                item.setZchkmsg2(item.getZchkmsg()); // styled message
//                item.setChkYn("Y");
//                item.setSortLvl("2");

//                continue;
            }
            
            // *** 수량 체크
            if (this.selectToNumber(item.getZordqty()) <= 0
                    && !"E".equals(item.getMsgType())) {
                item.setMsgType("E");
                //item.setChkYn("Y");

                // Quantity 용어 가져오기
                MapsCommCodeVO codeVo = new MapsCommCodeVO();
                codeVo.setCboDfltId("W0000002860"); // W0000002860 Quantity
                codeVo.setLangCd(loginVo.getLangCd());
                String sQuantityTmp = mapsCommCodeMDAO.selectCodeWordNm(codeVo);    
                
                // 수량 오류 메시지  - EC00000014 {0} must be greater than {1}
                item.setZchkmsg(MessageUtil.getMessage("EC00000014", new String[]{sQuantityTmp, "0"}, loginVo.getUserLcale()));
                item.setZchkmsg2("<fc v='blue'>" + item.getZchkmsg() + "</fc>"); // styled message
                item.setSortLvl("9");
            
                continue;
            }

            
        } // END-FOR
        
        
        // *** Sort : 오류건 위로
        paramLst.sort(new Comparator<OrderEntryVO>() {
            @Override
            public int compare(OrderEntryVO arg0, OrderEntryVO arg1) {
                if (arg0 == null || arg1 == null) return 0;
                
                String val0 = arg0.getMsgType() + arg0.getSortLvl() + StringUtils.trimToEmpty(arg0.getZchkmsg());
                String val1 = arg1.getMsgType() + arg1.getSortLvl() + StringUtils.trimToEmpty(arg1.getZchkmsg());
                
                return val0.compareTo(val1);
            }
        });
        
        
        return paramLst;
    }




    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderEntryService#selectOrderEntryTxtUpload(com.mobis.maps.cmmn.vo.LoginInfoVO, java.io.File)
     */
    @Override
    public List<OrderEntryVO> selectOrderEntryTxtUpload(LoginInfoVO loginVo, File fUp) throws Exception {
        
        if (fUp == null) {
            throw new MapsBizException(this.messageSource, "WC00000015", loginVo.getUserLcale(), null); // WC00000015 업로드된 파일이 없습니다. There are no uploaded files.
        }
        
        long nSize = FileUtils.sizeOf(fUp);
        if (nSize > (1024 * 1024)) {
            throw new MapsBizException(this.messageSource, "WC00000016", new String[]{"1Mbyte"}, loginVo.getUserLcale(), null); // WC00000016 업로드 파일의 최대 크기는 1Mbyte로 제한됩니다.  The maximum size of upload file is limited to 1Mbyte.
        }

        if (fUp.getName().toUpperCase().matches(".+\\.TXT")) {
            throw new MapsBizException(this.messageSource, "WC00000017", loginVo.getUserLcale(), null); // WC00000017 TXT 파일만 업로드할 수 있습니다. TXT 파일을 선택해 주세요. Only TXT files can be uploaded. Please select a TXT file.
        }
        
        byte[] binData = FileUtils.readFileToByteArray(fUp);
        
        for(int idx = 0; binData != null && idx < binData.length; idx++) {
            if (binData[idx] < 0x09) {
                if(logger.isDebugEnabled()){logger.debug("##### [TXT Upload] Binary file uploaded.");}
                throw new MapsBizException(this.messageSource, "WC00000017", loginVo.getUserLcale(), null); // WC00000017 TXT 파일만 업로드할 수 있습니다. TXT 파일을 선택해 주세요. Only TXT files can be uploaded. Please select a TXT file.
            }
        }

        // File read
//        String inputStr = FileUtils.readFileToString(fUp);
        String inputStr = new String(binData);
        
        /**
         * 파일구조
         * OrderType\tOrderNo\tno\tpartNo\tqty
         */
        
        // vo list구성
        List<OrderEntryVO> itemLst = this.selectExportTxtValues(inputStr);
        if(logger.isDebugEnabled()){
            logger.debug(" vo Size :",itemLst.size());
        }

        return itemLst;
    }


    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderEntryService#selectCanvassNoLst(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderEntryVO)
     */
    @Override
    public List<OrderCanvassNoVO> selectCanvassNoLst(LoginInfoVO loginVo, OrderCanvassNoVO params) throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_CANVASS_NO;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
      
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 처리결과
        List<OrderCanvassNoVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, OrderCanvassNoVO.class);
        
        
        if (list == null) {return null;}
        
        // 화면 display 용 세팅
        StringBuffer sBuf = new StringBuffer();
        for (OrderCanvassNoVO vo: list) {
            
            sBuf.delete(0, sBuf.length());sBuf.setLength(0);
            sBuf.append(vo.getZcanvno()).append(" : ").append(vo.getZcanvnm());
            
            vo.setCanvassDesc(sBuf.toString());
        }
        
        return list;
    }


    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderEntryService#selectShipMode(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderShipModeVO)
     */
    @Override
    public List<OrderShipModeVO> selectShipMode(LoginInfoVO loginVo, OrderShipModeVO params) throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_SHIPMODE;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
      
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        if ("E".equals(params.getMsgType())) {
            return null;
        }
        
        //*** 처리결과
        List<OrderShipModeVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_RESULT", params, OrderShipModeVO.class);
        
        return list;
    }

    
    
    /**
     * Statements
     *
     * @param inputTxt
     * @return
     * @throws Exception
     */
    private List<OrderEntryVO> selectExportTxtValues(String inputTxt) throws Exception {        
        
        if (StringUtils.isEmpty(inputTxt)) {
            return null;
        }
        
        String[] strInputSplit = StringUtils.split(inputTxt, "\n");
        if (strInputSplit.length < 1) {
            return null;
        }
        
        List<OrderEntryVO> vos = new ArrayList<OrderEntryVO>();
        
        for(int i = 0 ; i < strInputSplit.length ; i++){
            String splitStr = StringUtils.trim(strInputSplit[i]);
            
            if (splitStr == null) continue;
            
            String[] items = StringUtils.split(splitStr , "\t");
            
            if (items == null || items.length <= 0) continue;
            
            
            OrderEntryVO item = new OrderEntryVO();
            
            /**
             *  OrderType\tOrderNo\tno\tpartNo\tqty
             */

            item.setZordtyp(items[0]); // Order Type
            
            // Order No
            if (items.length > 1) {item.setZordnoE(items[1]); }
            
            // no
            
            // Part No
            if (items.length > 3) {item.setZmatnrInput(items[3]); }
            
            // QTY
            if (items.length > 4) {item.setZordqty(items[4]); }
            
            
            if (StringUtils.isBlank(item.getZmatnrInput())) {
                if (logger.isDebugEnabled()) {
                    logger.debug("##### [TXT Upload] Invalid order item data. skipped. (" + StringUtils.substring(items[0], 0, 10) + " ...)");
                }

            } else {
                vos.add(item);
            }
            
        }
        
        return vos;
    }    

    
    /**
     * Statements
     *
     * @param val
     * @return
     * @throws Exception
     */
    private int selectToNumber(String val) throws Exception {
        int rslt = 0;
        
        if (StringUtils.isBlank(val)) return rslt;
        
        try {
            rslt = Integer.parseInt(val.trim());
        } catch (Exception e1) {
            rslt = 0;
        }
        
        return rslt;
    }


    
    /**
     * 아이템의 Line 값을 integer로 변환하여 리턴
     *
     * @param item
     * @return
     * @throws Exception
     */
    private int selectParseIntLine(OrderEntryVO item) throws Exception {
        if (item == null) return 0;
        
        return this.selectToNumber(item.getZordln());
    }

}

