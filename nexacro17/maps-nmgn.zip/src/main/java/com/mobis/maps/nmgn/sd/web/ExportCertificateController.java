package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.vo.SearchInfoVO;
import com.mobis.maps.nmgn.sd.service.ExportCertificateService;
import com.mobis.maps.nmgn.sd.vo.CertificateRequestVO;
import com.mobis.maps.nmgn.sd.vo.CertificateVO;
import com.mobis.maps.nmgn.sd.vo.ExportCertificateVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ExportCertificateController.java
 * @Description : ZJSDO80150 Export Certificate Search & Download
 * @author 이수지
 * @since 2020. 08. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 08. 20.       이수지                최초 생성
 * </pre>
 */

@Controller
public class ExportCertificateController extends HController {

    @Resource(name = "exportCertificateService")
    private ExportCertificateService exportCertificateService;

    /**
     * selectcertificate
     */
    @RequestMapping(value = "/sd/selectcertificate.do")
    public NexacroResult selectcertificate(NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<CertificateVO> list = exportCertificateService.selectcertificate(loginInfo);
        
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectExportCertificate
     *
     * @param params
     * @param results
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectExportCertificate.do")
    public NexacroResult selectExportCertificate(@ParamDataSet(name="dsInput") ExportCertificateVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<ExportCertificateVO> list = exportCertificateService.selectExportCertificate(loginInfo, params);
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectCanvassListExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectExportCertificateExcelDown.do")
    public NexacroResult selectExportCertificateExcelDown(@ParamDataSet(name="dsInput") ExportCertificateVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<ExportCertificateVO> list = exportCertificateService.selectExportCertificate(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectCertificateDoc
     */
    @RequestMapping(value = "/sd/selectCertificateDoc.do")
    public NexacroResult selectCertificateDoc(NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<CertificateRequestVO> list = exportCertificateService.selectCertificateDoc(loginInfo);
        
        result.addDataSet("dsOutput", list);
        
        return result;
    }    
    
    /**
     * selectcertificateChk
     */
    @RequestMapping(value = "/sd/selectcertificateChk.do")
    public NexacroResult selectcertificateChk(@ParamDataSet(name="dsInput") CertificateRequestVO params
                                            , @ParamDataSet(name="dsInput2") List<CertificateRequestVO> paramList
                                            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<CertificateRequestVO> list = exportCertificateService.selectcertificateChk(loginInfo, params, paramList);
      
        result.addDataSet("dsOutput", list);

        return result;
    }    
    
    /**
     * selectCertificateRequestList
     *
     * @param params
     * @param results
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectCertificateRequestList.do")
    public NexacroResult selectCertificateRequestList(@ParamDataSet(name="dsInput") CertificateRequestVO params
                                                    , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = exportCertificateService.selectCertificateRequestList(loginInfo, params);
        
        CertificateRequestVO retList1 = (CertificateRequestVO)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<CertificateRequestVO> retList2 = (List<CertificateRequestVO>)retMap.get("body1");
        @SuppressWarnings("unchecked")
        List<CertificateRequestVO> retList3 = (List<CertificateRequestVO>)retMap.get("body2");        
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput1", retList1);
        result.addDataSet("dsOutput2", retList2);
        result.addDataSet("dsOutput3", retList3);
        
        return result;
    }
    
    /**
     * multiCertificateRequest
     *
     * @param params
     * @param results
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/multiCertificateRequest.do")
    public NexacroResult multiCertificateRequest(@ParamDataSet(name="dsInput") CertificateRequestVO paramVO
                                               , @ParamDataSet(name="dsInput1") CertificateRequestVO paramHead    
                                               , @ParamDataSet(name="dsInput2") List<CertificateRequestVO> paramDetail      
                                               , @ParamDataSet(name="dsInput3") List<CertificateRequestVO> paramList
                                               , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = exportCertificateService.multiCertificateRequest(paramVO, paramHead, paramDetail, paramList, loginInfo);
        
        CertificateRequestVO retVO = (CertificateRequestVO)retMap.get("head");
      
        result.addDataSet("dsOutput", retVO);      

        return result;
    }
   
    /***
     * 플렌트/사급업체/제품업체/국가코드 조회
     * Statements
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectVendorList.do")
    public NexacroResult selectVendorList(@ParamDataSet(name="dsInput") SearchInfoVO paramVO
                                              , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> rsltMap = exportCertificateService.selectVendorList(loginInfo, paramVO);

        if (rsltMap != null) {
            SearchInfoVO esReturn = (SearchInfoVO)rsltMap.get("esReturn");
            @SuppressWarnings("unchecked")
            List<SearchInfoVO> etData = (List<SearchInfoVO>)rsltMap.get("etData");
            
            result.addDataSet("dsEsRetrun", esReturn);
            result.addDataSet("dsOutput", etData);
        }

        return result;
    }
}
