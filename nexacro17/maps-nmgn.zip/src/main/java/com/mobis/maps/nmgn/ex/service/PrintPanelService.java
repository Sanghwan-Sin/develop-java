package com.mobis.maps.nmgn.ex.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.vo.PrintPanelVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PrintPanelService.java
 * @Description : ZPEXF00290 Print Panel
 * @author 이수지
 * @since 2020. 06. 03.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 03.      이수지      	        최초 생성
 * </pre>
 */

public interface PrintPanelService {

    /**
     * selectShippingAdviceImageFile
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<PrintPanelVO> selectShippingAdviceImageFile (LoginInfoVO loginVo, PrintPanelVO params) throws Exception;

    /**
     * selectPrintPanel
     *
     * @param loginInfo
     * @param params
     * @return
     */
    Map<String, Object> selectPrintPanel(LoginInfoVO loginInfo, PrintPanelVO params) throws Exception;
}
