package com.mobis.maps.nmgn.ex.service.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsFileDwnlException;
import com.mobis.maps.cmmn.util.FiexedFieldLenVoToStringUtil;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ex.service.InvoiceFileDlService;
import com.mobis.maps.nmgn.ex.vo.InvoiceFileDlVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFileInfoVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingHeaderServiceImpl.java
 * @Description : ZJEXR00300 Packing Header
 * @author 이수지
 * @since 2020. 07. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 07. 27.       이수지      	        최초 생성
 * </pre>
 */

@Service("invoiceFileDlService")
public class InvoiceFileDlServiceImpl extends HService implements InvoiceFileDlService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    @Resource(name = "mapsCommFileService")
    private MapsCommFileService mapsCommFileService;
    
    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceFileDlService#selectInvoiceFileDl(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.AirInvoiceVO)
     */
    @Override
    public List<InvoiceFileDlVO> selectInvoiceFileDl(LoginInfoVO loginVo, InvoiceFileDlVO params)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_INVOICE_FILE_LIST;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        
        //*** 조회결과
        List<InvoiceFileDlVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", params, InvoiceFileDlVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceFileDlService#selectInvoiceFileDlInfo(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ex.vo.InvoiceFileInfoVO)
     */
    @Override
    public Map<String, Object> selectInvoiceFileDlInfo(LoginInfoVO loginVo, List<InvoiceFileInfoVO> paramList) throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
        InvoiceFileInfoVO paramVO = new InvoiceFileInfoVO();
        
        FunctionResult funcRslt = null;
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_INVOICE_FILE_DOWNLOAD;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, paramVO);
        
        /* RFC 파라미터(Import) 셋팅 */
        
        JCoTable jcoTbl = func.getImportTableParameter("IT_INVOICE");
        
        for (InvoiceFileInfoVO item : paramList) {
            jcoTbl.appendRow();
            jcoTbl.setValue("INVOICE", item.getInvoice());
        }
        
        // RFC 호출 실행
        funcRslt = mapsCmmnSapService.selectExecute(loginVo, func, true);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        // 개별데이타 저장
        MapsRfcMappperUtil.setExportParamList(funcRslt, paramVO, loginVo.getUserLcale());
        List<InvoiceFileInfoVO> list = MapsRfcMappperUtil.getExportTableResultValues(funcRslt, "ET_LIST", InvoiceFileInfoVO.class);
                       
        
        retMap.put("body", list);
        retMap.put("excel", paramVO);
        
        return retMap;
    }

    /*
     * @see com.mobis.maps.nmgn.ex.service.InvoiceFileDlService#selectInvoiceTxtDownload(com.mobis.maps.cmmn.vo.LoginInfoVO, java.lang.String[], java.lang.String, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void selectInvoiceTxtDownload(LoginInfoVO loginInfo, String[] invoiceNo, String fileName,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        
        List<InvoiceFileInfoVO> paramList =  new ArrayList<InvoiceFileInfoVO>();
                
        for (int idx = 0; idx < invoiceNo.length; idx++) {
            InvoiceFileInfoVO vo = new InvoiceFileInfoVO();
            vo.setInvoice(invoiceNo[idx]);
            paramList.add(vo);
        }
        
        Map<String, Object> retMap = selectInvoiceFileDlInfo(loginInfo, paramList);
        
        @SuppressWarnings("unchecked")
        List<InvoiceFileInfoVO> invoiceFile = (List<InvoiceFileInfoVO>)retMap.get("body");
        InvoiceFileInfoVO excelVo = (InvoiceFileInfoVO)retMap.get("excel");
        
        /** util 초기화 **/
        FiexedFieldLenVoToStringUtil convertUtil = new FiexedFieldLenVoToStringUtil();

        /** fixed length 정의 **/
        String[] rowDefinition = new String[] {
            "invoice,0~10"             ,"invDate,10~18,date"       ,"zfptld,18~33"              ,"zfpldv,33~48"                 ,"zshptp,48~49"
           ,"zfcarnm,49~69"            ,"zfvyno,69~75"             ,"zfhblno,75~90"             ,"zfobdt,90~98,date"            ,"noOfBox,98~103,number"
           ,"noOfLine,103~108,number"  ,"freCost,108~119,curr"     ,"zfobpr,119~130,curr"       ,"contNum,130~150"              ,"outBoxNum,150~161"
           ,"inBoxNum,161~172"         ,"zordnoE,172~182"          ,"zordln,182~186,number"     ,"zordls,186~187"               ,"zmatnrInput,187~205"
           ,"confMatnr,205~223"        ,"splyMatnr,223~241"        ,"netpr,241~248,curr"        ,"zcfmqty,248~255,number"       ,"shipQty,255~262,number"
           ,"zboqty,262~269,number"    ,"zcancqty,269~276,number"  ,"shipValue,276~285,curr"    ,"totShipQty,285~292,number"    ,"zamdcf,292~294"
           ,"land1,294~296"            ,"zweig,296~303,number"     ,"outBoxGrwei,303~308,number","outBoxNtgew,308~313,number"   ,"outBoxLeng,313~316,number"
           ,"outBoxWid,316~319,number" ,"outBoxHei,319~322,number" ,"inBoxGrwei,322~327,number" ,"inBoxNtgew,327~332,number"    ,"inBoxLeng,332~335,number"
           ,"inBoxWid,335~338,number"  ,"inBoxHei,338~341,number"  ,"ccngn,341~351"             ,"intTrade,351~352"             ,"zfcifamt,352~361,curr"
        };
        convertUtil.setDefinition(rowDefinition);
        
        // *** field 딜리미터 설정 (입력하지 않으면 " " 스페이스문자)
        convertUtil.setFieldFillDelim(" ");
        
        // *** row 의 식별인자 (입력하지 않으면 "\r\n")
        convertUtil.setRowDelim("\r\n");
        
        // *** txt파일 생성
        StringBuffer txtData = new StringBuffer();
        
        // 헤더세팅
        txtData.append(excelVo.geteHead()).append(convertUtil.getRowDelim());
        
        // 본문세팅
        txtData.append(convertUtil.getFiexedFieldTxt(invoiceFile));
        
        // footer 세팅
        txtData.append(excelVo.geteTail());
        
        // *** 파일 다운로드
        InputStream bis = null;
        try {

            byte[] bRtn = txtData.toString().getBytes();
            bis = new ByteArrayInputStream(bRtn);

            mapsCommFileService.selectFileDownload(bis, fileName + ".txt", bRtn.length, request, response, false);

        } catch (Exception e) {
            logger.error("ERROR", e);
            throw new MapsFileDwnlException(e.getMessage(), e);
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                    bis = null;
                } catch (Exception e1) {
                    if (logger.isDebugEnabled()) {logger.debug("ERROR", e1);}
                }
            }
        }
        
        return;
    }


}
