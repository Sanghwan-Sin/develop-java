package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : IssueTrackerAddOutputVO.java
 * @Description : Issue Tracker(VOC Request Add)VO (저장 및 상세조회 VO)
 * @author ChoKyungHo
 * @since 2020. 03. 05.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 05.    ChoKyungHo      	        최초 생성
 * </pre>
 */

public class IssueTrackerAddOutputVO extends MapsCommSapRfcIfCommVO{
    
    /** -----[T_RESULT] START----- */
    /** Single-Character Flag */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="TYPE" )
    private String type;
    /** Ticket No. */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZTICKET_NO" )
    private String zticketNo;
    /** Name */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZDEALER_TXT" )
    private String zdealerTxt;
    /** 고객코드 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZSACUTM_DLR" )
    private String zsacutmDlr;
    /** Name */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="KUNNR_TXT" )
    private String kunnrTxt;
    /** 고객코드 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZSACUTM_DIST" )
    private String zsacutmDist;
    /** Sales Organization */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZVKORG_DIST" )
    private String zvkorgDist;
    /** Create Local Date */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /** Completion Date */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZCPLT_DT" )
    private Date zcpltDt;
    /** Requested Department */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZREQ_DPMT" )
    private String zreqDpmt;
    /** 코드 명 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZREQ_DPMT_TXT" )
    private String zreqDpmtTxt;
    /** Category L */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZCTGR_L" )
    private String zctgrL;
    /** 코드 명 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZCTGR_L_TXT" )
    private String zctgrLTxt;
    /** Category M */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZCTGR_M" )
    private String zctgrM;
    /** 코드 명 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZCTGR_M_TXT" )
    private String zctgrMTxt;
    /** Category S */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZCTGR_S" )
    private String zctgrS;
    /** 코드 명 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZCTGR_S_TXT" )
    private String zctgrSTxt;
    /** Assignee */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZIASS_ID" )
    private String ziassId;
    /** 코드 명 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZIASS_ID_TXT" )
    private String ziassIdTxt;
    /** SEQ번호(청구번호) */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZORDNO" )
    private String zordno;
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZORDLN" )
    private String zordln;
    /** 신청수량 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZREQQTY" )
    private BigDecimal zreqqty;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="MEINS" )
    private String meins;
    /** Material Number */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** Case No */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZCAS_NO" )
    private String zcasNo;
    /** Customer group 1 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /** L-REGION */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZLREGIO" )
    private String zlregio;
    /** M-REGION */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZMREGIO" )
    private String zmregio;
    /** S-REGION */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZSREGIO" )
    private String zsregio;
    /** Amend Code */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZAMENDCD" )
    private String zamendcd;
    /** 코드 명 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZAMENDCD_TXT" )
    private String zamendcdTxt;
    /** Invoice No. */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZINV_NO" )
    private String zinvNo;
    /** Public Flag */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZPUBLIC" )
    private String zpublic;
    /** Analyst */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZANALYST" )
    private String zanalyst;
    /** Change User */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZUDNAME" )
    private String zudname;
    /** Last name */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZUDNAME_TXT" )
    private String zudnameTxt;
    /** Change Local Date */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZUDLDATE" )
    private Date zudldate;
    /** Change Local Time */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZUDLTIME" )
    private Date zudltime;
    /** Process Code */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZPRC_CD" )
    private String zprcCd;
    /** 코드 명 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZPRC_CD_TXT" )
    private String zprcCdTxt;
    /** Request Count */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZREQCNT" )
    private BigDecimal zreqcnt;
    /** Subject */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZSBJT" )
    private String zsbjt;
    /** Attached File 1 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZATH_FLE1" )
    private String zathFle1;
    /** Attached File 2 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZATH_FLE2" )
    private String zathFle2;
    /** Attached File 3 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZATH_FLE3" )
    private String zathFle3;
    /** Attached File 4 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZATH_FLE4" )
    private String zathFle4;
    /** Attached File 5 */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZATH_FLE5" )
    private String zathFle5;
    /** Customer Number */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="KUNNR" )
    private String kunnr;
    /** Customer Number */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZDEALER" )
    private String zdealer;
    /** Reference No */
    @MapsRfcMappper( targetName="ES_OUTPUT", ipttSe="E", fieldKey="ZREF_NO" )
    private String zrefNo;
    
    
    /** -----[T_CONTENT] START----- */
    /** Text (length 132) */
    @MapsRfcMappper( targetName="T_CONTENT", ipttSe="I|E", fieldKey="LINE|LINE" )
    private String zlineC;

    /** -----[T_REPLY] START----- */
    /** Text (length 132) */
    @MapsRfcMappper( targetName="T_REPLY", ipttSe="I|E", fieldKey="LINE|LINE" )
    private String zlineR;


    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the zticketNo
     */
    public String getZticketNo() {
        return zticketNo;
    }

    /**
     * @param zticketNo the zticketNo to set
     */
    public void setZticketNo(String zticketNo) {
        this.zticketNo = zticketNo;
    }

    /**
     * @return the zdealerTxt
     */
    public String getZdealerTxt() {
        return zdealerTxt;
    }

    /**
     * @param zdealerTxt the zdealerTxt to set
     */
    public void setZdealerTxt(String zdealerTxt) {
        this.zdealerTxt = zdealerTxt;
    }

    /**
     * @return the zsacutmDlr
     */
    public String getZsacutmDlr() {
        return zsacutmDlr;
    }

    /**
     * @param zsacutmDlr the zsacutmDlr to set
     */
    public void setZsacutmDlr(String zsacutmDlr) {
        this.zsacutmDlr = zsacutmDlr;
    }

    /**
     * @return the kunnrTxt
     */
    public String getKunnrTxt() {
        return kunnrTxt;
    }

    /**
     * @param kunnrTxt the kunnrTxt to set
     */
    public void setKunnrTxt(String kunnrTxt) {
        this.kunnrTxt = kunnrTxt;
    }

    /**
     * @return the zsacutmDist
     */
    public String getZsacutmDist() {
        return zsacutmDist;
    }

    /**
     * @param zsacutmDist the zsacutmDist to set
     */
    public void setZsacutmDist(String zsacutmDist) {
        this.zsacutmDist = zsacutmDist;
    }

    /**
     * @return the zvkorgDist
     */
    public String getZvkorgDist() {
        return zvkorgDist;
    }

    /**
     * @param zvkorgDist the zvkorgDist to set
     */
    public void setZvkorgDist(String zvkorgDist) {
        this.zvkorgDist = zvkorgDist;
    }

    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }

    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }

    /**
     * @return the zcpltDt
     */
    public Date getZcpltDt() {
        return zcpltDt;
    }

    /**
     * @param zcpltDt the zcpltDt to set
     */
    public void setZcpltDt(Date zcpltDt) {
        this.zcpltDt = zcpltDt;
    }

    /**
     * @return the zreqDpmt
     */
    public String getZreqDpmt() {
        return zreqDpmt;
    }

    /**
     * @param zreqDpmt the zreqDpmt to set
     */
    public void setZreqDpmt(String zreqDpmt) {
        this.zreqDpmt = zreqDpmt;
    }

    /**
     * @return the zreqDpmtTxt
     */
    public String getZreqDpmtTxt() {
        return zreqDpmtTxt;
    }

    /**
     * @param zreqDpmtTxt the zreqDpmtTxt to set
     */
    public void setZreqDpmtTxt(String zreqDpmtTxt) {
        this.zreqDpmtTxt = zreqDpmtTxt;
    }

    /**
     * @return the zctgrL
     */
    public String getZctgrL() {
        return zctgrL;
    }

    /**
     * @param zctgrL the zctgrL to set
     */
    public void setZctgrL(String zctgrL) {
        this.zctgrL = zctgrL;
    }

    /**
     * @return the zctgrLTxt
     */
    public String getZctgrLTxt() {
        return zctgrLTxt;
    }

    /**
     * @param zctgrLTxt the zctgrLTxt to set
     */
    public void setZctgrLTxt(String zctgrLTxt) {
        this.zctgrLTxt = zctgrLTxt;
    }

    /**
     * @return the zctgrM
     */
    public String getZctgrM() {
        return zctgrM;
    }

    /**
     * @param zctgrM the zctgrM to set
     */
    public void setZctgrM(String zctgrM) {
        this.zctgrM = zctgrM;
    }

    /**
     * @return the zctgrMTxt
     */
    public String getZctgrMTxt() {
        return zctgrMTxt;
    }

    /**
     * @param zctgrMTxt the zctgrMTxt to set
     */
    public void setZctgrMTxt(String zctgrMTxt) {
        this.zctgrMTxt = zctgrMTxt;
    }

    /**
     * @return the zctgrS
     */
    public String getZctgrS() {
        return zctgrS;
    }

    /**
     * @param zctgrS the zctgrS to set
     */
    public void setZctgrS(String zctgrS) {
        this.zctgrS = zctgrS;
    }

    /**
     * @return the zctgrSTxt
     */
    public String getZctgrSTxt() {
        return zctgrSTxt;
    }

    /**
     * @param zctgrSTxt the zctgrSTxt to set
     */
    public void setZctgrSTxt(String zctgrSTxt) {
        this.zctgrSTxt = zctgrSTxt;
    }

    /**
     * @return the ziassId
     */
    public String getZiassId() {
        return ziassId;
    }

    /**
     * @param ziassId the ziassId to set
     */
    public void setZiassId(String ziassId) {
        this.ziassId = ziassId;
    }

    /**
     * @return the ziassIdTxt
     */
    public String getZiassIdTxt() {
        return ziassIdTxt;
    }

    /**
     * @param ziassIdTxt the ziassIdTxt to set
     */
    public void setZiassIdTxt(String ziassIdTxt) {
        this.ziassIdTxt = ziassIdTxt;
    }

    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }

    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }

    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }

    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }

    /**
     * @return the zreqqty
     */
    public BigDecimal getZreqqty() {
        return zreqqty;
    }

    /**
     * @param zreqqty the zreqqty to set
     */
    public void setZreqqty(BigDecimal zreqqty) {
        this.zreqqty = zreqqty;
    }

    /**
     * @return the meins
     */
    public String getMeins() {
        return meins;
    }

    /**
     * @param meins the meins to set
     */
    public void setMeins(String meins) {
        this.meins = meins;
    }

    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }

    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }

    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }

    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }

    /**
     * @return the zcasNo
     */
    public String getZcasNo() {
        return zcasNo;
    }

    /**
     * @param zcasNo the zcasNo to set
     */
    public void setZcasNo(String zcasNo) {
        this.zcasNo = zcasNo;
    }

    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }

    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }

    /**
     * @return the zlregio
     */
    public String getZlregio() {
        return zlregio;
    }

    /**
     * @param zlregio the zlregio to set
     */
    public void setZlregio(String zlregio) {
        this.zlregio = zlregio;
    }

    /**
     * @return the zmregio
     */
    public String getZmregio() {
        return zmregio;
    }

    /**
     * @param zmregio the zmregio to set
     */
    public void setZmregio(String zmregio) {
        this.zmregio = zmregio;
    }

    /**
     * @return the zsregio
     */
    public String getZsregio() {
        return zsregio;
    }

    /**
     * @param zsregio the zsregio to set
     */
    public void setZsregio(String zsregio) {
        this.zsregio = zsregio;
    }

    /**
     * @return the zamendcd
     */
    public String getZamendcd() {
        return zamendcd;
    }

    /**
     * @param zamendcd the zamendcd to set
     */
    public void setZamendcd(String zamendcd) {
        this.zamendcd = zamendcd;
    }

    /**
     * @return the zamendcdTxt
     */
    public String getZamendcdTxt() {
        return zamendcdTxt;
    }

    /**
     * @param zamendcdTxt the zamendcdTxt to set
     */
    public void setZamendcdTxt(String zamendcdTxt) {
        this.zamendcdTxt = zamendcdTxt;
    }

    /**
     * @return the zinvNo
     */
    public String getZinvNo() {
        return zinvNo;
    }

    /**
     * @param zinvNo the zinvNo to set
     */
    public void setZinvNo(String zinvNo) {
        this.zinvNo = zinvNo;
    }

    /**
     * @return the zpublic
     */
    public String getZpublic() {
        return zpublic;
    }

    /**
     * @param zpublic the zpublic to set
     */
    public void setZpublic(String zpublic) {
        this.zpublic = zpublic;
    }

    /**
     * @return the zanalyst
     */
    public String getZanalyst() {
        return zanalyst;
    }

    /**
     * @param zanalyst the zanalyst to set
     */
    public void setZanalyst(String zanalyst) {
        this.zanalyst = zanalyst;
    }

    /**
     * @return the zudname
     */
    public String getZudname() {
        return zudname;
    }

    /**
     * @param zudname the zudname to set
     */
    public void setZudname(String zudname) {
        this.zudname = zudname;
    }

    /**
     * @return the zudnameTxt
     */
    public String getZudnameTxt() {
        return zudnameTxt;
    }

    /**
     * @param zudnameTxt the zudnameTxt to set
     */
    public void setZudnameTxt(String zudnameTxt) {
        this.zudnameTxt = zudnameTxt;
    }

    /**
     * @return the zudldate
     */
    public Date getZudldate() {
        return zudldate;
    }

    /**
     * @param zudldate the zudldate to set
     */
    public void setZudldate(Date zudldate) {
        this.zudldate = zudldate;
    }

    /**
     * @return the zudltime
     */
    public Date getZudltime() {
        return zudltime;
    }

    /**
     * @param zudltime the zudltime to set
     */
    public void setZudltime(Date zudltime) {
        this.zudltime = zudltime;
    }

    /**
     * @return the zprcCd
     */
    public String getZprcCd() {
        return zprcCd;
    }

    /**
     * @param zprcCd the zprcCd to set
     */
    public void setZprcCd(String zprcCd) {
        this.zprcCd = zprcCd;
    }

    /**
     * @return the zprcCdTxt
     */
    public String getZprcCdTxt() {
        return zprcCdTxt;
    }

    /**
     * @param zprcCdTxt the zprcCdTxt to set
     */
    public void setZprcCdTxt(String zprcCdTxt) {
        this.zprcCdTxt = zprcCdTxt;
    }

    /**
     * @return the zreqcnt
     */
    public BigDecimal getZreqcnt() {
        return zreqcnt;
    }

    /**
     * @param zreqcnt the zreqcnt to set
     */
    public void setZreqcnt(BigDecimal zreqcnt) {
        this.zreqcnt = zreqcnt;
    }

    /**
     * @return the zsbjt
     */
    public String getZsbjt() {
        return zsbjt;
    }

    /**
     * @param zsbjt the zsbjt to set
     */
    public void setZsbjt(String zsbjt) {
        this.zsbjt = zsbjt;
    }

    /**
     * @return the zathFle1
     */
    public String getZathFle1() {
        return zathFle1;
    }

    /**
     * @param zathFle1 the zathFle1 to set
     */
    public void setZathFle1(String zathFle1) {
        this.zathFle1 = zathFle1;
    }

    /**
     * @return the zathFle2
     */
    public String getZathFle2() {
        return zathFle2;
    }

    /**
     * @param zathFle2 the zathFle2 to set
     */
    public void setZathFle2(String zathFle2) {
        this.zathFle2 = zathFle2;
    }

    /**
     * @return the zathFle3
     */
    public String getZathFle3() {
        return zathFle3;
    }

    /**
     * @param zathFle3 the zathFle3 to set
     */
    public void setZathFle3(String zathFle3) {
        this.zathFle3 = zathFle3;
    }

    /**
     * @return the zathFle4
     */
    public String getZathFle4() {
        return zathFle4;
    }

    /**
     * @param zathFle4 the zathFle4 to set
     */
    public void setZathFle4(String zathFle4) {
        this.zathFle4 = zathFle4;
    }

    /**
     * @return the zathFle5
     */
    public String getZathFle5() {
        return zathFle5;
    }

    /**
     * @param zathFle5 the zathFle5 to set
     */
    public void setZathFle5(String zathFle5) {
        this.zathFle5 = zathFle5;
    }

    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }

    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }

    /**
     * @return the zdealer
     */
    public String getZdealer() {
        return zdealer;
    }

    /**
     * @param zdealer the zdealer to set
     */
    public void setZdealer(String zdealer) {
        this.zdealer = zdealer;
    }

    /**
     * @return the zrefNo
     */
    public String getZrefNo() {
        return zrefNo;
    }

    /**
     * @param zrefNo the zrefNo to set
     */
    public void setZrefNo(String zrefNo) {
        this.zrefNo = zrefNo;
    }

    /**
     * @return the zlineC
     */
    public String getZlineC() {
        return zlineC;
    }

    /**
     * @param zlineC the zlineC to set
     */
    public void setZlineC(String zlineC) {
        this.zlineC = zlineC;
    }

    /**
     * @return the zlineR
     */
    public String getZlineR() {
        return zlineR;
    }

    /**
     * @param zlineR the zlineR to set
     */
    public void setZlineR(String zlineR) {
        this.zlineR = zlineR;
    }
}
