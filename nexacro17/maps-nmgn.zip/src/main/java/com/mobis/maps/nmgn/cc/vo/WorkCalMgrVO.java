package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : DistInfoVO.java
 * @Description : DistInfoVO
 * @author ha.jeongryeong
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.    ha.jeongryeong      최초 생성
 *               </pre>
 */

public class WorkCalMgrVO extends MapsCommSapRfcIfCommVO {

    /* 조회조건 */
    private String chkYn;
    private String year;
    private String corpCode;
    
    /* 조회결과 */
    private int rnum;
    private String holDate;
    private String holName;
    private String holFlag;
    private String preDate;
    
    
    
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the preDate
     */
    public String getPreDate() {
        return preDate;
    }
    /**
     * @param preDate the preDate to set
     */
    public void setPreDate(String preDate) {
        this.preDate = preDate;
    }
    /**
     * @return the chkYn
     */
    public String getChkYn() {
        return chkYn;
    }
    /**
     * @param chkYn the chkYn to set
     */
    public void setChkYn(String chkYn) {
        this.chkYn = chkYn;
    }
    /**
     * @return the year
     */
    public String getYear() {
        return year;
    }
    /**
     * @param year the year to set
     */
    public void setYear(String year) {
        this.year = year;
    }
    /**
     * @return the corpCode
     */
    public String getCorpCode() {
        return corpCode;
    }
    /**
     * @param corpCode the corpCode to set
     */
    public void setCorpCode(String corpCode) {
        this.corpCode = corpCode;
    }
    /**
     * @return the holDate
     */
    public String getHolDate() {
        return holDate;
    }
    /**
     * @param holDate the holDate to set
     */
    public void setHolDate(String holDate) {
        this.holDate = holDate;
    }
    /**
     * @return the holName
     */
    public String getHolName() {
        return holName;
    }
    /**
     * @param holName the holName to set
     */
    public void setHolName(String holName) {
        this.holName = holName;
    }
    /**
     * @return the holFlag
     */
    public String getHolFlag() {
        return holFlag;
    }
    /**
     * @param holFlag the holFlag to set
     */
    public void setHolFlag(String holFlag) {
        this.holFlag = holFlag;
    }
    
    
}
