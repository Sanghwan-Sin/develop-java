package com.mobis.maps.nmgn.qm.service;

import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.qm.vo.FormatDataVO;
import com.mobis.maps.nmgn.qm.vo.QualityNonconfirmityDetVO;
import com.mobis.maps.nmgn.qm.vo.QualityNonconfirmityVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityNonconfirmityService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 14.     jiyongdo     	최초 생성
 * </pre>
 */

public interface QualityNonconfirmityService {

    /**
     * 조회
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectQualityNonconfirmityList(LoginInfoVO loginInfo, QualityNonconfirmityVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectQualityNonconfirmityDetail(LoginInfoVO loginInfo, QualityNonconfirmityDetVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVo
     * @return
     */
    FormatDataVO selectFormatData(LoginInfoVO loginInfo, FormatDataVO paramVo) throws Exception;
}
