package com.mobis.maps.nmgn.sd.vo;



import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ImporterCountryVO.java
 * @Description : ZPSD_NMGN_S_COUNTRY
 * @author 이수지
 * @since 2020. 03. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 30.     이수지     	       최초 생성
 * </pre>
 */

public class ImporterCountryVO extends MapsCommSapRfcIfCommVO {
    
    /** 국가코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_LAND1" )
    private String ivLand1;

    /** -----[T_DATA] START----- */
    
    /** Country Key */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LAND1" )
    private String land1;
    /** Country Name */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LANDX" )
    private String landx;
    
    /** -----[T_DATA] END----- */
    
    
    /**
     * @return the ivLand1
     */
    public String getIvLand1() {
        return ivLand1;
    }
    /**
     * @param ivLand1 the ivLand1 to set
     */
    public void setIvLand1(String ivLand1) {
        this.ivLand1 = ivLand1;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the landx
     */
    public String getLandx() {
        return landx;
    }
    /**
     * @param landx the landx to set
     */
    public void setLandx(String landx) {
        this.landx = landx;
    }
}
