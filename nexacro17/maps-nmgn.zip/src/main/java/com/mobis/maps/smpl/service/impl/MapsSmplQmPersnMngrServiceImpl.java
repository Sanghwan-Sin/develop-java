package com.mobis.maps.smpl.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.sapjco.manager.Destination;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.mobis.maps.smpl.service.MapsSmplQmPersnMngrService;
import com.mobis.maps.smpl.vo.MapsSmplQmMngrVO;
import com.nexacro17.xapi.data.DataSet;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplQmPersnMngrServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     Sin Sanghwan       최초 생성
 * </pre>
 */
@Service("mapsSmplQmPersnMngrService")
public class MapsSmplQmPersnMngrServiceImpl extends HService implements MapsSmplQmPersnMngrService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplQmPersnMngrService#selectSelectQmPersnList(com.mobis.maps.smpl.vo.MapsSmplQmMngrVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsSmplQmMngrVO> selectQmPersnList(MapsSmplQmMngrVO paramVO
            , LoginInfoVO loginInfo) throws Exception {
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_SRS_R_RESP;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);

        
        List<MapsSmplQmMngrVO> lstQmMngr = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", paramVO, MapsSmplQmMngrVO.class);
        
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSelectQmPersnList::end");
        }
        return lstQmMngr;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplQmPersnMngrService#multiQmPersn(com.mobis.maps.smpl.vo.MapsSmplQmMngrVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<MapsSmplQmMngrVO> multiQmPersn(MapsSmplQmMngrVO paramVO
            , List<MapsSmplQmMngrVO> paramList
            , LoginInfoVO loginInfo) throws Exception {

        List<MapsSmplQmMngrVO>  retList = new ArrayList<>(); //결과리스트
        MapsSmplQmMngrVO        retVO   = null;
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_SRS_R_RESP;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        // 파라미터(TABLES) 추출, 적재
        for(MapsSmplQmMngrVO tmpVO : paramList) {
            if(tmpVO.getRowType() == DataSet.ROW_TYPE_NORMAL) {
                continue;
            }
            if (!"Y".equals(tmpVO.getChkYn())) {
                continue;
            }
            switch(tmpVO.getRowSe()) {
                case "I":
                    tmpVO.setZflag("C");
                    break;
                case "U":
                    tmpVO.setZflag("M");
                    break;
                case "D":
                    tmpVO.setZflag("D");
                    break;
                default :
                    break;                        
            }
            
            MapsRfcMappperUtil.appendImportTableRow(func, "ET_DATA", tmpVO);
            
            //결과리스트 세팅
            retVO = new MapsSmplQmMngrVO();
            retVO.setRowSe(tmpVO.getRowSe());
            retList.add(retVO);
        }
        
        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func, true);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        // 개별데이타 저장
        List<MapsSmplQmMngrVO> lstQmMngr = MapsRfcMappperUtil.getExportTableResultValues(funcRslt, "ET_DATA", MapsSmplQmMngrVO.class);
        
        return lstQmMngr;
    }
    
    /*
     * @see com.mobis.maps.smpl.service.MapsQmPersnMngrService#rfcQmPersnList(com.mobis.maps.smpl.vo.MapsSmplMngrVO)
     */
    @Override
    public List<MapsSmplQmMngrVO> selectQmPersnList(MapsSmplQmMngrVO paramVO) throws Exception {
        
        // Destination 얻어내기
        Destination destination = mapsCmmnSapService.selectDestination(Locale.KOREA);
        
        // RFC 얻어내기
        Function function = destination.getFunction("ZPQM_SRS_R_RESP");
        
        // 공통파라미터(Import) 셋팅
        JCoStructure jsIfComm = function.getImportParameterList().getStructure("IS_IFCOMM");
        jsIfComm.setValue("IFCODE",     paramVO.getIfCode());
        jsIfComm.setValue("BUKRS",      paramVO.getBukRs());
        jsIfComm.setValue("VKORG",      paramVO.getVkorg());
        jsIfComm.setValue("TZONE",      paramVO.getTzone());
        jsIfComm.setValue("UNAME",      paramVO.getUname());
        jsIfComm.setValue("SPRAS",      paramVO.getSpras());
        if (StringUtils.equals(paramVO.getPgType(), "S")) {
            jsIfComm.setValue("PGCNUM", paramVO.getScrollPgNum());
            jsIfComm.setValue("PGSIZE", paramVO.getScrollPgSize());
        } else {
            jsIfComm.setValue("PGCNUM", paramVO.getPgNum());
            jsIfComm.setValue("PGSIZE", paramVO.getPgSize());
        }
        
        // 파라미터(Import) 셋팅
        function.getImportParameterList().setValue("I_BUKRS",   paramVO.getiBukrs());
        function.getImportParameterList().setValue("I_LIFNR",   paramVO.getiLinfnr());
        function.getImportParameterList().setValue("I_ZPROCCD", paramVO.getiZproccd());
        function.getImportParameterList().setValue("I_ZMATGB",  paramVO.getiZmatgb());
        function.getImportParameterList().setValue("I_FLAG",    paramVO.getiFlag());
        
        // RFC 호출
        FunctionResult result = function.execute();
        
        // 파라미터(Export) 추출
        JCoStructure resReturn = result.getExportParameterList().getStructure("ES_RETURN");
        
        // 파라미터(Export, Tables) 출력
        paramVO.setMsgType( resReturn.getString("MTYPE"));
        paramVO.setMsgId(   resReturn.getString("MSGID"));
        paramVO.setMsgNo(   resReturn.getString("MSGNO"));
        paramVO.setMsg(     resReturn.getString("MESSAGE"));
        
        // 파라미터(TABLES) 추출
        List<Map<String, Object>> lstData = result.getTable("ET_DATA");
        
        // 데이타 적재
        List<MapsSmplQmMngrVO> retList = new ArrayList<MapsSmplQmMngrVO>();
        int rcnt = 0;
        int rnum = ((paramVO.getPgNum() - 1) * paramVO.getPgSize()) + 1;
        for (Map<String, Object> tmpData : lstData) {
            MapsSmplQmMngrVO tmpVO = new MapsSmplQmMngrVO();
            if (rcnt == 0) {
                tmpVO.setTotCnt(Integer.parseInt(StringUtils.trim(resReturn.getString("TOTCNT"))));
            }
            tmpVO.setRnum(rnum);
            tmpVO.setChkYn("0");
            tmpVO.setSeqno(     String.valueOf(tmpData.get("SEQNO")));
            tmpVO.setBukrs(     String.valueOf(tmpData.get("BUKRS")));
            tmpVO.setButxt(     String.valueOf(tmpData.get("BUTXT")));
            tmpVO.setLifnr(     String.valueOf(tmpData.get("LIFNR")));
            tmpVO.setName1(     String.valueOf(tmpData.get("NAME1")));
            tmpVO.setZproccd(   String.valueOf(tmpData.get("ZPROCCD")));
            tmpVO.setZproccdTxt(String.valueOf(tmpData.get("ZPROCCD_TXT")));
            tmpVO.setZmatgb(    String.valueOf(tmpData.get("ZMATGB")));
            tmpVO.setZmatgbTxt( String.valueOf(tmpData.get("ZMATGB_TXT")));
            tmpVO.setNameLast(  String.valueOf(tmpData.get("NAME_LAST")));
            tmpVO.setTelNumber( String.valueOf(tmpData.get("TEL_NUMBER")));
            tmpVO.setSmtpAddr(  String.valueOf(tmpData.get("SMTP_ADDR")));

            tmpVO.setMsgType(   "");
            tmpVO.setMsg(       "");
            tmpVO.setMsgId(     "");
            tmpVO.setMsgNo(     "");
            
            retList.add(tmpVO);
            rcnt++;
            rnum++;
        }
        
        return retList;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplQmPersnMngrService#rfcSaveQmPersnList(com.mobis.maps.smpl.vo.MapsSmplQmMngrVO)
     */
    @Override
    public Map<String, Object> insertQmPersnList(MapsSmplQmMngrVO paramVO, List<MapsSmplQmMngrVO> paramList) throws Exception {
        
        Map<String, Object>     retMap  = new HashMap<String, Object>();
        List<MapsSmplQmMngrVO>  retList = new ArrayList<>(); //결과리스트
        MapsSmplQmMngrVO        retVO   = null;
        
        // Destination 얻어내기
        Destination destination = mapsCmmnSapService.selectDestination(Locale.KOREAN);
        
        // RFC 얻어내기
        Function function = destination.getFunction("ZPQM_SRS_R_RESP");
        
        // 공통파라미터(Import) 셋팅
        JCoStructure jsIfComm = function.getImportParameterList().getStructure("IS_IFCOMM");
        jsIfComm.setValue("IFCODE",     paramVO.getIfCode());
        jsIfComm.setValue("BUKRS",      paramVO.getBukRs());
        jsIfComm.setValue("VKORG",      paramVO.getVkorg());
        jsIfComm.setValue("TZONE",      paramVO.getTzone());
        jsIfComm.setValue("UNAME",      paramVO.getUname());
        jsIfComm.setValue("SPRAS",      paramVO.getSpras());
        if (StringUtils.equals(paramVO.getPgType(), "S")) {
            jsIfComm.setValue("PGCNUM", paramVO.getScrollPgNum());
            jsIfComm.setValue("PGSIZE", paramVO.getScrollPgSize());
        } else {
            jsIfComm.setValue("PGCNUM", paramVO.getPgNum());
            jsIfComm.setValue("PGSIZE", paramVO.getPgSize());
        }
        
        // 파라미터(Import) 셋팅
        function.getImportParameterList().setValue("I_BUKRS",   paramVO.getiBukrs());
        function.getImportParameterList().setValue("I_LIFNR",   paramVO.getiLinfnr());
        function.getImportParameterList().setValue("I_ZPROCCD", paramVO.getiZproccd());
        function.getImportParameterList().setValue("I_ZMATGB",  paramVO.getiZmatgb());
        function.getImportParameterList().setValue("I_FLAG",    paramVO.getiFlag());
        
        // 파라미터(TABLES) 추출, 적재
        JCoTable jcoTbl = function.getImportTableParameter("ET_DATA");
        for(MapsSmplQmMngrVO tmpVO : paramList) {
            if(tmpVO.getRowType() != DataSet.ROW_TYPE_NORMAL) {
                
                jcoTbl.appendRow();
                jcoTbl.setValue("BUKRS",        tmpVO.getBukrs());
                jcoTbl.setValue("BUTXT",        tmpVO.getButxt());
                jcoTbl.setValue("LIFNR",        tmpVO.getLifnr());
                jcoTbl.setValue("NAME1",        tmpVO.getName1());
                jcoTbl.setValue("ZPROCCD",      tmpVO.getZproccd());
                jcoTbl.setValue("ZMATGB",       tmpVO.getZmatgb());
                jcoTbl.setValue("NAME_LAST",    tmpVO.getNameLast());
                jcoTbl.setValue("TEL_NUMBER",   tmpVO.getTelNumber());
                jcoTbl.setValue("SMTP_ADDR",    tmpVO.getSmtpAddr());
                
                if ("Y".equals(tmpVO.getChkYn())) {
                    switch(tmpVO.getRowSe()) {
                        case "I":
                            jcoTbl.setValue("ZFLAG",    "C");
                            break;
                        case "U":
                            jcoTbl.setValue("ZFLAG",    "M");
                            break;
                        case "D":
                            jcoTbl.setValue("ZFLAG",    "D");
                            break;
                        default :
                            break;                        
                    }
                    
                    //결과리스트 세팅
                    retVO = new MapsSmplQmMngrVO();
                    retVO.setRowSe(tmpVO.getRowSe());
                    retList.add(retVO);
                }
            }
        }
        
        // RFC 호출
        FunctionResult result = function.execute();
        
        // 결과데이타 추출
        JCoStructure resReturn = result.getExportParameterList().getStructure("ES_RETURN");
        
        // 전체메세지 추출
        paramVO.setMsgType( resReturn.getString("MTYPE"));
        paramVO.setMsgId(   resReturn.getString("MSGID"));
        paramVO.setMsgNo(   resReturn.getString("MSGNO"));
        paramVO.setMsg(     resReturn.getString("MESSAGE"));
        retMap.put("head", paramVO);
        
        // 개별데이타 추출
        List<Map<String, Object>> lstData = result.getTable("ET_DATA");
        
       // 개별데이타 저장
        for(int i=0; i<lstData.size(); i++) {
            Map<String, Object> tMpa = lstData.get(i);
            MapsSmplQmMngrVO tmpVO = retList.get(i);
            
            tmpVO.setBukrs(     (String)tMpa.get("BUKRS"));
            tmpVO.setButxt(     (String)tMpa.get("BUTXT"));
            tmpVO.setLifnr(     (String)tMpa.get("LIFNR"));
            tmpVO.setName1(     (String)tMpa.get("NAME1"));
            tmpVO.setZproccd(   (String)tMpa.get("ZPROCCD"));
            tmpVO.setZmatgb(    (String)tMpa.get("ZMATGB"));
            tmpVO.setNameLast(  (String)tMpa.get("NAME_LAST"));
            
            tmpVO.setMsgType(   (String)tMpa.get("MTYPE"));
            tmpVO.setMsg(       (String)tMpa.get("MESSAGE"));
            tmpVO.setMsgId(     (String)tMpa.get("MSGID"));
            tmpVO.setMsgNo(     (String)tMpa.get("MSGNO"));
        }
        
        retMap.put("body", retList);
        
        return retMap;
    }

}
