package com.mobis.maps.nmgn.cc.service.impl;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.cc.service.KpiService;
import com.mobis.maps.nmgn.cc.vo.KpiInfoOneVO;
import com.mobis.maps.nmgn.cc.vo.KpiInfoVO;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : KpiServiceImpl.java
 * @Description : Monthly KPI Info
 * @author hong.minho
 * @since 2020. 11. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 11. 24.     hong.minho     	최초 생성
 * </pre>
 */

@Service("kpiService")
public class KpiServiceImpl extends HService implements KpiService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.KpiService#selectKpiInfo(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.KpiInfoOneVO)
     */
    @Override
    public int selectKpiInfo(LoginInfoVO loginInfo, KpiInfoOneVO paramVO) throws MapsBizException, Exception {
        
        
        KpiInfoVO params = new KpiInfoVO();
        BeanUtils.copyProperties(params, paramVO);
        
        params.setiType("R"); // 조회
        params.setiGjahr(paramVO.getStdYear());
        params.setiZsacutm(paramVO.getDistCd());
        params.setiVkorg(paramVO.getVkorg());
        params.setiVtweg(paramVO.getVtweg());
        params.setiWaers("USD"); // USD 고정
        
        
        
        // *** RFC 조회 처리 *********
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_KPI;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        //*** 조회결과
        List<KpiInfoVO> lst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_LIST", paramVO, KpiInfoVO.class);
        
        if (lst == null || lst.size() <= 0) {
            return 0;
        }
        
        // *** GRID용 VO 로 변환
        this.copyToOneRow(lst, paramVO);
        
        
        return lst.size();
    }

    
    /*
     * @see com.mobis.maps.nmgn.cc.service.KpiService#multiKpiInfo(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.KpiInfoOneVO)
     */
    @Override
    public int multiKpiInfo(LoginInfoVO loginInfo, KpiInfoOneVO paramVO) throws MapsBizException, Exception {
        
        
        // *** Parameters 구성
        KpiInfoVO params = new KpiInfoVO();
        BeanUtils.copyProperties(params, paramVO);
        
        params.setiGjahr(paramVO.getStdYear());
        params.setiZsacutm(paramVO.getDistCd());
        params.setiVkorg(paramVO.getVkorg());
        params.setiVtweg(paramVO.getVtweg());
        params.setiWaers("USD"); // USD 고정
        
        KpiInfoOneVO param2VO = new KpiInfoOneVO();
        BeanUtils.copyProperties(param2VO, paramVO);
        
        // *** 데이터 조회
        int nCnt = selectKpiInfo(loginInfo, param2VO);

        if (nCnt > 0) {
            params.setiType("U"); // 수정
        } else {
            params.setiType("C"); // 신규
        }
        
        
        // *** RFC용 VO List 로  변환
        List<KpiInfoVO> lst = this.selectToMultiRows(paramVO);
        
        
        // *** RFC 처리
        
        // RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_KPI;
        params.setIfCode(sapRfcInfo.getIfCode());
        
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        // TABLES 적재
        for(KpiInfoVO vo : lst) {
            if (vo == null) continue;
            
            vo.setWaers("USD");// USD 고정
            MapsRfcMappperUtil.appendImportTableRow(func, "T_LIST", vo);
        }
        
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        // RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        if ("E".equals(paramVO.getMsgType())) {
            return -100;
        }
        
        
        // 저장 성공 후 재조회
        int nRslt = selectKpiInfo(loginInfo, paramVO);
        
        return nRslt;
    }
    
    
    
    /**
     * 단일로우 VO ==> RFC VO List 로 변환
     *
     * @param inVo
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    private List<KpiInfoVO> selectToMultiRows(KpiInfoOneVO inVo) throws MapsBizException, Exception {
        List<KpiInfoVO> lst = new ArrayList<KpiInfoVO>();
        int nKpiCount = 17;
        Method getter = null;
        Class[] blankClss = new Class[]{};
        Object[] blankArgs = new Object[]{};
        
        if (inVo == null) return lst;
        
        for(int idx = 1; idx <= nKpiCount; idx++) {
            KpiInfoVO vo = new KpiInfoVO();
            String sidx = StringUtils.leftPad(idx+"", 2, "0");

//            getter = inVo.getClass().getMethod("getK"+sidx+"cd", blankClss);
//            vo.setZfactor((String)getter.invoke(inVo, blankArgs));
            vo.setZfactor(sidx);
            
            getter = inVo.getClass().getMethod("getK"+sidx+"mon01", blankClss);
            vo.setZkpiamt01(toString((BigDecimal)getter.invoke(inVo, blankArgs)));
            
            getter = inVo.getClass().getMethod("getK"+sidx+"mon02", blankClss);
            vo.setZkpiamt02(toString((BigDecimal)getter.invoke(inVo, blankArgs)));
            
            getter = inVo.getClass().getMethod("getK"+sidx+"mon03", blankClss);
            vo.setZkpiamt03(toString((BigDecimal)getter.invoke(inVo, blankArgs)));
            
            getter = inVo.getClass().getMethod("getK"+sidx+"mon04", blankClss);
            vo.setZkpiamt04(toString((BigDecimal)getter.invoke(inVo, blankArgs)));

            getter = inVo.getClass().getMethod("getK"+sidx+"mon05", blankClss);
            vo.setZkpiamt05(toString((BigDecimal)getter.invoke(inVo, blankArgs)));
            
            getter = inVo.getClass().getMethod("getK"+sidx+"mon06", blankClss);
            vo.setZkpiamt06(toString((BigDecimal)getter.invoke(inVo, blankArgs)));

            getter = inVo.getClass().getMethod("getK"+sidx+"mon07", blankClss);
            vo.setZkpiamt07(toString((BigDecimal)getter.invoke(inVo, blankArgs)));

            getter = inVo.getClass().getMethod("getK"+sidx+"mon08", blankClss);
            vo.setZkpiamt08(toString((BigDecimal)getter.invoke(inVo, blankArgs)));

            getter = inVo.getClass().getMethod("getK"+sidx+"mon09", blankClss);
            vo.setZkpiamt09(toString((BigDecimal)getter.invoke(inVo, blankArgs)));

            getter = inVo.getClass().getMethod("getK"+sidx+"mon10", blankClss);
            vo.setZkpiamt10(toString((BigDecimal)getter.invoke(inVo, blankArgs)));

            getter = inVo.getClass().getMethod("getK"+sidx+"mon11", blankClss);
            vo.setZkpiamt11(toString((BigDecimal)getter.invoke(inVo, blankArgs)));
            
            getter = inVo.getClass().getMethod("getK"+sidx+"mon12", blankClss);
            vo.setZkpiamt12(toString((BigDecimal)getter.invoke(inVo, blankArgs)));
            
            getter = inVo.getClass().getMethod("getK"+sidx+"tot", blankClss);
            vo.setZtoamt(toString((BigDecimal)getter.invoke(inVo, blankArgs)));

            getter = inVo.getClass().getMethod("getK"+sidx+"avg", blankClss);
            vo.setZavamt(toString((BigDecimal)getter.invoke(inVo, blankArgs)));

            getter = inVo.getClass().getMethod("getK"+sidx+"trgt", blankClss);
            vo.setZtgamt(toString((BigDecimal)getter.invoke(inVo, blankArgs)));
            
            
            lst.add(vo);
        }
        
        
        return lst;
    }

    /**
     * RFC VO List ==> 단일로우 VO 로 변환
     *
     * @param inVo
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    private void copyToOneRow(List<KpiInfoVO> lst, KpiInfoOneVO oneVo) throws MapsBizException, Exception {
        int nKpiCount = 17;

        Method setter = null;
        
        if (lst == null || lst.size() <= 0) {
            if (logger.isDebugEnabled()) logger.debug("### List<KpiInfoVO> lst is NULL .");
            return;
        }
        
        if (oneVo == null) {
            if (logger.isDebugEnabled()) logger.debug("### KpiInfoOneVO oneVo is NULL .");
            return;
        }
        
        int cntCal = 1;
        for(int idx = 1; idx <= lst.size() && idx <= nKpiCount; idx++) {
            KpiInfoVO vo = lst.get(idx-1);
            
            if (StringUtils.isBlank(vo.getZfactor())) continue;
            
            String sidx = StringUtils.leftPad(cntCal+"", 2, "0"); // KPI Factor 코드

            setter = oneVo.getClass().getMethod("setK"+sidx+"cd", new Class[]{String.class});
//            setter.invoke(oneVo, new Object[]{vo.getZfactor()});
            setter.invoke(oneVo, new Object[]{sidx});
            
            setter = oneVo.getClass().getMethod("setK"+sidx+"mon01", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt01())});

            setter = oneVo.getClass().getMethod("setK"+sidx+"mon02", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt02())});
            
            setter = oneVo.getClass().getMethod("setK"+sidx+"mon03", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt03())});
            
            setter = oneVo.getClass().getMethod("setK"+sidx+"mon04", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt04())});

            setter = oneVo.getClass().getMethod("setK"+sidx+"mon05", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt05())});
            
            setter = oneVo.getClass().getMethod("setK"+sidx+"mon06", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt06())});

            setter = oneVo.getClass().getMethod("setK"+sidx+"mon07", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt07())});

            setter = oneVo.getClass().getMethod("setK"+sidx+"mon08", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt08())});

            setter = oneVo.getClass().getMethod("setK"+sidx+"mon09", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt09())});

            setter = oneVo.getClass().getMethod("setK"+sidx+"mon10", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt10())});

            setter = oneVo.getClass().getMethod("setK"+sidx+"mon11", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt11())});
            
            setter = oneVo.getClass().getMethod("setK"+sidx+"mon12", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZkpiamt12())});
            
            setter = oneVo.getClass().getMethod("setK"+sidx+"tot", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZtoamt())});

            setter = oneVo.getClass().getMethod("setK"+sidx+"avg", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZavamt())});

            setter = oneVo.getClass().getMethod("setK"+sidx+"trgt", new Class[]{BigDecimal.class});
            setter.invoke(oneVo, new Object[]{toBigDecimal(vo.getZtgamt())});
            cntCal++;
        }
        
    }
    
    
    /**
     * String 2 BigDecimal
     *
     * @param val
     * @return
     */
    private BigDecimal toBigDecimal(String val) {
        boolean isMinus = false;
        BigDecimal rslt = null;
        
        if (StringUtils.isBlank(val)) {
            return rslt;
        }
        
        String valTmp = val.trim().replaceAll("[^0-9\\.\\-]", "");
        
        // SAP Minus(-) 변환
        if (valTmp.endsWith("-")) {
            valTmp = valTmp.replaceAll("\\-", "");
            isMinus = true;
        }

        try {
            rslt = new BigDecimal(valTmp);
            
            if (isMinus) {
                rslt = rslt.multiply(BigDecimal.valueOf(-1));
            }
            
        } catch (Exception e) {
            if (logger.isDebugEnabled()) {
                logger.debug("ERROR", e);
            }
        }
        
        return rslt;
    }
    
    /**
     * BigDecimal 2 String
     *
     * @param val
     * @return
     */
    private String toString(BigDecimal val) {
        if (val == null) return "";
        
        return val.toString();
    }
}
