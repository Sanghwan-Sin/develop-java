package com.mobis.maps.nmgn.sd.vo;


import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceFullFileVO.java
 * @Description : ZPSD_MGN_R_LIST_PRICE_FUL_FILE / ZPSD_MGN_R_CUSTOMER_INFO
 * @author 이수지
 * @since 2020. 2. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *   2020. 2. 12.     이수지     	       최초 생성
 * </pre>
 */

public class ListPriceFullFileVO extends MapsCommSapRfcIfCommVO {
    
    /** -----[IS_DATES] START----- */
    
    /** ABAP: ID: I/E (include/exclude values) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="SIGN" )
    private String sign;
    /** ABAP: Selection option (EQ/BT/CP/...) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="OPTION" )
    private String option;
    /** 'Generic' SELECT-OPTION for Dynamic Selections */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="LOW" )
    private String low;
    /** 'Generic' SELECT-OPTION for Dynamic Selections */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="HIGH" )
    private String high;
    
    /** -----[IS_DATES] END----- */
    
    /** nMGN Car Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CARTP" )
    private String iCartp;
    /** 진행상태 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_STATUS" )
    private String iStatus;
    /** R/U (조회:R, 변경:U) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** H/K 구분 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    /** Price List Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PLTYP" )
    private String iPltyp;
    /**  */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_UKURS_TXT" )
    private String eUkursTxt;
    
    /** -----[T_RESULT] START----- */
    
    /** 작업구분 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="TYPE" )
    private String type;
    /** 고객코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name 1 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** H/K 구분 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** 코드설명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD_DESC" )
    private String zhkcdDesc;
    /** 요청번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="REQNO" )
    private String reqno;
    /** nMGN Car Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="CAR_TYPE" )
    private String carType;
    /** 코드설명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="CAR_TYPE_NAME" )
    private String carTypeName;
    /** Price Time */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="PRICE_TIME" )
    private String priceTime;
    /** 코드설명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PRICE_TIME_TEXT" )
    private String priceTimeText;
    /** Price List Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PLTYP" )
    private String pltyp;
    /** 코드설명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PTEXT" )
    private String ptext;
    /** 신청일자 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="REQDT" )
    private Date reqdt;
    /** 적용일 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="APPDT" )
    private Date appdt;
    /** 진행상태 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="STATUS" )
    private String status;
    /** 코드설명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="STATUS_TEXT" )
    private String statusText;
    /** SD document currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** 파일내역 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_NAME" )
    private String zfileName;
    /** 파일경로 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_PATH" )
    private String zfilePath;
    /** 파일사이즈 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_SIZE" )
    private String zfileSize;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_TYPE" )
    private String zfileType;
    /** Create Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /** Change User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZCRNAME" )
    private String zcrname;
    /** Change Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZUDLDATE" )
    private Date zudldate;
    /** Change User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZUDNAME" )
    private String zudname;
    /** Deletion Indicator */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="LOEVM" )
    private String loevm;
    /** 메세지 결과: S 성공, E 오류 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /** 메시지 텍스트 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MSGNO" )
    private String msgno;   
    /** Customer Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KUNNR" )
    private String kunnr;
    /** Name 1 of organization */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NAME_ORG1" )
    private String nameOrg1;
    /** Customer group 2 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR2" )
    private String kvgr2;
    /** Customer group 3 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR3" )
    private String kvgr3;
    /** Customer group 4 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR4" )
    private String kvgr4;
    /** Customer group 5 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR5" )
    private String kvgr5;
    /** Price View */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRICE_VIEW" )
    private String zpriceView;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_SEQNO" )
    private String zfileSeqno;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="REF_NO" )
    private String refNo;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;    
    
    /** -----[T_RESULT] END----- */
    
    /**
     * @return the sign
     */
    public String getSign() {
        return sign;
    }
    /**
     * @param sign the sign to set
     */
    public void setSign(String sign) {
        this.sign = sign;
    }
    /**
     * @return the option
     */
    public String getOption() {
        return option;
    }
    /**
     * @param option the option to set
     */
    public void setOption(String option) {
        this.option = option;
    }
    /**
     * @return the low
     */
    public String getLow() {
        return low;
    }
    /**
     * @param low the low to set
     */
    public void setLow(String low) {
        this.low = low;
    }
    /**
     * @return the high
     */
    public String getHigh() {
        return high;
    }
    /**
     * @param high the high to set
     */
    public void setHigh(String high) {
        this.high = high;
    }
    /**
     * @return the iCartp
     */
    public String getiCartp() {
        return iCartp;
    }
    /**
     * @param iCartp the iCartp to set
     */
    public void setiCartp(String iCartp) {
        this.iCartp = iCartp;
    }
    /**
     * @return the iStatus
     */
    public String getiStatus() {
        return iStatus;
    }
    /**
     * @param iStatus the iStatus to set
     */
    public void setiStatus(String iStatus) {
        this.iStatus = iStatus;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zhkcdDesc
     */
    public String getZhkcdDesc() {
        return zhkcdDesc;
    }
    /**
     * @param zhkcdDesc the zhkcdDesc to set
     */
    public void setZhkcdDesc(String zhkcdDesc) {
        this.zhkcdDesc = zhkcdDesc;
    }
    /**
     * @return the reqno
     */
    public String getReqno() {
        return reqno;
    }
    /**
     * @param reqno the reqno to set
     */
    public void setReqno(String reqno) {
        this.reqno = reqno;
    }
    /**
     * @return the carType
     */
    public String getCarType() {
        return carType;
    }
    /**
     * @param carType the carType to set
     */
    public void setCarType(String carType) {
        this.carType = carType;
    }
    /**
     * @return the carTypeName
     */
    public String getCarTypeName() {
        return carTypeName;
    }
    /**
     * @param carTypeName the carTypeName to set
     */
    public void setCarTypeName(String carTypeName) {
        this.carTypeName = carTypeName;
    }
    /**
     * @return the priceTime
     */
    public String getPriceTime() {
        return priceTime;
    }
    /**
     * @param priceTime the priceTime to set
     */
    public void setPriceTime(String priceTime) {
        this.priceTime = priceTime;
    }
    /**
     * @return the priceTimeText
     */
    public String getPriceTimeText() {
        return priceTimeText;
    }
    /**
     * @param priceTimeText the priceTimeText to set
     */
    public void setPriceTimeText(String priceTimeText) {
        this.priceTimeText = priceTimeText;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the ptext
     */
    public String getPtext() {
        return ptext;
    }
    /**
     * @param ptext the ptext to set
     */
    public void setPtext(String ptext) {
        this.ptext = ptext;
    }
    /**
     * @return the reqdt
     */
    public Date getReqdt() {
        return reqdt;
    }
    /**
     * @param reqdt the reqdt to set
     */
    public void setReqdt(Date reqdt) {
        this.reqdt = reqdt;
    }
    /**
     * @return the appdt
     */
    public Date getAppdt() {
        return appdt;
    }
    /**
     * @param appdt the appdt to set
     */
    public void setAppdt(Date appdt) {
        this.appdt = appdt;
    }
    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }
    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    /**
     * @return the statusText
     */
    public String getStatusText() {
        return statusText;
    }
    /**
     * @param statusText the statusText to set
     */
    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }
    /**
     * @return the zfileName
     */
    public String getZfileName() {
        return zfileName;
    }
    /**
     * @param zfileName the zfileName to set
     */
    public void setZfileName(String zfileName) {
        this.zfileName = zfileName;
    }
    /**
     * @return the zfilePath
     */
    public String getZfilePath() {
        return zfilePath;
    }
    /**
     * @param zfilePath the zfilePath to set
     */
    public void setZfilePath(String zfilePath) {
        this.zfilePath = zfilePath;
    }
    /**
     * @return the zfileSize
     */
    public String getZfileSize() {
        return zfileSize;
    }
    /**
     * @param zfileSize the zfileSize to set
     */
    public void setZfileSize(String zfileSize) {
        this.zfileSize = zfileSize;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zcrname
     */
    public String getZcrname() {
        return zcrname;
    }
    /**
     * @param zcrname the zcrname to set
     */
    public void setZcrname(String zcrname) {
        this.zcrname = zcrname;
    }
    /**
     * @return the zudldate
     */
    public Date getZudldate() {
        return zudldate;
    }
    /**
     * @param zudldate the zudldate to set
     */
    public void setZudldate(Date zudldate) {
        this.zudldate = zudldate;
    }
    /**
     * @return the zudname
     */
    public String getZudname() {
        return zudname;
    }
    /**
     * @param zudname the zudname to set
     */
    public void setZudname(String zudname) {
        this.zudname = zudname;
    }
    /**
     * @return the loevm
     */
    public String getLoevm() {
        return loevm;
    }
    /**
     * @param loevm the loevm to set
     */
    public void setLoevm(String loevm) {
        this.loevm = loevm;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public String getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(String msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the nameOrg1
     */
    public String getNameOrg1() {
        return nameOrg1;
    }
    /**
     * @param nameOrg1 the nameOrg1 to set
     */
    public void setNameOrg1(String nameOrg1) {
        this.nameOrg1 = nameOrg1;
    }
    /**
     * @return the kvgr2
     */
    public String getKvgr2() {
        return kvgr2;
    }
    /**
     * @param kvgr2 the kvgr2 to set
     */
    public void setKvgr2(String kvgr2) {
        this.kvgr2 = kvgr2;
    }
    /**
     * @return the kvgr3
     */
    public String getKvgr3() {
        return kvgr3;
    }
    /**
     * @param kvgr3 the kvgr3 to set
     */
    public void setKvgr3(String kvgr3) {
        this.kvgr3 = kvgr3;
    }
    /**
     * @return the kvgr4
     */
    public String getKvgr4() {
        return kvgr4;
    }
    /**
     * @param kvgr4 the kvgr4 to set
     */
    public void setKvgr4(String kvgr4) {
        this.kvgr4 = kvgr4;
    }
    /**
     * @return the kvgr5
     */
    public String getKvgr5() {
        return kvgr5;
    }
    /**
     * @param kvgr5 the kvgr5 to set
     */
    public void setKvgr5(String kvgr5) {
        this.kvgr5 = kvgr5;
    }
    /**
     * @return the zpriceView
     */
    public String getZpriceView() {
        return zpriceView;
    }
    /**
     * @param zpriceView the zpriceView to set
     */
    public void setZpriceView(String zpriceView) {
        this.zpriceView = zpriceView;
    }
    /**
     * @return the iPltyp
     */
    public String getiPltyp() {
        return iPltyp;
    }
    /**
     * @param iPltyp the iPltyp to set
     */
    public void setiPltyp(String iPltyp) {
        this.iPltyp = iPltyp;
    }
    /**
     * @return the eUkursTxt
     */
    public String geteUkursTxt() {
        return eUkursTxt;
    }
    /**
     * @param eUkursTxt the eUkursTxt to set
     */
    public void seteUkursTxt(String eUkursTxt) {
        this.eUkursTxt = eUkursTxt;
    }
    /**
     * @return the zfileType
     */
    public String getZfileType() {
        return zfileType;
    }
    /**
     * @param zfileType the zfileType to set
     */
    public void setZfileType(String zfileType) {
        this.zfileType = zfileType;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the zfileSeqno
     */
    public String getZfileSeqno() {
        return zfileSeqno;
    }
    /**
     * @param zfileSeqno the zfileSeqno to set
     */
    public void setZfileSeqno(String zfileSeqno) {
        this.zfileSeqno = zfileSeqno;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }    
    
}
