package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.RfcOptionVO;
import com.mobis.maps.nmgn.sd.vo.CountryHsCodeVO;
import com.mobis.maps.nmgn.sd.vo.ImporterCountryVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CountryHsCodeService.java
 * @Description : ZJSDR50040 Country HS code by parts no
 * @author 이수지
 * @since 2020. 1. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 20.       이수지      	       최초 생성
 * </pre>
 */

public interface CountryHsCodeService {

    /**
     * CountryHsCodeService
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<CountryHsCodeVO> selectCountryHsCode (LoginInfoVO loginVo, CountryHsCodeVO params, List<RfcOptionVO> paramList) throws Exception;
    
    /**
     * ImporterCountryService
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<ImporterCountryVO> selectImporterCountry (LoginInfoVO loginVo, ImporterCountryVO params) throws Exception;
}
