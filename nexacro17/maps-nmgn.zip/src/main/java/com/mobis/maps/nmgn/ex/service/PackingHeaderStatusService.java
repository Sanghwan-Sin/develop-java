package com.mobis.maps.nmgn.ex.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.vo.PackingHeaderStatusVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingHeaderStatusService.java
 * @Description : ZJEXR00170 Packing Header Status
 * @author 이수지
 * @since 2020. 2. 4.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 4.       이수지      	        최초 생성
 * </pre>
 */

public interface PackingHeaderStatusService {

    /**
     * Packing Header Status
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<PackingHeaderStatusVO> selectPackingHeaderStatus (LoginInfoVO loginVo, PackingHeaderStatusVO params) throws Exception;
}
