package com.mobis.maps.nmgn.ex.web;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.service.InvoiceNoListService;
import com.mobis.maps.nmgn.ex.vo.InvoiceDetailVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceDownloadVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceExcelDownloadVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFtaCoPartsVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFtaCoVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceHeaderVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceNoListVO;
import com.mobis.maps.nmgn.ex.vo.InvoicePackingVO;
import com.mobis.maps.nmgn.ex.vo.InvoicePopVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceNoListController.java
 * @Description : Invoice List, Header, Detail
 * @author jiyongdo
 * @since 2020. 2. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 3.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class InvoiceNoListController extends HController{

    @Resource(name = "invoiceNoListService")
    private InvoiceNoListService invoiceNoListService;
    
    /**
     * selectInvoiceNoList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoiceNoList.do")
    public NexacroResult selectInvoiceNoList(@ParamDataSet(name="dsInput") InvoiceNoListVO paramVO
                                           , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = invoiceNoListService.selectInvoiceNoList(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        //InvoiceNoListVO rtnList = (InvoiceNoListVO)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<InvoiceNoListVO> retList = (List<InvoiceNoListVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", paramVO);   

        return result;
    }    
    
    /**
     * selectInvoiceNoListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoiceNoListExcelDown.do")
    public NexacroResult selectInvoiceNoListExcelDown(@ParamDataSet(name="dsInput") InvoiceNoListVO paramVO
                                                    , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);        
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        Map<String, Object> retMap = invoiceNoListService.selectInvoiceNoList(loginInfo, paramVO);
        
        @SuppressWarnings("unchecked")
        List<InvoiceNoListVO> retList = (List<InvoiceNoListVO>)retMap.get("body");
      
        result.addDataSet("dsOutput", retList);

        return result;
    }    
    
    /**
     * selectInvoiceNoList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoiceDetailList.do")
    public NexacroResult selectInvoiceDetailList(@ParamDataSet(name="dsInput") InvoiceDetailVO paramVO
                                               , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = invoiceNoListService.selectInvoiceDetailList(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        //InvoiceDetailVO rtnList = (InvoiceDetailVO)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<InvoiceDetailVO> retList = (List<InvoiceDetailVO>)retMap.get("body");
        for(int i = 0; i < retList.size(); i++)
        {
            retList.get(i).setInvoiceNo(paramVO.getiInvoice());
        }            
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", paramVO);   

        return result;
    }    
    
    /**
     * selectInvoiceNoListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoiceDetailListExcelDown.do")
    public NexacroResult selectInvoiceDetailListExcelDown(@ParamDataSet(name="dsInput") InvoiceDetailVO paramVO
                                                        , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);        
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        Map<String, Object> retMap = invoiceNoListService.selectInvoiceDetailList(loginInfo, paramVO);
        
        @SuppressWarnings("unchecked")
        List<InvoiceDetailVO> retList = (List<InvoiceDetailVO>)retMap.get("body");
      
        for(int i = 0; i < retList.size(); i++)
        {
            retList.get(i).setInvoiceNo(paramVO.getiInvoice());
        }        
        
        result.addDataSet("dsOutput", retList);

        return result;
    }      
    
    /**
     * selectInvoicePackingListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoicePackingListExcelDown.do")
    public NexacroResult selectInvoicePackingListExcelDown(@ParamDataSet(name="dsInput") InvoicePackingVO paramVO
                                                         , NexacroResult result) throws Exception {
         
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);        
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        List<InvoicePackingVO> packingVO = invoiceNoListService.selectInvoicePackingListExcelDown(loginInfo, paramVO);
      
        for(int i = 0; i < packingVO.size(); i++)
        {
            packingVO.get(i).setInvoiceNo(paramVO.getInvoiceNo());
        }        
        
        result.addDataSet("dsOutput", packingVO);

        return result;
    }       
    
    /**
     * selectInvoiceDownloadListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoiceDownloadListExcelDown.do")
    public NexacroResult selectInvoiceDownloadListExcelDown(@ParamDataSet(name="dsInput") InvoiceDownloadVO paramVO
                                                          , NexacroResult result) throws Exception {
         
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);        
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        List<InvoiceDownloadVO> downloadVO = invoiceNoListService.selectInvoiceDownloadListExcelDown(loginInfo, paramVO);
      
        for(int i = 0; i < downloadVO.size(); i++)
        {
            downloadVO.get(i).setInvoiceNo(paramVO.getInvoiceNo());
        }        
        
        result.addDataSet("dsOutput", downloadVO);

        return result;
    }      
    
    /**
     * selectInvoiceNoPopupList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoiceNoPopupList.do")
    public NexacroResult selectInvoiceNoPopupList(@ParamDataSet(name="dsInput") InvoicePopVO paramVO
                                               , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<InvoicePopVO> retList = invoiceNoListService.selectInvoiceNoPopupList(loginInfo, paramVO);
                  
        result.addDataSet("dsOutput", retList);

        return result;
    }   
    
    /**
     * selectInvoiceHeaderList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoiceHeaderList.do")
    public NexacroResult selectInvoiceHeaderList(@ParamDataSet(name="dsInput") InvoiceHeaderVO paramVO
                                               , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = invoiceNoListService.selectInvoiceHeaderList(loginInfo, paramVO);

        InvoiceHeaderVO retVO = (InvoiceHeaderVO)retMap.get("head");
        @SuppressWarnings("unchecked")
        List<InvoiceHeaderVO> retList = (List<InvoiceHeaderVO>)retMap.get("body");
        
        //retList.size() = Math.floorDiv(retList.size(),10)+1;

        InvoiceHeaderVO formatVo = new InvoiceHeaderVO();
        List<InvoiceHeaderVO> formatListVo = new ArrayList<InvoiceHeaderVO>();
        
        for(int idx = 0; retList != null && idx < retList.size(); idx++) {
            InvoiceHeaderVO item = retList.get(idx);
            int oidx = (idx%10) + 1;
            
            Method setter = formatVo.getClass().getMethod("setOrder"+oidx, new Class[]{String.class});
            setter.invoke(formatVo, new Object[]{item.getOrder()});
            
            if (oidx == 10 || idx == (retList.size() - 1)) {
                formatListVo.add(formatVo);
                formatVo = new InvoiceHeaderVO();
            }
        }

        result.addDataSet("dsOutput", formatListVo);
        result.addDataSet("dsOutput2", retVO);   
        result.addDataSet("dsOutput3", paramVO);   

        return result;        
    }     
    
    /**
     * selectInvoiceFtaCoListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoiceFtaCoListExcelDown.do")
    public NexacroResult selectInvoiceFtaCoListExcelDown(@ParamDataSet(name="dsInput") InvoiceFtaCoVO paramVO
                                                       , NexacroResult result) throws Exception {
         
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);        
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        List<InvoiceFtaCoVO> downloadVO = invoiceNoListService.selectInvoiceFtaCoListExcelDown(loginInfo, paramVO);
      
        for(int i = 0; i < downloadVO.size(); i++)
        {
            downloadVO.get(i).setInvoiceNo(paramVO.getiInvoice());
        }        
        
        result.addDataSet("dsOutput", downloadVO);

        return result;
    }      
    
    /**
     * selectInvoiceFtaCoPartsListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/ex/selectInvoiceFtaCoPartsListExcelDown.do")
    public NexacroResult selectInvoiceFtaCoPartsListExcelDown(@ParamDataSet(name="dsInput") InvoiceFtaCoPartsVO paramVO
                                                            , NexacroResult result) throws Exception {
         
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);        
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        List<InvoiceFtaCoPartsVO> downloadVO = invoiceNoListService.selectInvoiceFtaCoPartsListExcelDown(loginInfo, paramVO);
      
        for(int i = 0; i < downloadVO.size(); i++)
        {
            downloadVO.get(i).setInvoiceNo(paramVO.getiInvoice());
        }        
        
        result.addDataSet("dsOutput", downloadVO);

        return result;
    }
    
    
    @RequestMapping(value = "/ex/selectInvoiceExcelDown.do")
    public NexacroResult selectInvoiceExcelDown(@ParamDataSet(name="dsInput") List<InvoiceExcelDownloadVO> paramList
            , NexacroResult result) throws Exception {
         
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<InvoiceExcelDownloadVO> list = invoiceNoListService.selectInvoiceExcelDown(loginInfo, paramList);
        
        result.addDataSet("dsOutput", list);

        return result;
    }     
}
