package com.mobis.maps.nmgn.qm.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.qm.service.QualityNonconfirmityService;
import com.mobis.maps.nmgn.qm.vo.FormatDataVO;
import com.mobis.maps.nmgn.qm.vo.QualityNonconfirmityDetVO;
import com.mobis.maps.nmgn.qm.vo.QualityNonconfirmityVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityNonconfirmityController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 14.     jiyongdo     	최초 생성
 * </pre>
 */
@Controller
public class QualityNonconfirmityController extends HController{

    @Resource(name = "qualityNonconfirmityService")
    private QualityNonconfirmityService qualityNonconfirmityService;
    
    @RequestMapping(value = "/qm/selectQualityNonconfirmityList.do")
    public NexacroResult selectQualityNonconfirmityList(@ParamDataSet(name="dsInput") QualityNonconfirmityVO paramVO
                                                      , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = qualityNonconfirmityService.selectQualityNonconfirmityList(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        //QualityNonconfirmityVO totList = (QualityNonconfirmityVO) retMap.get("head");
        @SuppressWarnings("unchecked")
        List<QualityNonconfirmityVO> retList = (List<QualityNonconfirmityVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", paramVO);   

        return result;
    }
    
    @RequestMapping(value = "/qm/selectQualityNonconfirmityListExcelDown.do")
    public NexacroResult selectQualityNonconfirmityListExcelDown(@ParamDataSet(name="dsInput") QualityNonconfirmityVO paramVO
                                                               , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());        
        
        Map<String, Object> retMap = qualityNonconfirmityService.selectQualityNonconfirmityList(loginInfo, paramVO);  
        @SuppressWarnings("unchecked")
        List<QualityNonconfirmityVO> retList = (List<QualityNonconfirmityVO>)retMap.get("body");        
        result.addDataSet("dsOutput", retList);

        return result;
    }      
    
    @RequestMapping(value = "/qm/selectQualityNonconfirmityDetail.do")
    public NexacroResult selectQualityNonconfirmityDetail(@ParamDataSet(name="dsInput") QualityNonconfirmityDetVO paramVO
                                       , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = qualityNonconfirmityService.selectQualityNonconfirmityDetail(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        QualityNonconfirmityDetVO esRtn = (QualityNonconfirmityDetVO) retMap.get("esRtn");
        QualityNonconfirmityDetVO data = (QualityNonconfirmityDetVO) retMap.get("data");
        @SuppressWarnings("unchecked")
        List<QualityNonconfirmityDetVO> lotLst = (List<QualityNonconfirmityDetVO>)retMap.get("lotLst");
        @SuppressWarnings("unchecked")
        List<QualityNonconfirmityDetVO> txtLst1 = (List<QualityNonconfirmityDetVO>)retMap.get("txtLst1");
        @SuppressWarnings("unchecked")
        List<QualityNonconfirmityDetVO> txtLst2 = (List<QualityNonconfirmityDetVO>)retMap.get("txtLst2");
        @SuppressWarnings("unchecked")
        List<QualityNonconfirmityDetVO> txtLst3 = (List<QualityNonconfirmityDetVO>)retMap.get("txtLst3");               
        
        result.addDataSet("dsOutput", esRtn);
        result.addDataSet("dsOutput2", data);   
        result.addDataSet("dsOutput3", lotLst);   
        result.addDataSet("dsOutput4", txtLst1);   
        result.addDataSet("dsOutput5", txtLst2);  
        result.addDataSet("dsOutput6", txtLst3);  
        result.addDataSet("dsOutput7", paramVO);  
        
        return result;
    }    
    
    /***
     * @DESC : 양식다운로드  관련 RFC 공통 기능 호출
     * @RFC : ZPQM_CHNNL_S_FORMAT_DATA
     * Statements
     *
     * @param paramVo
     * @param result
     * @return FSCODE , REF_NO , FILE_SEQ_NO
     * @throws Exception
     */
    @RequestMapping(value = "/qm/selectFormatData.do")
    public NexacroResult selectFormatData(@ParamDataSet(name ="dsFormatIn") FormatDataVO paramVo
                                         ,NexacroResult result)throws Exception{
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        FormatDataVO resultVo =  qualityNonconfirmityService.selectFormatData(loginInfo, paramVo);
        
        result.addDataSet("dsFormat", resultVo);
        return result;
    }    
}
