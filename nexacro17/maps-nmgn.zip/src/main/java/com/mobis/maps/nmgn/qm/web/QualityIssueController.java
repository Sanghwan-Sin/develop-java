package com.mobis.maps.nmgn.qm.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.qm.service.QualityIssueService;
import com.mobis.maps.nmgn.qm.vo.ClaimCodeListVO;
import com.mobis.maps.nmgn.qm.vo.ClaimListVO;
import com.mobis.maps.nmgn.qm.vo.QualityIssueDetailVO;
import com.mobis.maps.nmgn.qm.vo.QualityIssueQnaVO;
import com.mobis.maps.nmgn.qm.vo.QualityIssueVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityIssueController.java
 * @Description : Quality Issue
 * @author jiyongdo
 * @since 2020. 3. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 17.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class QualityIssueController extends HController{

    @Resource(name = "qualityIssueService")
    private QualityIssueService qualityIssueService;
    
    /**
     * selectQualityIssueList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */        
    @RequestMapping(value = "/qm/selectQualityIssueList.do")
    public NexacroResult selectQualityIssueList(@ParamDataSet(name="dsInput") QualityIssueVO paramVO
                                              , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = qualityIssueService.selectQualityIssueList(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        //ClaimListVO totList = (ClaimListVO) retMap.get("head");
        @SuppressWarnings("unchecked")
        List<QualityIssueVO> retList = (List<QualityIssueVO>)retMap.get("body");
        for(int i = 0; i < retList.size(); i++)
        {
            retList.get(i).setRnum(retList.get(i).getRnum()+1);
        }        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", paramVO);   

        return result;
    }    
    
    /**
     * selectIssueTypeList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/qm/selectIssueTypeList.do")
    public NexacroResult selectIssueTypeList(@ParamDataSet(name="dsInput") ClaimCodeListVO paramVO
                                           , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<ClaimCodeListVO> retVo = qualityIssueService.selectIssueTypeList(loginInfo, paramVO);
        
        for(int i = 0; i < retVo.size(); i++)
        {
            retVo.get(i).setClcodeName(retVo.get(i).getClcodegr() + " : " + retVo.get(i).getClcodegrName());
        }        
        
        result.addDataSet("dsOutput", retVo);
        result.addDataSet("dsOutput2", paramVO);
       

        return result;
    }    
    
    /**
     * selectQualityIssueListExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */        
    @RequestMapping(value = "/qm/selectQualityIssueListExcelDown.do")
    public NexacroResult selectQualityIssueListExcelDown(@ParamDataSet(name="dsInput") QualityIssueVO paramVO
                                                       , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt()); 
        Map<String, Object> retMap = qualityIssueService.selectQualityIssueList(loginInfo, paramVO);

        @SuppressWarnings("unchecked")
        List<ClaimListVO> retList = (List<ClaimListVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList); 

        return result;
    }      
    
    /**
     * selectQualityIssueDetail
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */        
    @RequestMapping(value = "/qm/selectQualityIssueDetail.do")
    public NexacroResult selectQualityIssueDetail(@ParamDataSet(name="dsInput") QualityIssueDetailVO paramVO
                                              , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = qualityIssueService.selectQualityIssueDetail(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        //ClaimListVO totList = (ClaimListVO) retMap.get("head");
        QualityIssueDetailVO retVo = (QualityIssueDetailVO)retMap.get("body");
  
        result.addDataSet("dsOutput", retVo);
        result.addDataSet("dsOutput2", paramVO);   

        return result;
    }        
    
    @RequestMapping(value = "/qm/multiQualityIssueDetail.do")
    public NexacroResult multiQualityIssueDetail(@ParamDataSet(name="dsInput") QualityIssueDetailVO paramVO
                                               , @ParamDataSet(name="dsInput2") QualityIssueDetailVO rtnParamVO
                                               , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = qualityIssueService.multiQualityIssueDetail(paramVO, rtnParamVO, loginInfo);

        QualityIssueDetailVO rtnVo = (QualityIssueDetailVO)retMap.get("body");
        
        result.addDataSet("dsOutput", paramVO);
        
        if("S".equals(rtnVo.getMtype()))
        {
            QualityIssueDetailVO reSearch = new QualityIssueDetailVO();
            
            reSearch.setZcrud("R");
            reSearch.setZqissueno(rtnVo.getZqissueno());
            reSearch.setBukrs2(rtnVo.getBukrs2());
            reSearch.setZsyscode("");
            retMap = qualityIssueService.selectQualityIssueDetail(loginInfo, reSearch);
            
            rtnVo = (QualityIssueDetailVO)retMap.get("body");
        }
        
        result.addDataSet("dsOutput2", rtnVo);        

        return result;
    }    
    
    /**
     * selectQualityIssueQna
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */        
    @RequestMapping(value = "/qm/selectQualityIssueQna.do")
    public NexacroResult selectQualityIssueQna(@ParamDataSet(name="dsInput") QualityIssueQnaVO paramVO
                                             , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> retMap = qualityIssueService.selectQualityIssueQna(loginInfo, paramVO);

        //OdrUnprocessedItmLstVO retVO = (OdrUnprocessedItmLstVO)retMap.get("head");
        //ClaimListVO totList = (ClaimListVO) retMap.get("head");
        @SuppressWarnings("unchecked")
        List<QualityIssueQnaVO> retVoList = (List<QualityIssueQnaVO>)retMap.get("body");
  
        result.addDataSet("dsOutput", retVoList);
        result.addDataSet("dsOutput2", paramVO);   

        return result;
    }    
    
    /**
     * multiQualityIssueQna
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/qm/multiQualityIssueQna.do")
    public NexacroResult multiQualityIssueQna(@ParamDataSet(name="dsInput") QualityIssueQnaVO paramVO
                                            , @ParamDataSet(name="dsInput2") QualityIssueQnaVO rtnParamVO
                                            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = qualityIssueService.multiQualityIssueQna(paramVO, rtnParamVO, loginInfo);

        QualityIssueQnaVO rtnVo = (QualityIssueQnaVO)retMap.get("body");
        
        result.addDataSet("dsOutput", paramVO);
        result.addDataSet("dsOutput2", rtnVo);        

        return result;
    }      
}
