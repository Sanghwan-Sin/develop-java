package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.nmgn.cc.vo.DistSearchVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistSearchService.java
 * @Description : 대리점 검색
 * @author hong.minho
 * @since 2020. 3. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 13.     hong.minho     	최초 생성
 * </pre>
 */

public interface DistSearchService {

    /**
     * 대리점검색
     *
     * @param params
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    public List<DistSearchVO> selectDistSearch(DistSearchVO params) throws MapsBizException, Exception;
    
    
    /**
     * 대리점 정보 조회
     *
     * @param params
     * @param orgVo
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    public DistSearchVO selectDistInfo(DistSearchVO params, MapsOrgnztDistVO orgVo) throws MapsBizException, Exception;


    /**
     * 하위대리점 조회 (대표대리점의 경우)
     *
     * @param params
     * @param loginInfo
     * @param orgVo
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    public List<DistSearchVO> selectSubDistLst(DistSearchVO params, LoginInfoVO loginInfo, MapsOrgnztDistVO orgVo) throws MapsBizException, Exception;
}
