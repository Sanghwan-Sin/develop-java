package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.IssueTrackerService;
import com.mobis.maps.nmgn.sd.vo.IssueTrackerAddInputVO;
import com.mobis.maps.nmgn.sd.vo.IssueTrackerAddOutputVO;
import com.mobis.maps.nmgn.sd.vo.IssueTrackerVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : IssueTrackerController.java
 * @Description : ZJSDR01750 Issue Tracker(VOC Request)
 * @author ChoKyungHo
 * @since 2020. 03. 02.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 02.    ChoKyungHo     	          최초 생성
 * </pre>
 */
@Controller
public class IssueTrackerController extends HController{
    
    @Resource(name = "issueTrackerService")
    private IssueTrackerService issueTrackerService;
    
    
    /**
     * selectIssueTrackerList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */

    @RequestMapping(value = "/sd/selectIssueTrackerList.do")
    public NexacroResult selectIssueTrackerList(
            @ParamDataSet(name="dsInput") IssueTrackerVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        List<IssueTrackerVO> rtnLst = issueTrackerService.selectIssueTrackerList(loginInfo, paramVO);
        
        result.addDataSet("dsReturn", paramVO);
        result.addDataSet("dsOutput", rtnLst);

        return result;
    }
    
    /**
     * selectIssueTrackerExcelDown
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectIssueTrackerExcelDown.do")
    public NexacroResult selectIssueTrackerExcelDown(@ParamDataSet(name="dsInput") IssueTrackerVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(paramVO.getTotMaxCnt());
        
        List<IssueTrackerVO> list = issueTrackerService.selectIssueTrackerList(loginInfo, paramVO);
              
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectIssueTrackerDetail
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */

    @RequestMapping(value = "/sd/selectIssueTrackerDetail.do")
    public NexacroResult selectIssueTrackerDetail(
            @ParamDataSet(name="dsInput") IssueTrackerAddInputVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = issueTrackerService.selectIssueTrackerDetail(loginInfo, paramVO);
        

        IssueTrackerAddOutputVO retVO = (IssueTrackerAddOutputVO)retMap.get("detail");
        
        @SuppressWarnings("unchecked")
        List<IssueTrackerAddOutputVO> cLst = (List<IssueTrackerAddOutputVO>)retMap.get("content");
        @SuppressWarnings("unchecked")
        List<IssueTrackerAddOutputVO> rLst = (List<IssueTrackerAddOutputVO>)retMap.get("reply");

        result.addDataSet("dsOutput1", retVO);    
        result.addDataSet("dsOutput2", cLst);
        result.addDataSet("dsOutput3", rLst);

        return result;
    }
    
    /**
     * multiSaveIssueTrackerRequest
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */

    @RequestMapping(value = "/sd/multiSaveIssueTrackerRequest.do")
    public NexacroResult multiSaveIssueTrackerRequest(
             @ParamDataSet(name="dsInput1") IssueTrackerAddInputVO paramVO
            ,@ParamDataSet(name="dsInput2") List<IssueTrackerAddInputVO > paramComments
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = issueTrackerService.multiSaveIssueTrackerRequest(loginInfo, paramVO, paramComments);
        
        
        IssueTrackerAddOutputVO retVo = (IssueTrackerAddOutputVO)retMap.get("result");
        result.addDataSet("dsOutput",retVo);
        result.addDataSet("dsReturn",paramVO);
        

        return result;
    }
    
    
    /**
     * updateIssueTrackerRequest
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */

    @RequestMapping(value = "/sd/updateIssueTrackerRequest.do")
    public NexacroResult updateIssueTrackerRequest(
             @ParamDataSet(name="dsInput1") IssueTrackerAddInputVO paramVO
            ,@ParamDataSet(name="dsInput2") List<IssueTrackerAddInputVO > paramReply
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = issueTrackerService.updateIssueTrackerRequest(loginInfo, paramVO, paramReply);
        
        @SuppressWarnings("unchecked")
        List<IssueTrackerAddOutputVO> cLst = (List<IssueTrackerAddOutputVO>)retMap.get("content");
        result.addDataSet("dsOutput",cLst);
      
        result.addDataSet("dsReturn" ,paramVO);
        
        
        return result;
    }
}
