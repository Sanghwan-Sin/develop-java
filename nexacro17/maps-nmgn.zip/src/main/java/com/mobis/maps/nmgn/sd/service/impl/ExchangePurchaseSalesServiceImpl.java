package com.mobis.maps.nmgn.sd.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.util.StringUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.cc.service.DistSearchService;
import com.mobis.maps.nmgn.cc.vo.DistSearchVO;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.ExchangePurchaseSalesService;
import com.mobis.maps.nmgn.sd.vo.ExchangePurchaseDetailVO;
import com.mobis.maps.nmgn.sd.vo.ExchangePurchaseSalesVO;
import com.mobis.maps.nmgn.sd.vo.PartInfoVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ExchangePurchaseSalesServiceImpl.java
 * @Description : Dist. Exchange Purchase Sales List/Add
 * @author jiyongdo
 * @since 2020. 2. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 19.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("exchangePurchaseSalesService")
public class ExchangePurchaseSalesServiceImpl extends HService implements ExchangePurchaseSalesService{
    
    @Resource(name = "mapsCmmnSapService")  
    private MapsCommSapService mapsCmmnSapService;
    
    @Resource(name = "distSearchService")  
    private DistSearchService distSearchService;

    /*
     * @see com.mobis.maps.nmgn.sd.service.ExchangePurchaseSalesService#selectExchangePurchaseSalesList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.ExchangePurchaseSalesVO)
     */
    @Override
    public Map<String, Object> selectExchangePurchaseSalesList(LoginInfoVO loginInfo, ExchangePurchaseSalesVO paramVO)
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_DIST_EXCHANGE_LIST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<ExchangePurchaseSalesVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, ExchangePurchaseSalesVO.class);
        
        retMap.put("body", odrLst);       
        
        return retMap;     
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ExchangePurchaseSalesService#selectDistExchangeDetailList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.ExchangePurchaseDetailVO)
     */
    @Override
    public Map<String, Object> selectDistExchangeDetailList(LoginInfoVO loginInfo, ExchangePurchaseDetailVO paramVO)
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_DIST_EXCHANGE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        //ExchangePurchaseDetailVO HeadLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "CS_HEADER", ExchangePurchaseDetailVO.class);
        List<ExchangePurchaseDetailVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_ITEM", paramVO, ExchangePurchaseDetailVO.class);
        List<ExchangePurchaseDetailVO> headLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "CS_HEADER", paramVO, ExchangePurchaseDetailVO.class);

        // 대표대리점 조회
        ExchangePurchaseDetailVO vo = (headLst != null && headLst.size() > 0 ? headLst.get(0) : null); 

        if (vo != null) {
            // 대표대리점 조회
            DistSearchVO distVo = new DistSearchVO();
            MapsOrgnztDistVO orgVo = new MapsOrgnztDistVO();
            distVo.setZsacutm(vo.getZsacutmDist());
            distVo.setVkorg(loginInfo.getBsnOrgnztCd());
            distVo = distSearchService.selectDistInfo(distVo, orgVo);
            if(distVo != null && !StringUtil.isEmpty(distVo.getRefSacutm())){
                vo.setHighDistCd(distVo.getRefSacutm());        
            }
        } 
        
        retMap.put("head", headLst); 
        retMap.put("body", odrLst); 

        return retMap;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ExchangePurchaseSalesService#searchPartInfoList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.PartInfoVO)
     */
    @Override
    public Map<String, Object> selectPartInfoList(LoginInfoVO loginInfo, PartInfoVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_PART_INFO;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<PartInfoVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, PartInfoVO.class);
        
        retMap.put("body", odrLst); 
        
        return retMap;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ExchangePurchaseSalesService#saveDistExchangeDetailList(com.mobis.maps.nmgn.sd.vo.ExchangePurchaseDetailVO, com.mobis.maps.nmgn.sd.vo.ExchangePurchaseDetailVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, Object> multiSaveDistExchangeDetailList(ExchangePurchaseDetailVO paramVO,
            ExchangePurchaseDetailVO headerVO, List<ExchangePurchaseDetailVO> paramList, LoginInfoVO loginInfo)
            throws Exception {
        Map<String, Object>    retMap  = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_DIST_EXCHANGE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        // 파라미터(Import) 셋팅
        func.getImportParameterList().setValue("I_TYPE",       paramVO.getiType());
        func.getImportParameterList().setValue("I_ZDOCNUM",    paramVO.getiZdocnum());       
        
        MapsRfcMappperUtil.appendImportTableRow(func, "CS_HEADER", headerVO);
        
        // 파라미터(TABLES) 적재
        for(ExchangePurchaseDetailVO tmpVO : paramList) {
            if (!"N".equals(tmpVO.getRowSe()) && "Y".equals(tmpVO.getChkYn())) {
                switch (tmpVO.getRowSe()) {
                    case "I":
                        tmpVO.setZcrud("C");
                        break;
                    case "U":
                        tmpVO.setZcrud("U");
                        break;
                    case "D":
                        tmpVO.setZcrud("D");
                        break;
                    default:
                        break;
                }
                MapsRfcMappperUtil.appendImportTableRow(func, "T_ITEM", tmpVO);
            }
        }        
        
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        // 개별데이타 추출
        //List<ExchangePurchaseDetailVO> odrLst =  MapsRfcMappperUtil.getExportTableResultValues(funcRslt, "IT_DATA", ExchangePurchaseDetailVO.class);
        List<ExchangePurchaseDetailVO> retList =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_ITEM", ExchangePurchaseDetailVO.class);
        List<ExchangePurchaseDetailVO> headList =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "CS_HEADER", ExchangePurchaseDetailVO.class);
        retMap.put("body", retList);
        retMap.put("head", headList);
        
        return retMap;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.ExchangePurchaseSalesService#deleteDistExchangeDetailList(com.mobis.maps.nmgn.sd.vo.ExchangePurchaseDetailVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, Object> deleteDistExchangeDetailList(ExchangePurchaseDetailVO paramVO, LoginInfoVO loginInfo)
            throws Exception {
        Map<String, Object>    retMap  = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_DIST_EXCHANGE;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        // 파라미터(Import) 셋팅
        func.getImportParameterList().setValue("I_TYPE",       "D");
        func.getImportParameterList().setValue("I_ZDOCNUM",    paramVO.getiZdocnum());   
   
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);  
        List<ExchangePurchaseDetailVO> retList =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_ITEM", ExchangePurchaseDetailVO.class);
        retMap.put("body", retList);        
     
        return retMap;
    }
}
