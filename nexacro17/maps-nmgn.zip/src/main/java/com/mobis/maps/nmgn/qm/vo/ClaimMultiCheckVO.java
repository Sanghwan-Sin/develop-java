package com.mobis.maps.nmgn.qm.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimMultiCheckVO.java
 * @Description : Claim Multi Check
 * @author hong.minho
 * @since 2020. 10. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 10. 26.     hong.minho     	최초 생성
 * </pre>
 */

public class ClaimMultiCheckVO extends MapsCommSapRfcIfCommVO {

    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDIST" )
    private String iZdist;
    /** undefined */
    
    //-----[T_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZNO|ZNO" )
    private String zno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="MTYPE|MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="MESSAGE|MESSAGE" )
    private String message;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCLANO|ZCLANO" )
    private String zclano;
    /** Invoice No. */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZINVOICE|ZINVOICE" )
    private String zinvoice;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCASENO|ZCASENO" )
    private String zcaseno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="MATNR|MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="CLCODE|CLCODE" )
    private String clcode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="CLQTY|CLQTY" )
    private BigDecimal clqty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="LAGME|LAGME" )
    private String lagme;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZREIMTY|ZREIMTY" )
    private String zreimty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZPACKLOT|ZPACKLOT" )
    private String zpacklot;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCOMMENT|ZCOMMENT" )
    private String zcomment;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT1_FSCODE|ZATT1_FSCODE" )
    private String zatt1Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT1_REF_NO|ZATT1_REF_NO" )
    private String zatt1RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT1_FNAME|ZATT1_FNAME" )
    private String zatt1Fname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT2_FSCODE|ZATT2_FSCODE" )
    private String zatt2Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT2_REF_NO|ZATT2_REF_NO" )
    private String zatt2RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT2_FNAME|ZATT2_FNAME" )
    private String zatt2Fname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT3_FSCODE|ZATT3_FSCODE" )
    private String zatt3Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT3_REF_NO|ZATT3_REF_NO" )
    private String zatt3RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT3_FNAME|ZATT3_FNAME" )
    private String zatt3Fname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT4_FSCODE|ZATT4_FSCODE" )
    private String zatt4Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT4_REF_NO|ZATT4_REF_NO" )
    private String zatt4RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT4_FNAME|ZATT4_FNAME" )
    private String zatt4Fname;
    //-----[T_DATA] END-----
    
    /**
     * @return the iZdist
     */
    public String getiZdist() {
        return iZdist;
    }
    /**
     * @param iZdist the iZdist to set
     */
    public void setiZdist(String iZdist) {
        this.iZdist = iZdist;
    }
    /**
     * @return the zno
     */
    public String getZno() {
        return zno;
    }
    /**
     * @param zno the zno to set
     */
    public void setZno(String zno) {
        this.zno = zno;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the zclano
     */
    public String getZclano() {
        return zclano;
    }
    /**
     * @param zclano the zclano to set
     */
    public void setZclano(String zclano) {
        this.zclano = zclano;
    }
    /**
     * @return the zinvoice
     */
    public String getZinvoice() {
        return zinvoice;
    }
    /**
     * @param zinvoice the zinvoice to set
     */
    public void setZinvoice(String zinvoice) {
        this.zinvoice = zinvoice;
    }
    /**
     * @return the zcaseno
     */
    public String getZcaseno() {
        return zcaseno;
    }
    /**
     * @param zcaseno the zcaseno to set
     */
    public void setZcaseno(String zcaseno) {
        this.zcaseno = zcaseno;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the clcode
     */
    public String getClcode() {
        return clcode;
    }
    /**
     * @param clcode the clcode to set
     */
    public void setClcode(String clcode) {
        this.clcode = clcode;
    }
    /**
     * @return the clqty
     */
    public BigDecimal getClqty() {
        return clqty;
    }
    /**
     * @param clqty the clqty to set
     */
    public void setClqty(BigDecimal clqty) {
        this.clqty = clqty;
    }
    /**
     * @return the lagme
     */
    public String getLagme() {
        return lagme;
    }
    /**
     * @param lagme the lagme to set
     */
    public void setLagme(String lagme) {
        this.lagme = lagme;
    }
    /**
     * @return the zreimty
     */
    public String getZreimty() {
        return zreimty;
    }
    /**
     * @param zreimty the zreimty to set
     */
    public void setZreimty(String zreimty) {
        this.zreimty = zreimty;
    }
    /**
     * @return the zpacklot
     */
    public String getZpacklot() {
        return zpacklot;
    }
    /**
     * @param zpacklot the zpacklot to set
     */
    public void setZpacklot(String zpacklot) {
        this.zpacklot = zpacklot;
    }
    /**
     * @return the zcomment
     */
    public String getZcomment() {
        return zcomment;
    }
    /**
     * @param zcomment the zcomment to set
     */
    public void setZcomment(String zcomment) {
        this.zcomment = zcomment;
    }
    /**
     * @return the zatt1Fscode
     */
    public String getZatt1Fscode() {
        return zatt1Fscode;
    }
    /**
     * @param zatt1Fscode the zatt1Fscode to set
     */
    public void setZatt1Fscode(String zatt1Fscode) {
        this.zatt1Fscode = zatt1Fscode;
    }
    /**
     * @return the zatt1RefNo
     */
    public String getZatt1RefNo() {
        return zatt1RefNo;
    }
    /**
     * @param zatt1RefNo the zatt1RefNo to set
     */
    public void setZatt1RefNo(String zatt1RefNo) {
        this.zatt1RefNo = zatt1RefNo;
    }
    /**
     * @return the zatt1Fname
     */
    public String getZatt1Fname() {
        return zatt1Fname;
    }
    /**
     * @param zatt1Fname the zatt1Fname to set
     */
    public void setZatt1Fname(String zatt1Fname) {
        this.zatt1Fname = zatt1Fname;
    }
    /**
     * @return the zatt2Fscode
     */
    public String getZatt2Fscode() {
        return zatt2Fscode;
    }
    /**
     * @param zatt2Fscode the zatt2Fscode to set
     */
    public void setZatt2Fscode(String zatt2Fscode) {
        this.zatt2Fscode = zatt2Fscode;
    }
    /**
     * @return the zatt2RefNo
     */
    public String getZatt2RefNo() {
        return zatt2RefNo;
    }
    /**
     * @param zatt2RefNo the zatt2RefNo to set
     */
    public void setZatt2RefNo(String zatt2RefNo) {
        this.zatt2RefNo = zatt2RefNo;
    }
    /**
     * @return the zatt2Fname
     */
    public String getZatt2Fname() {
        return zatt2Fname;
    }
    /**
     * @param zatt2Fname the zatt2Fname to set
     */
    public void setZatt2Fname(String zatt2Fname) {
        this.zatt2Fname = zatt2Fname;
    }
    /**
     * @return the zatt3Fscode
     */
    public String getZatt3Fscode() {
        return zatt3Fscode;
    }
    /**
     * @param zatt3Fscode the zatt3Fscode to set
     */
    public void setZatt3Fscode(String zatt3Fscode) {
        this.zatt3Fscode = zatt3Fscode;
    }
    /**
     * @return the zatt3RefNo
     */
    public String getZatt3RefNo() {
        return zatt3RefNo;
    }
    /**
     * @param zatt3RefNo the zatt3RefNo to set
     */
    public void setZatt3RefNo(String zatt3RefNo) {
        this.zatt3RefNo = zatt3RefNo;
    }
    /**
     * @return the zatt3Fname
     */
    public String getZatt3Fname() {
        return zatt3Fname;
    }
    /**
     * @param zatt3Fname the zatt3Fname to set
     */
    public void setZatt3Fname(String zatt3Fname) {
        this.zatt3Fname = zatt3Fname;
    }
    /**
     * @return the zatt4Fscode
     */
    public String getZatt4Fscode() {
        return zatt4Fscode;
    }
    /**
     * @param zatt4Fscode the zatt4Fscode to set
     */
    public void setZatt4Fscode(String zatt4Fscode) {
        this.zatt4Fscode = zatt4Fscode;
    }
    /**
     * @return the zatt4RefNo
     */
    public String getZatt4RefNo() {
        return zatt4RefNo;
    }
    /**
     * @param zatt4RefNo the zatt4RefNo to set
     */
    public void setZatt4RefNo(String zatt4RefNo) {
        this.zatt4RefNo = zatt4RefNo;
    }
    /**
     * @return the zatt4Fname
     */
    public String getZatt4Fname() {
        return zatt4Fname;
    }
    /**
     * @param zatt4Fname the zatt4Fname to set
     */
    public void setZatt4Fname(String zatt4Fname) {
        this.zatt4Fname = zatt4Fname;
    }
    
}
