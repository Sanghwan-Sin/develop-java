package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplPriceRqstVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 9. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 26.     Jiyongdo     	최초 생성
 * </pre>
 */

public class ListPriceRqstVO extends MapsCommSapRfcIfCommVO {

    //-----[IS_MATNR] START-----
    /** ABAP: ID: I/E (포함/제외된 값) */
    @MapsRfcMappper( targetName="IS_MATNR", ipttSe="I", fieldKey="SIGN" )
    private String isMatnrSign;
    /** ABAP: 선택옵션 (EQ/BT/CP/...) */
    @MapsRfcMappper( targetName="IS_MATNR", ipttSe="I", fieldKey="OPTION" )
    private String isMatnrOption;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_MATNR", ipttSe="I", fieldKey="LOW" )
    private String isMatnrLow;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_MATNR", ipttSe="I", fieldKey="HIGH" )
    private String isMatnrHigh;
    //-----[IS_MATNR] END-----
    //-----[IS_REQDT] START-----
    /** ABAP: ID: I/E (포함/제외된 값) */
    @MapsRfcMappper( targetName="IS_REQDT", ipttSe="I", fieldKey="SIGN" )
    private String isReqDtsign;
    /** ABAP: 선택옵션 (EQ/BT/CP/...) */
    @MapsRfcMappper( targetName="IS_REQDT", ipttSe="I", fieldKey="OPTION" )
    private String isReqDtOption;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_REQDT", ipttSe="I", fieldKey="LOW" )
    private String isReqDtLow;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_REQDT", ipttSe="I", fieldKey="HIGH" )
    private String isReqDtHigh;
    //-----[IS_REQDT] END-----
    //-----[IS_REQNO] START-----
    /** ABAP: ID: I/E (포함/제외된 값) */
    @MapsRfcMappper( targetName="IS_REQNO", ipttSe="I", fieldKey="SIGN" )
    private String isReqNoSign;
    /** ABAP: 선택옵션 (EQ/BT/CP/...) */
    @MapsRfcMappper( targetName="IS_REQNO", ipttSe="I", fieldKey="OPTION" )
    private String isReqNoOption;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_REQNO", ipttSe="I", fieldKey="LOW" )
    private String isReqNoLow;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_REQNO", ipttSe="I", fieldKey="HIGH" )
    private String isReqNoHigh;
    //-----[IS_REQNO] END-----
    /** 언어 키 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_LANGU" )
    private String iLangu;
    /** Request Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQTY" )
    private String iReqty;
    /** 요청자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQUSER" )
    private String iRequser;
    /** 비고 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQ_REASON" )
    private String iReqReason;
    /** Status */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_STATUS" )
    private String iStatus;
    /** C/R/U/D (조회:R, 저장:C) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 현대/기아 구분자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** 대리점코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPROD_TYP" )
    private String iZprodTyp;    
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;    
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_REQ_SRC" )
    private String iReqSrc;    
    //-----[T_RESULT] START-----
    /** 타입(C 저장, U 업데이트) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="TYPE" )
    private String type;
    /** 고객코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** 조직의 이름 1 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NAME_ORG1" )
    private String nameOrg1;
    /** H/K */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** 유통 경로 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="VTWEG" )
    private String vtweg;
    /** Pricing Request No */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="REQNO" )
    private String reqno;
    /** 순번 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="SEQNO" )
    private Integer seqno;
    /** Request Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="REQTY" )
    private String reqty;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="MATNR" )
    private String matnr;
    /** 자재내역 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** Similarity PNO */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="MATNR_REF" )
    private String matnrRef;
    /** Reason for Request */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="REQ_REASON" )
    private String reqReason;
    /** 적용모델코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZVEH" )
    private String zveh;
    /** NEW PNC */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZPNC" )
    private String zpnc;
    /** SUC CODE-최종 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="ZSUC" )
    private String zsuc;
    /** 제품군 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="SPART" )
    private String spart;
    /** 가격 리스트 유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="PLTYP" )
    private String pltyp;
    /** 통화 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="WAERS" )
    private String waers;
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="REQ_LIST_PRICE" )
    private String reqListPrice;
    /** Requested date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="REQDT" )
    private Date reqdt;
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="APP_LIST_PRICE" )
    private String appListPrice;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="APPDT" )
    private Date appdt;
    /** Reason for Decision */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="I|E", fieldKey="DECISION_REASON" )
    private String decisionReason;
    /** Status */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="STATUS" )
    private String status;
    /** 상세내역 확인 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="DETAIL" )
    private String detail;
    /** Create Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /** Create User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCRNAME" )
    private String zcrname;
    /** Change Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDLDATE" )
    private Date zudldate;
    /** Change User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDNAME" )
    private String zudname;
    /** Change Local Time */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDLTIME" )
    private Date zudltime;
    /** 메세지 결과: S 성공, E 오류 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /** 메시지 텍스트 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** 메시지 번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MSGNO" )
    private BigDecimal msgno;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="REQ_SRC" )
    private String reqSrc;
    
    private String statusImg;
    private String xlsYn;
    private String chkRsltCd;
    private String chkRslt;
    
    /**
     * @return the isMatnrSign
     */
    public String getIsMatnrSign() {
        return isMatnrSign;
    }
    /**
     * @param isMatnrSign the isMatnrSign to set
     */
    public void setIsMatnrSign(String isMatnrSign) {
        this.isMatnrSign = isMatnrSign;
    }
    /**
     * @return the isMatnrOption
     */
    public String getIsMatnrOption() {
        return isMatnrOption;
    }
    /**
     * @param isMatnrOption the isMatnrOption to set
     */
    public void setIsMatnrOption(String isMatnrOption) {
        this.isMatnrOption = isMatnrOption;
    }
    /**
     * @return the isMatnrLow
     */
    public String getIsMatnrLow() {
        return isMatnrLow;
    }
    /**
     * @param isMatnrLow the isMatnrLow to set
     */
    public void setIsMatnrLow(String isMatnrLow) {
        this.isMatnrLow = isMatnrLow;
    }
    /**
     * @return the isMatnrHigh
     */
    public String getIsMatnrHigh() {
        return isMatnrHigh;
    }
    /**
     * @param isMatnrHigh the isMatnrHigh to set
     */
    public void setIsMatnrHigh(String isMatnrHigh) {
        this.isMatnrHigh = isMatnrHigh;
    }
    /**
     * @return the isReqDtsign
     */
    public String getIsReqDtsign() {
        return isReqDtsign;
    }
    /**
     * @param isReqDtsign the isReqDtsign to set
     */
    public void setIsReqDtsign(String isReqDtsign) {
        this.isReqDtsign = isReqDtsign;
    }
    /**
     * @return the isReqDtOption
     */
    public String getIsReqDtOption() {
        return isReqDtOption;
    }
    /**
     * @param isReqDtOption the isReqDtOption to set
     */
    public void setIsReqDtOption(String isReqDtOption) {
        this.isReqDtOption = isReqDtOption;
    }
    /**
     * @return the isReqDtLow
     */
    public String getIsReqDtLow() {
        return isReqDtLow;
    }
    /**
     * @param isReqDtLow the isReqDtLow to set
     */
    public void setIsReqDtLow(String isReqDtLow) {
        this.isReqDtLow = isReqDtLow;
    }
    /**
     * @return the isReqDtHigh
     */
    public String getIsReqDtHigh() {
        return isReqDtHigh;
    }
    /**
     * @param isReqDtHigh the isReqDtHigh to set
     */
    public void setIsReqDtHigh(String isReqDtHigh) {
        this.isReqDtHigh = isReqDtHigh;
    }
    /**
     * @return the isReqNoSign
     */
    public String getIsReqNoSign() {
        return isReqNoSign;
    }
    /**
     * @param isReqNoSign the isReqNoSign to set
     */
    public void setIsReqNoSign(String isReqNoSign) {
        this.isReqNoSign = isReqNoSign;
    }
    /**
     * @return the isReqNoOption
     */
    public String getIsReqNoOption() {
        return isReqNoOption;
    }
    /**
     * @param isReqNoOption the isReqNoOption to set
     */
    public void setIsReqNoOption(String isReqNoOption) {
        this.isReqNoOption = isReqNoOption;
    }
    /**
     * @return the isReqNoLow
     */
    public String getIsReqNoLow() {
        return isReqNoLow;
    }
    /**
     * @param isReqNoLow the isReqNoLow to set
     */
    public void setIsReqNoLow(String isReqNoLow) {
        this.isReqNoLow = isReqNoLow;
    }
    /**
     * @return the isReqNoHigh
     */
    public String getIsReqNoHigh() {
        return isReqNoHigh;
    }
    /**
     * @param isReqNoHigh the isReqNoHigh to set
     */
    public void setIsReqNoHigh(String isReqNoHigh) {
        this.isReqNoHigh = isReqNoHigh;
    }
    /**
     * @return the iLangu
     */
    public String getiLangu() {
        return iLangu;
    }
    /**
     * @param iLangu the iLangu to set
     */
    public void setiLangu(String iLangu) {
        this.iLangu = iLangu;
    }
    /**
     * @return the iReqty
     */
    public String getiReqty() {
        return iReqty;
    }
    /**
     * @param iReqty the iReqty to set
     */
    public void setiReqty(String iReqty) {
        this.iReqty = iReqty;
    }
    /**
     * @return the iRequser
     */
    public String getiRequser() {
        return iRequser;
    }
    /**
     * @param iRequser the iRequser to set
     */
    public void setiRequser(String iRequser) {
        this.iRequser = iRequser;
    }
    /**
     * @return the iReqReason
     */
    public String getiReqReason() {
        return iReqReason;
    }
    /**
     * @param iReqReason the iReqReason to set
     */
    public void setiReqReason(String iReqReason) {
        this.iReqReason = iReqReason;
    }
    /**
     * @return the iStatus
     */
    public String getiStatus() {
        return iStatus;
    }
    /**
     * @param iStatus the iStatus to set
     */
    public void setiStatus(String iStatus) {
        this.iStatus = iStatus;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZprodTyp
     */
    public String getiZprodTyp() {
        return iZprodTyp;
    }
    /**
     * @param iZprodTyp the iZprodTyp to set
     */
    public void setiZprodTyp(String iZprodTyp) {
        this.iZprodTyp = iZprodTyp;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the iReqSrc
     */
    public String getiReqSrc() {
        return iReqSrc;
    }
    /**
     * @param iReqSrc the iReqSrc to set
     */
    public void setiReqSrc(String iReqSrc) {
        this.iReqSrc = iReqSrc;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the nameOrg1
     */
    public String getNameOrg1() {
        return nameOrg1;
    }
    /**
     * @param nameOrg1 the nameOrg1 to set
     */
    public void setNameOrg1(String nameOrg1) {
        this.nameOrg1 = nameOrg1;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the reqno
     */
    public String getReqno() {
        return reqno;
    }
    /**
     * @param reqno the reqno to set
     */
    public void setReqno(String reqno) {
        this.reqno = reqno;
    }
    /**
     * @return the seqno
     */
    public Integer getSeqno() {
        return seqno;
    }
    /**
     * @param seqno the seqno to set
     */
    public void setSeqno(Integer seqno) {
        this.seqno = seqno;
    }
    /**
     * @return the reqty
     */
    public String getReqty() {
        return reqty;
    }
    /**
     * @param reqty the reqty to set
     */
    public void setReqty(String reqty) {
        this.reqty = reqty;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the matnrRef
     */
    public String getMatnrRef() {
        return matnrRef;
    }
    /**
     * @param matnrRef the matnrRef to set
     */
    public void setMatnrRef(String matnrRef) {
        this.matnrRef = matnrRef;
    }
    /**
     * @return the reqReason
     */
    public String getReqReason() {
        return reqReason;
    }
    /**
     * @param reqReason the reqReason to set
     */
    public void setReqReason(String reqReason) {
        this.reqReason = reqReason;
    }
    /**
     * @return the zveh
     */
    public String getZveh() {
        return zveh;
    }
    /**
     * @param zveh the zveh to set
     */
    public void setZveh(String zveh) {
        this.zveh = zveh;
    }
    /**
     * @return the zpnc
     */
    public String getZpnc() {
        return zpnc;
    }
    /**
     * @param zpnc the zpnc to set
     */
    public void setZpnc(String zpnc) {
        this.zpnc = zpnc;
    }
    /**
     * @return the zsuc
     */
    public String getZsuc() {
        return zsuc;
    }
    /**
     * @param zsuc the zsuc to set
     */
    public void setZsuc(String zsuc) {
        this.zsuc = zsuc;
    }
    /**
     * @return the spart
     */
    public String getSpart() {
        return spart;
    }
    /**
     * @param spart the spart to set
     */
    public void setSpart(String spart) {
        this.spart = spart;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the reqListPrice
     */
    public String getReqListPrice() {
        return reqListPrice;
    }
    /**
     * @param reqListPrice the reqListPrice to set
     */
    public void setReqListPrice(String reqListPrice) {
        this.reqListPrice = reqListPrice;
    }
    /**
     * @return the reqdt
     */
    public Date getReqdt() {
        return reqdt;
    }
    /**
     * @param reqdt the reqdt to set
     */
    public void setReqdt(Date reqdt) {
        this.reqdt = reqdt;
    }
    /**
     * @return the appListPrice
     */
    public String getAppListPrice() {
        return appListPrice;
    }
    /**
     * @param appListPrice the appListPrice to set
     */
    public void setAppListPrice(String appListPrice) {
        this.appListPrice = appListPrice;
    }
    /**
     * @return the appdt
     */
    public Date getAppdt() {
        return appdt;
    }
    /**
     * @param appdt the appdt to set
     */
    public void setAppdt(Date appdt) {
        this.appdt = appdt;
    }
    /**
     * @return the decisionReason
     */
    public String getDecisionReason() {
        return decisionReason;
    }
    /**
     * @param decisionReason the decisionReason to set
     */
    public void setDecisionReason(String decisionReason) {
        this.decisionReason = decisionReason;
    }
    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }
    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    /**
     * @return the detail
     */
    public String getDetail() {
        return detail;
    }
    /**
     * @param detail the detail to set
     */
    public void setDetail(String detail) {
        this.detail = detail;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zcrname
     */
    public String getZcrname() {
        return zcrname;
    }
    /**
     * @param zcrname the zcrname to set
     */
    public void setZcrname(String zcrname) {
        this.zcrname = zcrname;
    }
    /**
     * @return the zudldate
     */
    public Date getZudldate() {
        return zudldate;
    }
    /**
     * @param zudldate the zudldate to set
     */
    public void setZudldate(Date zudldate) {
        this.zudldate = zudldate;
    }
    /**
     * @return the zudname
     */
    public String getZudname() {
        return zudname;
    }
    /**
     * @param zudname the zudname to set
     */
    public void setZudname(String zudname) {
        this.zudname = zudname;
    }
    /**
     * @return the zudltime
     */
    public Date getZudltime() {
        return zudltime;
    }
    /**
     * @param zudltime the zudltime to set
     */
    public void setZudltime(Date zudltime) {
        this.zudltime = zudltime;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public BigDecimal getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(BigDecimal msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the reqSrc
     */
    public String getReqSrc() {
        return reqSrc;
    }
    /**
     * @param reqSrc the reqSrc to set
     */
    public void setReqSrc(String reqSrc) {
        this.reqSrc = reqSrc;
    }
    /**
     * @return the statusImg
     */
    public String getStatusImg() {
        return statusImg;
    }
    /**
     * @param statusImg the statusImg to set
     */
    public void setStatusImg(String statusImg) {
        this.statusImg = statusImg;
    }
    /**
     * @return the xlsYn
     */
    public String getXlsYn() {
        return xlsYn;
    }
    /**
     * @param xlsYn the xlsYn to set
     */
    public void setXlsYn(String xlsYn) {
        this.xlsYn = xlsYn;
    }
    /**
     * @return the chkRsltCd
     */
    public String getChkRsltCd() {
        return chkRsltCd;
    }
    /**
     * @param chkRsltCd the chkRsltCd to set
     */
    public void setChkRsltCd(String chkRsltCd) {
        this.chkRsltCd = chkRsltCd;
    }
    /**
     * @return the chkRslt
     */
    public String getChkRslt() {
        return chkRslt;
    }
    /**
     * @param chkRslt the chkRslt to set
     */
    public void setChkRslt(String chkRslt) {
        this.chkRslt = chkRslt;
    }
}
