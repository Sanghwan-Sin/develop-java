package com.mobis.maps.nmgn.mm.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackageImprovementVO.java
 * @Description : ZPMM_NMGN_R_LIST_PI_REQ
 * @author 이수지
 * @since 2020. 3.5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3.5.        이수지     	       최초 생성
 * </pre>
 */

public class PackageImprovementVO extends MapsCommSapRfcIfCommVO {
    
    /** 회사 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_BUKRS" )
    private String iBukrs;
    /** 대리점 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KUNNR" )
    private String iKunnr;
    /** 삭제 지시자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_LOEKZ" )
    private String iLoekz;
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** 사업장 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_WERKS" )
    private String iWerks;
    /** 내수/수출 구분 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZEDCD" )
    private String iZedcd;
    /** H/K 구분 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** 개선 담당자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZIMP_EMPNO" )
    private String iZimpEmpno;
    /** 의뢰일자(시작일) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQ_DATE_F" )
    private Date iZreqDateF;
    /** 의뢰일자(종료일) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQ_DATE_T" )
    private Date iZreqDateT;
    /** 진행 상태 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQ_STATUS" )
    private String iZreqStatus;
    /** 의뢰번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSPCNO" )
    private String iZspcno;
    /** 의뢰자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQ_EMPNO" )
    private String iZreqEmpno;
    /** 개선부서 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZIMP_DEPT" )
    private String iZimpDept;
    
    /** -----[ET_RESULT] START----- */
    
    /** 진행상태 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZREQ_STATUS" )
    private String zreqStatus;
    /** 의뢰번호 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZSPCNO" )
    private String zspcno;
    /** 의뢰일자 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZREQ_DATE" )
    private String zreqDate;
    /** Company Code */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="BUKRS" )
    private String bukrs;
    /** Name of Company Code or Company */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="BUTXT" )
    private String butxt;
    /** 사업장 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="WERKS" )
    private String werks;
    /** 사업장명 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZWERKS_TXT" )
    private String zwerksTxt;
    /** Customer Number */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="KUNNR" )
    private String kunnr;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** H/K구분 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** 내수/수출 구분 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZEDCD" )
    private String zedcd;
    /** 부품/용품 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZPA_FLG" )
    private String zpaFlg;
    /** 부품/용품 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZPA_FLG_TXT" )
    private String zpaFlgTxt;
    /** 발생지역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZAREA" )
    private String zarea;
    /** 발생지역 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZAREA_TXT" )
    private String zareaTxt;
    /** 발생처 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZOCC_GB" )
    private String zoccGb;
    /** Char 20 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZOCC_GB_TXT" )
    private String zoccGbTxt;
    /** 개선구분 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZIMPGB" )
    private String zimpgb;
    /** 개선구분 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZIMPGB_TXT" )
    private String zimpgbTxt;
    /** 불량유형 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZUNFIT_TYPE" )
    private String zunfitType;
    /** 불량유형 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZUNFIT_TYPE_TXT" )
    private String zunfitTypeTxt;
    /** 의뢰부서 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZDEPT" )
    private String zdept;
    /** 의뢰부서 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZDEPT_TXT" )
    private String zdeptTxt;
    /** 의뢰자 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZREQ_EMPNO" )
    private String zreqEmpno;
    /** 개선부서  */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="I|E", fieldKey="ZIMP_DEPT" )
    private String zimpDept;
    /** 개선부서 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZIMP_DEPT_TXT" )
    private String zimpDeptTxt;
    /** 포장업체코드 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="LIFNR" )
    private String lifnr;
    /** Name */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** 1차 검토결과 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZSND_RESULT" )
    private String zsndResult;
    /**  */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZSND_RESULT_TXT" )
    private String zsndResultTxt;
    /** 2차 검토결과 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZRESULT" )
    private String zresult;
    /** 2차검토결과 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZRESULT_TXT" )
    private String zresultTxt;
    /** 최종검토결과 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZFIN_RESULT" )
    private String zfinResult;
    /** 최종검토결과 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZFIN_RESULT_TXT" )
    private String zfinResultTxt;
    /** 승인여부 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZEND_STATUS" )
    private String zendStatus;
    /** 최종검토결과 내역 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZEND_STATUS_TXT" )
    private String zendStatusTxt;
    /** 결재일자 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZEND_DATE" )
    private String zendDate;
    /** 1차검토일자 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZSND_DATE" )
    private String zsndDate;
    /** 2차검토일자 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZIMP_DATE" )
    private String zimpDate;
    /** 최종검토일자 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="ZFIN_DATE" )
    private String zfinDate;
    /** 삭제지시자 */
    @MapsRfcMappper( targetName="ET_RESULT", ipttSe="E", fieldKey="LOEKZ" )
    private String loekz;
    
    /** -----[ET_RESULT] END----- */       
    
    /**
     * @return the iBukrs
     */
    public String getiBukrs() {
        return iBukrs;
    }
    /**
     * @param iBukrs the iBukrs to set
     */
    public void setiBukrs(String iBukrs) {
        this.iBukrs = iBukrs;
    }
    /**
     * @return the iLoekz
     */
    public String getiLoekz() {
        return iLoekz;
    }
    /**
     * @param iLoekz the iLoekz to set
     */
    public void setiLoekz(String iLoekz) {
        this.iLoekz = iLoekz;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iWerks
     */
    public String getiWerks() {
        return iWerks;
    }
    /**
     * @param iWerks the iWerks to set
     */
    public void setiWerks(String iWerks) {
        this.iWerks = iWerks;
    }
    /**
     * @return the iZedcd
     */
    public String getiZedcd() {
        return iZedcd;
    }
    /**
     * @param iZedcd the iZedcd to set
     */
    public void setiZedcd(String iZedcd) {
        this.iZedcd = iZedcd;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZimpEmpno
     */
    public String getiZimpEmpno() {
        return iZimpEmpno;
    }
    /**
     * @param iZimpEmpno the iZimpEmpno to set
     */
    public void setiZimpEmpno(String iZimpEmpno) {
        this.iZimpEmpno = iZimpEmpno;
    }
    /**
     * @return the iZreqDateF
     */
    public Date getiZreqDateF() {
        return iZreqDateF;
    }
    /**
     * @param iZreqDateF the iZreqDateF to set
     */
    public void setiZreqDateF(Date iZreqDateF) {
        this.iZreqDateF = iZreqDateF;
    }
    /**
     * @return the iZreqDateT
     */
    public Date getiZreqDateT() {
        return iZreqDateT;
    }
    /**
     * @param iZreqDateT the iZreqDateT to set
     */
    public void setiZreqDateT(Date iZreqDateT) {
        this.iZreqDateT = iZreqDateT;
    }
    /**
     * @return the iZreqStatus
     */
    public String getiZreqStatus() {
        return iZreqStatus;
    }
    /**
     * @param iZreqStatus the iZreqStatus to set
     */
    public void setiZreqStatus(String iZreqStatus) {
        this.iZreqStatus = iZreqStatus;
    }
    /**
     * @return the iZspcno
     */
    public String getiZspcno() {
        return iZspcno;
    }
    /**
     * @param iZspcno the iZspcno to set
     */
    public void setiZspcno(String iZspcno) {
        this.iZspcno = iZspcno;
    }
    /**
     * @return the zreqStatus
     */
    public String getZreqStatus() {
        return zreqStatus;
    }
    /**
     * @param zreqStatus the zreqStatus to set
     */
    public void setZreqStatus(String zreqStatus) {
        this.zreqStatus = zreqStatus;
    }
    /**
     * @return the zspcno
     */
    public String getZspcno() {
        return zspcno;
    }
    /**
     * @param zspcno the zspcno to set
     */
    public void setZspcno(String zspcno) {
        this.zspcno = zspcno;
    }
    /**
     * @return the zreqDate
     */
    public String getZreqDate() {
        return zreqDate;
    }
    /**
     * @param zreqDate the zreqDate to set
     */
    public void setZreqDate(String zreqDate) {
        this.zreqDate = zreqDate;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the butxt
     */
    public String getButxt() {
        return butxt;
    }
    /**
     * @param butxt the butxt to set
     */
    public void setButxt(String butxt) {
        this.butxt = butxt;
    }
    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }
    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }
    /**
     * @return the zwerksTxt
     */
    public String getZwerksTxt() {
        return zwerksTxt;
    }
    /**
     * @param zwerksTxt the zwerksTxt to set
     */
    public void setZwerksTxt(String zwerksTxt) {
        this.zwerksTxt = zwerksTxt;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zedcd
     */
    public String getZedcd() {
        return zedcd;
    }
    /**
     * @param zedcd the zedcd to set
     */
    public void setZedcd(String zedcd) {
        this.zedcd = zedcd;
    }
    /**
     * @return the zpaFlg
     */
    public String getZpaFlg() {
        return zpaFlg;
    }
    /**
     * @param zpaFlg the zpaFlg to set
     */
    public void setZpaFlg(String zpaFlg) {
        this.zpaFlg = zpaFlg;
    }
    /**
     * @return the zpaFlgTxt
     */
    public String getZpaFlgTxt() {
        return zpaFlgTxt;
    }
    /**
     * @param zpaFlgTxt the zpaFlgTxt to set
     */
    public void setZpaFlgTxt(String zpaFlgTxt) {
        this.zpaFlgTxt = zpaFlgTxt;
    }
    /**
     * @return the zarea
     */
    public String getZarea() {
        return zarea;
    }
    /**
     * @param zarea the zarea to set
     */
    public void setZarea(String zarea) {
        this.zarea = zarea;
    }
    /**
     * @return the zareaTxt
     */
    public String getZareaTxt() {
        return zareaTxt;
    }
    /**
     * @param zareaTxt the zareaTxt to set
     */
    public void setZareaTxt(String zareaTxt) {
        this.zareaTxt = zareaTxt;
    }
    /**
     * @return the zoccGb
     */
    public String getZoccGb() {
        return zoccGb;
    }
    /**
     * @param zoccGb the zoccGb to set
     */
    public void setZoccGb(String zoccGb) {
        this.zoccGb = zoccGb;
    }
    /**
     * @return the zoccGbTxt
     */
    public String getZoccGbTxt() {
        return zoccGbTxt;
    }
    /**
     * @param zoccGbTxt the zoccGbTxt to set
     */
    public void setZoccGbTxt(String zoccGbTxt) {
        this.zoccGbTxt = zoccGbTxt;
    }
    /**
     * @return the zimpgb
     */
    public String getZimpgb() {
        return zimpgb;
    }
    /**
     * @param zimpgb the zimpgb to set
     */
    public void setZimpgb(String zimpgb) {
        this.zimpgb = zimpgb;
    }
    /**
     * @return the zimpgbTxt
     */
    public String getZimpgbTxt() {
        return zimpgbTxt;
    }
    /**
     * @param zimpgbTxt the zimpgbTxt to set
     */
    public void setZimpgbTxt(String zimpgbTxt) {
        this.zimpgbTxt = zimpgbTxt;
    }
    /**
     * @return the zunfitType
     */
    public String getZunfitType() {
        return zunfitType;
    }
    /**
     * @param zunfitType the zunfitType to set
     */
    public void setZunfitType(String zunfitType) {
        this.zunfitType = zunfitType;
    }
    /**
     * @return the zunfitTypeTxt
     */
    public String getZunfitTypeTxt() {
        return zunfitTypeTxt;
    }
    /**
     * @param zunfitTypeTxt the zunfitTypeTxt to set
     */
    public void setZunfitTypeTxt(String zunfitTypeTxt) {
        this.zunfitTypeTxt = zunfitTypeTxt;
    }
    /**
     * @return the zdept
     */
    public String getZdept() {
        return zdept;
    }
    /**
     * @param zdept the zdept to set
     */
    public void setZdept(String zdept) {
        this.zdept = zdept;
    }
    /**
     * @return the zdeptTxt
     */
    public String getZdeptTxt() {
        return zdeptTxt;
    }
    /**
     * @param zdeptTxt the zdeptTxt to set
     */
    public void setZdeptTxt(String zdeptTxt) {
        this.zdeptTxt = zdeptTxt;
    }
    /**
     * @return the zreqEmpno
     */
    public String getZreqEmpno() {
        return zreqEmpno;
    }
    /**
     * @param zreqEmpno the zreqEmpno to set
     */
    public void setZreqEmpno(String zreqEmpno) {
        this.zreqEmpno = zreqEmpno;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zsndResult
     */
    public String getZsndResult() {
        return zsndResult;
    }
    /**
     * @param zsndResult the zsndResult to set
     */
    public void setZsndResult(String zsndResult) {
        this.zsndResult = zsndResult;
    }
    /**
     * @return the zsndResultTxt
     */
    public String getZsndResultTxt() {
        return zsndResultTxt;
    }
    /**
     * @param zsndResultTxt the zsndResultTxt to set
     */
    public void setZsndResultTxt(String zsndResultTxt) {
        this.zsndResultTxt = zsndResultTxt;
    }
    /**
     * @return the zresult
     */
    public String getZresult() {
        return zresult;
    }
    /**
     * @param zresult the zresult to set
     */
    public void setZresult(String zresult) {
        this.zresult = zresult;
    }
    /**
     * @return the zresultTxt
     */
    public String getZresultTxt() {
        return zresultTxt;
    }
    /**
     * @param zresultTxt the zresultTxt to set
     */
    public void setZresultTxt(String zresultTxt) {
        this.zresultTxt = zresultTxt;
    }
    /**
     * @return the zfinResult
     */
    public String getZfinResult() {
        return zfinResult;
    }
    /**
     * @param zfinResult the zfinResult to set
     */
    public void setZfinResult(String zfinResult) {
        this.zfinResult = zfinResult;
    }
    /**
     * @return the zfinResultTxt
     */
    public String getZfinResultTxt() {
        return zfinResultTxt;
    }
    /**
     * @param zfinResultTxt the zfinResultTxt to set
     */
    public void setZfinResultTxt(String zfinResultTxt) {
        this.zfinResultTxt = zfinResultTxt;
    }
    /**
     * @return the zendStatus
     */
    public String getZendStatus() {
        return zendStatus;
    }
    /**
     * @param zendStatus the zendStatus to set
     */
    public void setZendStatus(String zendStatus) {
        this.zendStatus = zendStatus;
    }
    /**
     * @return the zendStatusTxt
     */
    public String getZendStatusTxt() {
        return zendStatusTxt;
    }
    /**
     * @param zendStatusTxt the zendStatusTxt to set
     */
    public void setZendStatusTxt(String zendStatusTxt) {
        this.zendStatusTxt = zendStatusTxt;
    }
    /**
     * @return the zendDate
     */
    public String getZendDate() {
        return zendDate;
    }
    /**
     * @param zendDate the zendDate to set
     */
    public void setZendDate(String zendDate) {
        this.zendDate = zendDate;
    }
    /**
     * @return the zsndDate
     */
    public String getZsndDate() {
        return zsndDate;
    }
    /**
     * @param zsndDate the zsndDate to set
     */
    public void setZsndDate(String zsndDate) {
        this.zsndDate = zsndDate;
    }
    /**
     * @return the zimpDate
     */
    public String getZimpDate() {
        return zimpDate;
    }
    /**
     * @param zimpDate the zimpDate to set
     */
    public void setZimpDate(String zimpDate) {
        this.zimpDate = zimpDate;
    }
    /**
     * @return the zfinDate
     */
    public String getZfinDate() {
        return zfinDate;
    }
    /**
     * @param zfinDate the zfinDate to set
     */
    public void setZfinDate(String zfinDate) {
        this.zfinDate = zfinDate;
    }
    /**
     * @return the loekz
     */
    public String getLoekz() {
        return loekz;
    }
    /**
     * @param loekz the loekz to set
     */
    public void setLoekz(String loekz) {
        this.loekz = loekz;
    }
    /**
     * @return the iZreqEmpno
     */
    public String getiZreqEmpno() {
        return iZreqEmpno;
    }
    /**
     * @param iZreqEmpno the iZreqEmpno to set
     */
    public void setiZreqEmpno(String iZreqEmpno) {
        this.iZreqEmpno = iZreqEmpno;
    }
    /**
     * @return the zimpDept
     */
    public String getZimpDept() {
        return zimpDept;
    }
    /**
     * @param zimpDept the zimpDept to set
     */
    public void setZimpDept(String zimpDept) {
        this.zimpDept = zimpDept;
    }
    /**
     * @return the zimpDeptTxt
     */
    public String getZimpDeptTxt() {
        return zimpDeptTxt;
    }
    /**
     * @param zimpDeptTxt the zimpDeptTxt to set
     */
    public void setZimpDeptTxt(String zimpDeptTxt) {
        this.zimpDeptTxt = zimpDeptTxt;
    }
    /**
     * @return the iZimpDept
     */
    public String getiZimpDept() {
        return iZimpDept;
    }
    /**
     * @param iZimpDept the iZimpDept to set
     */
    public void setiZimpDept(String iZimpDept) {
        this.iZimpDept = iZimpDept;
    }
    /**
     * @return the iKunnr
     */
    public String getiKunnr() {
        return iKunnr;
    }
    /**
     * @param iKunnr the iKunnr to set
     */
    public void setiKunnr(String iKunnr) {
        this.iKunnr = iKunnr;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    
}
