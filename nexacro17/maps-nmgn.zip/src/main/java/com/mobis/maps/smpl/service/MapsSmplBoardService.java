package com.mobis.maps.smpl.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.smpl.vo.MapsSmplBoardVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplBoardService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

public interface MapsSmplBoardService {

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    List<MapsSmplBoardVO> selectSmplBoardList(MapsSmplBoardVO inputVO) throws Exception;

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsSmplBoardVO selectSmplBoardNewList(MapsSmplBoardVO inputVO) throws Exception;

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsSmplBoardVO multiSmplBoard(MapsSmplBoardVO inputVO) throws Exception;

    /**
     * Statements
     *
     * @param atchFileVO
     * @param atchFiles
     * @return
     */
    int multiAtchFile(MapsSmplBoardVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception;

}
