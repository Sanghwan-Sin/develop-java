package com.mobis.maps.nmgn.sd.vo;


import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CanvassListVO.java
 * @Description : ZPSD_NMGN_R_CANVASS_LIST
 * @author 이수지
 * @since 2020. 2. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *   2020. 2. 25.     이수지     	       최초 생성
 * </pre>
 */

public class CanvassListVO extends MapsCommSapRfcIfCommVO {
    
    private int ordQty = 0; // 오더수량
    private String evenRow = "";
    
    
    /** Category */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CATEGORY" )
    private String iCategory;
    /** Dist Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** Publication Date - From */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PUBDATE" )
    private Date iPubdate;
    /** Publication Date - To */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PUBDATE_TO" )
    private Date iPubdateTo;
    /** 단일 문자 표시 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    
    /** -----[T_RESULT] START----- */
    
    /** H/K 구분 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** Canvass No. */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCANVNO" )
    private String zcanvno;
    /** Canvass Name */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCANVNM" )
    private String zcanvnm;
    /** Category */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCATEGORY" )
    private String zcategory;
    /** 완료요청일 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZDUEDT" )
    private Date zduedt;
    /** Model Name */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMODEL" )
    private String zmodel;
    /** Material Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Region */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZVERSION" )
    private String zversion;
    /** Publication Schedule Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPLANDT" )
    private Date zplandt;
    /** Publication Schedule Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPUBTP" )
    private String zpubtp;
    /** Publication Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPUBDT" )
    private Date zpubdt;
    /** 오더번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO" )
    private String zordno;
    
    /** -----[T_RESULT] END----- */
    
    
    /**
     * @return the iCategory
     */
    public String getiCategory() {
        return iCategory;
    }
    /**
     * @param iCategory the iCategory to set
     */
    public void setiCategory(String iCategory) {
        this.iCategory = iCategory;
    }
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iPubdate
     */
    public Date getiPubdate() {
        return iPubdate;
    }
    /**
     * @param iPubdate the iPubdate to set
     */
    public void setiPubdate(Date iPubdate) {
        this.iPubdate = iPubdate;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zcanvno
     */
    public String getZcanvno() {
        return zcanvno;
    }
    /**
     * @param zcanvno the zcanvno to set
     */
    public void setZcanvno(String zcanvno) {
        this.zcanvno = zcanvno;
    }
    /**
     * @return the zcanvnm
     */
    public String getZcanvnm() {
        return zcanvnm;
    }
    /**
     * @param zcanvnm the zcanvnm to set
     */
    public void setZcanvnm(String zcanvnm) {
        this.zcanvnm = zcanvnm;
    }
    /**
     * @return the zcategory
     */
    public String getZcategory() {
        return zcategory;
    }
    /**
     * @param zcategory the zcategory to set
     */
    public void setZcategory(String zcategory) {
        this.zcategory = zcategory;
    }
    /**
     * @return the zduedt
     */
    public Date getZduedt() {
        return zduedt;
    }
    /**
     * @param zduedt the zduedt to set
     */
    public void setZduedt(Date zduedt) {
        this.zduedt = zduedt;
    }
    /**
     * @return the zmodel
     */
    public String getZmodel() {
        return zmodel;
    }
    /**
     * @param zmodel the zmodel to set
     */
    public void setZmodel(String zmodel) {
        this.zmodel = zmodel;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zversion
     */
    public String getZversion() {
        return zversion;
    }
    /**
     * @param zversion the zversion to set
     */
    public void setZversion(String zversion) {
        this.zversion = zversion;
    }
    /**
     * @return the zplandt
     */
    public Date getZplandt() {
        return zplandt;
    }
    /**
     * @param zplandt the zplandt to set
     */
    public void setZplandt(Date zplandt) {
        this.zplandt = zplandt;
    }
    /**
     * @return the zpubtp
     */
    public String getZpubtp() {
        return zpubtp;
    }
    /**
     * @param zpubtp the zpubtp to set
     */
    public void setZpubtp(String zpubtp) {
        this.zpubtp = zpubtp;
    }
    /**
     * @return the zpubdt
     */
    public Date getZpubdt() {
        return zpubdt;
    }
    /**
     * @param zpubdt the zpubdt to set
     */
    public void setZpubdt(Date zpubdt) {
        this.zpubdt = zpubdt;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the ordQty
     */
    public int getOrdQty() {
        return ordQty;
    }
    /**
     * @param ordQty the ordQty to set
     */
    public void setOrdQty(int ordQty) {
        this.ordQty = ordQty;
    }
    /**
     * @return the evenRow
     */
    public String getEvenRow() {
        return evenRow;
    }
    /**
     * @param evenRow the evenRow to set
     */
    public void setEvenRow(String evenRow) {
        this.evenRow = evenRow;
    }
    /**
     * @return the iPubdateTo
     */
    public Date getiPubdateTo() {
        return iPubdateTo;
    }
    /**
     * @param iPubdateTo the iPubdateTo to set
     */
    public void setiPubdateTo(Date iPubdateTo) {
        this.iPubdateTo = iPubdateTo;
    }              
    
}
