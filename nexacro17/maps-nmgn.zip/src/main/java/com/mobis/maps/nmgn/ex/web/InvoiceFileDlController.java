package com.mobis.maps.nmgn.ex.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.service.InvoiceFileDlService;
import com.mobis.maps.nmgn.ex.vo.InvoiceFileDlVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFileInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceFileDlController.java
 * @Description : ZJEXR00300 Invoice Download
 * @author 이수지
 * @since 2020. 07. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 07. 27.     이수지                최초 생성
 * </pre>
 */

@Controller
public class InvoiceFileDlController extends HController {

    @Resource(name = "invoiceFileDlService")
    private InvoiceFileDlService invoiceFileDlService;

    /**
     * selectInvoiceFileDl
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectInvoiceFileDl.do")
    public NexacroResult selectInvoiceFileDl(@ParamDataSet(name="dsInput") InvoiceFileDlVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<InvoiceFileDlVO> list = invoiceFileDlService.selectInvoiceFileDl(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectInvoiceFileExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectInvoiceFileExcelDown.do")
    public NexacroResult selectInvoiceFileExcelDown(@ParamDataSet(name="dsInput") List<InvoiceFileInfoVO> paramList
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = invoiceFileDlService.selectInvoiceFileDlInfo(loginInfo, paramList);      

        @SuppressWarnings("unchecked")
        List<InvoiceFileInfoVO> bodyList = (List<InvoiceFileInfoVO>)retMap.get("body");
        InvoiceFileInfoVO excelVo = (InvoiceFileInfoVO)retMap.get("excel");
      
        result.addDataSet("dsOutput1", bodyList);
        result.addDataSet("dsOutput2", excelVo);
        
        return result;
    }
    
    /**
     * selectInvoiceTxtDownload
     *
     * @param params,request,response
     * @param 
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ex/selectInvoiceTxtDownload.do")
    public void selectInvoiceTxtDownload(@RequestParam("invoiceNo") String[] invoiceNo
            , @RequestParam("fileName") String fileName
            , HttpServletRequest request
            , HttpServletResponse response) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        invoiceFileDlService.selectInvoiceTxtDownload(loginInfo, invoiceNo, fileName, request, response);
        
        return;
    } 
}
