package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ZPSDS3256VO.java
 * @Description : MOFF : Order Confirm List
 * @author hong.minho
 * @since 2020. 6. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 24.     hong.minho     	최초 생성
 * </pre>
 */

public class ZPSDS3256VO extends MapsCommSapRfcIfCommVO {
    private String detail01; /* [detail01,0~10] Order Number */
    private String detail02; /* [detail02,10~18] Proforma Number */
    private String detail03; /* [detail03,18~26] Confirmed Date */
    private String detail04; /* [detail04,26~37] Total Amount */
    private String detail05; /* [detail05,37~46] Total Pieces */
    private String detail06; /* [detail06,46~53] Total Count of Items */
    private String detail07; /* [detail07,53~60] Volume */
    private String detail08; /* [detail08,60~67] Weight */
    private String detail09; /* [detail09,67~71] Line Item Number */
    private String detail10; /* [detail10,71~72] Line Item Number Suffix */
    private String detail11; /* [detail11,72~90] Confirmed Part Number */
    private String detail12; /* [detail12,90~103] Part Name */
    private String detail13; /* [detail13,103~110] Normal Quantity */
    private String detail14; /* [detail14,110~117] Abnormal Quantity */
    private String detail15; /* [detail15,117~124] Unit Price */
    private String detail16; /* [detail16,124~126] Amend Code */
    private String detail17; /* [detail17,126~144] Ordered Part Number */
    private String detail18; /* [detail18,144~152] ETD */
    private String detail19; /* [detail19,152~153] Intermediary Trade */
    
    /**
     * @return the detail01
     */
    public String getDetail01() {
        return detail01;
    }
    /**
     * @param detail01 the detail01 to set
     */
    public void setDetail01(String detail01) {
        this.detail01 = detail01;
    }
    /**
     * @return the detail02
     */
    public String getDetail02() {
        return detail02;
    }
    /**
     * @param detail02 the detail02 to set
     */
    public void setDetail02(String detail02) {
        this.detail02 = detail02;
    }
    /**
     * @return the detail03
     */
    public String getDetail03() {
        return detail03;
    }
    /**
     * @param detail03 the detail03 to set
     */
    public void setDetail03(String detail03) {
        this.detail03 = detail03;
    }
    /**
     * @return the detail04
     */
    public String getDetail04() {
        return detail04;
    }
    /**
     * @param detail04 the detail04 to set
     */
    public void setDetail04(String detail04) {
        this.detail04 = detail04;
    }
    /**
     * @return the detail05
     */
    public String getDetail05() {
        return detail05;
    }
    /**
     * @param detail05 the detail05 to set
     */
    public void setDetail05(String detail05) {
        this.detail05 = detail05;
    }
    /**
     * @return the detail06
     */
    public String getDetail06() {
        return detail06;
    }
    /**
     * @param detail06 the detail06 to set
     */
    public void setDetail06(String detail06) {
        this.detail06 = detail06;
    }
    /**
     * @return the detail07
     */
    public String getDetail07() {
        return detail07;
    }
    /**
     * @param detail07 the detail07 to set
     */
    public void setDetail07(String detail07) {
        this.detail07 = detail07;
    }
    /**
     * @return the detail08
     */
    public String getDetail08() {
        return detail08;
    }
    /**
     * @param detail08 the detail08 to set
     */
    public void setDetail08(String detail08) {
        this.detail08 = detail08;
    }
    /**
     * @return the detail09
     */
    public String getDetail09() {
        return detail09;
    }
    /**
     * @param detail09 the detail09 to set
     */
    public void setDetail09(String detail09) {
        this.detail09 = detail09;
    }
    /**
     * @return the detail10
     */
    public String getDetail10() {
        return detail10;
    }
    /**
     * @param detail10 the detail10 to set
     */
    public void setDetail10(String detail10) {
        this.detail10 = detail10;
    }
    /**
     * @return the detail11
     */
    public String getDetail11() {
        return detail11;
    }
    /**
     * @param detail11 the detail11 to set
     */
    public void setDetail11(String detail11) {
        this.detail11 = detail11;
    }
    /**
     * @return the detail12
     */
    public String getDetail12() {
        return detail12;
    }
    /**
     * @param detail12 the detail12 to set
     */
    public void setDetail12(String detail12) {
        this.detail12 = detail12;
    }
    /**
     * @return the detail13
     */
    public String getDetail13() {
        return detail13;
    }
    /**
     * @param detail13 the detail13 to set
     */
    public void setDetail13(String detail13) {
        this.detail13 = detail13;
    }
    /**
     * @return the detail14
     */
    public String getDetail14() {
        return detail14;
    }
    /**
     * @param detail14 the detail14 to set
     */
    public void setDetail14(String detail14) {
        this.detail14 = detail14;
    }
    /**
     * @return the detail15
     */
    public String getDetail15() {
        return detail15;
    }
    /**
     * @param detail15 the detail15 to set
     */
    public void setDetail15(String detail15) {
        this.detail15 = detail15;
    }
    /**
     * @return the detail16
     */
    public String getDetail16() {
        return detail16;
    }
    /**
     * @param detail16 the detail16 to set
     */
    public void setDetail16(String detail16) {
        this.detail16 = detail16;
    }
    /**
     * @return the detail17
     */
    public String getDetail17() {
        return detail17;
    }
    /**
     * @param detail17 the detail17 to set
     */
    public void setDetail17(String detail17) {
        this.detail17 = detail17;
    }
    /**
     * @return the detail18
     */
    public String getDetail18() {
        return detail18;
    }
    /**
     * @param detail18 the detail18 to set
     */
    public void setDetail18(String detail18) {
        this.detail18 = detail18;
    }
    /**
     * @return the detail19
     */
    public String getDetail19() {
        return detail19;
    }
    /**
     * @param detail19 the detail19 to set
     */
    public void setDetail19(String detail19) {
        this.detail19 = detail19;
    }

}
