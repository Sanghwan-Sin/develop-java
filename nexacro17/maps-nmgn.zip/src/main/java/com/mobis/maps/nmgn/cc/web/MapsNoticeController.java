package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.nmgn.cc.service.MapsNoticeService;
import com.mobis.maps.nmgn.cc.vo.MapsNoticeAtchFileVO;
import com.mobis.maps.nmgn.cc.vo.MapsNoticeVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsNoticeController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class MapsNoticeController extends HController{
    @Resource(name = "mapsNoticeService")
    private MapsNoticeService mapsNoticeService;
    
    @RequestMapping(value = "/cc/selectNoticeList.do")
    public NexacroResult selectNoticeList(@ParamDataSet(name="dsInput") MapsNoticeVO inputVO
                                           , NexacroResult result) throws Exception {
        List<MapsNoticeVO> resultVo = mapsNoticeService.selectNoticeList(inputVO);

        result.addDataSet("dsOutput", resultVo);

        return result;
    }    
    
    @RequestMapping(value = "/cc/selectNoticeNewList.do")
    public NexacroResult selectNoticeNewList(@ParamDataSet(name="dsInput") MapsNoticeVO inputVO
                                              , NexacroResult result) throws Exception {
        MapsNoticeVO resultVo = mapsNoticeService.selectNoticeNewList(inputVO);

        result.addDataSet("dsOutput", resultVo);

        return result;
    }      
    
    @RequestMapping(value = "/cc/multiNotice.do")
    public NexacroResult multiNotice(
            @ParamDataSet(name="dsInput") MapsNoticeVO inputVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        inputVO.setRegistId(loginInfo.getUserId());
        inputVO.setUpdtId(loginInfo.getUserId());

        MapsNoticeVO resultVo = mapsNoticeService.multiNotice(inputVO);
        
        result.addDataSet("dsOutput", resultVo);

        return result;
    }
    
    /**
     * 첨부파일 등록
     *
     * @param noticeAtchFileVO
     * @param atchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/multiNoticeAtchFile.do")
    public NexacroResult multiNoticeAtchFile(
            @ParamDataSet(name="dsInput") MapsNoticeAtchFileVO mapsNoticeAtchFileVO
            , @ParamDataSet(name="dsInputAtchFile") List<MapsAtchFileVO> atchFiles
            , NexacroResult result) throws Exception {
        
        int procCnt = mapsNoticeService.multiNoticeAtchFile(mapsNoticeAtchFileVO, atchFiles);

        result.addVariable("procCnt", procCnt);

        return result;
    }
}
