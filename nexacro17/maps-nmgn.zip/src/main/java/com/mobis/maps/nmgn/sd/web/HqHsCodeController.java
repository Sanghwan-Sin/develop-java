package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.RfcOptionVO;
import com.mobis.maps.nmgn.sd.service.HqHsCodeService;
import com.mobis.maps.nmgn.sd.vo.HqFtaAgreementVO;
import com.mobis.maps.nmgn.sd.vo.HqHsCodeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : HqHsCodeController.java
 * @Description : ZJSDR50030 HQ HS code by parts no
 * @author 이수지
 * @since 2020. 1. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 17.       이수지                최초 생성
 * </pre>
 */

@Controller
public class HqHsCodeController extends HController {

    @Resource(name = "hqHsCodeService")
    private HqHsCodeService hqHsCodeService;

    /**
     * selectHqHsCode
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectHqHsCode.do")
    public NexacroResult selectHqHsCode(@ParamDataSet(name="dsInput") HqHsCodeVO params
                                      , @ParamDataSet(name="dsMultiPartCd") List<RfcOptionVO> paramList
                                      , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setPgSize(params.getTotMaxCnt());        
        List<HqHsCodeVO> list = hqHsCodeService.selectHqHsCode(loginInfo, params, paramList);
        
        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectHqHsCodeExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectHqHsCodeExcelDown.do")
    public NexacroResult selectHqHsCodeExcelDown(@ParamDataSet(name="dsInput") HqHsCodeVO params
                                               , @ParamDataSet(name="dsMultiPartCd") List<RfcOptionVO> paramList
                                               , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<HqHsCodeVO> list = hqHsCodeService.selectHqHsCode(loginInfo, params, paramList);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectHqFtaAgreement
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectHqFtaAgreement.do")
    public NexacroResult selectHqFtaAgreement(@ParamDataSet(name="dsInput") HqFtaAgreementVO params
                                      , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<HqFtaAgreementVO> list = hqHsCodeService.selectHqFtaAgreement(loginInfo, params);
        
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
}
