package com.mobis.maps.nmgn.sd.vo;


import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : BatteryShippingVO.java
 * @Description : ZPSD_NMGN_S_BATTERY
 * @author 이수지
 * @since 2020. 8. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *   2020. 8. 10.     이수지     	       최초 생성
 * </pre>
 */

public class BatteryShippingVO extends MapsCommSapRfcIfCommVO {
    
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** 부품명칭 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPTNM" )
    private String iZptnm;

    /** -----[T_DATA] START----- */
    
    /** 자재 번호 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** 부품명칭 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /** H/K 구분 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** 공급업체 또는 채권자의 계정 번호 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LIFNR" )
    private String lifnr;
    /** 이름 1 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** 부품 등록일자 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZINS_DATE" )
    private Date zinsDate;
    /** 대표모델코드 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZKEY_VHC" )
    private String zkeyVhc;
    /** LPD최후발주일자 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZLPD" )
    private String zlpd;
    /** File Server ID */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;
    /** Reference Number */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REF_NO1" )
    private String refNo1;
    /** 등록일 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZATTACH_DATE_U" )
    private String zattachDateU;
    /** UN38.3 등록상태 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZATTACH_ST_U" )
    private String zattachStU;
    /** SOC(%) */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZSOC" )
    private BigDecimal zsoc;
    /** 무게(KG) */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZWEIGHT" )
    private BigDecimal zweight;
    /** 35Kg 초과 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZWEIGHT35" )
    private String zweight35;
    /** 항공가능여부 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZAIRPOSSIBLE" )
    private String zairpossible;
    /** 합성방지 유무 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZHSBGOX_TXT" )
    private String zhsbgoxTxt;
    /** 역전류 방지 유무 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZYJRBGOX_TXT" )
    private String zyjrbgoxTxt;
    
    /** -----[T_DATA] END-----  */  
    
    
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iZptnm
     */
    public String getiZptnm() {
        return iZptnm;
    }
    /**
     * @param iZptnm the iZptnm to set
     */
    public void setiZptnm(String iZptnm) {
        this.iZptnm = iZptnm;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the lifnr
     */
    public String getLifnr() {
        return lifnr;
    }
    /**
     * @param lifnr the lifnr to set
     */
    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zinsDate
     */
    public Date getZinsDate() {
        return zinsDate;
    }
    /**
     * @param zinsDate the zinsDate to set
     */
    public void setZinsDate(Date zinsDate) {
        this.zinsDate = zinsDate;
    }
    /**
     * @return the zkeyVhc
     */
    public String getZkeyVhc() {
        return zkeyVhc;
    }
    /**
     * @param zkeyVhc the zkeyVhc to set
     */
    public void setZkeyVhc(String zkeyVhc) {
        this.zkeyVhc = zkeyVhc;
    }
    /**
     * @return the zlpd
     */
    public String getZlpd() {
        return zlpd;
    }
    /**
     * @param zlpd the zlpd to set
     */
    public void setZlpd(String zlpd) {
        this.zlpd = zlpd;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the refNo1
     */
    public String getRefNo1() {
        return refNo1;
    }
    /**
     * @param refNo1 the refNo1 to set
     */
    public void setRefNo1(String refNo1) {
        this.refNo1 = refNo1;
    }
    /**
     * @return the zattachDateU
     */
    public String getZattachDateU() {
        return zattachDateU;
    }
    /**
     * @param zattachDateU the zattachDateU to set
     */
    public void setZattachDateU(String zattachDateU) {
        this.zattachDateU = zattachDateU;
    }
    /**
     * @return the zattachStU
     */
    public String getZattachStU() {
        return zattachStU;
    }
    /**
     * @param zattachStU the zattachStU to set
     */
    public void setZattachStU(String zattachStU) {
        this.zattachStU = zattachStU;
    }
    /**
     * @return the zsoc
     */
    public BigDecimal getZsoc() {
        return zsoc;
    }
    /**
     * @param zsoc the zsoc to set
     */
    public void setZsoc(BigDecimal zsoc) {
        this.zsoc = zsoc;
    }
    /**
     * @return the zweight
     */
    public BigDecimal getZweight() {
        return zweight;
    }
    /**
     * @param zweight the zweight to set
     */
    public void setZweight(BigDecimal zweight) {
        this.zweight = zweight;
    }
    /**
     * @return the zweight35
     */
    public String getZweight35() {
        return zweight35;
    }
    /**
     * @param zweight35 the zweight35 to set
     */
    public void setZweight35(String zweight35) {
        this.zweight35 = zweight35;
    }
    /**
     * @return the zairpossible
     */
    public String getZairpossible() {
        return zairpossible;
    }
    /**
     * @param zairpossible the zairpossible to set
     */
    public void setZairpossible(String zairpossible) {
        this.zairpossible = zairpossible;
    }
    /**
     * @return the zhsbgoxTxt
     */
    public String getZhsbgoxTxt() {
        return zhsbgoxTxt;
    }
    /**
     * @param zhsbgoxTxt the zhsbgoxTxt to set
     */
    public void setZhsbgoxTxt(String zhsbgoxTxt) {
        this.zhsbgoxTxt = zhsbgoxTxt;
    }
    /**
     * @return the zyjrbgoxTxt
     */
    public String getZyjrbgoxTxt() {
        return zyjrbgoxTxt;
    }
    /**
     * @param zyjrbgoxTxt the zyjrbgoxTxt to set
     */
    public void setZyjrbgoxTxt(String zyjrbgoxTxt) {
        this.zyjrbgoxTxt = zyjrbgoxTxt;
    }
     
}
