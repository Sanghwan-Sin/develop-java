package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionProfileVO.java
 * @Description : RFC : ZPSD_MGN_S_PROMOTION_PROFILE (Promotion Profile List를 조회하는 VO)
 * @author ChoKyungHo
 * @since 2020. 03. 06.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 06.    ChoKyungHo     	       최초 생성
 * </pre>
 */

public class PromotionProfileVO extends MapsCommSapRfcIfCommVO {
    /** -----[IS_DATES] START----- */
    /** ABAP: ID: I/E (include/exclude values) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="SIGN" )
    private String iSign;
    /** ABAP: Selection option (EQ/BT/CP/...) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="OPTION" )
    private String iOption;
    /** Apply Date From */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="LOW" )
    private String iLow;
    /** Apply Date To */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="HIGH" )
    private String iHigh;
    
    
    /** C/R/U/D (조회:R) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 프로모션 Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPRTYP" )
    private String iZprtyp;
    /** 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** Sub 대리점코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    
    
    /** -----[T_RESULT] START----- */
    /** 프로모션 프로파일 번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPI" )
    private String zppi;
    /** 프로모션 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRNM" )
    private String zprnm;
    /** 프로모션 Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRTYP" )
    private String zprtyp;
    /** 프로모션 Type명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRTYP_NM" )
    private String zprtypNm;
    /** 발생유형코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPOTYP" )
    private String zpotyp;
    /** 발생유형코드명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPOTYP_NM" )
    private String zpotypNm;
    
    
    /**
     * @return the iSign
     */
    public String getiSign() {
        return iSign;
    }
    /**
     * @param iSign the iSign to set
     */
    public void setiSign(String iSign) {
        this.iSign = iSign;
    }
    /**
     * @return the iOption
     */
    public String getiOption() {
        return iOption;
    }
    /**
     * @param iOption the iOption to set
     */
    public void setiOption(String iOption) {
        this.iOption = iOption;
    }
    /**
     * @return the iLow
     */
    public String getiLow() {
        return iLow;
    }
    /**
     * @param iLow the iLow to set
     */
    public void setiLow(String iLow) {
        this.iLow = iLow;
    }
    /**
     * @return the iHigh
     */
    public String getiHigh() {
        return iHigh;
    }
    /**
     * @param iHigh the iHigh to set
     */
    public void setiHigh(String iHigh) {
        this.iHigh = iHigh;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZprtyp
     */
    public String getiZprtyp() {
        return iZprtyp;
    }
    /**
     * @param iZprtyp the iZprtyp to set
     */
    public void setiZprtyp(String iZprtyp) {
        this.iZprtyp = iZprtyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zppi
     */
    public String getZppi() {
        return zppi;
    }
    /**
     * @param zppi the zppi to set
     */
    public void setZppi(String zppi) {
        this.zppi = zppi;
    }
    /**
     * @return the zprnm
     */
    public String getZprnm() {
        return zprnm;
    }
    /**
     * @param zprnm the zprnm to set
     */
    public void setZprnm(String zprnm) {
        this.zprnm = zprnm;
    }
    /**
     * @return the zprtyp
     */
    public String getZprtyp() {
        return zprtyp;
    }
    /**
     * @param zprtyp the zprtyp to set
     */
    public void setZprtyp(String zprtyp) {
        this.zprtyp = zprtyp;
    }
    /**
     * @return the zprtypNm
     */
    public String getZprtypNm() {
        return zprtypNm;
    }
    /**
     * @param zprtypNm the zprtypNm to set
     */
    public void setZprtypNm(String zprtypNm) {
        this.zprtypNm = zprtypNm;
    }
    /**
     * @return the zpotyp
     */
    public String getZpotyp() {
        return zpotyp;
    }
    /**
     * @param zpotyp the zpotyp to set
     */
    public void setZpotyp(String zpotyp) {
        this.zpotyp = zpotyp;
    }
    /**
     * @return the zpotypNm
     */
    public String getZpotypNm() {
        return zpotypNm;
    }
    /**
     * @param zpotypNm the zpotypNm to set
     */
    public void setZpotypNm(String zpotypNm) {
        this.zpotypNm = zpotypNm;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }    
}
