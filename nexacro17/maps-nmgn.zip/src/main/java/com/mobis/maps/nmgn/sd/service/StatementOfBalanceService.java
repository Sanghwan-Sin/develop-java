package com.mobis.maps.nmgn.sd.service;

import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.StatementOfBalanceVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : StatementOfBalanceService.java
 * @Description : Statement of Balance
 * @author jiyongdo
 * @since 2020. 4. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 14.     jiyongdo     	최초 생성
 * </pre>
 */

public interface StatementOfBalanceService {

    /**
     * Statement of Balance 조회
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectStatementOfBalanceList(LoginInfoVO loginInfo, StatementOfBalanceVO paramVO) throws Exception;

}
