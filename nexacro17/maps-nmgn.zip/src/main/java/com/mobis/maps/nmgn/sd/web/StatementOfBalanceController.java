package com.mobis.maps.nmgn.sd.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.AccountCdSearchService;
import com.mobis.maps.nmgn.sd.service.StatementOfBalanceService;
import com.mobis.maps.nmgn.sd.vo.AccountSearchVO;
import com.mobis.maps.nmgn.sd.vo.StatementOfBalanceVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : StatementofBalanceController.java
 * @Description : Statement of Balance
 * @author jiyongdo
 * @since 2020. 4. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 14.     jiyongdo     	최초 생성
 * </pre>
 */

@Controller
public class StatementOfBalanceController extends HController{
    
    @Resource(name = "statementOfBalanceService")
    private StatementOfBalanceService statementOfBalanceService;
    
    @Resource(name = "accountCdSearchService")
    private AccountCdSearchService accountCdSearchService;
    
    /**
     * selectStatementOfBalanceList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectStatementOfBalanceList.do")
    public NexacroResult selectStatementOfBalanceList(@ParamDataSet(name="dsInput") StatementOfBalanceVO paramVO
                                                    , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = statementOfBalanceService.selectStatementOfBalanceList(loginInfo, paramVO);
        
        @SuppressWarnings("unchecked")
        List<StatementOfBalanceVO> retList = (List<StatementOfBalanceVO>)retMap.get("body");
        StatementOfBalanceVO retVo = (StatementOfBalanceVO)retMap.get("head");
        
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsOutput2", retVo);
        result.addDataSet("dsReturn", paramVO);   

        return result;
    }    
    
    /**
     * selectStatementOfBalanceList
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectStatementOfBalanceListExcelDown.do")
    public NexacroResult selectStatementOfBalanceListExcelDown(@ParamDataSet(name="dsInput") StatementOfBalanceVO paramVO
                                                             , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);     
        
        paramVO.setExcelDwnlYn("Y");
        paramVO.setPgNum(1);
        paramVO.setPgSize(5000);        
        
        Map<String, Object> retMap = statementOfBalanceService.selectStatementOfBalanceList(loginInfo, paramVO);
        
        @SuppressWarnings("unchecked")
        List<StatementOfBalanceVO> retList = (List<StatementOfBalanceVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList);

        return result;
    }  
    
    /**
     * 어카운트 검색
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectAccountCd.do")
    public NexacroResult selectAccountCd (@ParamDataSet(name="dsInput") AccountSearchVO paramVO
                                            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        Map<String, Object> retMap = accountCdSearchService.selectAccountCdList(loginInfo, paramVO);
        
        @SuppressWarnings("unchecked")
        List<AccountSearchVO> retList = (List<AccountSearchVO>)retMap.get("body");
        
        result.addDataSet("dsOutput", retList);

        result.addDataSet("dsReturn", paramVO);   

        return result;
    }    
}
