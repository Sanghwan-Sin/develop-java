package com.mobis.maps.nmgn.sd.service;

import java.io.File;
import java.util.List;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.OrderCanvassNoVO;
import com.mobis.maps.nmgn.sd.vo.OrderEntryVO;
import com.mobis.maps.nmgn.sd.vo.OrderShipModeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderEntryService.java
 * @Description : ZJSDO30240 Order Placement
 * @author 홍민호
 * @since 2020. 2. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 20.     홍민호     	최초 생성
 * </pre>
 */

public interface OrderEntryService {
    
    
    /**
     * Order Entry 조회
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<OrderEntryVO> selectOrderEntry(LoginInfoVO loginVo, OrderEntryVO params) throws Exception;
    
    /**
     * Order Entry 저장
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<OrderEntryVO> multiSaveOrderEntry(LoginInfoVO loginVo, OrderEntryVO params, List<OrderEntryVO> paramLst) throws Exception;
    
    
    /**
     * 부품번호 체크
     *
     * @param loginVo
     * @param params
     * @param paramLst
     * @return
     * @throws Exception
     */
    List<OrderEntryVO> selectOrderMatnrChk(LoginInfoVO loginVo, OrderEntryVO params, List<OrderEntryVO> paramLst) throws MapsBizException, Exception;

    
    

    /**
     * Order Entry TXT upload
     *
     * @param params
     * @return
     * @throws Exception
     */
    List<OrderEntryVO> selectOrderEntryTxtUpload(LoginInfoVO loginVo, File fUp) throws Exception;
    
    
    /**
     * Canvass No List
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<OrderCanvassNoVO> selectCanvassNoLst(LoginInfoVO loginVo, OrderCanvassNoVO params) throws Exception;
    
    
    /**
     * Ship Mode List
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<OrderShipModeVO> selectShipMode(LoginInfoVO loginVo, OrderShipModeVO params) throws Exception;
    
    
}
