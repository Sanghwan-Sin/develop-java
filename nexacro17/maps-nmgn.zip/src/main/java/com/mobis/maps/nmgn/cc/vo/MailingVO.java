package com.mobis.maps.nmgn.cc.vo;

import java.util.ArrayList;
import java.util.List;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MailingVO.java
 * @Description : MailingMgr
 * @author hong.minho
 * @since 2020. 4. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 14.     hong.minho     	최초 생성
 * </pre>
 */

public class MailingVO extends MapsCommSapRfcIfCommVO {
    // Mailing Classification CODE
    public static final String CD_EMLTP_10 = "10"; // Order
    public static final String CD_EMLTP_11 = "11"; // Claim
    public static final String CD_EMLTP_12 = "12"; // Download
    public static final String CD_EMLTP_13 = "13"; // VOC
    public static final String CD_EMLTP_14 = "14"; // Payment
    public static final String CD_EMLTP_15 = "15"; // Monthly Report
    public static final String CD_EMLTP_60 = "60"; // News Letter
    
    private boolean includeSubDist = false; // 하위대리점도 포함할지 여부
    
    private List<String> ikunnrs = new ArrayList<String>(); // 다건 처리용
    private List<String> emltps = new ArrayList<String>(); // 다건 처리용
    
    /***** IMPORT *****/
    private String izlregio   ;
    private String izmregio   ;
    private String izsregio   ;
    private String iland1     ;
    private String ikunnr     ;
    private String emltp      ;
    
    
    /***** IT_DATA *****/
    private String kunnr      ;
    private String vkorg      ;
    private String vtweg      ;
    private String zsacutm    ;
    private String zkunam     ;
    private String zlregio    ;
    private String zmregio    ;
    private String zsregio    ;
    private String land1      ;
    private String kvgr1      ;
    private String stffnm     ;
    private String emlid      ;
    
    
    /**
     * @return the izlregio
     */
    public String getIzlregio() {
        return izlregio;
    }
    /**
     * @param izlregio the izlregio to set
     */
    public void setIzlregio(String izlregio) {
        this.izlregio = izlregio;
    }
    /**
     * @return the izmregio
     */
    public String getIzmregio() {
        return izmregio;
    }
    /**
     * @param izmregio the izmregio to set
     */
    public void setIzmregio(String izmregio) {
        this.izmregio = izmregio;
    }
    /**
     * @return the izsregio
     */
    public String getIzsregio() {
        return izsregio;
    }
    /**
     * @param izsregio the izsregio to set
     */
    public void setIzsregio(String izsregio) {
        this.izsregio = izsregio;
    }
    /**
     * @return the iland1
     */
    public String getIland1() {
        return iland1;
    }
    /**
     * @param iland1 the iland1 to set
     */
    public void setIland1(String iland1) {
        this.iland1 = iland1;
    }
    /**
     * @return the ikunnr
     */
    public String getIkunnr() {
        return ikunnr;
    }
    /**
     * @param ikunnr the ikunnr to set
     */
    public void setIkunnr(String ikunnr) {
        this.ikunnr = ikunnr;
    }
    /**
     * @return the emltp
     */
    public String getEmltp() {
        return emltp;
    }
    /**
     * @param emltp the emltp to set
     */
    public void setEmltp(String emltp) {
        this.emltp = emltp;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the zkunam
     */
    public String getZkunam() {
        return zkunam;
    }
    /**
     * @param zkunam the zkunam to set
     */
    public void setZkunam(String zkunam) {
        this.zkunam = zkunam;
    }
    /**
     * @return the zlregio
     */
    public String getZlregio() {
        return zlregio;
    }
    /**
     * @param zlregio the zlregio to set
     */
    public void setZlregio(String zlregio) {
        this.zlregio = zlregio;
    }
    /**
     * @return the zmregio
     */
    public String getZmregio() {
        return zmregio;
    }
    /**
     * @param zmregio the zmregio to set
     */
    public void setZmregio(String zmregio) {
        this.zmregio = zmregio;
    }
    /**
     * @return the zsregio
     */
    public String getZsregio() {
        return zsregio;
    }
    /**
     * @param zsregio the zsregio to set
     */
    public void setZsregio(String zsregio) {
        this.zsregio = zsregio;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the stffnm
     */
    public String getStffnm() {
        return stffnm;
    }
    /**
     * @param stffnm the stffnm to set
     */
    public void setStffnm(String stffnm) {
        this.stffnm = stffnm;
    }
    /**
     * @return the emlid
     */
    public String getEmlid() {
        return emlid;
    }
    /**
     * @param emlid the emlid to set
     */
    public void setEmlid(String emlid) {
        this.emlid = emlid;
    }
    /**
     * @return the ikunnrs
     */
    public List<String> getIkunnrs() {
        return ikunnrs;
    }
    /**
     * @param ikunnrs the ikunnrs to set
     */
    public void setIkunnrs(List<String> ikunnrs) {
        this.ikunnrs = ikunnrs;
    }
    /**
     * @return the emltps
     */
    public List<String> getEmltps() {
        return emltps;
    }
    /**
     * @param emltps the emltps to set
     */
    public void setEmltps(List<String> emltps) {
        this.emltps = emltps;
    }
    /**
     * @return the includeSubDist
     */
    public boolean isIncludeSubDist() {
        return includeSubDist;
    }
    /**
     * @param includeSubDist the includeSubDist to set
     */
    public void setIncludeSubDist(boolean includeSubDist) {
        this.includeSubDist = includeSubDist;
    }

}
