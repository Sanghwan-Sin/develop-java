package com.mobis.maps.nmgn.qm.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.qm.vo.ClaimCodeListVO;
import com.mobis.maps.nmgn.qm.vo.QualityIssueDetailVO;
import com.mobis.maps.nmgn.qm.vo.QualityIssueQnaVO;
import com.mobis.maps.nmgn.qm.vo.QualityIssueVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityIssueService.java
 * @Description : Quality Issue
 * @author jiyongdo
 * @since 2020. 3. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 17.     jiyongdo     	최초 생성
 * </pre>
 */

public interface QualityIssueService {

    /**
     * 조회
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectQualityIssueList(LoginInfoVO loginInfo, QualityIssueVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<ClaimCodeListVO> selectIssueTypeList(LoginInfoVO loginInfo, ClaimCodeListVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectQualityIssueDetail(LoginInfoVO loginInfo, QualityIssueDetailVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVO
     * @param rtnParamVO
     * @param loginInfo
     * @return
     */
    Map<String, Object> multiQualityIssueDetail(QualityIssueDetailVO paramVO, QualityIssueDetailVO rtnParamVO,
            LoginInfoVO loginInfo) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectQualityIssueQna(LoginInfoVO loginInfo, QualityIssueQnaVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param paramVO
     * @param rtnParamVO
     * @param loginInfo
     * @return
     */
    Map<String, Object> multiQualityIssueQna(QualityIssueQnaVO paramVO, QualityIssueQnaVO rtnParamVO,
            LoginInfoVO loginInfo) throws Exception;

}
