package com.mobis.maps.nmgn.ex.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ex.service.CertificateInvoiceService;
import com.mobis.maps.nmgn.ex.vo.CertificateInvoiceExcelDownVO;
import com.mobis.maps.nmgn.ex.vo.CertificateInvoiceVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CertificateInvoiceServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author ChoKyungHo
 * @since 2020. 2. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 12.    ChoKyungHo     	                   최초 생성
 * </pre>
 */

@Service("certificateInvoiceService")
public class CertificateInvoiceServiceImpl extends HService implements CertificateInvoiceService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

  
    @Override
    public  List<CertificateInvoiceVO>  selectCertificateInvoice(LoginInfoVO loginInfo, CertificateInvoiceVO paramVO)  throws Exception {
       
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_GET_CO_LIST;
        
        paramVO.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        
        //*** 조회결과
        List<CertificateInvoiceVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, CertificateInvoiceVO.class);
        
        return list;
    }
    
    public  List<CertificateInvoiceExcelDownVO>  selectCertificateInvoiceExcelDown(LoginInfoVO loginInfo, CertificateInvoiceExcelDownVO paramVO)  throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPEX_MGN_DOWN_CO_LIST;
        
        paramVO.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        
        //*** 조회결과
        List<CertificateInvoiceExcelDownVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST", paramVO, CertificateInvoiceExcelDownVO.class);
        
        return list;
    }
}
