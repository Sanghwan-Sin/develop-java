package com.mobis.maps.nmgn.cc.vo;

import java.util.Date;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : DistInfoVO.java
 * @Description : DistInfoVO
 * @author ha.jeongryeong
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.    ha.jeongryeong      최초 생성
 *  2020.04. 03.    ChoKyungHo          To-be 테이블 변경
 *               </pre>
 */

public class PartsDeptInfoVO extends MapsCommSapRfcIfCommVO {

    /* 조회조건 */
    private String iVkorg;
    private String iZlregio;
    private String iZmregio;
    private String iZsregio;
    private String iKvgr1;
    private String iDistCd;
    
    /* 조회결과 */
    private int rnum;
    private String corpCode;
    private String distCode;
    private String distName;
    private String nationCode;
    private String nationName;
    private String updDt;
    private String updUsr;
    private String vkorg;
    private String vtweg;
    private String kunnr;
    
    private String agcCode;
    private String aplyYear;
    private int chnlDealers;
    private int chnlBrs;
    private int chnlShops;
    private int chnlEtc;
    private int stafSum;
    private int stafPm;
    private int stafSlz;
    private int stafMkt;
    private int stafInv;
    private int stafWrhs;
    private int stafSppt;
    private int stafEtc;
    private int wrhsGsSqm1;
    private int wrhsGsSqm2;
    private int wrhsGsSqm3;
    private int wrhsGsSqm4;
    private int wrhsGsSqm5;
    private int wrhsGsSqm6;
    private int wrhsGsSqmt;
    private int wrhsSsSqm1;
    private int wrhsSsSqm2;
    private int wrhsSsSqm3;
    private int wrhsSsSqm4;
    private int wrhsSsSqm5;
    private int wrhsSsSqm6;
    private int wrhsSsSqmt;
    private int wrhsRsSqm1;
    private int wrhsRsSqm2;
    private int wrhsRsSqm3;
    private int wrhsRsSqm4;
    private int wrhsRsSqm5;
    private int wrhsRsSqm6;
    private int wrhsRsSqmt;
    private String wrhsExpPlan;
    private String sysStatus;
    private String sysDptPart;
    private String sysDptSlz;
    private String sysDptAcct;
    private String sysDptSrvc;
    private String sysDptEtc;
    private String sysDptEtcName;
    private String sysNetHq;
    private String sysNetWrhs;
    private String sysNetDeal;
    private String sysNetBr;
    private String sysNetEtc;
    private String sysNetEtcName;
    private String sysUpgrdPlan;
    private String sysDpt;
    private String sysNet;
    
    private String zlregio;
    private String updtId;
    private Date updtdt;
    
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the sysDpt
     */
    public String getSysDpt() {
        return sysDpt;
    }
    /**
     * @param sysDpt the sysDpt to set
     */
    public void setSysDpt(String sysDpt) {
        this.sysDpt = sysDpt;
    }
    /**
     * @return the sysNet
     */
    public String getSysNet() {
        return sysNet;
    }
    /**
     * @param sysNet the sysNet to set
     */
    public void setSysNet(String sysNet) {
        this.sysNet = sysNet;
    }
    /**
     * @return the updUsr
     */
    public String getUpdUsr() {
        return updUsr;
    }
    /**
     * @param updUsr the updUsr to set
     */
    public void setUpdUsr(String updUsr) {
        this.updUsr = updUsr;
    }
    /**
     * @return the agcCode
     */
    public String getAgcCode() {
        return agcCode;
    }
    /**
     * @param agcCode the agcCode to set
     */
    public void setAgcCode(String agcCode) {
        this.agcCode = agcCode;
    }
    /**
     * @return the aplyYear
     */
    public String getAplyYear() {
        return aplyYear;
    }
    /**
     * @param aplyYear the aplyYear to set
     */
    public void setAplyYear(String aplyYear) {
        this.aplyYear = aplyYear;
    }
    /**
     * @return the chnlDealers
     */
    public int getChnlDealers() {
        return chnlDealers;
    }
    /**
     * @param chnlDealers the chnlDealers to set
     */
    public void setChnlDealers(int chnlDealers) {
        this.chnlDealers = chnlDealers;
    }
    /**
     * @return the chnlBrs
     */
    public int getChnlBrs() {
        return chnlBrs;
    }
    /**
     * @param chnlBrs the chnlBrs to set
     */
    public void setChnlBrs(int chnlBrs) {
        this.chnlBrs = chnlBrs;
    }
    /**
     * @return the chnlShops
     */
    public int getChnlShops() {
        return chnlShops;
    }
    /**
     * @param chnlShops the chnlShops to set
     */
    public void setChnlShops(int chnlShops) {
        this.chnlShops = chnlShops;
    }
    /**
     * @return the chnlEtc
     */
    public int getChnlEtc() {
        return chnlEtc;
    }
    /**
     * @param chnlEtc the chnlEtc to set
     */
    public void setChnlEtc(int chnlEtc) {
        this.chnlEtc = chnlEtc;
    }
    /**
     * @return the stafSum
     */
    public int getStafSum() {
        return stafSum;
    }
    /**
     * @param stafSum the stafSum to set
     */
    public void setStafSum(int stafSum) {
        this.stafSum = stafSum;
    }
    /**
     * @return the stafPm
     */
    public int getStafPm() {
        return stafPm;
    }
    /**
     * @param stafPm the stafPm to set
     */
    public void setStafPm(int stafPm) {
        this.stafPm = stafPm;
    }
    /**
     * @return the stafSlz
     */
    public int getStafSlz() {
        return stafSlz;
    }
    /**
     * @param stafSlz the stafSlz to set
     */
    public void setStafSlz(int stafSlz) {
        this.stafSlz = stafSlz;
    }
    /**
     * @return the stafMkt
     */
    public int getStafMkt() {
        return stafMkt;
    }
    /**
     * @param stafMkt the stafMkt to set
     */
    public void setStafMkt(int stafMkt) {
        this.stafMkt = stafMkt;
    }
    /**
     * @return the stafInv
     */
    public int getStafInv() {
        return stafInv;
    }
    /**
     * @param stafInv the stafInv to set
     */
    public void setStafInv(int stafInv) {
        this.stafInv = stafInv;
    }
    /**
     * @return the stafWrhs
     */
    public int getStafWrhs() {
        return stafWrhs;
    }
    /**
     * @param stafWrhs the stafWrhs to set
     */
    public void setStafWrhs(int stafWrhs) {
        this.stafWrhs = stafWrhs;
    }
    /**
     * @return the stafSppt
     */
    public int getStafSppt() {
        return stafSppt;
    }
    /**
     * @param stafSppt the stafSppt to set
     */
    public void setStafSppt(int stafSppt) {
        this.stafSppt = stafSppt;
    }
    /**
     * @return the stafEtc
     */
    public int getStafEtc() {
        return stafEtc;
    }
    /**
     * @param stafEtc the stafEtc to set
     */
    public void setStafEtc(int stafEtc) {
        this.stafEtc = stafEtc;
    }
    /**
     * @return the wrhsGsSqm1
     */
    public int getWrhsGsSqm1() {
        return wrhsGsSqm1;
    }
    /**
     * @param wrhsGsSqm1 the wrhsGsSqm1 to set
     */
    public void setWrhsGsSqm1(int wrhsGsSqm1) {
        this.wrhsGsSqm1 = wrhsGsSqm1;
    }
    /**
     * @return the wrhsGsSqm2
     */
    public int getWrhsGsSqm2() {
        return wrhsGsSqm2;
    }
    /**
     * @param wrhsGsSqm2 the wrhsGsSqm2 to set
     */
    public void setWrhsGsSqm2(int wrhsGsSqm2) {
        this.wrhsGsSqm2 = wrhsGsSqm2;
    }
    /**
     * @return the wrhsGsSqm3
     */
    public int getWrhsGsSqm3() {
        return wrhsGsSqm3;
    }
    /**
     * @param wrhsGsSqm3 the wrhsGsSqm3 to set
     */
    public void setWrhsGsSqm3(int wrhsGsSqm3) {
        this.wrhsGsSqm3 = wrhsGsSqm3;
    }
    /**
     * @return the wrhsGsSqm4
     */
    public int getWrhsGsSqm4() {
        return wrhsGsSqm4;
    }
    /**
     * @param wrhsGsSqm4 the wrhsGsSqm4 to set
     */
    public void setWrhsGsSqm4(int wrhsGsSqm4) {
        this.wrhsGsSqm4 = wrhsGsSqm4;
    }
    /**
     * @return the wrhsGsSqm5
     */
    public int getWrhsGsSqm5() {
        return wrhsGsSqm5;
    }
    /**
     * @param wrhsGsSqm5 the wrhsGsSqm5 to set
     */
    public void setWrhsGsSqm5(int wrhsGsSqm5) {
        this.wrhsGsSqm5 = wrhsGsSqm5;
    }
    /**
     * @return the wrhsGsSqm6
     */
    public int getWrhsGsSqm6() {
        return wrhsGsSqm6;
    }
    /**
     * @param wrhsGsSqm6 the wrhsGsSqm6 to set
     */
    public void setWrhsGsSqm6(int wrhsGsSqm6) {
        this.wrhsGsSqm6 = wrhsGsSqm6;
    }
    /**
     * @return the wrhsGsSqmt
     */
    public int getWrhsGsSqmt() {
        return wrhsGsSqmt;
    }
    /**
     * @param wrhsGsSqmt the wrhsGsSqmt to set
     */
    public void setWrhsGsSqmt(int wrhsGsSqmt) {
        this.wrhsGsSqmt = wrhsGsSqmt;
    }
    /**
     * @return the wrhsSsSqm1
     */
    public int getWrhsSsSqm1() {
        return wrhsSsSqm1;
    }
    /**
     * @param wrhsSsSqm1 the wrhsSsSqm1 to set
     */
    public void setWrhsSsSqm1(int wrhsSsSqm1) {
        this.wrhsSsSqm1 = wrhsSsSqm1;
    }
    /**
     * @return the wrhsSsSqm2
     */
    public int getWrhsSsSqm2() {
        return wrhsSsSqm2;
    }
    /**
     * @param wrhsSsSqm2 the wrhsSsSqm2 to set
     */
    public void setWrhsSsSqm2(int wrhsSsSqm2) {
        this.wrhsSsSqm2 = wrhsSsSqm2;
    }
    /**
     * @return the wrhsSsSqm3
     */
    public int getWrhsSsSqm3() {
        return wrhsSsSqm3;
    }
    /**
     * @param wrhsSsSqm3 the wrhsSsSqm3 to set
     */
    public void setWrhsSsSqm3(int wrhsSsSqm3) {
        this.wrhsSsSqm3 = wrhsSsSqm3;
    }
    /**
     * @return the wrhsSsSqm4
     */
    public int getWrhsSsSqm4() {
        return wrhsSsSqm4;
    }
    /**
     * @param wrhsSsSqm4 the wrhsSsSqm4 to set
     */
    public void setWrhsSsSqm4(int wrhsSsSqm4) {
        this.wrhsSsSqm4 = wrhsSsSqm4;
    }
    /**
     * @return the wrhsSsSqm5
     */
    public int getWrhsSsSqm5() {
        return wrhsSsSqm5;
    }
    /**
     * @param wrhsSsSqm5 the wrhsSsSqm5 to set
     */
    public void setWrhsSsSqm5(int wrhsSsSqm5) {
        this.wrhsSsSqm5 = wrhsSsSqm5;
    }
    /**
     * @return the wrhsSsSqm6
     */
    public int getWrhsSsSqm6() {
        return wrhsSsSqm6;
    }
    /**
     * @param wrhsSsSqm6 the wrhsSsSqm6 to set
     */
    public void setWrhsSsSqm6(int wrhsSsSqm6) {
        this.wrhsSsSqm6 = wrhsSsSqm6;
    }
    /**
     * @return the wrhsSsSqmt
     */
    public int getWrhsSsSqmt() {
        return wrhsSsSqmt;
    }
    /**
     * @param wrhsSsSqmt the wrhsSsSqmt to set
     */
    public void setWrhsSsSqmt(int wrhsSsSqmt) {
        this.wrhsSsSqmt = wrhsSsSqmt;
    }
    /**
     * @return the wrhsRsSqm1
     */
    public int getWrhsRsSqm1() {
        return wrhsRsSqm1;
    }
    /**
     * @param wrhsRsSqm1 the wrhsRsSqm1 to set
     */
    public void setWrhsRsSqm1(int wrhsRsSqm1) {
        this.wrhsRsSqm1 = wrhsRsSqm1;
    }
    /**
     * @return the wrhsRsSqm2
     */
    public int getWrhsRsSqm2() {
        return wrhsRsSqm2;
    }
    /**
     * @param wrhsRsSqm2 the wrhsRsSqm2 to set
     */
    public void setWrhsRsSqm2(int wrhsRsSqm2) {
        this.wrhsRsSqm2 = wrhsRsSqm2;
    }
    /**
     * @return the wrhsRsSqm3
     */
    public int getWrhsRsSqm3() {
        return wrhsRsSqm3;
    }
    /**
     * @param wrhsRsSqm3 the wrhsRsSqm3 to set
     */
    public void setWrhsRsSqm3(int wrhsRsSqm3) {
        this.wrhsRsSqm3 = wrhsRsSqm3;
    }
    /**
     * @return the wrhsRsSqm4
     */
    public int getWrhsRsSqm4() {
        return wrhsRsSqm4;
    }
    /**
     * @param wrhsRsSqm4 the wrhsRsSqm4 to set
     */
    public void setWrhsRsSqm4(int wrhsRsSqm4) {
        this.wrhsRsSqm4 = wrhsRsSqm4;
    }
    /**
     * @return the wrhsRsSqm5
     */
    public int getWrhsRsSqm5() {
        return wrhsRsSqm5;
    }
    /**
     * @param wrhsRsSqm5 the wrhsRsSqm5 to set
     */
    public void setWrhsRsSqm5(int wrhsRsSqm5) {
        this.wrhsRsSqm5 = wrhsRsSqm5;
    }
    /**
     * @return the wrhsRsSqm6
     */
    public int getWrhsRsSqm6() {
        return wrhsRsSqm6;
    }
    /**
     * @param wrhsRsSqm6 the wrhsRsSqm6 to set
     */
    public void setWrhsRsSqm6(int wrhsRsSqm6) {
        this.wrhsRsSqm6 = wrhsRsSqm6;
    }
    /**
     * @return the wrhsRsSqmt
     */
    public int getWrhsRsSqmt() {
        return wrhsRsSqmt;
    }
    /**
     * @param wrhsRsSqmt the wrhsRsSqmt to set
     */
    public void setWrhsRsSqmt(int wrhsRsSqmt) {
        this.wrhsRsSqmt = wrhsRsSqmt;
    }
    /**
     * @return the wrhsExpPlan
     */
    public String getWrhsExpPlan() {
        return wrhsExpPlan;
    }
    /**
     * @param wrhsExpPlan the wrhsExpPlan to set
     */
    public void setWrhsExpPlan(String wrhsExpPlan) {
        this.wrhsExpPlan = wrhsExpPlan;
    }
    /**
     * @return the sysStatus
     */
    public String getSysStatus() {
        return sysStatus;
    }
    /**
     * @param sysStatus the sysStatus to set
     */
    public void setSysStatus(String sysStatus) {
        this.sysStatus = sysStatus;
    }
    /**
     * @return the sysDptPart
     */
    public String getSysDptPart() {
        return sysDptPart;
    }
    /**
     * @param sysDptPart the sysDptPart to set
     */
    public void setSysDptPart(String sysDptPart) {
        this.sysDptPart = sysDptPart;
    }
    /**
     * @return the sysDptSlz
     */
    public String getSysDptSlz() {
        return sysDptSlz;
    }
    /**
     * @param sysDptSlz the sysDptSlz to set
     */
    public void setSysDptSlz(String sysDptSlz) {
        this.sysDptSlz = sysDptSlz;
    }
    /**
     * @return the sysDptAcct
     */
    public String getSysDptAcct() {
        return sysDptAcct;
    }
    /**
     * @param sysDptAcct the sysDptAcct to set
     */
    public void setSysDptAcct(String sysDptAcct) {
        this.sysDptAcct = sysDptAcct;
    }
    /**
     * @return the sysDptSrvc
     */
    public String getSysDptSrvc() {
        return sysDptSrvc;
    }
    /**
     * @param sysDptSrvc the sysDptSrvc to set
     */
    public void setSysDptSrvc(String sysDptSrvc) {
        this.sysDptSrvc = sysDptSrvc;
    }
    /**
     * @return the sysDptEtc
     */
    public String getSysDptEtc() {
        return sysDptEtc;
    }
    /**
     * @param sysDptEtc the sysDptEtc to set
     */
    public void setSysDptEtc(String sysDptEtc) {
        this.sysDptEtc = sysDptEtc;
    }
    /**
     * @return the sysDptEtcName
     */
    public String getSysDptEtcName() {
        return sysDptEtcName;
    }
    /**
     * @param sysDptEtcName the sysDptEtcName to set
     */
    public void setSysDptEtcName(String sysDptEtcName) {
        this.sysDptEtcName = sysDptEtcName;
    }
    /**
     * @return the sysNetHq
     */
    public String getSysNetHq() {
        return sysNetHq;
    }
    /**
     * @param sysNetHq the sysNetHq to set
     */
    public void setSysNetHq(String sysNetHq) {
        this.sysNetHq = sysNetHq;
    }
    /**
     * @return the sysNetWrhs
     */
    public String getSysNetWrhs() {
        return sysNetWrhs;
    }
    /**
     * @param sysNetWrhs the sysNetWrhs to set
     */
    public void setSysNetWrhs(String sysNetWrhs) {
        this.sysNetWrhs = sysNetWrhs;
    }
    /**
     * @return the sysNetDeal
     */
    public String getSysNetDeal() {
        return sysNetDeal;
    }
    /**
     * @param sysNetDeal the sysNetDeal to set
     */
    public void setSysNetDeal(String sysNetDeal) {
        this.sysNetDeal = sysNetDeal;
    }
    /**
     * @return the sysNetBr
     */
    public String getSysNetBr() {
        return sysNetBr;
    }
    /**
     * @param sysNetBr the sysNetBr to set
     */
    public void setSysNetBr(String sysNetBr) {
        this.sysNetBr = sysNetBr;
    }
    /**
     * @return the sysNetEtc
     */
    public String getSysNetEtc() {
        return sysNetEtc;
    }
    /**
     * @param sysNetEtc the sysNetEtc to set
     */
    public void setSysNetEtc(String sysNetEtc) {
        this.sysNetEtc = sysNetEtc;
    }
    /**
     * @return the sysNetEtcName
     */
    public String getSysNetEtcName() {
        return sysNetEtcName;
    }
    /**
     * @param sysNetEtcName the sysNetEtcName to set
     */
    public void setSysNetEtcName(String sysNetEtcName) {
        this.sysNetEtcName = sysNetEtcName;
    }
    /**
     * @return the sysUpgrdPlan
     */
    public String getSysUpgrdPlan() {
        return sysUpgrdPlan;
    }
    /**
     * @param sysUpgrdPlan the sysUpgrdPlan to set
     */
    public void setSysUpgrdPlan(String sysUpgrdPlan) {
        this.sysUpgrdPlan = sysUpgrdPlan;
    }
    
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iZlregio
     */
    public String getiZlregio() {
        return iZlregio;
    }
    /**
     * @param iZlregio the iZlregio to set
     */
    public void setiZlregio(String iZlregio) {
        this.iZlregio = iZlregio;
    }
    /**
     * @return the iZmregio
     */
    public String getiZmregio() {
        return iZmregio;
    }
    /**
     * @param iZmregio the iZmregio to set
     */
    public void setiZmregio(String iZmregio) {
        this.iZmregio = iZmregio;
    }
    /**
     * @return the iZsregio
     */
    public String getiZsregio() {
        return iZsregio;
    }
    /**
     * @param iZsregio the iZsregio to set
     */
    public void setiZsregio(String iZsregio) {
        this.iZsregio = iZsregio;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the distName
     */
    public String getDistName() {
        return distName;
    }
    /**
     * @param distName the distName to set
     */
    public void setDistName(String distName) {
        this.distName = distName;
    }
    /**
     * @return the nationCode
     */
    public String getNationCode() {
        return nationCode;
    }
    /**
     * @param nationCode the nationCode to set
     */
    public void setNationCode(String nationCode) {
        this.nationCode = nationCode;
    }
    /**
     * @return the nationName
     */
    public String getNationName() {
        return nationName;
    }
    /**
     * @param nationName the nationName to set
     */
    public void setNationName(String nationName) {
        this.nationName = nationName;
    }
    /**
     * @return the updDt
     */
    public String getUpdDt() {
        return updDt;
    }
    /**
     * @param updDt the updDt to set
     */
    public void setUpdDt(String updDt) {
        this.updDt = updDt;
    }
    /**
     * @return the iDistCd
     */
    public String getiDistCd() {
        return iDistCd;
    }
    /**
     * @param iDistCd the iDistCd to set
     */
    public void setiDistCd(String iDistCd) {
        this.iDistCd = iDistCd;
    }
    /**
     * @return the corpCode
     */
    public String getCorpCode() {
        return corpCode;
    }
    /**
     * @param corpCode the corpCode to set
     */
    public void setCorpCode(String corpCode) {
        this.corpCode = corpCode;
    }
    /**
     * @return the distCode
     */
    public String getDistCode() {
        return distCode;
    }
    /**
     * @param distCode the distCode to set
     */
    public void setDistCode(String distCode) {
        this.distCode = distCode;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the zlregio
     */
    public String getZlregio() {
        return zlregio;
    }
    /**
     * @param zlregio the zlregio to set
     */
    public void setZlregio(String zlregio) {
        this.zlregio = zlregio;
    }
    /**
     * @return the updtId
     */
    public String getUpdtId() {
        return updtId;
    }
    /**
     * @param updtId the updtId to set
     */
    public void setUpdtId(String updtId) {
        this.updtId = updtId;
    }
    /**
     * @return the updtdt
     */
    public Date getUpdtdt() {
        return updtdt;
    }
    /**
     * @param updtdt the updtdt to set
     */
    public void setUpdtdt(Date updtdt) {
        this.updtdt = updtdt;
    }
}
