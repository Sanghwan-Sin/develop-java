package com.mobis.maps.nmgn.sd.web;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.excel.ExcelUtil;
import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.FileUploadUtil;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsOrgnztDistVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.nmgn.sd.service.OrderEntryService;
import com.mobis.maps.nmgn.sd.vo.OrderCanvassNoVO;
import com.mobis.maps.nmgn.sd.vo.OrderEntryVO;
import com.mobis.maps.nmgn.sd.vo.OrderShipModeVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderEntryController.java
 * @Description : ZJSDO30240 Order Placement
 * @author 홍민호
 * @since 2020. 2. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 20.     홍민호     	최초 생성
 * </pre>
 */

@Controller
public class OrderEntryController extends HController {

    @Resource(name = "orderEntryService")
    private OrderEntryService service;
    
    @Resource(name="mapsCommFileService")
    private MapsCommFileService mapsCommFileService;
    
    /**
     * Order Entry 조회
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderEntry.do")
    public NexacroResult selectOrderEntry(@ParamDataSet(name="dsInput") OrderEntryVO params
            , NexacroResult result) throws Exception {
        
        if (logger.isDebugEnabled()) {logger.debug("*** Order Entry 조회  S T A R T . . . ");}
        
        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<OrderEntryVO> rsltLst = service.selectOrderEntry(loginVo, params);
        
        if (rsltLst != null) {
            result.addDataSet("dsOutput", rsltLst);
        }
        
        result.addDataSet("dsReturn", params);
        
        return result;        

    }
    
    /**
     * Order Entry Excel download
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderEntryExcelDown.do")
    public NexacroResult selectOrderEntryExcelDown(@ParamDataSet(name="dsInput") OrderEntryVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<OrderEntryVO> rsltLst = service.selectOrderEntry(loginVo, params);
        
        result.addDataSet("dsOutput", rsltLst);
        result.addDataSet("dsReturn", params);
        
        return result;        

    }    
    
    
    /**
     * Order Entry Excel upload
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderEntryExcelUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectOrderEntryExcelUp(HttpServletRequest request, NexacroResult result) throws Exception {

        int rnum = 1;
        List<OrderEntryVO> dsList = new ArrayList<OrderEntryVO>();
        List<String[]> rowList = ExcelUtil.importExcelToList(request, 1, 4, 0, "N");
        
        for(int idx = 0; rowList != null && idx < rowList.size(); idx++) {
            String[] arrCol = rowList.get(idx);
        
            OrderEntryVO vo = new OrderEntryVO();
            
            vo.setZmatnrInput(arrCol[0]);
            vo.setZordqty(arrCol[1]);
//            vo.setCcngn(arrCol[2]);
            vo.setZimemo(arrCol[2]);

            if (StringUtils.isBlank(vo.getZmatnrInput())) continue;
            
            vo.setChkYn("Y");
            vo.setRnum(rnum++);
            vo.setType("C");
            vo.setRowSe("I");
            
            dsList.add(vo);
        }
        
        result.addDataSet("dsOutput", dsList);

        return result;
    }  


    /**
     * Order Entry 저장
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/multiSaveOrderEntry.do")
    public NexacroResult multiSaveOrderEntry(@ParamDataSet(name="dsInput") OrderEntryVO params
            , @ParamDataSet(name="dsList") List<OrderEntryVO> paramLst
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<OrderEntryVO> rsltLst = service.multiSaveOrderEntry(loginVo, params, paramLst);
        
        if ("E".equals(params.getMsgType())) {
            result.addDataSet("dsOutput", paramLst); // 오류이면 return 결과 안보냄
        } else {
            result.addDataSet("dsOutput", rsltLst);
        }
        
        result.addDataSet("dsReturn", params);
        
        return result;        

    }

    
    /**
     * 부품번호 체크
     *
     * @param params
     * @param paramLst
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderMatnrChk.do")
    public NexacroResult selectOrderMatnrChk(@ParamDataSet(name="dsInput") OrderEntryVO params
            , @ParamDataSet(name="dsList") List<OrderEntryVO> paramLst
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<OrderEntryVO> rsltLst = service.selectOrderMatnrChk(loginVo, params, paramLst);
        
        result.addDataSet("dsOutput", rsltLst);
        result.addDataSet("dsReturn", params);
        
        return result;        

    }


    
    /**
     * Canvass No List
     *
     * @param params
     * @param paramLst
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectCanvassNo.do")
    public NexacroResult selectCanvassNo(@ParamDataSet(name="dsInput") OrderCanvassNoVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        MapsOrgnztDistVO orgVo = (MapsOrgnztDistVO) getSessionAttribute(MapsConstants.SSS_ORGNZT_INFO);
        
        params.setiType("R");
        
        // H/K
        if (StringUtils.isEmpty(params.getiZhkcd())) {
            params.setiZhkcd(orgVo.getKvgr1());
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("###### iType :" + params.getiType());
            logger.debug("###### iZhkcd:" + params.getiZhkcd());
        }
        
        List<OrderCanvassNoVO> rsltLst = service.selectCanvassNoLst(loginVo, params);
        
        result.addDataSet("dsCanvassNo", rsltLst);
        result.addDataSet("dsReturn", params);
        
        return result;        

    }
    

    /**
     * Ship Mode List
     *
     * @param params
     * @param paramLst
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectShipMode.do")
    public NexacroResult selectShipMode(@ParamDataSet(name="dsInput") OrderShipModeVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
//        MapsOrgnztDistVO orgVo = (MapsOrgnztDistVO) getSessionAttribute(MapsConstants.SSS_ORGNZT_INFO);
        
        List<OrderShipModeVO> rsltLst = service.selectShipMode(loginVo, params);
        
        if (rsltLst != null) {
            result.addDataSet("dsShipMode", rsltLst);
        }
        
        result.addDataSet("dsReturn", params);
        
        return result;        

    }

    
    
    
    /**
     * Order Entry File upload
     *
     * @param request
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderEntryFileUp.do", method = {RequestMethod.POST, RequestMethod.GET})
    public NexacroResult selectOrderEntryFileUp(HttpServletRequest request, NexacroResult result) throws Exception {
        File fUp = null;
        List<OrderEntryVO> dsList = null;
        OrderEntryVO params = new OrderEntryVO();
        params.setMsgType("S");

        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        try {
            fUp = mapsCommFileService.selectFileUpload(request);
            
            if(logger.isDebugEnabled()) {logger.debug("##### " + fUp.getPath());}

            dsList = service.selectOrderEntryTxtUpload(loginVo, fUp);
            
        } catch (MapsBizException be) {
            params.setMsgType("E");
            params.setMsg(be.getMessage());

        } catch (IOException ioe) {
            StringBuffer sBuf = new StringBuffer();
            sBuf.append(MessageUtil.getMessage("WC00000007", null, loginVo.getUserLcale())) /* WC00000007 Upload file failed. */
                .append("\n").append(ioe.getMessage());
            
            params.setMsgType("E");
            params.setMsg(sBuf.toString());

        } catch (Exception e) {
            params.setMsgType("E");
            params.setMsg(MessageUtil.getMessage("WC00000007", null, loginVo.getUserLcale())); // WC00000007 Upload file failed.
        
        } finally {
            if (fUp != null) {
                FileUploadUtil.removeFile(fUp);
            }
        }
        
        result.addDataSet("dsReturn", params);

        if (dsList != null) {
            result.addDataSet("dsOutput", dsList);
        }

        return result;
    }  
    
}
