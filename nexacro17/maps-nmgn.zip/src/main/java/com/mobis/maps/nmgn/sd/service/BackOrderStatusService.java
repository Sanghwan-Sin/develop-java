package com.mobis.maps.nmgn.sd.service;

import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.BackOrderStatusVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : BackOrderStatusService.java
 * @Description : BackOrder Status
 * @author 이수지
 * @since 2020. 06. 08.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 08.       이수지      	   최초 생성
 * </pre>
 */

public interface BackOrderStatusService {

    /**
     * BackOrder Status
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    Map<String, Object> selectBackOrderStatus (LoginInfoVO loginVo, BackOrderStatusVO params) throws Exception;
}
