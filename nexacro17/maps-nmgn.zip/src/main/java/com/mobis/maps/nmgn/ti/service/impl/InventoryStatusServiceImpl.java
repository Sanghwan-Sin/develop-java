package com.mobis.maps.nmgn.ti.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ti.service.InventoryStatusService;
import com.mobis.maps.nmgn.ti.vo.InventoryStatusVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InventoryStatusServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 7. 15.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 15.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("inventoryStatusService")
public class InventoryStatusServiceImpl extends HService implements InventoryStatusService{
    
    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.ti.service.InventoryStatusService#selectInventoryStatusList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.InventoryStatusVO, com.mobis.maps.nmgn.ti.vo.InventoryStatusVO)
     */
    @Override
    public List<InventoryStatusVO> selectInventoryStatusList(LoginInfoVO loginInfo, InventoryStatusVO params,
            List<InventoryStatusVO> paramList) throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_INVENTORY_STAT;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        for (InventoryStatusVO tmpVO : paramList) {
            MapsRfcMappperUtil.appendImportTableRow(func, "IT_DATA", tmpVO);
        }
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<InventoryStatusVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_DATA", params, InventoryStatusVO.class);
        
        return list;
    }
}
