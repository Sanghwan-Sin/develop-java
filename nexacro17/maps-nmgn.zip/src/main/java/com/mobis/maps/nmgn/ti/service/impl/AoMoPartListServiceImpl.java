package com.mobis.maps.nmgn.ti.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ti.service.AoMoPartListService;
import com.mobis.maps.nmgn.ti.vo.AoMoPartListVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AoMoPartListServiceImpl.java
 * @Description : ZJTIR02090 AO/MO Part List
 * @author 이수지
 * @since 2020. 5. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 11.      이수지      	        최초 생성
 * </pre>
 */

@Service("aoMoPartListService")
public class AoMoPartListServiceImpl extends HService implements AoMoPartListService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.ti.service.AoMoPartListService#selectAoMoPartList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.AoMoPartListVO)
     */
    @Override
    public List<AoMoPartListVO> selectAoMoPartList(LoginInfoVO loginVo, AoMoPartListVO params)
            throws Exception {

        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_AO_MO_LIST_HQ;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<AoMoPartListVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, AoMoPartListVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.AoMoPartListService#selectRegion(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.AoMoPartListVO)
     */
    @Override
    public List<AoMoPartListVO> selectRegion(LoginInfoVO loginVo, AoMoPartListVO params) throws Exception {
      
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_SELECT_AREA_CODE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<AoMoPartListVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, AoMoPartListVO.class);
        
        return list;
    }    
    
    /*
     * @see com.mobis.maps.nmgn.ti.service.AoMoPartListService#selectModel(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.AoMoPartListVO)
     */
    @Override
    public List<AoMoPartListVO> selectModel(LoginInfoVO loginVo, AoMoPartListVO params) throws Exception {
       
      //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_SELECT_MODEL_CODE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<AoMoPartListVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, AoMoPartListVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.AoMoPartListService#selectAoDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.AoMoPartListVO)
     */
    @Override
    public List<AoMoPartListVO> selectAoDetail(LoginInfoVO loginVo, AoMoPartListVO params) throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_AO_DETAIL_HQ;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());


        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<AoMoPartListVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, AoMoPartListVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.AoMoPartListService#selectMoDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.AoMoPartListVO)
     */
    @Override
    public List<AoMoPartListVO> selectMoDetail(LoginInfoVO loginVo, AoMoPartListVO params) throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_MO_DETAIL_HQ;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<AoMoPartListVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, AoMoPartListVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.AoMoPartListService#selectAoMoParentList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.AoMoPartListVO)
     */
    @Override
    public List<AoMoPartListVO> selectAoMoParentList(LoginInfoVO loginInfo, AoMoPartListVO params) throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_AO_MO_PARENT_HQ;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<AoMoPartListVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, AoMoPartListVO.class);
        
        return list;
    }

}
