package com.mobis.maps.nmgn.sd.vo;



import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : HqHsCodeVO.java
 * @Description : ZPSD_GTS_R_HSCODE
 * @author 이수지
 * @since 2020. 01. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 01. 17.     이수지     	       최초 생성
 * </pre>
 */

public class HqHsCodeVO extends MapsCommSapRfcIfCommVO {
    
    /** effective date */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_EFDAT" )
    private Date ivEfdat;
    /** 법적 규정 */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_LGREG" )
    private String ivLgreg;        
    
    /** -----[CT_DATA] START----- */
    
    /** Legal Regulation */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="LGREG" )
    private String lgreg;
    /** Legal Regulation Description */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="FTANA_E" )
    private String ftanaE;
    /** Material Number */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** effective date */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="EFDAT" )
    private Date efdat;
    /** Material description */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** Number */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="CCNGN" )
    private String ccngn;
    /** Create Local Date */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="REGDAT" )
    private Date regdat;
    /** Valid From */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="DATAB" )
    private Date datab;
    /** Valid To */
    @MapsRfcMappper( targetName="CT_DATA", ipttSe="E", fieldKey="DATBI" )
    private Date datbi;
    
    /** -----[CT_DATA] END----- */
          
    /**
     * @return the lgreg
     */
    public String getLgreg() {
        return lgreg;
    }
    /**
     * @param lgreg the lgreg to set
     */
    public void setLgreg(String lgreg) {
        this.lgreg = lgreg;
    }
    /**
     * @return the ivEfdat
     */
    public Date getIvEfdat() {
        return ivEfdat;
    }
    /**
     * @param ivEfdat the ivEfdat to set
     */
    public void setIvEfdat(Date ivEfdat) {
        this.ivEfdat = ivEfdat;
    }
    /**
     * @return the ivLgreg
     */
    public String getIvLgreg() {
        return ivLgreg;
    }
    /**
     * @param ivLgreg the ivLgreg to set
     */
    public void setIvLgreg(String ivLgreg) {
        this.ivLgreg = ivLgreg;
    }    
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the efdat
     */
    public Date getEfdat() {
        return efdat;
    }
    /**
     * @param efdat the efdat to set
     */
    public void setEfdat(Date efdat) {
        this.efdat = efdat;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the ccngn
     */
    public String getCcngn() {
        return ccngn;
    }
    /**
     * @param ccngn the ccngn to set
     */
    public void setCcngn(String ccngn) {
        this.ccngn = ccngn;
    }
    /**
     * @return the datab
     */
    public Date getDatab() {
        return datab;
    }
    /**
     * @param datab the datab to set
     */
    public void setDatab(Date datab) {
        this.datab = datab;
    }
    /**
     * @return the datbi
     */
    public Date getDatbi() {
        return datbi;
    }
    /**
     * @param datbi the datbi to set
     */
    public void setDatbi(Date datbi) {
        this.datbi = datbi;
    }
    /**
     * @return the ftanaE
     */
    public String getFtanaE() {
        return ftanaE;
    }
    /**
     * @param ftanaE the ftanaE to set
     */
    public void setFtanaE(String ftanaE) {
        this.ftanaE = ftanaE;
    }
    /**
     * @return the regdat
     */
    public Date getRegdat() {
        return regdat;
    }
    /**
     * @param regdat the regdat to set
     */
    public void setRegdat(Date regdat) {
        this.regdat = regdat;
    }    
            
}
