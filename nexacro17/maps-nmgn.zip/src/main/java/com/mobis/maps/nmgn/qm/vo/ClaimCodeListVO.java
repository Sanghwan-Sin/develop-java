package com.mobis.maps.nmgn.qm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimCodeListVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 3. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 11.     jiyongdo     	최초 생성
 * </pre>
 */

public class ClaimCodeListVO extends MapsCommSapRfcIfCommVO{
    /** 클레임 코드그룹 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CLCDGR" )
    private String iClcdgr;
    /** 클레임 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CLCODE" )
    private String iClcode;
    /** 클레임코드 유형 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CLTYPE" )
    private String iCltype;
    /** ABAP System Field: Language Key of Text Environment */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_LANGU" )
    private String iLangu;
    /** 클레임 코드그룹 조회 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_QISSUE" )
    private String iQissue;
    //-----[T_DATA] START-----
    /** 클레임코드 유형 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLTYPE" )
    private String cltype;
    /** 클레임 코드그룹 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLCODEGR" )
    private String clcodegr;
    /** 클레임 코드그룹명 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLCODEGR_NAME" )
    private String clcodegrName;
    /** 의뢰코드 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLCODE" )
    private String clcode;
    /** 클레임 코드명 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLCODE_NAME" )
    private String clcodeName;
    /** 삭제 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="DEL" )
    private String del;
    //-----[T_DATA] END-----
    /**
     * @return the iClcdgr
     */
    public String getiClcdgr() {
        return iClcdgr;
    }
    /**
     * @param iClcdgr the iClcdgr to set
     */
    public void setiClcdgr(String iClcdgr) {
        this.iClcdgr = iClcdgr;
    }
    /**
     * @return the iClcode
     */
    public String getiClcode() {
        return iClcode;
    }
    /**
     * @param iClcode the iClcode to set
     */
    public void setiClcode(String iClcode) {
        this.iClcode = iClcode;
    }
    /**
     * @return the iCltype
     */
    public String getiCltype() {
        return iCltype;
    }
    /**
     * @param iCltype the iCltype to set
     */
    public void setiCltype(String iCltype) {
        this.iCltype = iCltype;
    }
    /**
     * @return the iLangu
     */
    public String getiLangu() {
        return iLangu;
    }
    /**
     * @param iLangu the iLangu to set
     */
    public void setiLangu(String iLangu) {
        this.iLangu = iLangu;
    }
    /**
     * @return the iQissue
     */
    public String getiQissue() {
        return iQissue;
    }
    /**
     * @param iQissue the iQissue to set
     */
    public void setiQissue(String iQissue) {
        this.iQissue = iQissue;
    }
    /**
     * @return the cltype
     */
    public String getCltype() {
        return cltype;
    }
    /**
     * @param cltype the cltype to set
     */
    public void setCltype(String cltype) {
        this.cltype = cltype;
    }
    /**
     * @return the clcodegr
     */
    public String getClcodegr() {
        return clcodegr;
    }
    /**
     * @param clcodegr the clcodegr to set
     */
    public void setClcodegr(String clcodegr) {
        this.clcodegr = clcodegr;
    }
    /**
     * @return the clcodegrName
     */
    public String getClcodegrName() {
        return clcodegrName;
    }
    /**
     * @param clcodegrName the clcodegrName to set
     */
    public void setClcodegrName(String clcodegrName) {
        this.clcodegrName = clcodegrName;
    }
    /**
     * @return the clcode
     */
    public String getClcode() {
        return clcode;
    }
    /**
     * @param clcode the clcode to set
     */
    public void setClcode(String clcode) {
        this.clcode = clcode;
    }
    /**
     * @return the clcodeName
     */
    public String getClcodeName() {
        return clcodeName;
    }
    /**
     * @param clcodeName the clcodeName to set
     */
    public void setClcodeName(String clcodeName) {
        this.clcodeName = clcodeName;
    }
    /**
     * @return the del
     */
    public String getDel() {
        return del;
    }
    /**
     * @param del the del to set
     */
    public void setDel(String del) {
        this.del = del;
    }
}
