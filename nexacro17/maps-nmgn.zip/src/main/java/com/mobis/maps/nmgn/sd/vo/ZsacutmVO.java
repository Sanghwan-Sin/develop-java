package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : zsacutmVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 2. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 27.     jiyongdo     	최초 생성
 * </pre>
 */

public class ZsacutmVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    //-----[T_RESULT] START-----
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Customer Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KUNNR" )
    private String kunnr;
    /** Name 1 of organization */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NAME_ORG1" )
    private String nameOrg1;
    /** Customer group 1 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /** Customer group 2 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR2" )
    private String kvgr2;
    /** Customer group 3 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR3" )
    private String kvgr3;
    /** Customer group 4 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR4" )
    private String kvgr4;
    /** Customer group 5 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KVGR5" )
    private String kvgr5;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRICE_VIEW" )
    private String zpriceView;
    /** Price List Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PLTYP" )
    private String pltyp;
    //-----[T_RESULT] END-----
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the nameOrg1
     */
    public String getNameOrg1() {
        return nameOrg1;
    }
    /**
     * @param nameOrg1 the nameOrg1 to set
     */
    public void setNameOrg1(String nameOrg1) {
        this.nameOrg1 = nameOrg1;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the kvgr2
     */
    public String getKvgr2() {
        return kvgr2;
    }
    /**
     * @param kvgr2 the kvgr2 to set
     */
    public void setKvgr2(String kvgr2) {
        this.kvgr2 = kvgr2;
    }
    /**
     * @return the kvgr3
     */
    public String getKvgr3() {
        return kvgr3;
    }
    /**
     * @param kvgr3 the kvgr3 to set
     */
    public void setKvgr3(String kvgr3) {
        this.kvgr3 = kvgr3;
    }
    /**
     * @return the kvgr4
     */
    public String getKvgr4() {
        return kvgr4;
    }
    /**
     * @param kvgr4 the kvgr4 to set
     */
    public void setKvgr4(String kvgr4) {
        this.kvgr4 = kvgr4;
    }
    /**
     * @return the kvgr5
     */
    public String getKvgr5() {
        return kvgr5;
    }
    /**
     * @param kvgr5 the kvgr5 to set
     */
    public void setKvgr5(String kvgr5) {
        this.kvgr5 = kvgr5;
    }
    /**
     * @return the zpriceView
     */
    public String getZpriceView() {
        return zpriceView;
    }
    /**
     * @param zpriceView the zpriceView to set
     */
    public void setZpriceView(String zpriceView) {
        this.zpriceView = zpriceView;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
}
