package com.mobis.maps.nmgn.ti.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DownloadAoRequestVO.java
 * @Description : ZPTI_NMGN_R_DOWNLOAD_REQUEST
 * @author 이수지
 * @since 2020. 06. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 16.     이수지     	       최초 생성
 * </pre>
 */

public class DownloadAoRequestVO extends MapsCommSapRfcIfCommVO {
    
    /** 지역 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAREA" )
    private String iZarea;
    /** 대리점 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDISTCD" )
    private String iZdistcd;
    /** 부품 생성일 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFDATE" )
    private Date iZfdate;
    /** 파일 유형 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFTYPE" )
    private String iZftype;
    /** H/K 구분 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** 요청자 메일 ID */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZMAILID" )
    private String iZmailid;
    /** 요청일자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQDT" )
    private Date iZreqdt;
    /** 요청자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQID" )
    private String iZreqid;
    /** 요청시각 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQTM" )
    private Date iZreqtm;
    /** 부품 생성일 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZTDATE" )
    private Date iZtdate;
    /** 모비스차종코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZVHC" )
    private String iZvhc;
    
    /**
     * @return the iZarea
     */
    public String getiZarea() {
        return iZarea;
    }
    /**
     * @param iZarea the iZarea to set
     */
    public void setiZarea(String iZarea) {
        this.iZarea = iZarea;
    }
    /**
     * @return the iZdistcd
     */
    public String getiZdistcd() {
        return iZdistcd;
    }
    /**
     * @param iZdistcd the iZdistcd to set
     */
    public void setiZdistcd(String iZdistcd) {
        this.iZdistcd = iZdistcd;
    }
    /**
     * @return the iZfdate
     */
    public Date getiZfdate() {
        return iZfdate;
    }
    /**
     * @param iZfdate the iZfdate to set
     */
    public void setiZfdate(Date iZfdate) {
        this.iZfdate = iZfdate;
    }
    /**
     * @return the iZftype
     */
    public String getiZftype() {
        return iZftype;
    }
    /**
     * @param iZftype the iZftype to set
     */
    public void setiZftype(String iZftype) {
        this.iZftype = iZftype;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZmailid
     */
    public String getiZmailid() {
        return iZmailid;
    }
    /**
     * @param iZmailid the iZmailid to set
     */
    public void setiZmailid(String iZmailid) {
        this.iZmailid = iZmailid;
    }
    /**
     * @return the iZreqdt
     */
    public Date getiZreqdt() {
        return iZreqdt;
    }
    /**
     * @param iZreqdt the iZreqdt to set
     */
    public void setiZreqdt(Date iZreqdt) {
        this.iZreqdt = iZreqdt;
    }
    /**
     * @return the iZreqid
     */
    public String getiZreqid() {
        return iZreqid;
    }
    /**
     * @param iZreqid the iZreqid to set
     */
    public void setiZreqid(String iZreqid) {
        this.iZreqid = iZreqid;
    }
    /**
     * @return the iZreqtm
     */
    public Date getiZreqtm() {
        return iZreqtm;
    }
    /**
     * @param iZreqtm the iZreqtm to set
     */
    public void setiZreqtm(Date iZreqtm) {
        this.iZreqtm = iZreqtm;
    }
    /**
     * @return the iZtdate
     */
    public Date getiZtdate() {
        return iZtdate;
    }
    /**
     * @param iZtdate the iZtdate to set
     */
    public void setiZtdate(Date iZtdate) {
        this.iZtdate = iZtdate;
    }
    /**
     * @return the iZvhc
     */
    public String getiZvhc() {
        return iZvhc;
    }
    /**
     * @param iZvhc the iZvhc to set
     */
    public void setiZvhc(String iZvhc) {
        this.iZvhc = iZvhc;
    }
    
}
