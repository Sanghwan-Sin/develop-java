package com.mobis.maps.nmgn.sd.vo;



import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : HqFtaAgreementVO.java
 * @Description : ZPSD_NMGN_S_AGREEMENT
 * @author 이수지
 * @since 2020. 03. 30.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 30.     이수지     	       최초 생성
 * </pre>
 */

public class HqFtaAgreementVO extends MapsCommSapRfcIfCommVO {
    
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_LAND1" )
    private String ivLand1;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_LGREG" )
    private String ivLgreg;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="IV_LGREG_NM" )
    private String ivLgregNm;
    /** -----[T_DATA] START----- */
    
    /** 협정 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LGREG" )
    private String lgreg;
    /** Legal Regulation Description */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="LGREG_NM" )
    private String lgregNm;
    
    /** -----[T_DATA] END----- */
    
    
    
    /**
     * @return the lgreg
     */
    public String getLgreg() {
        return lgreg;
    }
    /**
     * @param lgreg the lgreg to set
     */
    public void setLgreg(String lgreg) {
        this.lgreg = lgreg;
    }
    /**
     * @return the ivLand1
     */
    public String getIvLand1() {
        return ivLand1;
    }
    /**
     * @param ivLand1 the ivLand1 to set
     */
    public void setIvLand1(String ivLand1) {
        this.ivLand1 = ivLand1;
    }
    /**
     * @return the ivLgreg
     */
    public String getIvLgreg() {
        return ivLgreg;
    }
    /**
     * @param ivLgreg the ivLgreg to set
     */
    public void setIvLgreg(String ivLgreg) {
        this.ivLgreg = ivLgreg;
    }
    /**
     * @return the ivLgregNm
     */
    public String getIvLgregNm() {
        return ivLgregNm;
    }
    /**
     * @param ivLgregNm the ivLgregNm to set
     */
    public void setIvLgregNm(String ivLgregNm) {
        this.ivLgregNm = ivLgregNm;
    }
    /**
     * @return the lgregNm
     */
    public String getLgregNm() {
        return lgregNm;
    }
    /**
     * @param lgregNm the lgregNm to set
     */
    public void setLgregNm(String lgregNm) {
        this.lgregNm = lgregNm;
    }
   
}
