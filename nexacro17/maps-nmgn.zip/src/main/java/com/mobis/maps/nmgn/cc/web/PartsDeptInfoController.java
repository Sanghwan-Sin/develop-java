package com.mobis.maps.nmgn.cc.web;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.PartsDeptInfoService;
import com.mobis.maps.nmgn.cc.vo.PartsDeptInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartsDeptInfoController.java
 * @Description : PartsDeptInfoController
 * @author ha.jeongryeong
 * @since 2019. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 10.     ha.jeongryeong         최초 생성
 * </pre>
 */
@Controller
public class PartsDeptInfoController extends HController {

    @Resource(name = "partsDeptInfoService")
    private PartsDeptInfoService partsDeptInfoService;
    
    /**
     * 조회(detail)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectPartsDeptInfo.do")
    public NexacroResult selectPartsDeptInfo(
            @ParamDataSet(name="dsInput") PartsDeptInfoVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        PartsDeptInfoVO retVO = partsDeptInfoService.selectPartsDeptInfo(paramVO);

        result.addDataSet("dsOutput", retVO);

        return result;
    }
    
    /**
     * 저장(detail)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/multiPartsDeptInfo.do")
    public NexacroResult multiPartsDeptInfo(
            @ParamDataSet(name="dsInput") PartsDeptInfoVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        partsDeptInfoService.multiPartsDeptInfo(paramVO);

        return result;
    }
    
    
    /**
     * 조회(list)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectPartsDeptInfoListExcelDown.do")
    public NexacroResult selectPartsDeptInfoListExcelDown(
            @ParamDataSet(name="dsInput") PartsDeptInfoVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        PartsDeptInfoVO retVO = partsDeptInfoService.selectPartsDeptInfo(paramVO);

        result.addDataSet("dsOutput", retVO);

        return result;
    }
}
