package com.mobis.maps.nmgn.sd.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.util.StringUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.OrderSalesSummaryService;
import com.mobis.maps.nmgn.sd.vo.OrderSalesSummaryVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderSalesSummaryServiceImpl.java
 * @Description : Order & Sales Summary
 * @author 이수지
 * @since 2020. 4. 08.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 08.      이수지      	        최초 생성
 * </pre>
 */

@Service("orderSalesSummaryService")
public class OrderSalesSummaryServiceImpl extends HService implements OrderSalesSummaryService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderSalesSummaryService#selectOrderSalesSummary(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderSalesSummaryVO)
     */
    @Override
    public Map<String, Object> selectOrderSalesSummary(LoginInfoVO loginVo, OrderSalesSummaryVO params)
            throws Exception {
        
        final String[] MONS = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
        
        List<OrderSalesSummaryVO> formatListVo = new ArrayList<OrderSalesSummaryVO>();
        OrderSalesSummaryVO item = null;     
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDERNSALES_CF;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
                
        //*** 조회결과
        List<OrderSalesSummaryVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST_D", params, OrderSalesSummaryVO.class);
        OrderSalesSummaryVO excelList = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_LIST_H", OrderSalesSummaryVO.class);
        // SORT
//        if (list != null && list.size() > 0) {
//            list.sort(new Comparator<OrderSalesSummaryVO>() {
//                @Override
//                public int compare(OrderSalesSummaryVO arg0, OrderSalesSummaryVO arg1) {
//                    if (arg0 == null || arg1 == null) return 0;
//                    if (arg0.getGjahr() == null) return 0;
//                    if (arg0.getMonth() == null) return 0;
//                    if (arg1.getGjahr() == null) return 0;
//                    if (arg1.getMonth() == null) return 0;
//                    
//                    int val0 = arg0.getGjahr().intValue() + arg0.getMonth().intValue();
//                    int val1 = arg1.getGjahr().intValue() + arg1.getMonth().intValue();
//                    
//                    if (val0 < val1) {return 1;}
//                    else if (val0 == val1) {return 0;}
//                    else {return -1;}
//                }                
//            });     
//        }
        
        //*** List 초기화
        for (int nMon = 0; nMon < 12; nMon++) {
            item = new OrderSalesSummaryVO();
            formatListVo.add(item);

            item.setMonth(new BigDecimal(nMon + 1));
            item.setKtx(MONS[nMon]);
        }
        
        int inYear = StringUtil.isNullToInt(params.getiGjahr(), 2000);
        int idx = 0;
        
        // 4년 Loop
        for (int nth = 0; nth < 4; nth++) {
            int nYear = inYear - 3 + nth;

            // 12개월 Loop
            for (int nMon = 1; nMon <= 12; nMon++) {
                item = formatListVo.get(nMon - 1);

                OrderSalesSummaryVO rfcVo = (list != null && list.size() > idx ? list.get(idx) : null);

                if (rfcVo == null)
                    continue;
                
                BigDecimal ordVal = null;
                BigDecimal salVal = null;
                
                if ("Q".equals(params.getiZtype())) { // Qty
                    ordVal = rfcVo.getOrdqty(); 
                    salVal = rfcVo.getSalqty();                     
                } else { // Amt
                    ordVal = this.selectToBigDecimal(rfcVo.getOrdamt());
                    salVal = this.selectToBigDecimal(rfcVo.getSalamt());
                }
                
                // 해당 년/월에 맞는 데이터 조회 시 해당 데이터 세팅
                if (rfcVo.getGjahr().compareTo(BigDecimal.valueOf((long) nYear)) == 0                                                                                     
                        && rfcVo.getMonth().compareTo(BigDecimal.valueOf((long) nMon)) == 0) {                                       
                    
                    switch (nth) {
                        case 0:                         
                            item.setOrdamt1(ordVal);
                            item.setSalamt1(salVal);
                            break;
                        case 1:
                            item.setOrdamt2(ordVal);
                            item.setSalamt2(salVal);
                            break;
                        case 2:
                            item.setOrdamt3(ordVal);
                            item.setSalamt3(salVal);
                            break;
                        case 3:
                            item.setOrdamt4(ordVal);
                            item.setSalamt4(salVal);
                            break;
                        default:
                            break;
                    }
                    idx++; // RFC 다음 레코드로이동
                }

            } // END-FOR 12개월

        } // END-FOR 4년
        
        retMap.put("head", excelList);
        retMap.put("body", formatListVo);
        
        return retMap;
    }

    
    /**
     * toBigDecimal
     *
     * @param val
     * @return
     */
    private BigDecimal selectToBigDecimal(String val) {
        BigDecimal rslt = null;
        
        if (StringUtils.isBlank(val)) return rslt;
        
        String tmp = val.replaceAll("[^0-9\\.\\-]", "").replaceAll("(.+)(-$)", "$2$1");
          
        try {
            rslt = new BigDecimal(tmp);
        } catch (Exception e) {
            if (logger.isDebugEnabled()) logger.debug("##### toBigDecimal Fail. SKIP.");
            rslt = new BigDecimal(0);
        }
        
        return rslt;
    }
}
