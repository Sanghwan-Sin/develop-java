package com.mobis.maps.smpl.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.smpl.vo.MapsSmplBoardVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplBoardMDAO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

@Mapper("mapsSmplBoardMDAO")
public interface MapsSmplBoardMDAO {

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    List<MapsSmplBoardVO> selectSmplBoardList(MapsSmplBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsSmplBoardVO selectSmplBoardNewList(MapsSmplBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int insertSmplBoard(MapsSmplBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int updateSmplBoard(MapsSmplBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int deleteSmplBoard(MapsSmplBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsSmplBoardVO selectContId(MapsSmplBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsSmplBoardVO selectSeq(MapsSmplBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int insertSmplBoardRply(MapsSmplBoardVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     */
    void deleteAtchFileAll(MapsSmplBoardVO inputVO);

}
