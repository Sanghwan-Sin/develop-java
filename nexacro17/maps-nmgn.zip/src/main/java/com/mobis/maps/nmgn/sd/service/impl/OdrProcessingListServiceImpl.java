package com.mobis.maps.nmgn.sd.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.OdrProcessingListService;
import com.mobis.maps.nmgn.sd.vo.OdrProcessingListVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OdrProcessingListServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 9.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 9.     jiyongdo     	최초 생성
 * </pre>
 */
@Service("odrProcessingListService")
public class OdrProcessingListServiceImpl extends HService implements OdrProcessingListService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.sd.service.OdrUnprocessedItmLstService#selectOdrUnprocessedItmList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderListVO)
     */
    @Override
    public Map<String, Object> selectOdrProcessingSumList(LoginInfoVO loginInfo, OdrProcessingListVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER_SUMMARY;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<OdrProcessingListVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, OdrProcessingListVO.class);
        //List<OdrProcessingListVO> totLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ES_TOTAL", paramVO, OdrProcessingListVO.class);
        OdrProcessingListVO totLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_TOTAL", OdrProcessingListVO.class);
        //List<OdrProcessingListVO> sumLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ES_SUMMARY", paramVO, OdrProcessingListVO.class);
        OdrProcessingListVO sumLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_SUMMARY", OdrProcessingListVO.class);
        sumLst.setZordTot1(sumLst.getZordcntTv().add(sumLst.getZordcntTg().add(sumLst.getZordcntTe().add(sumLst.getZordcntTsSm().add(sumLst.getZordcntTaSm().add(sumLst.getZordcntTpSm()))))));
        sumLst.setZordTot2(sumLst.getZordcntTm().add(sumLst.getZordcntTs()));
        
        retMap.put("head", totLst);
        retMap.put("body", odrLst);     
        retMap.put("summ", sumLst);     
        
        return retMap;        
    }  
}
