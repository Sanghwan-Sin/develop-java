package com.mobis.maps.nmgn.ti.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DownloadAoVO.java
 * @Description : ZPTI_NMGN_R_DOWNLOAD_SEARCH
 * @author 이수지
 * @since 2020. 06. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 16.     이수지     	       최초 생성
 * </pre>
 */

public class DownloadAoVO extends MapsCommSapRfcIfCommVO {
    
    /** 지역 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAREA" )
    private String iZarea;
    /** Dist Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDISTCD" )
    private String iZdistcd;
    /** 파일 유형 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFTYPE" )
    private String iZftype;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** 요청일자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQFDT" )
    private Date iZreqfdt;
    /** 요청자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQID" )
    private String iZreqid;
    /** 요청일자 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZREQTDT" )
    private Date iZreqtdt;
    /** 모비스차종코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZVHC" )
    private String iZvhc;

    
    /** -----[ET_DATA] START----- */
    
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZDISTCD" )
    private String zdistcd;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSEQNO" )
    private String zseqno;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZFTYPE" )
    private String zftype;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZREQID" )
    private String zreqid;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZREQDT" )
    private Date zreqdt;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZREQTM" )
    private Date zreqtm;   
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZFDESC" )
    private String zfdesc;
    /** H/K */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZAREA" )
    private String zarea;
    /** Mobis Car Code (Model No) */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZVHC" )
    private String zvhc;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZFSIZE" )
    private String zfsize;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="REF_NO" )
    private String refNo;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="FILE_NAME" )
    private String fileName;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="FILE_SEQNO" )
    private String fileSeqno;
    
    /** -----[ET_DATA] END----- */
    
    /**
     * @return the iZarea
     */
    public String getiZarea() {
        return iZarea;
    }
    /**
     * @param iZarea the iZarea to set
     */
    public void setiZarea(String iZarea) {
        this.iZarea = iZarea;
    }
    /**
     * @return the iZdistcd
     */
    public String getiZdistcd() {
        return iZdistcd;
    }
    /**
     * @param iZdistcd the iZdistcd to set
     */
    public void setiZdistcd(String iZdistcd) {
        this.iZdistcd = iZdistcd;
    }
    /**
     * @return the iZftype
     */
    public String getiZftype() {
        return iZftype;
    }
    /**
     * @param iZftype the iZftype to set
     */
    public void setiZftype(String iZftype) {
        this.iZftype = iZftype;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZreqfdt
     */
    public Date getiZreqfdt() {
        return iZreqfdt;
    }
    /**
     * @param iZreqfdt the iZreqfdt to set
     */
    public void setiZreqfdt(Date iZreqfdt) {
        this.iZreqfdt = iZreqfdt;
    }
    /**
     * @return the iZreqid
     */
    public String getiZreqid() {
        return iZreqid;
    }
    /**
     * @param iZreqid the iZreqid to set
     */
    public void setiZreqid(String iZreqid) {
        this.iZreqid = iZreqid;
    }
    /**
     * @return the iZreqtdt
     */
    public Date getiZreqtdt() {
        return iZreqtdt;
    }
    /**
     * @param iZreqtdt the iZreqtdt to set
     */
    public void setiZreqtdt(Date iZreqtdt) {
        this.iZreqtdt = iZreqtdt;
    }
    /**
     * @return the iZvhc
     */
    public String getiZvhc() {
        return iZvhc;
    }
    /**
     * @param iZvhc the iZvhc to set
     */
    public void setiZvhc(String iZvhc) {
        this.iZvhc = iZvhc;
    }
    /**
     * @return the zdistcd
     */
    public String getZdistcd() {
        return zdistcd;
    }
    /**
     * @param zdistcd the zdistcd to set
     */
    public void setZdistcd(String zdistcd) {
        this.zdistcd = zdistcd;
    }
    /**
     * @return the zseqno
     */
    public String getZseqno() {
        return zseqno;
    }
    /**
     * @param zseqno the zseqno to set
     */
    public void setZseqno(String zseqno) {
        this.zseqno = zseqno;
    }
    /**
     * @return the zftype
     */
    public String getZftype() {
        return zftype;
    }
    /**
     * @param zftype the zftype to set
     */
    public void setZftype(String zftype) {
        this.zftype = zftype;
    }
    /**
     * @return the zreqid
     */
    public String getZreqid() {
        return zreqid;
    }
    /**
     * @param zreqid the zreqid to set
     */
    public void setZreqid(String zreqid) {
        this.zreqid = zreqid;
    }
    /**
     * @return the zreqdt
     */
    public Date getZreqdt() {
        return zreqdt;
    }
    /**
     * @param zreqdt the zreqdt to set
     */
    public void setZreqdt(Date zreqdt) {
        this.zreqdt = zreqdt;
    }
    /**
     * @return the zreqtm
     */
    public Date getZreqtm() {
        return zreqtm;
    }
    /**
     * @param zreqtm the zreqtm to set
     */
    public void setZreqtm(Date zreqtm) {
        this.zreqtm = zreqtm;
    }
    /**
     * @return the zfdesc
     */
    public String getZfdesc() {
        return zfdesc;
    }
    /**
     * @param zfdesc the zfdesc to set
     */
    public void setZfdesc(String zfdesc) {
        this.zfdesc = zfdesc;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zarea
     */
    public String getZarea() {
        return zarea;
    }
    /**
     * @param zarea the zarea to set
     */
    public void setZarea(String zarea) {
        this.zarea = zarea;
    }
    /**
     * @return the zvhc
     */
    public String getZvhc() {
        return zvhc;
    }
    /**
     * @param zvhc the zvhc to set
     */
    public void setZvhc(String zvhc) {
        this.zvhc = zvhc;
    }
    /**
     * @return the zfsize
     */
    public String getZfsize() {
        return zfsize;
    }
    /**
     * @param zfsize the zfsize to set
     */
    public void setZfsize(String zfsize) {
        this.zfsize = zfsize;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }
    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    /**
     * @return the fileSeqno
     */
    public String getFileSeqno() {
        return fileSeqno;
    }
    /**
     * @param fileSeqno the fileSeqno to set
     */
    public void setFileSeqno(String fileSeqno) {
        this.fileSeqno = fileSeqno;
    }
    
    
}
