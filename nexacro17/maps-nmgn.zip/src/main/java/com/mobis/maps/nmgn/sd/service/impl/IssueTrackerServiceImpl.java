package com.mobis.maps.nmgn.sd.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.IssueTrackerService;
import com.mobis.maps.nmgn.sd.vo.IssueTrackerAddInputVO;
import com.mobis.maps.nmgn.sd.vo.IssueTrackerAddOutputVO;
import com.mobis.maps.nmgn.sd.vo.IssueTrackerVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : IssueTrackerServiceImpl.java
 * @Description : Issue Tracker(VOC Request) Service 구현
 * @author ChoKyungHo
 * @since 2020. 03. 02.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 02.    ChoKyungHo     	         최초 생성
 * </pre>
 */

@Service("issueTrackerService")
public class IssueTrackerServiceImpl extends HService implements IssueTrackerService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.IssueTrackerService#selectIssueTrackerList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.IssueTrackerVO)
     */
    @Override
    public List<IssueTrackerVO> selectIssueTrackerList(LoginInfoVO loginInfo, IssueTrackerVO paramVO) throws Exception {
     
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ISSUE_TRACKER_LIST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<IssueTrackerVO> itLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", paramVO, IssueTrackerVO.class);

        return itLst;
    }
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.IssueTrackerService#selectIssueTrackerDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.IssueTrackerAddInputVO)
     */
    @Override
    public Map<String, Object> selectIssueTrackerDetail(LoginInfoVO loginInfo, IssueTrackerAddInputVO paramVO) throws Exception {
     
        Map<String, Object> retMap  = new HashMap<String, Object>();

        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ISSUE_TRACKER;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportStructure(func, "IS_INPUT", paramVO);
        /* RFC 호출 */
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        IssueTrackerAddOutputVO rtnVO = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_OUTPUT", IssueTrackerAddOutputVO.class);  
        List<IssueTrackerAddOutputVO> cLst =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_CONTENT", IssueTrackerAddOutputVO.class);
        List<IssueTrackerAddOutputVO> rLst = MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_REPLY", IssueTrackerAddOutputVO.class);
        
        retMap.put("detail", rtnVO);
        retMap.put("content", cLst);
        retMap.put("reply", rLst);
        
        return retMap;
    }
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.IssueTrackerService#saveIssueTrackerRequest(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.IssueTrackerAddInputVO,
        com.mobis.maps.nmgn.cc.vo. List<IssueTrackerAddInputVO>)
     */
    @Override
    public Map<String, Object> multiSaveIssueTrackerRequest(LoginInfoVO loginInfo, IssueTrackerAddInputVO paramVO,
            List<IssueTrackerAddInputVO> paramComments) throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ISSUE_TRACKER;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
       // MapsRfcMappperUtil.setImportParamList(func, paramVO);
        MapsRfcMappperUtil.setImportStructure(func, "IS_INPUT", paramVO);
        
       
       //Comments
        if(paramComments != null && paramComments.size() >0)
        {
            for(int i=0; i<paramComments.size(); i++)
            {
               IssueTrackerAddInputVO tempCommentsVo = paramComments.get(i);
               MapsRfcMappperUtil.appendImportTableRow(func, "T_CONTENT", tempCommentsVo);
               
            }
        }
      
       
        /* RFC 호출 */
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func, true);
       
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        IssueTrackerAddOutputVO rtnVO = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_OUTPUT", IssueTrackerAddOutputVO.class); 
        
        retMap.put("result", rtnVO);

        // 결과데이타 추출
        //IssueTrackerAddVO rtnVO = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_OUTPUT", IssueTrackerAddVO.class);  
       
        //retMap.put("output", rtnVO);
       
        return retMap;
        
        
    }
    
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.IssueTrackerService#updateIssueTrackerRequest(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.IssueTrackerAddVO,
        com.mobis.maps.nmgn.cc.vo. List<IssueTrackerAddVO>)
     */
    @Override
    public Map<String, Object> updateIssueTrackerRequest(LoginInfoVO loginInfo, IssueTrackerAddInputVO paramVO,
            List<IssueTrackerAddInputVO> paramReply) throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ISSUE_TRACKER;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
       // MapsRfcMappperUtil.setImportParamList(func, paramVO);
        MapsRfcMappperUtil.setImportStructure(func, "IS_INPUT", paramVO);
        
       
        // Reply
        for (int i = 0; paramReply != null && i < paramReply.size(); i++) {
            IssueTrackerAddInputVO tempReplyVo = paramReply.get(i);
            MapsRfcMappperUtil.appendImportTableRow(func, "T_REPLY", tempReplyVo);

            
        }
       
        /* RFC 호출 */
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func, true);
       
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
       
        List<IssueTrackerAddOutputVO> cLst =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_CONTENT", IssueTrackerAddOutputVO.class);
       
        retMap.put("content", cLst);
       
        // 결과데이타 추출
        //IssueTrackerAddVO rtnVO = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_OUTPUT", IssueTrackerAddVO.class);  
       
        //retMap.put("output", rtnVO);
       
        return retMap;
        
    }

}
