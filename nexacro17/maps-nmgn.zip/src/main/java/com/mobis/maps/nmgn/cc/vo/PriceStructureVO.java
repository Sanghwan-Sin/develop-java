package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : DistInfoVO.java
 * @Description : DistInfoVO
 * @author hjeongryeong
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.    hjeongryeong      최초 생성
 *               </pre>
 */

public class PriceStructureVO extends MapsCommSapRfcIfCommVO {

    private String vkorg;
    private String vtweg;
    private String kunnr;
    private String aplyYear;
    private String zsacutm;
    private String land1;
    
    private double fob;
    private double fre;
    private double ins;
    private double cif;
    private double dut;
    private double wha;
    private double inl;
    private double frw;
    private double lcc;
    private double oth;
    private double sut;
    private double ldc;
    private double dis;
    private double den;
    private double dem;
    private double rnv;
    private double vat;
    private double rwv;
    
    private double disPro;
    private double demPro;
    
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the aplyYear
     */
    public String getAplyYear() {
        return aplyYear;
    }
    /**
     * @param aplyYear the aplyYear to set
     */
    public void setAplyYear(String aplyYear) {
        this.aplyYear = aplyYear;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the fob
     */
    public double getFob() {
        return fob;
    }
    /**
     * @param fob the fob to set
     */
    public void setFob(double fob) {
        this.fob = fob;
    }
    /**
     * @return the fre
     */
    public double getFre() {
        return fre;
    }
    /**
     * @param fre the fre to set
     */
    public void setFre(double fre) {
        this.fre = fre;
    }
    /**
     * @return the ins
     */
    public double getIns() {
        return ins;
    }
    /**
     * @param ins the ins to set
     */
    public void setIns(double ins) {
        this.ins = ins;
    }
    /**
     * @return the cif
     */
    public double getCif() {
        return cif;
    }
    /**
     * @param cif the cif to set
     */
    public void setCif(double cif) {
        this.cif = cif;
    }
    /**
     * @return the dut
     */
    public double getDut() {
        return dut;
    }
    /**
     * @param dut the dut to set
     */
    public void setDut(double dut) {
        this.dut = dut;
    }
    /**
     * @return the wha
     */
    public double getWha() {
        return wha;
    }
    /**
     * @param wha the wha to set
     */
    public void setWha(double wha) {
        this.wha = wha;
    }
    /**
     * @return the inl
     */
    public double getInl() {
        return inl;
    }
    /**
     * @param inl the inl to set
     */
    public void setInl(double inl) {
        this.inl = inl;
    }
    /**
     * @return the frw
     */
    public double getFrw() {
        return frw;
    }
    /**
     * @param frw the frw to set
     */
    public void setFrw(double frw) {
        this.frw = frw;
    }
    /**
     * @return the lcc
     */
    public double getLcc() {
        return lcc;
    }
    /**
     * @param lcc the lcc to set
     */
    public void setLcc(double lcc) {
        this.lcc = lcc;
    }
    /**
     * @return the oth
     */
    public double getOth() {
        return oth;
    }
    /**
     * @param oth the oth to set
     */
    public void setOth(double oth) {
        this.oth = oth;
    }
    /**
     * @return the sut
     */
    public double getSut() {
        return sut;
    }
    /**
     * @param sut the sut to set
     */
    public void setSut(double sut) {
        this.sut = sut;
    }
    /**
     * @return the ldc
     */
    public double getLdc() {
        return ldc;
    }
    /**
     * @param ldc the ldc to set
     */
    public void setLdc(double ldc) {
        this.ldc = ldc;
    }
    /**
     * @return the dis
     */
    public double getDis() {
        return dis;
    }
    /**
     * @param dis the dis to set
     */
    public void setDis(double dis) {
        this.dis = dis;
    }
    /**
     * @return the den
     */
    public double getDen() {
        return den;
    }
    /**
     * @param den the den to set
     */
    public void setDen(double den) {
        this.den = den;
    }
    /**
     * @return the dem
     */
    public double getDem() {
        return dem;
    }
    /**
     * @param dem the dem to set
     */
    public void setDem(double dem) {
        this.dem = dem;
    }
    /**
     * @return the rnv
     */
    public double getRnv() {
        return rnv;
    }
    /**
     * @param rnv the rnv to set
     */
    public void setRnv(double rnv) {
        this.rnv = rnv;
    }
    /**
     * @return the vat
     */
    public double getVat() {
        return vat;
    }
    /**
     * @param vat the vat to set
     */
    public void setVat(double vat) {
        this.vat = vat;
    }
    /**
     * @return the rwv
     */
    public double getRwv() {
        return rwv;
    }
    /**
     * @param rwv the rwv to set
     */
    public void setRwv(double rwv) {
        this.rwv = rwv;
    }
    /**
     * @return the disPro
     */
    public double getDisPro() {
        return disPro;
    }
    /**
     * @param disPro the disPro to set
     */
    public void setDisPro(double disPro) {
        this.disPro = disPro;
    }
    /**
     * @return the demPro
     */
    public double getDemPro() {
        return demPro;
    }
    /**
     * @param demPro the demPro to set
     */
    public void setDemPro(double demPro) {
        this.demPro = demPro;
    }
}
