package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.MsdsManagementVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MsdsManagementService.java
 * @Description : ZJSDR80140 MSDS Management
 * @author 이수지
 * @since 2020. 07. 15.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 07. 15.       이수지      	        최초 생성
 * </pre>
 */

public interface MsdsManagementService {

    /**
     * selectMsdsManagement
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<MsdsManagementVO> selectMsdsManagement (LoginInfoVO loginVo, MsdsManagementVO params) throws Exception;
    
}
