package com.mobis.maps.nmgn.ex.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFileInfoVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFileDlVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceFileDlService.java
 * @Description : ZJEXR00300 Invoice Download
 * @author 이수지
 * @since 2020. 07. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 07. 27.       이수지      	        최초 생성
 * </pre>
 */

public interface InvoiceFileDlService {

    /**
     * Invoice File Download
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<InvoiceFileDlVO> selectInvoiceFileDl (LoginInfoVO loginVo, InvoiceFileDlVO params) throws Exception;

    /**
     * Invoice File Download Info
     *
     * @param loginInfo
     * @param paramList
     * @return
     */
    Map<String, Object> selectInvoiceFileDlInfo(LoginInfoVO loginInfo, List<InvoiceFileInfoVO> paramList) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param invoiceNo
     * @param fileName
     * @param request
     * @param response
     */
    void selectInvoiceTxtDownload(LoginInfoVO loginInfo, String[] invoiceNo, String fileName,
            HttpServletRequest request, HttpServletResponse response) throws Exception;
}
