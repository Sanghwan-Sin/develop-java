package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.PromotionListService;
import com.mobis.maps.nmgn.sd.vo.PromotionListVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionListController.java
 * @Description : ZJSDR20120 Promotion List
 * @author 이수지
 * @since 2020. 3. 11
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 11       이수지                최초 생성
 * </pre>
 */

@Controller
public class PromotionListController extends HController {

    @Resource(name = "promotionListService")
    private PromotionListService promotionListService;

    /**
     * selectPromotionList
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPromotionList.do")
    public NexacroResult selectPromotionList(@ParamDataSet(name="dsInput") PromotionListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<PromotionListVO> list = promotionListService.selectPromotionList(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectPromotionListExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectPromotionListExcelDown.do")
    public NexacroResult selectPromotionListExcelDown(@ParamDataSet(name="dsInput") PromotionListVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<PromotionListVO> list = promotionListService.selectPromotionList(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
}
