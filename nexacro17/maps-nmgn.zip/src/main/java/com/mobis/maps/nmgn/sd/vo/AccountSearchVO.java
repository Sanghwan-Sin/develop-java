package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AccountSearchVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 4. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 17.     jiyongdo     	최초 생성
 * </pre>
 */

public class AccountSearchVO extends MapsCommSapRfcIfCommVO {

    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_LAND1" )
    private String iLand1;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_LREGIO" )
    private String iLregio;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MREGIO" )
    private String iMregio;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_NAME1" )
    private String iName1;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_SREGIO" )
    private String iSregio;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZACTNO" )
    private String iZactno;

    //-----[ET_LIST] START-----
    /** seq_nr */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SEQNO" )
    private Integer seqno;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZACTNO" )
    private String zactno;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZBANK_S" )
    private String zbankS;
    /** Dist. Code */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name 1 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /** Customer group 1 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /** Description */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="BEZEI" )
    private String bezei;
    /** Currency Key */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /** Long Text */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LTEXT" )
    private String ltext;
    /** Country Key */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LAND1" )
    private String land1;
    /** Country Name */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LANDX" )
    private String landx;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZLREGIO" )
    private String zlregio;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZLREGIO_TEXT" )
    private String zlregioText;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZMREGIO" )
    private String zmregio;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZMREGIO_TEXT" )
    private String zmregioText;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZSREGIO" )
    private String zsregio;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ZSREGIO_TEXT" )
    private String zsregioText;
    //-----[ET_LIST] END-----
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iLand1
     */
    public String getiLand1() {
        return iLand1;
    }
    /**
     * @param iLand1 the iLand1 to set
     */
    public void setiLand1(String iLand1) {
        this.iLand1 = iLand1;
    }
    /**
     * @return the iLregio
     */
    public String getiLregio() {
        return iLregio;
    }
    /**
     * @param iLregio the iLregio to set
     */
    public void setiLregio(String iLregio) {
        this.iLregio = iLregio;
    }
    /**
     * @return the iMregio
     */
    public String getiMregio() {
        return iMregio;
    }
    /**
     * @param iMregio the iMregio to set
     */
    public void setiMregio(String iMregio) {
        this.iMregio = iMregio;
    }
    /**
     * @return the iName1
     */
    public String getiName1() {
        return iName1;
    }
    /**
     * @param iName1 the iName1 to set
     */
    public void setiName1(String iName1) {
        this.iName1 = iName1;
    }
    /**
     * @return the iSregio
     */
    public String getiSregio() {
        return iSregio;
    }
    /**
     * @param iSregio the iSregio to set
     */
    public void setiSregio(String iSregio) {
        this.iSregio = iSregio;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iZactno
     */
    public String getiZactno() {
        return iZactno;
    }
    /**
     * @param iZactno the iZactno to set
     */
    public void setiZactno(String iZactno) {
        this.iZactno = iZactno;
    }
    /**
     * @return the seqno
     */
    public Integer getSeqno() {
        return seqno;
    }
    /**
     * @param seqno the seqno to set
     */
    public void setSeqno(Integer seqno) {
        this.seqno = seqno;
    }
    /**
     * @return the zactno
     */
    public String getZactno() {
        return zactno;
    }
    /**
     * @param zactno the zactno to set
     */
    public void setZactno(String zactno) {
        this.zactno = zactno;
    }
    /**
     * @return the zbankS
     */
    public String getZbankS() {
        return zbankS;
    }
    /**
     * @param zbankS the zbankS to set
     */
    public void setZbankS(String zbankS) {
        this.zbankS = zbankS;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the bezei
     */
    public String getBezei() {
        return bezei;
    }
    /**
     * @param bezei the bezei to set
     */
    public void setBezei(String bezei) {
        this.bezei = bezei;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the ltext
     */
    public String getLtext() {
        return ltext;
    }
    /**
     * @param ltext the ltext to set
     */
    public void setLtext(String ltext) {
        this.ltext = ltext;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the landx
     */
    public String getLandx() {
        return landx;
    }
    /**
     * @param landx the landx to set
     */
    public void setLandx(String landx) {
        this.landx = landx;
    }
    /**
     * @return the zlregio
     */
    public String getZlregio() {
        return zlregio;
    }
    /**
     * @param zlregio the zlregio to set
     */
    public void setZlregio(String zlregio) {
        this.zlregio = zlregio;
    }
    /**
     * @return the zlregioText
     */
    public String getZlregioText() {
        return zlregioText;
    }
    /**
     * @param zlregioText the zlregioText to set
     */
    public void setZlregioText(String zlregioText) {
        this.zlregioText = zlregioText;
    }
    /**
     * @return the zmregio
     */
    public String getZmregio() {
        return zmregio;
    }
    /**
     * @param zmregio the zmregio to set
     */
    public void setZmregio(String zmregio) {
        this.zmregio = zmregio;
    }
    /**
     * @return the zmregioText
     */
    public String getZmregioText() {
        return zmregioText;
    }
    /**
     * @param zmregioText the zmregioText to set
     */
    public void setZmregioText(String zmregioText) {
        this.zmregioText = zmregioText;
    }
    /**
     * @return the zsregio
     */
    public String getZsregio() {
        return zsregio;
    }
    /**
     * @param zsregio the zsregio to set
     */
    public void setZsregio(String zsregio) {
        this.zsregio = zsregio;
    }
    /**
     * @return the zsregioText
     */
    public String getZsregioText() {
        return zsregioText;
    }
    /**
     * @param zsregioText the zsregioText to set
     */
    public void setZsregioText(String zsregioText) {
        this.zsregioText = zsregioText;
    }
}
