package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.MailingVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistMailingMgrMDAO.java
 * @Description : 대리점 직원 메일링 주소조회
 * @author hong.minho
 * @since 2020. 4. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 14.     hong.minho     	최초 생성
 * </pre>
 */

@Mapper("distMailingMgrMDAO")
public interface DistMailingMgrMDAO {
    
    /**
     * 메일링목록조회
     *
     * @param vo
     * @return
     * @throws Exception
     */
    List<MailingVO> selectMailingLst(MailingVO vo) throws Exception;
}
