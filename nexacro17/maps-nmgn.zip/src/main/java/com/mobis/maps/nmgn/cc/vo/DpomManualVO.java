package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DpomManualVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 10. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

public class DpomManualVO extends PgBascVO{
    
    /* 조회조건 */
    private String pCmpnySeCd;
    private String pClCd;
    private String pSj;
    private String pFnctSe;
    private String strDate;
    private String endDate;
    
    
    /* 조회결과 */
    /** 순번 **/
    private String regNum;
    /** 문서번호 */
    private String docNo;
    /** 기능구분 */
    private String fnctSe;
    /** 회사구분 */
    private String cmpnySeCd;
    /** 분류(카테고리)명 */
    private String clNm;
    /** 제목 */
    private String sj;
    /** 내용 */
    private String cn;
    /** 첨부파일명 */
    private String atchmnflNm;
    /** 첨부파일타입 */
    private String atchmnflTy;
    /** 삭제여부 */
    private String delYn;
    /** 등록자ID */
    private String dpomRegistId;
    /** 등록일 */
    private String dpomRegistDt;
    /** 수정자ID */
    private String updtId;
    /** 사용자ID */
    private String userId;
    private String fileCnt;
    private String atchSe;
    private String atchId;
    private String seq;
    private String salesOrg;
    private int rcnt;

    /**
     * @return the pCmpnySeCd
     */
    public String getpCmpnySeCd() {
        return pCmpnySeCd;
    }
    /**
     * @param pCmpnySeCd the pCmpnySeCd to set
     */
    public void setpCmpnySeCd(String pCmpnySeCd) {
        this.pCmpnySeCd = pCmpnySeCd;
    }
    /**
     * @return the pClCd
     */
    public String getpClCd() {
        return pClCd;
    }
    /**
     * @param pClCd the pClCd to set
     */
    public void setpClCd(String pClCd) {
        this.pClCd = pClCd;
    }
    /**
     * @return the pSj
     */
    public String getpSj() {
        return pSj;
    }
    /**
     * @param pSj the pSj to set
     */
    public void setpSj(String pSj) {
        this.pSj = pSj;
    }
    /**
     * @return the pFnctSe
     */
    public String getpFnctSe() {
        return pFnctSe;
    }
    /**
     * @param pFnctSe the pFnctSe to set
     */
    public void setpFnctSe(String pFnctSe) {
        this.pFnctSe = pFnctSe;
    }
    /**
     * @return the strDate
     */
    public String getStrDate() {
        return strDate;
    }
    /**
     * @param strDate the strDate to set
     */
    public void setStrDate(String strDate) {
        this.strDate = strDate;
    }
    /**
     * @return the endDate
     */
    public String getEndDate() {
        return endDate;
    }
    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    /**
     * @return the regNum
     */
    public String getRegNum() {
        return regNum;
    }
    /**
     * @param regNum the regNum to set
     */
    public void setRegNum(String regNum) {
        this.regNum = regNum;
    }
    /**
     * @return the docNo
     */
    public String getDocNo() {
        return docNo;
    }
    /**
     * @param docNo the docNo to set
     */
    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }
    /**
     * @return the fnctSe
     */
    public String getFnctSe() {
        return fnctSe;
    }
    /**
     * @param fnctSe the fnctSe to set
     */
    public void setFnctSe(String fnctSe) {
        this.fnctSe = fnctSe;
    }
    /**
     * @return the cmpnySeCd
     */
    public String getCmpnySeCd() {
        return cmpnySeCd;
    }
    /**
     * @param cmpnySeCd the cmpnySeCd to set
     */
    public void setCmpnySeCd(String cmpnySeCd) {
        this.cmpnySeCd = cmpnySeCd;
    }
    /**
     * @return the clNm
     */
    public String getClNm() {
        return clNm;
    }
    /**
     * @param clNm the clNm to set
     */
    public void setClNm(String clNm) {
        this.clNm = clNm;
    }
    /**
     * @return the sj
     */
    public String getSj() {
        return sj;
    }
    /**
     * @param sj the sj to set
     */
    public void setSj(String sj) {
        this.sj = sj;
    }
    /**
     * @return the cn
     */
    public String getCn() {
        return cn;
    }
    /**
     * @param cn the cn to set
     */
    public void setCn(String cn) {
        this.cn = cn;
    }
    /**
     * @return the atchmnflNm
     */
    public String getAtchmnflNm() {
        return atchmnflNm;
    }
    /**
     * @param atchmnflNm the atchmnflNm to set
     */
    public void setAtchmnflNm(String atchmnflNm) {
        this.atchmnflNm = atchmnflNm;
    }
    /**
     * @return the atchmnflTy
     */
    public String getAtchmnflTy() {
        return atchmnflTy;
    }
    /**
     * @param atchmnflTy the atchmnflTy to set
     */
    public void setAtchmnflTy(String atchmnflTy) {
        this.atchmnflTy = atchmnflTy;
    }
    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }
    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    /**
     * @return the dpomRegistId
     */
    public String getDpomRegistId() {
        return dpomRegistId;
    }
    /**
     * @param dpomRegistId the dpomRegistId to set
     */
    public void setDpomRegistId(String dpomRegistId) {
        this.dpomRegistId = dpomRegistId;
    }
    /**
     * @return the dpomRegistDt
     */
    public String getDpomRegistDt() {
        return dpomRegistDt;
    }
    /**
     * @param dpomRegistDt the dpomRegistDt to set
     */
    public void setDpomRegistDt(String dpomRegistDt) {
        this.dpomRegistDt = dpomRegistDt;
    }
    /**
     * @return the updtId
     */
    public String getUpdtId() {
        return updtId;
    }
    /**
     * @param updtId the updtId to set
     */
    public void setUpdtId(String updtId) {
        this.updtId = updtId;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the fileCnt
     */
    public String getFileCnt() {
        return fileCnt;
    }
    /**
     * @param fileCnt the fileCnt to set
     */
    public void setFileCnt(String fileCnt) {
        this.fileCnt = fileCnt;
    }
    /**
     * @return the atchSe
     */
    public String getAtchSe() {
        return atchSe;
    }
    /**
     * @param atchSe the atchSe to set
     */
    public void setAtchSe(String atchSe) {
        this.atchSe = atchSe;
    }
    /**
     * @return the atchId
     */
    public String getAtchId() {
        return atchId;
    }
    /**
     * @param atchId the atchId to set
     */
    public void setAtchId(String atchId) {
        this.atchId = atchId;
    }
    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }
    /**
     * @return the salesOrg
     */
    public String getSalesOrg() {
        return salesOrg;
    }
    /**
     * @param salesOrg the salesOrg to set
     */
    public void setSalesOrg(String salesOrg) {
        this.salesOrg = salesOrg;
    }
    /**
     * @return the rcnt
     */
    public int getRcnt() {
        return rcnt;
    }
    /**
     * @param rcnt the rcnt to set
     */
    public void setRcnt(int rcnt) {
        this.rcnt = rcnt;
    }
}
