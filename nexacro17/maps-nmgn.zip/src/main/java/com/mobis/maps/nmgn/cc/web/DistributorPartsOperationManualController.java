package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.nmgn.cc.service.DistributorPartsOperationManualService;
import com.mobis.maps.nmgn.cc.vo.DpomManualVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistributorPartsOperationManualController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 10. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 22.     Jiyongdo     	최초 생성
 * </pre>
 */
@Controller
public class DistributorPartsOperationManualController extends HController{

    @Resource(name = "distributorPartsOperationManualService")
    private DistributorPartsOperationManualService distributorPartsOperationManualService;
    
    /**
     * DPOM List 조회
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDpomList.do")
    public NexacroResult selectDpomList(@ParamDataSet(name="dsInput") DpomManualVO paramVO
                                      , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<DpomManualVO> retList = distributorPartsOperationManualService.selectDpomList(loginInfo, paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }    
    
    /**
     * DPOM List 저장
     *
     * @param paramVO
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/cc/multiSaveDpomList.do")
    public NexacroResult multiSaveDpomList(@ParamDataSet(name="dsInput") List<DpomManualVO> paramVOList
                                    , NexacroResult result) throws Exception {
        
        int cnt = distributorPartsOperationManualService.multiSaveDpomList(paramVOList);

        result.addVariable("procCnt", cnt);

        return result;
    }        
    
    /**
     * DPOM Edit 조회
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDpomEditList.do")
    public NexacroResult selectDpomEditList(@ParamDataSet(name="dsInput") DpomManualVO paramVO
                                      , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        DpomManualVO reslt = distributorPartsOperationManualService.selectDpomEditList(loginInfo, paramVO);

        result.addDataSet("dsOutput", reslt);

        return result;
    }      
    
    /**
     * DPOM List 저장
     *
     * @param paramVO
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/cc/deleteDpomList.do")
    public NexacroResult deleteDpomList(@ParamDataSet(name="dsInput") DpomManualVO paramVO
                                    , NexacroResult result) throws Exception {
        
        int cnt = distributorPartsOperationManualService.deleteDpom(paramVO);

        result.addVariable("procCnt", cnt);

        return result;
    }     
    
    /**
     * DPOM List 저장
     *
     * @param paramVO
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/cc/updateDpomList.do")
    public NexacroResult updateDpomList(@ParamDataSet(name="dsInput") DpomManualVO paramVO
                                      , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setUpdtId(loginInfo.getUserId());
        
        int cnt = distributorPartsOperationManualService.updateDpom(paramVO);
        
        result.addVariable("procCnt", cnt);

        return result;
    }     
    
    /**
     * DPOM List 저장
     *
     * @param paramVO
     * @return
     * @throws Exception
     */    
    @RequestMapping(value = "/cc/insertDpomList.do")
    public NexacroResult insertDpomList(@ParamDataSet(name="dsInput") DpomManualVO paramVO
                                      , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        paramVO.setUserId(loginInfo.getUserId());
        paramVO.setRegistId(loginInfo.getUserId());
        DpomManualVO retList = distributorPartsOperationManualService.insertDpom(paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }  
    
    /**
     * 샘플 첨부파일 등록
     *
     * @param DpomManualVO
     * @param atchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/multiAtchFile.do")
    public NexacroResult multiAtchFile(
            @ParamDataSet(name="dsInput") DpomManualVO atchFileVO
            , @ParamDataSet(name="dsInputAtchFile") List<MapsAtchFileVO> atchFiles
            , NexacroResult result) throws Exception {
        
        int procCnt = distributorPartsOperationManualService.multiAtchFile(atchFileVO, atchFiles);

        result.addVariable("procCnt", procCnt);

        return result;
    }    
}
