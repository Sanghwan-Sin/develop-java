package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.PartTransactionStatusVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartTransactionStatusService.java
 * @Description : Part Transaction Status
 * @author 이수지
 * @since 2020. 11. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 11. 25.     이수지     	       최초 생성
 * </pre>
 */

public interface PartTransactionStatusService {

    /**
     * Part Transaction Status
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<PartTransactionStatusVO> selectPartTransactionStatus(LoginInfoVO loginInfo, PartTransactionStatusVO params) throws Exception;
}
