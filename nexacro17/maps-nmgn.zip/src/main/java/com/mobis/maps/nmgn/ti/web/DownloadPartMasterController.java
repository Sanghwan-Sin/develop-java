package com.mobis.maps.nmgn.ti.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ti.service.DownloadPartMasterService;
import com.mobis.maps.nmgn.ti.vo.DownloadAoFinishVO;
import com.mobis.maps.nmgn.ti.vo.DownloadAoRequestVO;
import com.mobis.maps.nmgn.ti.vo.DownloadAoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DownloadPartMasterController.java
 * @Description : ZJSDR03020 Download Part Master
 * @author 이수지
 * @since 2020. 06. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 16.       이수지              최초 생성
 * </pre>
 */

@Controller
public class DownloadPartMasterController extends HController {

    @Resource(name = "downloadPartMasterService")
    private DownloadPartMasterService downloadPartMasterService;

    /**
     * selectPartMasterDownload
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectDownloadPartMaster.do")
    public NexacroResult selectDownloadPartMaster(@ParamDataSet(name="dsInput") DownloadAoVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<DownloadAoVO> list = downloadPartMasterService.selectDownloadPartMaster(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectDownloadPartMasterExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectDownloadPartMasterExcelDown.do")
    public NexacroResult selectDownloadPartMasterExcelDown(@ParamDataSet(name="dsInput") DownloadAoVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<DownloadAoVO> list = downloadPartMasterService.selectDownloadPartMaster(loginInfo, params);
      
        result.addDataSet("dsOutput", list);

        return result;
    }
    
    /**
     * selectPartMasterDownloadRequest
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectDownloadPartMasterRequest.do")
    public NexacroResult selectDownloadPartMasterRequest(@ParamDataSet(name="dsInput") DownloadAoRequestVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setiZreqid(loginInfo.getUserId()); // 요청자 ID
       
        downloadPartMasterService.selectDownloadPartMasterRequest(loginInfo, params);

        result.addDataSet("dsReturn", params);
        
        return result;
    }
    
    /**
     * selectPartMasterDownFinish
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ti/selectDownloadPartMasterFinish.do")
    public NexacroResult selectDownloadPartMasterFinish(@ParamDataSet(name="dsInput") DownloadAoFinishVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);       
       
        downloadPartMasterService.selectDownloadPartMasterFinish(loginInfo, params);

        result.addDataSet("dsReturn", params);
        
        return result;
    }
}
