package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionListVO.java
 * @Description : ZPSD_MGN_S_PROMOTION_DETAIL
 * @author 이수지
 * @since 2020. 3. 12
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 12       이수지     	       최초 생성
 * </pre>
 */

public class PromotionListVO extends MapsCommSapRfcIfCommVO {

    /** ABAP system field: Current date of application server */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATES_F" )
    private Date iDatesF;
    /** ABAP system field: Current date of application server */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATES_T" )
    private Date iDatesT;
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR_F" )
    private String iMatnrF;
    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR_T" )
    private String iMatnrT;
    /** Approval Status(A: All, Y: Applied, F: Finished)) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_STATUS" )
    private String iStatus;
    /** C/R/U/D (Search:R) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 프로모션 프로파일 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPPI_F" )
    private String iZppiF;
    /** 프로모션 프로파일 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPPI_T" )
    private String iZppiT;
    /** nMGN Product Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPROD_TYP" )
    private String iZprodTyp;
    /** Promotion Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPRTYP" )
    private String iZprtyp;
    /** Dist. code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    
    /** -----[T_RESULT] START----- */
    
    /** Dist. Code */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Material Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** Product 타입코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPROD_TYP" )
    private String zprodTyp;
    /** Character field of length 40 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPROD_TYP_DESC" )
    private String zprodTypDesc;
    /** 오더번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /** 프로모션 프로파일 번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPI" )
    private String zppi;
    /** Character field of length 40 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRNM" )
    private String zprnm;
    /** 프로모션 Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRTYP" )
    private String zprtyp;
    /** Character field of length 40 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRTYP_DESC" )
    private String zprtypDesc;
    /** Quantity(20자리) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="UMMENGE" )
    private String ummenge;
    /** 프로파일 유효시작일 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPIST" )
    private Date zppist;
    /** 프로파일 유효종료일 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPIEN" )
    private Date zppien;
    /** Status */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSTATUS" )
    private String zstatus;
    /** Currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /** Price List Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PLTYP" )
    private String pltyp;
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="LIST_PRICE" )
    private String listPrice;
    /** General D/C */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZGDDC" )
    private String zgddc;
    /** Additional D/C */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZADDC" )
    private String zaddc;
    /** Plus D/C */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPDDC" )
    private String zpddc;
    /** Fixed Price */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFPDC" )
    private String zfpdc;
    /** Order D/C */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDDC" )
    private String zorddc;
    /** Celling D/C */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCLDC" )
    private String zcldc;
    /** Condition unit (currency or percentage) */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="KONWA" )
    private String konwa;
    /** Currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** A:Icon 미표시, B:OrderType 표시, C:ALL, D:Popup */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZTYPE" )
    private String ztype;
    /** Order Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP" )
    private String zordtyp;
    /** Order Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP_NM" )
    private String zordtypNm;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="STD_PRICE" )
    private String stdPrice;
    
    /** -----[T_RESULT] END----- */
    
    
    /**
     * @return the iDatesF
     */
    public Date getiDatesF() {
        return iDatesF;
    }
    /**
     * @param iDatesF the iDatesF to set
     */
    public void setiDatesF(Date iDatesF) {
        this.iDatesF = iDatesF;
    }
    /**
     * @return the iDatesT
     */
    public Date getiDatesT() {
        return iDatesT;
    }
    /**
     * @param iDatesT the iDatesT to set
     */
    public void setiDatesT(Date iDatesT) {
        this.iDatesT = iDatesT;
    }
    /**
     * @return the iMatnrF
     */
    public String getiMatnrF() {
        return iMatnrF;
    }
    /**
     * @param iMatnrF the iMatnrF to set
     */
    public void setiMatnrF(String iMatnrF) {
        this.iMatnrF = iMatnrF;
    }
    /**
     * @return the iMatnrT
     */
    public String getiMatnrT() {
        return iMatnrT;
    }
    /**
     * @param iMatnrT the iMatnrT to set
     */
    public void setiMatnrT(String iMatnrT) {
        this.iMatnrT = iMatnrT;
    }
    /**
     * @return the iStatus
     */
    public String getiStatus() {
        return iStatus;
    }
    /**
     * @param iStatus the iStatus to set
     */
    public void setiStatus(String iStatus) {
        this.iStatus = iStatus;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZppiF
     */
    public String getiZppiF() {
        return iZppiF;
    }
    /**
     * @param iZppiF the iZppiF to set
     */
    public void setiZppiF(String iZppiF) {
        this.iZppiF = iZppiF;
    }
    /**
     * @return the iZppiT
     */
    public String getiZppiT() {
        return iZppiT;
    }
    /**
     * @param iZppiT the iZppiT to set
     */
    public void setiZppiT(String iZppiT) {
        this.iZppiT = iZppiT;
    }
    /**
     * @return the iZprodTyp
     */
    public String getiZprodTyp() {
        return iZprodTyp;
    }
    /**
     * @param iZprodTyp the iZprodTyp to set
     */
    public void setiZprodTyp(String iZprodTyp) {
        this.iZprodTyp = iZprodTyp;
    }
    /**
     * @return the iZprtyp
     */
    public String getiZprtyp() {
        return iZprtyp;
    }
    /**
     * @param iZprtyp the iZprtyp to set
     */
    public void setiZprtyp(String iZprtyp) {
        this.iZprtyp = iZprtyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zprodTyp
     */
    public String getZprodTyp() {
        return zprodTyp;
    }
    /**
     * @param zprodTyp the zprodTyp to set
     */
    public void setZprodTyp(String zprodTyp) {
        this.zprodTyp = zprodTyp;
    }
    /**
     * @return the zprodTypDesc
     */
    public String getZprodTypDesc() {
        return zprodTypDesc;
    }
    /**
     * @param zprodTypDesc the zprodTypDesc to set
     */
    public void setZprodTypDesc(String zprodTypDesc) {
        this.zprodTypDesc = zprodTypDesc;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zppi
     */
    public String getZppi() {
        return zppi;
    }
    /**
     * @param zppi the zppi to set
     */
    public void setZppi(String zppi) {
        this.zppi = zppi;
    }
    /**
     * @return the zprnm
     */
    public String getZprnm() {
        return zprnm;
    }
    /**
     * @param zprnm the zprnm to set
     */
    public void setZprnm(String zprnm) {
        this.zprnm = zprnm;
    }
    /**
     * @return the zprtyp
     */
    public String getZprtyp() {
        return zprtyp;
    }
    /**
     * @param zprtyp the zprtyp to set
     */
    public void setZprtyp(String zprtyp) {
        this.zprtyp = zprtyp;
    }
    /**
     * @return the zprtypDesc
     */
    public String getZprtypDesc() {
        return zprtypDesc;
    }
    /**
     * @param zprtypDesc the zprtypDesc to set
     */
    public void setZprtypDesc(String zprtypDesc) {
        this.zprtypDesc = zprtypDesc;
    }
    /**
     * @return the ummenge
     */
    public String getUmmenge() {
        return ummenge;
    }
    /**
     * @param ummenge the ummenge to set
     */
    public void setUmmenge(String ummenge) {
        this.ummenge = ummenge;
    }
    /**
     * @return the zppist
     */
    public Date getZppist() {
        return zppist;
    }
    /**
     * @param zppist the zppist to set
     */
    public void setZppist(Date zppist) {
        this.zppist = zppist;
    }
    /**
     * @return the zppien
     */
    public Date getZppien() {
        return zppien;
    }
    /**
     * @param zppien the zppien to set
     */
    public void setZppien(Date zppien) {
        this.zppien = zppien;
    }
    /**
     * @return the zstatus
     */
    public String getZstatus() {
        return zstatus;
    }
    /**
     * @param zstatus the zstatus to set
     */
    public void setZstatus(String zstatus) {
        this.zstatus = zstatus;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the listPrice
     */
    public String getListPrice() {
        return listPrice;
    }
    /**
     * @param listPrice the listPrice to set
     */
    public void setListPrice(String listPrice) {
        this.listPrice = listPrice;
    }
    /**
     * @return the zgddc
     */
    public String getZgddc() {
        return zgddc;
    }
    /**
     * @param zgddc the zgddc to set
     */
    public void setZgddc(String zgddc) {
        this.zgddc = zgddc;
    }
    /**
     * @return the zaddc
     */
    public String getZaddc() {
        return zaddc;
    }
    /**
     * @param zaddc the zaddc to set
     */
    public void setZaddc(String zaddc) {
        this.zaddc = zaddc;
    }
    /**
     * @return the zpddc
     */
    public String getZpddc() {
        return zpddc;
    }
    /**
     * @param zpddc the zpddc to set
     */
    public void setZpddc(String zpddc) {
        this.zpddc = zpddc;
    }
    /**
     * @return the zfpdc
     */
    public String getZfpdc() {
        return zfpdc;
    }
    /**
     * @param zfpdc the zfpdc to set
     */
    public void setZfpdc(String zfpdc) {
        this.zfpdc = zfpdc;
    }
    /**
     * @return the zorddc
     */
    public String getZorddc() {
        return zorddc;
    }
    /**
     * @param zorddc the zorddc to set
     */
    public void setZorddc(String zorddc) {
        this.zorddc = zorddc;
    }
    /**
     * @return the konwa
     */
    public String getKonwa() {
        return konwa;
    }
    /**
     * @param konwa the konwa to set
     */
    public void setKonwa(String konwa) {
        this.konwa = konwa;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the ztype
     */
    public String getZtype() {
        return ztype;
    }
    /**
     * @param ztype the ztype to set
     */
    public void setZtype(String ztype) {
        this.ztype = ztype;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the zordtypNm
     */
    public String getZordtypNm() {
        return zordtypNm;
    }
    /**
     * @param zordtypNm the zordtypNm to set
     */
    public void setZordtypNm(String zordtypNm) {
        this.zordtypNm = zordtypNm;
    }
    /**
     * @return the zcldc
     */
    public String getZcldc() {
        return zcldc;
    }
    /**
     * @param zcldc the zcldc to set
     */
    public void setZcldc(String zcldc) {
        this.zcldc = zcldc;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the stdPrice
     */
    public String getStdPrice() {
        return stdPrice;
    }
    /**
     * @param stdPrice the stdPrice to set
     */
    public void setStdPrice(String stdPrice) {
        this.stdPrice = stdPrice;
    }
    
}
