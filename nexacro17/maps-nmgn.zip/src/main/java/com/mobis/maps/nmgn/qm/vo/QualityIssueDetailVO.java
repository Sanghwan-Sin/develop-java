package com.mobis.maps.nmgn.qm.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : QualityIssueDetailVO.java
 * @Description : Quality Issue Detail
 * @author jiyongdo
 * @since 2020. 3. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 17.     jiyongdo     	최초 생성
 * </pre>
 */

public class QualityIssueDetailVO extends MapsCommSapRfcIfCommVO{
    //-----[IS_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZCRUD" )
    private String zcrud;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZSYSCODE" )
    private String zsyscode;
    //-----[IS_DATA] END-----
    //-----[ES_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZQISSUENO" )
    private String zqissueno;
    /** Company Code */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="BUKRS" )
    private String bukrs2;
    /** Name of Company Code or Company */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="BUKRST" )
    private String bukrst;
    /** Plant */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="WERKS" )
    private String werks;
    /** Name */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="WERKST" )
    private String werkst;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="VKBUR" )
    private String vkbur;
    /** Description */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="VKBURT" )
    private String vkburt;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZSTSCODE" )
    private String zstscode;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZSTSCODET" )
    private String zstscodet;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZREQCODE" )
    private String zreqcode;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZREQCODET" )
    private String zreqcodet;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZDIST" )
    private String zdist;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZDISTT" )
    private String zdistt;
    /** Material Number */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="MATNR" )
    private String matnr;
    /** Material description */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="MATNRT" )
    private String matnrt;
    /** Quantity */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="MENGE" )
    private BigDecimal menge;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="MEINS" )
    private String meins;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZPSLOT" )
    private String zpslot;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="CLCODEGR1" )
    private String clcodegr1;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="CLCODEGR1T" )
    private String clcodegr1t;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZDELDATE" )
    private Date zdeldate;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZDELID" )
    private String zdelid;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZDELIDT" )
    private String zdelidt;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZREQDATE" )
    private Date zreqdate;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZREQID" )
    private String zreqid;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZREQIDT" )
    private String zreqidt;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZSMBDATE" )
    private Date zsmbdate;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZSMBID" )
    private String zsmbid;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZSMBIDT" )
    private String zsmbidt;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="ZREQDETAIL" )
    private String zreqdetail;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="FSCODE" )
    private String fscode;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="FILE_SEQNO_OK" )
    private String fileSeqnoOk;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="REF_NO_OK" )
    private String refNoOk;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="FILET_OK" )
    private String filetOk;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="FILE_SEQNO_NG" )
    private String fileSeqnoNg;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="REF_NO_NG" )
    private String refNoNg;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="FILET_DEFECT" )
    private String filetDefect;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="FILE_SEQNO_LABEL" )
    private String fileSeqnoLabel;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="REF_NO_LABEL" )
    private String refNoLabel;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="FILET_LABEL" )
    private String filetLabel;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="FILE_SEQNO_ETC1" )
    private String fileSeqnoEtc1;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="REF_NO_ETC1" )
    private String refNoEtc1;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="FILET_ETC1" )
    private String filetEtc1;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="FILE_SEQNO_ETC2" )
    private String fileSeqnoEtc2;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="REF_NO_ETC2" )
    private String refNoEtc2;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="FILET_ETC2" )
    private String filetEtc2;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="FILE_SEQNO_ETC3" )
    private String fileSeqnoEtc3;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="REF_NO_ETC3" )
    private String refNoEtc3;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA|ES_DATA", ipttSe="I|E", fieldKey="FILET_ETC3" )
    private String filetEtc3;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRCVDATE" )
    private Date zrcvdate;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRCVID" )
    private String zrcvid;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRCVIDT" )
    private String zrcvidt;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRCNDATE" )
    private Date zrcndate;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRCNID" )
    private String zrcnid;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRCNIDT" )
    private String zrcnidt;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRCNRSN" )
    private String zrcnrsn;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPRCCODE" )
    private String zprccode;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPRCCODET" )
    private String zprccodet;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRSPLIFNR" )
    private String zrsplifnr;
    /** Name 1 */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZRSPLIFNRT" )
    private String zrsplifnrt;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZNCRNO" )
    private String zncrno;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="CLCODE2" )
    private String clcode2;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="CLCODE2T" )
    private String clcode2t;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPRCDATE" )
    private Date zprcdate;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPRCID" )
    private String zprcid;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPRCIDT" )
    private String zprcidt;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="ZPRCOPN" )
    private String zprcopn;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** Message Number */
    @MapsRfcMappper( targetName="ES_DATA", ipttSe="E", fieldKey="MSGNO" )
    private BigDecimal msgno;
    /**  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZREQIDMAIL" )
    private String zreqidmail;    
    /**  */
    @MapsRfcMappper( targetName="IS_DATA", ipttSe="I", fieldKey="ZSMBIDMAIL" )
    private String zsmbidmail;    
    //-----[ES_DATA] END-----
    /**
     * @return the zcrud
     */
    public String getZcrud() {
        return zcrud;
    }
    /**
     * @param zcrud the zcrud to set
     */
    public void setZcrud(String zcrud) {
        this.zcrud = zcrud;
    }
    /**
     * @return the zsyscode
     */
    public String getZsyscode() {
        return zsyscode;
    }
    /**
     * @param zsyscode the zsyscode to set
     */
    public void setZsyscode(String zsyscode) {
        this.zsyscode = zsyscode;
    }
    /**
     * @return the zqissueno
     */
    public String getZqissueno() {
        return zqissueno;
    }
    /**
     * @param zqissueno the zqissueno to set
     */
    public void setZqissueno(String zqissueno) {
        this.zqissueno = zqissueno;
    }
    /**
     * @return the bukrs2
     */
    public String getBukrs2() {
        return bukrs2;
    }
    /**
     * @param bukrs2 the bukrs2 to set
     */
    public void setBukrs2(String bukrs2) {
        this.bukrs2 = bukrs2;
    }
    /**
     * @return the bukrst
     */
    public String getBukrst() {
        return bukrst;
    }
    /**
     * @param bukrst the bukrst to set
     */
    public void setBukrst(String bukrst) {
        this.bukrst = bukrst;
    }
    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }
    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }
    /**
     * @return the werkst
     */
    public String getWerkst() {
        return werkst;
    }
    /**
     * @param werkst the werkst to set
     */
    public void setWerkst(String werkst) {
        this.werkst = werkst;
    }
    /**
     * @return the vkbur
     */
    public String getVkbur() {
        return vkbur;
    }
    /**
     * @param vkbur the vkbur to set
     */
    public void setVkbur(String vkbur) {
        this.vkbur = vkbur;
    }
    /**
     * @return the vkburt
     */
    public String getVkburt() {
        return vkburt;
    }
    /**
     * @param vkburt the vkburt to set
     */
    public void setVkburt(String vkburt) {
        this.vkburt = vkburt;
    }
    /**
     * @return the zstscode
     */
    public String getZstscode() {
        return zstscode;
    }
    /**
     * @param zstscode the zstscode to set
     */
    public void setZstscode(String zstscode) {
        this.zstscode = zstscode;
    }
    /**
     * @return the zstscodet
     */
    public String getZstscodet() {
        return zstscodet;
    }
    /**
     * @param zstscodet the zstscodet to set
     */
    public void setZstscodet(String zstscodet) {
        this.zstscodet = zstscodet;
    }
    /**
     * @return the zreqcode
     */
    public String getZreqcode() {
        return zreqcode;
    }
    /**
     * @param zreqcode the zreqcode to set
     */
    public void setZreqcode(String zreqcode) {
        this.zreqcode = zreqcode;
    }
    /**
     * @return the zreqcodet
     */
    public String getZreqcodet() {
        return zreqcodet;
    }
    /**
     * @param zreqcodet the zreqcodet to set
     */
    public void setZreqcodet(String zreqcodet) {
        this.zreqcodet = zreqcodet;
    }
    /**
     * @return the zdist
     */
    public String getZdist() {
        return zdist;
    }
    /**
     * @param zdist the zdist to set
     */
    public void setZdist(String zdist) {
        this.zdist = zdist;
    }
    /**
     * @return the zdistt
     */
    public String getZdistt() {
        return zdistt;
    }
    /**
     * @param zdistt the zdistt to set
     */
    public void setZdistt(String zdistt) {
        this.zdistt = zdistt;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the matnrt
     */
    public String getMatnrt() {
        return matnrt;
    }
    /**
     * @param matnrt the matnrt to set
     */
    public void setMatnrt(String matnrt) {
        this.matnrt = matnrt;
    }
    /**
     * @return the menge
     */
    public BigDecimal getMenge() {
        return menge;
    }
    /**
     * @param menge the menge to set
     */
    public void setMenge(BigDecimal menge) {
        this.menge = menge;
    }
    /**
     * @return the meins
     */
    public String getMeins() {
        return meins;
    }
    /**
     * @param meins the meins to set
     */
    public void setMeins(String meins) {
        this.meins = meins;
    }
    /**
     * @return the zpslot
     */
    public String getZpslot() {
        return zpslot;
    }
    /**
     * @param zpslot the zpslot to set
     */
    public void setZpslot(String zpslot) {
        this.zpslot = zpslot;
    }
    /**
     * @return the clcodegr1
     */
    public String getClcodegr1() {
        return clcodegr1;
    }
    /**
     * @param clcodegr1 the clcodegr1 to set
     */
    public void setClcodegr1(String clcodegr1) {
        this.clcodegr1 = clcodegr1;
    }
    /**
     * @return the clcodegr1t
     */
    public String getClcodegr1t() {
        return clcodegr1t;
    }
    /**
     * @param clcodegr1t the clcodegr1t to set
     */
    public void setClcodegr1t(String clcodegr1t) {
        this.clcodegr1t = clcodegr1t;
    }
    /**
     * @return the zdeldate
     */
    public Date getZdeldate() {
        return zdeldate;
    }
    /**
     * @param zdeldate the zdeldate to set
     */
    public void setZdeldate(Date zdeldate) {
        this.zdeldate = zdeldate;
    }
    /**
     * @return the zdelid
     */
    public String getZdelid() {
        return zdelid;
    }
    /**
     * @param zdelid the zdelid to set
     */
    public void setZdelid(String zdelid) {
        this.zdelid = zdelid;
    }
    /**
     * @return the zdelidt
     */
    public String getZdelidt() {
        return zdelidt;
    }
    /**
     * @param zdelidt the zdelidt to set
     */
    public void setZdelidt(String zdelidt) {
        this.zdelidt = zdelidt;
    }
    /**
     * @return the zreqdate
     */
    public Date getZreqdate() {
        return zreqdate;
    }
    /**
     * @param zreqdate the zreqdate to set
     */
    public void setZreqdate(Date zreqdate) {
        this.zreqdate = zreqdate;
    }
    /**
     * @return the zreqid
     */
    public String getZreqid() {
        return zreqid;
    }
    /**
     * @param zreqid the zreqid to set
     */
    public void setZreqid(String zreqid) {
        this.zreqid = zreqid;
    }
    /**
     * @return the zreqidt
     */
    public String getZreqidt() {
        return zreqidt;
    }
    /**
     * @param zreqidt the zreqidt to set
     */
    public void setZreqidt(String zreqidt) {
        this.zreqidt = zreqidt;
    }
    /**
     * @return the zsmbdate
     */
    public Date getZsmbdate() {
        return zsmbdate;
    }
    /**
     * @param zsmbdate the zsmbdate to set
     */
    public void setZsmbdate(Date zsmbdate) {
        this.zsmbdate = zsmbdate;
    }
    /**
     * @return the zsmbid
     */
    public String getZsmbid() {
        return zsmbid;
    }
    /**
     * @param zsmbid the zsmbid to set
     */
    public void setZsmbid(String zsmbid) {
        this.zsmbid = zsmbid;
    }
    /**
     * @return the zsmbidt
     */
    public String getZsmbidt() {
        return zsmbidt;
    }
    /**
     * @param zsmbidt the zsmbidt to set
     */
    public void setZsmbidt(String zsmbidt) {
        this.zsmbidt = zsmbidt;
    }
    /**
     * @return the zreqdetail
     */
    public String getZreqdetail() {
        return zreqdetail;
    }
    /**
     * @param zreqdetail the zreqdetail to set
     */
    public void setZreqdetail(String zreqdetail) {
        this.zreqdetail = zreqdetail;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the fileSeqnoOk
     */
    public String getFileSeqnoOk() {
        return fileSeqnoOk;
    }
    /**
     * @param fileSeqnoOk the fileSeqnoOk to set
     */
    public void setFileSeqnoOk(String fileSeqnoOk) {
        this.fileSeqnoOk = fileSeqnoOk;
    }
    /**
     * @return the refNoOk
     */
    public String getRefNoOk() {
        return refNoOk;
    }
    /**
     * @param refNoOk the refNoOk to set
     */
    public void setRefNoOk(String refNoOk) {
        this.refNoOk = refNoOk;
    }
    /**
     * @return the filetOk
     */
    public String getFiletOk() {
        return filetOk;
    }
    /**
     * @param filetOk the filetOk to set
     */
    public void setFiletOk(String filetOk) {
        this.filetOk = filetOk;
    }
    /**
     * @return the fileSeqnoNg
     */
    public String getFileSeqnoNg() {
        return fileSeqnoNg;
    }
    /**
     * @param fileSeqnoNg the fileSeqnoNg to set
     */
    public void setFileSeqnoNg(String fileSeqnoNg) {
        this.fileSeqnoNg = fileSeqnoNg;
    }
    /**
     * @return the refNoNg
     */
    public String getRefNoNg() {
        return refNoNg;
    }
    /**
     * @param refNoNg the refNoNg to set
     */
    public void setRefNoNg(String refNoNg) {
        this.refNoNg = refNoNg;
    }
    /**
     * @return the filetDefect
     */
    public String getFiletDefect() {
        return filetDefect;
    }
    /**
     * @param filetDefect the filetDefect to set
     */
    public void setFiletDefect(String filetDefect) {
        this.filetDefect = filetDefect;
    }
    /**
     * @return the fileSeqnoLabel
     */
    public String getFileSeqnoLabel() {
        return fileSeqnoLabel;
    }
    /**
     * @param fileSeqnoLabel the fileSeqnoLabel to set
     */
    public void setFileSeqnoLabel(String fileSeqnoLabel) {
        this.fileSeqnoLabel = fileSeqnoLabel;
    }
    /**
     * @return the refNoLabel
     */
    public String getRefNoLabel() {
        return refNoLabel;
    }
    /**
     * @param refNoLabel the refNoLabel to set
     */
    public void setRefNoLabel(String refNoLabel) {
        this.refNoLabel = refNoLabel;
    }
    /**
     * @return the filetLabel
     */
    public String getFiletLabel() {
        return filetLabel;
    }
    /**
     * @param filetLabel the filetLabel to set
     */
    public void setFiletLabel(String filetLabel) {
        this.filetLabel = filetLabel;
    }
    /**
     * @return the fileSeqnoEtc1
     */
    public String getFileSeqnoEtc1() {
        return fileSeqnoEtc1;
    }
    /**
     * @param fileSeqnoEtc1 the fileSeqnoEtc1 to set
     */
    public void setFileSeqnoEtc1(String fileSeqnoEtc1) {
        this.fileSeqnoEtc1 = fileSeqnoEtc1;
    }
    /**
     * @return the refNoEtc1
     */
    public String getRefNoEtc1() {
        return refNoEtc1;
    }
    /**
     * @param refNoEtc1 the refNoEtc1 to set
     */
    public void setRefNoEtc1(String refNoEtc1) {
        this.refNoEtc1 = refNoEtc1;
    }
    /**
     * @return the filetEtc1
     */
    public String getFiletEtc1() {
        return filetEtc1;
    }
    /**
     * @param filetEtc1 the filetEtc1 to set
     */
    public void setFiletEtc1(String filetEtc1) {
        this.filetEtc1 = filetEtc1;
    }
    /**
     * @return the fileSeqnoEtc2
     */
    public String getFileSeqnoEtc2() {
        return fileSeqnoEtc2;
    }
    /**
     * @param fileSeqnoEtc2 the fileSeqnoEtc2 to set
     */
    public void setFileSeqnoEtc2(String fileSeqnoEtc2) {
        this.fileSeqnoEtc2 = fileSeqnoEtc2;
    }
    /**
     * @return the refNoEtc2
     */
    public String getRefNoEtc2() {
        return refNoEtc2;
    }
    /**
     * @param refNoEtc2 the refNoEtc2 to set
     */
    public void setRefNoEtc2(String refNoEtc2) {
        this.refNoEtc2 = refNoEtc2;
    }
    /**
     * @return the filetEtc2
     */
    public String getFiletEtc2() {
        return filetEtc2;
    }
    /**
     * @param filetEtc2 the filetEtc2 to set
     */
    public void setFiletEtc2(String filetEtc2) {
        this.filetEtc2 = filetEtc2;
    }
    /**
     * @return the fileSeqnoEtc3
     */
    public String getFileSeqnoEtc3() {
        return fileSeqnoEtc3;
    }
    /**
     * @param fileSeqnoEtc3 the fileSeqnoEtc3 to set
     */
    public void setFileSeqnoEtc3(String fileSeqnoEtc3) {
        this.fileSeqnoEtc3 = fileSeqnoEtc3;
    }
    /**
     * @return the refNoEtc3
     */
    public String getRefNoEtc3() {
        return refNoEtc3;
    }
    /**
     * @param refNoEtc3 the refNoEtc3 to set
     */
    public void setRefNoEtc3(String refNoEtc3) {
        this.refNoEtc3 = refNoEtc3;
    }
    /**
     * @return the filetEtc3
     */
    public String getFiletEtc3() {
        return filetEtc3;
    }
    /**
     * @param filetEtc3 the filetEtc3 to set
     */
    public void setFiletEtc3(String filetEtc3) {
        this.filetEtc3 = filetEtc3;
    }
    /**
     * @return the zrcvdate
     */
    public Date getZrcvdate() {
        return zrcvdate;
    }
    /**
     * @param zrcvdate the zrcvdate to set
     */
    public void setZrcvdate(Date zrcvdate) {
        this.zrcvdate = zrcvdate;
    }
    /**
     * @return the zrcvid
     */
    public String getZrcvid() {
        return zrcvid;
    }
    /**
     * @param zrcvid the zrcvid to set
     */
    public void setZrcvid(String zrcvid) {
        this.zrcvid = zrcvid;
    }
    /**
     * @return the zrcvidt
     */
    public String getZrcvidt() {
        return zrcvidt;
    }
    /**
     * @param zrcvidt the zrcvidt to set
     */
    public void setZrcvidt(String zrcvidt) {
        this.zrcvidt = zrcvidt;
    }
    /**
     * @return the zrcndate
     */
    public Date getZrcndate() {
        return zrcndate;
    }
    /**
     * @param zrcndate the zrcndate to set
     */
    public void setZrcndate(Date zrcndate) {
        this.zrcndate = zrcndate;
    }
    /**
     * @return the zrcnid
     */
    public String getZrcnid() {
        return zrcnid;
    }
    /**
     * @param zrcnid the zrcnid to set
     */
    public void setZrcnid(String zrcnid) {
        this.zrcnid = zrcnid;
    }
    /**
     * @return the zrcnidt
     */
    public String getZrcnidt() {
        return zrcnidt;
    }
    /**
     * @param zrcnidt the zrcnidt to set
     */
    public void setZrcnidt(String zrcnidt) {
        this.zrcnidt = zrcnidt;
    }
    /**
     * @return the zrcnrsn
     */
    public String getZrcnrsn() {
        return zrcnrsn;
    }
    /**
     * @param zrcnrsn the zrcnrsn to set
     */
    public void setZrcnrsn(String zrcnrsn) {
        this.zrcnrsn = zrcnrsn;
    }
    /**
     * @return the zprccode
     */
    public String getZprccode() {
        return zprccode;
    }
    /**
     * @param zprccode the zprccode to set
     */
    public void setZprccode(String zprccode) {
        this.zprccode = zprccode;
    }
    /**
     * @return the zprccodet
     */
    public String getZprccodet() {
        return zprccodet;
    }
    /**
     * @param zprccodet the zprccodet to set
     */
    public void setZprccodet(String zprccodet) {
        this.zprccodet = zprccodet;
    }
    /**
     * @return the zrsplifnr
     */
    public String getZrsplifnr() {
        return zrsplifnr;
    }
    /**
     * @param zrsplifnr the zrsplifnr to set
     */
    public void setZrsplifnr(String zrsplifnr) {
        this.zrsplifnr = zrsplifnr;
    }
    /**
     * @return the zrsplifnrt
     */
    public String getZrsplifnrt() {
        return zrsplifnrt;
    }
    /**
     * @param zrsplifnrt the zrsplifnrt to set
     */
    public void setZrsplifnrt(String zrsplifnrt) {
        this.zrsplifnrt = zrsplifnrt;
    }
    /**
     * @return the zncrno
     */
    public String getZncrno() {
        return zncrno;
    }
    /**
     * @param zncrno the zncrno to set
     */
    public void setZncrno(String zncrno) {
        this.zncrno = zncrno;
    }
    /**
     * @return the clcode2
     */
    public String getClcode2() {
        return clcode2;
    }
    /**
     * @param clcode2 the clcode2 to set
     */
    public void setClcode2(String clcode2) {
        this.clcode2 = clcode2;
    }
    /**
     * @return the clcode2t
     */
    public String getClcode2t() {
        return clcode2t;
    }
    /**
     * @param clcode2t the clcode2t to set
     */
    public void setClcode2t(String clcode2t) {
        this.clcode2t = clcode2t;
    }
    /**
     * @return the zprcdate
     */
    public Date getZprcdate() {
        return zprcdate;
    }
    /**
     * @param zprcdate the zprcdate to set
     */
    public void setZprcdate(Date zprcdate) {
        this.zprcdate = zprcdate;
    }
    /**
     * @return the zprcid
     */
    public String getZprcid() {
        return zprcid;
    }
    /**
     * @param zprcid the zprcid to set
     */
    public void setZprcid(String zprcid) {
        this.zprcid = zprcid;
    }
    /**
     * @return the zprcidt
     */
    public String getZprcidt() {
        return zprcidt;
    }
    /**
     * @param zprcidt the zprcidt to set
     */
    public void setZprcidt(String zprcidt) {
        this.zprcidt = zprcidt;
    }
    /**
     * @return the zprcopn
     */
    public String getZprcopn() {
        return zprcopn;
    }
    /**
     * @param zprcopn the zprcopn to set
     */
    public void setZprcopn(String zprcopn) {
        this.zprcopn = zprcopn;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public BigDecimal getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(BigDecimal msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the zreqidmail
     */
    public String getZreqidmail() {
        return zreqidmail;
    }
    /**
     * @param zreqidmail the zreqidmail to set
     */
    public void setZreqidmail(String zreqidmail) {
        this.zreqidmail = zreqidmail;
    }
    /**
     * @return the zsmbidmail
     */
    public String getZsmbidmail() {
        return zsmbidmail;
    }
    /**
     * @param zsmbidmail the zsmbidmail to set
     */
    public void setZsmbidmail(String zsmbidmail) {
        this.zsmbidmail = zsmbidmail;
    }
}
