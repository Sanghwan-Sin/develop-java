package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.PromotionListVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionListService.java
 * @Description : ZJSDR20120 Promotion List
 * @author 이수지
 * @since 2020. 3. 11
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 11       이수지      	        최초 생성
 * </pre>
 */

public interface PromotionListService {

    /**
     * Promotion List
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<PromotionListVO> selectPromotionList (LoginInfoVO loginVo, PromotionListVO params) throws Exception;
}
