package com.mobis.maps.nmgn.sd.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.nmgn.cc.vo.NewsLetterVO;
import com.mobis.maps.nmgn.sd.vo.ListPriceRqstVO;
import com.mobis.maps.nmgn.sd.vo.PartInfoVO;
import com.mobis.maps.nmgn.sd.vo.PriceRqstDetailVO;
import com.mobis.maps.nmgn.sd.vo.RqstNoVO;
import com.mobis.maps.nmgn.sd.vo.ZsacutmVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmpListPriceRqstService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 9. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 9. 26.     Jiyongdo     	최초 생성
 * </pre>
 */

public interface ListPriceRqstService {

    /**
     * LIST PRICE REQUEST 조회
     *
     * @param paramVO
     * @return
     */
    List<ListPriceRqstVO> selectPriceRequestList(ListPriceRqstVO paramVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 소속대리점 정보 조회
     *
     * @param paramVO
     * @return
     */
    List<ZsacutmVO> selectZsacutm(ZsacutmVO paramVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * 부품정보 조회
     *
     * @param paramVO
     * @return
     */
    List<PartInfoVO> selectMaktx(PartInfoVO paramVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * reqno 조회
     *
     * @param paramVO
     * @return
     */
    List<RqstNoVO> selectReqNo(RqstNoVO paramVO, LoginInfoVO loginInfo) throws Exception;    
    
    /**
     * LIST PRICE REQUEST 저장
     *
     * @param paramVO
     * @param paramList
     */
    public Map<String, Object> multiListPriceRequest(ListPriceRqstVO paramVO, List<ListPriceRqstVO> paramList, LoginInfoVO loginInfo) throws Exception;

    /**
     * LIST PRICE REQUEST DETAIL 조회
     *
     * @param paramVO
     * @return
     */
    List<PriceRqstDetailVO> selectPriceRequestDetailList(PriceRqstDetailVO paramVO, LoginInfoVO loginInfo) throws Exception;

    /**
     * LIST PRICE REQUEST DETAIL 저장
     *
     * @param paramVO
     * @param paramList
     * @return
     */
    public Map<String, Object> multiPriceRequestDetail(PriceRqstDetailVO paramVO, List<PriceRqstDetailVO> paramList, LoginInfoVO loginInfo) throws Exception;

    /**
     * Statements
     *
     * @param atchFileVO
     * @param atchFiles
     * @return
     */
    int multiAtchFile(NewsLetterVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception;

    /**
     * Statements
     *
     * @param paramVO
     * @param paramList
     * @param loginInfo
     * @return
     */
    List<ListPriceRqstVO> selectMaktxMulti(PartInfoVO paramVO, List<ListPriceRqstVO> paramList, LoginInfoVO loginInfo) throws Exception;
}
