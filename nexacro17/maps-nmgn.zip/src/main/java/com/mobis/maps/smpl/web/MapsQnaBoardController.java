package com.mobis.maps.smpl.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.smpl.service.MapsQnaBoardService;
import com.mobis.maps.smpl.vo.MapsQnaBoardVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsQnaBoardController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048105
 * @since 2020. 4. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 7.     DT048105     	최초 생성
 * </pre>
 */

@Controller
public class MapsQnaBoardController extends HController{
    @Resource(name = "mapsQnaBoardService")
    private MapsQnaBoardService mapsQnaBoardService;
    
    @RequestMapping(value = "/smpl/selectQnaBoardList.do")
    public NexacroResult selectQnaBoardList(@ParamDataSet(name="dsInput") MapsQnaBoardVO inputVO
                                           , NexacroResult result) throws Exception {
        List<MapsQnaBoardVO> resultVo = mapsQnaBoardService.selectQnaBoardList(inputVO);

        result.addDataSet("dsOutput", resultVo);

        return result;
    }    
    
    @RequestMapping(value = "/smpl/selectQnaBoardNewList.do")
    public NexacroResult selectQnaBoardNewList(@ParamDataSet(name="dsInput") MapsQnaBoardVO inputVO
                                              , NexacroResult result) throws Exception {
        MapsQnaBoardVO resultVo = mapsQnaBoardService.selectQnaBoardNewList(inputVO);

        result.addDataSet("dsOutput", resultVo);

        return result;
    }     
    
    @RequestMapping(value = "/smpl/updateQnaBoardCount.do")
    public NexacroResult updateQnaBoardCount(@ParamDataSet(name="dsInput") MapsQnaBoardVO inputVO
            , NexacroResult result) throws Exception {
        mapsQnaBoardService.updateQnaBoardCount(inputVO);
        
        result.addVariable("procCnt", 1);
        return result;
    } 
    
    @RequestMapping(value = "/smpl/multiQnaBoard.do")
    public NexacroResult multiQnaBoard(@ParamDataSet(name="dsInput") MapsQnaBoardVO inputVO
                                      , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        inputVO.setRegistId(loginInfo.getUserId());
        inputVO.setUpdtId(loginInfo.getUserId());
        
        MapsQnaBoardVO resultVo = mapsQnaBoardService.multiQnaBoard(inputVO);
        //int cnt = mapsSmplBoardService.multiSmplBoard(inputVO);
        //result.addVariable("procCnt", cnt);
        result.addDataSet("dsOutput", resultVo);

        return result;
    }   
    
    /**
     * 샘플 첨부파일 등록
     *
     * @param DpomManualVO
     * @param atchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/smpl/multiQnaAtchFile.do")
    public NexacroResult multiQnaAtchFile(
            @ParamDataSet(name="dsInput") MapsQnaBoardVO atchFileVO
            , @ParamDataSet(name="dsInputAtchFile") List<MapsAtchFileVO> atchFiles
            , NexacroResult result) throws Exception {
        
        int procCnt = mapsQnaBoardService.multiAtchFile(atchFileVO, atchFiles);

        result.addVariable("procCnt", procCnt);

        return result;
    }        
}
