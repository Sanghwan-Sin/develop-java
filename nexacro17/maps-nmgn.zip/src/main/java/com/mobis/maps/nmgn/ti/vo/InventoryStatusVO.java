package com.mobis.maps.nmgn.ti.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InventoryStatusVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 7. 15.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 15.     jiyongdo     	최초 생성
 * </pre>
 */

public class InventoryStatusVO extends MapsCommSapRfcIfCommVO {
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAREA" )
    private String iZarea;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDISTCD" )
    private String iZdistcd;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;

    //-----[IT_DATA] START-----
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="I|E", fieldKey="ZSEQNO" )
    private Integer zseqno;
    /** Material Number */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="I|E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZLIST_PRICE" )
    private String zlistPrice;
    /** Currency Key */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZQFP" )
    private String zqfp;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZQUP" )
    private String zqup;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZSTKQTY" )
    private String zstkqty;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZWEIG" )
    private String zweig;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZWUNIT" )
    private String zwunit;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZLENG" )
    private String zleng;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZWIDT" )
    private String zwidt;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZHIGH" )
    private String zhigh;
    /** Base Unit of Measure */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZLUNIT" )
    private String zlunit;
    /** General Field with Length 2, for Function Modules */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZCOO" )
    private String zcoo;
    /** HQ SUC */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZSUCCD" )
    private String zsuccd;
    /**  */
    @MapsRfcMappper( targetName="IT_DATA", ipttSe="E", fieldKey="ZHSCD" )
    private String zhscd;
    //-----[IT_DATA] END-----
    /**
     * @return the iZarea
     */
    public String getiZarea() {
        return iZarea;
    }
    /**
     * @param iZarea the iZarea to set
     */
    public void setiZarea(String iZarea) {
        this.iZarea = iZarea;
    }
    /**
     * @return the iZdistcd
     */
    public String getiZdistcd() {
        return iZdistcd;
    }
    /**
     * @param iZdistcd the iZdistcd to set
     */
    public void setiZdistcd(String iZdistcd) {
        this.iZdistcd = iZdistcd;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the zseqno
     */
    public Integer getZseqno() {
        return zseqno;
    }
    /**
     * @param zseqno the zseqno to set
     */
    public void setZseqno(Integer zseqno) {
        this.zseqno = zseqno;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the zlistPrice
     */
    public String getZlistPrice() {
        return zlistPrice;
    }
    /**
     * @param zlistPrice the zlistPrice to set
     */
    public void setZlistPrice(String zlistPrice) {
        this.zlistPrice = zlistPrice;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the zqfp
     */
    public String getZqfp() {
        return zqfp;
    }
    /**
     * @param zqfp the zqfp to set
     */
    public void setZqfp(String zqfp) {
        this.zqfp = zqfp;
    }
    /**
     * @return the zqup
     */
    public String getZqup() {
        return zqup;
    }
    /**
     * @param zqup the zqup to set
     */
    public void setZqup(String zqup) {
        this.zqup = zqup;
    }
    /**
     * @return the zstkqty
     */
    public String getZstkqty() {
        return zstkqty;
    }
    /**
     * @param zstkqty the zstkqty to set
     */
    public void setZstkqty(String zstkqty) {
        this.zstkqty = zstkqty;
    }
    /**
     * @return the zweig
     */
    public String getZweig() {
        return zweig;
    }
    /**
     * @param zweig the zweig to set
     */
    public void setZweig(String zweig) {
        this.zweig = zweig;
    }
    /**
     * @return the zwunit
     */
    public String getZwunit() {
        return zwunit;
    }
    /**
     * @param zwunit the zwunit to set
     */
    public void setZwunit(String zwunit) {
        this.zwunit = zwunit;
    }
    /**
     * @return the zleng
     */
    public String getZleng() {
        return zleng;
    }
    /**
     * @param zleng the zleng to set
     */
    public void setZleng(String zleng) {
        this.zleng = zleng;
    }
    /**
     * @return the zwidt
     */
    public String getZwidt() {
        return zwidt;
    }
    /**
     * @param zwidt the zwidt to set
     */
    public void setZwidt(String zwidt) {
        this.zwidt = zwidt;
    }
    /**
     * @return the zhigh
     */
    public String getZhigh() {
        return zhigh;
    }
    /**
     * @param zhigh the zhigh to set
     */
    public void setZhigh(String zhigh) {
        this.zhigh = zhigh;
    }
    /**
     * @return the zlunit
     */
    public String getZlunit() {
        return zlunit;
    }
    /**
     * @param zlunit the zlunit to set
     */
    public void setZlunit(String zlunit) {
        this.zlunit = zlunit;
    }
    /**
     * @return the zcoo
     */
    public String getZcoo() {
        return zcoo;
    }
    /**
     * @param zcoo the zcoo to set
     */
    public void setZcoo(String zcoo) {
        this.zcoo = zcoo;
    }
    /**
     * @return the zsuccd
     */
    public String getZsuccd() {
        return zsuccd;
    }
    /**
     * @param zsuccd the zsuccd to set
     */
    public void setZsuccd(String zsuccd) {
        this.zsuccd = zsuccd;
    }
    /**
     * @return the zhscd
     */
    public String getZhscd() {
        return zhscd;
    }
    /**
     * @param zhscd the zhscd to set
     */
    public void setZhscd(String zhscd) {
        this.zhscd = zhscd;
    }
    
}
