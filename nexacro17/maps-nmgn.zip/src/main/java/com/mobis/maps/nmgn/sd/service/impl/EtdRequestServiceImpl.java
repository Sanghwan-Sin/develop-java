package com.mobis.maps.nmgn.sd.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.util.MessageUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.EtdRequestService;
import com.mobis.maps.nmgn.sd.vo.EtdRequestChkVO;
import com.mobis.maps.nmgn.sd.vo.EtdRequestDetailVO;
import com.mobis.maps.nmgn.sd.vo.EtdRequestVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : EtdRequestServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 6. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 8.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("etdRequestService")
public class EtdRequestServiceImpl extends HService implements EtdRequestService{
    @Resource(name = "mapsCmmnSapService")  
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.sd.service.EtdRequestService#selectEtdRequesList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.EtdRequestVO)
     */
    @Override
    public Map<String, Object> selectEtdRequesList(LoginInfoVO loginInfo, EtdRequestVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ETD_REQUEST_LIST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<EtdRequestVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_HEAD", paramVO, EtdRequestVO.class);
        retMap.put("head", odrLst);      
        /* RFC 호출 조회정보 추출 */
        List<EtdRequestVO> itmLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_ITEM", paramVO, EtdRequestVO.class);
        retMap.put("body", itmLst);           
        
        return retMap;     
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.EtdRequestService#selectEtdRequesDetailList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.EtdRequestDetailVO)
     */
    @Override
    public Map<String, Object> selectEtdRequesDetailList(LoginInfoVO loginInfo, EtdRequestDetailVO paramVO) throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ETD_REQUEST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<EtdRequestDetailVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_HEAD", paramVO, EtdRequestDetailVO.class);
        retMap.put("head", odrLst);       
        /* RFC 호출 조회정보 추출 */
        List<EtdRequestDetailVO> itmLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_ITEM", paramVO, EtdRequestDetailVO.class);
        
        List<EtdRequestDetailVO> itmLstFormat = new ArrayList<EtdRequestDetailVO>();
        EtdRequestDetailVO nullVo = new EtdRequestDetailVO();
        nullVo.setRowSe("I");
        for(int row = 0; row < 25; row++){
            if(row < itmLst.size()){
                itmLstFormat.add(itmLst.get(row));
            }else{
                itmLstFormat.add(nullVo);
            }
        }
        
        retMap.put("body", itmLstFormat);          
        
        return retMap; 
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.EtdRequestService#multiEtdRequesDetail(com.mobis.maps.nmgn.sd.vo.EtdRequestDetailVO, com.mobis.maps.nmgn.sd.vo.EtdRequestDetailVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public Map<String, Object> multiEtdRequesDetail(EtdRequestDetailVO paramVO, EtdRequestDetailVO param,
            List<EtdRequestDetailVO> paramList, LoginInfoVO loginInfo) throws Exception {
        Map<String, Object>    retMap  = new HashMap<String, Object>();
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ETD_REQUEST;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);    
        
        // 파라미터(TABLES) 적재
        MapsRfcMappperUtil.appendImportTableRow(func, "IT_HEAD", param);
        
        // 파라미터(TABLES) 적재
        for(EtdRequestDetailVO tmpVO : paramList) {
            if ("F".equals(tmpVO.getChkCode()) || // Shipped
                "C".equals(tmpVO.getChkCode()) || // Cancelled
                "S".equals(tmpVO.getChkCode()) || // P/N Changed
                "W".equals(tmpVO.getChkCode()) || // Wrong Info
//                "X".equals(tmpVO.getChkCode()) || // Wrong Info(Accessory)
                "D".equals(tmpVO.getChkCode()) || // Duplicated
                "N".equals(tmpVO.getChkCode()) || // Order Not Confirmed
                "P".equals(tmpVO.getChkCode()))   // Etd Privided
            {
                continue;
            }
         
            if (StringUtils.isBlank(tmpVO.getZordnoE())) {
                continue;
            }

            if (StringUtils.isBlank(tmpVO.getZordln())) {
                continue;
            }

            if (StringUtils.isBlank(tmpVO.getMatnr())) {
                continue;
            }
            
            switch (tmpVO.getRowSe()) {
                case "I":
                    tmpVO.setType("C");
                    break;
                case "N":
                case "U":
                    tmpVO.setType("U");
                    break;
                case "D":
                    tmpVO.setType("D");
                    break;
                default:
                    break;
            }
            
            MapsRfcMappperUtil.appendImportTableRow(func, "IT_ITEM", tmpVO);
            
        }   // END-FOR        
        
        // RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);

        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        List<EtdRequestDetailVO> odrLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_HEAD", paramVO, EtdRequestDetailVO.class);
        if("E".equals(paramVO.getMsgType())){
          retMap.put("head", odrLst);       
          /* RFC 호출 조회정보 추출 */
          List<EtdRequestDetailVO> itmLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_ITEM", paramVO, EtdRequestDetailVO.class);
          List<EtdRequestDetailVO> itmLstFormat = new ArrayList<EtdRequestDetailVO>();
          EtdRequestDetailVO nullVo = new EtdRequestDetailVO();
          nullVo.setRowSe("I");
          for(int row = 0; row < 25; row++){
              if(row < itmLst.size()){
                  itmLstFormat.add(itmLst.get(row));
              }else{
                  itmLstFormat.add(nullVo);
              }
          }        
          retMap.put("body", itmLstFormat);
        }else{
        
            paramVO.setiType("R");
            paramVO.setiZdocNum(odrLst.get(0).getZdocNum());
            retMap = selectEtdRequesDetailList(loginInfo, paramVO);
        
        }
        return retMap;
    }


    /*
     * @see com.mobis.maps.nmgn.sd.service.EtdRequestService#selectEtdRechkRtn(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.EtdRequestChkVO, java.util.List)
     */
    @Override
    public List<EtdRequestDetailVO> selectEtdRechkRtn(LoginInfoVO loginInfo, EtdRequestChkVO chkVo,
            List<EtdRequestDetailVO> itemLst) throws Exception {
        StringBuffer sBuf = new StringBuffer();
        
        
        if (itemLst == null || itemLst.size() <= 0) {
            if (logger.isDebugEnabled()) logger.debug("##### No items to Check. End.");
            return null;
        }
        
        chkVo.setiType("R");
//        chkVo.setiZsacutm(); // client 에서 세팅
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ETD_VALIDATE;
        chkVo.setIfCode(sapRfcInfo.getIfCode());
        
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, chkVo);


        for(int idx = 0; idx < itemLst.size(); idx++) {
            EtdRequestDetailVO itemVo = itemLst.get(idx);

            sBuf.delete(0, sBuf.length());sBuf.setLength(0);
            
            if ("N".equals(itemVo.getRowSe()) || "D".equals(itemVo.getRowSe())) {
                continue;
            
            } else if ("O".equals(itemVo.getChkCode())) {
                continue;

            } else if (StringUtils.isBlank(itemVo.getZordnoE())
                    && StringUtils.isBlank(itemVo.getZordln())
                    && StringUtils.isBlank(itemVo.getMatnr())) {
                continue;
            }
            
            if (StringUtils.isBlank(itemVo.getZordnoE())) {sBuf.append("'Order No' ");}
            if (StringUtils.isBlank(itemVo.getZordln())) {sBuf.append("'Line' ");}
            if (StringUtils.isBlank(itemVo.getMatnr())) {sBuf.append("'Part No' ");}
            
            if (sBuf.length() > 0) {
                String msg = MessageUtil.getMessage("EC00000001", new String[]{sBuf.toString().trim()}, loginInfo.getUserLcale());
                
                itemVo.setChkCode("W");
                itemVo.setChkDesc(msg);
                
                continue;
            }

            
            chkVo.setiZordnoE(itemVo.getZordnoE());
            chkVo.setiZordln(itemVo.getZordln());
            chkVo.setiZordls(itemVo.getZordls());
            chkVo.setiMatnr(itemVo.getMatnr());
            
            // 파라미터(Import) 셋팅
            MapsRfcMappperUtil.setImportParamList(func, chkVo);
            
            /* RFC 호출 */
            FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
            
            // RFC 호출 공통결과 정보 추출
            mapsCmmnSapService.selectSetRfcResult(funcRslt, chkVo);
            
            
            if ("E".equals(chkVo.getMsgType())) {
                itemVo.setChkCode(chkVo.getMsgType());
                itemVo.setChkDesc(chkVo.getMsg());
                
                continue;
            }
            
            /* RFC 호출 조회정보 추출 */
            List<EtdRequestChkVO> itmLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_DATA", chkVo, EtdRequestChkVO.class);
            
            if (itemLst == null || itemLst.size() <= 0) {
                if (logger.isDebugEnabled()) logger.debug("##### [" + idx + "] no IT_DATA return.");
                continue;
            }
            
            itemVo.setZboqty(toBigDecimal(itmLst.get(0).getZboqty()));
            itemVo.setChkCode(itmLst.get(0).getZcode());
            itemVo.setChkDesc(itmLst.get(0).getZdesc());
            itemVo.setZinEtdOri(itmLst.get(0).getZetdBo());
            itemVo.setZinQtyOri(toBigDecimal(itmLst.get(0).getZetdQtBo()));
            itemVo.setZboEtdOri(itmLst.get(0).getZetdIv());
            itemVo.setZboQtyOri(toBigDecimal(itmLst.get(0).getZetdQtIv()));
        }
        
        
        
        return itemLst; 
    }
    
    
    /**
     * Statements
     *
     * @param val
     * @return
     * @throws Exception
     */
    private BigDecimal toBigDecimal(String val) throws Exception {
        if (StringUtils.isBlank(val)) {
            return null;
        }
        
        String valTmp = val.replaceAll("[^0-9.\\-]", "");
        
        return new BigDecimal(valTmp);
    }
    
}
