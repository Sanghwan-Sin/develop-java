package com.mobis.maps.nmgn.main.service;

import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.vo.MapsOrderSummaryVO;
import com.mobis.maps.nmgn.main.vo.MobisDefaultMainVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MobisDefaultMainService.java
 * @Description : Main Service
 * @author jiyongdo
 * @since 2020. 8. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 14.     jiyongdo     	최초 생성
 * </pre>
 */

public interface MobisDefaultMainService {

    /**
     * selectMainPaymentDueOrderList
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectMainPaymentDueOrderList(LoginInfoVO loginInfo, MobisDefaultMainVO paramVO) throws Exception;

    /**
     * selectMainStatementofBalance
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectMainStatementofBalance(LoginInfoVO loginInfo, MobisDefaultMainVO paramVO) throws Exception;
    
    
    /**
     * Main
     * - Order Processing Summary
     * - Order Status Summary
     * - Order Unprocessed List
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws Exception
     */
    MapsOrderSummaryVO selectOrderProcessSummary(LoginInfoVO loginInfo, MapsOrderSummaryVO params) throws Exception;

}
