package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoicePackingVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 2. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 7.     jiyongdo     	최초 생성
 * </pre>
 */

public class InvoicePackingVO extends MapsCommSapRfcIfCommVO{
    private String invoiceNo;
    /** Invoice No. */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /**  */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SEQ" )
    private Integer seq;
    /** Container NO. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CONTAINER_NO" )
    private String containerNo;
    /** Carton Box Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CASE_NO" )
    private String caseNo;
    /** 오더번호 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="ORDER" )
    private String order;
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LINE_ITEM" )
    private String lineItem;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PART_NO" )
    private String partNo;
    /** 설계부품명칭 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PART_NAME" )
    private String partName;
    /** 국가 키 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CO_CNTY" )
    private String coCnty;
    /** 순 중량 */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SHIP_QTY" )
    private BigDecimal shipQty;
    
    /**
     * @return the invoiceNo
     */
    public String getInvoiceNo() {
        return invoiceNo;
    }

    /**
     * @param invoiceNo the invoiceNo to set
     */
    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }

    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }

    /**
     * @return the seq
     */
    public Integer getSeq() {
        return seq;
    }

    /**
     * @param seq the seq to set
     */
    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    /**
     * @return the containerNo
     */
    public String getContainerNo() {
        return containerNo;
    }

    /**
     * @param containerNo the containerNo to set
     */
    public void setContainerNo(String containerNo) {
        this.containerNo = containerNo;
    }

    /**
     * @return the caseNo
     */
    public String getCaseNo() {
        return caseNo;
    }

    /**
     * @param caseNo the caseNo to set
     */
    public void setCaseNo(String caseNo) {
        this.caseNo = caseNo;
    }

    /**
     * @return the order
     */
    public String getOrder() {
        return order;
    }

    /**
     * @param order the order to set
     */
    public void setOrder(String order) {
        this.order = order;
    }

    /**
     * @return the lineItem
     */
    public String getLineItem() {
        return lineItem;
    }

    /**
     * @param lineItem the lineItem to set
     */
    public void setLineItem(String lineItem) {
        this.lineItem = lineItem;
    }

    /**
     * @return the partNo
     */
    public String getPartNo() {
        return partNo;
    }

    /**
     * @param partNo the partNo to set
     */
    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }

    /**
     * @return the partName
     */
    public String getPartName() {
        return partName;
    }

    /**
     * @param partName the partName to set
     */
    public void setPartName(String partName) {
        this.partName = partName;
    }

    /**
     * @return the coCnty
     */
    public String getCoCnty() {
        return coCnty;
    }

    /**
     * @param coCnty the coCnty to set
     */
    public void setCoCnty(String coCnty) {
        this.coCnty = coCnty;
    }

    /**
     * @return the shipQty
     */
    public BigDecimal getShipQty() {
        return shipQty;
    }

    /**
     * @param shipQty the shipQty to set
     */
    public void setShipQty(BigDecimal shipQty) {
        this.shipQty = shipQty;
    }
}
