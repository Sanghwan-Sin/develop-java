package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartTransactionStatusVO.java
 * @Description : ZPSD_NMGN_R_ORDER_PART_STATUS
 * @author 이수지
 * @since 2020. 11. 25.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 11. 25.    이수지     	     최초 생성
 * </pre>
 */

public class PartTransactionStatusVO extends MapsCommSapRfcIfCommVO {

    /** 자재 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PARTNO" )
    private String iPartno;
    /** C:Create, U:Change, R:Display */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 최초부품코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZMATNR_INPUT" )
    private String iZmatnrInput;
    /** ORDERED DATE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_FR" )
    private Date iZorddtFr;
    /** ORDERED DATE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_TO" )
    private Date iZorddtTo;
    /** 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_E" )
    private String iZordnoE;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    /** History Data Included */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_HISTORY" )
    private String iHistory;

    /** -----[T_RESULT] START----- */
    
    /** Order Line Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDLN" )
    private String zordln;
    /** Order Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /** 최초부품코드 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMATNR_INPUT" )
    private String zmatnrInput;
    /** Material Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMATNR_SHIP" )
    private String zmatnrShip;
    /** Material description */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** Pieces Ordered */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDQTY" )
    private String zordqty;
    /** ieces Confirmed */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCFMQTY" )
    private String zcfmqty;
    /** Processing B/O */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZBOQTY" )
    private String zboqty;
    /** Current Qty */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCURQTY" )
    private String zcurqty;
    /** Processing Alloc. */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZALOQTY" )
    private String zaloqty;
    /** Processing Shipped */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSHPQTY" )
    private String zshpqty;
    /** Carton Box Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFCARTNO" )
    private String zfcartno;
    /** Invoice No. */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFCIVNO" )
    private String zfcivno;
    /** Shipmode */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFSHPMD" )
    private String zfshpmd;
    /** On Board Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFOBDT" )
    private Date zfobdt;
    /** Vessel Name */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFCARNM" )
    private String zfcarnm;
    /** Master B/L No. */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFMBLNO" )
    private String zfmblno;
    /** Container# */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFCNTRNO" )
    private String zfcntrno;
    /** Single-Character Flag */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="HISTORY" )
    private String history;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDLS" )
    private String zordls;
    
    /** -----[T_RESULT] END----- */
    
    
    /**
     * @return the iPartno
     */
    public String getiPartno() {
        return iPartno;
    }
    /**
     * @param iPartno the iPartno to set
     */
    public void setiPartno(String iPartno) {
        this.iPartno = iPartno;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZmatnrInput
     */
    public String getiZmatnrInput() {
        return iZmatnrInput;
    }
    /**
     * @param iZmatnrInput the iZmatnrInput to set
     */
    public void setiZmatnrInput(String iZmatnrInput) {
        this.iZmatnrInput = iZmatnrInput;
    }
    /**
     * @return the iZorddtFr
     */
    public Date getiZorddtFr() {
        return iZorddtFr;
    }
    /**
     * @param iZorddtFr the iZorddtFr to set
     */
    public void setiZorddtFr(Date iZorddtFr) {
        this.iZorddtFr = iZorddtFr;
    }
    /**
     * @return the iZorddtTo
     */
    public Date getiZorddtTo() {
        return iZorddtTo;
    }
    /**
     * @param iZorddtTo the iZorddtTo to set
     */
    public void setiZorddtTo(Date iZorddtTo) {
        this.iZorddtTo = iZorddtTo;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zmatnrInput
     */
    public String getZmatnrInput() {
        return zmatnrInput;
    }
    /**
     * @param zmatnrInput the zmatnrInput to set
     */
    public void setZmatnrInput(String zmatnrInput) {
        this.zmatnrInput = zmatnrInput;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zmatnrShip
     */
    public String getZmatnrShip() {
        return zmatnrShip;
    }
    /**
     * @param zmatnrShip the zmatnrShip to set
     */
    public void setZmatnrShip(String zmatnrShip) {
        this.zmatnrShip = zmatnrShip;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zordqty
     */
    public String getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(String zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zcfmqty
     */
    public String getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(String zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zcurqty
     */
    public String getZcurqty() {
        return zcurqty;
    }
    /**
     * @param zcurqty the zcurqty to set
     */
    public void setZcurqty(String zcurqty) {
        this.zcurqty = zcurqty;
    }
    /**
     * @return the zaloqty
     */
    public String getZaloqty() {
        return zaloqty;
    }
    /**
     * @param zaloqty the zaloqty to set
     */
    public void setZaloqty(String zaloqty) {
        this.zaloqty = zaloqty;
    }
    /**
     * @return the zshpqty
     */
    public String getZshpqty() {
        return zshpqty;
    }
    /**
     * @param zshpqty the zshpqty to set
     */
    public void setZshpqty(String zshpqty) {
        this.zshpqty = zshpqty;
    }
    /**
     * @return the zfcartno
     */
    public String getZfcartno() {
        return zfcartno;
    }
    /**
     * @param zfcartno the zfcartno to set
     */
    public void setZfcartno(String zfcartno) {
        this.zfcartno = zfcartno;
    }
    /**
     * @return the zfcivno
     */
    public String getZfcivno() {
        return zfcivno;
    }
    /**
     * @param zfcivno the zfcivno to set
     */
    public void setZfcivno(String zfcivno) {
        this.zfcivno = zfcivno;
    }
    /**
     * @return the zfshpmd
     */
    public String getZfshpmd() {
        return zfshpmd;
    }
    /**
     * @param zfshpmd the zfshpmd to set
     */
    public void setZfshpmd(String zfshpmd) {
        this.zfshpmd = zfshpmd;
    }
    /**
     * @return the zfobdt
     */
    public Date getZfobdt() {
        return zfobdt;
    }
    /**
     * @param zfobdt the zfobdt to set
     */
    public void setZfobdt(Date zfobdt) {
        this.zfobdt = zfobdt;
    }
    /**
     * @return the zfcarnm
     */
    public String getZfcarnm() {
        return zfcarnm;
    }
    /**
     * @param zfcarnm the zfcarnm to set
     */
    public void setZfcarnm(String zfcarnm) {
        this.zfcarnm = zfcarnm;
    }
    /**
     * @return the zfmblno
     */
    public String getZfmblno() {
        return zfmblno;
    }
    /**
     * @param zfmblno the zfmblno to set
     */
    public void setZfmblno(String zfmblno) {
        this.zfmblno = zfmblno;
    }
    /**
     * @return the zfcntrno
     */
    public String getZfcntrno() {
        return zfcntrno;
    }
    /**
     * @param zfcntrno the zfcntrno to set
     */
    public void setZfcntrno(String zfcntrno) {
        this.zfcntrno = zfcntrno;
    }
    /**
     * @return the history
     */
    public String getHistory() {
        return history;
    }
    /**
     * @param history the history to set
     */
    public void setHistory(String history) {
        this.history = history;
    }
    /**
     * @return the zordls
     */
    public String getZordls() {
        return zordls;
    }
    /**
     * @param zordls the zordls to set
     */
    public void setZordls(String zordls) {
        this.zordls = zordls;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the iHistory
     */
    public String getiHistory() {
        return iHistory;
    }
    /**
     * @param iHistory the iHistory to set
     */
    public void setiHistory(String iHistory) {
        this.iHistory = iHistory;
    }
          
}
