package com.mobis.maps.nmgn.cc.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : TargetTreeVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 4. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 8.     jiyongdo     	최초 생성
 * </pre>
 */

public class TargetTreeVO {
    
    private int rnum;
    /** 체크 */
    private String chkYn;
    /** 레벨 */
    private String lv;
    /** 코드값*/
    private String cd;
    /** 코드명*/
    private String cdDesc;
    /** 코드명*/
    private String gid;
    /** 코드명*/
    private String gidDesc;    
    
    private String spras;    
    private String sysid;    
    private String mandt;    
    
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the chkYn
     */
    public String getChkYn() {
        return chkYn;
    }
    /**
     * @param chkYn the chkYn to set
     */
    public void setChkYn(String chkYn) {
        this.chkYn = chkYn;
    }
    /**
     * @return the lv
     */
    public String getLv() {
        return lv;
    }
    /**
     * @param lv the lv to set
     */
    public void setLv(String lv) {
        this.lv = lv;
    }
    /**
     * @return the cd
     */
    public String getCd() {
        return cd;
    }
    /**
     * @param cd the cd to set
     */
    public void setCd(String cd) {
        this.cd = cd;
    }
    /**
     * @return the cdDesc
     */
    public String getCdDesc() {
        return cdDesc;
    }
    /**
     * @param cdDesc the cdDesc to set
     */
    public void setCdDesc(String cdDesc) {
        this.cdDesc = cdDesc;
    }
    /**
     * @return the gid
     */
    public String getGid() {
        return gid;
    }
    /**
     * @param gid the gid to set
     */
    public void setGid(String gid) {
        this.gid = gid;
    }
    /**
     * @return the gidDesc
     */
    public String getGidDesc() {
        return gidDesc;
    }
    /**
     * @param gidDesc the gidDesc to set
     */
    public void setGidDesc(String gidDesc) {
        this.gidDesc = gidDesc;
    }
    /**
     * @return the spras
     */
    public String getSpras() {
        return spras;
    }
    /**
     * @param spras the spras to set
     */
    public void setSpras(String spras) {
        this.spras = spras;
    }
    /**
     * @return the sysid
     */
    public String getSysid() {
        return sysid;
    }
    /**
     * @param sysid the sysid to set
     */
    public void setSysid(String sysid) {
        this.sysid = sysid;
    }
    /**
     * @return the mandt
     */
    public String getMandt() {
        return mandt;
    }
    /**
     * @param mandt the mandt to set
     */
    public void setMandt(String mandt) {
        this.mandt = mandt;
    }
}
