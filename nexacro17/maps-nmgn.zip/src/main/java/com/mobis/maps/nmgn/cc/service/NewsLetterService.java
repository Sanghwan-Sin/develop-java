package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.vo.MapsCommCodeVO;
import com.mobis.maps.nmgn.cc.vo.NewsLetterVO;
import com.mobis.maps.nmgn.cc.vo.TargetTreeVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : NewsLetterService.java
 * @Description : News Letter
 * @author 이수지
 * @since 2020. 03. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 31.     이수지            	최초 생성
 * </pre>
 */

public interface NewsLetterService {

    /**
     * News Letter 조회
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws Exception
     */
    List<NewsLetterVO> selectNewsLetter(LoginInfoVO loginInfo, NewsLetterVO params) throws Exception;
    
    /**
     * News Letter 상세조회
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws Exception
     */
    List<NewsLetterVO> selectNewsLetterDetail(LoginInfoVO loginInfo, NewsLetterVO params) throws Exception;
    
    /**
     * News Letter 저장
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws Exception
     */
    NewsLetterVO insertNewsLetter(NewsLetterVO params) throws Exception;
        
    /**
     * 첨부파일 등록
     *
     * @param atchFileVO
     * @param atchFiles
     * @return
     */
    int multiAtchFile(NewsLetterVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param commCodeVO 
     * @param params
     * @return
     */
    List<TargetTreeVO> selectTargetTreeList(LoginInfoVO loginInfo, MapsCommCodeVO commCodeVO, TargetTreeVO params) throws Exception;
   
    /**
     * 메일 전송
     *
     * @param loginInfo
     * @param param
     * @throws Exception 
     */
    void insertNewsLetterMailSend(LoginInfoVO loginInfo, List<NewsLetterVO> param) throws Exception;
    
    /**
     * 메일전송 상태 업데이트
     *
     * @param params
     */
    void updateNewsLetteMail(NewsLetterVO params);
}
