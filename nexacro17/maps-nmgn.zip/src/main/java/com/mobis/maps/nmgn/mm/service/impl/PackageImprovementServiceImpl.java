package com.mobis.maps.nmgn.mm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.mm.service.PackageImprovementService;
import com.mobis.maps.nmgn.mm.vo.DuplicationCheckVO;
import com.mobis.maps.nmgn.mm.vo.PackageImproveReqDetailVO;
import com.mobis.maps.nmgn.mm.vo.PackageImproveRequestVO;
import com.mobis.maps.nmgn.mm.vo.PackageImproveSatisfyVO;
import com.mobis.maps.nmgn.mm.vo.PackageImprovementVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingHeaderServiceImpl.java
 * @Description : ZJMMO20100 포장 개선 리스트
 * @author 이수지
 * @since 2020. 3.5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3.5.       이수지      	        최초 생성
 * </pre>
 */

@Service("packageImprovementService")
public class PackageImprovementServiceImpl extends HService implements PackageImprovementService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.ex.service.PackageImprovementService#selectPackageImprovement(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.PackageImprovementVO)
     */
    @Override
    public List<PackageImprovementVO> selectPackageImprovement(LoginInfoVO loginVo, PackageImprovementVO params)
            throws Exception {

        // *** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPMM_NMGN_R_LIST_PI_REQ;

        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        // *** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        // *** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);

        // *** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);

        // *** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);

        // *** 조회결과
        List<PackageImprovementVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_RESULT", params, PackageImprovementVO.class);

        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.mm.service.PackageImprovementService#selectDuplicationCheck(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.mm.service.DuplicationCheckVO)
     */
    @Override
    public void selectDuplicationCheck(LoginInfoVO loginVo, DuplicationCheckVO params) throws Exception {

        // *** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPMM_NMGN_R_DUPCHK_PI_REQ;

        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        // *** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        // *** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);

        // *** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);

        // *** RFC 호출결과 정보 추출
        MapsRfcMappperUtil.setExportParamList(funcRslt, params, loginVo.getUserLcale());
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);

    }
    
    /*
     * @see com.mobis.maps.nmgn.mm.service.PackageImprovementService#selectPackageImproveRequest(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.mm.vo.PackageImproveReqDetailVO)
     */
    @Override
    public Map<String, Object> selectPackageImproveRequest(LoginInfoVO loginVo, PackageImproveReqDetailVO paramVO)
            throws Exception {

        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPMM_NMGN_R_DISPLAY_PI_RST;
        
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, paramVO);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        PackageImproveReqDetailVO rtnVO = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_RESULT", PackageImproveReqDetailVO.class);        
        
        retMap.put("rsltVO", rtnVO);
        
        return retMap;   
    }
    
    /*
     * @see com.mobis.maps.nmgn.mm.service.PackageImprovementService#savePackageImproveRequest(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.mm.vo.PackageImproveRequestVO)
     */
    @Override
    public void multiSavePackageImproveRequest(LoginInfoVO loginVo, PackageImproveRequestVO paramVO)
            throws Exception {

        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPMM_NMGN_R_CREATE_PI_REQ;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportStructure(func, "IS_DATA", paramVO);
        
       
        /* RFC 호출 */
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func, true);
       
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        // *** RFC 호출결과 정보 추출
        MapsRfcMappperUtil.setExportParamList(funcRslt, paramVO, loginVo.getUserLcale());
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
    }
    
    
    /*
     * @see com.mobis.maps.nmgn.mm.service.PackageImprovementService#savePackageImproveSatisfaction(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.mm.vo.PackageImproveSatisfyVO)
     */
    @Override
    public void multiSavePackageImproveSatisfaction(LoginInfoVO loginVo, PackageImproveSatisfyVO paramVO)
            throws Exception {

        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPMM_NMGN_R_CREATE_PI_CSAT;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, paramVO);
         // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        
       
        /* RFC 호출 */
        /* RFC 호출 싨행시 반드시 호출해야 하는 함수 service.selectExcecute*/
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func, true);
       
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        // *** RFC 호출결과 정보 추출
        MapsRfcMappperUtil.setExportParamList(funcRslt, paramVO, loginVo.getUserLcale());
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
    }

    /*
     * @see com.mobis.maps.nmgn.mm.service.PackageImprovementService#deletePackageImprove(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.mm.vo.DuplicationCheckVO)
     */
    @Override
    public void deletePackageImprove(LoginInfoVO loginVo, PackageImprovementVO params) throws Exception {
        
        // *** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPMM_NMGN_R_DELETE_PI_REQ;

        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());

        // *** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        // *** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);

        // *** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);

        // *** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
    }   
}
