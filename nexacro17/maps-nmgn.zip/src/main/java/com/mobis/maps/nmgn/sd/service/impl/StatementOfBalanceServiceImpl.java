package com.mobis.maps.nmgn.sd.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.StatementOfBalanceService;
import com.mobis.maps.nmgn.sd.vo.StatementOfBalanceVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : StatementOfBalanceServiceImpl.java
 * @Description : Statement of Balance
 * @author jiyongdo
 * @since 2020. 4. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 14.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("statementOfBalanceService")
public class StatementOfBalanceServiceImpl extends HService implements StatementOfBalanceService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.sd.service.StatementOfBalanceService#selectStatementOfBalanceList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.StatementOfBalanceVO)
     */
    @Override
    public Map<String, Object> selectStatementOfBalanceList(LoginInfoVO loginInfo, StatementOfBalanceVO paramVO) throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_BALANCE;
        //paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        List<StatementOfBalanceVO> rtnLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_LIST_D", paramVO, StatementOfBalanceVO.class);
        StatementOfBalanceVO totLst = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_LIST_H", StatementOfBalanceVO.class);
        
        retMap.put("head", totLst);
        retMap.put("body", rtnLst);      
        
        return retMap;   
    }
}
