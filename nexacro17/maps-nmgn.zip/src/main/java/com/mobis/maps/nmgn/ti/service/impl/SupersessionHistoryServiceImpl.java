package com.mobis.maps.nmgn.ti.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.ti.service.SupersessionHistoryService;
import com.mobis.maps.nmgn.ti.vo.SupersessionDetailVO;
import com.mobis.maps.nmgn.ti.vo.SupersessionHistoryVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SupersessionHistoryServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 5. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 19.     jiyongdo     	최초 생성
 * </pre>
 */

@Service("supersessionHistoryService")
public class SupersessionHistoryServiceImpl extends HService implements SupersessionHistoryService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.ti.service.SupersessionHistoryService#selectSupersessionHistoryList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.SupersessionHistoryVO)
     */
    @Override
    public List<SupersessionHistoryVO> selectSupersessionHistoryList(LoginInfoVO loginInfo,
            SupersessionHistoryVO params) throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_PART_LIST_HQ;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<SupersessionHistoryVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, SupersessionHistoryVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.SupersessionHistoryService#selectRegionList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.SupersessionHistoryVO)
     */
    @Override
    public List<SupersessionHistoryVO> selectRegionList(LoginInfoVO loginInfo, SupersessionHistoryVO params)
            throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_SELECT_AREA_CODE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<SupersessionHistoryVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, SupersessionHistoryVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.SupersessionHistoryService#selectModelList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.SupersessionHistoryVO)
     */
    @Override
    public List<SupersessionHistoryVO> selectModelList(LoginInfoVO loginInfo, SupersessionHistoryVO params)
            throws Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_SELECT_MODEL_CODE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());

        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 조회결과
        List<SupersessionHistoryVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, SupersessionHistoryVO.class);
        
        return list;
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.SupersessionHistoryService#selectSupersessionDetailList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.SupersessionHistoryVO)
     */
    @Override
    public Map<String, Object> selectSupersessionDetailList(LoginInfoVO loginInfo, SupersessionDetailVO params)
            throws Exception {
        
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_PART_DETAIL_HQ;
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());         
        
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        /* RFC 호출 조회정보 추출 */
        SupersessionDetailVO rtnVo =  MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_DATA", SupersessionDetailVO.class);

        retMap.put("head", rtnVo);      
        
        /* RFC Function 취득 */
        sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_REGION_MASTER_HQ;
        params.setIfCode(sapRfcInfo.getIfCode());
        func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        /* RFC 호출 */
        funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        /* RFC 호출 조회정보 추출 */
        List<SupersessionDetailVO> rtnListVo = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, SupersessionDetailVO.class);

        retMap.put("body", rtnListVo);            
        
        return retMap; 
    }

    /*
     * @see com.mobis.maps.nmgn.ti.service.SupersessionHistoryService#selectSupersessionDetailListExcelDown(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.ti.vo.SupersessionDetailVO)
     */
    @Override
    public Map<String, Object> selectSupersessionDetailListExcelDown(LoginInfoVO loginInfo, SupersessionDetailVO params)
            throws Exception {
        Map<String, Object> retMap  = new HashMap<String, Object>();
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPTI_NMGN_S_REGION_MASTER_HQ;
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        // 공통파라미터(Import) 셋팅              
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);          
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        /* RFC 호출 */
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        /* RFC 호출 조회정보 추출 */
        List<SupersessionDetailVO> rtnListVo = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "ET_DATA", params, SupersessionDetailVO.class);

        retMap.put("head", rtnListVo);                  
        
        return retMap; 
    }
}
