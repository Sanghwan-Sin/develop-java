package com.mobis.maps.nmgn.cc.vo;

import java.util.List;
import java.util.Map;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : CalendarVO.java
 * @Description : 달력
 * @author hong.minho
 * @since 2020. 5. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 20.     hong.minho     	최초 생성
 * </pre>
 */

public class CalendarVO extends MapsCommSapRfcIfCommVO {
    
    // params.
    private String bukrs; // 법인코드4자리
    private String year; // 년도4자리
    private String lang; // 사용언어
    private String calOnlyYn; // 달력만 조회여부 (Y:년달력만, N:년달력+공휴일)
    
    // 
    private String ym; // 년월
    private String mon; // 월
    private String wk; // 일련번호 (0부터, 해당년의 주차)
    
    
    // Description List Map
    private Map<String, List<CalendarHdyVO>> descLstMap = null;
    
    
    // yyyymmdd
    private String date0; // sun
    private String date1; // mon
    private String date2; // tue
    private String date3; // wed
    private String date4; // thr
    private String date5; // fri
    private String date6; // sat

    // today 여부
    private String isToday0; // sun 
    private String isToday1; // mon 
    private String isToday2; // tue
    private String isToday3; // wed
    private String isToday4; // thr
    private String isToday5; // fri
    private String isToday6; // sat
    
    
    // 휴일여부
    private String hdYn0; // sun
    private String hdYn1; // mon
    private String hdYn2; // tue
    private String hdYn3; // wed
    private String hdYn4; // thr
    private String hdYn5; // fri
    private String hdYn6; // sat

    // 휴일내용
    private String desc0; // sun
    private String desc1; // mon
    private String desc2; // tue
    private String desc3; // wed
    private String desc4; // thr
    private String desc5; // fri
    private String desc6; // sat

    
    // 기념일여부
    private String anvsyYn0; // sun
    private String anvsyYn1; // mon
    private String anvsyYn2; // tue
    private String anvsyYn3; // wed
    private String anvsyYn4; // thr
    private String anvsyYn5; // fri
    private String anvsyYn6; // sat

    // 기념일내용
    private String anvsyDesc0; // sun
    private String anvsyDesc1; // mon
    private String anvsyDesc2; // tue
    private String anvsyDesc3; // wed
    private String anvsyDesc4; // thr
    private String anvsyDesc5; // fri
    private String anvsyDesc6; // sat
    
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the year
     */
    public String getYear() {
        return year;
    }
    /**
     * @param year the year to set
     */
    public void setYear(String year) {
        this.year = year;
    }
    /**
     * @return the ym
     */
    public String getYm() {
        return ym;
    }
    /**
     * @param ym the ym to set
     */
    public void setYm(String ym) {
        this.ym = ym;
    }
    /**
     * @return the wk
     */
    public String getWk() {
        return wk;
    }
    /**
     * @param wk the wk to set
     */
    public void setWk(String wk) {
        this.wk = wk;
    }
    /**
     * @return the date0
     */
    public String getDate0() {
        return date0;
    }
    /**
     * @param date0 the date0 to set
     */
    public void setDate0(String date0) {
        this.date0 = date0;
    }
    /**
     * @return the date1
     */
    public String getDate1() {
        return date1;
    }
    /**
     * @param date1 the date1 to set
     */
    public void setDate1(String date1) {
        this.date1 = date1;
    }
    /**
     * @return the date2
     */
    public String getDate2() {
        return date2;
    }
    /**
     * @param date2 the date2 to set
     */
    public void setDate2(String date2) {
        this.date2 = date2;
    }
    /**
     * @return the date3
     */
    public String getDate3() {
        return date3;
    }
    /**
     * @param date3 the date3 to set
     */
    public void setDate3(String date3) {
        this.date3 = date3;
    }
    /**
     * @return the date4
     */
    public String getDate4() {
        return date4;
    }
    /**
     * @param date4 the date4 to set
     */
    public void setDate4(String date4) {
        this.date4 = date4;
    }
    /**
     * @return the date5
     */
    public String getDate5() {
        return date5;
    }
    /**
     * @param date5 the date5 to set
     */
    public void setDate5(String date5) {
        this.date5 = date5;
    }
    /**
     * @return the date6
     */
    public String getDate6() {
        return date6;
    }
    /**
     * @param date6 the date6 to set
     */
    public void setDate6(String date6) {
        this.date6 = date6;
    }
    /**
     * @return the hdYn0
     */
    public String getHdYn0() {
        return hdYn0;
    }
    /**
     * @param hdYn0 the hdYn0 to set
     */
    public void setHdYn0(String hdYn0) {
        this.hdYn0 = hdYn0;
    }
    /**
     * @return the hdYn1
     */
    public String getHdYn1() {
        return hdYn1;
    }
    /**
     * @param hdYn1 the hdYn1 to set
     */
    public void setHdYn1(String hdYn1) {
        this.hdYn1 = hdYn1;
    }
    /**
     * @return the hdYn2
     */
    public String getHdYn2() {
        return hdYn2;
    }
    /**
     * @param hdYn2 the hdYn2 to set
     */
    public void setHdYn2(String hdYn2) {
        this.hdYn2 = hdYn2;
    }
    /**
     * @return the hdYn3
     */
    public String getHdYn3() {
        return hdYn3;
    }
    /**
     * @param hdYn3 the hdYn3 to set
     */
    public void setHdYn3(String hdYn3) {
        this.hdYn3 = hdYn3;
    }
    /**
     * @return the hdYn4
     */
    public String getHdYn4() {
        return hdYn4;
    }
    /**
     * @param hdYn4 the hdYn4 to set
     */
    public void setHdYn4(String hdYn4) {
        this.hdYn4 = hdYn4;
    }
    /**
     * @return the hdYn5
     */
    public String getHdYn5() {
        return hdYn5;
    }
    /**
     * @param hdYn5 the hdYn5 to set
     */
    public void setHdYn5(String hdYn5) {
        this.hdYn5 = hdYn5;
    }
    /**
     * @return the hdYn6
     */
    public String getHdYn6() {
        return hdYn6;
    }
    /**
     * @param hdYn6 the hdYn6 to set
     */
    public void setHdYn6(String hdYn6) {
        this.hdYn6 = hdYn6;
    }
    /**
     * @return the desc0
     */
    public String getDesc0() {
        return desc0;
    }
    /**
     * @param desc0 the desc0 to set
     */
    public void setDesc0(String desc0) {
        this.desc0 = desc0;
    }
    /**
     * @return the desc1
     */
    public String getDesc1() {
        return desc1;
    }
    /**
     * @param desc1 the desc1 to set
     */
    public void setDesc1(String desc1) {
        this.desc1 = desc1;
    }
    /**
     * @return the desc2
     */
    public String getDesc2() {
        return desc2;
    }
    /**
     * @param desc2 the desc2 to set
     */
    public void setDesc2(String desc2) {
        this.desc2 = desc2;
    }
    /**
     * @return the desc3
     */
    public String getDesc3() {
        return desc3;
    }
    /**
     * @param desc3 the desc3 to set
     */
    public void setDesc3(String desc3) {
        this.desc3 = desc3;
    }
    /**
     * @return the desc4
     */
    public String getDesc4() {
        return desc4;
    }
    /**
     * @param desc4 the desc4 to set
     */
    public void setDesc4(String desc4) {
        this.desc4 = desc4;
    }
    /**
     * @return the desc5
     */
    public String getDesc5() {
        return desc5;
    }
    /**
     * @param desc5 the desc5 to set
     */
    public void setDesc5(String desc5) {
        this.desc5 = desc5;
    }
    /**
     * @return the desc6
     */
    public String getDesc6() {
        return desc6;
    }
    /**
     * @param desc6 the desc6 to set
     */
    public void setDesc6(String desc6) {
        this.desc6 = desc6;
    }
    /**
     * @return the mon
     */
    public String getMon() {
        return mon;
    }
    /**
     * @param mon the mon to set
     */
    public void setMon(String mon) {
        this.mon = mon;
    }
    /**
     * @return the lang
     */
    public String getLang() {
        return lang;
    }
    /**
     * @param lang the lang to set
     */
    public void setLang(String lang) {
        this.lang = lang;
    }
    /**
     * @return the anvsyYn0
     */
    public String getAnvsyYn0() {
        return anvsyYn0;
    }
    /**
     * @param anvsyYn0 the anvsyYn0 to set
     */
    public void setAnvsyYn0(String anvsyYn0) {
        this.anvsyYn0 = anvsyYn0;
    }
    /**
     * @return the anvsyYn1
     */
    public String getAnvsyYn1() {
        return anvsyYn1;
    }
    /**
     * @param anvsyYn1 the anvsyYn1 to set
     */
    public void setAnvsyYn1(String anvsyYn1) {
        this.anvsyYn1 = anvsyYn1;
    }
    /**
     * @return the anvsyYn2
     */
    public String getAnvsyYn2() {
        return anvsyYn2;
    }
    /**
     * @param anvsyYn2 the anvsyYn2 to set
     */
    public void setAnvsyYn2(String anvsyYn2) {
        this.anvsyYn2 = anvsyYn2;
    }
    /**
     * @return the anvsyYn3
     */
    public String getAnvsyYn3() {
        return anvsyYn3;
    }
    /**
     * @param anvsyYn3 the anvsyYn3 to set
     */
    public void setAnvsyYn3(String anvsyYn3) {
        this.anvsyYn3 = anvsyYn3;
    }
    /**
     * @return the anvsyYn4
     */
    public String getAnvsyYn4() {
        return anvsyYn4;
    }
    /**
     * @param anvsyYn4 the anvsyYn4 to set
     */
    public void setAnvsyYn4(String anvsyYn4) {
        this.anvsyYn4 = anvsyYn4;
    }
    /**
     * @return the anvsyYn5
     */
    public String getAnvsyYn5() {
        return anvsyYn5;
    }
    /**
     * @param anvsyYn5 the anvsyYn5 to set
     */
    public void setAnvsyYn5(String anvsyYn5) {
        this.anvsyYn5 = anvsyYn5;
    }
    /**
     * @return the anvsyYn6
     */
    public String getAnvsyYn6() {
        return anvsyYn6;
    }
    /**
     * @param anvsyYn6 the anvsyYn6 to set
     */
    public void setAnvsyYn6(String anvsyYn6) {
        this.anvsyYn6 = anvsyYn6;
    }
    /**
     * @return the anvsyDesc0
     */
    public String getAnvsyDesc0() {
        return anvsyDesc0;
    }
    /**
     * @param anvsyDesc0 the anvsyDesc0 to set
     */
    public void setAnvsyDesc0(String anvsyDesc0) {
        this.anvsyDesc0 = anvsyDesc0;
    }
    /**
     * @return the anvsyDesc1
     */
    public String getAnvsyDesc1() {
        return anvsyDesc1;
    }
    /**
     * @param anvsyDesc1 the anvsyDesc1 to set
     */
    public void setAnvsyDesc1(String anvsyDesc1) {
        this.anvsyDesc1 = anvsyDesc1;
    }
    /**
     * @return the anvsyDesc2
     */
    public String getAnvsyDesc2() {
        return anvsyDesc2;
    }
    /**
     * @param anvsyDesc2 the anvsyDesc2 to set
     */
    public void setAnvsyDesc2(String anvsyDesc2) {
        this.anvsyDesc2 = anvsyDesc2;
    }
    /**
     * @return the anvsyDesc3
     */
    public String getAnvsyDesc3() {
        return anvsyDesc3;
    }
    /**
     * @param anvsyDesc3 the anvsyDesc3 to set
     */
    public void setAnvsyDesc3(String anvsyDesc3) {
        this.anvsyDesc3 = anvsyDesc3;
    }
    /**
     * @return the anvsyDesc4
     */
    public String getAnvsyDesc4() {
        return anvsyDesc4;
    }
    /**
     * @param anvsyDesc4 the anvsyDesc4 to set
     */
    public void setAnvsyDesc4(String anvsyDesc4) {
        this.anvsyDesc4 = anvsyDesc4;
    }
    /**
     * @return the anvsyDesc5
     */
    public String getAnvsyDesc5() {
        return anvsyDesc5;
    }
    /**
     * @param anvsyDesc5 the anvsyDesc5 to set
     */
    public void setAnvsyDesc5(String anvsyDesc5) {
        this.anvsyDesc5 = anvsyDesc5;
    }
    /**
     * @return the anvsyDesc6
     */
    public String getAnvsyDesc6() {
        return anvsyDesc6;
    }
    /**
     * @param anvsyDesc6 the anvsyDesc6 to set
     */
    public void setAnvsyDesc6(String anvsyDesc6) {
        this.anvsyDesc6 = anvsyDesc6;
    }
    /**
     * @return the calOnlyYn
     */
    public String getCalOnlyYn() {
        return calOnlyYn;
    }
    /**
     * @param calOnlyYn the calOnlyYn to set
     */
    public void setCalOnlyYn(String calOnlyYn) {
        this.calOnlyYn = calOnlyYn;
    }
    /**
     * @return the descLstMap
     */
    public Map<String, List<CalendarHdyVO>> getDescLstMap() {
        return descLstMap;
    }
    /**
     * @param descLstMap the descLstMap to set
     */
    public void setDescLstMap(Map<String, List<CalendarHdyVO>> descLstMap) {
        this.descLstMap = descLstMap;
    }
    /**
     * @return the isToday0
     */
    public String getIsToday0() {
        return isToday0;
    }
    /**
     * @param isToday0 the isToday0 to set
     */
    public void setIsToday0(String isToday0) {
        this.isToday0 = isToday0;
    }
    /**
     * @return the isToday1
     */
    public String getIsToday1() {
        return isToday1;
    }
    /**
     * @param isToday1 the isToday1 to set
     */
    public void setIsToday1(String isToday1) {
        this.isToday1 = isToday1;
    }
    /**
     * @return the isToday2
     */
    public String getIsToday2() {
        return isToday2;
    }
    /**
     * @param isToday2 the isToday2 to set
     */
    public void setIsToday2(String isToday2) {
        this.isToday2 = isToday2;
    }
    /**
     * @return the isToday3
     */
    public String getIsToday3() {
        return isToday3;
    }
    /**
     * @param isToday3 the isToday3 to set
     */
    public void setIsToday3(String isToday3) {
        this.isToday3 = isToday3;
    }
    /**
     * @return the isToday4
     */
    public String getIsToday4() {
        return isToday4;
    }
    /**
     * @param isToday4 the isToday4 to set
     */
    public void setIsToday4(String isToday4) {
        this.isToday4 = isToday4;
    }
    /**
     * @return the isToday5
     */
    public String getIsToday5() {
        return isToday5;
    }
    /**
     * @param isToday5 the isToday5 to set
     */
    public void setIsToday5(String isToday5) {
        this.isToday5 = isToday5;
    }
    /**
     * @return the isToday6
     */
    public String getIsToday6() {
        return isToday6;
    }
    /**
     * @param isToday6 the isToday6 to set
     */
    public void setIsToday6(String isToday6) {
        this.isToday6 = isToday6;
    }
    


    
}
