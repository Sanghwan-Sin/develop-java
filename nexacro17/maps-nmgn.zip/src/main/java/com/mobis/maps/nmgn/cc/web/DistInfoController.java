package com.mobis.maps.nmgn.cc.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.nmgn.cc.service.DistInfoService;
import com.mobis.maps.nmgn.cc.vo.CodeNameVO;
import com.mobis.maps.nmgn.cc.vo.DistInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistInfoController.java
 * @Description : DistInfoController
 * @author ha.jeongryeong
 * @since 2019. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 10.     ha.jeongryeong         최초 생성
 * </pre>
 */
@Controller
public class DistInfoController extends HController {

    @Resource(name = "distInfoService")
    private DistInfoService distInfoService;
          
    /**
     * 조회(detail)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDistInfoDetail.do")
    public NexacroResult selectDistInfoDetail(
            @ParamDataSet(name="dsInput") DistInfoVO paramVO
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        DistInfoVO retVO = distInfoService.selectDistInfoDetail(paramVO);

        result.addDataSet("dsOutput", retVO);

        return result;
    }
    
    /**
     * 조회(staff)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDistStaffInfoList.do")
    public NexacroResult selectDistStaffInfoList(
            @ParamDataSet(name="dsInput") DistInfoVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        List<DistInfoVO> retList = distInfoService.selectDistStaffInfoList(paramVO);
                
        result.addDataSet("dsOutput", retList);
        result.addDataSet("dsReturn", paramVO);
                
        return result;
    }
    
    /**
     * 조회(staff) 엑셀
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectDistStaffInfoListExcelDown.do")
    public NexacroResult selectDistStaffInfoListExcelDown(
            @ParamDataSet(name="dsInput") DistInfoVO paramVO
            , NexacroResult result) throws Exception {

        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        paramVO.setExcelDwnlYn("Y");
        List<DistInfoVO> retList = distInfoService.selectDistStaffInfoList(paramVO);

        result.addDataSet("dsOutput", retList);

        return result;
    }
    
    /**
     * 조회(코드)
     *
     * @param paramVO
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectChgNameList.do")
    public NexacroResult selectChgNameList(
            NexacroResult result) throws Exception {

        List<CodeNameVO> retList = distInfoService.selectChgNameList();

        result.addDataSet("dsOutput", retList);

        return result;
    }
    
    /**
     * 저장(staff)
     *
     * @param smplAtchFileVO
     * @param atchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/multiDistDetailInfo.do")
    public NexacroResult multiDistDetailInfo(
            @ParamDataSet(name="dsInput") DistInfoVO paramVO
            , @ParamDataSet(name="dsInput2") List<DistInfoVO> paramList
            , @ParamDataSet(name="dsInputAtchFile") List<MapsAtchFileVO> atchFiles
            , @ParamDataSet(name="dsInputAtchFile2") List<MapsAtchFileVO> atchFiles2
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
        
        List<DistInfoVO> retList = distInfoService.multiDistDetailInfo(paramVO, atchFiles, atchFiles2, paramList);

        result.addDataSet("dsOutput", retList);
        
        return result;
    }
    
    /**
     * 저장(staff photo)
     *
     * @param smplAtchFileVO
     * @param atchFiles
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/multiDistStaffPhoto.do")
    public NexacroResult multiDistStaffPhoto(
            @ParamDataSet(name="dsInput") DistInfoVO paramVO
            , @ParamDataSet(name="dsInputAtchFile") List<MapsAtchFileVO> atchFiles
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        paramVO.setUname(loginInfo.getUserId());
        paramVO.setTzone(loginInfo.getRfcTzone());
        paramVO.setSpras(loginInfo.getRfcLang());
                
        distInfoService.multiDistStaffPhoto(paramVO, atchFiles);
        
        return result;
    }
}
