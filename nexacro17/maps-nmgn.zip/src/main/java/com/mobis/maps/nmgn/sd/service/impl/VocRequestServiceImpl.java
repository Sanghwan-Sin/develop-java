package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.VocRequestService;
import com.mobis.maps.nmgn.sd.vo.AmendCodeVO;
import com.mobis.maps.nmgn.sd.vo.VocRequestVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : VocRequestServiceImpl.java
 * @Description : VOC Request (HQ)
 * @author hong.minho
 * @since 2020. 6. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 6. 8.     hong.minho     	최초 생성
 * </pre>
 */

@Service("vocRequestService")
public class VocRequestServiceImpl extends HService implements VocRequestService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.VocRequestService#selectVOCDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.VocRequestVO)
     */
    @Override
    public VocRequestVO selectVOCDetail(LoginInfoVO loginInfo, VocRequestVO params) throws MapsBizException, Exception {
        if (params == null) {
            logger.error("##### ERROR : VocRequestVO params is null.");
            return null;
        }
        
        params.setType("R");
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ISSUE_TRACKER;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportStructure(func, "IS_INPUT", params);
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func, true);
       
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 처리결과
        VocRequestVO rsltVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_OUTPUT", VocRequestVO.class); 

        //*** 처리결과-Contents
        List<VocRequestVO> contents =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_CONTENT", VocRequestVO.class);
        rsltVo.settContents(contents);
        
        return rsltVo;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.VocRequestService#saveVOCDetail(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.VocRequestVO)
     */
    @Override
    public VocRequestVO multiSaveVOCDetail(LoginInfoVO loginInfo, VocRequestVO params) throws MapsBizException, Exception {
        if (params == null) {
            logger.error("##### ERROR : VocRequestVO params is null.");
            return null;
        }
        
        // *** TYPE : C (신규) , U (수정/답변) , Q (Reply)
        if (StringUtils.isEmpty(params.getType())) {
            params.setType(StringUtils.isEmpty(params.getZticketNo()) ? "C" : "U");
        }
            
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ISSUE_TRACKER;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportStructure(func, "IS_INPUT", params);
        
        
        //*** 입력 Comments / Reply 적재
        JCoTable jcoTbl = null;
        String inputStr = "";
        if (!StringUtils.isBlank(params.getCline())) {
            jcoTbl = func.getImportTableParameter("T_CONTENT");
            inputStr = params.getCline();
        } else {
            jcoTbl = func.getImportTableParameter("T_REPLY");
            inputStr = params.getLine();
        }
        
        if (!StringUtils.isBlank(inputStr)) {
            String[] lines = inputStr.split("\\n"); // 개행단위 Record-Set
            
            for(String ln : lines) {
                String buf = ln;
                
                while(buf.length() > 130) { // 130자 넘어가면 New Record
                    jcoTbl.appendRow();            
                    jcoTbl.setValue("LINE", buf.substring(0, 130));
                    
                    buf = buf.substring(130);
                }
                
                jcoTbl.appendRow();            
                jcoTbl.setValue("LINE", buf);
            }
        }

        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func, true);
       
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 처리결과
        VocRequestVO rsltVo = MapsRfcMappperUtil.getExportStructure(funcRslt, "ES_OUTPUT", VocRequestVO.class); 

        //*** 처리결과-Contents
        List<VocRequestVO> contents =  MapsRfcMappperUtil.getExportTableValues(funcRslt, "T_CONTENT", VocRequestVO.class);
        rsltVo.settContents(contents);
        
        return rsltVo;
    }

    
    
    /*
     * @see com.mobis.maps.nmgn.sd.service.VocRequestService#selectAmendCdLst(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.AmendCodeVO)
     */
    @Override
    public List<AmendCodeVO> selectAmendCdLst(LoginInfoVO loginInfo, AmendCodeVO params) throws MapsBizException, Exception {
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_AMEND_CD;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        if (logger.isDebugEnabled()) {logger.debug("*** 공통파라미터(Import) 셋팅 ");}
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, params);

        params.setiType("R"); // Select
        
        //*** 파라미터(Import) 셋팅
        if (logger.isDebugEnabled()) {logger.debug("*** 파라미터(Import) 셋팅");}
        MapsRfcMappperUtil.setImportParamList(func, params);
        
        //*** RFC 호출
        if (logger.isDebugEnabled()) {logger.debug("*** RFC 호출");}
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);

        //*** RFC 호출결과 정보 추출
        if (logger.isDebugEnabled()) {logger.debug("*** RFC 호출결과 정보 추출");}
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);

        if (logger.isDebugEnabled()) {logger.debug("*** params.getMsgType():" + params.getMsgType());}
        
        if ("E".equals(params.getMsgType())) {
            return null;
        }
        
        //*** 조회결과
        List<AmendCodeVO> rsltLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_DATA", params, AmendCodeVO.class);     

        return rsltLst;
    }

}
