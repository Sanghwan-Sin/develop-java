package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderConfirmDownloadVO.java
 * @Description : Order Confirm Download
 * @author jiyongdo
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     jiyongdo     	최초 생성
 * </pre>
 */

public class OrderConfirmDownloadVO extends MapsCommSapRfcIfCommVO{
    //-----[IS_DATES] START-----
    /** ABAP: ID: I/E (include/exclude values) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="SIGN" )
    private String sign;
    /** ABAP: Selection option (EQ/BT/CP/...) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="OPTION" )
    private String option;
    /** 'Generic' SELECT-OPTION for Dynamic Selections */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="LOW" )
    private String low;
    /** 'Generic' SELECT-OPTION for Dynamic Selections */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="HIGH" )
    private String high;
    //-----[IS_DATES] END-----
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFILE_GRP" )
    private String iZfileGrp;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_UKURS_TXT" )
    private String eUkursTxt;
    /** Customer */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;    
    //-----[T_RESULT] START-----
    /** Dist. Code */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** Name 1 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM_NM" )
    private String zsacutmNm;
    /** H/K */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZHKCD_DESC" )
    private String zhkcdDesc;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_GRP" )
    private String zfileGrp;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZRVC_DATE" )
    private Date zrvcDate;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_NAME" )
    private String zfileName;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_REAL_NAME" )
    private String zfileRealName;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_PATH" )
    private String zfilePath;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="REF_NO" )
    private String refNo;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="FSCODE" )
    private String fscode;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_SIZE" )
    private String zfileSize;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_TYPE" )
    private String zfileType;
    /** Create Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCRLDATE" )
    private Date zcrldate;
    /** Create User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCRNAME" )
    private String zcrname;
    /** Change Local Date */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDLDATE" )
    private Date zudldate;
    /** Change User */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZUDNAME" )
    private String zudname;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZFILE_SEQNO" )
    private String zfileSeqno;
    
    //-----[T_RESULT] END-----
    /**
     * @return the sign
     */
    public String getSign() {
        return sign;
    }
    /**
     * @param sign the sign to set
     */
    public void setSign(String sign) {
        this.sign = sign;
    }
    /**
     * @return the option
     */
    public String getOption() {
        return option;
    }
    /**
     * @param option the option to set
     */
    public void setOption(String option) {
        this.option = option;
    }
    /**
     * @return the low
     */
    public String getLow() {
        return low;
    }
    /**
     * @param low the low to set
     */
    public void setLow(String low) {
        this.low = low;
    }
    /**
     * @return the high
     */
    public String getHigh() {
        return high;
    }
    /**
     * @param high the high to set
     */
    public void setHigh(String high) {
        this.high = high;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZfileGrp
     */
    public String getiZfileGrp() {
        return iZfileGrp;
    }
    /**
     * @param iZfileGrp the iZfileGrp to set
     */
    public void setiZfileGrp(String iZfileGrp) {
        this.iZfileGrp = iZfileGrp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the eUkursTxt
     */
    public String geteUkursTxt() {
        return eUkursTxt;
    }
    /**
     * @param eUkursTxt the eUkursTxt to set
     */
    public void seteUkursTxt(String eUkursTxt) {
        this.eUkursTxt = eUkursTxt;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the zsacutmNm
     */
    public String getZsacutmNm() {
        return zsacutmNm;
    }
    /**
     * @param zsacutmNm the zsacutmNm to set
     */
    public void setZsacutmNm(String zsacutmNm) {
        this.zsacutmNm = zsacutmNm;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zhkcdDesc
     */
    public String getZhkcdDesc() {
        return zhkcdDesc;
    }
    /**
     * @param zhkcdDesc the zhkcdDesc to set
     */
    public void setZhkcdDesc(String zhkcdDesc) {
        this.zhkcdDesc = zhkcdDesc;
    }
    /**
     * @return the zrvcDate
     */
    public Date getZrvcDate() {
        return zrvcDate;
    }
    /**
     * @param zrvcDate the zrvcDate to set
     */
    public void setZrvcDate(Date zrvcDate) {
        this.zrvcDate = zrvcDate;
    }
    /**
     * @return the zfileName
     */
    public String getZfileName() {
        return zfileName;
    }
    /**
     * @param zfileName the zfileName to set
     */
    public void setZfileName(String zfileName) {
        this.zfileName = zfileName;
    }
    /**
     * @return the zfileRealName
     */
    public String getZfileRealName() {
        return zfileRealName;
    }
    /**
     * @param zfileRealName the zfileRealName to set
     */
    public void setZfileRealName(String zfileRealName) {
        this.zfileRealName = zfileRealName;
    }
    /**
     * @return the zfilePath
     */
    public String getZfilePath() {
        return zfilePath;
    }
    /**
     * @param zfilePath the zfilePath to set
     */
    public void setZfilePath(String zfilePath) {
        this.zfilePath = zfilePath;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the fscode
     */
    public String getFscode() {
        return fscode;
    }
    /**
     * @param fscode the fscode to set
     */
    public void setFscode(String fscode) {
        this.fscode = fscode;
    }
    /**
     * @return the zfileSize
     */
    public String getZfileSize() {
        return zfileSize;
    }
    /**
     * @param zfileSize the zfileSize to set
     */
    public void setZfileSize(String zfileSize) {
        this.zfileSize = zfileSize;
    }
    /**
     * @return the zfileType
     */
    public String getZfileType() {
        return zfileType;
    }
    /**
     * @param zfileType the zfileType to set
     */
    public void setZfileType(String zfileType) {
        this.zfileType = zfileType;
    }
    /**
     * @return the zcrldate
     */
    public Date getZcrldate() {
        return zcrldate;
    }
    /**
     * @param zcrldate the zcrldate to set
     */
    public void setZcrldate(Date zcrldate) {
        this.zcrldate = zcrldate;
    }
    /**
     * @return the zcrname
     */
    public String getZcrname() {
        return zcrname;
    }
    /**
     * @param zcrname the zcrname to set
     */
    public void setZcrname(String zcrname) {
        this.zcrname = zcrname;
    }
    /**
     * @return the zudldate
     */
    public Date getZudldate() {
        return zudldate;
    }
    /**
     * @param zudldate the zudldate to set
     */
    public void setZudldate(Date zudldate) {
        this.zudldate = zudldate;
    }
    /**
     * @return the zudname
     */
    public String getZudname() {
        return zudname;
    }
    /**
     * @param zudname the zudname to set
     */
    public void setZudname(String zudname) {
        this.zudname = zudname;
    }
    /**
     * @return the zfileSeqno
     */
    public String getZfileSeqno() {
        return zfileSeqno;
    }
    /**
     * @param zfileSeqno the zfileSeqno to set
     */
    public void setZfileSeqno(String zfileSeqno) {
        this.zfileSeqno = zfileSeqno;
    }
    /**
     * @return the zfileGrp
     */
    public String getZfileGrp() {
        return zfileGrp;
    }
    /**
     * @param zfileGrp the zfileGrp to set
     */
    public void setZfileGrp(String zfileGrp) {
        this.zfileGrp = zfileGrp;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
}
