package com.mobis.maps.nmgn.qm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimReportVO.java
 * @Description : Claim Report
 *                by Part   : ZPQM_REPORT_PART
 *                by Code   : ZPQM_REPORT_CLAIMCODE
 * @author hong.minho
 * @since 2020. 10. 12.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 10. 12.     hong.minho     	최초 생성
 * </pre>
 */

public class ClaimReportVO extends MapsCommSapRfcIfCommVO {
    
    // ** 구분자 (P:part, C:code)
    private String tp;

    /** 의뢰년월 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATE_FROM" )
    private String iDateFrom;
    /** 의뢰년월 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATE_TO" )
    private String iDateTo;
    /** '1':Total, '2':list */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_SELTYP" )
    private String iSeltyp;
    /** 부품번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PARTNO" )
    private String iPartno;
    /** Claim Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CLCODE" )
    private String iClcode;
    /** 해외 대리점코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDIST" )
    private String iZdist;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSUBDIST" )
    private String iZsubdist;

    
    // ********* T_DATA
    /** 부품번호 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** 부품명 */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** Claim Code */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLA_CODE" )
    private String claCode;
    /** Claim Code Name */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="CLA_CODETX" )
    private String claCodetx;
    /** Accept Item */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ACC_ITEM" )
    private String accItem;
    /** Accept Q'ty */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ACC_QTY" )
    private String accQty;
    /** Accept Amount */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ACC_AMT" )
    private String accAmt;
    /** Reject Item */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REJ_ITEM" )
    private String rejItem;
    /** Reject Q'ty */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REJ_QTY" )
    private String rejQty;
    /** Reject Amount */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="REJ_AMT" )
    private String rejAmt;
    /** Pending Item */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="PEND_ITEM" )
    private String pendItem;
    /** Pending Q'ty */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="PEND_QTY" )
    private String pendQty;
    /** Pending Amount */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="PEND_AMT" )
    private String pendAmt;
    /** Total Item */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="TOTAL_ITEM" )
    private String totalItem;
    /** Total Q'ty */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="TOTAL_QTY" )
    private String totalQty;
    /** Total Amount */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="TOTAL_AMT" )
    private String totalAmt;
    /**
     * @return the iDateFrom
     */
    public String getiDateFrom() {
        return iDateFrom;
    }
    /**
     * @param iDateFrom the iDateFrom to set
     */
    public void setiDateFrom(String iDateFrom) {
        this.iDateFrom = iDateFrom;
    }
    /**
     * @return the iDateTo
     */
    public String getiDateTo() {
        return iDateTo;
    }
    /**
     * @param iDateTo the iDateTo to set
     */
    public void setiDateTo(String iDateTo) {
        this.iDateTo = iDateTo;
    }
    /**
     * @return the iSeltyp
     */
    public String getiSeltyp() {
        return iSeltyp;
    }
    /**
     * @param iSeltyp the iSeltyp to set
     */
    public void setiSeltyp(String iSeltyp) {
        this.iSeltyp = iSeltyp;
    }
    /**
     * @return the iPartno
     */
    public String getiPartno() {
        return iPartno;
    }
    /**
     * @param iPartno the iPartno to set
     */
    public void setiPartno(String iPartno) {
        this.iPartno = iPartno;
    }
    /**
     * @return the iClcode
     */
    public String getiClcode() {
        return iClcode;
    }
    /**
     * @param iClcode the iClcode to set
     */
    public void setiClcode(String iClcode) {
        this.iClcode = iClcode;
    }
    /**
     * @return the iZdist
     */
    public String getiZdist() {
        return iZdist;
    }
    /**
     * @param iZdist the iZdist to set
     */
    public void setiZdist(String iZdist) {
        this.iZdist = iZdist;
    }
    /**
     * @return the iZsubdist
     */
    public String getiZsubdist() {
        return iZsubdist;
    }
    /**
     * @param iZsubdist the iZsubdist to set
     */
    public void setiZsubdist(String iZsubdist) {
        this.iZsubdist = iZsubdist;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the claCode
     */
    public String getClaCode() {
        return claCode;
    }
    /**
     * @param claCode the claCode to set
     */
    public void setClaCode(String claCode) {
        this.claCode = claCode;
    }
    /**
     * @return the claCodetx
     */
    public String getClaCodetx() {
        return claCodetx;
    }
    /**
     * @param claCodetx the claCodetx to set
     */
    public void setClaCodetx(String claCodetx) {
        this.claCodetx = claCodetx;
    }
    /**
     * @return the accItem
     */
    public String getAccItem() {
        return accItem;
    }
    /**
     * @param accItem the accItem to set
     */
    public void setAccItem(String accItem) {
        this.accItem = accItem;
    }
    /**
     * @return the accQty
     */
    public String getAccQty() {
        return accQty;
    }
    /**
     * @param accQty the accQty to set
     */
    public void setAccQty(String accQty) {
        this.accQty = accQty;
    }
    /**
     * @return the accAmt
     */
    public String getAccAmt() {
        return accAmt;
    }
    /**
     * @param accAmt the accAmt to set
     */
    public void setAccAmt(String accAmt) {
        this.accAmt = accAmt;
    }
    /**
     * @return the rejItem
     */
    public String getRejItem() {
        return rejItem;
    }
    /**
     * @param rejItem the rejItem to set
     */
    public void setRejItem(String rejItem) {
        this.rejItem = rejItem;
    }
    /**
     * @return the rejQty
     */
    public String getRejQty() {
        return rejQty;
    }
    /**
     * @param rejQty the rejQty to set
     */
    public void setRejQty(String rejQty) {
        this.rejQty = rejQty;
    }
    /**
     * @return the rejAmt
     */
    public String getRejAmt() {
        return rejAmt;
    }
    /**
     * @param rejAmt the rejAmt to set
     */
    public void setRejAmt(String rejAmt) {
        this.rejAmt = rejAmt;
    }
    /**
     * @return the pendItem
     */
    public String getPendItem() {
        return pendItem;
    }
    /**
     * @param pendItem the pendItem to set
     */
    public void setPendItem(String pendItem) {
        this.pendItem = pendItem;
    }
    /**
     * @return the pendQty
     */
    public String getPendQty() {
        return pendQty;
    }
    /**
     * @param pendQty the pendQty to set
     */
    public void setPendQty(String pendQty) {
        this.pendQty = pendQty;
    }
    /**
     * @return the pendAmt
     */
    public String getPendAmt() {
        return pendAmt;
    }
    /**
     * @param pendAmt the pendAmt to set
     */
    public void setPendAmt(String pendAmt) {
        this.pendAmt = pendAmt;
    }
    /**
     * @return the totalItem
     */
    public String getTotalItem() {
        return totalItem;
    }
    /**
     * @param totalItem the totalItem to set
     */
    public void setTotalItem(String totalItem) {
        this.totalItem = totalItem;
    }
    /**
     * @return the totalQty
     */
    public String getTotalQty() {
        return totalQty;
    }
    /**
     * @param totalQty the totalQty to set
     */
    public void setTotalQty(String totalQty) {
        this.totalQty = totalQty;
    }
    /**
     * @return the totalAmt
     */
    public String getTotalAmt() {
        return totalAmt;
    }
    /**
     * @param totalAmt the totalAmt to set
     */
    public void setTotalAmt(String totalAmt) {
        this.totalAmt = totalAmt;
    }
    /**
     * @return the tp
     */
    public String getTp() {
        return tp;
    }
    /**
     * @param tp the tp to set
     */
    public void setTp(String tp) {
        this.tp = tp;
    }


}
