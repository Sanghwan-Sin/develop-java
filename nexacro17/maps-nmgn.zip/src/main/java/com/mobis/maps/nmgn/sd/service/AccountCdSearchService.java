package com.mobis.maps.nmgn.sd.service;

import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.AccountSearchVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AccountCdSearchService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 4. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 17.     jiyongdo     	최초 생성
 * </pre>
 */

public interface AccountCdSearchService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectAccountCdList(LoginInfoVO loginInfo, AccountSearchVO paramVO) throws Exception;

}
