package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.DistGeneralInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistGeneralInfoMDAO.java
 * @Description : Distributor General Info.
 * @author hong.minho
 * @since 2020. 4. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 28.     hong.minho     	최초 생성
 * </pre>
 */
@Mapper("distGeneralInfoMDAO")
public interface DistGeneralInfoMDAO {

    /**
     * 조회
     *
     * @param inputVO
     * @return
     */
    List<DistGeneralInfoVO> selectDistGeneralInfoList(DistGeneralInfoVO paramVO);
   
}
