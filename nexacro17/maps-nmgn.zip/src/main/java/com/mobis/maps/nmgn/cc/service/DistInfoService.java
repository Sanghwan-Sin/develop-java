package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.nmgn.cc.vo.CodeNameVO;
import com.mobis.maps.nmgn.cc.vo.DistInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistInfoService.java
 * @Description : DistInfoService
 * @author ha.jeongryeong
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     ha.jeongryeong         최초 생성
 * </pre>
 */

public interface DistInfoService {   
 
    /**
     * 조회
     *
     * @param inputVO
     * @return
     */
    public DistInfoVO selectDistInfoDetail(DistInfoVO paramVO) throws Exception;
    
    /**
     * 조회
     *
     * @param inputVO
     * @return
     */
    public List<DistInfoVO> selectDistStaffInfoList(DistInfoVO paramVO) throws Exception;
    
    /**
     * 조회(코드)
     *
     * @param inputVO
     * @return
     */
    public List<CodeNameVO> selectChgNameList() throws Exception;
    
    /**
     * 조회
     *
     * @param inputVO
     * @return
     */
    public List<DistInfoVO> multiDistDetailInfo(DistInfoVO paramVO, List<MapsAtchFileVO> atchFiles, List<MapsAtchFileVO> atchFiles2, List<DistInfoVO> paramList) throws Exception;
    
    /**
     * 조회
     *
     * @param inputVO
     * @return
     */
    public int multiDistStaffPhoto(DistInfoVO paramVO, List<MapsAtchFileVO> atchFiles) throws Exception;
    
}
