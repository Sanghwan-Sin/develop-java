package com.mobis.maps.nmgn.qm.vo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimDetailVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 1. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 1. 28.     jiyongdo     	최초 생성
 * </pre>
 */

public class ClaimDetailVO extends MapsCommSapRfcIfCommVO{
    private List<ClaimDetailVO> body1 = null;
    private List<ClaimDetailVO> body2 = null;
    private List<ClaimDetailVO> body3 = null;
    private ClaimDetailVO body4 = null;
    
    /**
     * @return the body1
     */
    public List<ClaimDetailVO> getBody1() {
        return body1;
    }
    /**
     * @param body1 the body1 to set
     */
    public void setBody1(List<ClaimDetailVO> body1) {
        this.body1 = body1;
    }
    /**
     * @return the body2
     */
    public List<ClaimDetailVO> getBody2() {
        return body2;
    }
    /**
     * @param body2 the body2 to set
     */
    public void setBody2(List<ClaimDetailVO> body2) {
        this.body2 = body2;
    }
    /**
     * @return the body3
     */
    public List<ClaimDetailVO> getBody3() {
        return body3;
    }
    /**
     * @param body3 the body3 to set
     */
    public void setBody3(List<ClaimDetailVO> body3) {
        this.body3 = body3;
    }
    /**
     * @return the body4
     */
    public ClaimDetailVO getBody4() {
        return body4;
    }
    /**
     * @param body4 the body4 to set
     */
    public void setBody4(ClaimDetailVO body4) {
        this.body4 = body4;
    }

    /** [QM] 클레임업무 테이블 생성, 읽기, 수정, 삭제 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CRUD" )
    private String iCrud;
    /** 클레임번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZCLANO" )
    private String iZclano;
    /** 해외 대리점코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSUBDIST" )
    private String iZsubdist;
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_QIISUENO" )
    private String iQiisueno;
    /** 생성 Reference Number 01 +AMT */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA01" )
    private String eRefNoa01;
    /** 생성 Reference Number 02 -AMT */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA02" )
    private String eRefNoa02;
    /** 생성 Reference Number 03 Label */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA03" )
    private String eRefNoa03;
    /** 생성 Reference Number 04 Defect 1 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA04" )
    private String eRefNoa04;
    /** 생성 Reference Number 05 Defect 2 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA05" )
    private String eRefNoa05;
    /** 생성 Reference Number 06 Packing Box */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA06" )
    private String eRefNoa06;
    /** 판정 Reference Number 07 Attachment File */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA07" )
    private String eRefNoa07;
    /** 폐기 Reference Number 08 Label */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA08" )
    private String eRefNoa08;
    /** 폐기 Reference Number 09 Parts 1 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA09" )
    private String eRefNoa09;
    /** 폐기 Reference Number 10 Standard Form */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NOA10" )
    private String eRefNoa10;
    /** 클레임번호 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZCLANO" )
    private String eZclano;    
    
    /** Client */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="MANDT" )
    private String mandt;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU|T_DATA_SC", ipttSe="I|E", fieldKey="ZCLANO" )
    private String zclano;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCLSTATUS" )
    private String zclstatus;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCLTYPE" )
    private String zcltype;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="KVGR1" )
    private String kvgr1;
    /** Sales office */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="VKBUR" )
    private String vkbur;
    /** Sales group */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="VKGRP" )
    private String vkgrp;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="VKGRPTEXT" )
    private String vkgrptext;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZDIST" )
    private String zdist;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZDISTCNO" )
    private String zdistcno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUBDIST" )
    private String zsubdist;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCOPDC" )
    private String zcopdc;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUBBUKRS" )
    private String zsubbukrs;
    /** Company Code */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="BUKRS" )
    private String bukrs;
    /** Plant */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="WERKS" )
    private String werks;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="SITE" )
    private String site;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSALESNO" )
    private String zsalesno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSORDER" )
    private String zsorder;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSORDERITEM" )
    private String zsorderitem;
    /** Invoice No. */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZINVOICE" )
    private String zinvoice;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCASENO" )
    private String zcaseno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZHK" )
    private String zhk;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="MAKTX" )
    private String maktx;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZPARTGR" )
    private String zpartgr;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="CLTYPE" )
    private String cltype;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="CLCODEGR" )
    private String clcodegr;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="CLCODE" )
    private String clcode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="CLQTY" )
    private BigDecimal clqty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="LAGME" )
    private String lagme;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZPACKLOT" )
    private String zpacklot;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZPACKDATE" )
    private Date zpackdate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZINSPCERT" )
    private String zinspcert;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZREDOCTY" )
    private String zredocty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZREDOCNO" )
    private String zredocno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZREFDOCNO" )
    private String zrefdocno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZTGGPRDATE" )
    private Date ztggprdate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZTGGPRTIME" )
    private Date ztggprtime;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCR_DE" )
    private String zcrDe;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZREIMTY" )
    private String zreimty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZTRANSTY" )
    private String ztransty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZUNITPRICE" )
    private BigDecimal zunitprice;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZUNITPRICECU" )
    private String zunitpricecu;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZEXUNITPRI" )
    private String zexunitpri;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZMAKEUP_RATE" )
    private BigDecimal zmakeupRate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZMARKRATE" )
    private BigDecimal zmarkrate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZMVAVPRI" )
    private BigDecimal zmvavpri;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZADDAMO1" )
    private BigDecimal zaddamo1;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZADDAMO2" )
    private BigDecimal zaddamo2;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZTOTAMO" )
    private BigDecimal ztotamo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZTOTAMOCU" )
    private String ztotamocu;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZTOTAMOK" )
    private BigDecimal ztotamok;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZTOTAMOKCU" )
    private String ztotamokcu;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCOMMENT" )
    private String zcomment;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZLATYPE" )
    private String zlatype;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUPP_M" )
    private String zsuppM;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUPP_P" )
    private String zsuppP;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUPP_S" )
    private String zsuppS;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUPP_R" )
    private String zsuppR;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZJU_SUBCLANOH" )
    private String zjuSubclanoh;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZRECLANO_CY" )
    private String zreclanoCy;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUBMDATE" )
    private Date zsubmdate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUBMTIME" )
    private Date zsubmtime;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUBMBY" )
    private String zsubmby;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCAN" )
    private String zcan;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCANDATE" )
    private Date zcandate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCANTIME" )
    private Date zcantime;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCANBY" )
    private String zcanby;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATTAMT1_FSCODE" )
    private String zattamt1Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATTAMT1_REF_NO" )
    private String zattamt1RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATTAMT1" )
    private String zattamt1;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATTAMT1_FNAME" )
    private String zattamt1Fname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATTAMT2_FSCODE" )
    private String zattamt2Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATTAMT2_REF_NO" )
    private String zattamt2RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATTAMT2" )
    private String zattamt2;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATTAMT2_FNAME" )
    private String zattamt2Fname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="E", fieldKey="ZRESTDT" )
    private Date zrestdt;    
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT1_FSCODE" )
    private String zatt1Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT1_REF_NO" )
    private String zatt1RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT1" )
    private String zatt1;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT1_FNAME" )
    private String zatt1Fname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT2_FSCODE" )
    private String zatt2Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT2_REF_NO" )
    private String zatt2RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT2" )
    private String zatt2;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT2_FNAME" )
    private String zatt2Fname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT3_FSCODE" )
    private String zatt3Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT3_REF_NO" )
    private String zatt3RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT3" )
    private String zatt3;
    /**  */
    @MapsRfcMappper( targetName="T_DATA|T_DATA_JU", ipttSe="I|E", fieldKey="ZATT3_FNAME" )
    private String zatt3Fname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT4_FSCODE" )
    private String zatt4Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT4_REF_NO" )
    private String zatt4RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT4" )
    private String zatt4;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZATT4_FNAME" )
    private String zatt4Fname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZPACKLOT_YR" )
    private String zpacklotYr;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZPACKLOT_MON" )
    private String zpacklotMon;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZPACKLOT_DAY" )
    private String zpacklotDay;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZDE_GBKYN" )
    private String zdeGbkyn;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZDE_SNDDT" )
    private Date zdeSnddt;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZDE_RCVDT" )
    private Date zdeRcvdt;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZHMC_MIP" )
    private String zhmcMip;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZREORDER" )
    private String zreorder;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZKIT" )
    private String zkit;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZASIS_CLAIMNO" )
    private String zasisClaimno;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCHCREATE" )
    private Date zchcreate;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCHCRTIME" )
    private Date zchcrtime;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCHCRID" )
    private String zchcrid;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCHCRIDNAME" )
    private String zchcridname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZSUBMBYNAME" )
    private String zsubmbyname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZCANBYNAME" )
    private String zcanbyname;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="DOC_NUMBER" )
    private String docNumber;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ITEM_NO" )
    private String itemNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="DOC_YEAR" )
    private String docYear;
    /** Change User */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZUDNAME" )
    private String zudname;
    /** Change System Date */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZUDSDATE" )
    private Date zudsdate;
    /** Change System Time */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZUDSTIME" )
    private Date zudstime;
    /** Change Local Date */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZUDLDATE" )
    private Date zudldate;
    /** Change Local Time */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZUDLTIME" )
    private Date zudltime;
    /** ABAP System Field: Time Zone of Current User */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="ZONLO" )
    private String zonlo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="MTYPE" )
    private String mtype;
    /**  */
    @MapsRfcMappper( targetName="T_DATA", ipttSe="I|E", fieldKey="MESSAGE" )
    private String message;
    //-----[T_DATA] END-----

    //-----[T_DATA_JU] START-----
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_RESULT" )
    private String zjuResult;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_RESULTX" )
    private String zjuResultx;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_RECODE" )
    private String zjuRecode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_RECODE_NAME" )
    private String zjuRecodeName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_CLCODE" )
    private String zjuClcode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_CLCODE_NAME" )
    private String zjuClcodeName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_QTY" )
    private String zjuQty;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_QTYUNIT" )
    private String zjuQtyunit;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_ACTY" )
    private String zjuActy;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_ACTY_NAME" )
    private String zjuActyName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_FOTYP" )
    private String zjuFotyp;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_FOTYPE_NAME" )
    private String zjuFotypeName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_FOACT" )
    private String zjuFoact;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_FOACT_NAME" )
    private String zjuFoactName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_SCRAPCHK" )
    private String zjuScrapchk;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_SCRAPSDAT" )
    private Date zjuScrapsdat;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_FOCNOH_CHK" )
    private String zjuFocnohChk;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_FOCNOH" )
    private String zjuFocnoh;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_LATYPE" )
    private String zjuLatype;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_LATYPEX" )
    private String zjuLatypex;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_LASUP" )
    private String zjuLasup;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_LASUPX" )
    private String zjuLasupx;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_COMMENT" )
    private String zjuComment;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_OCOST" )
    private String zjuOcost;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_OCOSTCUR" )
    private String zjuOcostcur;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_ADTYPE" )
    private String zjuAdtype;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_ADCOST" )
    private String zjuAdcost;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_ADCOSTCUR" )
    private String zjuAdcostcur;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_ADCOMT" )
    private String zjuAdcomt;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_TOTALRECOST" )
    private String zjuTotalrecost;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZJU_TOTALRECOSTCUR" )
    private String zjuTotalrecostcur;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_JU", ipttSe="I|E", fieldKey="ZNCRNO" )
    private String zncrno;
    //-----[T_DATA_JU] END-----

    //-----[T_DATA_SC] START-----
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZSC_STDFORM_FSCODE" )
    private String zscStdformFscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZSC_STDFORM_REF_NO" )
    private String zscStdformRefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZSC_STDFORM" )
    private String zscStdform;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZSC_STDFORM_NAME" )
    private String zscStdformName;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCU_ATT1_FSCODE" )
    private String zcuAtt1Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCU_ATT1_REF_NO" )
    private String zcuAtt1RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCU_ATT1" )
    private String zcuAtt1;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCU_ATT1_NAME" )
    private String zcuAtt1Name;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCU_ATT2_FSCODE" )
    private String zcuAtt2Fscode;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCU_ATT2_REF_NO" )
    private String zcuAtt2RefNo;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCU_ATT2" )
    private String zcuAtt2;
    /**  */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCU_ATT2_NAME" )
    private String zcuAtt2Name;
    /** Create Local Date */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCRDATE" )
    private Date zcrdate;
    /** Create Local Time */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCRTIME" )
    private Date zcrtime;
    /** Create User */
    @MapsRfcMappper( targetName="T_DATA_SC", ipttSe="I|E", fieldKey="ZCRID" )
    private String zcrid;
    //-----[T_DATA_SC] END-----
    /**
     * @return the iCrud
     */
    public String getiCrud() {
        return iCrud;
    }
    /**
     * @param iCrud the iCrud to set
     */
    public void setiCrud(String iCrud) {
        this.iCrud = iCrud;
    }
    /**
     * @return the iZclano
     */
    public String getiZclano() {
        return iZclano;
    }
    /**
     * @param iZclano the iZclano to set
     */
    public void setiZclano(String iZclano) {
        this.iZclano = iZclano;
    }
    /**
     * @return the iZsubdist
     */
    public String getiZsubdist() {
        return iZsubdist;
    }
    /**
     * @param iZsubdist the iZsubdist to set
     */
    public void setiZsubdist(String iZsubdist) {
        this.iZsubdist = iZsubdist;
    }
    /**
     * @return the iQiisueno
     */
    public String getiQiisueno() {
        return iQiisueno;
    }
    /**
     * @param iQiisueno the iQiisueno to set
     */
    public void setiQiisueno(String iQiisueno) {
        this.iQiisueno = iQiisueno;
    }
    /**
     * @return the eRefNoa01
     */
    public String geteRefNoa01() {
        return eRefNoa01;
    }
    /**
     * @param eRefNoa01 the eRefNoa01 to set
     */
    public void seteRefNoa01(String eRefNoa01) {
        this.eRefNoa01 = eRefNoa01;
    }
    /**
     * @return the eRefNoa02
     */
    public String geteRefNoa02() {
        return eRefNoa02;
    }
    /**
     * @param eRefNoa02 the eRefNoa02 to set
     */
    public void seteRefNoa02(String eRefNoa02) {
        this.eRefNoa02 = eRefNoa02;
    }
    /**
     * @return the eRefNoa03
     */
    public String geteRefNoa03() {
        return eRefNoa03;
    }
    /**
     * @param eRefNoa03 the eRefNoa03 to set
     */
    public void seteRefNoa03(String eRefNoa03) {
        this.eRefNoa03 = eRefNoa03;
    }
    /**
     * @return the eRefNoa04
     */
    public String geteRefNoa04() {
        return eRefNoa04;
    }
    /**
     * @param eRefNoa04 the eRefNoa04 to set
     */
    public void seteRefNoa04(String eRefNoa04) {
        this.eRefNoa04 = eRefNoa04;
    }
    /**
     * @return the eRefNoa05
     */
    public String geteRefNoa05() {
        return eRefNoa05;
    }
    /**
     * @param eRefNoa05 the eRefNoa05 to set
     */
    public void seteRefNoa05(String eRefNoa05) {
        this.eRefNoa05 = eRefNoa05;
    }
    /**
     * @return the eRefNoa06
     */
    public String geteRefNoa06() {
        return eRefNoa06;
    }
    /**
     * @param eRefNoa06 the eRefNoa06 to set
     */
    public void seteRefNoa06(String eRefNoa06) {
        this.eRefNoa06 = eRefNoa06;
    }
    /**
     * @return the eRefNoa07
     */
    public String geteRefNoa07() {
        return eRefNoa07;
    }
    /**
     * @param eRefNoa07 the eRefNoa07 to set
     */
    public void seteRefNoa07(String eRefNoa07) {
        this.eRefNoa07 = eRefNoa07;
    }
    /**
     * @return the eRefNoa08
     */
    public String geteRefNoa08() {
        return eRefNoa08;
    }
    /**
     * @param eRefNoa08 the eRefNoa08 to set
     */
    public void seteRefNoa08(String eRefNoa08) {
        this.eRefNoa08 = eRefNoa08;
    }
    /**
     * @return the eRefNoa09
     */
    public String geteRefNoa09() {
        return eRefNoa09;
    }
    /**
     * @param eRefNoa09 the eRefNoa09 to set
     */
    public void seteRefNoa09(String eRefNoa09) {
        this.eRefNoa09 = eRefNoa09;
    }
    /**
     * @return the eRefNoa10
     */
    public String geteRefNoa10() {
        return eRefNoa10;
    }
    /**
     * @param eRefNoa10 the eRefNoa10 to set
     */
    public void seteRefNoa10(String eRefNoa10) {
        this.eRefNoa10 = eRefNoa10;
    }
    /**
     * @return the eZclano
     */
    public String geteZclano() {
        return eZclano;
    }
    /**
     * @param eZclano the eZclano to set
     */
    public void seteZclano(String eZclano) {
        this.eZclano = eZclano;
    }
    /**
     * @return the mandt
     */
    public String getMandt() {
        return mandt;
    }
    /**
     * @param mandt the mandt to set
     */
    public void setMandt(String mandt) {
        this.mandt = mandt;
    }
    /**
     * @return the zclano
     */
    public String getZclano() {
        return zclano;
    }
    /**
     * @param zclano the zclano to set
     */
    public void setZclano(String zclano) {
        this.zclano = zclano;
    }
    /**
     * @return the zclstatus
     */
    public String getZclstatus() {
        return zclstatus;
    }
    /**
     * @param zclstatus the zclstatus to set
     */
    public void setZclstatus(String zclstatus) {
        this.zclstatus = zclstatus;
    }
    /**
     * @return the zcltype
     */
    public String getZcltype() {
        return zcltype;
    }
    /**
     * @param zcltype the zcltype to set
     */
    public void setZcltype(String zcltype) {
        this.zcltype = zcltype;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the vkbur
     */
    public String getVkbur() {
        return vkbur;
    }
    /**
     * @param vkbur the vkbur to set
     */
    public void setVkbur(String vkbur) {
        this.vkbur = vkbur;
    }
    /**
     * @return the vkgrp
     */
    public String getVkgrp() {
        return vkgrp;
    }
    /**
     * @param vkgrp the vkgrp to set
     */
    public void setVkgrp(String vkgrp) {
        this.vkgrp = vkgrp;
    }
    /**
     * @return the vkgrptext
     */
    public String getVkgrptext() {
        return vkgrptext;
    }
    /**
     * @param vkgrptext the vkgrptext to set
     */
    public void setVkgrptext(String vkgrptext) {
        this.vkgrptext = vkgrptext;
    }
    /**
     * @return the zdist
     */
    public String getZdist() {
        return zdist;
    }
    /**
     * @param zdist the zdist to set
     */
    public void setZdist(String zdist) {
        this.zdist = zdist;
    }
    /**
     * @return the zdistcno
     */
    public String getZdistcno() {
        return zdistcno;
    }
    /**
     * @param zdistcno the zdistcno to set
     */
    public void setZdistcno(String zdistcno) {
        this.zdistcno = zdistcno;
    }
    /**
     * @return the zsubdist
     */
    public String getZsubdist() {
        return zsubdist;
    }
    /**
     * @param zsubdist the zsubdist to set
     */
    public void setZsubdist(String zsubdist) {
        this.zsubdist = zsubdist;
    }
    /**
     * @return the zcopdc
     */
    public String getZcopdc() {
        return zcopdc;
    }
    /**
     * @param zcopdc the zcopdc to set
     */
    public void setZcopdc(String zcopdc) {
        this.zcopdc = zcopdc;
    }
    /**
     * @return the zsubbukrs
     */
    public String getZsubbukrs() {
        return zsubbukrs;
    }
    /**
     * @param zsubbukrs the zsubbukrs to set
     */
    public void setZsubbukrs(String zsubbukrs) {
        this.zsubbukrs = zsubbukrs;
    }
    /**
     * @return the bukrs
     */
    public String getBukrs() {
        return bukrs;
    }
    /**
     * @param bukrs the bukrs to set
     */
    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }
    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }
    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }
    /**
     * @return the site
     */
    public String getSite() {
        return site;
    }
    /**
     * @param site the site to set
     */
    public void setSite(String site) {
        this.site = site;
    }
    /**
     * @return the zsalesno
     */
    public String getZsalesno() {
        return zsalesno;
    }
    /**
     * @param zsalesno the zsalesno to set
     */
    public void setZsalesno(String zsalesno) {
        this.zsalesno = zsalesno;
    }
    /**
     * @return the zsorder
     */
    public String getZsorder() {
        return zsorder;
    }
    /**
     * @param zsorder the zsorder to set
     */
    public void setZsorder(String zsorder) {
        this.zsorder = zsorder;
    }
    /**
     * @return the zsorderitem
     */
    public String getZsorderitem() {
        return zsorderitem;
    }
    /**
     * @param zsorderitem the zsorderitem to set
     */
    public void setZsorderitem(String zsorderitem) {
        this.zsorderitem = zsorderitem;
    }
    /**
     * @return the zinvoice
     */
    public String getZinvoice() {
        return zinvoice;
    }
    /**
     * @param zinvoice the zinvoice to set
     */
    public void setZinvoice(String zinvoice) {
        this.zinvoice = zinvoice;
    }
    /**
     * @return the zcaseno
     */
    public String getZcaseno() {
        return zcaseno;
    }
    /**
     * @param zcaseno the zcaseno to set
     */
    public void setZcaseno(String zcaseno) {
        this.zcaseno = zcaseno;
    }
    /**
     * @return the zhk
     */
    public String getZhk() {
        return zhk;
    }
    /**
     * @param zhk the zhk to set
     */
    public void setZhk(String zhk) {
        this.zhk = zhk;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zpartgr
     */
    public String getZpartgr() {
        return zpartgr;
    }
    /**
     * @param zpartgr the zpartgr to set
     */
    public void setZpartgr(String zpartgr) {
        this.zpartgr = zpartgr;
    }
    /**
     * @return the cltype
     */
    public String getCltype() {
        return cltype;
    }
    /**
     * @param cltype the cltype to set
     */
    public void setCltype(String cltype) {
        this.cltype = cltype;
    }
    /**
     * @return the clcodegr
     */
    public String getClcodegr() {
        return clcodegr;
    }
    /**
     * @param clcodegr the clcodegr to set
     */
    public void setClcodegr(String clcodegr) {
        this.clcodegr = clcodegr;
    }
    /**
     * @return the clcode
     */
    public String getClcode() {
        return clcode;
    }
    /**
     * @param clcode the clcode to set
     */
    public void setClcode(String clcode) {
        this.clcode = clcode;
    }
    /**
     * @return the clqty
     */
    public BigDecimal getClqty() {
        return clqty;
    }
    /**
     * @param clqty the clqty to set
     */
    public void setClqty(BigDecimal clqty) {
        this.clqty = clqty;
    }
    /**
     * @return the lagme
     */
    public String getLagme() {
        return lagme;
    }
    /**
     * @param lagme the lagme to set
     */
    public void setLagme(String lagme) {
        this.lagme = lagme;
    }
    /**
     * @return the zpacklot
     */
    public String getZpacklot() {
        return zpacklot;
    }
    /**
     * @param zpacklot the zpacklot to set
     */
    public void setZpacklot(String zpacklot) {
        this.zpacklot = zpacklot;
    }
    /**
     * @return the zpackdate
     */
    public Date getZpackdate() {
        return zpackdate;
    }
    /**
     * @param zpackdate the zpackdate to set
     */
    public void setZpackdate(Date zpackdate) {
        this.zpackdate = zpackdate;
    }
    /**
     * @return the zinspcert
     */
    public String getZinspcert() {
        return zinspcert;
    }
    /**
     * @param zinspcert the zinspcert to set
     */
    public void setZinspcert(String zinspcert) {
        this.zinspcert = zinspcert;
    }
    /**
     * @return the zredocty
     */
    public String getZredocty() {
        return zredocty;
    }
    /**
     * @param zredocty the zredocty to set
     */
    public void setZredocty(String zredocty) {
        this.zredocty = zredocty;
    }
    /**
     * @return the zredocno
     */
    public String getZredocno() {
        return zredocno;
    }
    /**
     * @param zredocno the zredocno to set
     */
    public void setZredocno(String zredocno) {
        this.zredocno = zredocno;
    }
    /**
     * @return the zrefdocno
     */
    public String getZrefdocno() {
        return zrefdocno;
    }
    /**
     * @param zrefdocno the zrefdocno to set
     */
    public void setZrefdocno(String zrefdocno) {
        this.zrefdocno = zrefdocno;
    }
    /**
     * @return the ztggprdate
     */
    public Date getZtggprdate() {
        return ztggprdate;
    }
    /**
     * @param ztggprdate the ztggprdate to set
     */
    public void setZtggprdate(Date ztggprdate) {
        this.ztggprdate = ztggprdate;
    }
    /**
     * @return the ztggprtime
     */
    public Date getZtggprtime() {
        return ztggprtime;
    }
    /**
     * @param ztggprtime the ztggprtime to set
     */
    public void setZtggprtime(Date ztggprtime) {
        this.ztggprtime = ztggprtime;
    }
    /**
     * @return the zcrDe
     */
    public String getZcrDe() {
        return zcrDe;
    }
    /**
     * @param zcrDe the zcrDe to set
     */
    public void setZcrDe(String zcrDe) {
        this.zcrDe = zcrDe;
    }
    /**
     * @return the zreimty
     */
    public String getZreimty() {
        return zreimty;
    }
    /**
     * @param zreimty the zreimty to set
     */
    public void setZreimty(String zreimty) {
        this.zreimty = zreimty;
    }
    /**
     * @return the ztransty
     */
    public String getZtransty() {
        return ztransty;
    }
    /**
     * @param ztransty the ztransty to set
     */
    public void setZtransty(String ztransty) {
        this.ztransty = ztransty;
    }
    /**
     * @return the zunitprice
     */
    public BigDecimal getZunitprice() {
        return zunitprice;
    }
    /**
     * @param zunitprice the zunitprice to set
     */
    public void setZunitprice(BigDecimal zunitprice) {
        this.zunitprice = zunitprice;
    }
    /**
     * @return the zunitpricecu
     */
    public String getZunitpricecu() {
        return zunitpricecu;
    }
    /**
     * @param zunitpricecu the zunitpricecu to set
     */
    public void setZunitpricecu(String zunitpricecu) {
        this.zunitpricecu = zunitpricecu;
    }
    /**
     * @return the zexunitpri
     */
    public String getZexunitpri() {
        return zexunitpri;
    }
    /**
     * @param zexunitpri the zexunitpri to set
     */
    public void setZexunitpri(String zexunitpri) {
        this.zexunitpri = zexunitpri;
    }
    /**
     * @return the zmakeupRate
     */
    public BigDecimal getZmakeupRate() {
        return zmakeupRate;
    }
    /**
     * @param zmakeupRate the zmakeupRate to set
     */
    public void setZmakeupRate(BigDecimal zmakeupRate) {
        this.zmakeupRate = zmakeupRate;
    }
    /**
     * @return the zmarkrate
     */
    public BigDecimal getZmarkrate() {
        return zmarkrate;
    }
    /**
     * @param zmarkrate the zmarkrate to set
     */
    public void setZmarkrate(BigDecimal zmarkrate) {
        this.zmarkrate = zmarkrate;
    }
    /**
     * @return the zmvavpri
     */
    public BigDecimal getZmvavpri() {
        return zmvavpri;
    }
    /**
     * @param zmvavpri the zmvavpri to set
     */
    public void setZmvavpri(BigDecimal zmvavpri) {
        this.zmvavpri = zmvavpri;
    }
    /**
     * @return the zaddamo1
     */
    public BigDecimal getZaddamo1() {
        return zaddamo1;
    }
    /**
     * @param zaddamo1 the zaddamo1 to set
     */
    public void setZaddamo1(BigDecimal zaddamo1) {
        this.zaddamo1 = zaddamo1;
    }
    /**
     * @return the zaddamo2
     */
    public BigDecimal getZaddamo2() {
        return zaddamo2;
    }
    /**
     * @param zaddamo2 the zaddamo2 to set
     */
    public void setZaddamo2(BigDecimal zaddamo2) {
        this.zaddamo2 = zaddamo2;
    }
    /**
     * @return the ztotamo
     */
    public BigDecimal getZtotamo() {
        return ztotamo;
    }
    /**
     * @param ztotamo the ztotamo to set
     */
    public void setZtotamo(BigDecimal ztotamo) {
        this.ztotamo = ztotamo;
    }
    /**
     * @return the ztotamocu
     */
    public String getZtotamocu() {
        return ztotamocu;
    }
    /**
     * @param ztotamocu the ztotamocu to set
     */
    public void setZtotamocu(String ztotamocu) {
        this.ztotamocu = ztotamocu;
    }
    /**
     * @return the ztotamok
     */
    public BigDecimal getZtotamok() {
        return ztotamok;
    }
    /**
     * @param ztotamok the ztotamok to set
     */
    public void setZtotamok(BigDecimal ztotamok) {
        this.ztotamok = ztotamok;
    }
    /**
     * @return the ztotamokcu
     */
    public String getZtotamokcu() {
        return ztotamokcu;
    }
    /**
     * @param ztotamokcu the ztotamokcu to set
     */
    public void setZtotamokcu(String ztotamokcu) {
        this.ztotamokcu = ztotamokcu;
    }
    /**
     * @return the zcomment
     */
    public String getZcomment() {
        return zcomment;
    }
    /**
     * @param zcomment the zcomment to set
     */
    public void setZcomment(String zcomment) {
        this.zcomment = zcomment;
    }
    /**
     * @return the zlatype
     */
    public String getZlatype() {
        return zlatype;
    }
    /**
     * @param zlatype the zlatype to set
     */
    public void setZlatype(String zlatype) {
        this.zlatype = zlatype;
    }
    /**
     * @return the zsuppM
     */
    public String getZsuppM() {
        return zsuppM;
    }
    /**
     * @param zsuppM the zsuppM to set
     */
    public void setZsuppM(String zsuppM) {
        this.zsuppM = zsuppM;
    }
    /**
     * @return the zsuppP
     */
    public String getZsuppP() {
        return zsuppP;
    }
    /**
     * @param zsuppP the zsuppP to set
     */
    public void setZsuppP(String zsuppP) {
        this.zsuppP = zsuppP;
    }
    /**
     * @return the zsuppS
     */
    public String getZsuppS() {
        return zsuppS;
    }
    /**
     * @param zsuppS the zsuppS to set
     */
    public void setZsuppS(String zsuppS) {
        this.zsuppS = zsuppS;
    }
    /**
     * @return the zsuppR
     */
    public String getZsuppR() {
        return zsuppR;
    }
    /**
     * @param zsuppR the zsuppR to set
     */
    public void setZsuppR(String zsuppR) {
        this.zsuppR = zsuppR;
    }
    /**
     * @return the zjuSubclanoh
     */
    public String getZjuSubclanoh() {
        return zjuSubclanoh;
    }
    /**
     * @param zjuSubclanoh the zjuSubclanoh to set
     */
    public void setZjuSubclanoh(String zjuSubclanoh) {
        this.zjuSubclanoh = zjuSubclanoh;
    }
    /**
     * @return the zreclanoCy
     */
    public String getZreclanoCy() {
        return zreclanoCy;
    }
    /**
     * @param zreclanoCy the zreclanoCy to set
     */
    public void setZreclanoCy(String zreclanoCy) {
        this.zreclanoCy = zreclanoCy;
    }
    /**
     * @return the zsubmdate
     */
    public Date getZsubmdate() {
        return zsubmdate;
    }
    /**
     * @param zsubmdate the zsubmdate to set
     */
    public void setZsubmdate(Date zsubmdate) {
        this.zsubmdate = zsubmdate;
    }
    /**
     * @return the zsubmtime
     */
    public Date getZsubmtime() {
        return zsubmtime;
    }
    /**
     * @param zsubmtime the zsubmtime to set
     */
    public void setZsubmtime(Date zsubmtime) {
        this.zsubmtime = zsubmtime;
    }
    /**
     * @return the zsubmby
     */
    public String getZsubmby() {
        return zsubmby;
    }
    /**
     * @param zsubmby the zsubmby to set
     */
    public void setZsubmby(String zsubmby) {
        this.zsubmby = zsubmby;
    }
    /**
     * @return the zcan
     */
    public String getZcan() {
        return zcan;
    }
    /**
     * @param zcan the zcan to set
     */
    public void setZcan(String zcan) {
        this.zcan = zcan;
    }
    /**
     * @return the zcandate
     */
    public Date getZcandate() {
        return zcandate;
    }
    /**
     * @param zcandate the zcandate to set
     */
    public void setZcandate(Date zcandate) {
        this.zcandate = zcandate;
    }
    /**
     * @return the zcantime
     */
    public Date getZcantime() {
        return zcantime;
    }
    /**
     * @param zcantime the zcantime to set
     */
    public void setZcantime(Date zcantime) {
        this.zcantime = zcantime;
    }
    /**
     * @return the zcanby
     */
    public String getZcanby() {
        return zcanby;
    }
    /**
     * @param zcanby the zcanby to set
     */
    public void setZcanby(String zcanby) {
        this.zcanby = zcanby;
    }
    /**
     * @return the zattamt1Fscode
     */
    public String getZattamt1Fscode() {
        return zattamt1Fscode;
    }
    /**
     * @param zattamt1Fscode the zattamt1Fscode to set
     */
    public void setZattamt1Fscode(String zattamt1Fscode) {
        this.zattamt1Fscode = zattamt1Fscode;
    }
    /**
     * @return the zattamt1RefNo
     */
    public String getZattamt1RefNo() {
        return zattamt1RefNo;
    }
    /**
     * @param zattamt1RefNo the zattamt1RefNo to set
     */
    public void setZattamt1RefNo(String zattamt1RefNo) {
        this.zattamt1RefNo = zattamt1RefNo;
    }
    /**
     * @return the zattamt1
     */
    public String getZattamt1() {
        return zattamt1;
    }
    /**
     * @param zattamt1 the zattamt1 to set
     */
    public void setZattamt1(String zattamt1) {
        this.zattamt1 = zattamt1;
    }
    /**
     * @return the zattamt1Fname
     */
    public String getZattamt1Fname() {
        return zattamt1Fname;
    }
    /**
     * @param zattamt1Fname the zattamt1Fname to set
     */
    public void setZattamt1Fname(String zattamt1Fname) {
        this.zattamt1Fname = zattamt1Fname;
    }
    /**
     * @return the zattamt2Fscode
     */
    public String getZattamt2Fscode() {
        return zattamt2Fscode;
    }
    /**
     * @param zattamt2Fscode the zattamt2Fscode to set
     */
    public void setZattamt2Fscode(String zattamt2Fscode) {
        this.zattamt2Fscode = zattamt2Fscode;
    }
    /**
     * @return the zattamt2RefNo
     */
    public String getZattamt2RefNo() {
        return zattamt2RefNo;
    }
    /**
     * @param zattamt2RefNo the zattamt2RefNo to set
     */
    public void setZattamt2RefNo(String zattamt2RefNo) {
        this.zattamt2RefNo = zattamt2RefNo;
    }
    /**
     * @return the zattamt2
     */
    public String getZattamt2() {
        return zattamt2;
    }
    /**
     * @param zattamt2 the zattamt2 to set
     */
    public void setZattamt2(String zattamt2) {
        this.zattamt2 = zattamt2;
    }
    /**
     * @return the zattamt2Fname
     */
    public String getZattamt2Fname() {
        return zattamt2Fname;
    }
    /**
     * @param zattamt2Fname the zattamt2Fname to set
     */
    public void setZattamt2Fname(String zattamt2Fname) {
        this.zattamt2Fname = zattamt2Fname;
    }
    /**
     * @return the zrestdt
     */
    public Date getZrestdt() {
        return zrestdt;
    }
    /**
     * @param zrestdt the zrestdt to set
     */
    public void setZrestdt(Date zrestdt) {
        this.zrestdt = zrestdt;
    }
    /**
     * @return the zatt1Fscode
     */
    public String getZatt1Fscode() {
        return zatt1Fscode;
    }
    /**
     * @param zatt1Fscode the zatt1Fscode to set
     */
    public void setZatt1Fscode(String zatt1Fscode) {
        this.zatt1Fscode = zatt1Fscode;
    }
    /**
     * @return the zatt1RefNo
     */
    public String getZatt1RefNo() {
        return zatt1RefNo;
    }
    /**
     * @param zatt1RefNo the zatt1RefNo to set
     */
    public void setZatt1RefNo(String zatt1RefNo) {
        this.zatt1RefNo = zatt1RefNo;
    }
    /**
     * @return the zatt1
     */
    public String getZatt1() {
        return zatt1;
    }
    /**
     * @param zatt1 the zatt1 to set
     */
    public void setZatt1(String zatt1) {
        this.zatt1 = zatt1;
    }
    /**
     * @return the zatt1Fname
     */
    public String getZatt1Fname() {
        return zatt1Fname;
    }
    /**
     * @param zatt1Fname the zatt1Fname to set
     */
    public void setZatt1Fname(String zatt1Fname) {
        this.zatt1Fname = zatt1Fname;
    }
    /**
     * @return the zatt2Fscode
     */
    public String getZatt2Fscode() {
        return zatt2Fscode;
    }
    /**
     * @param zatt2Fscode the zatt2Fscode to set
     */
    public void setZatt2Fscode(String zatt2Fscode) {
        this.zatt2Fscode = zatt2Fscode;
    }
    /**
     * @return the zatt2RefNo
     */
    public String getZatt2RefNo() {
        return zatt2RefNo;
    }
    /**
     * @param zatt2RefNo the zatt2RefNo to set
     */
    public void setZatt2RefNo(String zatt2RefNo) {
        this.zatt2RefNo = zatt2RefNo;
    }
    /**
     * @return the zatt2
     */
    public String getZatt2() {
        return zatt2;
    }
    /**
     * @param zatt2 the zatt2 to set
     */
    public void setZatt2(String zatt2) {
        this.zatt2 = zatt2;
    }
    /**
     * @return the zatt2Fname
     */
    public String getZatt2Fname() {
        return zatt2Fname;
    }
    /**
     * @param zatt2Fname the zatt2Fname to set
     */
    public void setZatt2Fname(String zatt2Fname) {
        this.zatt2Fname = zatt2Fname;
    }
    /**
     * @return the zatt3Fscode
     */
    public String getZatt3Fscode() {
        return zatt3Fscode;
    }
    /**
     * @param zatt3Fscode the zatt3Fscode to set
     */
    public void setZatt3Fscode(String zatt3Fscode) {
        this.zatt3Fscode = zatt3Fscode;
    }
    /**
     * @return the zatt3RefNo
     */
    public String getZatt3RefNo() {
        return zatt3RefNo;
    }
    /**
     * @param zatt3RefNo the zatt3RefNo to set
     */
    public void setZatt3RefNo(String zatt3RefNo) {
        this.zatt3RefNo = zatt3RefNo;
    }
    /**
     * @return the zatt3
     */
    public String getZatt3() {
        return zatt3;
    }
    /**
     * @param zatt3 the zatt3 to set
     */
    public void setZatt3(String zatt3) {
        this.zatt3 = zatt3;
    }
    /**
     * @return the zatt3Fname
     */
    public String getZatt3Fname() {
        return zatt3Fname;
    }
    /**
     * @param zatt3Fname the zatt3Fname to set
     */
    public void setZatt3Fname(String zatt3Fname) {
        this.zatt3Fname = zatt3Fname;
    }
    /**
     * @return the zatt4Fscode
     */
    public String getZatt4Fscode() {
        return zatt4Fscode;
    }
    /**
     * @param zatt4Fscode the zatt4Fscode to set
     */
    public void setZatt4Fscode(String zatt4Fscode) {
        this.zatt4Fscode = zatt4Fscode;
    }
    /**
     * @return the zatt4RefNo
     */
    public String getZatt4RefNo() {
        return zatt4RefNo;
    }
    /**
     * @param zatt4RefNo the zatt4RefNo to set
     */
    public void setZatt4RefNo(String zatt4RefNo) {
        this.zatt4RefNo = zatt4RefNo;
    }
    /**
     * @return the zatt4
     */
    public String getZatt4() {
        return zatt4;
    }
    /**
     * @param zatt4 the zatt4 to set
     */
    public void setZatt4(String zatt4) {
        this.zatt4 = zatt4;
    }
    /**
     * @return the zatt4Fname
     */
    public String getZatt4Fname() {
        return zatt4Fname;
    }
    /**
     * @param zatt4Fname the zatt4Fname to set
     */
    public void setZatt4Fname(String zatt4Fname) {
        this.zatt4Fname = zatt4Fname;
    }
    /**
     * @return the zpacklotYr
     */
    public String getZpacklotYr() {
        return zpacklotYr;
    }
    /**
     * @param zpacklotYr the zpacklotYr to set
     */
    public void setZpacklotYr(String zpacklotYr) {
        this.zpacklotYr = zpacklotYr;
    }
    /**
     * @return the zpacklotMon
     */
    public String getZpacklotMon() {
        return zpacklotMon;
    }
    /**
     * @param zpacklotMon the zpacklotMon to set
     */
    public void setZpacklotMon(String zpacklotMon) {
        this.zpacklotMon = zpacklotMon;
    }
    /**
     * @return the zpacklotDay
     */
    public String getZpacklotDay() {
        return zpacklotDay;
    }
    /**
     * @param zpacklotDay the zpacklotDay to set
     */
    public void setZpacklotDay(String zpacklotDay) {
        this.zpacklotDay = zpacklotDay;
    }
    /**
     * @return the zdeGbkyn
     */
    public String getZdeGbkyn() {
        return zdeGbkyn;
    }
    /**
     * @param zdeGbkyn the zdeGbkyn to set
     */
    public void setZdeGbkyn(String zdeGbkyn) {
        this.zdeGbkyn = zdeGbkyn;
    }
    /**
     * @return the zdeSnddt
     */
    public Date getZdeSnddt() {
        return zdeSnddt;
    }
    /**
     * @param zdeSnddt the zdeSnddt to set
     */
    public void setZdeSnddt(Date zdeSnddt) {
        this.zdeSnddt = zdeSnddt;
    }
    /**
     * @return the zdeRcvdt
     */
    public Date getZdeRcvdt() {
        return zdeRcvdt;
    }
    /**
     * @param zdeRcvdt the zdeRcvdt to set
     */
    public void setZdeRcvdt(Date zdeRcvdt) {
        this.zdeRcvdt = zdeRcvdt;
    }
    /**
     * @return the zhmcMip
     */
    public String getZhmcMip() {
        return zhmcMip;
    }
    /**
     * @param zhmcMip the zhmcMip to set
     */
    public void setZhmcMip(String zhmcMip) {
        this.zhmcMip = zhmcMip;
    }
    /**
     * @return the zreorder
     */
    public String getZreorder() {
        return zreorder;
    }
    /**
     * @param zreorder the zreorder to set
     */
    public void setZreorder(String zreorder) {
        this.zreorder = zreorder;
    }
    /**
     * @return the zkit
     */
    public String getZkit() {
        return zkit;
    }
    /**
     * @param zkit the zkit to set
     */
    public void setZkit(String zkit) {
        this.zkit = zkit;
    }
    /**
     * @return the zasisClaimno
     */
    public String getZasisClaimno() {
        return zasisClaimno;
    }
    /**
     * @param zasisClaimno the zasisClaimno to set
     */
    public void setZasisClaimno(String zasisClaimno) {
        this.zasisClaimno = zasisClaimno;
    }
    /**
     * @return the zchcreate
     */
    public Date getZchcreate() {
        return zchcreate;
    }
    /**
     * @param zchcreate the zchcreate to set
     */
    public void setZchcreate(Date zchcreate) {
        this.zchcreate = zchcreate;
    }
    /**
     * @return the zchcrtime
     */
    public Date getZchcrtime() {
        return zchcrtime;
    }
    /**
     * @param zchcrtime the zchcrtime to set
     */
    public void setZchcrtime(Date zchcrtime) {
        this.zchcrtime = zchcrtime;
    }
    /**
     * @return the zchcrid
     */
    public String getZchcrid() {
        return zchcrid;
    }
    /**
     * @param zchcrid the zchcrid to set
     */
    public void setZchcrid(String zchcrid) {
        this.zchcrid = zchcrid;
    }
    /**
     * @return the zchcridname
     */
    public String getZchcridname() {
        return zchcridname;
    }
    /**
     * @param zchcridname the zchcridname to set
     */
    public void setZchcridname(String zchcridname) {
        this.zchcridname = zchcridname;
    }
    /**
     * @return the zsubmbyname
     */
    public String getZsubmbyname() {
        return zsubmbyname;
    }
    /**
     * @param zsubmbyname the zsubmbyname to set
     */
    public void setZsubmbyname(String zsubmbyname) {
        this.zsubmbyname = zsubmbyname;
    }
    /**
     * @return the zcanbyname
     */
    public String getZcanbyname() {
        return zcanbyname;
    }
    /**
     * @param zcanbyname the zcanbyname to set
     */
    public void setZcanbyname(String zcanbyname) {
        this.zcanbyname = zcanbyname;
    }
    /**
     * @return the docNumber
     */
    public String getDocNumber() {
        return docNumber;
    }
    /**
     * @param docNumber the docNumber to set
     */
    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }
    /**
     * @return the itemNo
     */
    public String getItemNo() {
        return itemNo;
    }
    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(String itemNo) {
        this.itemNo = itemNo;
    }
    /**
     * @return the docYear
     */
    public String getDocYear() {
        return docYear;
    }
    /**
     * @param docYear the docYear to set
     */
    public void setDocYear(String docYear) {
        this.docYear = docYear;
    }
    /**
     * @return the zudname
     */
    public String getZudname() {
        return zudname;
    }
    /**
     * @param zudname the zudname to set
     */
    public void setZudname(String zudname) {
        this.zudname = zudname;
    }
    /**
     * @return the zudsdate
     */
    public Date getZudsdate() {
        return zudsdate;
    }
    /**
     * @param zudsdate the zudsdate to set
     */
    public void setZudsdate(Date zudsdate) {
        this.zudsdate = zudsdate;
    }
    /**
     * @return the zudstime
     */
    public Date getZudstime() {
        return zudstime;
    }
    /**
     * @param zudstime the zudstime to set
     */
    public void setZudstime(Date zudstime) {
        this.zudstime = zudstime;
    }
    /**
     * @return the zudldate
     */
    public Date getZudldate() {
        return zudldate;
    }
    /**
     * @param zudldate the zudldate to set
     */
    public void setZudldate(Date zudldate) {
        this.zudldate = zudldate;
    }
    /**
     * @return the zudltime
     */
    public Date getZudltime() {
        return zudltime;
    }
    /**
     * @param zudltime the zudltime to set
     */
    public void setZudltime(Date zudltime) {
        this.zudltime = zudltime;
    }
    /**
     * @return the zonlo
     */
    public String getZonlo() {
        return zonlo;
    }
    /**
     * @param zonlo the zonlo to set
     */
    public void setZonlo(String zonlo) {
        this.zonlo = zonlo;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the zjuResult
     */
    public String getZjuResult() {
        return zjuResult;
    }
    /**
     * @param zjuResult the zjuResult to set
     */
    public void setZjuResult(String zjuResult) {
        this.zjuResult = zjuResult;
    }
    /**
     * @return the zjuResultx
     */
    public String getZjuResultx() {
        return zjuResultx;
    }
    /**
     * @param zjuResultx the zjuResultx to set
     */
    public void setZjuResultx(String zjuResultx) {
        this.zjuResultx = zjuResultx;
    }
    /**
     * @return the zjuRecode
     */
    public String getZjuRecode() {
        return zjuRecode;
    }
    /**
     * @param zjuRecode the zjuRecode to set
     */
    public void setZjuRecode(String zjuRecode) {
        this.zjuRecode = zjuRecode;
    }
    /**
     * @return the zjuRecodeName
     */
    public String getZjuRecodeName() {
        return zjuRecodeName;
    }
    /**
     * @param zjuRecodeName the zjuRecodeName to set
     */
    public void setZjuRecodeName(String zjuRecodeName) {
        this.zjuRecodeName = zjuRecodeName;
    }
    /**
     * @return the zjuClcode
     */
    public String getZjuClcode() {
        return zjuClcode;
    }
    /**
     * @param zjuClcode the zjuClcode to set
     */
    public void setZjuClcode(String zjuClcode) {
        this.zjuClcode = zjuClcode;
    }
    /**
     * @return the zjuClcodeName
     */
    public String getZjuClcodeName() {
        return zjuClcodeName;
    }
    /**
     * @param zjuClcodeName the zjuClcodeName to set
     */
    public void setZjuClcodeName(String zjuClcodeName) {
        this.zjuClcodeName = zjuClcodeName;
    }
    /**
     * @return the zjuQty
     */
    public String getZjuQty() {
        return zjuQty;
    }
    /**
     * @param zjuQty the zjuQty to set
     */
    public void setZjuQty(String zjuQty) {
        this.zjuQty = zjuQty;
    }
    /**
     * @return the zjuQtyunit
     */
    public String getZjuQtyunit() {
        return zjuQtyunit;
    }
    /**
     * @param zjuQtyunit the zjuQtyunit to set
     */
    public void setZjuQtyunit(String zjuQtyunit) {
        this.zjuQtyunit = zjuQtyunit;
    }
    /**
     * @return the zjuActy
     */
    public String getZjuActy() {
        return zjuActy;
    }
    /**
     * @param zjuActy the zjuActy to set
     */
    public void setZjuActy(String zjuActy) {
        this.zjuActy = zjuActy;
    }
    /**
     * @return the zjuActyName
     */
    public String getZjuActyName() {
        return zjuActyName;
    }
    /**
     * @param zjuActyName the zjuActyName to set
     */
    public void setZjuActyName(String zjuActyName) {
        this.zjuActyName = zjuActyName;
    }
    /**
     * @return the zjuFotyp
     */
    public String getZjuFotyp() {
        return zjuFotyp;
    }
    /**
     * @param zjuFotyp the zjuFotyp to set
     */
    public void setZjuFotyp(String zjuFotyp) {
        this.zjuFotyp = zjuFotyp;
    }
    /**
     * @return the zjuFotypeName
     */
    public String getZjuFotypeName() {
        return zjuFotypeName;
    }
    /**
     * @param zjuFotypeName the zjuFotypeName to set
     */
    public void setZjuFotypeName(String zjuFotypeName) {
        this.zjuFotypeName = zjuFotypeName;
    }
    /**
     * @return the zjuFoact
     */
    public String getZjuFoact() {
        return zjuFoact;
    }
    /**
     * @param zjuFoact the zjuFoact to set
     */
    public void setZjuFoact(String zjuFoact) {
        this.zjuFoact = zjuFoact;
    }
    /**
     * @return the zjuFoactName
     */
    public String getZjuFoactName() {
        return zjuFoactName;
    }
    /**
     * @param zjuFoactName the zjuFoactName to set
     */
    public void setZjuFoactName(String zjuFoactName) {
        this.zjuFoactName = zjuFoactName;
    }
    /**
     * @return the zjuScrapchk
     */
    public String getZjuScrapchk() {
        return zjuScrapchk;
    }
    /**
     * @param zjuScrapchk the zjuScrapchk to set
     */
    public void setZjuScrapchk(String zjuScrapchk) {
        this.zjuScrapchk = zjuScrapchk;
    }
    /**
     * @return the zjuScrapsdat
     */
    public Date getZjuScrapsdat() {
        return zjuScrapsdat;
    }
    /**
     * @param zjuScrapsdat the zjuScrapsdat to set
     */
    public void setZjuScrapsdat(Date zjuScrapsdat) {
        this.zjuScrapsdat = zjuScrapsdat;
    }
    /**
     * @return the zjuFocnohChk
     */
    public String getZjuFocnohChk() {
        return zjuFocnohChk;
    }
    /**
     * @param zjuFocnohChk the zjuFocnohChk to set
     */
    public void setZjuFocnohChk(String zjuFocnohChk) {
        this.zjuFocnohChk = zjuFocnohChk;
    }
    /**
     * @return the zjuFocnoh
     */
    public String getZjuFocnoh() {
        return zjuFocnoh;
    }
    /**
     * @param zjuFocnoh the zjuFocnoh to set
     */
    public void setZjuFocnoh(String zjuFocnoh) {
        this.zjuFocnoh = zjuFocnoh;
    }
    /**
     * @return the zjuLatype
     */
    public String getZjuLatype() {
        return zjuLatype;
    }
    /**
     * @param zjuLatype the zjuLatype to set
     */
    public void setZjuLatype(String zjuLatype) {
        this.zjuLatype = zjuLatype;
    }
    /**
     * @return the zjuLatypex
     */
    public String getZjuLatypex() {
        return zjuLatypex;
    }
    /**
     * @param zjuLatypex the zjuLatypex to set
     */
    public void setZjuLatypex(String zjuLatypex) {
        this.zjuLatypex = zjuLatypex;
    }
    /**
     * @return the zjuLasup
     */
    public String getZjuLasup() {
        return zjuLasup;
    }
    /**
     * @param zjuLasup the zjuLasup to set
     */
    public void setZjuLasup(String zjuLasup) {
        this.zjuLasup = zjuLasup;
    }
    /**
     * @return the zjuLasupx
     */
    public String getZjuLasupx() {
        return zjuLasupx;
    }
    /**
     * @param zjuLasupx the zjuLasupx to set
     */
    public void setZjuLasupx(String zjuLasupx) {
        this.zjuLasupx = zjuLasupx;
    }
    /**
     * @return the zjuComment
     */
    public String getZjuComment() {
        return zjuComment;
    }
    /**
     * @param zjuComment the zjuComment to set
     */
    public void setZjuComment(String zjuComment) {
        this.zjuComment = zjuComment;
    }
    /**
     * @return the zjuOcost
     */
    public String getZjuOcost() {
        return zjuOcost;
    }
    /**
     * @param zjuOcost the zjuOcost to set
     */
    public void setZjuOcost(String zjuOcost) {
        this.zjuOcost = zjuOcost;
    }
    /**
     * @return the zjuOcostcur
     */
    public String getZjuOcostcur() {
        return zjuOcostcur;
    }
    /**
     * @param zjuOcostcur the zjuOcostcur to set
     */
    public void setZjuOcostcur(String zjuOcostcur) {
        this.zjuOcostcur = zjuOcostcur;
    }
    /**
     * @return the zjuAdtype
     */
    public String getZjuAdtype() {
        return zjuAdtype;
    }
    /**
     * @param zjuAdtype the zjuAdtype to set
     */
    public void setZjuAdtype(String zjuAdtype) {
        this.zjuAdtype = zjuAdtype;
    }
    /**
     * @return the zjuAdcost
     */
    public String getZjuAdcost() {
        return zjuAdcost;
    }
    /**
     * @param zjuAdcost the zjuAdcost to set
     */
    public void setZjuAdcost(String zjuAdcost) {
        this.zjuAdcost = zjuAdcost;
    }
    /**
     * @return the zjuAdcostcur
     */
    public String getZjuAdcostcur() {
        return zjuAdcostcur;
    }
    /**
     * @param zjuAdcostcur the zjuAdcostcur to set
     */
    public void setZjuAdcostcur(String zjuAdcostcur) {
        this.zjuAdcostcur = zjuAdcostcur;
    }
    /**
     * @return the zjuAdcomt
     */
    public String getZjuAdcomt() {
        return zjuAdcomt;
    }
    /**
     * @param zjuAdcomt the zjuAdcomt to set
     */
    public void setZjuAdcomt(String zjuAdcomt) {
        this.zjuAdcomt = zjuAdcomt;
    }
    /**
     * @return the zjuTotalrecost
     */
    public String getZjuTotalrecost() {
        return zjuTotalrecost;
    }
    /**
     * @param zjuTotalrecost the zjuTotalrecost to set
     */
    public void setZjuTotalrecost(String zjuTotalrecost) {
        this.zjuTotalrecost = zjuTotalrecost;
    }
    /**
     * @return the zjuTotalrecostcur
     */
    public String getZjuTotalrecostcur() {
        return zjuTotalrecostcur;
    }
    /**
     * @param zjuTotalrecostcur the zjuTotalrecostcur to set
     */
    public void setZjuTotalrecostcur(String zjuTotalrecostcur) {
        this.zjuTotalrecostcur = zjuTotalrecostcur;
    }
    /**
     * @return the zncrno
     */
    public String getZncrno() {
        return zncrno;
    }
    /**
     * @param zncrno the zncrno to set
     */
    public void setZncrno(String zncrno) {
        this.zncrno = zncrno;
    }
    /**
     * @return the zscStdformFscode
     */
    public String getZscStdformFscode() {
        return zscStdformFscode;
    }
    /**
     * @param zscStdformFscode the zscStdformFscode to set
     */
    public void setZscStdformFscode(String zscStdformFscode) {
        this.zscStdformFscode = zscStdformFscode;
    }
    /**
     * @return the zscStdformRefNo
     */
    public String getZscStdformRefNo() {
        return zscStdformRefNo;
    }
    /**
     * @param zscStdformRefNo the zscStdformRefNo to set
     */
    public void setZscStdformRefNo(String zscStdformRefNo) {
        this.zscStdformRefNo = zscStdformRefNo;
    }
    /**
     * @return the zscStdform
     */
    public String getZscStdform() {
        return zscStdform;
    }
    /**
     * @param zscStdform the zscStdform to set
     */
    public void setZscStdform(String zscStdform) {
        this.zscStdform = zscStdform;
    }
    /**
     * @return the zscStdformName
     */
    public String getZscStdformName() {
        return zscStdformName;
    }
    /**
     * @param zscStdformName the zscStdformName to set
     */
    public void setZscStdformName(String zscStdformName) {
        this.zscStdformName = zscStdformName;
    }
    /**
     * @return the zcuAtt1Fscode
     */
    public String getZcuAtt1Fscode() {
        return zcuAtt1Fscode;
    }
    /**
     * @param zcuAtt1Fscode the zcuAtt1Fscode to set
     */
    public void setZcuAtt1Fscode(String zcuAtt1Fscode) {
        this.zcuAtt1Fscode = zcuAtt1Fscode;
    }
    /**
     * @return the zcuAtt1RefNo
     */
    public String getZcuAtt1RefNo() {
        return zcuAtt1RefNo;
    }
    /**
     * @param zcuAtt1RefNo the zcuAtt1RefNo to set
     */
    public void setZcuAtt1RefNo(String zcuAtt1RefNo) {
        this.zcuAtt1RefNo = zcuAtt1RefNo;
    }
    /**
     * @return the zcuAtt1
     */
    public String getZcuAtt1() {
        return zcuAtt1;
    }
    /**
     * @param zcuAtt1 the zcuAtt1 to set
     */
    public void setZcuAtt1(String zcuAtt1) {
        this.zcuAtt1 = zcuAtt1;
    }
    /**
     * @return the zcuAtt1Name
     */
    public String getZcuAtt1Name() {
        return zcuAtt1Name;
    }
    /**
     * @param zcuAtt1Name the zcuAtt1Name to set
     */
    public void setZcuAtt1Name(String zcuAtt1Name) {
        this.zcuAtt1Name = zcuAtt1Name;
    }
    /**
     * @return the zcuAtt2Fscode
     */
    public String getZcuAtt2Fscode() {
        return zcuAtt2Fscode;
    }
    /**
     * @param zcuAtt2Fscode the zcuAtt2Fscode to set
     */
    public void setZcuAtt2Fscode(String zcuAtt2Fscode) {
        this.zcuAtt2Fscode = zcuAtt2Fscode;
    }
    /**
     * @return the zcuAtt2RefNo
     */
    public String getZcuAtt2RefNo() {
        return zcuAtt2RefNo;
    }
    /**
     * @param zcuAtt2RefNo the zcuAtt2RefNo to set
     */
    public void setZcuAtt2RefNo(String zcuAtt2RefNo) {
        this.zcuAtt2RefNo = zcuAtt2RefNo;
    }
    /**
     * @return the zcuAtt2
     */
    public String getZcuAtt2() {
        return zcuAtt2;
    }
    /**
     * @param zcuAtt2 the zcuAtt2 to set
     */
    public void setZcuAtt2(String zcuAtt2) {
        this.zcuAtt2 = zcuAtt2;
    }
    /**
     * @return the zcuAtt2Name
     */
    public String getZcuAtt2Name() {
        return zcuAtt2Name;
    }
    /**
     * @param zcuAtt2Name the zcuAtt2Name to set
     */
    public void setZcuAtt2Name(String zcuAtt2Name) {
        this.zcuAtt2Name = zcuAtt2Name;
    }
    /**
     * @return the zcrdate
     */
    public Date getZcrdate() {
        return zcrdate;
    }
    /**
     * @param zcrdate the zcrdate to set
     */
    public void setZcrdate(Date zcrdate) {
        this.zcrdate = zcrdate;
    }
    /**
     * @return the zcrtime
     */
    public Date getZcrtime() {
        return zcrtime;
    }
    /**
     * @param zcrtime the zcrtime to set
     */
    public void setZcrtime(Date zcrtime) {
        this.zcrtime = zcrtime;
    }
    /**
     * @return the zcrid
     */
    public String getZcrid() {
        return zcrid;
    }
    /**
     * @param zcrid the zcrid to set
     */
    public void setZcrid(String zcrid) {
        this.zcrid = zcrid;
    }
}
