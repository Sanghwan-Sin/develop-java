package com.mobis.maps.nmgn.qm.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : FormatDataVO.java
 * @Description : 양식 다운로드 관련 RFC 관련 공통 기능
 * @호출 RFC ID : ZPQM_CHNNL_S_FORMAT_DATA
 * @author DT060151
 * @since 2020. 3. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 31.     DT060151     	최초 생성
 * </pre>
 */

public class FormatDataVO extends MapsCommSapRfcIfCommVO{

    /** 프로그램명 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_BUKRS" )
    private String iBukrs;
    /** 회사코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_OBJ_NAME" )
    private String iObjName;
    /** 파일명 */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_FILE_NAME" )
    private String eFileName;
    /** FILE SEQ NO */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_FILE_SEQNO" )
    private String eFileSeqno;
    /** FILE SERVER ID */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_FSCODE" )
    private String eFscode;
    /** REFERENCE NUMBER */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_REF_NO" )
    private String eRefNo;
    
    
    /**
     * @return the iBukrs
     */
    public String getiBukrs() {
        return iBukrs;
    }
    /**
     * @param iBukrs the iBukrs to set
     */
    public void setiBukrs(String iBukrs) {
        this.iBukrs = iBukrs;
    }
    /**
     * @return the iObjName
     */
    public String getiObjName() {
        return iObjName;
    }
    /**
     * @param iObjName the iObjName to set
     */
    public void setiObjName(String iObjName) {
        this.iObjName = iObjName;
    }
    /**
     * @return the eFileName
     */
    public String geteFileName() {
        return eFileName;
    }
    /**
     * @param eFileName the eFileName to set
     */
    public void seteFileName(String eFileName) {
        this.eFileName = eFileName;
    }
    /**
     * @return the eFileSeqno
     */
    public String geteFileSeqno() {
        return eFileSeqno;
    }
    /**
     * @param eFileSeqno the eFileSeqno to set
     */
    public void seteFileSeqno(String eFileSeqno) {
        this.eFileSeqno = eFileSeqno;
    }
    /**
     * @return the eFscode
     */
    public String geteFscode() {
        return eFscode;
    }
    /**
     * @param eFscode the eFscode to set
     */
    public void seteFscode(String eFscode) {
        this.eFscode = eFscode;
    }
    /**
     * @return the eRefNo
     */
    public String geteRefNo() {
        return eRefNo;
    }
    /**
     * @param eRefNo the eRefNo to set
     */
    public void seteRefNo(String eRefNo) {
        this.eRefNo = eRefNo;
    }
    
    
}
