package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.ListPriceAdjFileDwnService;
import com.mobis.maps.nmgn.sd.vo.ListPriceAdjFileDwnVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ListPriceAdjFileDwnServiceImpl.java
 * @Description : ZJSDR20220 List Price Adjustment 파일 Download
 * @author 이수지
 * @since 2020. 01. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 01. 28.      이수지      	        최초 생성
 * </pre>
 */

@Service("listPriceAdjFileDwnService")
public class ListPriceAdjFileDwnServiceImpl extends HService implements ListPriceAdjFileDwnService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;

    /*
     * @see com.mobis.maps.nmgn.sd.service.ListPriceAdjFileDwnService#selectListPriceAdjFileDwn(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.ListPriceAdjFileDwnVO)
     */
    @Override
    public List<ListPriceAdjFileDwnVO> selectListPriceAdjFileDwn(LoginInfoVO loginVo, ListPriceAdjFileDwnVO params) throws Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_MGN_R_LIST_PRICE_ADJ_FILE;
        
        params.setIfCode(sapRfcInfo.getIfCode());

        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);

        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
        MapsRfcMappperUtil.setImportStructure(func, "IS_DATES", params);
                
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        MapsRfcMappperUtil.setExportParamList(funcRslt, params, loginVo.getUserLcale());
        
        //*** 조회결과
        List<ListPriceAdjFileDwnVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_RESULT", params, ListPriceAdjFileDwnVO.class);
        
        return list;
    }

}
