package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.vo.MapsCommSapAtchFileVO;
import com.mobis.maps.nmgn.sd.vo.OrderConfirmDownloadVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderConfirmDownloadService.java
 * @Description : Order Confirm Download
 * @author jiyongdo
 * @since 2020. 5. 8.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 8.     jiyongdo     	최초 생성
 * </pre>
 */

public interface OrderConfirmDownloadService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     * @throws Exception 
     */
    List<OrderConfirmDownloadVO> selectConfirmDownloadList(LoginInfoVO loginInfo, OrderConfirmDownloadVO params) throws Exception;

    
    /**
     * Order File Download (TXT 2 Excel)
     *
     * @param loginInfo
     * @param params
     * @param c
     * @return
     * @throws Exception
     */
    <T> List<T> selectOrderExcelDown(LoginInfoVO loginInfo, MapsCommSapAtchFileVO params, Class<? extends T> c) throws Exception;
}
