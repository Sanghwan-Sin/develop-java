package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.PromotionExportCeilingVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionExportCeilingService.java
 * @Description : ZJSDR20125 Export Ceiling Promotion Result
 * @author 이수지
 * @since 2020. 06. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 22.       이수지      	        최초 생성
 * </pre>
 */

public interface PromotionExportCeilingService {

    /**
     * Promotion List
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<PromotionExportCeilingVO> selectPromotionExportCeiling (LoginInfoVO loginVo, PromotionExportCeilingVO params) throws Exception;
}
