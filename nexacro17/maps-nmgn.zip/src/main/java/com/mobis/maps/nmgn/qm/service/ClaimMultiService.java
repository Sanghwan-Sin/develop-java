package com.mobis.maps.nmgn.qm.service;

import java.util.List;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.qm.vo.ClaimMultiCheckVO;
import com.mobis.maps.nmgn.qm.vo.ClaimMultiSaveVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimMultiService.java
 * @Description : Multi Claim 처리
 *                ZPQM_NMGN_R_CLAIM_MULTI_CHECK
 *                ZPQM_NMGN_R_CLAIM_MULTI_SAVE
 * @author hong.minho
 * @since 2020. 10. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 10. 26.     hong.minho     	최초 생성
 * </pre>
 */

public interface ClaimMultiService {

    
    /**
     * Multi Claim Check
     *
     * @param params
     * @param list
     * @param loginVo
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    List<ClaimMultiCheckVO> multiCheckClaim (ClaimMultiCheckVO params, List<ClaimMultiCheckVO> paramLst, LoginInfoVO loginVo) throws MapsBizException, Exception;


    /**
     * Multi Claim Save
     *
     * @param params
     * @param list
     * @param loginVo
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    List<ClaimMultiSaveVO> multiSaveClaim (ClaimMultiSaveVO params, List<ClaimMultiSaveVO> paramLst, LoginInfoVO loginVo) throws MapsBizException, Exception;
}
