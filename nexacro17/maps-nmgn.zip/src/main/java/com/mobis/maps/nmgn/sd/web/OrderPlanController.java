package com.mobis.maps.nmgn.sd.web;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.OrderPlanService;
import com.mobis.maps.nmgn.sd.vo.OrderPlanVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderPlanController.java
 * @Description : ZJSDO30220 Parts Order Plan
 * @author 홍민호
 * @since 2020. 2. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 5.     홍민호         최초 생성
 * </pre>
 */

@Controller
public class OrderPlanController extends HController {
    
    private final static String SHIP_MODE_SEA = "S"; // CD-SD-1015 Ship Mode - Sea
    private final static String SHIP_MODE_AIR = "A"; // CD-SD-1015 Ship Mode - Air
    
    @Resource(name = "orderPlanService")
    private OrderPlanService service;

    
    /**
     * Order Plan Inquiry
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderPlan.do")
    public NexacroResult selectOrderPlan(@ParamDataSet(name="dsInput") OrderPlanVO params
            , NexacroResult result) throws Exception {
        
        List<OrderPlanVO> planLst = new ArrayList<OrderPlanVO>();
        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<OrderPlanVO> rsltLst = service.selectOrderPlan(loginVo, params);

        // Sort
        rsltLst.sort(new Comparator<OrderPlanVO>() {
            @Override
            public int compare(OrderPlanVO arg0, OrderPlanVO arg1) {
                if (arg0 == null || arg1 == null) return 0;
                if (arg0.getZpseq() == null) return 0;
                
                return arg0.getZpseq().compareTo(arg1.getZpseq());
            }
        });
        
        
        // String ==> BigDecimal
        for (OrderPlanVO vo : rsltLst) {
            vo.setAmt01(this.selectToBigDecimal(vo.getZbpamt01()));
            vo.setAmt02(this.selectToBigDecimal(vo.getZbpamt02()));
            vo.setAmt03(this.selectToBigDecimal(vo.getZbpamt03()));
            vo.setAmt04(this.selectToBigDecimal(vo.getZbpamt04()));
            vo.setAmt05(this.selectToBigDecimal(vo.getZbpamt05()));
            vo.setAmt06(this.selectToBigDecimal(vo.getZbpamt06()));
            vo.setAmt07(this.selectToBigDecimal(vo.getZbpamt07()));
            vo.setAmt08(this.selectToBigDecimal(vo.getZbpamt08()));
            vo.setAmt09(this.selectToBigDecimal(vo.getZbpamt09()));
            vo.setAmt10(this.selectToBigDecimal(vo.getZbpamt10()));
            vo.setAmt11(this.selectToBigDecimal(vo.getZbpamt11()));
            vo.setAmt12(this.selectToBigDecimal(vo.getZbpamt12()));
        }

        
        // ***** Stock Order 구성
        long seq = 1;
        
        for (OrderPlanVO vo : rsltLst) {
            if (vo == null) continue;
            if (!SHIP_MODE_SEA.equals(vo.getVsart())) continue; // Sea (Stock Order)
            
            vo.setSeq(seq++);
            planLst.add(vo);
            
            if (seq > 4) break;
        }

        while(seq <= 4) {
            OrderPlanVO vo = new OrderPlanVO();
            vo.setVsart(SHIP_MODE_SEA);
            vo.setSeq(seq++);

            planLst.add(vo);
        }
        

        // ***** Air Order 구성
        OrderPlanVO item = null;
        for(OrderPlanVO vo : rsltLst) {
            if (vo == null) continue;
            if (SHIP_MODE_AIR.equals(vo.getVsart())) { // Air (Stock Order)
                item = vo;
                break;
            }
        }
        
        if (item == null) {
            item = new OrderPlanVO();
            item.setVsart(SHIP_MODE_AIR);
        }
        
        planLst.add(item);

        
        

        result.addDataSet("dsOutput", planLst);
        result.addDataSet("dsReturn", params);
        
        return result;
    }

    
    /**
     * Excel Download
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectOrderPlanExcelDown.do")
    public NexacroResult selectOrderPlanExcelDown(@ParamDataSet(name="dsInput") OrderPlanVO params
            , NexacroResult result) throws Exception {
        return this.selectOrderPlan(params, result);
    }
    

    /**
     * Order Plan Save
     *
     * @param params
     * @param paramLst
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/multiSaveOrderPlan.do")
    public NexacroResult multiSaveOrderPlan(@ParamDataSet(name="dsInput") OrderPlanVO params
                                       ,@ParamDataSet(name="dsList") List<OrderPlanVO> paramLst
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginVo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        // BigDecimal ==> String
        for (OrderPlanVO vo : paramLst) {
            vo.setZbpamt01(vo.getAmt01() != null ? vo.getAmt01().toString() : "");
            vo.setZbpamt02(vo.getAmt02() != null ? vo.getAmt02().toString() : "");
            vo.setZbpamt03(vo.getAmt03() != null ? vo.getAmt03().toString() : "");
            vo.setZbpamt04(vo.getAmt04() != null ? vo.getAmt04().toString() : "");
            vo.setZbpamt05(vo.getAmt05() != null ? vo.getAmt05().toString() : "");
            vo.setZbpamt06(vo.getAmt06() != null ? vo.getAmt06().toString() : "");
            vo.setZbpamt07(vo.getAmt07() != null ? vo.getAmt07().toString() : "");
            vo.setZbpamt08(vo.getAmt08() != null ? vo.getAmt08().toString() : "");
            vo.setZbpamt09(vo.getAmt09() != null ? vo.getAmt09().toString() : "");
            vo.setZbpamt10(vo.getAmt10() != null ? vo.getAmt10().toString() : "");
            vo.setZbpamt11(vo.getAmt11() != null ? vo.getAmt11().toString() : "");
            vo.setZbpamt12(vo.getAmt12() != null ? vo.getAmt12().toString() : "");
        }        
        
        
        OrderPlanVO rsltVo = service.multiSaveOrderPlan(loginVo, params, paramLst);
        
        result.addDataSet("dsOutput", rsltVo.getList());
        result.addDataSet("dsReturn", rsltVo);
        
        return result;

    }
    
    
    /**
     * Statements
     *
     * @param val
     * @return
     */
    private BigDecimal selectToBigDecimal(String val) {
        BigDecimal rslt = null;
        
        if (val == null) return rslt;
        
        String valTmp = val.replaceAll("[^\\.\\-0-9]", "");

        if (StringUtils.isBlank(valTmp)) return rslt;

        try {
            rslt = new BigDecimal(valTmp);
            
        } catch (NumberFormatException e1) {
            if (logger.isDebugEnabled()) {logger.debug("ERROR 오류", e1);}
            rslt = null;

        } catch (Exception e1) {
            if (logger.isDebugEnabled()) {logger.debug("ERROR 오류", e1);}
            rslt = null;
        }
        
        return rslt;
    }
}
