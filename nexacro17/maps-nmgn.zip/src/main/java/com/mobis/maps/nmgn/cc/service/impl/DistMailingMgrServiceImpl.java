package com.mobis.maps.nmgn.cc.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.nmgn.cc.service.DistMailingMgrService;
import com.mobis.maps.nmgn.cc.service.dao.DistMailingMgrMDAO;
import com.mobis.maps.nmgn.cc.vo.MailingVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistMailingMgrServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author hong.minho
 * @since 2020. 4. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 17.     hong.minho     	최초 생성
 * </pre>
 */

@Service("distMailingMgrService")
public class DistMailingMgrServiceImpl extends HService implements DistMailingMgrService {
    private static final int MAX_LEN = 1024*64;
    
    @Resource(name="distMailingMgrMDAO")
    DistMailingMgrMDAO dao;
    
    
    /**
     * Mailing Group ID 를 해당 그룹 조회조건VO로 파싱
     *
     * @param gids
     * @return
     * @throws MapsBizException
     * @throws Exception
     */
    @Override
    public List<MailingVO> selectParseGID(String gids) throws MapsBizException, Exception {
        List<MailingVO> mailingVos = new ArrayList<MailingVO>();
        
        if (StringUtils.isBlank(gids)) return mailingVos;
        
        /*
         * Sample Input : ASIA, OTHERS<|H|ASA|APC|AUS> , ASIA<|H|ASA>, A00HAS TEST Dist<|H|ASA|APC|AUS|1I4OA00HAS>
         */
        
        
        String[] vals = gids.replaceAll("([\\>|^])\\s*\\,\\s*", "$1@|@").split("\\@\\|\\@");

        for(String val : vals) {
            if (val == null || val.trim().length() <= 0) continue;
            
            val = val.trim();
            
            if (val.replaceAll("[^\\<]","").length() != 1) {
                if (logger.isDebugEnabled()) {logger.debug("ERROR:Parsing failed. Unknown string.");}
                continue;
            }

            if (val.replaceAll("[^\\>]","").length() != 1) {
                if (logger.isDebugEnabled()) {logger.debug("ERROR:Parsing failed. Unknown string.");}
                continue;
            }
            
//            String title = val.replaceFirst("(.*)\\<.+\\>.*", "$1").trim();
            String tmp = val.replaceFirst(".*\\<(.+)\\>.*", "$1");
//            System.out.println("\n" + val + " ==> " + tmp);
//            System.out.println("<" + title + ">===========================================");
            
            String[] attrs = tmp.split("\\|");
            if (attrs == null) continue;
            
            MailingVO vo = new MailingVO();
            for(int idx = 0; idx < attrs.length; idx++) {
                String attr = attrs[idx];
                
                if (logger.isDebugEnabled()) {logger.debug("#### [" + idx + "]" + attr);}                
                
                if (StringUtils.isBlank(attr)) continue;
                
                if (idx == 1) {vo.setKvgr1(attr);} // H/K
                if (idx == 2) {vo.setIzlregio(attr);} // Region L
                if (idx == 3) {vo.setIzmregio(attr);} // Region M
                if (idx == 4) {vo.setIzsregio(attr);} // Region S
                if (idx == 5) {vo.setIkunnr(attr);} // Dist. CD
            }
            
            mailingVos.add(vo);

        }
        
        return mailingVos;
    }
    

    /*
     * @see com.mobis.maps.nmgn.cc.service.DistMailingMgrService#selectMailingLst(com.mobis.maps.nmgn.cc.vo.MailingVO)
     */
    @Override
    public List<MailingVO> selectMailingLst(MailingVO vo) throws MapsBizException, Exception {
        if (vo == null) {
            logger.error("################# ERROR. parameters<MailingVO> is null. END.");
            return null;
        }
        
        if (vo.getIkunnrs() == null) {vo.setIkunnrs(new ArrayList<String>());}
        if (vo.getEmltps() == null) {vo.setEmltps(new ArrayList<String>());}
        
        vo.getIkunnrs().clear();
        vo.getEmltps().clear();
        
        if (vo.getIkunnr() != null) {
            String[] ikunnrs = vo.getIkunnr().split("\\,");
            for(String item : ikunnrs) {
                if (item == null || item.trim().length() <= 0) continue;
                vo.getIkunnrs().add(item.trim());
            }
        }
        
        if (vo.getEmltp() != null) {
            String[] emltps = vo.getEmltp().split("\\,");
            for(String item : emltps) {
                if (item == null || item.trim().length() <= 0) continue;
                vo.getEmltps().add(item.trim());
            }
        }

        return dao.selectMailingLst(vo);
    }


    /*
     * @see com.mobis.maps.nmgn.cc.service.DistMailingMgrService#selectMailingLst(java.lang.String, java.lang.String)
     */
    @Override
    public List<MailingVO> selectMailingLst(String gids, String emlTp) throws MapsBizException, Exception {
        List<MailingVO> mailLst = new ArrayList<MailingVO>();
        
        List<MailingVO> params = this.selectParseGID(gids);
        if (params == null || params.size() <= 0) {
            return mailLst;
        }

        
        for(MailingVO vo : params) {
            vo.setEmltp(emlTp);
            vo.setIncludeSubDist(true); // 하위대리점 포함
            
            List<MailingVO> mailLst01 = this.selectMailingLst(vo);
            
            if (mailLst01 != null && mailLst01.size() > 0) {
                mailLst.addAll(mailLst01);
            }
        }
        
        // distinct
        HashSet<MailingVO> distinctData = new HashSet<MailingVO>(mailLst);
        mailLst = new ArrayList<MailingVO>(distinctData);        
        
        return mailLst;
    }


    /*
     * @see com.mobis.maps.nmgn.cc.service.DistMailingMgrService#selectMailingString(java.lang.String, java.lang.String)
     */
    @Override
    public String selectMailingString(String gids, String emlTp) throws MapsBizException, Exception {
        StringBuffer mailAddr = new StringBuffer();
        
        List<MailingVO> mailLst = this.selectMailingLst(gids, emlTp);
        for(MailingVO vo : mailLst) {
            if (vo == null) continue;
            if (StringUtils.isBlank(vo.getEmlid())) continue;
            
            if (mailAddr.length() > 0) {mailAddr.append(",");}
            
            if (!StringUtils.isBlank(vo.getStffnm())) {
                mailAddr.append(vo.getStffnm().trim()).append("<").append(vo.getEmlid().trim()).append(">");
            } else {
                mailAddr.append(vo.getEmlid().trim());
            }
            
            if (mailAddr.length() > (MAX_LEN - 1024)) {
                logger.debug("##### Too long e-Mail Address. Skipped.");
                break;
            }
        }
        
        return mailAddr.toString();
    }

}
