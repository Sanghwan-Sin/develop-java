package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.BatteryShippingVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : BatteryShippingService.java
 * @Description : Battery Shipping By Air
 * @author 이수지
 * @since 2020. 8. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 10.      이수지	            최초 생성
 * </pre>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
 */

public interface BatteryShippingService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param params
     * @return
     */
    List<BatteryShippingVO> selectBatteryShipping(LoginInfoVO loginInfo, BatteryShippingVO params) throws Exception;

}
