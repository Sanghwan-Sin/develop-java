package com.mobis.maps.nmgn.ti.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AoMoPartListVO.java
 * @Description : ZPTI_NMGN_S_AO_MO_LIST_HQ / ZPTI_NMGN_S_SELECT_AREA_CODE / ZPTI_NMGN_S_SELECT_MODEL_CODE
 * @author 이수지
 * @since 2020. 5. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 11.     이수지     	       최초 생성
 * </pre>
 */

public class AoMoPartListVO extends MapsCommSapRfcIfCommVO {
    
    /** Part No */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /** Search By */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PCGUBUN" )
    private String iPcgubun;
    /** Region */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAREA" )
    private String iZarea;
    /** Dist Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDISTCD" )
    private String iZdistcd;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /** Model */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZVHC" )
    private String iZvhc;
    /** AO Flag */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_AO_FLAG" )
    private String iAoFlag;
    /** MO Flag */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MO_FLAG" )
    private String iMoFlag;
    
    /** -----[ET_DATA] START----- */
    
    /** Material Number */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Part Name */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /** HQ SUC */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSUCCD" )
    private String zsuccd;
    /** Kit Code */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSK_CD" )
    private String zskCd;
    /** AO_FLAG */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZAO_FLAG" )
    private String zaoFlag;
    /** MO_FLAG */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZMO_FLAG" )
    private String zmoFlag;
    /** Region */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZAREA" )
    private String zarea;
    /** Mobis Car Code (Model No) */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZVHC" )
    private String zvhc;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSEQNO" )
    private String zseqno;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZUPTNO" )
    private String zuptno;   
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZMGT_CD" )
    private String zmgtCd;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSRC_CD" )
    private String zsrcCd;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZQTY" )
    private String zqty;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZMADTE" )
    private String zmadte;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZMSEQ" )
    private String zmseq;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSSEQ" )
    private String zsseq;
    /** H/K */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZHKCD" )
    private String zhkcd;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZUPDTE" )
    private String zupdte;
    /** Character field of length 40 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="DESCR" )
    private String descr;
    
    /** -----[ET_DATA] END----- */
        
    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }
    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }
    /**
     * @return the iPcgubun
     */
    public String getiPcgubun() {
        return iPcgubun;
    }
    /**
     * @param iPcgubun the iPcgubun to set
     */
    public void setiPcgubun(String iPcgubun) {
        this.iPcgubun = iPcgubun;
    }
    /**
     * @return the iZarea
     */
    public String getiZarea() {
        return iZarea;
    }
    /**
     * @param iZarea the iZarea to set
     */
    public void setiZarea(String iZarea) {
        this.iZarea = iZarea;
    }
    /**
     * @return the iZdistcd
     */
    public String getiZdistcd() {
        return iZdistcd;
    }
    /**
     * @param iZdistcd the iZdistcd to set
     */
    public void setiZdistcd(String iZdistcd) {
        this.iZdistcd = iZdistcd;
    }
    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }
    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }
    /**
     * @return the iZvhc
     */
    public String getiZvhc() {
        return iZvhc;
    }
    /**
     * @param iZvhc the iZvhc to set
     */
    public void setiZvhc(String iZvhc) {
        this.iZvhc = iZvhc;
    }
    /**
     * @return the iAoFlag
     */
    public String getiAoFlag() {
        return iAoFlag;
    }
    /**
     * @param iAoFlag the iAoFlag to set
     */
    public void setiAoFlag(String iAoFlag) {
        this.iAoFlag = iAoFlag;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }
    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }
    /**
     * @return the zsuccd
     */
    public String getZsuccd() {
        return zsuccd;
    }
    /**
     * @param zsuccd the zsuccd to set
     */
    public void setZsuccd(String zsuccd) {
        this.zsuccd = zsuccd;
    }
    /**
     * @return the zskCd
     */
    public String getZskCd() {
        return zskCd;
    }
    /**
     * @param zskCd the zskCd to set
     */
    public void setZskCd(String zskCd) {
        this.zskCd = zskCd;
    }
    /**
     * @return the zaoFlag
     */
    public String getZaoFlag() {
        return zaoFlag;
    }
    /**
     * @param zaoFlag the zaoFlag to set
     */
    public void setZaoFlag(String zaoFlag) {
        this.zaoFlag = zaoFlag;
    }
    /**
     * @return the zmoFlag
     */
    public String getZmoFlag() {
        return zmoFlag;
    }
    /**
     * @param zmoFlag the zmoFlag to set
     */
    public void setZmoFlag(String zmoFlag) {
        this.zmoFlag = zmoFlag;
    }
    /**
     * @return the zarea
     */
    public String getZarea() {
        return zarea;
    }
    /**
     * @param zarea the zarea to set
     */
    public void setZarea(String zarea) {
        this.zarea = zarea;
    }
    /**
     * @return the zvhc
     */
    public String getZvhc() {
        return zvhc;
    }
    /**
     * @param zvhc the zvhc to set
     */
    public void setZvhc(String zvhc) {
        this.zvhc = zvhc;
    }
    /**
     * @return the zseqno
     */
    public String getZseqno() {
        return zseqno;
    }
    /**
     * @param zseqno the zseqno to set
     */
    public void setZseqno(String zseqno) {
        this.zseqno = zseqno;
    }
    /**
     * @return the zuptno
     */
    public String getZuptno() {
        return zuptno;
    }
    /**
     * @param zuptno the zuptno to set
     */
    public void setZuptno(String zuptno) {
        this.zuptno = zuptno;
    }
    /**
     * @return the zmgtCd
     */
    public String getZmgtCd() {
        return zmgtCd;
    }
    /**
     * @param zmgtCd the zmgtCd to set
     */
    public void setZmgtCd(String zmgtCd) {
        this.zmgtCd = zmgtCd;
    }
    /**
     * @return the zsrcCd
     */
    public String getZsrcCd() {
        return zsrcCd;
    }
    /**
     * @param zsrcCd the zsrcCd to set
     */
    public void setZsrcCd(String zsrcCd) {
        this.zsrcCd = zsrcCd;
    }
    /**
     * @return the zqty
     */
    public String getZqty() {
        return zqty;
    }
    /**
     * @param zqty the zqty to set
     */
    public void setZqty(String zqty) {
        this.zqty = zqty;
    }
    /**
     * @return the zmadte
     */
    public String getZmadte() {
        return zmadte;
    }
    /**
     * @param zmadte the zmadte to set
     */
    public void setZmadte(String zmadte) {
        this.zmadte = zmadte;
    }
    /**
     * @return the zmseq
     */
    public String getZmseq() {
        return zmseq;
    }
    /**
     * @param zmseq the zmseq to set
     */
    public void setZmseq(String zmseq) {
        this.zmseq = zmseq;
    }
    /**
     * @return the zsseq
     */
    public String getZsseq() {
        return zsseq;
    }
    /**
     * @param zsseq the zsseq to set
     */
    public void setZsseq(String zsseq) {
        this.zsseq = zsseq;
    }
    /**
     * @return the zhkcd
     */
    public String getZhkcd() {
        return zhkcd;
    }
    /**
     * @param zhkcd the zhkcd to set
     */
    public void setZhkcd(String zhkcd) {
        this.zhkcd = zhkcd;
    }
    /**
     * @return the zupdte
     */
    public String getZupdte() {
        return zupdte;
    }
    /**
     * @param zupdte the zupdte to set
     */
    public void setZupdte(String zupdte) {
        this.zupdte = zupdte;
    }
    /**
     * @return the iMoFlag
     */
    public String getiMoFlag() {
        return iMoFlag;
    }
    /**
     * @param iMoFlag the iMoFlag to set
     */
    public void setiMoFlag(String iMoFlag) {
        this.iMoFlag = iMoFlag;
    }
    /**
     * @return the descr
     */
    public String getDescr() {
        return descr;
    }
    /**
     * @param descr the descr to set
     */
    public void setDescr(String descr) {
        this.descr = descr;
    }
    
}
