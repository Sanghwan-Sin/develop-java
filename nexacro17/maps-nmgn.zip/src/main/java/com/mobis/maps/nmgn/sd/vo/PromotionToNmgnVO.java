package com.mobis.maps.nmgn.sd.vo;

import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionToNmgnVO.java
 * @Description : ZPSD_MGN_S_PROMOTION_HEADER 
 * @author 조경호
 * @since 2020. 2. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 24.       조경호     	                             최초 생성
 * </pre>
 */

public class PromotionToNmgnVO extends MapsCommSapRfcIfCommVO {
   
    /*** INPUT **********************************************/
    /** ABAP: ID: I/E (포함/제외된 값) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="SIGN" )
    private String iDsign;
    /** ABAP: 선택옵션 (EQ/BT/CP/...) */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="OPTION" )
    private String iDoption;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="LOW" )
    private String iDlow;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_DATES", ipttSe="I", fieldKey="HIGH" )
    private String iDhigh;

    /** ABAP: ID: I/E (포함/제외된 값) */
    @MapsRfcMappper( targetName="IS_ZPPI", ipttSe="I", fieldKey="SIGN" )
    private String iZsign;
    /** ABAP: 선택옵션 (EQ/BT/CP/...) */
    @MapsRfcMappper( targetName="IS_ZPPI", ipttSe="I", fieldKey="OPTION" )
    private String iZoption;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_ZPPI", ipttSe="I", fieldKey="LOW" )
    private String iZlow;
    /** 동적 선택에 대한 '일반' 선택 옵션 */
    @MapsRfcMappper( targetName="IS_ZPPI", ipttSe="I", fieldKey="HIGH" )
    private String iZhigh;
    
    /** Approval Status(A: All, Y: Applied, F: Finished)) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_STATUS" )
    private String iStatus;
    /** C/R/U/D (조회:R) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 프로모션 Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPRTYP" )
    private String iZprtyp;
    /** 대리점 코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    
    /*** T_RESULT ******************************************************/
    private List<?> tResult = null;
//    -----[T_RESULT] START-----
    /** Dist. Code */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** 프로모션 프로파일 번호 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPI" )
    private String zppi;
    /** 프로모션 명 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRNM" )
    private String zprnm;
    /** 프로모션 Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRTYP" )
    private String zprtyp;
    /** 문자 80 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRTYP_NM" )
    private String zprtypNm;
    /** Order No. */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /** Order D/C */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDDC" )
    private String zorddc;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZTGORA" )
    private String ztgora;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZAVCEA" )
    private String zavcea;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZACORA" )
    private String zacora;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZDIFF" )
    private String zdiff;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZEXCAMT" )
    private String zexcamt;
    /** SD document currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** 프로파일 유효시작일 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPIST" )
    private String zppist;
    /** 프로파일 유효종료일 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPIEN" )
    private String zppien;
    /** Status */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSTATUS" )
    private String zstatus;
    /** A:Icon 미표시, B:OrderType 표시, C:ALL, D:Popup */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZTYPE" )
    private String ztype;
    /** 오더 유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP" )
    private String zordtyp;
    /** 오더 유형 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP_NM" )
    private String zordtypNm;
    /** 레벨 */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZLEVEL" )
    private String zlevel;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPARENT_ID" )
    private String zparentId;
    private int count;
    
    public String getiDsign() {
        return iDsign;
    }
    /**
     * @param iDsign the iDsign to set
     */
    public void setiDsign(String iDsign) {
        this.iDsign = iDsign;
    }
    /**
     * @return the iDoption
     */
    public String getiDoption() {
        return iDoption;
    }
    /**
     * @param iDoption the iDoption to set
     */
    public void setiDoption(String iDoption) {
        this.iDoption = iDoption;
    }
    /**
     * @return the iDlow
     */
    public String getiDlow() {
        return iDlow;
    }
    /**
     * @param iDlow the iDlow to set
     */
    public void setiDlow(String iDlow) {
        this.iDlow = iDlow;
    }
    /**
     * @return the iDhigh
     */
    public String getiDhigh() {
        return iDhigh;
    }
    /**
     * @param iDhigh the iDhigh to set
     */
    public void setiDhigh(String iDhigh) {
        this.iDhigh = iDhigh;
    }
    /**
     * @return the iZsign
     */
    public String getiZsign() {
        return iZsign;
    }
    /**
     * @param iZsign the iZsign to set
     */
    public void setiZsign(String iZsign) {
        this.iZsign = iZsign;
    }
    /**
     * @return the iZoption
     */
    public String getiZoption() {
        return iZoption;
    }
    /**
     * @param iZoption the iZoption to set
     */
    public void setiZoption(String iZoption) {
        this.iZoption = iZoption;
    }
    /**
     * @return the iZlow
     */
    public String getiZlow() {
        return iZlow;
    }
    /**
     * @param iZlow the iZlow to set
     */
    public void setiZlow(String iZlow) {
        this.iZlow = iZlow;
    }
    /**
     * @return the iZhigh
     */
    public String getiZhigh() {
        return iZhigh;
    }
    /**
     * @param iZhigh the iZhigh to set
     */
    public void setiZhigh(String iZhigh) {
        this.iZhigh = iZhigh;
    }
    /**
     * @return the iStatus
     */
    public String getiStatus() {
        return iStatus;
    }
    /**
     * @param iStatus the iStatus to set
     */
    public void setiStatus(String iStatus) {
        this.iStatus = iStatus;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZprtyp
     */
    public String getiZprtyp() {
        return iZprtyp;
    }
    /**
     * @param iZprtyp the iZprtyp to set
     */
    public void setiZprtyp(String iZprtyp) {
        this.iZprtyp = iZprtyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zppi
     */
    public String getZppi() {
        return zppi;
    }
    /**
     * @param zppi the zppi to set
     */
    public void setZppi(String zppi) {
        this.zppi = zppi;
    }
    /**
     * @return the zprnm
     */
    public String getZprnm() {
        return zprnm;
    }
    /**
     * @param zprnm the zprnm to set
     */
    public void setZprnm(String zprnm) {
        this.zprnm = zprnm;
    }
    /**
     * @return the zprtyp
     */
    public String getZprtyp() {
        return zprtyp;
    }
    /**
     * @param zprtyp the zprtyp to set
     */
    public void setZprtyp(String zprtyp) {
        this.zprtyp = zprtyp;
    }
    /**
     * @return the zprtypNm
     */
    public String getZprtypNm() {
        return zprtypNm;
    }
    /**
     * @param zprtypNm the zprtypNm to set
     */
    public void setZprtypNm(String zprtypNm) {
        this.zprtypNm = zprtypNm;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zppist
     */
    public String getZppist() {
        return zppist;
    }
    /**
     * @param zppist the zppist to set
     */
    public void setZppist(String zppist) {
        this.zppist = zppist;
    }
    /**
     * @return the zppien
     */
    public String getZppien() {
        return zppien;
    }
    /**
     * @param zppien the zppien to set
     */
    public void setZppien(String zppien) {
        this.zppien = zppien;
    }
    /**
     * @return the zstatus
     */
    public String getZstatus() {
        return zstatus;
    }
    /**
     * @param zstatus the zstatus to set
     */
    public void setZstatus(String zstatus) {
        this.zstatus = zstatus;
    }
    /**
     * @return the ztype
     */
    public String getZtype() {
        return ztype;
    }
    /**
     * @param ztype the ztype to set
     */
    public void setZtype(String ztype) {
        this.ztype = ztype;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the zordtypNm
     */
    public String getZordtypNm() {
        return zordtypNm;
    }
    /**
     * @param zordtypNm the zordtypNm to set
     */
    public void setZordtypNm(String zordtypNm) {
        this.zordtypNm = zordtypNm;
    }
    /**
     * @return the tResult
     */
    public List<?> gettResult() {
        return tResult;
    }
    /**
     * @param tResult the tResult to set
     */
    public void settResult(List<?> tResult) {
        this.tResult = tResult;
    }
    /**
     * @return the zorddc
     */
    public String getZorddc() {
        return zorddc;
    }
    /**
     * @param zorddc the zorddc to set
     */
    public void setZorddc(String zorddc) {
        this.zorddc = zorddc;
    }
    /**
     * @return the ztgora
     */
    public String getZtgora() {
        return ztgora;
    }
    /**
     * @param ztgora the ztgora to set
     */
    public void setZtgora(String ztgora) {
        this.ztgora = ztgora;
    }
    /**
     * @return the zavcea
     */
    public String getZavcea() {
        return zavcea;
    }
    /**
     * @param zavcea the zavcea to set
     */
    public void setZavcea(String zavcea) {
        this.zavcea = zavcea;
    }
    /**
     * @return the zacora
     */
    public String getZacora() {
        return zacora;
    }
    /**
     * @param zacora the zacora to set
     */
    public void setZacora(String zacora) {
        this.zacora = zacora;
    }
    /**
     * @return the zdiff
     */
    public String getZdiff() {
        return zdiff;
    }
    /**
     * @param zdiff the zdiff to set
     */
    public void setZdiff(String zdiff) {
        this.zdiff = zdiff;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the zlevel
     */
    public String getZlevel() {
        return zlevel;
    }
    /**
     * @param zlevel the zlevel to set
     */
    public void setZlevel(String zlevel) {
        this.zlevel = zlevel;
    }
    /**
     * @return the zparentId
     */
    public String getZparentId() {
        return zparentId;
    }
    /**
     * @param zparentId the zparentId to set
     */
    public void setZparentId(String zparentId) {
        this.zparentId = zparentId;
    }
    /**
     * @return the count
     */
    public int getCount() {
        return count;
    }
    /**
     * @param count the count to set
     */
    public void setCount(int count) {
        this.count = count;
    }
    /**
     * @return the zexcamt
     */
    public String getZexcamt() {
        return zexcamt;
    }
    /**
     * @param zexcamt the zexcamt to set
     */
    public void setZexcamt(String zexcamt) {
        this.zexcamt = zexcamt;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
   
}
