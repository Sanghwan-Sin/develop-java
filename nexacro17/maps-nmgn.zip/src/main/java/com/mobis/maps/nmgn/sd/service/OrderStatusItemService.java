package com.mobis.maps.nmgn.sd.service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.OrderStatusItemVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderStatusItemService.java
 * @Description : Order Status Item List
 * @author 홍민호
 * @since 2019. 12. 24.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 12. 24.     홍민호     	최초 생성
 * </pre>
 */

public interface OrderStatusItemService {
    
    /**
     * Order Status List
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    OrderStatusItemVO selectOrderStatusItem (LoginInfoVO loginVo, OrderStatusItemVO params) throws Exception;

}
