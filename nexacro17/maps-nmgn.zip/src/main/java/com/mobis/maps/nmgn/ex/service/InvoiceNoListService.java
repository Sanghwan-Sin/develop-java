package com.mobis.maps.nmgn.ex.service;

import java.util.List;
import java.util.Map;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceDetailVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceDownloadVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceExcelDownloadVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFtaCoPartsVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceFtaCoVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceHeaderVO;
import com.mobis.maps.nmgn.ex.vo.InvoiceNoListVO;
import com.mobis.maps.nmgn.ex.vo.InvoicePackingVO;
import com.mobis.maps.nmgn.ex.vo.InvoicePopVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : InvoiceNoListService.java
 * @Description : Invoice List, Header, Detail
 * @author jiyongdo
 * @since 2020. 2. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 3.     jiyongdo     	최초 생성
 * </pre>
 */

public interface InvoiceNoListService {

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectInvoiceNoList(LoginInfoVO loginInfo, InvoiceNoListVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectInvoiceDetailList(LoginInfoVO loginInfo, InvoiceDetailVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<InvoicePackingVO> selectInvoicePackingListExcelDown(LoginInfoVO loginInfo, InvoicePackingVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<InvoiceDownloadVO> selectInvoiceDownloadListExcelDown(LoginInfoVO loginInfo, InvoiceDownloadVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<InvoicePopVO> selectInvoiceNoPopupList(LoginInfoVO loginInfo, InvoicePopVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    Map<String, Object> selectInvoiceHeaderList(LoginInfoVO loginInfo, InvoiceHeaderVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<InvoiceFtaCoVO> selectInvoiceFtaCoListExcelDown(LoginInfoVO loginInfo, InvoiceFtaCoVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramVO
     * @return
     */
    List<InvoiceFtaCoPartsVO> selectInvoiceFtaCoPartsListExcelDown(LoginInfoVO loginInfo, InvoiceFtaCoPartsVO paramVO) throws Exception;

    /**
     * Statements
     *
     * @param loginInfo
     * @param paramList
     * @return
     */
    List<InvoiceExcelDownloadVO> selectInvoiceExcelDown(LoginInfoVO loginInfo, List<InvoiceExcelDownloadVO> paramList) throws Exception;

}
