package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : OrderProcCodeVO.java
 * @Description : OrderProcCodeVO
 * @author ha.jeongryeong
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.    ha.jeongryeong      최초 생성
 *  2020. 3. 26.    ChoKyungHo          To-Be 테이블로 변경
 *               </pre>
 */

public class OrderProcCodeVO extends MapsCommSapRfcIfCommVO {

    /* 조회조건 */
    private String iVkorg;
    private String iZlregio;
    private String iZmregio;
    private String iZsregio;
    private String iKvgr1;
    private String iZsacutm;
    private String iZsacutmSub;
    
    /* 조회결과 */
    private int rnum;
    private String land1;
    private String zsacutm;
    private String riskclass;
    private String pltyp;
    private String zdisrate01;
    private String zdisrate02;
    private String zdisrate03;
    private String zwels1;
    private String zwels2;
    private String waers;
    private String zpamre;
    private String zmarkup;
    private String zinco1;
    private String zinco2;
    private String zarport1;
    private String zarport2;
    private String zfindes1;
    private String zfindes2;
    
    
    
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iZlregio
     */
    public String getiZlregio() {
        return iZlregio;
    }
    /**
     * @param iZlregio the iZlregio to set
     */
    public void setiZlregio(String iZlregio) {
        this.iZlregio = iZlregio;
    }
    /**
     * @return the iZmregio
     */
    public String getiZmregio() {
        return iZmregio;
    }
    /**
     * @param iZmregio the iZmregio to set
     */
    public void setiZmregio(String iZmregio) {
        this.iZmregio = iZmregio;
    }
    /**
     * @return the iZsregio
     */
    public String getiZsregio() {
        return iZsregio;
    }
    /**
     * @param iZsregio the iZsregio to set
     */
    public void setiZsregio(String iZsregio) {
        this.iZsregio = iZsregio;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the rnum
     */
    public int getRnum() {
        return rnum;
    }
    /**
     * @param rnum the rnum to set
     */
    public void setRnum(int rnum) {
        this.rnum = rnum;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the riskclass
     */
    public String getRiskclass() {
        return riskclass;
    }
    /**
     * @param riskclass the riskclass to set
     */
    public void setRiskclass(String riskclass) {
        this.riskclass = riskclass;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the zdisrate01
     */
    public String getZdisrate01() {
        return zdisrate01;
    }
    /**
     * @param zdisrate01 the zdisrate01 to set
     */
    public void setZdisrate01(String zdisrate01) {
        this.zdisrate01 = zdisrate01;
    }
    /**
     * @return the zdisrate02
     */
    public String getZdisrate02() {
        return zdisrate02;
    }
    /**
     * @param zdisrate02 the zdisrate02 to set
     */
    public void setZdisrate02(String zdisrate02) {
        this.zdisrate02 = zdisrate02;
    }
    /**
     * @return the zdisrate03
     */
    public String getZdisrate03() {
        return zdisrate03;
    }
    /**
     * @param zdisrate03 the zdisrate03 to set
     */
    public void setZdisrate03(String zdisrate03) {
        this.zdisrate03 = zdisrate03;
    }
    /**
     * @return the zwels1
     */
    public String getZwels1() {
        return zwels1;
    }
    /**
     * @param zwels1 the zwels1 to set
     */
    public void setZwels1(String zwels1) {
        this.zwels1 = zwels1;
    }
    /**
     * @return the zwels2
     */
    public String getZwels2() {
        return zwels2;
    }
    /**
     * @param zwels2 the zwels2 to set
     */
    public void setZwels2(String zwels2) {
        this.zwels2 = zwels2;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the zpamre
     */
    public String getZpamre() {
        return zpamre;
    }
    /**
     * @param zpamre the zpamre to set
     */
    public void setZpamre(String zpamre) {
        this.zpamre = zpamre;
    }
    /**
     * @return the zmarkup
     */
    public String getZmarkup() {
        return zmarkup;
    }
    /**
     * @param zmarkup the zmarkup to set
     */
    public void setZmarkup(String zmarkup) {
        this.zmarkup = zmarkup;
    }
    /**
     * @return the zinco1
     */
    public String getZinco1() {
        return zinco1;
    }
    /**
     * @param zinco1 the zinco1 to set
     */
    public void setZinco1(String zinco1) {
        this.zinco1 = zinco1;
    }
    /**
     * @return the zinco2
     */
    public String getZinco2() {
        return zinco2;
    }
    /**
     * @param zinco2 the zinco2 to set
     */
    public void setZinco2(String zinco2) {
        this.zinco2 = zinco2;
    }
    /**
     * @return the zarport1
     */
    public String getZarport1() {
        return zarport1;
    }
    /**
     * @param zarport1 the zarport1 to set
     */
    public void setZarport1(String zarport1) {
        this.zarport1 = zarport1;
    }
    /**
     * @return the zarport2
     */
    public String getZarport2() {
        return zarport2;
    }
    /**
     * @param zarport2 the zarport2 to set
     */
    public void setZarport2(String zarport2) {
        this.zarport2 = zarport2;
    }
    /**
     * @return the zfindes1
     */
    public String getZfindes1() {
        return zfindes1;
    }
    /**
     * @param zfindes1 the zfindes1 to set
     */
    public void setZfindes1(String zfindes1) {
        this.zfindes1 = zfindes1;
    }
    /**
     * @return the zfindes2
     */
    public String getZfindes2() {
        return zfindes2;
    }
    /**
     * @param zfindes2 the zfindes2 to set
     */
    public void setZfindes2(String zfindes2) {
        this.zfindes2 = zfindes2;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    
}
