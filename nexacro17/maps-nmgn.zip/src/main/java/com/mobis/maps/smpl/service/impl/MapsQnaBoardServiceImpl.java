package com.mobis.maps.smpl.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.mobis.maps.cmmn.constants.AtchFileSe;
import com.mobis.maps.cmmn.vo.MapsAtchFileVO;
import com.mobis.maps.comm.service.MapsCommFileService;
import com.mobis.maps.smpl.service.MapsQnaBoardService;
import com.mobis.maps.smpl.service.dao.MapsQnaBoardMDAO;
import com.mobis.maps.smpl.vo.MapsQnaBoardVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsQnaBoardServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author DT048105
 * @since 2020. 4. 7.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 4. 7.     DT048105     	최초 생성
 * </pre>
 */

@Service("mapsQnaBoardService")
public class MapsQnaBoardServiceImpl extends HService implements MapsQnaBoardService{
    @Resource(name = "mapsQnaBoardMDAO")
    private MapsQnaBoardMDAO mapsQnaBoardMDAO;
    
    @Resource(name="mapsCommFileService")
    private MapsCommFileService mapsCommFileService;   
    /*
     * @see com.mobis.maps.smpl.service.MapsSmplBoardService#selectSmplBoardList(com.mobis.maps.smpl.vo.MapsSmplBoardVO)
     */
    @Override
    public List<MapsQnaBoardVO> selectQnaBoardList(MapsQnaBoardVO inputVO) {
        List<MapsQnaBoardVO> mapsQnaBoardVO = mapsQnaBoardMDAO.selectQnaBoardList(inputVO);
        return mapsQnaBoardVO;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplBoardService#selectSmplBoardNewList(com.mobis.maps.smpl.vo.MapsSmplBoardVO)
     */
    @Override
    public MapsQnaBoardVO selectQnaBoardNewList(MapsQnaBoardVO inputVO) throws Exception {
        MapsQnaBoardVO mapsQnaBoardVO = mapsQnaBoardMDAO.selectQnaBoardNewList(inputVO);
        return mapsQnaBoardVO;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplBoardService#selectSmplBoardNewList(com.mobis.maps.smpl.vo.MapsSmplBoardVO)
     */
    @Override
    public void updateQnaBoardCount(MapsQnaBoardVO inputVO) throws Exception {
        
        mapsQnaBoardMDAO.updateQnaBoardCount(inputVO);
        
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplBoardService#multiQnaBoard(com.mobis.maps.smpl.vo.MapsQnaBoardVO)
     */
    @Override
    public MapsQnaBoardVO multiQnaBoard(MapsQnaBoardVO inputVO) throws Exception {
        //int nProcCnt = 0;
        MapsQnaBoardVO rtnVo = new MapsQnaBoardVO();
        if("S".equals(inputVO.getSaveType()))
        {
            MapsQnaBoardVO paramVo = mapsQnaBoardMDAO.selectContId(inputVO);
            if(!"".equals(paramVo.getBbscttId()) && !StringUtils.isEmpty(paramVo.getBbscttId()))
            {
                inputVO.setBbscttId(paramVo.getBbscttId());
            }
            else
            {
                inputVO.setBbscttId("0");
            }
            mapsQnaBoardMDAO.insertQnaBoard(inputVO);
            rtnVo.setAtchId(inputVO.getBbscttId());
        }
        else if("R".equals(inputVO.getSaveType()))
        {
            MapsQnaBoardVO paramVo = mapsQnaBoardMDAO.selectSeq(inputVO); 
            inputVO.setBbscttSeq(paramVo.getBbscttSeq());
            inputVO.setRegistNm("Admin");
            mapsQnaBoardMDAO.insertQnaBoardRply(inputVO);
            rtnVo.setAtchId(inputVO.getBbscttId());
            rtnVo.setSeqNo(paramVo.getBbscttSeq());
        }        
        else if("U".equals(inputVO.getSaveType()))
        {
            mapsQnaBoardMDAO.updateQnaBoard(inputVO);
        }
        else if("D".equals(inputVO.getSaveType()))
        {
            mapsQnaBoardMDAO.deleteQnaBoard(inputVO);
            MapsAtchFileVO atchFileVO = new MapsAtchFileVO();            
            atchFileVO.setAtchSe(inputVO.getAtchSe());
            atchFileVO.setAtchId(inputVO.getAtchId());
            
            mapsCommFileService.deleteAtchFileAll(atchFileVO);

        }
        return rtnVo;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsQnaBoardService#multiAtchFile(com.mobis.maps.smpl.vo.MapsQnaBoardVO, java.util.List)
     */
    @Override
    public int multiAtchFile(MapsQnaBoardVO atchFileVO, List<MapsAtchFileVO> atchFiles) throws Exception {
        int retCnt = 0;
        if (atchFiles != null && atchFiles.size()>0) {
            AtchFileSe atchFileGubn = AtchFileSe.get(atchFileVO.getAtchSe()); 
            retCnt = mapsCommFileService.multiAtchFile(atchFileGubn, atchFileVO, atchFiles);    
        }
        return retCnt;
    }
}
