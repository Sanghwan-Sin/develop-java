package com.mobis.maps.smpl.vo;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplBoardVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSmplBoardVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 28.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 28.     Jiyongdo     	최초 생성
 * </pre>
 */
public class MapsSmplBoardVO extends PgBascVO{
    /* 조회조건 */
    /** Interface ID */
    private String ifCode;
    /** 회사 코드 */
    private String bukRs;
    /** Source System */
    private String srfcId;
    /** Target System */
    private String trfcId;
    
    private String bbscttId    ; //게시글ID
    private String bbscttSeq   ; //게시글일련
    private String jobTy       ; //업무타입
    private String bbscttDp    ; //게시글계층
    private String bbscttSj    ; //게시글제목
    private String bbscttCn    ; //게시글내용
    private String registId     ; //작성자ID
    private String registNm     ; //작성자명
    private String registEmail  ; //작성자이메일
    private String registTelno  ; //작성자전화번호
    private String rdCnt       ; //조회수
    private String delYn    ; //삭제여부
    private String atchSe;
    private String atchId;
    
    private String strDate    ; //시작일
    private String fnsDate    ; //종료일

    private String saveType   ; //저장타입
    private String seqNo   ;
    
    private String bbscttReply    ; //게시글답변
    

    /**
     * @return the ifCode
     */
    public String getIfCode() {
        return ifCode;
    }

    /**
     * @param ifCode the ifCode to set
     */
    public void setIfCode(String ifCode) {
        this.ifCode = ifCode;
    }

    /**
     * @return the bukRs
     */
    public String getBukRs() {
        return bukRs;
    }

    /**
     * @param bukRs the bukRs to set
     */
    public void setBukRs(String bukRs) {
        this.bukRs = bukRs;
    }

    /**
     * @return the srfcId
     */
    public String getSrfcId() {
        return srfcId;
    }

    /**
     * @param srfcId the srfcId to set
     */
    public void setSrfcId(String srfcId) {
        this.srfcId = srfcId;
    }

    /**
     * @return the trfcId
     */
    public String getTrfcId() {
        return trfcId;
    }

    /**
     * @param trfcId the trfcId to set
     */
    public void setTrfcId(String trfcId) {
        this.trfcId = trfcId;
    }

    /**
     * @return the bbscttId
     */
    public String getBbscttId() {
        return bbscttId;
    }

    /**
     * @param bbscttId the bbscttId to set
     */
    public void setBbscttId(String bbscttId) {
        this.bbscttId = bbscttId;
    }

    /**
     * @return the bbscttSeq
     */
    public String getBbscttSeq() {
        return bbscttSeq;
    }

    /**
     * @param bbscttSeq the bbscttSeq to set
     */
    public void setBbscttSeq(String bbscttSeq) {
        this.bbscttSeq = bbscttSeq;
    }

    /**
     * @return the jobTy
     */
    public String getJobTy() {
        return jobTy;
    }

    /**
     * @param jobTy the jobTy to set
     */
    public void setJobTy(String jobTy) {
        this.jobTy = jobTy;
    }

    /**
     * @return the bbscttDp
     */
    public String getBbscttDp() {
        return bbscttDp;
    }

    /**
     * @param bbscttDp the bbscttDp to set
     */
    public void setBbscttDp(String bbscttDp) {
        this.bbscttDp = bbscttDp;
    }

    /**
     * @return the bbscttSj
     */
    public String getBbscttSj() {
        return bbscttSj;
    }

    /**
     * @param bbscttSj the bbscttSj to set
     */
    public void setBbscttSj(String bbscttSj) {
        this.bbscttSj = bbscttSj;
    }

    /**
     * @return the bbscttCn
     */
    public String getBbscttCn() {
        return bbscttCn;
    }

    /**
     * @param bbscttCn the bbscttCn to set
     */
    public void setBbscttCn(String bbscttCn) {
        this.bbscttCn = bbscttCn;
    }

    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }

    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }

    /**
     * @return the registNm
     */
    public String getRegistNm() {
        return registNm;
    }

    /**
     * @param registNm the registNm to set
     */
    public void setRegistNm(String registNm) {
        this.registNm = registNm;
    }

    /**
     * @return the registEmail
     */
    public String getRegistEmail() {
        return registEmail;
    }

    /**
     * @param registEmail the registEmail to set
     */
    public void setRegistEmail(String registEmail) {
        this.registEmail = registEmail;
    }

    /**
     * @return the registTelno
     */
    public String getRegistTelno() {
        return registTelno;
    }

    /**
     * @param registTelno the registTelno to set
     */
    public void setRegistTelno(String registTelno) {
        this.registTelno = registTelno;
    }

    /**
     * @return the rdCnt
     */
    public String getRdCnt() {
        return rdCnt;
    }

    /**
     * @param rdCnt the rdCnt to set
     */
    public void setRdCnt(String rdCnt) {
        this.rdCnt = rdCnt;
    }

    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }

    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }

    /**
     * @return the strDate
     */
    public String getStrDate() {
        return strDate;
    }

    /**
     * @param strDate the strDate to set
     */
    public void setStrDate(String strDate) {
        this.strDate = strDate;
    }

    /**
     * @return the fnsDate
     */
    public String getFnsDate() {
        return fnsDate;
    }

    /**
     * @param fnsDate the fnsDate to set
     */
    public void setFnsDate(String fnsDate) {
        this.fnsDate = fnsDate;
    }

    /**
     * @return the saveType
     */
    public String getSaveType() {
        return saveType;
    }

    /**
     * @param saveType the saveType to set
     */
    public void setSaveType(String saveType) {
        this.saveType = saveType;
    }

    /**
     * @return the atchSe
     */
    public String getAtchSe() {
        return atchSe;
    }

    /**
     * @param atchSe the atchSe to set
     */
    public void setAtchSe(String atchSe) {
        this.atchSe = atchSe;
    }

    /**
     * @return the atchId
     */
    public String getAtchId() {
        return atchId;
    }

    /**
     * @param atchId the atchId to set
     */
    public void setAtchId(String atchId) {
        this.atchId = atchId;
    }

    /**
     * @return the seqNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo the seqNo to set
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @return the bbscttReply
     */
    public String getBbscttReply() {
        return bbscttReply;
    }

    /**
     * @param bbscttReply the bbscttReply to set
     */
    public void setBbscttReply(String bbscttReply) {
        this.bbscttReply = bbscttReply;
    }
}
