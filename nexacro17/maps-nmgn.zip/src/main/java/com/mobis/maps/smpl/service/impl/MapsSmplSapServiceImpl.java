package com.mobis.maps.smpl.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import able.com.service.HService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.sapjco.manager.Destination;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;
import com.mobis.maps.smpl.service.MapsSmplSapService;
import com.mobis.maps.smpl.vo.MapsSmplMsgVO;
import com.mobis.maps.smpl.vo.MapsSmplSbookVO;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsSampleSapServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Sin Sanghwan
 * @since 2019. 7. 16.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 16.     Sin Sanghwan     	최초 생성
 * </pre>
 */
@Service("mapsSmplSapService")
public class MapsSmplSapServiceImpl extends HService implements MapsSmplSapService {
    
    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.smpl.service.MapsSmplSapService#selectSbookList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.smpl.vo.MapsSmplSbookVO)
     */
    @Override
    public List<MapsSmplSbookVO> selectSbookList(LoginInfoVO loginInfo, MapsSmplSbookVO smplSbookVO) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSbookList::start");
        }
        /* 파라미터 정보 */
//        String carrId = smplSbookVO.getCarrId();
//        String allYn = smplSbookVO.getAllYn();
        //logger.debug("→ rfcSbookList.smplSbookVO[carrId=" + carrId + ",allYn=" + allYn + "]");
//        if (!StringUtils.equals(allYn, "X")) {
//            smplSbookVO.setAllYn(" ");
//        }

        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPCA_PDA_R_PAGING_SBOOK_1;
        smplSbookVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, smplSbookVO);
        // 파라미터(Import) 셋팅
//        func.getImportParameterList().setValue("I_CARRID", carrId);
//        func.getImportParameterList().setValue("I_ALL", allYn);
        MapsRfcMappperUtil.setImportParamList(func, smplSbookVO);
        
        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, smplSbookVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
//        Map<String, String> mapngInfo = new HashMap<String, String>();
//        mapngInfo.put("CARRID", "carrId");
//        mapngInfo.put("CARRNAME", "carrNm");
//        mapngInfo.put("CONNID", "connId");
//        mapngInfo.put("FLDATE", "flDate");
//        mapngInfo.put("BOOKID", "bookId");
//        mapngInfo.put("CLASS", "flClass");
//        mapngInfo.put("AGENCYNUM", "agencyNum");
//        mapngInfo.put("LOCCURAM", "locCurAm");
//        mapngInfo.put("LOCCURKEY", "locCurKey");
//        // 조회정보 매핑
//        List<MapsSmplSbookVO> lstSbook = mapsCmmnSapService.selectGetExportTablePgVO(funcRslt, smplSbookVO, "IT_DATA", mapngInfo, MapsSmplSbookVO.class);
//        
//        List<MapsSmplSbookVO> lstSbook = mapsCmmnSapService.selectGetExportTablePgVO(funcRslt, smplSbookVO, "IT_DATA", MapsSmplSbookVO.class);
        
        List<MapsSmplSbookVO> lstSbook = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_DATA", smplSbookVO, MapsSmplSbookVO.class);
        if (logger.isDebugEnabled()) {
            logger.debug("→ selectSbookList::end");
        }
        
        return lstSbook;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSmplSapService#rfcSbookList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.smpl.vo.MapsSmplSbookVO)
     */
    @Override
    public List<MapsSmplSbookVO> selectRfcSbookList(LoginInfoVO loginInfo, MapsSmplSbookVO smplSbookVO) throws Exception {

        String rfcId = "ZPCA_PDA_R_PAGING_SBOOK_1";
        List<MapsSmplSbookVO> lst = mapsCmmnSapService.selectRfcList(loginInfo, rfcId, smplSbookVO, MapsSmplSbookVO.class);
        
        return lst;
    }

    /*
     * @see com.mobis.maps.smpl.service.MapsSampleSapService#rfcSbookList(com.mobis.maps.smpl.vo.MapsSmplSbookVO)
     * ※ 태스트 전용
     */
    @Override
    public List<MapsSmplSbookVO> selectRfcSbookList(MapsSmplSbookVO smplSbookVO) throws Exception {
        //
        
        String carrId = smplSbookVO.getCarrId();
        String allYn = smplSbookVO.getAllYn();
        if( logger.isDebugEnabled()) {
            logger.debug("→ rfcSbookList.smplSbookVO[carrId=" + carrId + ",allYn=" + allYn + "]");
        }
        if (StringUtils.equals(allYn, "X")) {
            allYn = " ";
        }

        List<MapsSmplSbookVO> lstSbook = new ArrayList<MapsSmplSbookVO>();

        // Destination 얻어내기
        Destination destination = mapsCmmnSapService.selectDestination(Locale.KOREA);
        // RFC 얻어내기
        Function function = destination.getFunction("ZPCA_PDA_R_PAGING_SBOOK_1");
        // 공통파라미터(Import) 셋팅
        JCoStructure jsIfComm = function.getImportParameterList().getStructure("IS_IFCOMM");
        jsIfComm.setValue("IFCODE", smplSbookVO.getIfCode());
        jsIfComm.setValue("BUKRS", smplSbookVO.getBukRs());
        jsIfComm.setValue("TZONE", smplSbookVO.getTzone());
        if (StringUtils.equals(smplSbookVO.getPgType(), "S")) {
            jsIfComm.setValue("PGCNUM", smplSbookVO.getScrollPgNum());
            jsIfComm.setValue("PGSIZE", smplSbookVO.getScrollPgSize());
        } else {
            jsIfComm.setValue("PGCNUM", smplSbookVO.getPgNum());
            jsIfComm.setValue("PGSIZE", smplSbookVO.getPgSize());
        }
        // 파라미터(Import) 셋팅
        function.getImportParameterList().setValue("I_CARRID", carrId);
        function.getImportParameterList().setValue("I_ALL", allYn);
        // RFC 호출
        FunctionResult result = function.execute();
        // 파라미터(Export) 추출
        JCoStructure resReturn = result.getExportParameterList().getStructure("ES_RETURN");
        // 파라미터(Export, Tables) 출력
        smplSbookVO.setMsgType(resReturn.getString("MTYPE"));
        smplSbookVO.setMsgId(resReturn.getString("MSGID"));
        smplSbookVO.setMsgNo(resReturn.getString("MSGNO"));
        smplSbookVO.setMsg(resReturn.getString("MESSAGE"));
        // 파라미터(TABLES) 추출
        List<Map<String, Object>> lstData = result.getTable("IT_DATA");
        int rcnt = 0;
        int rnum = ((smplSbookVO.getPgNum() - 1) * smplSbookVO.getPgSize()) + 1;
        for (Map<String, Object> mSbook : lstData) {
            MapsSmplSbookVO smplSbook = new MapsSmplSbookVO();
            if (rcnt == 0) {
                smplSbook.setTotCnt(Integer.parseInt(StringUtils.trim(resReturn.getString("TOTCNT"))));
            }
            smplSbook.setRnum(rnum);
            smplSbook.setCarrId(String.valueOf(mSbook.get("CARRID")));
            smplSbook.setCarrNm(String.valueOf(mSbook.get("CARRNAME")));
            smplSbook.setConnId(String.valueOf(mSbook.get("CONNID")));
            smplSbook.setFlDate((Date)mSbook.get("FLDATE"));
            smplSbook.setBookId(String.valueOf(mSbook.get("BOOKID")));
            smplSbook.setFlClass(String.valueOf(mSbook.get("CLASS")));
            smplSbook.setAgencyNum(String.valueOf(mSbook.get("AGENCYNUM")));
            smplSbook.setLocCurAm(String.valueOf(mSbook.get("LOCCURAM")));
            smplSbook.setLocCurKey(String.valueOf(mSbook.get("LOCCURKEY")));

            lstSbook.add(smplSbook);
            rcnt++;
            rnum++;
        }
        
        return lstSbook;
    }
    
    /*
     * @see com.mobis.maps.sample.service.MapsSampleSapService#rfctMsgList(com.mobis.maps.sample.vo.MapsSampleMsgVO)
     * ※ 태스트 전용
     */
    @Override
    public List<MapsSmplMsgVO> selectRfcMsgList(MapsSmplMsgVO sampleMsgVO) throws Exception {
        if( logger.isDebugEnabled()) {
            logger.debug("→ selectMsgList.sampleMsgVO[werks=" + sampleMsgVO.getWerks() + "]");
        }
        String reqWerks = sampleMsgVO.getWerks();// "0001";
        List<MapsSmplMsgVO> lstMsg = new ArrayList<MapsSmplMsgVO>();

        String[][] reqData = { { "0001", "0088", "LAGER 0088 (WM)" }, { "0003", "0001", "LAGER 0001" } };
        
        Destination destination = mapsCmmnSapService.selectDestination(Locale.KOREA);
        // RFC 얻어내기
        Function function = destination.getFunction("ZPCA_PDA_R_REQ_STORAGE_LOC");
        // 파라미터(Import) 셋팅
        function.getImportParameterList().setValue("I_WERKS", reqWerks);
        // 파라미터(TABLES) 셋팅
        JCoTable tDataReq = function.getImportTableParameter("IT_DATA");
        for (String[] row : reqData) {
            tDataReq.appendRow();
            tDataReq.setValue("WERKS", row[0]);
            tDataReq.setValue("LGORT", row[1]);
            tDataReq.setValue("LGOBE", row[2]);
        }
        // RFC 호출
        FunctionResult result = function.execute();
        // 파라미터(Export) 추출
        JCoStructure resReturn = result.getExportStructure("ES_RETURN");
        // 파라미터(TABLES) 추출
        List<Map<String, Object>> tDataResp = result.getTable("IT_DATA");

        // 파라미터(Export, Tables) 출력
        sampleMsgVO.setMsgType(resReturn.getString("MTYPE"));
        sampleMsgVO.setMsgId(resReturn.getString("ID"));
        sampleMsgVO.setMsgNo(resReturn.getString("NUMBER"));
        sampleMsgVO.setMsg(resReturn.getString("MESSAGE"));

        for (Map<String, Object> row : tDataResp) {
            MapsSmplMsgVO msgVO = new MapsSmplMsgVO();
            msgVO.setWerks(String.valueOf(row.get("WERKS")));
            msgVO.setLgort(String.valueOf(row.get("LGORT")));
            msgVO.setLgobe(String.valueOf(row.get("LGOBE")));
            msgVO.setLifnr(String.valueOf(row.get("LIFNR")));
            msgVO.setKunnr(String.valueOf(row.get("KUNNR")));
            msgVO.setMenge(String.valueOf(row.get("MENGE")));
            msgVO.setMeins(String.valueOf(row.get("MEINS")));
            msgVO.setNetpr(String.valueOf(row.get("NETPR")));
            msgVO.setWaers(String.valueOf(row.get("WAERS")));
            msgVO.setDatum(String.valueOf(row.get("DATUM")));
            msgVO.setUzeit(String.valueOf(row.get("UZEIT")));
            msgVO.setDatlo(String.valueOf(row.get("DATLO")));
            msgVO.setTimlo(String.valueOf(row.get("TIMLO")));
            msgVO.setMsgType(String.valueOf(row.get("MTYPE")));
            msgVO.setMsgId(String.valueOf(row.get("ID")));
            msgVO.setMsgNo(String.valueOf(row.get("NUMBER")));
            msgVO.setMsg(String.valueOf(row.get("MESSAGE")));

            lstMsg.add(msgVO);
        }

        return lstMsg;
    }
}
