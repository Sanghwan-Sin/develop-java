package com.mobis.maps.nmgn.main.vo;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MobisDefaultMainVO.java
 * @Description : Main VO
 * @author jiyongdo
 * @since 2020. 8. 14.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 14.     jiyongdo     	최초 생성
 * </pre>
 */

public class MobisDefaultMainVO extends MapsCommSapRfcIfCommVO{

    //-----ZPSD_NMGN_R_MAIN_PAYMENT_DUE START-----
    /** ZPSD_NMGN_R_MAIN_PAYMENT_DUE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    //-----[ES_LIST_H] START-----
    /** Dist. Code */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** SD document currency */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="TOTCNT" )
    private String totcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_LIST_H", ipttSe="E", fieldKey="ZCALAMT_C" )
    private String zcalamtC;
    //-----[ES_LIST_H] END-----
    //-----ZPSD_NMGN_R_MAIN_PAYMENT_DUE END-----
     
    //-----ZPSD_NMGN_R_MAIN_BALANCE START-----
    /** ZPSD_NMGN_R_MAIN_BALANCE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZACTNO" )
    private String iZactno;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_WAERS" )
    private String eWaers;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZAMT_CURRENT" )
    private String eZamtCurrent;
    //-----ZPSD_NMGN_R_MAIN_BALANCE END-----
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the totcnt
     */
    public String getTotcnt() {
        return totcnt;
    }
    /**
     * @param totcnt the totcnt to set
     */
    public void setTotcnt(String totcnt) {
        this.totcnt = totcnt;
    }
    /**
     * @return the zcalamtC
     */
    public String getZcalamtC() {
        return zcalamtC;
    }
    /**
     * @param zcalamtC the zcalamtC to set
     */
    public void setZcalamtC(String zcalamtC) {
        this.zcalamtC = zcalamtC;
    }
    /**
     * @return the iZactno
     */
    public String getiZactno() {
        return iZactno;
    }
    /**
     * @param iZactno the iZactno to set
     */
    public void setiZactno(String iZactno) {
        this.iZactno = iZactno;
    }
    /**
     * @return the eWaers
     */
    public String geteWaers() {
        return eWaers;
    }
    /**
     * @param eWaers the eWaers to set
     */
    public void seteWaers(String eWaers) {
        this.eWaers = eWaers;
    }
    /**
     * @return the eZamtCurrent
     */
    public String geteZamtCurrent() {
        return eZamtCurrent;
    }
    /**
     * @param eZamtCurrent the eZamtCurrent to set
     */
    public void seteZamtCurrent(String eZamtCurrent) {
        this.eZamtCurrent = eZamtCurrent;
    }
}
