package com.mobis.maps.nmgn.ex.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PackingHeaderVO.java
 * @Description : ZPEX_MGN_GET_PACKING_HEADER
 * @author 이수지
 * @since 2020. 2. 3.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 3.       이수지     	       최초 생성
 * </pre>
 */

public class PackingHeaderVO extends MapsCommSapRfcIfCommVO {
    
    /** Carton Box Number */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CASE_NO" )
    private String iCaseNo;
    /** Container NO.fined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_CNTR_NO" )
    private String iCntrNo;
    /** Invoice No. */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_INVOICE" )
    private String iInvoice;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;

    /** -----[ET_LIST] START----- */
    
    /** Seq */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="SEQ" )
    private Integer seq;
    /** Carton Box Number */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CASE_NO" )
    private String caseNo;
    /** Net weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="NET_WEIGHT" )
    private BigDecimal netWeight;
    /** Gross weight */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="GROSSWEIGHT" )
    private BigDecimal grossweight;
    /** [EX] LENGTH */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="LENGTH" )
    private Integer len;
    /** [EX] WIDTH */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="WIDTH" )
    private Integer width;
    /** [EX] HEIGHT */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="HEIGHT" )
    private Integer height;
    /** CBM */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CBM" )
    private BigDecimal cbm;
    /** Container NO. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="CONTAINER_NO" )
    private String containerNo;
    /** Box Type */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="BOX_TYPE" )
    private String boxType;
    /** Pallet Y/N */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="PALLET_YN" )
    private String palletYn;
    /** Invoice No. */
    @MapsRfcMappper( targetName="ET_LIST", ipttSe="E", fieldKey="INVOICE" )
    private String invoice;
    
    /** -----[ET_LIST] END----- */
    
    /**
     * @return the iCaseNo
     */
    public String getiCaseNo() {
        return iCaseNo;
    }
    /**
     * @param iCaseNo the iCaseNo to set
     */
    public void setiCaseNo(String iCaseNo) {
        this.iCaseNo = iCaseNo;
    }
    /**
     * @return the iCntrNo
     */
    public String getiCntrNo() {
        return iCntrNo;
    }
    /**
     * @param iCntrNo the iCntrNo to set
     */
    public void setiCntrNo(String iCntrNo) {
        this.iCntrNo = iCntrNo;
    }
    /**
     * @return the iInvoice
     */
    public String getiInvoice() {
        return iInvoice;
    }
    /**
     * @param iInvoice the iInvoice to set
     */
    public void setiInvoice(String iInvoice) {
        this.iInvoice = iInvoice;
    }
    /**
     * @return the seq
     */
    public Integer getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    /**
     * @return the caseNo
     */
    public String getCaseNo() {
        return caseNo;
    }
    /**
     * @param caseNo the caseNo to set
     */
    public void setCaseNo(String caseNo) {
        this.caseNo = caseNo;
    }
    /**
     * @return the netWeight
     */
    public BigDecimal getNetWeight() {
        return netWeight;
    }
    /**
     * @param netWeight the netWeight to set
     */
    public void setNetWeight(BigDecimal netWeight) {
        this.netWeight = netWeight;
    }
    /**
     * @return the grossweight
     */
    public BigDecimal getGrossweight() {
        return grossweight;
    }
    /**
     * @param grossweight the grossweight to set
     */
    public void setGrossweight(BigDecimal grossweight) {
        this.grossweight = grossweight;
    }
    /**
     * @return the len
     */
    public Integer getLen() {
        return len;
    }
    /**
     * @param len the len to set
     */
    public void setLen(Integer len) {
        this.len = len;
    }
    /**
     * @return the width
     */
    public Integer getWidth() {
        return width;
    }
    /**
     * @param width the width to set
     */
    public void setWidth(Integer width) {
        this.width = width;
    }
    /**
     * @return the height
     */
    public Integer getHeight() {
        return height;
    }
    /**
     * @param height the height to set
     */
    public void setHeight(Integer height) {
        this.height = height;
    }
    /**
     * @return the cbm
     */
    public BigDecimal getCbm() {
        return cbm;
    }
    /**
     * @param cbm the cbm to set
     */
    public void setCbm(BigDecimal cbm) {
        this.cbm = cbm;
    }
    /**
     * @return the containerNo
     */
    public String getContainerNo() {
        return containerNo;
    }
    /**
     * @param containerNo the containerNo to set
     */
    public void setContainerNo(String containerNo) {
        this.containerNo = containerNo;
    }
    /**
     * @return the boxType
     */
    public String getBoxType() {
        return boxType;
    }
    /**
     * @param boxType the boxType to set
     */
    public void setBoxType(String boxType) {
        this.boxType = boxType;
    }
    /**
     * @return the palletYn
     */
    public String getPalletYn() {
        return palletYn;
    }
    /**
     * @param palletYn the palletYn to set
     */
    public void setPalletYn(String palletYn) {
        this.palletYn = palletYn;
    }
    /**
     * @return the invoice
     */
    public String getInvoice() {
        return invoice;
    }
    /**
     * @param invoice the invoice to set
     */
    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    
}
