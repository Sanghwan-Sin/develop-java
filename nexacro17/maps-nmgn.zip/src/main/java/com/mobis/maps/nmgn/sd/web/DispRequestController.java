package com.mobis.maps.nmgn.sd.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.service.DispRequestService;
import com.mobis.maps.nmgn.sd.vo.DispRequestVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DispRequestController.java
 * @Description : Search Request List
 * @author 이수지
 * @since 2020. 8. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 26.     이수지       	       최초 생성
 * </pre>
 */

@Controller
public class DispRequestController extends HController {

    @Resource(name = "dispRequestService")
    private DispRequestService dispRequestService;

    /**
     * selectSearchRequest
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectSearchRequest.do")
    public NexacroResult selectSearchRequest(@ParamDataSet(name="dsInput") DispRequestVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        List<DispRequestVO> list = dispRequestService.selectSearchRequest(loginInfo, params);

        result.addDataSet("dsReturn", params);
        result.addDataSet("dsOutput", list);
        
        return result;
    }
    
    /**
     * selectSearchRequestExcelDown
     *
     * @param params
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/sd/selectSearchRequestExcelDown.do")
    public NexacroResult selectSearchRequestExcelDown(@ParamDataSet(name="dsInput") DispRequestVO params
            , NexacroResult result) throws Exception {
        
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);
        
        params.setExcelDwnlYn("Y");
        params.setPgNum(1);
        params.setPgSize(params.getTotMaxCnt());
        
        List<DispRequestVO> list = dispRequestService.selectSearchRequest(loginInfo, params);

        result.addDataSet("dsOutput", list);
        
        return result;
    }
}
