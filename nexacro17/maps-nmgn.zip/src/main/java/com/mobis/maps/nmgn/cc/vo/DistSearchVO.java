package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DistSearchVO.java
 * @Description : 대리점 정보
 * @author hong.minho
 * @since 2020. 3. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 13.     hong.minho     	최초 생성
 * </pre>
 */

public class DistSearchVO extends PgBascVO {

    private String refYn       ; // 대표 대리점 여부
    private String refSacutm   ; // 대표 대리점 코드(6자리)
    private String zkunam      ; // 대리점명
    private String zsacutm     ; // 대리점 코드(6자리)
    private String vkorg       ; // 영업조직(법인코드)
    private String vtweg       ; // 유통경로
    private String kunnr       ; // 고객번호 (10자리)
    private String vkbur       ; // 영업소
    private String zlregio     ; // L-REGION
    private String zmregio     ; // M-REGION
    private String zsregio     ; // S-REGION
    private String zactno      ; // ACCOUNT (ZPSDT1000)
    private String zcustat     ; // 고객상태
    private String land1       ; // 국가코드
    private String kvgr1       ; // H/K 구분자
    private String ort01       ; // 도시
    private String stras       ; // 상세주소
    private String pstlz       ; // 우편번호
    private String zemail      ; // 이메일
    private String zpamre      ; // 기술사양지역 (PAM REGION)
    private String waers       ; // 화폐코드
    private String distDesc    ; // 대리점명 Description
    private String pltyp       ; // Price List Type
    
    /**
     * @return the refYn
     */
    public String getRefYn() {
        return refYn;
    }
    /**
     * @param refYn the refYn to set
     */
    public void setRefYn(String refYn) {
        this.refYn = refYn;
    }
    /**
     * @return the refSacutm
     */
    public String getRefSacutm() {
        return refSacutm;
    }
    /**
     * @param refSacutm the refSacutm to set
     */
    public void setRefSacutm(String refSacutm) {
        this.refSacutm = refSacutm;
    }
    /**
     * @return the zkunam
     */
    public String getZkunam() {
        return zkunam;
    }
    /**
     * @param zkunam the zkunam to set
     */
    public void setZkunam(String zkunam) {
        this.zkunam = zkunam;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the vkbur
     */
    public String getVkbur() {
        return vkbur;
    }
    /**
     * @param vkbur the vkbur to set
     */
    public void setVkbur(String vkbur) {
        this.vkbur = vkbur;
    }
    /**
     * @return the zlregio
     */
    public String getZlregio() {
        return zlregio;
    }
    /**
     * @param zlregio the zlregio to set
     */
    public void setZlregio(String zlregio) {
        this.zlregio = zlregio;
    }
    /**
     * @return the zmregio
     */
    public String getZmregio() {
        return zmregio;
    }
    /**
     * @param zmregio the zmregio to set
     */
    public void setZmregio(String zmregio) {
        this.zmregio = zmregio;
    }
    /**
     * @return the zsregio
     */
    public String getZsregio() {
        return zsregio;
    }
    /**
     * @param zsregio the zsregio to set
     */
    public void setZsregio(String zsregio) {
        this.zsregio = zsregio;
    }
    /**
     * @return the zactno
     */
    public String getZactno() {
        return zactno;
    }
    /**
     * @param zactno the zactno to set
     */
    public void setZactno(String zactno) {
        this.zactno = zactno;
    }
    /**
     * @return the zcustat
     */
    public String getZcustat() {
        return zcustat;
    }
    /**
     * @param zcustat the zcustat to set
     */
    public void setZcustat(String zcustat) {
        this.zcustat = zcustat;
    }
    /**
     * @return the land1
     */
    public String getLand1() {
        return land1;
    }
    /**
     * @param land1 the land1 to set
     */
    public void setLand1(String land1) {
        this.land1 = land1;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the ort01
     */
    public String getOrt01() {
        return ort01;
    }
    /**
     * @param ort01 the ort01 to set
     */
    public void setOrt01(String ort01) {
        this.ort01 = ort01;
    }
    /**
     * @return the stras
     */
    public String getStras() {
        return stras;
    }
    /**
     * @param stras the stras to set
     */
    public void setStras(String stras) {
        this.stras = stras;
    }
    /**
     * @return the pstlz
     */
    public String getPstlz() {
        return pstlz;
    }
    /**
     * @param pstlz the pstlz to set
     */
    public void setPstlz(String pstlz) {
        this.pstlz = pstlz;
    }
    /**
     * @return the zemail
     */
    public String getZemail() {
        return zemail;
    }
    /**
     * @param zemail the zemail to set
     */
    public void setZemail(String zemail) {
        this.zemail = zemail;
    }
    /**
     * @return the zpamre
     */
    public String getZpamre() {
        return zpamre;
    }
    /**
     * @param zpamre the zpamre to set
     */
    public void setZpamre(String zpamre) {
        this.zpamre = zpamre;
    }
    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }
    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }
    /**
     * @return the distDesc
     */
    public String getDistDesc() {
        return distDesc;
    }
    /**
     * @param distDesc the distDesc to set
     */
    public void setDistDesc(String distDesc) {
        this.distDesc = distDesc;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    
}
