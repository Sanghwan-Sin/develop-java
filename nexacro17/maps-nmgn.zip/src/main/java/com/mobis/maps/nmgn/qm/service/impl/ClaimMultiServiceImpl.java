package com.mobis.maps.nmgn.qm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.exception.MapsBizException;
import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.qm.service.ClaimMultiService;
import com.mobis.maps.nmgn.qm.vo.ClaimMultiCheckVO;
import com.mobis.maps.nmgn.qm.vo.ClaimMultiSaveVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimMultiServiceImpl.java
 * @Description : Multi Claim 처리
 *                ZPQM_NMGN_R_CLAIM_MULTI_CHECK
 *                ZPQM_NMGN_R_CLAIM_MULTI_SAVE
 * @author hong.minho
 * @since 2020. 10. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 10. 26.     hong.minho     	최초 생성
 * </pre>
 */

@Service("claimMultiService")
public class ClaimMultiServiceImpl extends HService implements ClaimMultiService {

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.qm.service.ClaimMultiService#multiCheckClaim(com.mobis.maps.nmgn.qm.vo.ClaimMultiCheckVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<ClaimMultiCheckVO> multiCheckClaim(ClaimMultiCheckVO params, List<ClaimMultiCheckVO> paramLst, LoginInfoVO loginVo)
            throws MapsBizException, Exception {
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_R_CLAIM_MULTI_CHECK;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
      
        // Claim List(T_DATA) 적재
        for(ClaimMultiCheckVO vo : paramLst) {
            MapsRfcMappperUtil.appendImportTableRow(func, "T_DATA", vo);
        }
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
//        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 처리결과
        List<ClaimMultiCheckVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", params, ClaimMultiCheckVO.class);
        
        for(int idx = 0; list != null && idx < list.size(); idx++) {
            ClaimMultiCheckVO vo = list.get(idx);
            if (vo == null) continue;
            
            if (!"E".equals(vo.getMtype())) {
                vo.setMtype("S");
                vo.setMessage("OK");
            
            } else {
                // 오류
                vo.setChkYn("Y");
            }
            
        }
        
        
        return list;
    }

    
    /*
     * @see com.mobis.maps.nmgn.qm.service.ClaimMultiService#multiSaveClaim(com.mobis.maps.nmgn.qm.vo.ClaimMultiSaveVO, java.util.List, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public List<ClaimMultiSaveVO> multiSaveClaim(ClaimMultiSaveVO params, List<ClaimMultiSaveVO> paramLst, LoginInfoVO loginVo) throws MapsBizException, Exception {
        
        // I_CRUD
        if (params.getiCrud() == null || params.getiCrud().trim().length() <= 0) {
            params.setiCrud("A1"); // default A1 생성
        }
        
        //*** RFC Function 취득
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPQM_NMGN_R_CLAIM_MULTI_SAVE;
        
        params.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginVo, sapRfcInfo.name());
        
        //*** 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginVo, func, params);
        
        //*** 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, params);
      
        // Claim List(T_DATA) 적재
        for(ClaimMultiSaveVO vo : paramLst) {
            if (vo == null) continue;
            if (!"S".equals(vo.getMtype())) continue; // 성공건만 적재
            
            vo.setZchcrid(loginVo.getUserId()); // userId
            vo.setZchcridname(loginVo.getUserNm()); // userNm
            vo.setZsubmbyname(loginVo.getUserNm()); // userNm
                
            MapsRfcMappperUtil.appendImportTableRow(func, "T_DATA", vo);
        }
        
        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginVo, func);
        
        //*** RFC 호출결과 정보 추출
//        mapsCmmnSapService.selectSetRfcResult(funcRslt, params);
        
        //*** 처리결과
        List<ClaimMultiSaveVO> list = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "T_DATA", params, ClaimMultiSaveVO.class);
        
        for(int idx = 0; list != null && idx < list.size(); idx++) {
            ClaimMultiSaveVO vo = list.get(idx);
            if (vo == null) continue;
            
            if (!"E".equals(vo.getMtype())) {
                vo.setMtype("S");
                vo.setMessage("OK");
                vo.setTflag("Y");
            }
        }
        
        return list;
    }

}
