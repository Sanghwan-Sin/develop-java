package com.mobis.maps.nmgn.cc.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mobis.maps.cmmn.constants.MapsConstants;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.SearchInfoService;
import com.mobis.maps.nmgn.cc.vo.SearchInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SearchInfoController.java
 * @Description : 공통 Search Help 조회
 * @author DT060152
 * @since 2020.02.05.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020.02.05.     DT060152     	최초 생성
 *  2020.03.30.     DT060152        부품명 조회 추가
 *  2020.03.31.     DT060152        회사코드 조회 추가
 * </pre>
 */

@Controller
public class SearchInfoController extends HController {

    @Resource(name = "searchInfoService")
    private SearchInfoService searchInfoService;
    
    /***
     * 플렌트/사급업체/제품업체/국가코드 조회
     * Statements
     *
     * @param paramVO
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/cc/selectSearchInfoList.do")
    public NexacroResult selectSearchInfoList(@ParamDataSet(name="dsInput") SearchInfoVO paramVO
                                              , NexacroResult result) throws Exception {
        LoginInfoVO loginInfo = (LoginInfoVO) getSessionAttribute(MapsConstants.SSS_LOGIN_INFO);

        Map<String, Object> rsltMap = searchInfoService.selectSearchInfoList(loginInfo, paramVO);

        if (rsltMap != null) {
            SearchInfoVO esReturn = (SearchInfoVO)rsltMap.get("esReturn");
            @SuppressWarnings("unchecked")
            List<SearchInfoVO> etData = (List<SearchInfoVO>)rsltMap.get("etData");
            
            result.addDataSet("dsEsRetrun", esReturn);
            result.addDataSet("dsOutput", etData);
        }

        return result;
    }
}
