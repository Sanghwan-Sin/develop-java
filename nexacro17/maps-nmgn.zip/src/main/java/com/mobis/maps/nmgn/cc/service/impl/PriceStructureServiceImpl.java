package com.mobis.maps.nmgn.cc.service.impl;

import java.util.Calendar;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.cc.service.PriceStructureService;
import com.mobis.maps.nmgn.cc.service.dao.PriceStructureMDAO;
import com.mobis.maps.nmgn.cc.vo.PriceStructureVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PriceStructureServiceImpl.java
 * @Description : PriceStructureServiceImpl
 * @author ha.jeongryeong
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     ha.jeongryeong         최초 생성
 * </pre>
 */
@Service("priceStructureService")
public class PriceStructureServiceImpl extends HService implements PriceStructureService {

    @Resource(name = "priceStructureMDAO")
    private PriceStructureMDAO priceStructureMDAO;
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.PriceStructureService#selectPriceStructure(com.mobis.maps.nmgn.cc.vo.PriceStructureVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public PriceStructureVO selectPriceStructure(PriceStructureVO paramVO, LoginInfoVO loginInfo) {
        PriceStructureVO retVO = priceStructureMDAO.selectPriceStructure(paramVO);
        
        return retVO;
    }

    /*
     * @see com.mobis.maps.nmgn.cc.service.PriceStructureService#multiPriceStructure(com.mobis.maps.nmgn.cc.vo.PriceStructureVO, com.mobis.maps.cmmn.vo.LoginInfoVO)
     */
    @Override
    public int multiPriceStructure(PriceStructureVO paramVO, LoginInfoVO loginInfo) throws Exception{
        
        paramVO.setAplyYear(Integer.toString(Calendar.getInstance().get(Calendar.YEAR)));
        paramVO.setUpdtId(loginInfo.getUserId());
        
        int nRslt = priceStructureMDAO.insertPriceStructure(paramVO);
        
        return nRslt;
    }
    
}
