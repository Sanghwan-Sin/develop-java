package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderConfirmationListVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author ChoKyungHo
 * @since 2020. 02. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 02. 20.    ChoKyungHo      	        최초 생성
 * </pre>
 */

public class OrderConfirmationListVO extends MapsCommSapRfcIfCommVO{

    /** A: SPACEl, X, N */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ACODE_F" )
    private String iAcodeF;
    /** C:Create, U:Change, R:Display, D:Delete */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** AMEND CODE LAST */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAMDCL" )
    private String iZamdcl;
    /** ORDER HEAD FLAG CODE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZOHFCD" )
    private String iZohfcd;
    /** 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_E" )
    private String iZordnoE;
    /** 고객 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_P" )
    private String iZordnoP;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDLN" )
    private String iZordln;
    /** [SD] Order Header & Item 정보를 조회 및 생성 SAP<->Channel */
    /** 신보주문번호 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDNO" )
    private String zordno;
    /** 고객 오더번호 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDNO_P" )
    private String zordnoP;
    /** 오더번호 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /** C:Create, U:Change, R:Display, D:Delete */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="TYPE" )
    private String type;
    /** 영업 조직 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="VKORG" )
    private String vkorg;
    /** 유통 경로 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="VTWEG" )
    private String vtweg;
    /** 제품군 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="SPART" )
    private String spart;
    /** 영업소 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="VKBUR" )
    private String vkbur;
    /** 영업 그룹 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="VKGRP" )
    private String vkgrp;
    /** 고객 번호 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="KUNNR" )
    private String kunnr;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /** H/K */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="KVGR1" )
    private String kvgr1;
    /** 오더유형 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDTYP" )
    private String zordtyp;
    /** 출하 유형 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="VSART" )
    private String vsart;
    /** 근거번호 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZREM_NO" )
    private String zremNo;
    /** Message */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZMESSAGE" )
    private String zmessage;
    /** Memo */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZMEMO" )
    private String zmemo;
    /** ORDERED DATE */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDDT" )
    private Date zorddt;
    /** CONFIRME DATE */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZCFMDT" )
    private Date zcfmdt;
    /** 완성차변경일시분 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZDLRDT" )
    private String zdlrdt;
    /** ORDER HEAD PROCESS CODE */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZOHPCD" )
    private String zohpcd;
    /** ORDER HEAD FLAG CODE */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZOHFCD" )
    private String zohfcd;
    /** Quantity(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZITEM_H" )
    private String zitemH;
    /** Quantity(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZPCS_H" )
    private String zpcsH;
    /** SD 문서 통화 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZAMT_H" )
    private String zamtH;
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZTAX_H" )
    private String ztaxH;
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZTOTAMT_H" )
    private String ztotamtH;
    /** DATA COMMUNI */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZCOMTY" )
    private String zcomty;
    /** 청구품목번호(Order Line No) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDLN" )
    private BigDecimal zordln;
    /** 오더 Line Suffix */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDLS" )
    private String zordls;
    /** 최초부품코드 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZMATNR_INPUT" )
    private String zmatnrInput;
    /** 자재 번호 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** 자재내역 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** Quantity(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZORDQTY" )
    private String zordqty;
    /** Quantity(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZCFMQTY" )
    private String zcfmqty;
    /** Quantity(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZBOQTY" )
    private String zboqty;
    /** Quantity(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZSUPQTY" )
    private String zsupqty;
    /** CONFIRM APPLY FLAG */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZCFAFG" )
    private String zcfafg;
    /** 판매 단위 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="VRKME" )
    private String vrkme;
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="NETPR" )
    private String netpr;
    /** Net Value(20자리) */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZAMOUNT" )
    private String zamount;
    /** AMEND CODE LAST */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZAMDCL" )
    private String zamdcl;
    /** 번호 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="CCNGN" )
    private String ccngn;
    /** Memo */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZIMEMO" )
    private String zimemo;
    /** ORDER DETAIL FLAG CODE */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZODFCD" )
    private String zodfcd;
    /** 문자 100 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZCHKMSG" )
    private String zchkmsg;
    /** SUC CODE-최종 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZSUCCD" )
    private String zsuccd;
    /** 코드 명 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="ZSUCCD_NM" )
    private String zsuccdNm;
    /** 메세지 결과: S 성공, E 오류 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MTYPE" )
    private String mtype;
    /** 메시지 텍스트 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MESSAGE" )
    private String message;
    /** Message Class */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MSGID" )
    private String msgid;
    /** 메시지 번호 */
    @MapsRfcMappper( targetName="IT_RESULT", ipttSe="E", fieldKey="MSGNO" )
    private BigDecimal msgno;
    
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZamdcl
     */
    public String getiZamdcl() {
        return iZamdcl;
    }
    /**
     * @param iZamdcl the iZamdcl to set
     */
    public void setiZamdcl(String iZamdcl) {
        this.iZamdcl = iZamdcl;
    }
    /**
     * @return the iZohfcd
     */
    public String getiZohfcd() {
        return iZohfcd;
    }
    /**
     * @param iZohfcd the iZohfcd to set
     */
    public void setiZohfcd(String iZohfcd) {
        this.iZohfcd = iZohfcd;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the iZordnoP
     */
    public String getiZordnoP() {
        return iZordnoP;
    }
    /**
     * @param iZordnoP the iZordnoP to set
     */
    public void setiZordnoP(String iZordnoP) {
        this.iZordnoP = iZordnoP;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the zordnoP
     */
    public String getZordnoP() {
        return zordnoP;
    }
    /**
     * @param zordnoP the zordnoP to set
     */
    public void setZordnoP(String zordnoP) {
        this.zordnoP = zordnoP;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the vkorg
     */
    public String getVkorg() {
        return vkorg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }
    /**
     * @return the vtweg
     */
    public String getVtweg() {
        return vtweg;
    }
    /**
     * @param vtweg the vtweg to set
     */
    public void setVtweg(String vtweg) {
        this.vtweg = vtweg;
    }
    /**
     * @return the spart
     */
    public String getSpart() {
        return spart;
    }
    /**
     * @param spart the spart to set
     */
    public void setSpart(String spart) {
        this.spart = spart;
    }
    /**
     * @return the vkbur
     */
    public String getVkbur() {
        return vkbur;
    }
    /**
     * @param vkbur the vkbur to set
     */
    public void setVkbur(String vkbur) {
        this.vkbur = vkbur;
    }
    /**
     * @return the vkgrp
     */
    public String getVkgrp() {
        return vkgrp;
    }
    /**
     * @param vkgrp the vkgrp to set
     */
    public void setVkgrp(String vkgrp) {
        this.vkgrp = vkgrp;
    }
    /**
     * @return the kunnr
     */
    public String getKunnr() {
        return kunnr;
    }
    /**
     * @param kunnr the kunnr to set
     */
    public void setKunnr(String kunnr) {
        this.kunnr = kunnr;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the kvgr1
     */
    public String getKvgr1() {
        return kvgr1;
    }
    /**
     * @param kvgr1 the kvgr1 to set
     */
    public void setKvgr1(String kvgr1) {
        this.kvgr1 = kvgr1;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the vsart
     */
    public String getVsart() {
        return vsart;
    }
    /**
     * @param vsart the vsart to set
     */
    public void setVsart(String vsart) {
        this.vsart = vsart;
    }
    /**
     * @return the zremNo
     */
    public String getZremNo() {
        return zremNo;
    }
    /**
     * @param zremNo the zremNo to set
     */
    public void setZremNo(String zremNo) {
        this.zremNo = zremNo;
    }
    /**
     * @return the zmemo
     */
    public String getZmemo() {
        return zmemo;
    }
    /**
     * @param zmemo the zmemo to set
     */
    public void setZmemo(String zmemo) {
        this.zmemo = zmemo;
    }
    /**
     * @return the zorddt
     */
    public Date getZorddt() {
        return zorddt;
    }
    /**
     * @param zorddt the zorddt to set
     */
    public void setZorddt(Date zorddt) {
        this.zorddt = zorddt;
    }
    /**
     * @return the zcfmdt
     */
    public Date getZcfmdt() {
        return zcfmdt;
    }
    /**
     * @param zcfmdt the zcfmdt to set
     */
    public void setZcfmdt(Date zcfmdt) {
        this.zcfmdt = zcfmdt;
    }
    /**
     * @return the zdlrdt
     */
    public String getZdlrdt() {
        return zdlrdt;
    }
    /**
     * @param zdlrdt the zdlrdt to set
     */
    public void setZdlrdt(String zdlrdt) {
        this.zdlrdt = zdlrdt;
    }
    /**
     * @return the zohpcd
     */
    public String getZohpcd() {
        return zohpcd;
    }
    /**
     * @param zohpcd the zohpcd to set
     */
    public void setZohpcd(String zohpcd) {
        this.zohpcd = zohpcd;
    }
    /**
     * @return the zohfcd
     */
    public String getZohfcd() {
        return zohfcd;
    }
    /**
     * @param zohfcd the zohfcd to set
     */
    public void setZohfcd(String zohfcd) {
        this.zohfcd = zohfcd;
    }
    /**
     * @return the zitemH
     */
    public String getZitemH() {
        return zitemH;
    }
    /**
     * @param zitemH the zitemH to set
     */
    public void setZitemH(String zitemH) {
        this.zitemH = zitemH;
    }
    /**
     * @return the zpcsH
     */
    public String getZpcsH() {
        return zpcsH;
    }
    /**
     * @param zpcsH the zpcsH to set
     */
    public void setZpcsH(String zpcsH) {
        this.zpcsH = zpcsH;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the zamtH
     */
    public String getZamtH() {
        return zamtH;
    }
    /**
     * @param zamtH the zamtH to set
     */
    public void setZamtH(String zamtH) {
        this.zamtH = zamtH;
    }
    /**
     * @return the ztaxH
     */
    public String getZtaxH() {
        return ztaxH;
    }
    /**
     * @param ztaxH the ztaxH to set
     */
    public void setZtaxH(String ztaxH) {
        this.ztaxH = ztaxH;
    }
    /**
     * @return the ztotamtH
     */
    public String getZtotamtH() {
        return ztotamtH;
    }
    /**
     * @param ztotamtH the ztotamtH to set
     */
    public void setZtotamtH(String ztotamtH) {
        this.ztotamtH = ztotamtH;
    }
    /**
     * @return the zcomty
     */
    public String getZcomty() {
        return zcomty;
    }
    /**
     * @param zcomty the zcomty to set
     */
    public void setZcomty(String zcomty) {
        this.zcomty = zcomty;
    }
    /**
     * @return the zordln
     */
    public BigDecimal getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(BigDecimal zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zordls
     */
    public String getZordls() {
        return zordls;
    }
    /**
     * @param zordls the zordls to set
     */
    public void setZordls(String zordls) {
        this.zordls = zordls;
    }
    /**
     * @return the zmatnrInput
     */
    public String getZmatnrInput() {
        return zmatnrInput;
    }
    /**
     * @param zmatnrInput the zmatnrInput to set
     */
    public void setZmatnrInput(String zmatnrInput) {
        this.zmatnrInput = zmatnrInput;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the zordqty
     */
    public String getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(String zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zcfmqty
     */
    public String getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(String zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zsupqty
     */
    public String getZsupqty() {
        return zsupqty;
    }
    /**
     * @param zsupqty the zsupqty to set
     */
    public void setZsupqty(String zsupqty) {
        this.zsupqty = zsupqty;
    }
    /**
     * @return the vrkme
     */
    public String getVrkme() {
        return vrkme;
    }
    /**
     * @param vrkme the vrkme to set
     */
    public void setVrkme(String vrkme) {
        this.vrkme = vrkme;
    }
    /**
     * @return the netpr
     */
    public String getNetpr() {
        return netpr;
    }
    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(String netpr) {
        this.netpr = netpr;
    }
    /**
     * @return the zamount
     */
    public String getZamount() {
        return zamount;
    }
    /**
     * @param zamount the zamount to set
     */
    public void setZamount(String zamount) {
        this.zamount = zamount;
    }
    /**
     * @return the zamdcl
     */
    public String getZamdcl() {
        return zamdcl;
    }
    /**
     * @param zamdcl the zamdcl to set
     */
    public void setZamdcl(String zamdcl) {
        this.zamdcl = zamdcl;
    }
    /**
     * @return the ccngn
     */
    public String getCcngn() {
        return ccngn;
    }
    /**
     * @param ccngn the ccngn to set
     */
    public void setCcngn(String ccngn) {
        this.ccngn = ccngn;
    }
    /**
     * @return the zimemo
     */
    public String getZimemo() {
        return zimemo;
    }
    /**
     * @param zimemo the zimemo to set
     */
    public void setZimemo(String zimemo) {
        this.zimemo = zimemo;
    }
    /**
     * @return the zodfcd
     */
    public String getZodfcd() {
        return zodfcd;
    }
    /**
     * @param zodfcd the zodfcd to set
     */
    public void setZodfcd(String zodfcd) {
        this.zodfcd = zodfcd;
    }
    /**
     * @return the zchkmsg
     */
    public String getZchkmsg() {
        return zchkmsg;
    }
    /**
     * @param zchkmsg the zchkmsg to set
     */
    public void setZchkmsg(String zchkmsg) {
        this.zchkmsg = zchkmsg;
    }
    /**
     * @return the zsuccd
     */
    public String getZsuccd() {
        return zsuccd;
    }
    /**
     * @param zsuccd the zsuccd to set
     */
    public void setZsuccd(String zsuccd) {
        this.zsuccd = zsuccd;
    }
    /**
     * @return the zsuccdNm
     */
    public String getZsuccdNm() {
        return zsuccdNm;
    }
    /**
     * @param zsuccdNm the zsuccdNm to set
     */
    public void setZsuccdNm(String zsuccdNm) {
        this.zsuccdNm = zsuccdNm;
    }
    /**
     * @return the mtype
     */
    public String getMtype() {
        return mtype;
    }
    /**
     * @param mtype the mtype to set
     */
    public void setMtype(String mtype) {
        this.mtype = mtype;
    }
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @return the msgid
     */
    public String getMsgid() {
        return msgid;
    }
    /**
     * @param msgid the msgid to set
     */
    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }
    /**
     * @return the msgno
     */
    public BigDecimal getMsgno() {
        return msgno;
    }
    /**
     * @param msgno the msgno to set
     */
    public void setMsgno(BigDecimal msgno) {
        this.msgno = msgno;
    }
    /**
     * @return the zcfafg
     */
    public String getZcfafg() {
        return zcfafg;
    }
    /**
     * @param zcfafg the zcfafg to set
     */
    public void setZcfafg(String zcfafg) {
        this.zcfafg = zcfafg;
    }
    /**
     * @return the iAcodeF
     */
    public String getiAcodeF() {
        return iAcodeF;
    }
    /**
     * @param iAcodeF the iAcodeF to set
     */
    public void setiAcodeF(String iAcodeF) {
        this.iAcodeF = iAcodeF;
    }
    /**
     * @return the iZordln
     */
    public String getiZordln() {
        return iZordln;
    }
    /**
     * @param iZordln the iZordln to set
     */
    public void setiZordln(String iZordln) {
        this.iZordln = iZordln;
    }
    /**
     * @return the zmessage
     */
    public String getZmessage() {
        return zmessage;
    }
    /**
     * @param zmessage the zmessage to set
     */
    public void setZmessage(String zmessage) {
        this.zmessage = zmessage;
    }
}
