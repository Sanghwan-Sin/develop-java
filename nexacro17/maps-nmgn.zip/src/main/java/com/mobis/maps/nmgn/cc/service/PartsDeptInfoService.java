package com.mobis.maps.nmgn.cc.service;

import java.util.List;

import com.mobis.maps.nmgn.cc.vo.PartsDeptInfoVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartsDeptInfoService.java
 * @Description : PartsDeptInfoService
 * @author ha.jeongryeong
 * @since 2019. 8. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 20.     ha.jeongryeong         최초 생성
 * </pre>
 */

public interface PartsDeptInfoService {

 
    /**
     * 조회(detail)
     *
     * @param inputVO
     * @return
     */
    public PartsDeptInfoVO selectPartsDeptInfo(PartsDeptInfoVO paramVO) throws Exception;
    
    /**
     * 저장(detail)
     *
     * @param inputVO
     * @return
     */
    int multiPartsDeptInfo(PartsDeptInfoVO paramVO) throws Exception;
}
