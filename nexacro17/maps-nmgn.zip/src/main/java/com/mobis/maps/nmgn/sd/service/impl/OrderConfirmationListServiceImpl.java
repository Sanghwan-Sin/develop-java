package com.mobis.maps.nmgn.sd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import com.mobis.maps.cmmn.util.MapsRfcMappperUtil;
import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.comm.service.MapsCommSapService;
import com.mobis.maps.nmgn.constants.MapsSapRfcInfo;
import com.mobis.maps.nmgn.sd.service.OrderConfirmationListService;
import com.mobis.maps.nmgn.sd.vo.OrderConfirmationListVO;
import com.mobis.maps.nmgn.sd.vo.OrderNoListVO;
import com.mobis.maps.sapjco.manager.Function;
import com.mobis.maps.sapjco.manager.FunctionResult;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderConfirmationListServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author ChoKyungHo
 * @since 2020. 02. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 02. 20.    ChoKyungHo     	         최초 생성
 * </pre>
 */

@Service("orderConfirmationListService")
public class OrderConfirmationListServiceImpl extends HService implements OrderConfirmationListService{

    @Resource(name = "mapsCmmnSapService")
    private MapsCommSapService mapsCmmnSapService;
    
    /*
     * @see com.mobis.maps.nmgn.cc.service.OrderListService#selectSbookList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.cc.vo.OrderConfirmationListVO)
     */
    @Override
    public List<OrderConfirmationListVO> selectOrderConfirmationList(LoginInfoVO loginInfo, OrderConfirmationListVO paramVO) throws Exception {
     
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);

        //*** RFC 호출
        FunctionResult funcRslt = mapsCmmnSapService.selectExecute(loginInfo, func);
        
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<OrderConfirmationListVO> odrConfLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_RESULT", paramVO, OrderConfirmationListVO.class);

        return odrConfLst;
    }

    /*
     * @see com.mobis.maps.nmgn.sd.service.OrderConfirmationListService#selectOrderNoList(com.mobis.maps.cmmn.vo.LoginInfoVO, com.mobis.maps.nmgn.sd.vo.OrderNoListVO)
     */
    @Override
    public List<OrderNoListVO> selectOrderNoList(LoginInfoVO loginInfo, OrderNoListVO paramVO) throws Exception {
        
        /* RFC Function 취득 */
        MapsSapRfcInfo sapRfcInfo = MapsSapRfcInfo.ZPSD_NMGN_R_ORDER_NO;
        paramVO.setIfCode(sapRfcInfo.getIfCode());
        Function func = mapsCmmnSapService.selectFunction(loginInfo, sapRfcInfo.name());
        /* RFC 파라미터(Import) 셋팅 */
        // 공통파라미터(Import) 셋팅
        mapsCmmnSapService.selectSetRfcIfComm(loginInfo, func, paramVO);
        // 파라미터(Import) 셋팅
        MapsRfcMappperUtil.setImportParamList(func, paramVO);
        /* RFC 호출 */
        // RFC 호출 실행
        FunctionResult funcRslt = func.execute();
        // RFC 호출 공통결과 정보 추출
        mapsCmmnSapService.selectSetRfcResult(funcRslt, paramVO);
        /* RFC 호출 조회정보 추출 */
        // 조회정보 매핑정보 생성
        List<OrderNoListVO> odrConfLst = MapsRfcMappperUtil.getExportTablePaging(funcRslt, "IT_RESULT", paramVO, OrderNoListVO.class);

        return odrConfLst;
    }

}
