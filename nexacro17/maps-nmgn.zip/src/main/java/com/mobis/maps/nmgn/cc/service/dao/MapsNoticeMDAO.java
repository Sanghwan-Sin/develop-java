package com.mobis.maps.nmgn.cc.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;

import com.mobis.maps.nmgn.cc.vo.MapsNoticeVO;



/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : MapsNoticeMDAO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Jiyongdo
 * @since 2019. 8. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 8. 22.     Jiyongdo     	최초 생성
 * </pre>
 */

@Mapper("mapsNoticeMDAO")
public interface MapsNoticeMDAO {

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    List<MapsNoticeVO> selectNoticeList(MapsNoticeVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsNoticeVO selectNoticeNewList(MapsNoticeVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int insertNotice(MapsNoticeVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int updateNotice(MapsNoticeVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int deleteNotice(MapsNoticeVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsNoticeVO selectContId(MapsNoticeVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    MapsNoticeVO selectSeq(MapsNoticeVO inputVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    int insertNoticeRply(MapsNoticeVO inputVO);

    /**
     * Statements
     *
     * @param mapsNoticeVO
     * @return 
     */
    int updateNoticeRdCnt(MapsNoticeVO mapsNoticeVO);

    /**
     * Statements
     *
     * @param inputVO
     * @return
     */
    List<MapsNoticeVO> selectMainNoticeList(MapsNoticeVO inputVO);

}
