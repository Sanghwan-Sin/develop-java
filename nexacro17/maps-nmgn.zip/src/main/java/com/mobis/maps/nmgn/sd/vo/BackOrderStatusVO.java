package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : BackOrderStatusVO.java
 * @Description : ZPSD_NMGN_R_BORDER_STATUS
 * @author 이수지
 * @since 2020. 06. 08.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 08.     이수지     	       최초 생성
 * </pre>
 */

public class BackOrderStatusVO extends MapsCommSapRfcIfCommVO {
    
    /** All(A), Non Processing(P),할당(N) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_BO_OPT" )
    private String iBoOpt;
    /** All(A), Existence(E), Non Existence(N) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ETD_OPT" )
    private String iEtdOpt;
    /** O : Ordered Date (디폴트), C : Confirmed Date, E : ETD  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_OPT_DATE" )
    private String iOptDate;
    /** Material */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_PARTNO" )
    private String iPartno;
    /** C:Create, U:Change, R:Display */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** ORDER HEAD PROCESS CODE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZOHPCD" )
    private String iZohpcd;
    /** ORDERED DATE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_FR" )
    private Date iZorddtFr;
    /** ORDERED DATE */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDDT_TO" )
    private Date iZorddtTo;
    /** 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_E" )
    private String iZordnoE;
    /** 고객 오더번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDNO_P" )
    private String iZordnoP;
    /** Order Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZORDTYP" )
    private String iZordtyp;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** Customer */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    /** ORDER HEAD PROCESS CODE ( =' ') */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZOHPCD_EQ" )
    private String iZohpcdEq;

    /** -----[ES_TOTAL] START----- */
    
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZORDCNT" )
    private BigDecimal zordcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCFMCNT" )
    private BigDecimal zcfmcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCANCCNT" )
    private BigDecimal zcanccnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZBOCNT" )
    private BigDecimal zbocnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZALOCNT" )
    private BigDecimal zalocnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICCNT_ON" )
    private BigDecimal zpiccntOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACCNT_ON" )
    private BigDecimal zpaccntOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICCNT" )
    private BigDecimal zpiccnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACCNT" )
    private BigDecimal zpaccnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZINVCNT" )
    private BigDecimal zinvcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZSHPCNT" )
    private BigDecimal zshpcnt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZORDQTY" )
    private String zordqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCFMQTY" )
    private String zcfmqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZCANCQTY" )
    private String zcancqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZBOQTY" )
    private String zboqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZALOQTY" )
    private String zaloqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPICQTY_ON" )
    private String zpicqtyOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPACQTY_ON" )
    private String zpacqtyOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPICQTY" )
    private String zpicqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZPACQTY" )
    private String zpacqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZINVQTY" )
    private String zinvqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZSHPQTY" )
    private String zshpqty;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL|T_RESULT", ipttSe="E", fieldKey="ZORDAMT" )
    private String zordamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCFMAMT" )
    private String zcfmamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZCANCAMT" )
    private String zcancamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZBOAMT" )
    private String zboamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZALOAMT" )
    private String zaloamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICAMT_ON" )
    private String zpicamtOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACAMT_ON" )
    private String zpacamtOn;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPICAMT" )
    private String zpicamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZPACAMT" )
    private String zpacamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZINVAMT" )
    private String zinvamt;
    /**  */
    @MapsRfcMappper( targetName="ES_TOTAL", ipttSe="E", fieldKey="ZSHPAMT" )
    private String zshpamt;
    
    /** -----[ES_TOTAL] END----- */
    
    /** -----[T_RESULT] START----- */
    
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO" )
    private String zordno;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDLN" )
    private String zordln;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDLS" )
    private String zordls;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_E" )
    private String zordnoE;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDNO_P" )
    private String zordnoP;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDTYP" )
    private String zordtyp;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMATNR_INPUT" )
    private String zmatnrInput;
    /** Material Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /** Material Number */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMATNR_SHIP" )
    private String zmatnrShip;
    /** Material description */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="MAKTX" )
    private String maktx;
    /** SD document currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /** SD document currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK_USD" )
    private String waerkUsd;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NETPR" )
    private String netpr;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZNETPRU" )
    private String znetpru;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZTOT_DC" )
    private BigDecimal ztotDc;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZOHPCD" )
    private String zohpcd;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZODFCD" )
    private String zodfcd;
    /** Plant */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WERKS" )
    private String werks;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZAMDCL" )
    private String zamdcl;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZTRFQTY" )
    private String ztrfqty;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZLOADQTY" )
    private String zloadqty;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZORDDT" )
    private Date zorddt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCFMDT" )
    private Date zcfmdt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZBODT" )
    private Date zbodt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZALODT" )
    private Date zalodt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZONPICDT" )
    private Date zonpicdt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPICKDT" )
    private Date zpickdt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZONPACDT" )
    private Date zonpacdt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPACKDT" )
    private Date zpackdt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZTRFDT" )
    private Date ztrfdt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZLOADDT" )
    private Date zloaddt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZINVDT" )
    private Date zinvdt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSHIPDT" )
    private Date zshipdt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCANCDT" )
    private Date zcancdt;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETD_IV" )
    private Date zetdIv;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETA_IV" )
    private Date zetaIv;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETD_QT_IV" )
    private String zetdQtIv;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETD_BO" )
    private Date zetdBo;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETA_BO" )
    private Date zetaBo;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZETD_QT_BO" )
    private String zetdQtBo;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="SUPP_PROB" )
    private String suppProb;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="SUPP_PROB_NM" )
    private String suppProbNm;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZMEMO" )
    private String zmemo;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZCDKFG" )
    private String zcdkfg;
    
    /** -----[T_RESULT] END----- */
    
    /**
     * @return the iBoOpt
     */
    public String getiBoOpt() {
        return iBoOpt;
    }
    /**
     * @param iBoOpt the iBoOpt to set
     */
    public void setiBoOpt(String iBoOpt) {
        this.iBoOpt = iBoOpt;
    }
    /**
     * @return the iEtdOpt
     */
    public String getiEtdOpt() {
        return iEtdOpt;
    }
    /**
     * @param iEtdOpt the iEtdOpt to set
     */
    public void setiEtdOpt(String iEtdOpt) {
        this.iEtdOpt = iEtdOpt;
    }
    /**
     * @return the iOptDate
     */
    public String getiOptDate() {
        return iOptDate;
    }
    /**
     * @param iOptDate the iOptDate to set
     */
    public void setiOptDate(String iOptDate) {
        this.iOptDate = iOptDate;
    }
    /**
     * @return the iPartno
     */
    public String getiPartno() {
        return iPartno;
    }
    /**
     * @param iPartno the iPartno to set
     */
    public void setiPartno(String iPartno) {
        this.iPartno = iPartno;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZohpcd
     */
    public String getiZohpcd() {
        return iZohpcd;
    }
    /**
     * @param iZohpcd the iZohpcd to set
     */
    public void setiZohpcd(String iZohpcd) {
        this.iZohpcd = iZohpcd;
    }
    /**
     * @return the iZorddtFr
     */
    public Date getiZorddtFr() {
        return iZorddtFr;
    }
    /**
     * @param iZorddtFr the iZorddtFr to set
     */
    public void setiZorddtFr(Date iZorddtFr) {
        this.iZorddtFr = iZorddtFr;
    }
    /**
     * @return the iZorddtTo
     */
    public Date getiZorddtTo() {
        return iZorddtTo;
    }
    /**
     * @param iZorddtTo the iZorddtTo to set
     */
    public void setiZorddtTo(Date iZorddtTo) {
        this.iZorddtTo = iZorddtTo;
    }
    /**
     * @return the iZordnoE
     */
    public String getiZordnoE() {
        return iZordnoE;
    }
    /**
     * @param iZordnoE the iZordnoE to set
     */
    public void setiZordnoE(String iZordnoE) {
        this.iZordnoE = iZordnoE;
    }
    /**
     * @return the iZordnoP
     */
    public String getiZordnoP() {
        return iZordnoP;
    }
    /**
     * @param iZordnoP the iZordnoP to set
     */
    public void setiZordnoP(String iZordnoP) {
        this.iZordnoP = iZordnoP;
    }
    /**
     * @return the iZordtyp
     */
    public String getiZordtyp() {
        return iZordtyp;
    }
    /**
     * @param iZordtyp the iZordtyp to set
     */
    public void setiZordtyp(String iZordtyp) {
        this.iZordtyp = iZordtyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    /**
     * @return the zordcnt
     */
    public BigDecimal getZordcnt() {
        return zordcnt;
    }
    /**
     * @param zordcnt the zordcnt to set
     */
    public void setZordcnt(BigDecimal zordcnt) {
        this.zordcnt = zordcnt;
    }
    /**
     * @return the zcfmcnt
     */
    public BigDecimal getZcfmcnt() {
        return zcfmcnt;
    }
    /**
     * @param zcfmcnt the zcfmcnt to set
     */
    public void setZcfmcnt(BigDecimal zcfmcnt) {
        this.zcfmcnt = zcfmcnt;
    }
    /**
     * @return the zcanccnt
     */
    public BigDecimal getZcanccnt() {
        return zcanccnt;
    }
    /**
     * @param zcanccnt the zcanccnt to set
     */
    public void setZcanccnt(BigDecimal zcanccnt) {
        this.zcanccnt = zcanccnt;
    }
    /**
     * @return the zbocnt
     */
    public BigDecimal getZbocnt() {
        return zbocnt;
    }
    /**
     * @param zbocnt the zbocnt to set
     */
    public void setZbocnt(BigDecimal zbocnt) {
        this.zbocnt = zbocnt;
    }
    /**
     * @return the zalocnt
     */
    public BigDecimal getZalocnt() {
        return zalocnt;
    }
    /**
     * @param zalocnt the zalocnt to set
     */
    public void setZalocnt(BigDecimal zalocnt) {
        this.zalocnt = zalocnt;
    }
    /**
     * @return the zpiccntOn
     */
    public BigDecimal getZpiccntOn() {
        return zpiccntOn;
    }
    /**
     * @param zpiccntOn the zpiccntOn to set
     */
    public void setZpiccntOn(BigDecimal zpiccntOn) {
        this.zpiccntOn = zpiccntOn;
    }
    /**
     * @return the zpaccntOn
     */
    public BigDecimal getZpaccntOn() {
        return zpaccntOn;
    }
    /**
     * @param zpaccntOn the zpaccntOn to set
     */
    public void setZpaccntOn(BigDecimal zpaccntOn) {
        this.zpaccntOn = zpaccntOn;
    }
    /**
     * @return the zpiccnt
     */
    public BigDecimal getZpiccnt() {
        return zpiccnt;
    }
    /**
     * @param zpiccnt the zpiccnt to set
     */
    public void setZpiccnt(BigDecimal zpiccnt) {
        this.zpiccnt = zpiccnt;
    }
    /**
     * @return the zpaccnt
     */
    public BigDecimal getZpaccnt() {
        return zpaccnt;
    }
    /**
     * @param zpaccnt the zpaccnt to set
     */
    public void setZpaccnt(BigDecimal zpaccnt) {
        this.zpaccnt = zpaccnt;
    }
    /**
     * @return the zinvcnt
     */
    public BigDecimal getZinvcnt() {
        return zinvcnt;
    }
    /**
     * @param zinvcnt the zinvcnt to set
     */
    public void setZinvcnt(BigDecimal zinvcnt) {
        this.zinvcnt = zinvcnt;
    }
    /**
     * @return the zshpcnt
     */
    public BigDecimal getZshpcnt() {
        return zshpcnt;
    }
    /**
     * @param zshpcnt the zshpcnt to set
     */
    public void setZshpcnt(BigDecimal zshpcnt) {
        this.zshpcnt = zshpcnt;
    }
    /**
     * @return the zordqty
     */
    public String getZordqty() {
        return zordqty;
    }
    /**
     * @param zordqty the zordqty to set
     */
    public void setZordqty(String zordqty) {
        this.zordqty = zordqty;
    }
    /**
     * @return the zcfmqty
     */
    public String getZcfmqty() {
        return zcfmqty;
    }
    /**
     * @param zcfmqty the zcfmqty to set
     */
    public void setZcfmqty(String zcfmqty) {
        this.zcfmqty = zcfmqty;
    }
    /**
     * @return the zcancqty
     */
    public String getZcancqty() {
        return zcancqty;
    }
    /**
     * @param zcancqty the zcancqty to set
     */
    public void setZcancqty(String zcancqty) {
        this.zcancqty = zcancqty;
    }
    /**
     * @return the zboqty
     */
    public String getZboqty() {
        return zboqty;
    }
    /**
     * @param zboqty the zboqty to set
     */
    public void setZboqty(String zboqty) {
        this.zboqty = zboqty;
    }
    /**
     * @return the zaloqty
     */
    public String getZaloqty() {
        return zaloqty;
    }
    /**
     * @param zaloqty the zaloqty to set
     */
    public void setZaloqty(String zaloqty) {
        this.zaloqty = zaloqty;
    }
    /**
     * @return the zpicqtyOn
     */
    public String getZpicqtyOn() {
        return zpicqtyOn;
    }
    /**
     * @param zpicqtyOn the zpicqtyOn to set
     */
    public void setZpicqtyOn(String zpicqtyOn) {
        this.zpicqtyOn = zpicqtyOn;
    }
    /**
     * @return the zpacqtyOn
     */
    public String getZpacqtyOn() {
        return zpacqtyOn;
    }
    /**
     * @param zpacqtyOn the zpacqtyOn to set
     */
    public void setZpacqtyOn(String zpacqtyOn) {
        this.zpacqtyOn = zpacqtyOn;
    }
    /**
     * @return the zpicqty
     */
    public String getZpicqty() {
        return zpicqty;
    }
    /**
     * @param zpicqty the zpicqty to set
     */
    public void setZpicqty(String zpicqty) {
        this.zpicqty = zpicqty;
    }
    /**
     * @return the zpacqty
     */
    public String getZpacqty() {
        return zpacqty;
    }
    /**
     * @param zpacqty the zpacqty to set
     */
    public void setZpacqty(String zpacqty) {
        this.zpacqty = zpacqty;
    }
    /**
     * @return the zinvqty
     */
    public String getZinvqty() {
        return zinvqty;
    }
    /**
     * @param zinvqty the zinvqty to set
     */
    public void setZinvqty(String zinvqty) {
        this.zinvqty = zinvqty;
    }
    /**
     * @return the zshpqty
     */
    public String getZshpqty() {
        return zshpqty;
    }
    /**
     * @param zshpqty the zshpqty to set
     */
    public void setZshpqty(String zshpqty) {
        this.zshpqty = zshpqty;
    }
    /**
     * @return the zordamt
     */
    public String getZordamt() {
        return zordamt;
    }
    /**
     * @param zordamt the zordamt to set
     */
    public void setZordamt(String zordamt) {
        this.zordamt = zordamt;
    }
    /**
     * @return the zcfmamt
     */
    public String getZcfmamt() {
        return zcfmamt;
    }
    /**
     * @param zcfmamt the zcfmamt to set
     */
    public void setZcfmamt(String zcfmamt) {
        this.zcfmamt = zcfmamt;
    }
    /**
     * @return the zcancamt
     */
    public String getZcancamt() {
        return zcancamt;
    }
    /**
     * @param zcancamt the zcancamt to set
     */
    public void setZcancamt(String zcancamt) {
        this.zcancamt = zcancamt;
    }
    /**
     * @return the zboamt
     */
    public String getZboamt() {
        return zboamt;
    }
    /**
     * @param zboamt the zboamt to set
     */
    public void setZboamt(String zboamt) {
        this.zboamt = zboamt;
    }
    /**
     * @return the zaloamt
     */
    public String getZaloamt() {
        return zaloamt;
    }
    /**
     * @param zaloamt the zaloamt to set
     */
    public void setZaloamt(String zaloamt) {
        this.zaloamt = zaloamt;
    }
    /**
     * @return the zpicamtOn
     */
    public String getZpicamtOn() {
        return zpicamtOn;
    }
    /**
     * @param zpicamtOn the zpicamtOn to set
     */
    public void setZpicamtOn(String zpicamtOn) {
        this.zpicamtOn = zpicamtOn;
    }
    /**
     * @return the zpacamtOn
     */
    public String getZpacamtOn() {
        return zpacamtOn;
    }
    /**
     * @param zpacamtOn the zpacamtOn to set
     */
    public void setZpacamtOn(String zpacamtOn) {
        this.zpacamtOn = zpacamtOn;
    }
    /**
     * @return the zpicamt
     */
    public String getZpicamt() {
        return zpicamt;
    }
    /**
     * @param zpicamt the zpicamt to set
     */
    public void setZpicamt(String zpicamt) {
        this.zpicamt = zpicamt;
    }
    /**
     * @return the zpacamt
     */
    public String getZpacamt() {
        return zpacamt;
    }
    /**
     * @param zpacamt the zpacamt to set
     */
    public void setZpacamt(String zpacamt) {
        this.zpacamt = zpacamt;
    }
    /**
     * @return the zinvamt
     */
    public String getZinvamt() {
        return zinvamt;
    }
    /**
     * @param zinvamt the zinvamt to set
     */
    public void setZinvamt(String zinvamt) {
        this.zinvamt = zinvamt;
    }
    /**
     * @return the zshpamt
     */
    public String getZshpamt() {
        return zshpamt;
    }
    /**
     * @param zshpamt the zshpamt to set
     */
    public void setZshpamt(String zshpamt) {
        this.zshpamt = zshpamt;
    }
    /**
     * @return the zordno
     */
    public String getZordno() {
        return zordno;
    }
    /**
     * @param zordno the zordno to set
     */
    public void setZordno(String zordno) {
        this.zordno = zordno;
    }
    /**
     * @return the zordln
     */
    public String getZordln() {
        return zordln;
    }
    /**
     * @param zordln the zordln to set
     */
    public void setZordln(String zordln) {
        this.zordln = zordln;
    }
    /**
     * @return the zordls
     */
    public String getZordls() {
        return zordls;
    }
    /**
     * @param zordls the zordls to set
     */
    public void setZordls(String zordls) {
        this.zordls = zordls;
    }
    /**
     * @return the zordnoE
     */
    public String getZordnoE() {
        return zordnoE;
    }
    /**
     * @param zordnoE the zordnoE to set
     */
    public void setZordnoE(String zordnoE) {
        this.zordnoE = zordnoE;
    }
    /**
     * @return the zordnoP
     */
    public String getZordnoP() {
        return zordnoP;
    }
    /**
     * @param zordnoP the zordnoP to set
     */
    public void setZordnoP(String zordnoP) {
        this.zordnoP = zordnoP;
    }
    /**
     * @return the zordtyp
     */
    public String getZordtyp() {
        return zordtyp;
    }
    /**
     * @param zordtyp the zordtyp to set
     */
    public void setZordtyp(String zordtyp) {
        this.zordtyp = zordtyp;
    }
    /**
     * @return the zmatnrInput
     */
    public String getZmatnrInput() {
        return zmatnrInput;
    }
    /**
     * @param zmatnrInput the zmatnrInput to set
     */
    public void setZmatnrInput(String zmatnrInput) {
        this.zmatnrInput = zmatnrInput;
    }
    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }
    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }
    /**
     * @return the zmatnrShip
     */
    public String getZmatnrShip() {
        return zmatnrShip;
    }
    /**
     * @param zmatnrShip the zmatnrShip to set
     */
    public void setZmatnrShip(String zmatnrShip) {
        this.zmatnrShip = zmatnrShip;
    }
    /**
     * @return the maktx
     */
    public String getMaktx() {
        return maktx;
    }
    /**
     * @param maktx the maktx to set
     */
    public void setMaktx(String maktx) {
        this.maktx = maktx;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the waerkUsd
     */
    public String getWaerkUsd() {
        return waerkUsd;
    }
    /**
     * @param waerkUsd the waerkUsd to set
     */
    public void setWaerkUsd(String waerkUsd) {
        this.waerkUsd = waerkUsd;
    }
    /**
     * @return the netpr
     */
    public String getNetpr() {
        return netpr;
    }
    /**
     * @param netpr the netpr to set
     */
    public void setNetpr(String netpr) {
        this.netpr = netpr;
    }
    /**
     * @return the znetpru
     */
    public String getZnetpru() {
        return znetpru;
    }
    /**
     * @param znetpru the znetpru to set
     */
    public void setZnetpru(String znetpru) {
        this.znetpru = znetpru;
    }
    /**
     * @return the ztotDc
     */
    public BigDecimal getZtotDc() {
        return ztotDc;
    }
    /**
     * @param ztotDc the ztotDc to set
     */
    public void setZtotDc(BigDecimal ztotDc) {
        this.ztotDc = ztotDc;
    }
    /**
     * @return the zohpcd
     */
    public String getZohpcd() {
        return zohpcd;
    }
    /**
     * @param zohpcd the zohpcd to set
     */
    public void setZohpcd(String zohpcd) {
        this.zohpcd = zohpcd;
    }
    /**
     * @return the zodfcd
     */
    public String getZodfcd() {
        return zodfcd;
    }
    /**
     * @param zodfcd the zodfcd to set
     */
    public void setZodfcd(String zodfcd) {
        this.zodfcd = zodfcd;
    }
    /**
     * @return the werks
     */
    public String getWerks() {
        return werks;
    }
    /**
     * @param werks the werks to set
     */
    public void setWerks(String werks) {
        this.werks = werks;
    }
    /**
     * @return the zamdcl
     */
    public String getZamdcl() {
        return zamdcl;
    }
    /**
     * @param zamdcl the zamdcl to set
     */
    public void setZamdcl(String zamdcl) {
        this.zamdcl = zamdcl;
    }
    /**
     * @return the ztrfqty
     */
    public String getZtrfqty() {
        return ztrfqty;
    }
    /**
     * @param ztrfqty the ztrfqty to set
     */
    public void setZtrfqty(String ztrfqty) {
        this.ztrfqty = ztrfqty;
    }
    /**
     * @return the zloadqty
     */
    public String getZloadqty() {
        return zloadqty;
    }
    /**
     * @param zloadqty the zloadqty to set
     */
    public void setZloadqty(String zloadqty) {
        this.zloadqty = zloadqty;
    }
    /**
     * @return the zorddt
     */
    public Date getZorddt() {
        return zorddt;
    }
    /**
     * @param zorddt the zorddt to set
     */
    public void setZorddt(Date zorddt) {
        this.zorddt = zorddt;
    }
    /**
     * @return the zcfmdt
     */
    public Date getZcfmdt() {
        return zcfmdt;
    }
    /**
     * @param zcfmdt the zcfmdt to set
     */
    public void setZcfmdt(Date zcfmdt) {
        this.zcfmdt = zcfmdt;
    }
    /**
     * @return the zbodt
     */
    public Date getZbodt() {
        return zbodt;
    }
    /**
     * @param zbodt the zbodt to set
     */
    public void setZbodt(Date zbodt) {
        this.zbodt = zbodt;
    }
    /**
     * @return the zalodt
     */
    public Date getZalodt() {
        return zalodt;
    }
    /**
     * @param zalodt the zalodt to set
     */
    public void setZalodt(Date zalodt) {
        this.zalodt = zalodt;
    }
    /**
     * @return the zonpicdt
     */
    public Date getZonpicdt() {
        return zonpicdt;
    }
    /**
     * @param zonpicdt the zonpicdt to set
     */
    public void setZonpicdt(Date zonpicdt) {
        this.zonpicdt = zonpicdt;
    }
    /**
     * @return the zpickdt
     */
    public Date getZpickdt() {
        return zpickdt;
    }
    /**
     * @param zpickdt the zpickdt to set
     */
    public void setZpickdt(Date zpickdt) {
        this.zpickdt = zpickdt;
    }
    /**
     * @return the zonpacdt
     */
    public Date getZonpacdt() {
        return zonpacdt;
    }
    /**
     * @param zonpacdt the zonpacdt to set
     */
    public void setZonpacdt(Date zonpacdt) {
        this.zonpacdt = zonpacdt;
    }
    /**
     * @return the zpackdt
     */
    public Date getZpackdt() {
        return zpackdt;
    }
    /**
     * @param zpackdt the zpackdt to set
     */
    public void setZpackdt(Date zpackdt) {
        this.zpackdt = zpackdt;
    }
    /**
     * @return the ztrfdt
     */
    public Date getZtrfdt() {
        return ztrfdt;
    }
    /**
     * @param ztrfdt the ztrfdt to set
     */
    public void setZtrfdt(Date ztrfdt) {
        this.ztrfdt = ztrfdt;
    }
    /**
     * @return the zloaddt
     */
    public Date getZloaddt() {
        return zloaddt;
    }
    /**
     * @param zloaddt the zloaddt to set
     */
    public void setZloaddt(Date zloaddt) {
        this.zloaddt = zloaddt;
    }
    /**
     * @return the zinvdt
     */
    public Date getZinvdt() {
        return zinvdt;
    }
    /**
     * @param zinvdt the zinvdt to set
     */
    public void setZinvdt(Date zinvdt) {
        this.zinvdt = zinvdt;
    }
    /**
     * @return the zshipdt
     */
    public Date getZshipdt() {
        return zshipdt;
    }
    /**
     * @param zshipdt the zshipdt to set
     */
    public void setZshipdt(Date zshipdt) {
        this.zshipdt = zshipdt;
    }
    /**
     * @return the zcancdt
     */
    public Date getZcancdt() {
        return zcancdt;
    }
    /**
     * @param zcancdt the zcancdt to set
     */
    public void setZcancdt(Date zcancdt) {
        this.zcancdt = zcancdt;
    }
    /**
     * @return the zetdIv
     */
    public Date getZetdIv() {
        return zetdIv;
    }
    /**
     * @param zetdIv the zetdIv to set
     */
    public void setZetdIv(Date zetdIv) {
        this.zetdIv = zetdIv;
    }
    /**
     * @return the zetaIv
     */
    public Date getZetaIv() {
        return zetaIv;
    }
    /**
     * @param zetaIv the zetaIv to set
     */
    public void setZetaIv(Date zetaIv) {
        this.zetaIv = zetaIv;
    }
    /**
     * @return the zetdQtIv
     */
    public String getZetdQtIv() {
        return zetdQtIv;
    }
    /**
     * @param zetdQtIv the zetdQtIv to set
     */
    public void setZetdQtIv(String zetdQtIv) {
        this.zetdQtIv = zetdQtIv;
    }
    /**
     * @return the zetdBo
     */
    public Date getZetdBo() {
        return zetdBo;
    }
    /**
     * @param zetdBo the zetdBo to set
     */
    public void setZetdBo(Date zetdBo) {
        this.zetdBo = zetdBo;
    }
    /**
     * @return the zetaBo
     */
    public Date getZetaBo() {
        return zetaBo;
    }
    /**
     * @param zetaBo the zetaBo to set
     */
    public void setZetaBo(Date zetaBo) {
        this.zetaBo = zetaBo;
    }
    /**
     * @return the zetdQtBo
     */
    public String getZetdQtBo() {
        return zetdQtBo;
    }
    /**
     * @param zetdQtBo the zetdQtBo to set
     */
    public void setZetdQtBo(String zetdQtBo) {
        this.zetdQtBo = zetdQtBo;
    }
    /**
     * @return the suppProb
     */
    public String getSuppProb() {
        return suppProb;
    }
    /**
     * @param suppProb the suppProb to set
     */
    public void setSuppProb(String suppProb) {
        this.suppProb = suppProb;
    }
    /**
     * @return the suppProbNm
     */
    public String getSuppProbNm() {
        return suppProbNm;
    }
    /**
     * @param suppProbNm the suppProbNm to set
     */
    public void setSuppProbNm(String suppProbNm) {
        this.suppProbNm = suppProbNm;
    }
    /**
     * @return the zmemo
     */
    public String getZmemo() {
        return zmemo;
    }
    /**
     * @param zmemo the zmemo to set
     */
    public void setZmemo(String zmemo) {
        this.zmemo = zmemo;
    }
    /**
     * @return the zcdkfg
     */
    public String getZcdkfg() {
        return zcdkfg;
    }
    /**
     * @param zcdkfg the zcdkfg to set
     */
    public void setZcdkfg(String zcdkfg) {
        this.zcdkfg = zcdkfg;
    }
    /**
     * @return the iZohpcdEq
     */
    public String getiZohpcdEq() {
        return iZohpcdEq;
    }
    /**
     * @param iZohpcdEq the iZohpcdEq to set
     */
    public void setiZohpcdEq(String iZohpcdEq) {
        this.iZohpcdEq = iZohpcdEq;
    }
    
}
