package com.mobis.maps.nmgn.sd.service;

import java.util.List;

import com.mobis.maps.cmmn.vo.LoginInfoVO;
import com.mobis.maps.nmgn.sd.vo.DispRequestVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : DispRequestService.java
 * @Description : Search Request List
 * @author 이수지
 * @since 2020. 8. 26.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 8. 26.     이수지              	최초 생성
 * </pre>
 */

public interface DispRequestService {
    
    /**
     * Search Request List
     *
     * @param loginVo
     * @param params
     * @return
     * @throws Exception
     */
    List<DispRequestVO> selectSearchRequest (LoginInfoVO loginVo, DispRequestVO params) throws Exception;
}
