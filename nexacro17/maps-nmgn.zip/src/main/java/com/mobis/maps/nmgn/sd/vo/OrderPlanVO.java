package com.mobis.maps.nmgn.sd.vo;

import java.math.BigDecimal;
import java.util.List;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : OrderPlanVO.java
 * @Description : ZPSD_NMGN_R_ORDER_PLAN
 * @author 홍민호
 * @since 2020. 2. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 2. 5.     홍민호         최초 생성
 * </pre>
 */

public class OrderPlanVO extends MapsCommSapRfcIfCommVO {

    private int rowLevel; // Nexacro row level
    private long seq = 0; // 실제 표시할 순번

    
    private List<OrderPlanVO> list = null;
    
    /** 회계연도 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_GJAHR" )
    private String iGjahr;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_KVGR1" )
    private String iKvgr1;
    /** C:Create, U:Change, R:Display,D:Delete */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 영업소 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKBUR" )
    private String iVkbur;
    /** 영업 조직 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VKORG" )
    private String iVkorg;
    /** 정보구조의 버전번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VRSIO" )
    private String iVrsio;
    /** 유통 경로 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_VTWEG" )
    private String iVtweg;
    /** SD 문서 통화 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_WAERS" )
    private String iWaers;
    /** Product 타입코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPROD_TYP" )
    private String iZprodTyp;
    /** SMART/AMOS 고객코드 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /** 버전 상태 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZVERSTA" )
    private String iZversta;
    
    
//    -----[T_LIST] START-----
    /** 보험유형 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="VSART|VSART" )
    private String vsart;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT01|ZBPAMT01" )
    private String zbpamt01;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT02|ZBPAMT02" )
    private String zbpamt02;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT03|ZBPAMT03" )
    private String zbpamt03;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT04|ZBPAMT04" )
    private String zbpamt04;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT05|ZBPAMT05" )
    private String zbpamt05;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT06|ZBPAMT06" )
    private String zbpamt06;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT07|ZBPAMT07" )
    private String zbpamt07;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT08|ZBPAMT08" )
    private String zbpamt08;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT09|ZBPAMT09" )
    private String zbpamt09;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT10|ZBPAMT10" )
    private String zbpamt10;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT11|ZBPAMT11" )
    private String zbpamt11;
    /** 오더 금액 */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZBPAMT12|ZBPAMT12" )
    private String zbpamt12;
    /** Sequence */
    @MapsRfcMappper( targetName="T_LIST", ipttSe="I|E", fieldKey="ZPSEQ|ZPSEQ" )
    private String zpseq;
//    -----[T_LIST] END-----
    

    private BigDecimal amt01;
    private BigDecimal amt02;
    private BigDecimal amt03;
    private BigDecimal amt04;
    private BigDecimal amt05;
    private BigDecimal amt06;
    private BigDecimal amt07;
    private BigDecimal amt08;
    private BigDecimal amt09;
    private BigDecimal amt10;
    private BigDecimal amt11;
    private BigDecimal amt12;
    
    
    
    /**
     * @return the iGjahr
     */
    public String getiGjahr() {
        return iGjahr;
    }
    /**
     * @param iGjahr the iGjahr to set
     */
    public void setiGjahr(String iGjahr) {
        this.iGjahr = iGjahr;
    }
    /**
     * @return the iKvgr1
     */
    public String getiKvgr1() {
        return iKvgr1;
    }
    /**
     * @param iKvgr1 the iKvgr1 to set
     */
    public void setiKvgr1(String iKvgr1) {
        this.iKvgr1 = iKvgr1;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iVkbur
     */
    public String getiVkbur() {
        return iVkbur;
    }
    /**
     * @param iVkbur the iVkbur to set
     */
    public void setiVkbur(String iVkbur) {
        this.iVkbur = iVkbur;
    }
    /**
     * @return the iVkorg
     */
    public String getiVkorg() {
        return iVkorg;
    }
    /**
     * @param iVkorg the iVkorg to set
     */
    public void setiVkorg(String iVkorg) {
        this.iVkorg = iVkorg;
    }
    /**
     * @return the iVrsio
     */
    public String getiVrsio() {
        return iVrsio;
    }
    /**
     * @param iVrsio the iVrsio to set
     */
    public void setiVrsio(String iVrsio) {
        this.iVrsio = iVrsio;
    }
    /**
     * @return the iVtweg
     */
    public String getiVtweg() {
        return iVtweg;
    }
    /**
     * @param iVtweg the iVtweg to set
     */
    public void setiVtweg(String iVtweg) {
        this.iVtweg = iVtweg;
    }
    /**
     * @return the iWaers
     */
    public String getiWaers() {
        return iWaers;
    }
    /**
     * @param iWaers the iWaers to set
     */
    public void setiWaers(String iWaers) {
        this.iWaers = iWaers;
    }
    /**
     * @return the iZprodTyp
     */
    public String getiZprodTyp() {
        return iZprodTyp;
    }
    /**
     * @param iZprodTyp the iZprodTyp to set
     */
    public void setiZprodTyp(String iZprodTyp) {
        this.iZprodTyp = iZprodTyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the iZversta
     */
    public String getiZversta() {
        return iZversta;
    }
    /**
     * @param iZversta the iZversta to set
     */
    public void setiZversta(String iZversta) {
        this.iZversta = iZversta;
    }
    /**
     * @return the vsart
     */
    public String getVsart() {
        return vsart;
    }
    /**
     * @param vsart the vsart to set
     */
    public void setVsart(String vsart) {
        this.vsart = vsart;
    }
    /**
     * @return the zbpamt01
     */
    public String getZbpamt01() {
        return zbpamt01;
    }
    /**
     * @param zbpamt01 the zbpamt01 to set
     */
    public void setZbpamt01(String zbpamt01) {
        this.zbpamt01 = zbpamt01;
    }
    /**
     * @return the zbpamt02
     */
    public String getZbpamt02() {
        return zbpamt02;
    }
    /**
     * @param zbpamt02 the zbpamt02 to set
     */
    public void setZbpamt02(String zbpamt02) {
        this.zbpamt02 = zbpamt02;
    }
    /**
     * @return the zbpamt03
     */
    public String getZbpamt03() {
        return zbpamt03;
    }
    /**
     * @param zbpamt03 the zbpamt03 to set
     */
    public void setZbpamt03(String zbpamt03) {
        this.zbpamt03 = zbpamt03;
    }
    /**
     * @return the zbpamt04
     */
    public String getZbpamt04() {
        return zbpamt04;
    }
    /**
     * @param zbpamt04 the zbpamt04 to set
     */
    public void setZbpamt04(String zbpamt04) {
        this.zbpamt04 = zbpamt04;
    }
    /**
     * @return the zbpamt05
     */
    public String getZbpamt05() {
        return zbpamt05;
    }
    /**
     * @param zbpamt05 the zbpamt05 to set
     */
    public void setZbpamt05(String zbpamt05) {
        this.zbpamt05 = zbpamt05;
    }
    /**
     * @return the zbpamt06
     */
    public String getZbpamt06() {
        return zbpamt06;
    }
    /**
     * @param zbpamt06 the zbpamt06 to set
     */
    public void setZbpamt06(String zbpamt06) {
        this.zbpamt06 = zbpamt06;
    }
    /**
     * @return the zbpamt07
     */
    public String getZbpamt07() {
        return zbpamt07;
    }
    /**
     * @param zbpamt07 the zbpamt07 to set
     */
    public void setZbpamt07(String zbpamt07) {
        this.zbpamt07 = zbpamt07;
    }
    /**
     * @return the zbpamt08
     */
    public String getZbpamt08() {
        return zbpamt08;
    }
    /**
     * @param zbpamt08 the zbpamt08 to set
     */
    public void setZbpamt08(String zbpamt08) {
        this.zbpamt08 = zbpamt08;
    }
    /**
     * @return the zbpamt09
     */
    public String getZbpamt09() {
        return zbpamt09;
    }
    /**
     * @param zbpamt09 the zbpamt09 to set
     */
    public void setZbpamt09(String zbpamt09) {
        this.zbpamt09 = zbpamt09;
    }
    /**
     * @return the zbpamt10
     */
    public String getZbpamt10() {
        return zbpamt10;
    }
    /**
     * @param zbpamt10 the zbpamt10 to set
     */
    public void setZbpamt10(String zbpamt10) {
        this.zbpamt10 = zbpamt10;
    }
    /**
     * @return the zbpamt11
     */
    public String getZbpamt11() {
        return zbpamt11;
    }
    /**
     * @param zbpamt11 the zbpamt11 to set
     */
    public void setZbpamt11(String zbpamt11) {
        this.zbpamt11 = zbpamt11;
    }
    /**
     * @return the zbpamt12
     */
    public String getZbpamt12() {
        return zbpamt12;
    }
    /**
     * @param zbpamt12 the zbpamt12 to set
     */
    public void setZbpamt12(String zbpamt12) {
        this.zbpamt12 = zbpamt12;
    }
    /**
     * @return the zpseq
     */
    public String getZpseq() {
        return zpseq;
    }
    /**
     * @param zpseq the zpseq to set
     */
    public void setZpseq(String zpseq) {
        this.zpseq = zpseq;
    }
    /**
     * @return the rowLevel
     */
    public int getRowLevel() {
        return rowLevel;
    }
    /**
     * @param rowLevel the rowLevel to set
     */
    public void setRowLevel(int rowLevel) {
        this.rowLevel = rowLevel;
    }
    /**
     * @return the list
     */
    public List<OrderPlanVO> getList() {
        return list;
    }
    /**
     * @param list the list to set
     */
    public void setList(List<OrderPlanVO> list) {
        this.list = list;
    }
    /**
     * @return the seq
     */
    public long getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(long seq) {
        this.seq = seq;
    }
    /**
     * @return the amt01
     */
    public BigDecimal getAmt01() {
        return amt01;
    }
    /**
     * @param amt01 the amt01 to set
     */
    public void setAmt01(BigDecimal amt01) {
        this.amt01 = amt01;
    }
    /**
     * @return the amt02
     */
    public BigDecimal getAmt02() {
        return amt02;
    }
    /**
     * @param amt02 the amt02 to set
     */
    public void setAmt02(BigDecimal amt02) {
        this.amt02 = amt02;
    }
    /**
     * @return the amt03
     */
    public BigDecimal getAmt03() {
        return amt03;
    }
    /**
     * @param amt03 the amt03 to set
     */
    public void setAmt03(BigDecimal amt03) {
        this.amt03 = amt03;
    }
    /**
     * @return the amt04
     */
    public BigDecimal getAmt04() {
        return amt04;
    }
    /**
     * @param amt04 the amt04 to set
     */
    public void setAmt04(BigDecimal amt04) {
        this.amt04 = amt04;
    }
    /**
     * @return the amt05
     */
    public BigDecimal getAmt05() {
        return amt05;
    }
    /**
     * @param amt05 the amt05 to set
     */
    public void setAmt05(BigDecimal amt05) {
        this.amt05 = amt05;
    }
    /**
     * @return the amt06
     */
    public BigDecimal getAmt06() {
        return amt06;
    }
    /**
     * @param amt06 the amt06 to set
     */
    public void setAmt06(BigDecimal amt06) {
        this.amt06 = amt06;
    }
    /**
     * @return the amt07
     */
    public BigDecimal getAmt07() {
        return amt07;
    }
    /**
     * @param amt07 the amt07 to set
     */
    public void setAmt07(BigDecimal amt07) {
        this.amt07 = amt07;
    }
    /**
     * @return the amt08
     */
    public BigDecimal getAmt08() {
        return amt08;
    }
    /**
     * @param amt08 the amt08 to set
     */
    public void setAmt08(BigDecimal amt08) {
        this.amt08 = amt08;
    }
    /**
     * @return the amt09
     */
    public BigDecimal getAmt09() {
        return amt09;
    }
    /**
     * @param amt09 the amt09 to set
     */
    public void setAmt09(BigDecimal amt09) {
        this.amt09 = amt09;
    }
    /**
     * @return the amt10
     */
    public BigDecimal getAmt10() {
        return amt10;
    }
    /**
     * @param amt10 the amt10 to set
     */
    public void setAmt10(BigDecimal amt10) {
        this.amt10 = amt10;
    }
    /**
     * @return the amt11
     */
    public BigDecimal getAmt11() {
        return amt11;
    }
    /**
     * @param amt11 the amt11 to set
     */
    public void setAmt11(BigDecimal amt11) {
        this.amt11 = amt11;
    }
    /**
     * @return the amt12
     */
    public BigDecimal getAmt12() {
        return amt12;
    }
    /**
     * @param amt12 the amt12 to set
     */
    public void setAmt12(BigDecimal amt12) {
        this.amt12 = amt12;
    }
    
    
}
