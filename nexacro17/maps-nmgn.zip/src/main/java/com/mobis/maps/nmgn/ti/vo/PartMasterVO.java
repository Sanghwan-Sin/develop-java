package com.mobis.maps.nmgn.ti.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PartMasterVO.java
 * @Description : ZPTI_NMGN_S_PART_LIST_HQ 
 * @author 이수지
 * @since 2020. 5. 21.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 5. 21.     이수지             	최초 생성
 * </pre>
 */

public class PartMasterVO extends MapsCommSapRfcIfCommVO {
    /** Part No */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_MATNR" )
    private String iMatnr;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_SFLAG" )
    private String iSflag;
    /** Region */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZAREA" )
    private String iZarea;
    /** Dist Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDISTCD" )
    private String iZdistcd;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZFDATE" )
    private Date iZfdate;
    /** H/K */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZHKCD" )
    private String iZhkcd;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZMLTCD" )
    private String iZmltcd;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZTDATE" )
    private Date iZtdate;
    /** Model */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZVHC" )
    private String iZvhc;
    /** SUC */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSUCCD" )
    private String iZsuccd;
    
    /** -----[ET_DATA] START----- */
    
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSEQNO" )
    private Integer zseqno;
    /** Material Number */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="MATNR" )
    private String matnr;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPTNM" )
    private String zptnm;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZPNC" )
    private String zpnc;
    /** Color Part */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZCOL_FLG" )
    private String zcolFlg;
    /** HQ SUC */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSUCCD" )
    private String zsuccd;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZNEW_PNO" )
    private String znewPno;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZLIST_PRICE" )
    private String zlistPrice;
    /** Currency Key */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="WAERS" )
    private String waers;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZSTKQTY" )
    private String zstkqty;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZDUE_IN" )
    private String zdueIn;
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZINTER_CODE" )
    private String zinterCode;
    
    /** -----[ET_DATA] END----- */

    /** -----[ET_DATA] START----- */
    
    /**  */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZAREA" )
    private String zarea;
    /** Character field of length 40 */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="DESCR" )
    private String descr;
    /** Mobis Car Code (Model No) */
    @MapsRfcMappper( targetName="ET_DATA", ipttSe="E", fieldKey="ZVHC" )
    private String zvhc;
    
    /** -----[ET_DATA] END----- */

    /**
     * @return the iMatnr
     */
    public String getiMatnr() {
        return iMatnr;
    }

    /**
     * @param iMatnr the iMatnr to set
     */
    public void setiMatnr(String iMatnr) {
        this.iMatnr = iMatnr;
    }

    /**
     * @return the iSflag
     */
    public String getiSflag() {
        return iSflag;
    }

    /**
     * @param iSflag the iSflag to set
     */
    public void setiSflag(String iSflag) {
        this.iSflag = iSflag;
    }

    /**
     * @return the iZarea
     */
    public String getiZarea() {
        return iZarea;
    }

    /**
     * @param iZarea the iZarea to set
     */
    public void setiZarea(String iZarea) {
        this.iZarea = iZarea;
    }

    /**
     * @return the iZdistcd
     */
    public String getiZdistcd() {
        return iZdistcd;
    }

    /**
     * @param iZdistcd the iZdistcd to set
     */
    public void setiZdistcd(String iZdistcd) {
        this.iZdistcd = iZdistcd;
    }

    /**
     * @return the iZfdate
     */
    public Date getiZfdate() {
        return iZfdate;
    }

    /**
     * @param iZfdate the iZfdate to set
     */
    public void setiZfdate(Date iZfdate) {
        this.iZfdate = iZfdate;
    }

    /**
     * @return the iZhkcd
     */
    public String getiZhkcd() {
        return iZhkcd;
    }

    /**
     * @param iZhkcd the iZhkcd to set
     */
    public void setiZhkcd(String iZhkcd) {
        this.iZhkcd = iZhkcd;
    }

    /**
     * @return the iZmltcd
     */
    public String getiZmltcd() {
        return iZmltcd;
    }

    /**
     * @param iZmltcd the iZmltcd to set
     */
    public void setiZmltcd(String iZmltcd) {
        this.iZmltcd = iZmltcd;
    }

    /**
     * @return the iZtdate
     */
    public Date getiZtdate() {
        return iZtdate;
    }

    /**
     * @param iZtdate the iZtdate to set
     */
    public void setiZtdate(Date iZtdate) {
        this.iZtdate = iZtdate;
    }

    /**
     * @return the iZvhc
     */
    public String getiZvhc() {
        return iZvhc;
    }

    /**
     * @param iZvhc the iZvhc to set
     */
    public void setiZvhc(String iZvhc) {
        this.iZvhc = iZvhc;
    }

    /**
     * @return the zseqno
     */
    public Integer getZseqno() {
        return zseqno;
    }

    /**
     * @param zseqno the zseqno to set
     */
    public void setZseqno(Integer zseqno) {
        this.zseqno = zseqno;
    }

    /**
     * @return the matnr
     */
    public String getMatnr() {
        return matnr;
    }

    /**
     * @param matnr the matnr to set
     */
    public void setMatnr(String matnr) {
        this.matnr = matnr;
    }

    /**
     * @return the zptnm
     */
    public String getZptnm() {
        return zptnm;
    }

    /**
     * @param zptnm the zptnm to set
     */
    public void setZptnm(String zptnm) {
        this.zptnm = zptnm;
    }

    /**
     * @return the zpnc
     */
    public String getZpnc() {
        return zpnc;
    }

    /**
     * @param zpnc the zpnc to set
     */
    public void setZpnc(String zpnc) {
        this.zpnc = zpnc;
    }

    /**
     * @return the zcolFlg
     */
    public String getZcolFlg() {
        return zcolFlg;
    }

    /**
     * @param zcolFlg the zcolFlg to set
     */
    public void setZcolFlg(String zcolFlg) {
        this.zcolFlg = zcolFlg;
    }

    /**
     * @return the zsuccd
     */
    public String getZsuccd() {
        return zsuccd;
    }

    /**
     * @param zsuccd the zsuccd to set
     */
    public void setZsuccd(String zsuccd) {
        this.zsuccd = zsuccd;
    }

    /**
     * @return the znewPno
     */
    public String getZnewPno() {
        return znewPno;
    }

    /**
     * @param znewPno the znewPno to set
     */
    public void setZnewPno(String znewPno) {
        this.znewPno = znewPno;
    }

    /**
     * @return the zlistPrice
     */
    public String getZlistPrice() {
        return zlistPrice;
    }

    /**
     * @param zlistPrice the zlistPrice to set
     */
    public void setZlistPrice(String zlistPrice) {
        this.zlistPrice = zlistPrice;
    }

    /**
     * @return the waers
     */
    public String getWaers() {
        return waers;
    }

    /**
     * @param waers the waers to set
     */
    public void setWaers(String waers) {
        this.waers = waers;
    }

    /**
     * @return the zstkqty
     */
    public String getZstkqty() {
        return zstkqty;
    }

    /**
     * @param zstkqty the zstkqty to set
     */
    public void setZstkqty(String zstkqty) {
        this.zstkqty = zstkqty;
    }

    /**
     * @return the zdueIn
     */
    public String getZdueIn() {
        return zdueIn;
    }

    /**
     * @param zdueIn the zdueIn to set
     */
    public void setZdueIn(String zdueIn) {
        this.zdueIn = zdueIn;
    }

    /**
     * @return the zinterCode
     */
    public String getZinterCode() {
        return zinterCode;
    }

    /**
     * @param zinterCode the zinterCode to set
     */
    public void setZinterCode(String zinterCode) {
        this.zinterCode = zinterCode;
    }

    /**
     * @return the zarea
     */
    public String getZarea() {
        return zarea;
    }

    /**
     * @param zarea the zarea to set
     */
    public void setZarea(String zarea) {
        this.zarea = zarea;
    }

    /**
     * @return the zvhc
     */
    public String getZvhc() {
        return zvhc;
    }

    /**
     * @param zvhc the zvhc to set
     */
    public void setZvhc(String zvhc) {
        this.zvhc = zvhc;
    }

    /**
     * @return the descr
     */
    public String getDescr() {
        return descr;
    }

    /**
     * @param descr the descr to set
     */
    public void setDescr(String descr) {
        this.descr = descr;
    }

    /**
     * @return the iZsuccd
     */
    public String getiZsuccd() {
        return iZsuccd;
    }

    /**
     * @param iZsuccd the iZsuccd to set
     */
    public void setiZsuccd(String iZsuccd) {
        this.iZsuccd = iZsuccd;
    }
    
}
