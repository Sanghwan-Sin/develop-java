package com.mobis.maps.nmgn.qm.vo;

import java.math.BigDecimal;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ClaimMarkUpVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author jiyongdo
 * @since 2020. 3. 13.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 3. 13.     jiyongdo     	최초 생성
 * </pre>
 */

public class ClaimMarkUpVO extends MapsCommSapRfcIfCommVO{
    /** undefined */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZDIST" )
    private String iZdist;
    /** undefined */
    @MapsRfcMappper( ipttSe="E", fieldKey="E_ZCLAMK" )
    private BigDecimal eZclamk;
    /**
     * @return the iZdist
     */
    public String getiZdist() {
        return iZdist;
    }
    /**
     * @param iZdist the iZdist to set
     */
    public void setiZdist(String iZdist) {
        this.iZdist = iZdist;
    }
    /**
     * @return the eZclamk
     */
    public BigDecimal geteZclamk() {
        return eZclamk;
    }
    /**
     * @param eZclamk the eZclamk to set
     */
    public void seteZclamk(BigDecimal eZclamk) {
        this.eZclamk = eZclamk;
    }
    
    
}
