package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : FaqMnlManageVO.java
 * @Description : FaqMnlManageVO
 * @author choi.cheolho
 * @since 2019. 10. 17.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 10. 17.   choi.cheolho      최초 생성
 *               </pre>
 */

public class FaqMnlManageVO extends MapsCommSapRfcIfCommVO {

    /* 조회조건 */
    private String chkYn;
    private String pCmpnySeCd;
    private String pClCd;
    private String pSj;
    private String pFnctSe;
    private String salesOrg;
    private int indictOrdr;
    
    /* 조회결과 */
    /** 순번 **/
    private String regNum;
    /** 문서번호 */
    private String docNo;
    /** 기능구분 */
    private String fnctSe;
    /** 회사구분 */
    private String cmpnySeCd;
    /** 분류(카테고리)코드 */
    private String clCd;
    /** 분류(카테고리)명 */
    private String clNm;
    /** 제목 */
    private String sj;
    /** 내용 */
    private String cn;
    /** 첨부파일명 */
    private String atchmnflNm;
    /** 첨부파일타입 */
    private String atchmnflTy;
    /** 삭제여부 */
    private String delYn;
    /** 등록자ID */
    private String registId;
    /** 수정자ID */
    private String updtId;
    
    private String userId;
    private String detail; // 사용자화면
    
    /**
     * @return the chkYn
     */
    public String getChkYn() {
        return chkYn;
    }
    /**
     * @param chkYn the chkYn to set
     */
    public void setChkYn(String chkYn) {
        this.chkYn = chkYn;
    }
    /**
     * @return the pCmpnySeCd
     */
    public String getpCmpnySeCd() {
        return pCmpnySeCd;
    }
    /**
     * @param pCmpnySeCd the pCmpnySeCd to set
     */
    public void setpCmpnySeCd(String pCmpnySeCd) {
        this.pCmpnySeCd = pCmpnySeCd;
    }
    /**
     * @return the pClCd
     */
    public String getpClCd() {
        return pClCd;
    }
    /**
     * @param pClCd the pClCd to set
     */
    public void setpClCd(String pClCd) {
        this.pClCd = pClCd;
    }
    /**
     * @return the pCn
     */
    public String getpSj() {
        return pSj;
    }
    /**
     * @param pCn the pCn to set
     */
    public void setpSj(String pSj) {
        this.pSj = pSj;
    }
    /**
     * @return the regNum
     */
    public String getRegNum() {
        return regNum;
    }
    /**
     * @param regNum the regNum to set
     */
    public void setRegNum(String regNum) {
        this.regNum = regNum;
    }
    /**
     * @return the docNo
     */
    public String getDocNo() {
        return docNo;
    }
    /**
     * @param docNo the docNo to set
     */
    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }
    /**
     * @return the fnctSe
     */
    public String getFnctSe() {
        return fnctSe;
    }
    /**
     * @param fnctSe the fnctSe to set
     */
    public void setFnctSe(String fnctSe) {
        this.fnctSe = fnctSe;
    }
    /**
     * @return the cmpnySeCd
     */
    public String getCmpnySeCd() {
        return cmpnySeCd;
    }
    /**
     * @param cmpnySeCd the cmpnySeCd to set
     */
    public void setCmpnySeCd(String cmpnySeCd) {
        this.cmpnySeCd = cmpnySeCd;
    }
    /**
     * @return the clCd
     */
    public String getClCd() {
        return clCd;
    }
    /**
     * @param clCd the clCd to set
     */
    public void setClCd(String clCd) {
        this.clCd = clCd;
    }
    
    /**
     * @return the clNm
     */
    public String getClNm() {
        return clNm;
    }
    /**
     * @param clNm the clNm to set
     */
    public void setClNm(String clNm) {
        this.clNm = clNm;
    }
    /**
     * @return the sj
     */
    public String getSj() {
        return sj;
    }
    /**
     * @param sj the sj to set
     */
    public void setSj(String sj) {
        this.sj = sj;
    }
    /**
     * @return the cn
     */
    public String getCn() {
        return cn;
    }
    /**
     * @param cn the cn to set
     */
    public void setCn(String cn) {
        this.cn = cn;
    }
    /**
     * @return the atchmnflNm
     */
    public String getAtchmnflNm() {
        return atchmnflNm;
    }
    /**
     * @param atchmnflNm the atchmnflNm to set
     */
    public void setAtchmnflNm(String atchmnflNm) {
        this.atchmnflNm = atchmnflNm;
    }
    /**
     * @return the atchmnflTy
     */
    public String getAtchmnflTy() {
        return atchmnflTy;
    }
    /**
     * @param atchmnflTy the atchmnflTy to set
     */
    public void setAtchmnflTy(String atchmnflTy) {
        this.atchmnflTy = atchmnflTy;
    }
    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }
    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }
    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }
    /**
     * @return the updtId
     */
    public String getUpdtId() {
        return updtId;
    }
    /**
     * @param updtId the updtId to set
     */
    public void setUpdtId(String updtId) {
        this.updtId = updtId;
    }
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the pFnctSe
     */
    public String getpFnctSe() {
        return pFnctSe;
    }
    /**
     * @param pFnctSe the pFnctSe to set
     */
    public void setpFnctSe(String pFnctSe) {
        this.pFnctSe = pFnctSe;
    }
    /**
     * @return the salesOrg
     */
    public String getSalesOrg() {
        return salesOrg;
    }
    /**
     * @param salesOrg the salesOrg to set
     */
    public void setSalesOrg(String salesOrg) {
        this.salesOrg = salesOrg;
    }
    /**
     * @return the detail
     */
    public String getDetail() {
        return detail;
    }
    /**
     * @param detail the detail to set
     */
    public void setDetail(String detail) {
        this.detail = detail;
    }
    /**
     * @return the indictOrdr
     */
    public int getIndictOrdr() {
        return indictOrdr;
    }
    /**
     * @param indictOrdr the indictOrdr to set
     */
    public void setIndictOrdr(int indictOrdr) {
        this.indictOrdr = indictOrdr;
    }
}
