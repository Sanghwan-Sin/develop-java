package com.mobis.maps.nmgn.cc.vo;

import java.util.Date;

import com.mobis.maps.comm.vo.PgBascVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : NewsLetterVO.java
 * @Description : News Letter
 * @author 이수지
 * @since 2020. 03. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 03. 31.     이수지            	최초 생성
 * </pre>
 */

public class NewsLetterVO extends PgBascVO{
    
    /* 조회조건 */
    /** Category */
    private String iCategory;
    /** Subject */
    private String iSj;
    /** Date(시작일)*/
    private String iStrDate;
    /** Date(종료일)*/
    private String iFnhDate;
    /** 저장 여부 */
    private String iStreYn;
    
    /* 조회결과 */
    /** 순번 **/
    private String regNum;
    /** 뉴스레터순번 */
    private String refNo;
    /** 뉴스레터내용 */
    private String newsletterCn;
    /** 뉴스레터제목 */
    private String newsletterSj;
    /** 카테고리 코드 */
    private String categoryCd;
    /** 등록자ID */
    private String registId;
    /** 수정자ID */
    private String updtId;
    /** 송신자ID */
    private String sndngId;
    /** 삭제자ID */
    private String deleteId;
    /** 수신자이메일 */
    private String emailTo;
    /** 수신자이메일*/
    private String recptnEmail;
    /** 참조 */
    private String recptnCc;
    private String recptnEmailDesc;
    private String emailCcDesc;
    /** 등록일 */
    private Date registDate;
    /** 수정일 */
    private Date updtDate;
    /** 송신일 */
    private Date sndngdt;
    /** 삭제일 */
    private Date deleteDt;
    /** 삭제여부 */
    private String delYn;
    /** 전송여부 */
    private String sndngYn;
    /** 저장여부 */
    private String streYn;
    /** 조직코드 */
    private String salesOrg;
    /** Read Count */
    private String rcnt;
    /** Attach File Count */
    private String atchCnt;

    private String atchSe;
    private String atchId;
    private String seq;
    private String statYn;
    private String mailYn;
    private String mainYn;
    
    /**
     * @return the iCategory
     */
    public String getiCategory() {
        return iCategory;
    }
    /**
     * @param iCategory the iCategory to set
     */
    public void setiCategory(String iCategory) {
        this.iCategory = iCategory;
    }
    /**
     * @return the iSj
     */
    public String getiSj() {
        return iSj;
    }
    /**
     * @param iSj the iSj to set
     */
    public void setiSj(String iSj) {
        this.iSj = iSj;
    }
    /**
     * @return the iStrDate
     */
    public String getiStrDate() {
        return iStrDate;
    }
    /**
     * @param iStrDate the iStrDate to set
     */
    public void setiStrDate(String iStrDate) {
        this.iStrDate = iStrDate;
    }
    /**
     * @return the iFnhDate
     */
    public String getiFnhDate() {
        return iFnhDate;
    }
    /**
     * @param iFnhDate the iFnhDate to set
     */
    public void setiFnhDate(String iFnhDate) {
        this.iFnhDate = iFnhDate;
    }
    /**
     * @return the regNum
     */
    public String getRegNum() {
        return regNum;
    }
    /**
     * @param regNum the regNum to set
     */
    public void setRegNum(String regNum) {
        this.regNum = regNum;
    }
    /**
     * @return the refNo
     */
    public String getRefNo() {
        return refNo;
    }
    /**
     * @param refNo the refNo to set
     */
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    /**
     * @return the newsletterSj
     */
    public String getNewsletterSj() {
        return newsletterSj;
    }
    /**
     * @param newsletterSj the newsletterSj to set
     */
    public void setNewsletterSj(String newsletterSj) {
        this.newsletterSj = newsletterSj;
    }
    /**
     * @return the categoryCd
     */
    public String getCategoryCd() {
        return categoryCd;
    }
    /**
     * @param categoryCd the categoryCd to set
     */
    public void setCategoryCd(String categoryCd) {
        this.categoryCd = categoryCd;
    }
    /**
     * @return the registId
     */
    public String getRegistId() {
        return registId;
    }
    /**
     * @param registId the registId to set
     */
    public void setRegistId(String registId) {
        this.registId = registId;
    }
    /**
     * @return the updtId
     */
    public String getUpdtId() {
        return updtId;
    }
    /**
     * @param updtId the updtId to set
     */
    public void setUpdtId(String updtId) {
        this.updtId = updtId;
    }
    /**
     * @return the sndngId
     */
    public String getSndngId() {
        return sndngId;
    }
    /**
     * @param sndngId the sndngId to set
     */
    public void setSndngId(String sndngId) {
        this.sndngId = sndngId;
    }
    /**
     * @return the deleteId
     */
    public String getDeleteId() {
        return deleteId;
    }
    /**
     * @param deleteId the deleteId to set
     */
    public void setDeleteId(String deleteId) {
        this.deleteId = deleteId;
    }
    /**
     * @return the sndngdt
     */
    public Date getSndngdt() {
        return sndngdt;
    }
    /**
     * @param sndngdt the sndngdt to set
     */
    public void setSndngdt(Date sndngdt) {
        this.sndngdt = sndngdt;
    }
    /**
     * @return the deleteDt
     */
    public Date getDeleteDt() {
        return deleteDt;
    }
    /**
     * @param deleteDt the deleteDt to set
     */
    public void setDeleteDt(Date deleteDt) {
        this.deleteDt = deleteDt;
    }
    /**
     * @return the delYn
     */
    public String getDelYn() {
        return delYn;
    }
    /**
     * @param delYn the delYn to set
     */
    public void setDelYn(String delYn) {
        this.delYn = delYn;
    }
    /**
     * @return the sndngYn
     */
    public String getSndngYn() {
        return sndngYn;
    }
    /**
     * @param sndngYn the sndngYn to set
     */
    public void setSndngYn(String sndngYn) {
        this.sndngYn = sndngYn;
    }
    /**
     * @return the streYn
     */
    public String getStreYn() {
        return streYn;
    }
    /**
     * @param streYn the streYn to set
     */
    public void setStreYn(String streYn) {
        this.streYn = streYn;
    }
    /**
     * @return the registDate
     */
    public Date getRegistDate() {
        return registDate;
    }
    /**
     * @param registDate the registDate to set
     */
    public void setRegistDate(Date registDate) {
        this.registDate = registDate;
    }
    /**
     * @return the updtDate
     */
    public Date getUpdtDate() {
        return updtDate;
    }
    /**
     * @param updtDate the updtDate to set
     */
    public void setUpdtDate(Date updtDate) {
        this.updtDate = updtDate;
    }
    /**
     * @return the newsletterCn
     */
    public String getNewsletterCn() {
        return newsletterCn;
    }
    /**
     * @param newsletterCn the newsletterCn to set
     */
    public void setNewsletterCn(String newsletterCn) {
        this.newsletterCn = newsletterCn;
    }
    /**
     * @return the recptnEmail
     */
    public String getRecptnEmail() {
        return recptnEmail;
    }
    /**
     * @param recptnEmail the recptnEmail to set
     */
    public void setRecptnEmail(String recptnEmail) {
        this.recptnEmail = recptnEmail;
    }
    /**
     * @return the recptnCc
     */
    public String getRecptnCc() {
        return recptnCc;
    }
    /**
     * @param recptnCc the recptnCc to set
     */
    public void setRecptnCc(String recptnCc) {
        this.recptnCc = recptnCc;
    }
    /**
     * @return the atchSe
     */
    public String getAtchSe() {
        return atchSe;
    }
    /**
     * @param atchSe the atchSe to set
     */
    public void setAtchSe(String atchSe) {
        this.atchSe = atchSe;
    }
    /**
     * @return the atchId
     */
    public String getAtchId() {
        return atchId;
    }
    /**
     * @param atchId the atchId to set
     */
    public void setAtchId(String atchId) {
        this.atchId = atchId;
    }
    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }
    /**
     * @return the statYn
     */
    public String getStatYn() {
        return statYn;
    }
    /**
     * @param statYn the statYn to set
     */
    public void setStatYn(String statYn) {
        this.statYn = statYn;
    }
    /**
     * @return the mailYn
     */
    public String getMailYn() {
        return mailYn;
    }
    /**
     * @param mailYn the mailYn to set
     */
    public void setMailYn(String mailYn) {
        this.mailYn = mailYn;
    }
    /**
     * @return the vkorg
     */
    public String getSalesOrg() {
        return salesOrg;
    }
    /**
     * @param vkorg the vkorg to set
     */
    public void setSalesOrg(String salesOrg) {
        this.salesOrg = salesOrg;
    }
    /**
     * @return the emailTo
     */
    public String getEmailTo() {
        return emailTo;
    }
    /**
     * @param emailTo the emailTo to set
     */
    public void setEmailTo(String emailTo) {
        this.emailTo = emailTo;
    }
    /**
     * @return the recptnEmailDesc
     */
    public String getRecptnEmailDesc() {
        return recptnEmailDesc;
    }
    /**
     * @param recptnEmailDesc the recptnEmailDesc to set
     */
    public void setRecptnEmailDesc(String recptnEmailDesc) {
        this.recptnEmailDesc = recptnEmailDesc;
    }
    /**
     * @return the emailCcDesc
     */
    public String getEmailCcDesc() {
        return emailCcDesc;
    }
    /**
     * @param emailCcDesc the emailCcDesc to set
     */
    public void setEmailCcDesc(String emailCcDesc) {
        this.emailCcDesc = emailCcDesc;
    }
    /**
     * @return the rcnt
     */
    public String getRcnt() {
        return rcnt;
    }
    /**
     * @param rcnt the rcnt to set
     */
    public void setRcnt(String rcnt) {
        this.rcnt = rcnt;
    }
    /**
     * @return the iStreYn
     */
    public String getiStreYn() {
        return iStreYn;
    }
    /**
     * @param iStreYn the iStreYn to set
     */
    public void setiStreYn(String iStreYn) {
        this.iStreYn = iStreYn;
    }
    /**
     * @return the mainYn
     */
    public String getMainYn() {
        return mainYn;
    }
    /**
     * @param mainYn the mainYn to set
     */
    public void setMainYn(String mainYn) {
        this.mainYn = mainYn;
    }
    /**
     * @return the atchCnt
     */
    public String getAtchCnt() {
        return atchCnt;
    }
    /**
     * @param atchCnt the atchCnt to set
     */
    public void setAtchCnt(String atchCnt) {
        this.atchCnt = atchCnt;
    }
    
}
