package com.mobis.maps.nmgn.cc.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : DistInfoVO.java
 * @Description : DistInfoVO
 * @author ha.jeongryeong
 * @since 2019. 7. 19.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2019. 7. 19.    ha.jeongryeong      최초 생성
 *               </pre>
 */

public class WorkCalendarVO extends MapsCommSapRfcIfCommVO {

    /* 조회조건 */
    private String corpCode;
    private String year;
    private String month;
    
    /* 조회결과 */
    private String date0;
    private String date1;
    private String date2;
    private String date3;
    private String date4;
    private String date5;
    private String date6;
    
    private String data0;
    private String data1;
    private String data2;
    private String data3;
    private String data4;
    private String data5;
    private String data6;
    
    private String holMon;
    private String holDate;
    private String holName;
    
    
    /**
     * @return the holMon
     */
    public String getHolMon() {
        return holMon;
    }
    /**
     * @param holMon the holMon to set
     */
    public void setHolMon(String holMon) {
        this.holMon = holMon;
    }
    /**
     * @return the holDate
     */
    public String getHolDate() {
        return holDate;
    }
    /**
     * @param holDate the holDate to set
     */
    public void setHolDate(String holDate) {
        this.holDate = holDate;
    }
    /**
     * @return the holName
     */
    public String getHolName() {
        return holName;
    }
    /**
     * @param holName the holName to set
     */
    public void setHolName(String holName) {
        this.holName = holName;
    }
    /**
     * @return the year
     */
    public String getYear() {
        return year;
    }
    /**
     * @param year the year to set
     */
    public void setYear(String year) {
        this.year = year;
    }
    /**
     * @return the month
     */
    public String getMonth() {
        return month;
    }
    /**
     * @param month the month to set
     */
    public void setMonth(String month) {
        this.month = month;
    }
    /**
     * @return the corpCode
     */
    public String getCorpCode() {
        return corpCode;
    }
    /**
     * @param corpCode the corpCode to set
     */
    public void setCorpCode(String corpCode) {
        this.corpCode = corpCode;
    }
    /**
     * @return the date0
     */
    public String getDate0() {
        return date0;
    }
    /**
     * @param date0 the date0 to set
     */
    public void setDate0(String date0) {
        this.date0 = date0;
    }
    /**
     * @return the date1
     */
    public String getDate1() {
        return date1;
    }
    /**
     * @param date1 the date1 to set
     */
    public void setDate1(String date1) {
        this.date1 = date1;
    }
    /**
     * @return the date2
     */
    public String getDate2() {
        return date2;
    }
    /**
     * @param date2 the date2 to set
     */
    public void setDate2(String date2) {
        this.date2 = date2;
    }
    /**
     * @return the date3
     */
    public String getDate3() {
        return date3;
    }
    /**
     * @param date3 the date3 to set
     */
    public void setDate3(String date3) {
        this.date3 = date3;
    }
    /**
     * @return the date4
     */
    public String getDate4() {
        return date4;
    }
    /**
     * @param date4 the date4 to set
     */
    public void setDate4(String date4) {
        this.date4 = date4;
    }
    /**
     * @return the date5
     */
    public String getDate5() {
        return date5;
    }
    /**
     * @param date5 the date5 to set
     */
    public void setDate5(String date5) {
        this.date5 = date5;
    }
    /**
     * @return the date6
     */
    public String getDate6() {
        return date6;
    }
    /**
     * @param date6 the date6 to set
     */
    public void setDate6(String date6) {
        this.date6 = date6;
    }
    /**
     * @return the data0
     */
    public String getData0() {
        return data0;
    }
    /**
     * @param data0 the data0 to set
     */
    public void setData0(String data0) {
        this.data0 = data0;
    }
    /**
     * @return the data1
     */
    public String getData1() {
        return data1;
    }
    /**
     * @param data1 the data1 to set
     */
    public void setData1(String data1) {
        this.data1 = data1;
    }
    /**
     * @return the data2
     */
    public String getData2() {
        return data2;
    }
    /**
     * @param data2 the data2 to set
     */
    public void setData2(String data2) {
        this.data2 = data2;
    }
    /**
     * @return the data3
     */
    public String getData3() {
        return data3;
    }
    /**
     * @param data3 the data3 to set
     */
    public void setData3(String data3) {
        this.data3 = data3;
    }
    /**
     * @return the data4
     */
    public String getData4() {
        return data4;
    }
    /**
     * @param data4 the data4 to set
     */
    public void setData4(String data4) {
        this.data4 = data4;
    }
    /**
     * @return the data5
     */
    public String getData5() {
        return data5;
    }
    /**
     * @param data5 the data5 to set
     */
    public void setData5(String data5) {
        this.data5 = data5;
    }
    /**
     * @return the data6
     */
    public String getData6() {
        return data6;
    }
    /**
     * @param data6 the data6 to set
     */
    public void setData6(String data6) {
        this.data6 = data6;
    }
    
}
