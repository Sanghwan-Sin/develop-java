package com.mobis.maps.nmgn.sd.vo;

import java.util.Date;

import com.mobis.maps.cmmn.annotation.MapsRfcMappper;
import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PromotionExportCeilingVO.java
 * @Description : ZPSD_MGN_S_PROMOTION_RESULT
 * @author 이수지
 * @since 2020. 06. 22.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 06. 22.       이수지     	       최초 생성
 * </pre>
 */

public class PromotionExportCeilingVO extends MapsCommSapRfcIfCommVO {

    /** Date */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATES_F" )
    private Date iDatesF;
    /** Date */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_DATES_T" )
    private Date iDatesT;
    /** Approval Status */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_STATUS" )
    private String iStatus;
    /** C/R/U/D (조회:R) */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_TYPE" )
    private String iType;
    /** 프로모션 프로파일 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPPI_F" )
    private String iZppiF;
    /** 프로모션 프로파일 번호 */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPPI_T" )
    private String iZppiT;
    /** 프로모션 Type */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZPRTYP" )
    private String iZprtyp;
    /** Dist Code */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM" )
    private String iZsacutm;
    /**  */
    @MapsRfcMappper( ipttSe="I", fieldKey="I_ZSACUTM_SUB" )
    private String iZsacutmSub;
    
    /** -----[T_RESULT] START----- */
    
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPI" )
    private String zppi;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRNM" )
    private String zprnm;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRTYP" )
    private String zprtyp;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPRTYP_NM" )
    private String zprtypNm;
    /** Dist. Code */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSACUTM" )
    private String zsacutm;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NAME1" )
    private String name1;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPIST" )
    private String zppist;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPPIEN" )
    private String zppien;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZSTATUS" )
    private String zstatus;
    /** Price List Type */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="PLTYP" )
    private String pltyp;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NETWR_B" )
    private String netwrB;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NETWR_A" )
    private String netwrA;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="NETWR_D" )
    private String netwrD;
    /** SD document currency */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="WAERK" )
    private String waerk;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZLEVEL" )
    private String zlevel;
    /**  */
    @MapsRfcMappper( targetName="T_RESULT", ipttSe="E", fieldKey="ZPARENT_ID" )
    private String zparentId;
    private int count;
    
    /** -----[T_RESULT] END----- */
    
    /**
     * @return the iDatesF
     */
    public Date getiDatesF() {
        return iDatesF;
    }
    /**
     * @param iDatesF the iDatesF to set
     */
    public void setiDatesF(Date iDatesF) {
        this.iDatesF = iDatesF;
    }
    /**
     * @return the iDatesT
     */
    public Date getiDatesT() {
        return iDatesT;
    }
    /**
     * @param iDatesT the iDatesT to set
     */
    public void setiDatesT(Date iDatesT) {
        this.iDatesT = iDatesT;
    }
    /**
     * @return the iStatus
     */
    public String getiStatus() {
        return iStatus;
    }
    /**
     * @param iStatus the iStatus to set
     */
    public void setiStatus(String iStatus) {
        this.iStatus = iStatus;
    }
    /**
     * @return the iType
     */
    public String getiType() {
        return iType;
    }
    /**
     * @param iType the iType to set
     */
    public void setiType(String iType) {
        this.iType = iType;
    }
    /**
     * @return the iZppiF
     */
    public String getiZppiF() {
        return iZppiF;
    }
    /**
     * @param iZppiF the iZppiF to set
     */
    public void setiZppiF(String iZppiF) {
        this.iZppiF = iZppiF;
    }
    /**
     * @return the iZppiT
     */
    public String getiZppiT() {
        return iZppiT;
    }
    /**
     * @param iZppiT the iZppiT to set
     */
    public void setiZppiT(String iZppiT) {
        this.iZppiT = iZppiT;
    }
    /**
     * @return the iZprtyp
     */
    public String getiZprtyp() {
        return iZprtyp;
    }
    /**
     * @param iZprtyp the iZprtyp to set
     */
    public void setiZprtyp(String iZprtyp) {
        this.iZprtyp = iZprtyp;
    }
    /**
     * @return the iZsacutm
     */
    public String getiZsacutm() {
        return iZsacutm;
    }
    /**
     * @param iZsacutm the iZsacutm to set
     */
    public void setiZsacutm(String iZsacutm) {
        this.iZsacutm = iZsacutm;
    }
    /**
     * @return the zppi
     */
    public String getZppi() {
        return zppi;
    }
    /**
     * @param zppi the zppi to set
     */
    public void setZppi(String zppi) {
        this.zppi = zppi;
    }
    /**
     * @return the zprnm
     */
    public String getZprnm() {
        return zprnm;
    }
    /**
     * @param zprnm the zprnm to set
     */
    public void setZprnm(String zprnm) {
        this.zprnm = zprnm;
    }
    /**
     * @return the zprtyp
     */
    public String getZprtyp() {
        return zprtyp;
    }
    /**
     * @param zprtyp the zprtyp to set
     */
    public void setZprtyp(String zprtyp) {
        this.zprtyp = zprtyp;
    }
    /**
     * @return the zprtypNm
     */
    public String getZprtypNm() {
        return zprtypNm;
    }
    /**
     * @param zprtypNm the zprtypNm to set
     */
    public void setZprtypNm(String zprtypNm) {
        this.zprtypNm = zprtypNm;
    }
    /**
     * @return the zsacutm
     */
    public String getZsacutm() {
        return zsacutm;
    }
    /**
     * @param zsacutm the zsacutm to set
     */
    public void setZsacutm(String zsacutm) {
        this.zsacutm = zsacutm;
    }
    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }
    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }
    /**
     * @return the zppist
     */
    public String getZppist() {
        return zppist;
    }
    /**
     * @param zppist the zppist to set
     */
    public void setZppist(String zppist) {
        this.zppist = zppist;
    }
    /**
     * @return the zppien
     */
    public String getZppien() {
        return zppien;
    }
    /**
     * @param zppien the zppien to set
     */
    public void setZppien(String zppien) {
        this.zppien = zppien;
    }
    /**
     * @return the zstatus
     */
    public String getZstatus() {
        return zstatus;
    }
    /**
     * @param zstatus the zstatus to set
     */
    public void setZstatus(String zstatus) {
        this.zstatus = zstatus;
    }
    /**
     * @return the pltyp
     */
    public String getPltyp() {
        return pltyp;
    }
    /**
     * @param pltyp the pltyp to set
     */
    public void setPltyp(String pltyp) {
        this.pltyp = pltyp;
    }
    /**
     * @return the netwrB
     */
    public String getNetwrB() {
        return netwrB;
    }
    /**
     * @param netwrB the netwrB to set
     */
    public void setNetwrB(String netwrB) {
        this.netwrB = netwrB;
    }
    /**
     * @return the netwrA
     */
    public String getNetwrA() {
        return netwrA;
    }
    /**
     * @param netwrA the netwrA to set
     */
    public void setNetwrA(String netwrA) {
        this.netwrA = netwrA;
    }
    /**
     * @return the netwrD
     */
    public String getNetwrD() {
        return netwrD;
    }
    /**
     * @param netwrD the netwrD to set
     */
    public void setNetwrD(String netwrD) {
        this.netwrD = netwrD;
    }
    /**
     * @return the waerk
     */
    public String getWaerk() {
        return waerk;
    }
    /**
     * @param waerk the waerk to set
     */
    public void setWaerk(String waerk) {
        this.waerk = waerk;
    }
    /**
     * @return the zlevel
     */
    public String getZlevel() {
        return zlevel;
    }
    /**
     * @param zlevel the zlevel to set
     */
    public void setZlevel(String zlevel) {
        this.zlevel = zlevel;
    }
    /**
     * @return the zparentId
     */
    public String getZparentId() {
        return zparentId;
    }
    /**
     * @param zparentId the zparentId to set
     */
    public void setZparentId(String zparentId) {
        this.zparentId = zparentId;
    }
    /**
     * @return the count
     */
    public int getCount() {
        return count;
    }
    /**
     * @param count the count to set
     */
    public void setCount(int count) {
        this.count = count;
    }
    /**
     * @return the iZsacutmSub
     */
    public String getiZsacutmSub() {
        return iZsacutmSub;
    }
    /**
     * @param iZsacutmSub the iZsacutmSub to set
     */
    public void setiZsacutmSub(String iZsacutmSub) {
        this.iZsacutmSub = iZsacutmSub;
    }
    
}
