package com.mobis.maps.nmgn.sd.vo;

import com.mobis.maps.comm.vo.MapsCommSapRfcIfCommVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : ZPSDS3258VO.java
 * @Description : MBOR : Backorder Status
 * @author hong.minho
 * @since 2020. 7. 20.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2020. 7. 20.     hong.minho     	최초 생성
 * </pre>
 */

public class ZPSDS3258VO extends MapsCommSapRfcIfCommVO {
    private String ordno;   /* [ordno,0~10  ] Order Number */
    private String ordln;   /* [ordln,10~14 ] Line Item Number */
    private String ordls;   /* [ordls,14~15 ] Line Item Number Suffix */
    private String bptno;   /* [bptno,15~33 ] Supplied Part Number */
    private String cfqty;   /* [cfqty,33~38 ] Confirmed Quantity */
    private String spqty;   /* [spqty,38~43 ] Shipped Quantity */
    private String fbqty;   /* [fbqty,43~48 ] Processing Quantity */
    private String ubqty;   /* [ubqty,48~53 ] Back Order Quantity */
    private String etddt;   /* [etddt,53~61 ] ETD */
    private String cptno;   /* [cptno,61~79 ] Confirmed Part Number */
    private String intcd;   /* [intcd,79~80 ] Intermediary Trade */
    /**
     * @return the ordno
     */
    public String getOrdno() {
        return ordno;
    }
    /**
     * @param ordno the ordno to set
     */
    public void setOrdno(String ordno) {
        this.ordno = ordno;
    }
    /**
     * @return the ordln
     */
    public String getOrdln() {
        return ordln;
    }
    /**
     * @param ordln the ordln to set
     */
    public void setOrdln(String ordln) {
        this.ordln = ordln;
    }
    /**
     * @return the ordls
     */
    public String getOrdls() {
        return ordls;
    }
    /**
     * @param ordls the ordls to set
     */
    public void setOrdls(String ordls) {
        this.ordls = ordls;
    }
    /**
     * @return the bptno
     */
    public String getBptno() {
        return bptno;
    }
    /**
     * @param bptno the bptno to set
     */
    public void setBptno(String bptno) {
        this.bptno = bptno;
    }
    /**
     * @return the cfqty
     */
    public String getCfqty() {
        return cfqty;
    }
    /**
     * @param cfqty the cfqty to set
     */
    public void setCfqty(String cfqty) {
        this.cfqty = cfqty;
    }
    /**
     * @return the spqty
     */
    public String getSpqty() {
        return spqty;
    }
    /**
     * @param spqty the spqty to set
     */
    public void setSpqty(String spqty) {
        this.spqty = spqty;
    }
    /**
     * @return the fbqty
     */
    public String getFbqty() {
        return fbqty;
    }
    /**
     * @param fbqty the fbqty to set
     */
    public void setFbqty(String fbqty) {
        this.fbqty = fbqty;
    }
    /**
     * @return the ubqty
     */
    public String getUbqty() {
        return ubqty;
    }
    /**
     * @param ubqty the ubqty to set
     */
    public void setUbqty(String ubqty) {
        this.ubqty = ubqty;
    }
    /**
     * @return the etddt
     */
    public String getEtddt() {
        return etddt;
    }
    /**
     * @param etddt the etddt to set
     */
    public void setEtddt(String etddt) {
        this.etddt = etddt;
    }
    /**
     * @return the cptno
     */
    public String getCptno() {
        return cptno;
    }
    /**
     * @param cptno the cptno to set
     */
    public void setCptno(String cptno) {
        this.cptno = cptno;
    }
    /**
     * @return the intcd
     */
    public String getIntcd() {
        return intcd;
    }
    /**
     * @param intcd the intcd to set
     */
    public void setIntcd(String intcd) {
        this.intcd = intcd;
    }

}
